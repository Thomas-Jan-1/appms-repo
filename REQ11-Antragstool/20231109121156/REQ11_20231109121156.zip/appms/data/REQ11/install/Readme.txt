Readme f�r Ordner "Install":
----------------------------


Verwendungszweck des Ordners:
- Installationsskripte
- DB-Modell, bspw. im XML-Format