<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

/**
 * Die Klasse stellt Funktionen bereit, welche mit Button-Clicks verbunden werden können.
 * Dazu müssen die Funktionen in der Datenbanktabelle manager.button_functions registriert werden.
 * 
 * Als Beispiele können alle Methoden in ../controller/pagedata_class.php dienen, die mit dem Präfix
 * "internFunction_" beginnen. Einziger zu beachtender Unterschied ist dabei, dass diese sich bereits 
 * in dem Objekt  pagedata befinden und daher auf andere Methoden desselben Objektes  mit "$this" zugreifen.
 * Hier erfolgt der Zugriff auf das pagedata-Objekt über den Übergabeparameter "$in_pagedata".
 * 
 *
 * @author Thomas J.
 */


require_once("../controller/mask_class.php");
require_once("../controller/form_class.php");


class functions_buttonclick {
    
    
   
     /**
     *
     * @var     string     APP-ID der CMS-Anwendung 
     */
    protected $app_id;
    
    /**
     *
     * @var     integer     ID der neu erstellten Maske 
     */
    protected $mask_id;
    
    /**
     *
     * @var     string      APP-ID der Maske
     */
    protected $mask_app_id;
    
    /**
     *
     * @var     integer     ID der htmltaggroup, welche als Formulare aufnimmt. 
     */
    protected $htmltaggroupForForms_id;
    
    /**
     *
     * @var     string      APP-ID  der htmltaggroup, welche als Formulare aufnimmt. 
     */
    protected $htmltaggroupForForms_app_id;
    
    /**
     *
     * @var     integer     ID des neu erstellten Formulars in der Maske 
     */
    protected $form_id;
    
    /**
     *
     * @var     integer     ID des htmltag (Maskenelement), in dem sich das Formular befindet. 
     */
    protected $htmltag_id;
        
    /**
     *
     * @var     integer     ID des Artikels, welcher als Condition für das Formular genutzt wird.
     */
//    protected $article_id;
    
    /**
     *
     * @var     string      Name des Artikels. 
     */
//    protected $article_name;
    
    
    /**
     *
     * @var     string      Name des Schemas der APP REQ11; Default = appms_req11 
     */
    protected $req_schema = "appms_req11";
    
    /**
     *
     * @var     string      Connection-ID = APP-ID = REQ11
     */
    protected $req_connection_id = "REQ11";
    
    
    
    
    
    function __construct() 
    { 
        
    }
    

    
    
    /** Fügt Daten in die Tabelle datastore ein, sendet eine Mail und legt Attachements (falls vorhanden)
     * in der Tabelle files ab. Falls FILES hochgeladen wurden, werden diese in der DB-Tabelle files abgelegt
     * und beim Mailversand angefügt.
     * 
     * Alte Anträge, deren timetodelete erreicht ist, werden gelöscht.
     * 
     * @param   obhsct      $in_pagedata    Referenz zum pagedata-object
     * @return  integer                     Returncode, siehe konstantentyp_id = 35 [220|-220]     
     */
    public function insertDataWithFilesAndSendMail(&$in_pagedata) {
        
        //alte Anträge löschen
        $this->deleteOldRequests($in_pagedata);
        
        
        //deleteTime in newData ergänzen
        $delete_time = $this->getDeleteTimeForRequest($in_pagedata);
        $in_pagedata->getPostObject()->addNewDataContentAttribut(0, "timetodelete", $delete_time);

        
        //neuen Datensatz in datastore anlegen
        $insertFeedback = $in_pagedata->internFunction_insertDataAndSendMail();
        
        if($insertFeedback >= 0) {
            
            //Requestdaten (last_insert) holen
            $new_data = $in_pagedata->getNewDataFromPostarray();
            $request_data = $new_data[0]["content"];
            
            //id des neuen Datensatzes ermitteln
            $table = $new_data[0]["table"];
            $datastore_id = $in_pagedata->getIdFromAutoIncrementColumn($table.".id");

            //Filedaten ermitteln -> filesBase64 und lastInsert
            $file_Array = $in_pagedata->filesBase64;

            foreach ($file_Array as $key => $current_file) {
                //neue/n Datensatz in datastore_files anlegen, wenn vorhanden
                $in_pagedata->filesBase64[$key]["datastore_id"] = $datastore_id;
                $file_id = $this->setNewDatastoreFile($in_pagedata, "REQ11", $this->req_schema, $request_data["datastore.form_app_id"], $request_data["datastore.form_id"], $datastore_id, $current_file["name"], $current_file["filebase64"], $current_file["mimetype"], $current_file["filesize"]);

            }
        }
        
        return $insertFeedback;
    }
    
    
    
    
    /** Ermittelt, anhand der Angabe form.time_to_delete, die Löschfrist.
     * 
     * @param   object  $in_pagedata    pagedata-Objekt
     * @return  string                  Löschfrist im Format "Y-m-d H:i:s" (Bsp.: 2001-03-10 17:16:18 ) oder ein Leerstring, wenn form.time:to_delete leer ist
     */
    private function getDeleteTimeForRequest(&$in_pagedata) {
        
        
        //sender_form_id ermitteln
        $form_id = $in_pagedata->getPostObject()->getSenderformId();
        
        //time_to_delete von sender_form ermitteln
        $time_to_delete = $in_pagedata->getFormPropertyTimetodelete($form_id);
        if($time_to_delete == "") {
            //keine Löschfrist
            $feedback = "";
        } else {
            //deletetime berechnen
            $date = new DateTime("now");
            $date->add(new DateInterval('PT'.$time_to_delete.'S'));             //time_to_delete als Sekunden ergänzen
            $feedback = $date->format('Y-m-d H:i:s');
            
        }
        
        return $feedback;
        
    }
    
    
    
    
    
    
    /** Löscht alle Einträge der datastore-Tabelle, die den timetodelete-Wert erreicht haben.
     * 
     * @param  object   $in_pagadata            Referenz auf das pagedata-object
     * @return boolean
     */
    function deleteOldRequests(&$in_pagadata) {

        $app_id_from_kernel = global_variables::getAppIdFromSYS01();
        $sql_functionplaceholder_start_tag = getConfig("sql_start_tag_function_placeholder", $app_id_from_kernel);
        $sql_functionplaceholder_end_tag = getConfig("sql_end_tag_function_placeholder", $app_id_from_kernel);
        $where = " timetodelete is not null and timetodelete < current_timestamp - ".$sql_functionplaceholder_start_tag."function_name=interval?interval_value=1&interval_type=SECOND".$sql_functionplaceholder_end_tag;          //DB-unabhängige Syntax
        
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> lösche alte Anträge mit folgender Bedingung: ', $where);
       
        
        
        $deleteCommand = array("into" => "",
            "values" => "",
            "update" => "",
            "schema" => $this->req_schema,
            "table" => "datastore",
            "where" => $where,
            "logdata" => "",
            "logdata_id_data" => "");

        $dummy_form = array("form.logging" => 0, "form.app_id" => $this->req_connection_id);
        $dummy_account_id = "nobody";
        $dummy_form["form.connection_id"] = $this->req_connection_id;

        $feedback = deleteData($deleteCommand, $dummy_form, $dummy_account_id, $in_pagadata);
        return $feedback;


    }
    
    
    /** schreibt einen Datensatz in appms_req11.files
     * 
     * @param   object      $in_pagedata            Referenz auf das pagedata-object
     * @param   string      $in_table_app_id        APP-ID der Zieltabelle (files) 
     * @param   string      $in_schema              Schema der Zieltabelle
     * @param   string      $in_form_app_id         APP-ID des sendenden Formulars
     * @param   integer     $in_form_id             ID des sendenden Formulars
     * @param   integer     $in_datastore_id        ID des Datensatzes in datastore, zu dem die Files referenziert werden müssen.
     * @param   string      $in_file_name           Name der Datei
     * @param   string      $in_filebase64          Dateiinhalt
     * @param   string      $in_mimetype            Dateityp
     * @param   integer     $in_filesize            [biginteger] Größe der Datei in byte
     * @return  mixed                               ID des gerade eingefügten Datensatzes oder false
     */
    protected function setNewDatastoreFile(&$in_pagedata, $in_table_app_id, $in_schema, $in_form_app_id, $in_form_id, $in_datastore_id, $in_file_name, &$in_filebase64, $in_mimetype, $in_filesize) {
        
        
        $nextID = getMaxValue($in_table_app_id, $in_schema, "files", "id");
        $nextID = $nextID + rand(1,10);
        
        
        
        $SqlArray = array();
        $SqlArray["schema"] = $in_schema;
        $SqlArray["table"] = "files";
	$SqlArray["into"]   = " id, datastore_id, form_id, form_app_id, "
                            . "name, filebase64, mimetype, filesize";
	$SqlArray["values"] =   $nextID.", ".$in_datastore_id.", ".$in_form_id.", '".$in_form_app_id."', '".
                                $in_file_name."', '".$in_filebase64."', '".$in_mimetype."', ".$in_filesize;           
        
        //dummy_form ist nur für logging relevant
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getCurrentUserFromSession(), $in_pagedata);
        
        if ($result == false) {return false;} else {return $nextID;}
    }
    
    
    
    
    
     /** Ergänzt ein neues Antragsformular in REQ11.
     * Dabei werden folgende Schritte ausgeführt:
     * 1. neue Maske anlegen
     * 2. Maske für aktive Rolle freischalten
     * 3. Maske für Rolle guest freischalten, aber sperren
     * 4.1 Symbolleiste von WYSIWIK wird für Gastrolle deaktiviert
     * 4.2 Symbolleiste SYS01-Hinweis ergänzen
     * 4.3 Symbolleiste REQ11-Workflow ergänzen
     * 5. Maskenelementgruppe anlegen
     * 6. Maskenelementgruppe der neuen Maske zuordnen
     * 7. Grundgerüst (ebenfalls eine Maskenelementgruppe) wird der Maske zugeordnet
     * 8. Zuordnung eines Formulars für den Antrag (über separates Grundgerüst realisieren)
     * 9. Condition für datastore-Datensätze hinterlegen, die mit diesem Formular erfasst wurden. 
     * 
     * @param   object      $in_pagedata        Referenz auf pageData-Object
     * @return  integer                     	2010 = erfolgreich ; -2010 = fehlgeschlagen; Details werden in die Debug-Tabelle geschrieben
     */
    public function addNewRequestform(&$in_pagedata) {
        $feedback = 0;
        $result = 0;
		
               
//	addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Starte Funktion', __FUNCTION__);	
	
        
        //Daten aus Post auslesen
        $newMaskdata = $in_pagedata->getNewDataFromPostarray();
        $newMaskdata = $newMaskdata[0]["content"];
        
        $this->app_id = $newMaskdata["form.app_id"];
        //Schema der Anwendung ermitteln
        $this->req_schema = getDataFromTableByID(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "app_schema", "db_schema", "app_id = '".$this->app_id."'");
        $template_app_id = $newMaskdata["form.css_template_app_id"];
        $template_id = $newMaskdata["form.css_template_id"];
        $formstyle_app_id = $newMaskdata["form.style_element_app_id"];
        $formstyle_id = $newMaskdata["form.style_element_id"];
        $name = $newMaskdata["form.name"];  
        $width = $newMaskdata["form.width"];
        $link = "page.php";
        $parent_site = $newMaskdata["form.parent_site"];
        $sort = $newMaskdata["form.sort"];
        $filename = $newMaskdata["form.filename"];
        $image = $newMaskdata["form.image"];
        $navgroup = ""; //$navgroup = $newMaskdata["form.nav_menu_group"];
        $navgroupsort = ""; //$navgroupsort = $newMaskdata["form.nav_group_sort"];
        $showHeadline = $newMaskdata["form.headline_activate"];
        $description = $newMaskdata["form.description"];
        $timeToDelete = $newMaskdata["form.time_to_delete"];
        
        
        
        //1. Maske in Tabelle mask anlegen und id aufnehmen; 
        //   Dabei wird auch eine htmltaggroup für weitere Maskenelemente angelegt sowie
        //   Die Maskenelementgruppe "Grundgerüst" zugeordnet.
        try {
            $my_site = new mask($in_pagedata);
            $my_site->addNewMask($this->app_id, $template_app_id, $template_id, $name, $link, $this->app_id, $parent_site, $sort, $navgroup, $navgroupsort);
            $this->mask_id = $my_site->getMaskID(); 
            $this->htmltaggroupForForms_id = $my_site->getHtmltaggroupIDForForms();
        } catch (Exception $exc) {
            $result = $exc->getMessage();
        }

        
        
        
        
        if($result >= 0) {
            //2. Zugriffsrecht für die aktuelle Rolle setzen
            $role_app_id = $in_pagedata->getActiveRoleAppIdFromSession();
            $role_id = $in_pagedata->getActiveRoleIdFromSession();
            if($my_site->addAccessToMask($in_pagedata, $role_app_id, $role_id, true, true, true, true) == false) {
                $feedback = -2011;
            }
            
            //3. Zugriffsrecht (kein Zugriff) für Gast setzen
            $role_id = getConfig("guest_user_role", $this->app_id);
            if($my_site->addAccessToMask($in_pagedata, $this->app_id, $role_id, 0, 0, 0, 0) == false) {
                $feedback = -2012;
            }

            //4. ein Formular, inklusive Referenz zum Artikel, anlegen
            $this->createNewForm($in_pagedata, $this->app_id, $name, $formstyle_app_id, $formstyle_id, $width, $filename, $image, $showHeadline, $description, $timeToDelete);
            
            //5. Maskenelement, welches das Formular enthält, der Maske hinzufügen.
            if($my_site->addHtmlTagToHtmlTaggroup($this->htmltaggroupForForms_id, $this->app_id, $this->app_id, $this->htmltag_id, 1, 1, 1) == false) {
                $feedback = -2016;
            }
            
            
        }
        
        

        
        
        //99. wieder aufräumen
        if($result < 0) {
            //alle Daten der Masken-ID wieder löschen
                //ToDo: Tabellen: mask, form, article, htmltaggroup löschen, falls erfolgreich angelegt
            $feedback = $result;
        } else {
            $feedback = 2010;
            $feedbacktextarray = getFeedbacktextForFunction($feedback, $this->app_id);
            $feedbacktext = $feedbacktextarray[0]["konstante.klartext"];
            //neue Seite aufrufen
            $in_pagedata->reloadMask($in_pagedata->getMaskProbertyAppid(), __FUNCTION__, $in_pagedata->getMaskProbertyID(), $feedbacktext);

        }
        
        //HIER WEITER -> Testen
        return $feedback;
        
    }
    
    
    
    
    
     /** Fügt der Maske/Seite Formular hinzu und hinterlegt die Condition auf das eigene Formular, sodass nur
      * Daten der Tabelle datastore geladen werden können, die mit dem Formular erfast wurden.
     * 
     * @param   object  $in_pagedata        Referenz zum pagedate_object
     * @param   string  $in_app_id          APP-ID der Maske; diese wird auch für das Formular verwendet
     * @param   string  $in_name            Name der Maske. Dieses wird ergänzt, um eine Konstante und auch als Name für das Formular verwendet
     * @param   string  $in_style_app_id    app_id des Style-Elements
     * @param   integer $in_style_id        ID des Style-Elements
     * @param   string  $in_width           Breite des Formulars in %, ohne Prozentzeichen. Bsp.: "90" -> 90%. Wenn Leerstring, dann greift die CSS-Steuerung über die CSS-Klasse des Formulars
     * @param   string  $in_filename        Name der Datei, welche für die Druckaufbereiung aller Dateneingaben zuständig ist.
     * @param   string  $in_image           Pfad zu einer Bilddatei, die den Antrag symbolisiert.
     * @param   integer $in_timeToDelete    Zeit in Sekunden, nach der die Daten, welches über dieses Formular erfasst werden, wieder gelöscht werden.
     */
    private function createNewForm(&$in_pagedata, $in_app_id, $in_name, $in_style_app_id, $in_style_id, $in_width, $in_filename, $in_image, $in_showHeadline, $in_description, $in_timeToDelete) {
        $result = 0;
        
        //Referenz zu Artikeldatensatz im Formular hinterlegen
        $condition = "";
        $parent_dom_node_array = global_variables::getDefaultDomNodeForForms($this->app_id);
        $parent_dom_node = $parent_dom_node_array["id"];
        
        //Formulardatensatz anlegen
        try {
            $my_form = new form($in_pagedata);
            $my_form->addNewForm($in_app_id, $in_name, $in_showHeadline, "SingleData", $in_description, $this->req_schema, "datastore", "", "", "", $condition, 0, "", "", 0, "", 2, "", "lastInsert", $in_width, $parent_dom_node, $in_filename, $in_image, $in_timeToDelete, 1);
            $this->form_id = $my_form->getFormID();
            $this->htmltag_id = $my_form->getHtmltagID();
            
              
            //Form_id als condition in der neuen Form hinterlegen, damit mit diesem Antragsformular nur Datensätze angezeigt werden können,
            //die mit selbigen auch erfasst wurden.
            $form_condition = "form_app_id = ''".$this->app_id."'' AND form_id = ".$this->form_id;
            $my_form->updateFormData("default_condition", $form_condition);
            
            
        } catch (Exception $exc) {
            $result = $exc->getMessage();
        }
        
        
       
        
        //weitere Elemente  im Formular anlegen
        if($result >= 0) {
            //notwendige Felder anlegen
                //form_app_id
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewHiddenField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, "form_app_id", 1010, "form_app_id", 5, $this->app_id, 0);
                unset($my_field);
                //form_id
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewHiddenField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, "form_id", 1020, "form_id", 10, $this->form_id, 0);
                unset($my_field);
                //id
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewTextField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, "Request-ID", "id", 945, "200px", "300px", 0, 0, 0, 1, "", 2, "eindeutige ID des Antrages");
                unset($my_field);
                //current_user
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewHiddenField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, "Antragsteller", 1040, "applicant", 255, '$$function.SYS01.currentUser$$', 0);
                unset($my_field);
                //datastoretime
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewHiddenField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, "Antragszeit", 1050, "datastoretime", 20, '$$function.SYS01.now$$', 0);
                unset($my_field);
                
            //optionale Felder
                
                //Tipps
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewLabelField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, "Tipps", 900, "90%", $this->getDefaultTipText());
                unset($my_field);
                //Trennlinie - Absenden
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewLineField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, 910, 0, "Absenden", "Trennlinie - Absenden");
                unset($my_field);
                //Mail-TO
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewMailField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, 639, "Mail-Subject", "field36", 915, "200px", "300px", 0, 0, 0, 1, '$$form.name$$ (id = $$datastore.id$$)', "");
                unset($my_field);
                //Mail-TO
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewMailField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, 636, "Antrag weiterleiten an", "field37", 920, "200px", "300px", 0, 1, 1, 1, "test@test.de", "");
                unset($my_field);
                //Mail-CC
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewMailField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, 637, "Kopie senden an", "field38", 930, "200px", "300px", 0, 0, 0, 0, "", "");
                unset($my_field);
                //Mail-From
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewMailField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, 638, "Absender", "field39", 940, "200px", "300px", 0, 1, 0, 1, '$$function.SYS01.currentUserMail.REQ11$$', "");
                unset($my_field);
                //Trennlinie - Hinweise nach Absenden
                $my_field = new HTMLField();
                $my_field_feedback = $my_field->addNewLineField($in_pagedata, $this->app_id, $this->app_id, $this->form_id, 950, 2, $this->getDefaultAfterSubmitText(), "Trennlinie - Hinweise nach Absenden");
                unset($my_field);
            
            //Symbolleisten anlegen-------------------------
                //Hinweis-Symbolleiste (htmltaggroup-ID = 160)
                $my_form->addSymbolgroup(global_variables::getAppIdFromSYS01(), 160, 1, 1);
                //Workflow-Symbolleiste (htmltaggroup-ID = 199)
                $my_form->addSymbolgroup($this->app_id, 199, 1, 2);
                
                
            //Style dem Formular zuordnen
                $my_form->addStyleElement($in_style_app_id, $in_style_id);

        }
        
        

        
    }
    
    
    
    /** Löscht ein Antragsformular (mask, form und htmltaggroup)
     * 
     * @param   object  $in_pagedata    Referenz zum pagedata-object
     * @return  int
     */
    public function deleteRequest(&$in_pagedata) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , "starte: ".__FUNCTION__);
        $result = 0;
        
        
        
        //zu löschendes Antragsformular aus dem Post-Objekt ermitteln
        $deleteDatensaetze = $in_pagedata->getMarkedDataFromPostarray();
        
        
        if($deleteDatensaetze == false) {
            //es wurde kein Datensatz zum löschen markiert.
            $feedback = -35;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> zu löschende Datensätze: ', "Es wurde kein Datensatz zum Löschen markiert.","ERROR");
        } else { 
            $myDatensatz = $deleteDatensaetze[0];               //theoretisch kann es nur einen Datensatz geben.
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> zu löschender Datensatz: ', $myDatensatz);
            
            //Formularobjekt instanzieren
            $this->app_id = $myDatensatz["content"]["form.app_id"];
            $this->form_id = $myDatensatz["content"]["form.id"];
            $myForm = new form($in_pagedata, $this->app_id, $this->form_id);
            
            //Maskendaten des Formulars ermitteln (NUR der erste Maskendatensatz wird gelöscht)
            $maskList = $myForm->getMaskList();
            if(count($maskList) > 0) {
                $this->mask_app_id = $maskList[0]["mask.app_id"];
                $this->mask_id = $maskList[0]["mask.id"];
            }
            $mask_app_id = $this->mask_app_id;
            $mask_id = $this->mask_id;     
            
            //Maskenobjekt instanzieren
            $my_mask = new mask($in_pagedata, $mask_app_id, $mask_id);
            $htmltaggroups_list = $my_mask->getMaskelementsFromMask();
            
            //Schleife über alle htmltaggroups (Maskenelementgruppen) dieser Maske, welche Formulare enthalten.
            foreach ($htmltaggroups_list as $key1 => $cur_htmltaggroup) {
                //Formlist von htmltaggroups ermitteln
                $formlist= getFormsFromHtmltaggroup($mask_app_id, $cur_htmltaggroup);
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Formlist: ', $formlist);
            
                //Schleife über alle Formulare
                foreach ($formlist as $key2 => $cur_form) {
                    //Formular löschen
                    $my_form = new form($in_pagedata, $cur_form["html_tag.form_app_id"], $cur_form["html_tag.form_id"]);
                    $feedback = $my_form->deleteForm();
                    if($feedback < 0) {$result = -1;}
                } 

            }       

            //Seite/ Maske löschen
            if($result >= 0) {
                //Wenn Seiteninhalte erfolgreich gelöscht wurden oder es keine Seiteninhalte gab, wird auch die Seite/Maske gelöscht
                $mask_name = getDataFromTableByID(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "mask", "name", "app_id = '".$mask_app_id."' AND id = ".$mask_id);
                $feedback = $my_mask->deleteMask($mask_name);
                
            }

        }
        
        
        
        //Bis zu diesem Punkt kommt die Funktion nur, wenn ein Fehler auftrat. Andernfalls wird die Skriptausführung in reloadMask abgebrochen.
        return 2021;
    }
    
    
    
    /** Funktion gibt den Standardtext für das erste Hilfe-Feld zurück.
     * 
     * @return string
     */
    protected function getDefaultTipText() {
        $feedback = '<h1>Tipps</h1>'.
                    '<p>Sie haben erfolgreich das Grundgerüst eines Antragformulars angelegt. '.
                    'Nun gilt es weitere Felder zur Datenerfassung zu ergänzen sowie Hilfetexte für die Nutzer '.
                    'zu entwerfen. Nutzen Sie dazu die Maske "Antragsformulare verwalten".'.
                    '</p><p>Auf dieser Maske suchen Sie dieses Antragsformular anhand des Formularnamens.'.
                    '</p><p>Suchen Sie anschließend den Bereich "Felder des Antragformulars". '.
                    'In diesem Bereich sind bereits einige Felder vorhanden. '.
                    'Alle Felder der Feldart "hidden" müssen erhalten bleiben. '.
                    'Zudem gibt es ein Feld mit dem Namen "Tipps". Den Inhalt des Feldes lesen Sie gerade. '.
                    'Dieses Feld kann/sollte gelöscht werden.</p><p>Legen Sie neue Felder, '.
                    'wie in der Hilfe des Formulars "Felder des Antragsformulars" beschrieben, an.<br></p>';
        return $feedback;
    }
    
    
    /** Funktion gibt den Standardtext für das Hinweisfeld, welches nach dem Absenden des Formulars eingeblendet wird.
     * 
     * @return string
     */
    protected function getDefaultAfterSubmitText() {
        $feedback = '<p class=\"note_after\">'.
                    '<b>Hinweis:</b><br />'.
                    '<br />'.
                    'Der Antrag wurde versendet. Drucken oder Speichern Sie sich den Antrag bei Bedarf für Ihre Unterlagen.<br />'.
                    '</p>';
        return $feedback;
    }
    
    
}

?>
