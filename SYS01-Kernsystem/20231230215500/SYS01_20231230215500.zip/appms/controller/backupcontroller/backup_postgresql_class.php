<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


/** Für jede DB-spezifische-Backup-KLasse muss ein eigener Namespace definiert werden (virtueller Ordner).
 * Der Namespace muss der Dateinamekonvention folgen und er muss mit dem gewählten Namespace in der zugehörigen
 * db-connector-Klasse übereinstimmen.
 * 
 * Bsp. Wenn DBMS =  Postgres:
 * 
 * Dann:
 * DBMS-Parameter in config.xml = postgresql
 * Dateiname für die DB-spezifischen Klassen = backup_postgresql_class.php
 * namespace in dieser Datei = postgresql
 * Eintrag in Konstantenkatalog (konstantentyp_id = 50) = postgresql
 */
namespace postgresql;


/** Jede DB-spezifische-Klasse sollte von der namensgleichen Klasse in 
 * backup_universal_class.php erben, sodass der Anpassungsaufwand dauerhaft minimal bleibt.
 * 
 */
//require_once("backup_universal_class.php");
require_once("backup_universal_class.php");

/**
 * Alle Datenbankspezifischen Eigenschaften und Funktionen. Die Klasse erbt von 
 * backupTabele_universal.
 */
class backupTable extends \backupTable_universal {
    
    
    
    /** Ermittelt alle Daten, die zur Erstellung der CREATE INDEX-Anweisungen notwendig sind.
     * Zusätzlich ist der CREATE-INDEX-Befehl bereits vorhanden, da postgres diesen als über eine DB-Funktion (pg_get_indexdef) ausgeben kann.
     * //Attention NO-SQL-Standard: hier wird pg_catalog statt information_schema genutzt
     * 
     * @return  array   
     */
    function getIndexdata() {
        
        
        $table = $this->name;
        $schema = $this->_schema;
        $connection_id = $this->_connection_id;
        $feedback = array();
        
        $querySelectPart = "n.nspname  as schema
                            ,t.relname  as table
                            ,c.relname  as index
                            ,replace(pg_get_indexdef(indexrelid), 'USING btree ', '') as def";
                            //''USING btree ' wird ersetzt, da es nur in postgres verwendet wird. In Postgres ist es aber gleichzeitig der Defaultwert.
                            //replace-Syntax kann hier erhalten bleiben, auch wenn es nicht db-unabhängig ist, da hier im postgres-Konnektor keine db-Unabhängigkeit notwendig ist.
        
        $queryFromPart =    "pg_catalog.pg_class c
                            JOIN pg_catalog.pg_namespace n ON n.oid        = c.relnamespace
                            JOIN pg_catalog.pg_index i ON i.indexrelid = c.oid
                            JOIN pg_catalog.pg_class t ON i.indrelid   = t.oid";
                     
        $queryWherePart =   "c.relkind = 'i'
                            AND n.nspname not in ('pg_catalog', 'pg_toast')
                            AND i.indisprimary is false
                            --AND c.relname = 'bew_FKIndex1'
                            AND n.nspname = '$schema'
                            AND t.relname = '$table'";
        
        $group          =   "n.nspname
                            ,t.relname
                            ,c.relname
                            ,def";
                    
        $sort           =   "n.nspname
                            ,t.relname
                            ,c.relname;";

        
        $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $group, $sort);
        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
        
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für IndexData-Select', $result);
        $feedback = $result;
        
        return $feedback;
    }
    
    
    
    
    
    
    
    
    /**     Ermittelt alle Columns der Tabelle und wichtige Eigenschaften dieser. Die Column-Eigenschaften werden in Objekten vom Typ backupColumn gespeichert. 
     * 
     * @return  array                                   Zweidimensionales Array mit allen Spalten der aktuellen Tabelle. Pro Column werden folgende Merkmale zurück gegeben: 
     *                                                  columns.table_name 
                                                        , columns.column_name 
                                                        , columns.table_schema 
                                                        , columns.is_nullable 
                                                        , columns.data_type 
                                                        , columns.character_maximum_length
                                                        , columns.ordinal_position
     */
    function getColumnlist() {
        $db_schema_information = \global_variables::getNameOfDbSchemaInformation(); 
        $table = $this->name;
        $schema = $this->_schema;
        $connection_id = $this->_connection_id;
        
        
        $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("columns", "table_name");
            $queryRequest->addSelectColumn("columns", "column_name");
            $queryRequest->addSelectColumn("columns", "table_schema");
            $queryRequest->addSelectColumn("columns", "is_nullable");
            $queryRequest->addSelectColumn("columns", "", "data_type", "", "replace","string=udt_name&find_string='int4'&replace_with='int'");  
            $queryRequest->addSelectColumn("columns", "character_maximum_length");
            $queryRequest->addSelectColumn("columns", "ordinal_position");
            $queryRequest->addSelectColumn("columns", "column_default");

            $queryRequest->addTable($db_schema_information, "columns", 1, "BASE", "");

            $queryRequest->addWhereCondition("AND",    "", "columns", "table_schema",  "=", "'".$schema."'", "");
            $queryRequest->addWhereCondition("AND", "", "columns", "table_name",   "=", "'".$table."'", "");
            
            $queryRequest->addOrderbyPart("columns.ordinal_position");
        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für getColumnlist-Select', $result);
        
        //Objekte erzeugen und in _columnlist ablegen
        foreach ($result as $key => $column) {
            $column["columns.data_type"] = $column[".data_type"];         //Spalte "umbenennen", da sie in  backupColumn_universal so erwartet wird.
            $myColumn = new \backupColumn_universal($column);
            $this->_columnObjects[] = $myColumn;
        }
    }
    
    
    
    
    
    /**
     * Erzeugt für die gesamte Tabelle das CreateTable-Kommando
     * 
     * @return string           Create-Befehl für eine Tabelle ohne Constraints.
     */
    function createTableCommand() {
        //CREATE-Beginn
        $createCommand = "CREATE TABLE ".$this->_schema.".".$this->name." ( \n";
        $i = 0;
        //Spalten ergänzen
        foreach ($this->_columnObjects as $key => $myColumnobject) {
            $i = $i +1;
            if($i > 1) {$vorlauf = ", ";} else {$vorlauf = "";}
            
            if(strtolower($myColumnobject->datatype) == "longtext") {$myColumnobject->datatype = "text";}    //Migration MySql zu postgres
            
            
            if(strpos($myColumnobject->column_default ?? '', "nextval") !== FALSE) {
                $datatype = "SERIAL";                                           //Attention NO-SQL-Standard: Die  Anweisung entspricht dem Postgresdialekt. -> Thema = AUTO_INCREMENT
                $default = "";
            } else {
                $datatype = $myColumnobject->datatype;
                if($myColumnobject->column_default <> "") {$default = " DEFAULT ".$myColumnobject->column_default." ";} else {$default = "";}
            }
            
            if($myColumnobject->is_nullable == "NO") {$notNull = "NOT NULL";} else {$notNull = "";}
            if($myColumnobject->maxlength <> "" AND $datatype <> "text") {$length = "(".$myColumnobject->maxlength.")";} else {$length = "";}
            $createCommand = $createCommand."  ".$vorlauf.$myColumnobject->column_name." ".$datatype.$length.$default." ".$notNull." \n";
        }
        


        //Primary-Keys
        if($this->_primary_columns <> array()) {
            $i = 0;
            $createCommand = $createCommand."    , PRIMARY KEY (";
            foreach ($this->_primary_columns as $key => $primaryColumn) {
                $i = $i +1;
                if($i > 1) {$vorlauf = ", ";} else {$vorlauf = "";}
                $createCommand = $createCommand.$vorlauf.$primaryColumn;
            }
            $createCommand = $createCommand.") ";
        }
        

        
        //Abschluss
        $createCommand = $createCommand." \n )";
        
        //Hinweis: Foreign Keys dürfen nicht direct ins Create-Command integriert werden, sondern müssen in ein separates GRANT-Command,
        //da sonst beim Datenimport u.U. Datensätze nicht importiert werden können. Ursache ist, dass die INSERT-Befehle u.U. in der falschen Reihenfolge erfolgen könnten. 
        //Foreign-Keys würden dann einen Import verhindern.
        
        
        //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Create-Command für ".$this->_name, $createCommand);
        return $createCommand;
    }
    
    
    
    
    
}





/** Diese Klasse stellt alle Methoden für das Lesen oder Schreiben eines Backups
     * für das DBMS postgresql zur Verfügung. Die Klasse erbt von backup_universal_helper und überschreibt alle
     * Methoden, in denen Postgres-spezifische Anweisungen notwendig sind.
     * 
     */
class backup_helper extends \backup_helper_universal {
    
    
    
    
    /** In der Regel ist es sinnvoll einem langen Importskript bestimmte 
     * Konfigurationsparameter voranzustellen. Bspw. maximale-Skriptlaufzeit oder 
     * Prüfung-der-Foreign-Keys-deaktivieren usw. .
     *
     * Beachte aber, dass die Parameter, in Abhängigkeit von Source- und Target-DBMS unter Umständen
     * nicht gesetzt werden können. Die Entscheidung darüber trifft die Funktion
     * backupmanager_class->setDbmsParams
     * 
     * @return array            Liste mit SQL-Anweisungen 
     */
    function getInitialConfigparamsForDBMS() {
        $feedback = array();
        
        $feedback[] = "SET session_replication_role = replica;";             //Anweisung kann nicht gesetzt werden, da in postgress dazu nur der superuser, nicht jedoch der DB-owner, berechtigt ist.

        return $feedback;
    }
    
    
    /** Erstellt für die übergebenen Schema und Owner-Angaben die GRANT-Anweisungen und gibt diese als Strings in einem Array zurcük.
     * 
     * @param   array   $in_schemaOwnerlist Eindimensionales Array, wie es getSchemaOwner() erzeugt.
     * @param   string  $in_grantsToUser    Eigenschaft des backup_modes (grantsToUser) [olduser|newuser]; Wenn newUser oder wenn kein alter User ermittelt werden konnte, dann wird im SQL-Skript der Platzhalter "[db_user]" hinterlegt
     * @return  array                       Liste der GRANT-commands (key = schema., value = command)
     */
    function createSchemaOwnerCommand($in_schemaOwnerlist, $in_grantsToUser) {
        $SchemaOrders = array();
        
        
        foreach ($in_schemaOwnerlist as $currentSchema => $currentOwner) {
            if($in_grantsToUser == "oldUser" AND $currentOwner != "") {
                $user = $currentOwner;
            } else {
                $user = "[db_user]";
            }
            $order = "ALTER DEFAULT PRIVILEGES IN SCHEMA ".$currentSchema." GRANT ALL PRIVILEGES ON TABLES TO ".$user."; \n";
            $order = $order."ALTER DEFAULT PRIVILEGES IN SCHEMA ".$currentSchema." GRANT USAGE ON SEQUENCES TO ".$user;

            $SchemaOrders[$currentSchema]= $order;
        }
        return $SchemaOrders;
    }
    
    
    
    
    /** Wenn in getInitialConfigparamsForDBMS Einstellungen vorgenommen wurden,
     * ist es in der Regel sinnvoll, diese nach dem Datenimport wieder zurückzusetzen.
     * 
     * @return array        Liste der SQL-Commands
     */
    function resetInitialConfigparamsForDBMS() {
        $feedback = array();
        
        $feedback[] = "SET session_replication_role = DEFAULT;";
        
        return $feedback;
    }
    
    
    
    /**
     * Gibt eine Liste von Hinweisen aus, die in an den Beginn einer Backup-Datei, im Bereich "Hinweise",
     * eingefügt werden.
     * 
     * @return string Text, welcher als Hinweis angedruckt werden kann.
     */
    function getNotesForDBMS() {
        $feedback = "-- ACHTUNG: Dieses Script muss möglicherweise mit superuser-Rechten ausgeführt werden, wenn das Quellsystem (Source_DBMS) nicht selbst schon postgres ist! \n";
        $feedback = $feedback."-- Ursache: Von anderen Source-DBMS-Konnektoren in appms kann derzeit nicht garantiert werden, dass die Tabellen in der richtigen Reihenfolge angesprochen werden, \n";
        $feedback = $feedback."--         somit könnten Constraints beim ausführen dieses Scriptes Fehlermeldungen verursachen. Um dies zu vermeiden, muss der SET-Parameter session_replication_role genutzt werden. \n";
        $feedback = $feedback."--         Dazu ist nur der superuser berechtigt. \n";
        $feedback = $feedback."--         Wenn das Quellsystem ebenfalls postgres ist, wird der Parameter nicht mit angegeben und das Script kann mit Owner-Berechtigungen für die Ziel-DB ausgeführt werden. \n";
        $feedback = $feedback."--         \n";
        $feedback = $feedback."--         Wenn das Script als superuser ausgeführt wurde, muss zudem der Owner des Schemas separat auf den gewünschten DB-User gesetzt werden. \n";
        
        
        //Die folgende Anweisung wird als Dummy in Backups benötigt. 
        //Ursache: in einem Backup kann es vorkommen, dass gar keine Daten enthalten sind. Beim Einspielen des Backups über
        //PHP kann es dann zu einer missverständlichen Warnung kommen. daher wird der folgende Befehl vorangestellt.
        $feedback = $feedback."select * from information_schema.tables where 1=2; \n";
        
        
        return $feedback;
    }
    
    
    
    /** Ermittelt eine Liste aller UpdateSequence-Commands
     * 
     * @param   string  $in_connection_id       ID der Connection, welche genutzt werden soll.
     * @param   array   $in_schemaList          Liste aller DB-Schemas dessen Tabellen ermittelt werden sollen.
     * @return  array                           Wenn keine Update-Commands ermittelt werden konnten, wird ein leeres array zurückgegeben
     */
    function getUpdateSequenceCommands($in_connection_id, $in_schemaList) {
        
        $result = false;
        
        if($in_schemaList <> array()) {
            //Schema-Array in String umwandeln
            $schema_list = arrayToString($in_schemaList);
            $queryRequest = new \sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);    //Slash am Anfang ist wichtig, um aus dem aktuellen namespace heraus zu kommen

                $querySelectPart = "'SELECT SETVAL(' || quote_literal(quote_ident(PGT.schemaname) || '.' || quote_ident(S.relname)) || ', COALESCE(MAX(' ||quote_ident(C.attname)|| '), 1) ) FROM ' || quote_ident(PGT.schemaname)|| '.'||quote_ident(T.relname) AS command";
 
                $queryFromPart =   "pg_catalog.pg_class AS S,
                                    pg_catalog.pg_depend AS D,
                                    pg_catalog.pg_class AS T,
                                    pg_catalog.pg_attribute AS C,
                                    pg_catalog.pg_tables AS PGT";

                $queryWherePart =  "S.relkind = 'S'
                                    AND S.oid = D.objid
                                    AND D.refobjid = T.oid
                                    AND D.refobjid = C.attrelid
                                    AND D.refobjsubid = C.attnum
                                    AND T.relname = PGT.tablename
                                    AND PGT.tablename not like 'vquery_%'
                                    AND PGT.schemaname in (".$schema_list.")";
                
                $queryOrderByPart = "S.relname";
            
            
                $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, "", $queryOrderByPart);


            $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true, true, true);
        } else {
            $feedback = array();
        }
        
        
        
        if($result == false) {
            $feedback = array();
        } else {
            foreach ($result as $row) {
                //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> row in result', $row);
                $feedback[] = $row[".command"];
            }
        }
                
        return $feedback;
        
        
    }
    
    
    
     /** Ermittelt eine Liste aller Tabellen eines Schemas
     * //Attention NO-SQL-Standard: hier wird pg_catalog statt information_schema genutzt
     * 
     * @param   string  $in_connection_id       ID der Connection, welche genutzt werden soll.
     * @param   array   $in_schemaList          Liste aller DB-Schemas dessen Tabellen ermittelt werden sollen.
     * @return  array                           Wenn keine Tabellen ermittelt werden konnten, wird ein leeres array zurückgegeben
     */
    function getTablelistFromSchema($in_connection_id, $in_schemaList) {
        
        if($in_schemaList <> array()) {
            //Schema-Array in String umwandeln
            $schema_list = arrayToString($in_schemaList);
            $queryRequest = new \sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);    //Slash am Anfang ist wichtig, um aus dem aktuellen namespace heraus zu kommen

                $queryRequest->addSelectColumn("pg_namespace", "nspname");
                $queryRequest->addSelectColumn("pg_class", "relname");
                $queryRequest->addSelectColumn("pg_class", "relkind");

                $queryRequest->addTable("pg_catalog", "pg_class", 1, "BASE", "");
                $queryRequest->addTable("pg_catalog", "pg_namespace", 2, "INNER", "");

                $queryRequest->addWhereCondition("AND", "", "pg_class", "relkind",  "=", "'r'", "");
                $queryRequest->addWhereCondition("AND", "", "pg_class", "relname",  "not like", "'vquery_%'", "");
                $queryRequest->addWhereCondition("AND", "", "pg_namespace", "oid",   "=", "pg_class.relnamespace", "");
                $queryRequest->addWhereCondition("AND", "", "pg_namespace", "nspname",          "in", "(".$schema_list.")", "");
                
                $queryRequest->addOrderbyPart("pg_class.oid");

            $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        } else {
            $result = false;
        }
       
        
        
        if($result == false) {
            $feedback = array();
        } else {
            //Ergebnismenge so umwandeln, dass die keys den Namen des information_schema gemäß Standard-SQL-entsprechen
            foreach ($result as $row) {
                //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> row in result', $row);
                $newrow = array();
                $newrow["tables.table_schema"] = $row["pg_namespace.nspname"];
                $newrow["tables.table_name"] = $row["pg_class.relname"];
                $newrow["tables.table_type"] = $row["pg_class.relkind"];
                $feedback[] = $newrow;
            }
            
            
            //zusätzlich ignoreIfContentBackup-Definitionen ergänzen
            $tableDefinitionlist = getBackupTabledefinitions("'ignoreIfContentBackup'", $in_connection_id);
            
            foreach ($feedback as $keyResult => $currentTable) {
                foreach ($tableDefinitionlist as $keytableDefinition => $currentTableDefinition) {
                    if($currentTable["tables.table_name"] == $currentTableDefinition["backup_tabledefinitions.tablename"]){
                        $feedback[$keyResult]["backup_tabledefinitions.app_column"] = $currentTableDefinition["backup_tabledefinitions.app_column"];
                        $feedback[$keyResult]["backup_tabledefinitions.definition"] = $currentTableDefinition["backup_tabledefinitions.definition"];
                        break;      //Abbruch der inneren Schleife
                    }
                } 
                if(isset($feedback[$keyResult]["backup_tabledefinitions.app_column"]) == false) {
                    //Wenn keine Werte in $currentTableDefinition für $currentTable gefunden wurden, werden Leerstrings eingefügt
                    $feedback[$keyResult]["backup_tabledefinitions.app_column"] = "";
                    $feedback[$keyResult]["backup_tabledefinitions.definition"] = "";
                }
            }
            
        }
        
        
        
        
        
        return $feedback;
        
        
        
    }
    
    
    
    /** Erstellt für die übergebene Schemataliste die Drop-Anweisungen und gibt diese als String zurück.
     * 
     * @param   array  $in_schemalist       Eindimensionales array, wie es getSchemaList() erzeugt.
     * @return  string                      Liste der Drop-Commandos
     */
    function createSchemaDropCommand($in_schemalist) {
        $dropSchemaOrders = array();
        foreach ($in_schemalist as $key => $schema) {
            $dropOrder = "DROP SCHEMA IF EXISTS ".$schema." CASCADE";
            $dropSchemaOrders[]= $dropOrder;
            
        }
        return $dropSchemaOrders;
    }
    
    
    
    /** Erstellt für die übergebene Schemataliste die Create-Anweisungen und gibt diese als Strings in einem Array  zurück.
     * postgres beherrscht leider erst ab Version 9.3 den "IF NOT EXISTS"-Ausdruck, daher erst ab 2020 diese Syntax nutzen ->
     * (09.01.2021 -> Vererbung von backup_universal_class aktiviert).
     * 
     * @param   array  $in_schemalist       Eindimensionales array, wie es getSchemaList() erzeugt.
     * @return  array                       Liste der Create-Commands (key = Nr., value = command)
     */
//    function createSchemaCommand($in_schemalist) {
//        $SchemaOrders = array();
//        foreach ($in_schemalist as $key => $schema) {
//            $order = "CREATE SCHEMA ".$schema;
//            $SchemaOrders[]= $order;
//            
//        }
//        return $SchemaOrders;
//    }

    
}