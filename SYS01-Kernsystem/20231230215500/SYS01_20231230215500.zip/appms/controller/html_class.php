<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


require_once("../controller/nav_class.php");

/** 
 * Methoden zur Verwaltung des DOM-Baumes einer HTML-Seite.
 * Jeder Tag ist ein Knoten vom Typ HtmlTag
 * 
 */
class HtmlDomTree {
    protected $_htmlTag;            //htmlTag vom Typ "html" als Object, welches den gesamten DOM enthält
    protected $_htmlAttributList;   //Liste der Attribute zu den verwendeten tags der aktuellen Maske
    protected $_pagedata;           //Referenz zum pagedata-object
    
    
    /** Konstruktor, Erstellt bereits das HtmlTag-Objekt für das Tag html
     * 
     * @param   array   $in_html_tag            eindimensionales Array mit allen Angaben zum html_tag (siehe Tabelle html_tag)
     * @param   Integer $in_pagedata            Klasse, die alle Daten der aktuellen Site enthält (Maske, Formulare und sonstige Variablen)
     *
     */
    function __construct( $in_html_tag, &$in_pagedata ) 
    {        
        $this->_htmlAttributList = new HtmlAttributList($in_pagedata->getMaskArray()["id"], $in_pagedata->getMaskArray()["app_id"]);
        
        $html_tag = new HtmlTag($in_html_tag, $in_pagedata, true, "", $this->_htmlAttributList->getHtmlAttributList($in_html_tag["html_tag.id"]));      //html-tag
        $this->_htmlTag = $html_tag;
        $this->_pagedata = $in_pagedata;
     
        //        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> HTML-Code: ', $this->printHtmlCode());
    }
    
    /** Fügt dem DomTree ein Tag hinzu
     * ACHTUNG: Wenn die erwarteten Eigenschaften des Eingangsparameters in_tag angepasst werden, 
     * dann muss auch die Funktion showFields.getMaskTree entsprechend angepasst werden!
     * 
     * @param   array   $in_tag                     eindimensionales Array mit allen Angaben zum tag (siehe Tabelle html_tag)
     * @param   Array   $in_pagedata                Klasse mit allen Daten der aufgerufenen Seite (Maske, Formulare usw.) einer Maske.
     * @param   string  $in_default_parent_tag_id   ID eines HTML-Tags, welcher als parent-tag genutzt werden kann, <br />
     *                                              wenn der eigentliche Parenttag, anahnd der Eigenschaft $in_tag["html_tag.parent_tag"], nicht ermittelt werden kann. <br />
     *                                              Diese Variante ist für Navigationsmenüs gedacht. Dabei kann es passieren, <br />
     *                                              dass Masken zugeordnet werden, ohne das die übergeordneten Masken zugeordnet wurden.
     * @param   string  $in_htmlAttribut            Angabe von Attributen, de im HTML-Tag ergänzt werden sollen. bspw.:"class=\"test\"
     * @return  mixed                               HtmlTag oder false, falls htmlTag nicht angedruckt werden darf.
     */
    function addTag($in_tag, &$in_pagedata, $in_default_parent_tag_id = "", $in_htmlAttribut = "")
    {
//        addToDebug(__FILE__." Zeile ".__LINE__." -> ".__FUNCTION__ , "Start add tag");
        
        
        $tag_parent_object = $this->getElementById($in_tag["html_tag.parent_tag"]);
        if($tag_parent_object === false) {
            //Prüfen, ob ein default_parent_tag vorhanden ist
            if($in_default_parent_tag_id <> "") {
                $tag_parent_object = $this->getElementById($in_default_parent_tag_id);
            }
            
            //Fehler werfen, wenn parent_tag nicht ermittelt werden konnte.
            if($tag_parent_object === false) {
                throw new Exception("parenttag fehlt");
            }
        }
        $tag_htmlAttributList = $this->_htmlAttributList->getHtmlAttributList($in_tag["html_tag.id"]);                //Liste der html-Attribute für das aktuelle tag ermitteln
        $tag_htmlAttributList = $tag_htmlAttributList." ".$in_htmlAttribut;
        if(isset($in_tag["html_tag.value"])) {$tag_value = $in_tag["html_tag.value"];} else {$tag_value = "";}
//        addToDebug(__FILE__." Zeile ".__LINE__." -> ".__FUNCTION__."tagname", $in_tag);

//        echo "tagname: ".print_r($in_tag)."<br />";
        $tag = new HtmlTag($in_tag, $in_pagedata, false, $tag_parent_object, $tag_htmlAttributList);     //ein neues Tag erzeugen
        
        
        
        if($tag->hide_tag == true) {
            return false;
        } else {
    //        echo "tag ergänzt: ".print_r($in_tag)."<br />";
            $tag_parent_object->addChildTag($tag);                                                                          //das Tag im Baum einhängen
    //        echo "tag als Child eingehangen: <br />";

            //Navigationsmenü ergänzen, falls tag eines enthält
            if($in_tag["html_tag.has_mask_menu"] <> "") {
    //            echo "tagname: ".print_r($in_tag)."<br />";
                $tag->addNavMenu($this, $in_pagedata);
            }



            return $tag;
        }
    }
    
    
    
    
    /** Ergänzt eine neue Zeile für Inserts und legt diese im hiddenPart (div_2166) ab.
     * 
     * 
     * @param   string  $in_id          ID der Zeile
     * @param   string  $in_app_id      APP-ID des Formulars
     * @param   string  $in_form_id     Form-ID
     * @param   string  $in_value       Alle Elemente, die die Zeile enthalten soll, als HTML-Code
     * @param   integer $row_number     Zeilennummer im Formular
     */
    public function addTagNewHiddenRow($in_id, $in_app_id, $in_form_id, $in_value, $row_number) {
        $tag_array = array();
        $tag_array["html_tag.id"] = $in_id;
        $tag_array["html_tag.parent_tag"] = global_variables::getHiddenTagForNewLine();
        $tag_array["html_tag.app_id"] = $in_app_id;
        $tag_array["html_tag.name"] = "div";
        $tag_array["html_tag.level"] = "";
        $tag_array["html_tag.value"] = $in_value;
        $tag_array["html_tag.description"] = "";
        $tag_array["html_tag.form_id"] = "";
        $tag_array["html_tag.specialtype"] = "";
        $tag_array["html_tag.has_mask_menu"] = "";
        $tag_array["html_tag.aria_role"] = "row";
        addToDebug(__FILE__." Zeile ".__LINE__." -> ".__FUNCTION__." -> temp_array" , $tag_array);


        
        
        $furtherHtmlAttributs = 'aria-rowindex="'.$row_number.'" '.'data-row_in_form_instanz="form'.$in_form_id.'instancei0new" '.
                                "role=\"rowgroup\" class=\"div_tbody\"";
        
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Suche parent-Tag mit id: '.$tag_array["html_tag.parent_tag"], $this->printHtmlCode());
        
        $this->addTag($tag_array, $this->_pagedata, "", $furtherHtmlAttributs);
        
    }
    
    
    /** Setzt für ein bestimmtes Tag, welches anhand der oid erkannt wird, den value-Wert.
     * 
     * @param   Integer     $in_tag_oid Objekt-ID, entspricht der id der DB-Tabelle html_tag
     * @param   String      $in_value   Der Wert, der als value eingetragen werden soll.
     * @return  boolean     false, wenn das tag anhand der oid nicht gefunden werden konnte, ansonsten true.
     */
    function setValueForTag($in_tag_oid, $in_value) {
        $tag_object = $this->getElementById($in_tag_oid);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , 'tag-oid: '.$in_tag_oid.' - value: '.$in_value);
                                
        if ($tag_object == false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , 'tag-object konnte nicht ermittelt werden.');
            return false;                                                       //tag existiert nicht
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , 'tag-object gefunden.');
            $tag_object->setValueForTag($in_value);
            return true;
        }
        
    }
    
    /** Setzt für ein bestimmtes tag, welches anhand der oid erkannt wird, die Class-List-Eigenschaft
     * 
     * @param   Integer     $in_tag_oid     Objekt-ID, entspricht der id der DB-Tabelle html_tag
     * @param   String      $in_classList   Der Wert, der als Class_List eingetragen werden soll. (Eine durch Leerzeichen getrennte Aufzählung der Klassen)
     * @return  boolean
     */
    function setClassListForTag($in_tag_oid, $in_classList) {
        $tag_object = $this->getElementById($in_tag_oid);
        if ($tag_object == false) {
            return false;                                                       //tag existiert nicht
        } else {
            $tag_object->setClassList($in_classList);
            return true;
        }
    }
    
    
    
    /** Setzt die Klassen pro Tag, anhand eines eindimensionalen Feldes. 
     * Key = ID eines tags
     * Value = Durch Leerzeichen getrennte Liste aller Klassen pro tag
     * 
     * @param   array    $in_ClassListForAllTags
     */
    function setClassListForAllTags($in_ClassListForAllTags) {
        
        if(is_array($in_ClassListForAllTags)) {
            foreach ($in_ClassListForAllTags as $key => $value) {
                $this->setClassListForTag($key,$value);
            }
        }
    }
    
    
    
    
    /** Gibt den Verweis auf das Dom-Elememnt (Objekt) mit der angegebenen oid zurück.
     * 
     * @param   String  $in_id     eindeutige ID des Elements im DOM. Das entspricht html_tag.id (Primary-Key der DB-Tabelle html_tag)
     * @return  object              Wenn Objekt nicht gefunden werden kann, dann false
     */
    function getElementById($in_id)
    {
        return $this->_htmlTag->getElementById($in_id);                         
    }
    
    
    /** Gibt den gesamten HTML-Code des DOM als String zurück
     * 
     * @return string 
     */
    function printHtmlCode()
    {
        $htmlCode = "<!DOCTYPE html> \r\n";
        //$htmlCode = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\"> \r\n";   
        $htmlCode = $htmlCode.$this->_htmlTag->printHtmlCode()."\r\n";
        
        return $htmlCode;
    }
    
}



/**
 * Diese Klasse stellt Objekte bereit, die einem HTML-Tag (Bsp.: body, div o.s) entsprechen.
 * Dabei können Position im DOM, Attribute und Inhalte verwaltet werden.
 * 
 * @author Tom Jan <tomjan@gmx.de>
 */
class HtmlTag {
    protected $_oid="";                      //Objekt-ID -> Wert, der eindeutig im DOM ist. wird aus  DB-Tabelle gebildet (html_tag.id)
    protected $_tagname="";                  //Html-Tag des aktuellen Objektes (Bsp.: div)
    protected $_level=0;                     //Ebene im DOM-Baum -> html = 0, head and body = 1 -> usw.
    protected $_parentTag;                   //Verweis auf das übergeordnete HTMl-Element (Object)
    protected $_childTagList = array();      //Array mit Verweisen auf alle nachgeordneten HTML-Elemente (Object)
    //protected $_preTag;                      //Vorgängerobject auf gleichem Level
    protected $_id="";                       //ID für CSS und Object-Identifizierung. Muss pro DOM eindeutig sein. Kann dabei aber sprechend (alphanummerisch) sein. (Concat(html_tag.name, "_",html_tag.id))
    protected $_attributList = array();      //Style-Attribute, die dem aktuellen HTML-Tag zugeordnet sind. [key = css_attributname; value = css_attributvalue]
    protected $_value="";                    //Wert, der zwsichen den html-Tag-Identifiern steht. Je nach Tag ist das value oder text. Bsp.: <div>value</div>
    protected $_description = "";            //Wert wird als data-alt-Attribut im html_quelltext ausgegeben. somit soll die Lesbarkeit für Entwickler erhöht werden.
    protected $_form_id = "";                //Falls ein html-tag ein Formular enthält, wird in dieser Eigenschaft die ID des Formulars vermerkt
    protected $_form_array = array();        //Alle Eigenschaften des aktuellen Formulars, welches möglicherweise im aktuellen tag enthalten ist
    protected $_formconstructor = "";        //PHP-Function, welche zum Rendern des Formulars genutzt werden soll
    protected $_formHtmlCode = "";           //Enthält den fertigen HTML-Code eines Formulars
    protected $_classList = "";              //Durch Leerzeichen getrennte Liste aller Klassen eines html_tags
    protected $_pagedata;                    //Objekt, das alle Daten der aktuellen page enthält (Maske, Formulare und sonstige Variablen)
    protected $_htmlAttributList = "";       //String mit den zusätzlichen Attributen (Parametern), die im tag angedruckt werden sollen (Bsp.: charset="UTF-8"
    protected $_tempCondition = "";          //Ein Formular kann eine temporäre Bedingung erhalten, um die Inhalte einzuschränken. Diese Condition wird nach dem Aufbau des Formulars gelöscht. So kann bei Formularen, die mehrfach verwendet werden (bspw. eingebettete / nested Formulare), sichergesetllt werden, dass Bedingungen nur für den aktuellen Aufruf gelten
    protected $_specialtype = "";            //Kennzeichnet HTMLTags, die eine Spezialfunktion übernehmen (Bsp.: infobox -> zeigt Statusmeldungen für den benutzer an.
    protected $_has_mask_menu = 0;           //Gibt an, ob eine HtmlTag eine Navigationsmenügruppe enthält.
    public $hide_tag = false;                //Gibt an, ob ein tag ausgeblendet sein soll
    protected $_aria_role = "";              //Wert von html_tag.aria_role
    protected $_aria_label = "";             //Wert von html_tag.aria_label
    
    
    /** Constructor <br />
     * Diese Klasse stellt Objekte bereit, die einem HTML-Tag (Bsp.: body, div o.s) entsprechen.
     * Dabei können Position im DOM, Attribute und Inhalte verwaltet werden.
     * 
     * @param array     $in_html_tag                    eindimensionales Array mit allen Angaben zum html_tag (siehe Tabelle html_tag)
     * @param object    $in_pagedata                    Objekt, welches alle Daten der aktuellen page enthält (Maske, Formulare, Funktion und sonstige Variablen
     * @param boolean   $in_is_root                     Gibt an, ob es sich bei dem einzufügenden Tag um das root-Tag des HTML-Doms handelt (html = root)
     * @param object    $in_parent_object               Objekt vom Typ HtmlTag, welches das übergeordente  Element im Dom-Tree (eine Ebene höher) symbolisiert
     * @param string    $in_htmlAttributList            [optional] String mit den Attributen (siehe HtmlAttributList->getHtmlAttributList); Beispiel: "name=\"test\"; default = ""
     * @param string    $in_tempCondition               [optional] String, welcher eine SQL-Bedingung zur Einschränkung der Datensätze einer eventuell vorhandenen form enthält.  (default = "")
     * @param string    $in_is_nestedForm               [optional] Gibt an, ob es sich um ein eingebettetes Formular handelt (default = false)
     * @param string    $in_defaultValuesForInsert      [optional] Wenn für ein Formular DefaultValues für die Neuanlage bereits feststehen, können diese hier als Array übergeben werden. key = dom.field; value = Inhalt               
     */
    function __construct($in_html_tag, &$in_pagedata, $in_is_root, $in_parent_object, $in_htmlAttributList="", $in_tempCondition = "", $in_is_nestedForm = false, $in_defaultValuesForInsert = array())
    {
        
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> in_html_tag ', $in_html_tag);
        
        $this->_oid = $in_html_tag["html_tag.id"];   
        //ToDo: die oid müsste eigentlich auch die app_id berücksichtigen: $in_html_tag["html_tag.app_id"]."_".$in_html_tag["html_tag.id"]
        //Dann müssten aber auch in parentTag und preTag die app_id bekannt sein.
        $this->_tagname = $in_html_tag["html_tag.name"];
        $this->_level=$in_html_tag["html_tag.level"];
        $this->_id=$in_html_tag["html_tag.name"]."_".$this->_oid;
        if(isset($in_html_tag["html_tag.value"])) {$this->_value = $in_html_tag["html_tag.value"];} else {$this->_value = "";}
        $this->_description = $in_html_tag["html_tag.description"];
        $this->_form_id = $in_html_tag["html_tag.form_id"];
        $this->_pagedata = $in_pagedata;
        $this->_htmlAttributList = $in_htmlAttributList;
        $this->_parentTag=$in_parent_object;
        $this->_specialtype = $in_html_tag["html_tag.specialtype"];
        $this->_has_mask_menu = $in_html_tag["html_tag.has_mask_menu"];
        if(isset($in_html_tag["html_tag.aria_role"])) {$this->_aria_role = $in_html_tag["html_tag.aria_role"];} else {$this->_aria_role = "";}
        if(isset($in_html_tag["html_tag.aria_label"])) {$this->_aria_label = $in_html_tag["html_tag.aria_label"];} else {$this->_aria_label = "";}
       
        //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> objekt htmlTag ', $this->_id);
        
        //Wenn im html_tag kein Formular enthalten ist
        $dummy_form_id = global_variables::getDefaultDummyFormId();
        
        
        
        if ($this->_form_id <> "" AND $this->_form_id <> $dummy_form_id) {
            //echo "Form-ID: ".$this->_form_id."<br />";
            if($in_tempCondition<>"") {
                $instance_id = "i".str_replace(array(" ", "'", "=", "_"), "", $in_tempCondition);
            } else {
                $instance_id = "i0";
            }

            
            
            $in_pagedata->updateFormInstanceList($this->_form_id, $instance_id);
            $in_pagedata->setFormPropertyCondition($this->_form_id, $instance_id, $in_tempCondition, false, "default");
            $this->_form_array = $in_pagedata->getFormArray($this->_form_id);
            
            
            if(isset($this->_form_array["block_by_workflow_step"])) {
                //diese Situation kann auftreten, wenn ein Formular in einem Workflow verwendet wird,
                //jedoch im aktuellen Workflow-step der Zugriff untersagt ist.
                $this->hide_tag = true;
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> form_id: '.$this->_form_id, "html_tag nicht andrucken, da form in workflow_step nicht enthalten ist.");
                
            } else {    
            
            
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> form_array mit instance ', $in_pagedata->getFormArray($this->_form_id));
                if (isset($this->_form_array["form.constructor"])) {

                    if($this->_form_array["form.width"] <> "") {
                        //Wenn im Formular die Breite als Prozentzahl hinterlegt wurde
                        $this->_attributList["max-width"] = $this->_form_array["form.width"]."%";
                    }

                    $functionParams = $this->_pagedata->getFunctionArray();                                               //Wenn keine function_id übergeben wurde (default = 0) kommt es zu einem internen Fehler, der nur im Debug-Modus erscheint. Es wird anschließend der Standard-Konstruktor gestartet.
                    //$targetForms = getTargetForms($in_pagedata, $this->_form_id);
                    $dependingForms = $in_pagedata->getDependedForms($this->_form_id);
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> SetDependingForms bei : '.$this->_form_id, $dependingForms);
                    $in_pagedata->setFormPropertyTargetForms($this->_form_id, $dependingForms);
                    $this->_form_array = $in_pagedata->getFormArray($this->_form_id);                                     //form_array neuladen, da sich die Eigenschaft targetForms gerae geändert hat.
    //                if($button_target == 1) {
    //                    //Wenn sich die Funktion auch auf das auslösende Formular beziehen soll, dann wird es zu targetForms ergänzt
    //                    $targetForms[] = $functionParams["source_form_id"];
    //                    
    //                }

                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Aktuelles Formular: '.$this->_form_id, $this->_form_array);
    //                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> tempCondition: ', $in_tempCondition);
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Aktuelle Funktionsparameter: ', $functionParams);

                    //nestedForms werden in den übergeorneten Formularen nahtlos integriert, sodass auch die Symbolleisten der übergeordneten Formulare wirken. 
                    //Nur für die Neuanlage (i0new) werden sie als eigenständige Formulare integriert.
                    if($in_is_nestedForm == true) {
                        $formtagname = "div";
                        $cssClass = "nestedform";
                        $encoding = "";
                    } else {
                        $formtagname = "form";
                        $cssClass = "form";
                        $encoding = "method=\"post\" enctype=\"multipart/form-data\" ";
                    }



                    if ($this->_form_array["form.constructor"] == "TableData" OR
                        $this->_form_array["form.constructor"] == "SingleData" OR
                        $this->_form_array["form.constructor"] == "RectanglesForTable" OR
                        $this->_form_array["form.constructor"] == "RectanglesForTable2" OR
                        $this->_form_array["form.constructor"] == "simpleTable" OR
                        $this->_form_array["form.constructor"] == "getFormTableForQuery" OR
                        $this->_form_array["form.constructor"] == "RectanglesForQuery" OR
                        $this->_form_array["form.constructor"] == "dynamicSearch" OR
                        $this->_form_array["form.constructor"] == "SingleDataQuery") {                                                                       //Stellt Daten in Tabellenform dar
                        
                        if($this->_form_array["form.constructor"] == "dynamicSearch") {
                            $i_max = 3;
                        } else {
                            $i_max = 2;
                        }

                        for ($i = 1; $i <= $i_max; $i++) {       
                            //jedes Formular wird mindestens zweimal angelegt. Die zweite Instanz ist ein versteckets Formular zum Anlegen von neuen Datensätzen
                            if($i == 1) {

                                //Im ersten Durchlauf wird das Formular im vorgegebenen Modus erzeugt und im aktuellen Tag datgestellt
                                $this->_formHtmlCode = $this->_formHtmlCode."\r\n<$formtagname name=\"".$this->_form_array["form.name"]."\" id=\"form_".$this->_form_array["form.id"]."_".$instance_id."\" class=\"".$cssClass."\" ".$encoding.">\r\n";
                                    $this->_formHtmlCode = $this->_formHtmlCode.getForm($in_pagedata, $this->_form_id, $instance_id, $in_defaultValuesForInsert); 
                                $this->_formHtmlCode = $this->_formHtmlCode."</$formtagname>\r\n";  
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> addHTmlTag ', "Durchlauf 1 beendet", "INFO");
                            } elseif($i == 2) {
                                $formtagname = "form";
                                $cssClass = "form";

                                //Im zweiten Durchlauf wird ein verstecktes Formular zur Erfassung eines neuen Datensatzes angelegt. Dieses wird im Tag für versteckte Element eingehangen
                                if($in_defaultValuesForInsert == array() AND $in_pagedata->getFormPropertyIsnested($this->_form_id) == false) {
                                    //bei eigenständigen Formularen werden die tempValues nicht diesem __construct als Eingangsparameter mitgegeben, sondern können der 1. Instanz entnommen werden.
                                    $defaultValuesForInsert = $in_pagedata->getFormPropertyDefaultValueForInsert($this->_form_array["form_dependence.trigger_form_id"], $this->_form_id, $instance_id, false, $this->_form_array["form.is_nested_form"]);
                                } else {
                                    //bei eingebetteten Formularen wurden die defaultValues bereits in getHTMLCodeForNestedForms ermittelt
                                    $defaultValuesForInsert = $in_defaultValuesForInsert;
                                }
                                $instance_id = $instance_id."new";
                                $in_pagedata->createFormInstance($this->_form_id, $instance_id, false);
                                $in_pagedata->prepareFormForNewRow($this->_form_id, $instance_id, $defaultValuesForInsert);
//                                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Aktuelles Formular: '.$this->_form_id, $in_pagedata->getFormArray($this->_form_id));
                                //html-Code für das Formular generieren
                                $newFormHtmlCode= "";
                                $newFormHtmlCode = $newFormHtmlCode."\r\n<$formtagname name=\"".$this->_form_array["form.name"]."\" id=\"form_".$this->_form_array["form.id"]."_".$instance_id."\" class=\"".$cssClass."\" ".$encoding.">\r\n";
                                    $newFormHtmlCode = $newFormHtmlCode.getForm($in_pagedata, $this->_form_id, $instance_id); 
                                $newFormHtmlCode = $newFormHtmlCode."</$formtagname>\r\n"; 
                                //Html-Code des Formulars an die hiddenBox übergeben
                                $in_pagedata->hiddenbox->addForm($newFormHtmlCode, $this->_form_id, $instance_id);
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> addHTmlTag ', "Durchlauf 2 beendet", "INFO");

                            } elseif($i == 3) {
                                //Im dritten Durchlauf wird das Formular im tabledata Modus erzeugt und im aktuellen Tag datgestellt. Es handelt sich um die Ergebnisplatzhalter einer dynamischen Suche
                                $instance_id = "i".$i;
                                $this->_form_array["form.constructor"] = "TableData";
                                $this->_form_array["form.headline_activate"] = 0;
                                $this->_form_array["form.showdescription"] = 0;
                                $in_pagedata->setFormArray($this->_form_id, $this->_form_array);
                                $this->_formHtmlCode = $this->_formHtmlCode."\r\n<$formtagname name=\"".$this->_form_array["form.name"]."\" id=\"form_".$this->_form_array["form.id"]."_".$instance_id."\" class=\"".$cssClass."\" ".$encoding.">\r\n";
                                    $this->_formHtmlCode = $this->_formHtmlCode.getForm($in_pagedata, $this->_form_id, $instance_id); 
                                $this->_formHtmlCode = $this->_formHtmlCode."</$formtagname>\r\n";  
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> addHTmlTag ', "Durchlauf 1 beendet", "INFO");
                            }


                        }
                    } elseif ($this->_form_array["form.constructor"] == "SymbolGroup") {                                                               //Stellt nur die Symboleiste (ohne Formular) dar
    //                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> addHTmlTag ', "SymbolGroup", "INFO");
                            $this->_formHtmlCode = $this->_formHtmlCode.getSymbolGroupForAllModi($this->_form_array, $this->_pagedata);

                    } elseif ($this->_form_array["form.constructor"] == "getFormInternVariables") {                                                               //Stellt ein Formular ohne Datenbankanbindung dar
    //                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> addHTmlTag ', "getFormInternVariables", "INFO");
                            //if(isset($_SESSION)) {} else {$_SESSION = array('uid' => 'dummy');}
                            $this->_formHtmlCode = $this->_formHtmlCode.getForm($in_pagedata, $this->_form_id, $instance_id); 

    //                } elseif ($this->_form_array["form.constructor"] == "getFormTableForQuery" OR
    //                          $this->_form_array["form.constructor"] == "RectanglesForQuery" OR
    //                          $this->_form_array["form.constructor"] == "SingleDataQuery") {                                                               //Stellt ein Formular ohne Datenbankanbindung dar
    ////                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> addHTmlTag ', $this->_form_array["form.constructor"], "INFO");
    //                        $this->_formHtmlCode = $this->_formHtmlCode."\r\n<$formtagname name=\"".$this->_form_array["form.name"]."\" id=\"form_".$this->_form_array["form.id"]."_".$instance_id."\" class=\"".$cssClass."\" ".$encoding.">\r\n";
    //                        $this->_formHtmlCode = $this->_formHtmlCode.getForm($in_pagedata, $this->_form_id, $instance_id, $in_defaultValuesForInsert); 
    //                        $this->_formHtmlCode = $this->_formHtmlCode."</$formtagname>\r\n";  
                    }

                }
            }
        }
    }
    
    
    
    
    /**
     * Ergänzt das Navigationsmenü. Für jeden Eintrag des Navigationsmenüs wird ein Eigenständiges Html-Tag-Objekt ergänzt.
     * @param object    $in_HtmlDomObject       Referenz zum HTML-DOM-Tree
     * @param object    $in_pagedata            Referenz auf das pagedata-Object
     */
    public function addNavMenu(&$in_HtmlDomObject, &$in_pagedata) {
        //aktive (aufgerufene) Maske ermitteln
        $active_mask_id = $in_pagedata->getMaskProbertyID();

        //Navigationsmenü ergänzen
        $nav_group = $this->_has_mask_menu;
        $myNavMenu = new navMenu($active_mask_id, $this->_oid, $this->_level, $nav_group);
        $tagList = $myNavMenu->getNavTreeList();
        $defaultParentTag = $myNavMenu->getDefaultParentTag();
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Tag-Liste (NavigationsMenü), defaultparenttag = '.$defaultParentTag, $tagList);

        

        //Ausblenden-Button für vertikales Menü ergänzen
        $button_tag = $this->buildNavButton($tagList[0], "span", "closeBtnVerticalMenu");
        $in_HtmlDomObject->addTag($button_tag,$in_pagedata, $tagList[0]["html_tag.parent_tag"], "class=\"closeBtnVerticalMenu\"" );
        
        
        //Einblenden-Button für vertikales ergänzen
        $button_tag = $this->buildNavButton($tagList[0], "span", "openBtnVerticalMenu");
        $in_HtmlDomObject->addTag($button_tag,$in_pagedata, $tagList[0]["html_tag.parent_tag"], "class=\"openBtnVerticalMenu\"" );

        
        
        
        $button_tag_open = "";
        $button_tag_close = "";
        
        //Alle tags (NavigationsElemente) dem DOM hinzufügen
        for ($i = 0; $i < count($tagList); $i++) {
            if ($tagList[$i]["html_tag.name"] == "ul") {$level = "0";} else {$level = $tagList[$i]["html_tag.level"];}
            
            
            if($level == "0" AND $tagList[$i]["html_tag.name"] == "li") {
                //Wenn ein Menüeintrag auf oberster Ebene liegt (level = 0), dann soll dieser in einem neuem span-eingebettet werden.
                $new_structure_tag = $this->buildNavStructureTag($tagList[$i], "span");
                $in_HtmlDomObject->addTag($new_structure_tag,$in_pagedata, $defaultParentTag, "class=\"nav_item_level_$level\"");
                //Im Original-Tag muss der neue Structure-Tag nun als parent hinterlegt werden.
                $tagList[$i]["html_tag.parent_tag"] = $new_structure_tag["html_tag.id"];
                
                
                //Einblenden-Button für horizontales ergänzen
                $button_tag_open = $this->buildNavButton($tagList[$i], "span", "openBtnHorizontalMenu");
                
                //Ausblenden-Button für horizontales Menü ergänzen
                $button_tag_close = $this->buildNavButton($tagList[$i], "span", "closeBtnHorizontalMenu");
                
        
            } 
            
            $temp_tag = $in_HtmlDomObject->addTag($tagList[$i],$in_pagedata, $defaultParentTag, "class=\"nav_item_level_$level\"");  
            if($button_tag_open != "") {
                $temp_tag_id = $temp_tag->getOid();
                $button_tag_open["html_tag.parent_tag"] = "";                   //Eigenschaft muss auf "" gesetzt werden, damit $temp_tag_id als Parenttag verwendet wird.
                $in_HtmlDomObject->addTag($button_tag_open,$in_pagedata, $temp_tag_id, "class=\"openBtnHorizontalMenu\"" );
                $button_tag_close["html_tag.parent_tag"] = "";
                $in_HtmlDomObject->addTag($button_tag_close,$in_pagedata, $temp_tag_id, "class=\"closeBtnHorizontalMenu\"" );  
                $button_tag_open = "";
                $button_tag_close = "";
            }
        }
        
    }
    
    
    
    /** Gibt einen neuen Tag zurück, der dem übergebenen entspricht, jedoch eine neue ID hat und mit dem neuen tag_name erstellt wurde.
     * 
     * @param   array   $in_original_tag    Array eines einzelnen Navigationsmenüeintrages, wie es die Funktion getNavTreeList zurückgibt
     * @param   string  $in_tag_name        Tagname, der im HTML-DOM verwendet werden soll (bswp. "div" oder "span")
     * @return  array                       Neuer Tag, analog $in_original_tag
     */
    private function buildNavStructureTag($in_original_tag, $in_tag_name) {
        $feedback = $in_original_tag;
        $feedback["html_tag.name"] = $in_tag_name;
        $feedback["html_tag.id"] = $feedback["html_tag.id"];
        $feedback["html_tag.value"] = "";
        $feedback["html_tag.description"] = $in_tag_name."_".$feedback["html_tag.description"];
        return $feedback;
    }
    
    
    
    
    /** Gibt einen neuen Tag zurück, der dem übergebenen entspricht, jedoch eine neue ID hat und mit dem neuen tag_name erstellt wurde.
     * Zudem wird ein <a> Attribut eingeschlossen, welches den Close- oder Open-Button enthält
     * 
     * @param   array   $in_ul_tag          Array eines einzelnen Navigationsmenüeintrages, wie es die Funktion getNavTreeList zurückgibt
     * @param   string  $in_tag_name        Tagname, der im HTML-DOM verwendet werden soll (bswp. "div" oder "span")
     * @param   string  $in_type            [closeBtnVerticalMenu|openBtnVerticalMenu|closeBtnHorizonatlMenu|openBtnHorizontalMenu]                 
     * @return  array                       Neuer Tag, analog $in_ul_tag
     */
    private function buildNavButton($in_ul_tag, $in_tag_name, $in_type) {
        
        if      ($in_type == "closeBtnHorizontalMenu") {$type = "closeBtnHorizontalMenu"; $java = "closeNavMenuHorizontal()"; $symbol = "x";                      //"< "."&Xi;";
        } elseif($in_type == "openBtnHorizontalMenu")  {$type = "openBtnHorizontalMenu";  $java = "openNavMenuHorizontal()";  $symbol = "...";            
        } elseif($in_type == "closeBtnVerticalMenu")   {$type = "closeBtnVerticalMenu";   $java = "closeNavMenuVertical()";   $symbol = "CLOSE"." &times;";          
        } elseif($in_type == "openBtnVerticalMenu")    {$type = "openBtnVerticalMenu";    $java = "openNavMenuVertical()";    $symbol = "&equiv;"." OPEN";            
        }
        
        $feedback = $in_ul_tag;
        $feedback["html_tag.name"] = $in_tag_name;
        $feedback["html_tag.id"] = $feedback["html_tag.id"]."_".$type;
        $feedback["html_tag.value"] = "<a href=\"javascript:void(0)\" role=\"button\" class=\"\" onclick=\"$java\">$symbol</a>";
        $feedback["html_tag.description"] = $in_tag_name."_".$type;
        $feedback["html_tag.aria_role"] = "none";
        return $feedback;
    }
    
    
    
    
    
    
    
    
    /** Setzt oder fügt einen übergebenen String dem Value des tag hinzu
     * 
     * @param   String  $in_value   
     */
    function setValueForTag($in_value) {
        $this->_value = $this->_value.$in_value;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , 'value gesetzt: '.$in_value);
    }
    
    
    
    /** Setzt eine übergebene Klassenliste als ClassList-Eigenschaft
     * 
     * @param   String  $in_ClassList   Durch Leerzeichen getrennte Liste von Klassen
     */
    function setClassList($in_ClassList) {
        $this->_classList = $in_ClassList;
    }
    
    
    
    
    /**
     * Führt die Aufgabe, die mit dem jeweiligen Spezialtyp verbunden ist, aus.
     * 
     * infobox-> fügt dem Tag die Statusmeldungen hinzu.
     * hiddenbox-> fügt dem Tag die versteckten Elemente hinzu.
     */
    function executeSpecialType() {
        if ($this->_specialtype == "infobox") { $this->setValueForTag($this->_pagedata->infobox->printHtmlCode($this->_id));}
        if ($this->_specialtype == "hiddenbox") { $this->setValueForTag($this->_pagedata->hiddenbox->printHtmlCode());}
        
    }
    
    
    
    /**
     * Gibt das aktuelle HTML-Objekt und alle Child-Elemente in HTML-Synatx als String zurück.
     * CSS-Eigenschaften werden als Style-Attribute in den HTML-Tags ausgegeben, sodass eine separate CSS-Datei nicht notwendig ist.
     * 
     * @return String HTML-Code
     */
    function printHtmlCode()
    {
        
        $this->executeSpecialType();                                            //SpecialFunctions ausführen, da dadurch beispielsweise die Werte der Infobox in value des aktuelen tags übertragen werden könnten.
        
        
        
        
        // Falls die Klasse über Programmcode oder Template mitgegeben wurde
        if($this->_classList == "") {$class = "";} else {$class = " class=\"".$this->_classList."\"";}
        
        //html-Attributlist
        if($this->_htmlAttributList == "") {$html_attributlist = "";} else {$html_attributlist = " ".$this->_htmlAttributList;}
        
        
        //Falls eine Aria-Role angegeben wurde
        if($this->_aria_role != "") {$aria_role = " role=\"".$this->_aria_role."\"";} else {$aria_role = "";}
        
        //Falls ein Aria-Label angegeben wurde
        if($this->_aria_label != "") {$aria_label = " aria-label=\"".$this->_aria_label."\"";} else {$aria_label = "";}
        
        //Falls Style-Angaben vorhanden sind
        if($this->_attributList == array()) {$style = "";} else {$style = " ".$this->changeAttributlistToString($this->_attributList);}
        
        //Das id-Attribut ist bei einigen tags nicht zulässig
        if (in_array($this->_tagname, array("title", "meta"))) {$id = "";} else {$id = " id=\"".$this->_id."\"";}
        
        //das alt-Attribut ist bei einigen tags nicht zulässig
        if (in_array($this->_tagname, array("body", "div", "html", "head", "header", "li", "main", "nav", "footer", "title", "link", "meta", "span", "style", "script", "ul"))) {
            if($this->_description != "") {$data_alt = " data-alt=\"".$this->_description."\"";} else {$data_alt = "";}
        } else {
            if($this->_description != "") {$data_alt = " alt=\"".$this->_description."\"";} else {$data_alt = "";}
        }
        
        
        //das name-Attribut ist bei einigen tags nicht zulässig
        if (in_array($this->_tagname, array("div", "head", "html", "header", "label", "main", "nav", "footer", "title", "link", "meta", "style", "script", "body", "li", "span", "ul"))) {
            $name="";
        } else {
            $name = " name=\"".$this->_id."\"";
        }
           
        
        $level = " data-level=\"".$this->_level."\"";

        
        //öffnender Tagname mit Attributen
        $htmlCode = "<".$this->_tagname.
                $id.
                $name.                                                          //id- und name-Attribut sollten bei Formularelementen immer identisch sein, da bei Datenübergaben (ajax, get, post usw. mal das eine und mals das andere Attribut genutzt wird.
                $level.
                $class.
                $aria_role.
                $aria_label.
                $data_alt.
                $style.                                                         //Liste der Style-Attribute (css), soweit diese nicht im Style-tag enthalten sind
                $html_attributlist.                                             //Liste dr html-Attribute
                ">\r\n";
        
        
        
        if (in_array($this->_tagname, array("input", "link", "meta"))) {
            //einige tags haben weder child-tags, noch schließende tags
        } else {
            $htmlCode=$htmlCode.$this->_value.$this->_formHtmlCode."\r\n";

            //Alle Child-Elemente rekursiv durchlaufen
            foreach ($this->_childTagList as $key => $value) {
                $htmlCode=$htmlCode.$value->printHtmlCode()."\r\n";
            }

            //schließender Tagname
            $htmlCode= $htmlCode."</".$this->_tagname."> <!-- End: ".$this->_id." -->";
            //Zeilenumbruch ergänzen
        }
        
        $htmlCode= $htmlCode."\r\n";
        
        return $htmlCode;
    }
    
    
    
    
    
    function changeAttributlistToString($in_attributlist)
    {
        $stringAttributList = "";
        foreach ($in_attributlist as $key => $value) {
            $stringAttributList=$stringAttributList.$key.": ".$value."; ";
        }
        $stringAttributList=" style=\"".$stringAttributList."\" ";
        return $stringAttributList;
    }
    
    
    
    
    
    function addChildTag($in_childTag)
    {
        $this->_childTagList[]=$in_childTag;
    }
    
    
    
    
    /** Gibt die OID des HtmlTag-Objektes an.
     * @return String
     */
    function getOid()
    {
        return $this->_oid;
    }
    
     
    /** Ermittelt das Element mit der Angegebenen OID. Dabei werden das aktuelle Element und alle nachgeordneten Elemente überprüft
     * 
     * @param   String  $in_id  eindeutige ID des Elements im DOM. Das entspricht html_tag.id (Primary-Key der DB-Tabelle html_tag)
     * @return  Object          vom Typ HtmlTag oder false
     */
    function getElementById($in_id)
    {
        $feedback = false;
        $id = (string)$in_id;
//        echo ' Zeile '.__LINE__." Starte  ".$this->getOid()."<br />";
//        echo ' Zeile '.__LINE__." Childtags  ".var_dump($this->_childTagList)."<br />";
        
        //Vorsicht: Debug führt an dieser Stelle zu einer starken Performance-Belastung
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Suche Tag mit id: '.$in_oid, $this->_childTagList);
        if ($this->getOid() == $id) {                                         //Falls nach der id des obersten Elements im Dom gesucht wurde
//            echo "id $in_id gefunden <br />";
            return $this;
        } else {
        
            foreach ($this->_childTagList as $key => $value) {                      //durchsucht die Liste der zugeordneten Tag-Objekte vom Typ HtmlTag
//                echo ' Zeile '.__LINE__." Durchsuche  ".$value->getOid()."<br />";
                
                
                if ($value->getOid() == $id) {
//                    echo "id $in_id gefunden <br />";
                    return $value;
                } else {
//                    echo "id $in_id nicht gefunden, Suche in Childelementen fortsetzen <br />";
                    $feedback = $value->getElementById($id);
                }

                if ($feedback != false) {
                    return $feedback;
                }
                
            }
            // Falls das Element nicht gefunden wurde
//            echo "Nichts gefunden <br />";
            return false;
        }
    }
}


/** 
 * 
 * 
 */    
class CssAttribute {
    
    
    protected $_style_element_list; 
    
    /**
     *
     * @var     array           Liste der Template_id's von denen Attribute ermittelt wurden, inkl. aller vererbenden Templates; Bsp. array(1, 5, 8) 
     */
    protected $_template_list = array();
    
    
    
    
    /**
     *  Konstruktor.
     * Multidimensionales Array, welches alle Attribute und deren Zuordnung zu einem Style_element   enthält. Kann als String im HTML-Element <style> verwendet werden.
     * 
     * @param string    $in_mask_app_id             APP-ID der Maske.
     * @param String    $in_css_template_app_id     App-ID des Templates der Maske
     * @param integer   $in_css_template_id         ID des Templates der Maske
     *                                  
     */
    function __construct($in_mask_app_id, $in_css_template_app_id, $in_css_template_id) { 
        $this->addTemplateIDToTemplatelist($in_css_template_id);
        
        //StyleElemente und deren Attribute des Templates der Maske ermitteln
        $myStyleElementlist = getCssAttributList($in_css_template_id, $in_css_template_app_id, $in_mask_app_id);
        if($myStyleElementlist === false) {$myStyleElementlist = array();}
        //$myStyleElementlist = Multidimensional Array: 
        //Äußeres Array hat Tagnamen als Keys
        //Inneres Array hat Attributnamen als Keys und die Attributwerte als values
        
        
        //Wenn ein Parent-Template existiert, dann auch deren Style-Elemente ermitteln
        $condition = "app_id = '".$in_css_template_app_id."' AND id = ".$in_css_template_id;
        $template = getTableData(global_variables::getAppIdFromSYS01(), "css_template", global_variables::getNameOfDbSchemaSYS01(), true, "", $condition, __FUNCTION__);
        $parent_template_app_id = $template[0]["css_template.parent_template_app_id"];
        $parent_template_id = $template[0]["css_template.parent_template_id"];
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Style-List current template: ', $myStyleElementlist);
        
        if($parent_template_app_id <> "" AND $parent_template_id <> "") {
            //Wenn es ein Template gibt, von dem das current_template weitere Style-Attribute erben soll, dann werden folgende Schritte ausgeführt
            $css_parent_attribute = new CssAttribute($in_mask_app_id, $parent_template_app_id, $parent_template_id);  
            $parrentStyleElementListe = $css_parent_attribute->getStyleElementListInArrayformat();
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Style-List parent template: ', $parrentStyleElementListe);
            $aggregatedList = $this->mergeStyleElementList($parrentStyleElementListe, $myStyleElementlist);
            $this->addTemplateIDToTemplatelist($css_parent_attribute->getTemplateIDList());
        } else {
            $aggregatedList = $myStyleElementlist;
        }
            
        
        
        $this->_style_element_list = $aggregatedList;
        
    }
    
    
    /** Ergänzt die Liste, welche alle beteiligten Templates (Erbschaftsliste) enthält,
     * um die übergebende ID.
     * 
     * @param   integer or Array        $in_template_id         ID des Templates, welches der Liste hinzugefügt werden soll. Oder Liste von mehreren Templates, als einfaches Array (Bsp.: array(1,2))
     */
    protected function addTemplateIDToTemplatelist($in_template_id) {
        if(is_array($in_template_id)) {
            foreach ($in_template_id as $value) {
                $this->_template_list[] = $value;
            }
        } else {
            $this->_template_list[] = $in_template_id;
        }
    }
    
    
    /** Gibt die Liste der beteiligten Template-ID's zurück.
     * Aufgrund der Vererbungsfähigkeit von CSS-Templates, können mehrere Templates beteiligt sein.
     * 
     * @return  array           Bsp.: array(1,5,8)
     */
    public function getTemplateIDList() {
        return $this->_template_list;
    }
    
    
    /**
     * Gibt CSS-Attribut-List in dem Format zurück, wie sie im head als STYLE hinterlegt werden kann.
     * 
     * @return String Dieser String kann im Objekt htmlDomTree dem STYLE-Tag als value übergeben werden.
     */
    function getStyleElementListInCSSformat() 
    {
       
        $feedback = "";
        $style_element_list = $this->_style_element_list;
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Style-Attribut-Liste: ', $style_element_list);

        foreach ($style_element_list as $key => $value) {                               //Multidimensionales Array "zeilenweise" durchgehen. Dadurch ergeben sich Arrays, Attributname (key) und Attributwert (value) enthalten müssen.
            $name_for_css = $value["style_element_info"] ["name_for_css"];
            $prefix = $value["style_element_info"] ["css_prefix"];
            $sufix = $value["style_element_info"] ["css_sufix"];
            if (isset($value["style_element_info"] ["style_element_add_attribut"])) {   //Falls ein Zusatzattribut gesetzt ist (Bsp.: a[data-level='0'] -> Zusatzattribut wird in die eckigen Klammern integriert
                $add_attribut = "[".$value["style_element_info"] ["style_element_add_attribut"]."='".$value["style_element_info"] ["style_element_add_attribut_value"]."']";
            } else {
                $add_attribut = "";
            }
            $feedback = $feedback.$prefix.$name_for_css.$add_attribut." { ";                                   //Attributliste für aktuellen Tag öffnen/beginnen
            $attributlist = $value["attribut_list"];
            foreach ($attributlist as $key => $value) {                                //eindimensionales internes Array durchgehen.
                $feedback = $feedback.$key.": ".$value."; ";
            }
            $feedback = $feedback.$sufix." } \r\n";                                      //Attributliste für aktuellen Tag schließen und Zeilenumbruch hinzufügen.         
        }
        
        return $feedback;
    }
    
    
    /** Gibt die Liste der Style-Informationen als Array zurück
     * Bsp.: Array( <br />
                [235] => Array( <br />
                        [style_element_info] => Array( <br />
                                [name_for_css] => html <br />
                                [css_type_name] => tag <br />
                                [css_prefix] =>  <br />
                                [css_sufix] =>  <br />
                                [style_element_add_attribut] =>  <br />
                                [style_element_add_attribut_value] =>  <br />
                            ) <br />
                        [attribut_list] => Array( <br />
                                [height] => 100% <br />
                                [width] => 100% <br />
                            ) <br />
                    ) <br />
                [239] => Array ... <br />
     * 
     * @return  array()         Zweidimensionales Array
     */
    public function getStyleElementListInArrayformat() {
        return $this->_style_element_list;
    }
    
    
    
    
    /** Ergänzt die Elemente der ersten  Liste zur Zweiten,
     * jedoch nur, wenn ein namensgleiches Element, des gleichen CSS-Typs (tag, class, id)
     * noch nicht vorhanden ist. 
     * Syntax der Listen siehe getStyleElementListInArrayformat()
     * 
     * @param   array   $in_firstList           
     * @param   array   $in_secondList
     * @return  array   
     */
    private function mergeStyleElementList($in_firstList, $in_secondList) {
        $tempArray = array();
        
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> CSS-First-List: ', $in_firstList);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> CSS-Second-List: ', $in_secondList);
        
        //Schleife über alle Elemente der ersten Liste
        foreach ($in_firstList as $key_first => $style_from_firstList) {
            $foundItem = false;
            
            //Schleife über alle Elemente der zweiten Liste
            foreach ($in_secondList as $key_second => $style_from_secondList) {
                //Wenn das aktuelle Element der ersten Liste in der zweiten bereits vorhanden ist, wird abgebrochen
                if($style_from_firstList["style_element_info"]["name_for_css"] == $style_from_secondList["style_element_info"]["name_for_css"]) {
                    if($style_from_firstList["style_element_info"]["css_type_name"] == $style_from_secondList["style_element_info"]["css_type_name"]) {
                        //Element ist vorhanden
                        $foundItem = true;
                        break;  //in die obere Schleife zurückkehren
                    }
                }
            }
            
            if($foundItem == true) {
                //Element der ersten Liste ist in der zweiten bereits vorhanden, daher ist keine Aktion notwendig
            } else {
                //Element der ersten Liste ist in der zweiten Liste nicht vorhanden und wird daher ergänzt.
                $tempArray[$key_first] = $style_from_firstList;
            }
            
            
            
        }
        
        $feedback = $in_secondList + $tempArray;
        return $feedback;
    }
    
    
}


/** 
 * 
 * 
 */    
class HtmlAttributList {
    protected $_html_attribut_list;          
    
    
    
    
    /** Konstruktor für Attributliste.
     * 
     * Multidimensionales Array, welches alle Attribute und deren Zuordnung zu einem HTML_element für die aktuelle Maske enthält. 
     * Der Aufbau des Arrays erfordert nur einen Datenbankzugriff und vermeidet somit Latenzen. Die Attribute eines bestimmten HTML-Tags können
     * anschließend aus dieser Klasse mit getAttributForHtmlElement abgefragt werden.
     * 
     * @param Integer   $in_mask_id
     * @param String    $in_mask_app_id
     */
    function __construct($in_mask_id, $in_mask_app_id) 
    { 
        $this->_html_attribut_list = getHtmlAttributListFromMask($in_mask_id, $in_mask_app_id);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> html_attribut_list in class HTMLAttributList: ', $this->_html_attribut_list);
    }
    
    
    
    /**
     * Gibt die HTML-Attribute für ein bestimmtes tag zurück.
     * @param   Integer $in_tag_id  ID eines tags
     * @return  String              Dieser String enthält die Attributliste. Mehrere Attribute werden durch ein Leerzeichen getrennt. Die Liste kann im Tag ohne weitere Formatierung verwendet werden. Wenn keine Attribute vorliegen, wird ein Leerstring übergeben.
     */
    function getHtmlAttributList($in_tag_id) 
    {
       
        $feedback = "";
        $html_attribut_list = $this->_html_attribut_list;
        

        if (isset($html_attribut_list[$in_tag_id])) {
        //Wenn für die übergebene tag_id Attribute existieren, werden diese ausgegeben. 
            foreach ($html_attribut_list[$in_tag_id] as $key => $value) {
                $feedback = $feedback.$key."=\"".$value."\" ";
            }
        }
        return $feedback;
    }
    
    
    
}





class HTMLField {
    
    public $id;                             //id des Feldes (ACHTUNG: PrimaryKey besteht aus id und app_id!)
    public $app_id;
    public $name;
    public $laenge_sum;
    public $laenge_heading;
    public $laenge_content;
    public $laenge_measureunit;
    public $zeilen;
    public $schema;
    public $tabelle;
    public $spalte;
    public $ldapAttribut;
    public $konstante_id;
    public $feldinhalt;
    public $pos_header;
    public $inline;
    public $javascriptOnclick ;
    public $js_click_params;
    public $javascriptOnchange ;
    public $js_change_params;
    public $javascriptOnsubmit ;
    public $js_submit_params;
    public $javascriptOninput ;
    public $js_input_params;
    public $numericMin;
    public $numericMax;
    public $maxZeichen;
    public $ref_schema;
    public $ref_table;
    public $ref_id_field;
    public $ref_show_field;
    public $ref_order_by_field;
    public $ref_condition;
    public $ref_const_app_id;               //Referenz auf eine Konstantenliste
    public $ref_const_id;                   //Referenz auf eine Konstantenliste
    public $button_action_function_id ;
    public $button_action_function_app_id;
    public $button_target;
    public $button_target_mask;             //id der Zielmaske
    public $button_target_mask_app;         //app_id der Zielmaske ToDo: die app_id wird momentan innerhalb des Constructors über die id ermittelt. Das kann ist falsch, app_id Zeil des PK ist.
    public $button_target_form;             //erste target_form
    public $button_target_forms;            //Liste aller target_forms eines Buttons
    public $button_form_mode;
    public $button_paramname; 
    public $button_target_mask_link;        //Linkziel des Buttons, wenn eine abweichende Zielmaske gewählt wurde. Inkl. Suffix, d.h. ggf. temporärer Installationspfad; Bsp.: "../../appms/view/page.php?mask=100maskapp=SYS01&form_id=42"
    public $button_target_mask_link_org;    //Linkziel des Buttons, wenn eine abweichende Zielmaske gewählt wurde. Bsp.: "page.php?mask=100&maskapp=SYS01&form_id=42"
    public $class_container;
    public $class_content;
    public $required;
    public $requiredCode;                   //enthält den HTML Code für das required-Attribut in HTML
    public $readonly;
    public $readonlyCode;                   //enthält den HTML Code für das readonly-Attribut in HTML
    public $addClassCode;                   //enthält einen Zusatz für ein HTML-Attribut
    public $beachtePflichtfeldangabe;       //Boolean, gibt an, ob Pflichtfelder gekennzeichnet werden sollen oder nicht.
    public $depends_from_field;             //Array der Feld-ids, von denen dieses Feld abhängt (siehe DB-Tabelle fields_depends)
    public $dependsfield_target;            //Array der Datenbankfelder, welche die potentiellen Einträge für abhängige Felder bieten. Dieses Array ist analog zu depends_from_field sortiert.
    public $affected_to_field;              //Array der Feld-ids, welche vom aktuellen Feld beeinflußt werden.
    public $form_app_id;                    //App der zugehörigen Form
    public $form_id;                        //ID der zugehörigen Form
    public $query_app_id;                   //[optional] App_id einer query, über welche eine Refernzliste aufgebaut werden soll.
    public $query_id;                       //[optional] id einer query, über welche eine Refernzliste aufgebaut werden soll.
    public $query_ref_field_connection_id;  //Referenz auf ein Feld, welches eine App_id, die als Connection_ID für die in $query_id hinterlegte query genutzt werden soll. Wenn NULL, dann entspricht die Connection_id der app_id.
    public $helptext;                       //[optional] Hilfetext zu einem Feld
    public $is_password;                    //Gibt an, ob es sich um ein Feld vom Typ password-hash handelt. [true|false]
    public $is_encrypted;                   //Gibt an, ob es sich um ein Feld vom Typ encrypted handelt. [true|false]
    public $vorgabewert;                    //Vorgabewert
    public $ausblenden;                     //gibt an, in welchen modi das Feld ausgeblendet werden soll. 0=> nicht ausblenden, 123 => ausblenden in den Modi 1, 2 und 3
    public $is_mailFromField;               //kennzeichnet ein Feld vom Typ MailForm
    public $idAttr = "";                    //Das id-Attribut enthält eine eindeutige ID pro Field und Datensatz. Da Felder in Tabellenstrukturen mehrfach erscheinen, kann dieses eindeutig Attribut erst in showFiels->getFieldsOfRow gebildet werden.
    public $colIndex;                       //Variable zur Aufnahme des Spaltenindex (aria-colindex); Notwendig für Barrierefreiheit. Der Spaltenindex ergibt sich erst, wenn klar ist, ob ein Markierungsfeld vorangestellt wird.
    public $autocomplete;                   //gibt die Modi an, in denen die Autocomplete-Funktion aktiviert wird.
    public $autocomplete_start;             //Anzahl Zeichen, die der User anfügen muss, ehe die Auto-Complete-Funktion startet.
    public $add_attribut;                   //beliebige html-Zusatzattribute; Bsp.: autofocus. Wenn mehrere Attribute angegeben werden sollen, könnten diese durch ein Leerstring getrennt übergeben werden.
    
    /** Constructor der Klasse 
     * Ein Field-Objekt enthält alle Attribute eines Html-Feldes (siehe DB-Tabelle feld)
     * 
     */
    function __construct() {
        
    }
    
    
    
    /** Legt ein Feld der Art "hidden" an und gibt die ID zurück.
     * 
     * @param   object  $in_pagedata                    Referenz zum pagedata-object
     * @param   string  $in_field_app_id                APP-ID des Feldes
     * @param   string  $in_form_app_id                 APP-ID des einzufügenden Feldes; Angabe kann fehlen (Leerstring)
     * @param   integer $in_form_id                     ID des einzufügenden Feldes; Angabe kann fehlen (Leerstring); Angabe wird ignoriert, wenn $in_form_app_id = Leerstring            
     * @param   string  $in_name                        Name des Feldes
     * @param   integer $in_sort                        Reihenfolge in der das Feld im Formular angeordnet werden soll
     * @param   string  $in_spalte                      Name der DB-Spalte, Angabe sollte bei constructor SingleData und Tabledata einer DB-column entsprechen. Ansonsten beachte Hilfe zum Feld in der Oberfläche.
     * @param   integer $in_max_zeichen                 Anzahl zulässiger Zeichen
     * @param   String  $in_vorgabewert                 Vorgabewert bei Neuanlage eines Datensatzes. Mögliche Werte werden im Hilfetext der Oberfläche erläutert. Angabe kann fehlen (Leerstring)
     * @param   integer $in_hide_if_modi                Gibt an, ob ein Feld bei bestimmten Modi ausgeblendet werden soll. Es gibt 7 Modi (siehe Tabelle form_mode). Die Modi können in einem String übergeben werden. Bsp.: "123" blendet das Feld in den Modi 1,2 und 3 aus.
     * @return  mixed                                   Field_ID des angelegten Feldes oder false
     */
    public function addNewHiddenField(&$in_pagedata, $in_field_app_id, $in_form_app_id, $in_form_id, $in_name, $in_sort, $in_spalte, $in_max_zeichen, $in_vorgabewert, $in_hide_if_modi) {
        $app_id_kernel = global_variables::getAppIdFromSYS01();
        
        $this->id = setNewField($in_pagedata, $in_field_app_id, $app_id_kernel, 8, "", $in_form_app_id, $in_form_id, "",
                            "", "", "", "", $app_id_kernel, $in_name, $in_sort, 10, 10, 1, $in_spalte, "", 1, 0, "", "", $in_max_zeichen, "",
                            "", 0, "", "", "", "", "", "", 0, $in_vorgabewert, $in_hide_if_modi, "", "", 1, "");
        return $this->id;
    }
    
    
    
     /** Legt ein Feld der Art "label" (44) an und gibt die ID zurück.
     * 
     * @param   object  $in_pagedata                    Referenz zum pagedata-object
     * @param   string  $in_field_app_id                APP-ID des Feldes
     * @param   string  $in_form_app_id                 APP-ID des einzufügenden Feldes; Angabe kann fehlen (Leerstring)
     * @param   integer $in_form_id                     ID des einzufügenden Feldes; Angabe kann fehlen (Leerstring); Angabe wird ignoriert, wenn $in_form_app_id = Leerstring            
     * @param   string  $in_name                        Name des Feldes
     * @param   integer $in_sort                        Reihenfolge in der das Feld im Formular angeordnet werden soll
     * @param   string  $in_width                       Breite des Feldes. Beispielwerte [100px|90%|auto]
     * @param   string  $in_description                 Text, welcher innerhalb des Labels angedruckt werden soll. Dieser kann beliebige HTML-Ausdrücke enthalten.
     * @return  mixed                                   Field_ID des angelegten Feldes oder false
     */
    public function addNewLabelField(&$in_pagedata, $in_field_app_id, $in_form_app_id, $in_form_id, $in_name, $in_sort, $in_width, $in_description) {
        $app_id_kernel = global_variables::getAppIdFromSYS01();
        
        $this->id = setNewField($in_pagedata, $in_field_app_id, $app_id_kernel, 44, "", $in_form_app_id, $in_form_id, "",
                            "", "", "", "", $app_id_kernel, $in_name, $in_sort, $in_width, $in_width, 1, "", "", 2, 0, "", "", 100000, "",
                            "", 0, "", "", 0, "", "", "", 0, "", 0, "", "", 0, $in_description);
        return $this->id;
    }
    
    
    
        
     /** Legt ein Feld der Art "Mail" (88, 636 oder 637) an und gibt die ID zurück.
     * 
     * @param   object  $in_pagedata                    Referenz zum pagedata-object
     * @param   string  $in_field_app_id                APP-ID des Feldes
     * @param   string  $in_form_app_id                 APP-ID des einzufügenden Feldes; Angabe kann fehlen (Leerstring)
     * @param   integer $in_form_id                     ID des einzufügenden Feldes; Angabe kann fehlen (Leerstring); Angabe wird ignoriert, wenn $in_form_app_id = Leerstring            
     * @param   integer $in_field_type                  mögliche Werte: <br />
      *                                                     88 = normales Eingabefld, welches jedoch den String als E-Mail prüft. <br />
      *                                                     636 = wie 88 und zusätzlich wird Mail als TO-Adresse in einem folgenden Workflow verwendet, <br />
      *                                                     637 = wie 88 und zusätzlich wird Mail als CC-Adresse in einem folgenden Workflow verwendet, <br />
      *                                                     638 = wie 88 und zusätzlich wird Mail als FROM-Adresse in einem folgenden Workflow verwendet. <br />
      *                                                     639 = Textfeld. Eintrag wird als Mail-Subject verwendet. Platzhalter sind möglich (siehe Wiki).
     * @param   string  $in_name                        Name des Feldes
     * @param   string  $in_spalte                      Name der DB-Spalte, Angabe sollte bei constructor SingleData und Tabledata einer DB-column entsprechen. Ansonsten beachte Hilfe zum Feld in der Oberfläche.
     * @param   integer $in_sort                        Reihenfolge in der das Feld im Formular angeordnet werden soll
     * @param   string  $in_width_label                 Breite des Feldes. Beispielwerte [100px|90%|auto]
     * @param   string  $in_width_value                 Breite des Feldes. Beispielwerte [100px|90%|auto]
     * @param   integer $in_pos_header                  Anordnung der Feldbezeichnung [0 = links|1 = oben| 2 = ohne]
     * @param   integer $in_inline                      Gibt an, ob nach dem Feld ein Zeilenumbruch eingefügt wird. [0 = Zeilenumbruch|1 = inline]
     * @param   integer $in_required                    Pflichtfeld [0 = nein|1 = ja]
     * @param   integer $in_readonly                    Gibt an, ob ein Feld schreibgeschützt ist [1 = readonly|0 = open]
     * @param   String  $in_vorgabewert                 Vorgabewert bei Neuanlage eines Datensatzes. Mögliche Werte werden im Hilfetext der Oberfläche erläutert. Angabe optional (Leerstring)
     * @param   string  $in_description                 Text, welcher innerhalb des Labels angedruckt werden soll. Dieser kann beliebige HTML-Ausdrücke enthalten.
     * @return  mixed                                   Field_ID des angelegten Feldes oder false
     */
    public function addNewMailField(&$in_pagedata, $in_field_app_id, $in_form_app_id, $in_form_id, $in_field_type, $in_name, $in_spalte, $in_sort, $in_width_label, $in_width_value, $in_pos_header, $in_inline, $in_required, $in_readonly, $in_vorgabewert, $in_description) {
        $app_id_kernel = global_variables::getAppIdFromSYS01();
        
        $this->id = setNewField($in_pagedata, $in_field_app_id, $app_id_kernel, $in_field_type, "", $in_form_app_id, $in_form_id, "",
                            "", "", "", "", $app_id_kernel, $in_name, $in_sort, $in_width_value, $in_width_label, 1, $in_spalte, "", $in_pos_header, $in_inline, "", "", 255, "",
                            "", $in_required, "", "", 0, "", "", "", $in_readonly, $in_vorgabewert, 0, "", "", 0, $in_description);
        return $this->id;
    }
    
    
    
    /** Legt ein Feld der Art "Textfeld" (3) an und gibt die ID zurück.
     * 
     * @param   object  $in_pagedata                    Referenz zum pagedata-object
     * @param   string  $in_field_app_id                APP-ID des Feldes
     * @param   string  $in_form_app_id                 APP-ID des einzufügenden Feldes; Angabe kann fehlen (Leerstring)
     * @param   integer $in_form_id                     ID des einzufügenden Feldes; Angabe kann fehlen (Leerstring); Angabe wird ignoriert, wenn $in_form_app_id = Leerstring            
     * @param   string  $in_name                        Name des Feldes
     * @param   string  $in_spalte                      Name der DB-Spalte, Angabe sollte bei constructor SingleData und Tabledata einer DB-column entsprechen. Ansonsten beachte Hilfe zum Feld in der Oberfläche.
     * @param   integer $in_sort                        Reihenfolge in der das Feld im Formular angeordnet werden soll
     * @param   string  $in_width_label                 Breite des Feldes. Beispielwerte [100px|90%|auto]
     * @param   string  $in_width_value                 Breite des Feldes. Beispielwerte [100px|90%|auto]
     * @param   integer $in_pos_header                  Anordnung der Feldbezeichnung [0 = links|1 = oben| 2 = ohne]
     * @param   integer $in_inline                      Gibt an, ob nach dem Feld ein Zeilenumbruch eingefügt wird. [0 = Zeilenumbruch|1 = inline]
     * @param   integer $in_required                    Pflichtfeld [0 = nein|1 = ja]
     * @param   integer $in_readonly                    Gibt an, ob ein Feld schreibgeschützt ist [1 = readonly|0 = open]
     * @param   String  $in_vorgabewert                 Vorgabewert bei Neuanlage eines Datensatzes. Mögliche Werte werden im Hilfetext der Oberfläche erläutert. Angabe optional (Leerstring)
     * @param   integer $in_ausblenden_bei_modi         Gibt an, ob ein Feld bei bestimmten Modi ausgeblendet werden soll. Es gibt 7 Modi (siehe Tabelle form_mode). Die Modi können in einem String übergeben werden. Bsp.: "123" blendet das Feld in den Modi 1,2 und 3 aus.
     * @param   string  $in_description                 Text, welcher innerhalb des Labels angedruckt werden soll. Dieser kann beliebige HTML-Ausdrücke enthalten.
     * @return  mixed                                   Field_ID des angelegten Feldes oder false
     */
    public function addNewTextField(&$in_pagedata, $in_field_app_id, $in_form_app_id, $in_form_id, $in_name, $in_spalte, $in_sort, $in_width_label, $in_width_value, $in_pos_header, $in_inline, $in_required, $in_readonly, $in_vorgabewert, $in_ausblenden_bei_modi, $in_description) {
        $app_id_kernel = global_variables::getAppIdFromSYS01();
        
        $this->id = setNewField($in_pagedata, $in_field_app_id, $app_id_kernel, 3, "", $in_form_app_id, $in_form_id, "",
                            "", "", "", "", $app_id_kernel, $in_name, $in_sort, $in_width_value, $in_width_label, 1, $in_spalte, "", $in_pos_header, $in_inline, "", "", 255, "",
                            "", $in_required, "", "", 0, "", "", "", $in_readonly, $in_vorgabewert, $in_ausblenden_bei_modi, "", "", 0, $in_description);
        return $this->id;
    }
    
    
    
    
            
     /** Legt ein Feld der Art "Trennlinie" (517) an und gibt die ID zurück.
      * Oberhalb der Trennlinie werden 2 Leerzeilen ergänzt. Die Trennlinie hat eine Breite von 90% und
      * wird von einem Zeillenumbruch gefolgt.
     * 
     * @param   object  $in_pagedata                    Referenz zum pagedata-object
     * @param   string  $in_field_app_id                APP-ID des Feldes
     * @param   string  $in_form_app_id                 APP-ID des einzufügenden Feldes; Angabe kann fehlen (Leerstring)
     * @param   integer $in_form_id                     ID des einzufügenden Feldes; Angabe kann fehlen (Leerstring); Angabe wird ignoriert, wenn $in_form_app_id = Leerstring            
     * @param   integer $in_sort                        Reihenfolge in der das Feld im Formular angeordnet werden soll
     * @param   integer $in_ausblenden_bei_modi         Gibt an, ob ein Feld bei bestimmten Modi ausgeblendet werden soll. Es gibt 7 Modi (siehe Tabelle form_mode). Die Modi können in einem String übergeben werden. Bsp.: "123" blendet das Feld in den Modi 1,2 und 3 aus.
     * @param   string  $in_description                 Text, welcher innerhalb des Labels angedruckt werden soll. Dieser kann beliebige HTML-Ausdrücke enthalten.
     * @param   string  $in_name                        Wert, der im Name-Attribut der Trennlinie abgelegt werden soll. (max. 45 Zeichen)
     * @return  mixed                                   Field_ID des angelegten Feldes oder false
     */
    public function addNewLineField(&$in_pagedata, $in_field_app_id, $in_form_app_id, $in_form_id, $in_sort, $in_ausblenden_bei_modi, $in_description, $in_name) {
        $app_id_kernel = global_variables::getAppIdFromSYS01();
        $name = substr($in_name, 0, 45);
        
        $this->id = setNewField($in_pagedata, $in_field_app_id, $app_id_kernel, 517, "", $in_form_app_id, $in_form_id, "",
                            "", "", "", "", $app_id_kernel, $name, $in_sort, "90%", "90%", 2, "", "", 1, 0, "", "", 1, "",
                            "", 0, "", "", 0, "", "", "", 0, "", $in_ausblenden_bei_modi, "", "", 0, $in_description);
        return $this->id;
    }
    
    
    
    
    /** Legt ein Feld der Art "WYSIWYG" an und gibt die ID zurück.
     * 
     * @param   object  $in_pagedata                    Referenz zum pagedata-object
     * @param   string  $in_field_app_id                APP-ID des Feldes
     * @param   string  $in_form_app_id                 APP-ID des einzufügenden Formulars; Angabe kann fehlen (Leerstring)
     * @param   integer $in_form_id                     ID des einzufügenden Formulars; Angabe kann fehlen (Leerstring); Angabe wird ignoriert, wenn $in_form_app_id = Leerstring            
     * @param   string  $in_name                        Name des Feldes
     * @param   integer $in_sort                        Reihenfolge in der das Feld im Formular angeordnet werden soll
     * @param   string  $in_spalte                      Name der DB-Spalte, Angabe sollte bei constructor SingleData und Tabledata einer DB-column entsprechen. Ansonsten beachte Hilfe zum Feld in der Oberfläche.
     * @return  mixed                                   Field_ID des angelegten Feldes oder false
     */
    public function addNewWysiwygField(&$in_pagedata, $in_field_app_id, $in_form_app_id, $in_form_id, $in_name, $in_sort, $in_spalte) {
        $app_id_kernel = global_variables::getAppIdFromSYS01();
        
        $this->id = setNewField($in_pagedata, $in_field_app_id, $app_id_kernel, 694, "", $in_form_app_id, $in_form_id, "",
                            "", "", "", "", $app_id_kernel, $in_name, $in_sort, "auto", "auto", 1, $in_spalte, "", 2, 0, "", "", 10000000, "",
                            "", 0, "", "", "", "", "", "", 0, "", 0, "", "", 1, "");
        return $this->id;
    }
    
    
    
    /** Erstellt anhand eines Fieldarrays, wie es getFieldList erstellt, ein Field-Objekt.
     * 
     * @param   Array   $in_field                       Ein Datensatz aus der Arraylist $fieldlist
     * @param   Boolean $in_set_vorgabewert             Gibt an, ob in dem Feld bereits ein Vorgabewert angedruckt werden soll
     * @param   Boolean $in_beachte_Pflichtfeldangabe   Gibt an, ob Pflichtfelder vom Browser beachtet werden sollen
     * @param   object  $in_pagedata                    Referenz auf das pagedata-object
     * @param   Boolean $in_beachte_readonly            Gibt an, die Eigenschaft "readonly" beachtet werden soll. Bei Formularen, die im modus "Filter" gezeigt werden, sollte die Eigenschaft nicht beachtet werden. (default = true)
     * @param   Boolean $in_allways_readonly            Legt fest, dass alle Felder readonly sind. Dieser Parameter überlagert den Parameter $in_beachte_readonly. (default = false)
     */
    public function buildFieldBasedOnFieldArray($in_field, $in_set_vorgabewert, $in_beachte_Pflichtfeldangabe, &$in_pagedata, $in_beachte_readonly = true, $in_allways_readonly = false) { 
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> current_field ", $in_field, "INFO");
        $this->id=$in_field ["feld.id"];
        $this->app_id=$in_field ["feld.app_id"];
        $this->name=$in_field ["feld.name"];
        $this->inline = $in_field ["feld.inline"];
        $this->pos_header = $in_field ["feld.pos_header"];
        
        $laengen = $this->getLaengeFromField($in_field);
        $this->laenge_heading       = $laengen["laenge_heading"];
        $this->laenge_content       = $laengen["laenge_content"];
        $this->laenge_sum           = $laengen["laenge_sum"];
        $this->laenge_measureunit   = $laengen["laenge_measureunit"];
        $this->zeilen=$in_field ["feld.zeilen"];
        $this->schema = $in_field ["form.db_schema"];
        
        if(strpos($in_field["feld.spalte"] ??'',".")>0) {
            //Wenn in der Spalte ein Punkt enthalten ist, dann wurden Tabelle und Spalte in diesem Attribut hinterlegt. 
            //Das ist der vorgeschlagene Weg, wenn eine Query die Basis eines Formulars ist. In dem Fall kann es sein,
            //dass sich die Querie auf mehrere Tabellen bezieht, sodass die einmalige Angabe der Tabelle im Formular nicht ausreichend wäre.
            $my_tableAndColumn = explode(".", $in_field["feld.spalte"]);
            $this->tabelle = $my_tableAndColumn[0];
            $this->spalte = $my_tableAndColumn[1];
        } else {
            $this->tabelle = $in_field ["form.db_table"];
            $this->spalte = $in_field ["feld.spalte"];
        }
        
        $this->ldapAttribut = $in_field ["feld.ldap_attribut"];
        $this->konstante_id = $in_field ["feld.konstante_id"];
            if($this->konstante_id == 70) {$this->is_password = true;} else {$this->is_password = false;}
            if($this->konstante_id == 2628) {$this->is_encrypted = true;} else {$this->is_encrypted = false;}
            if($this->konstante_id == 638) {$this->is_mailFromField = true;} else {$this->is_mailFromField = false;}
        $this->javascriptOnclick = $this->buildJavascriptAttribut($in_field ["feld.javascript_onclick"], $in_field["feld.js_click_params"]) ;
        $this->js_click_params = $in_field["feld.js_click_params"];
        $this->javascriptOnchange = $this->buildJavascriptAttribut($in_field ["feld.javascript_onchange"], $in_field["feld.js_change_params"]) ;
        $this->js_change_params = $in_field["feld.js_change_params"];
        $this->javascriptOnsubmit = $this->buildJavascriptAttribut($in_field ["feld.javascript_onsubmit"], $in_field["feld.js_submit_params"]) ;
        $this->js_submit_params = $in_field["feld.js_submit_params"];
        $this->javascriptOninput = $this->buildJavascriptAttribut($in_field ["feld.javascript_oninput"], $in_field["feld.js_oninput_params"]) ;
        $this->js_input_params = $in_field["feld.js_oninput_params"];
        $this->numericMin = $in_field ["feld.numeric_min"];
        $this->numericMax = $in_field ["feld.numeric_max"];
        $this->maxZeichen = $in_field ["feld.max_zeichen"];
        $this->ref_schema = $in_field ["feld.ref_schema"];
        $this->ref_table = $in_field ["feld.ref_table"];
        $this->ref_id_field = $in_field ["feld.ref_id_field"];
        $this->ref_show_field = $in_field ["feld.ref_show_field"];
        $this->ref_order_by_field = $in_field ["feld.ref_order_by_field"];
        $this->ref_condition = $in_field ["feld.ref_condition"];
        $this->ref_const_app_id = $in_field ["feld.ref_konstantentyp_app_id"];
        $this->ref_const_id = $in_field ["feld.ref_konstantentyp_id"];
        $this->button_action_function_id = $in_field ["feld.button_action_function_id"];
        $this->button_action_function_app_id = $in_field ["feld.button_action_function_app_id"];
        $this->button_target = $in_field ["feld.button_target"];
        $this->button_target_mask = $in_field ["feld.button_target_mask"];
        //$this->button_target_form = $in_field ["feld.button_target_form"];            
        $this->button_form_mode = $in_field ["feld.form_mode_id"];
        if($in_field["content.content_type_id"] == 5) {
            //Wenn der Button einen URL-Parameter bestücken soll
            $this->button_paramname = $in_field ["content.text"];
        } else {
            $this->button_paramname = "";
        }
        $this->required = $in_field ["feld.required"];
        $this->readonly = $in_field ["feld.readonly"];
        $this->beachtePflichtfeldangabe = $in_beachte_Pflichtfeldangabe;
        $this->form_app_id = $in_field ["feld.form_app_id"];
        $this->form_id = $in_field ["feld.form_id"];
        $this->query_app_id = $in_field["feld.query_app_id"];
        $this->query_id = $in_field["feld.query_id"];
        $this->query_ref_field_connection_id = $in_field["feld.query_ref_field_connection_id"];
        $this->helptext = $in_field["feld.helptext"];
        $this->vorgabewert = $in_field ["feld.vorgabewert"];
            if ($in_pagedata->existWorkflow() == true) {
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> suche Field in Workflow ", $this->spalte, "INFO");
                //Prüfen, ob sich für die aktuelle Spalte im Workflow-Objekt Vorgabewerte finden lassen.
                $workflow_step_vorgabewert = "";
                if($in_allways_readonly == true) {
                    //Wenn Formular bereits in only_read ist (abgesendeter Workflow-Schritt, dann prüfen, ob in wkfl_Columns ein Wert eingegeben wurde
                    $workflow_step_vorgabewert = $in_pagedata->getWorkflow()->getUsedValueForField($this->spalte);
                }
                if($workflow_step_vorgabewert == "") {
                    //Ansonsten Vorgabewert nutzen
                    $workflow_step_vorgabewert = $in_pagedata->getWorkflow()->getDefaultValueForField($this->spalte);
                }
                if($workflow_step_vorgabewert!="") {
                    $workflow_step_vorgabewert = replacePluginFunction($workflow_step_vorgabewert, $in_pagedata);
                    $this->vorgabewert = $workflow_step_vorgabewert;
                    //Wenn es einen stepspezifischen Workflow-Vorgabewert gibt, dann überlagert dieser immer den vorhanden feldinhalt, da dieser aus einem alten Step stammt.
                    $in_field ["feld.feldinhalt"] = $workflow_step_vorgabewert;
                }
            }
        $this->ausblenden = $in_field["feld.ausblenden_bei_insert"];
        $this->autocomplete = $in_field["feld.autocomplete"];
        $this->autocomplete_start = $in_field["feld.autocomplete_start"];
        $this->add_attribut = $in_field["feld.add_attribut"];
        
        
        
        //Vorgabewert & vorhandener Feldinhalt
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> current_field ", $this->name." - isMailForm: ".$this->is_mailFromField, "INFO");
        if ($in_set_vorgabewert == true OR $this->is_mailFromField === true) {
            //Vorgabewert (modus muss theoretisch 2 (insert) sein oder es ist ein MailFormField)
            if(isset($in_field ["feld.feldinhalt"]) <> false AND $this->is_mailFromField === false) {
                //Dieser Fall tritt ein, wenn über getDefaultData Dummy-Daten mit Vorgabewerten aus einem Parent-Formular erzeugt wurden.
                if($in_field ["feld.feldinhalt"] == "") {$lookForDefaultValue = true;} else {$lookForDefaultValue = false;}
            } else {
                $lookForDefaultValue = true;
            }
            
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> lookForDefaultValue ", $lookForDefaultValue, "INFO");
        
            if($lookForDefaultValue == true) {
                if(strpos($this->vorgabewert ?? '','$$function.')!== false) {
//                    $localfeedback = getValueFromPluginFunction($this->vorgabewert,$in_pagedata);
//                    if($localfeedback !== false) {
//                        $this->feldinhalt = $localfeedback;
//                    } 
                    $this->feldinhalt = replacePluginFunction($this->vorgabewert, $in_pagedata);
                } else {
                    //Ansonsten wird die Angabe in $this->vorgabewert als Konstante behandelt.
                    $this->feldinhalt = $this->vorgabewert;
                }
            } else {
                $this->feldinhalt = $in_field ["feld.feldinhalt"];
            }
                
            
        } elseif(isset($in_field ["feld.feldinhalt"])) {
            //vorhandener Feldinhalt
            $this->feldinhalt = $in_field ["feld.feldinhalt"];
        } else {
            $this->feldinhalt="";
        }

//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Feldinhalt ", $this->feldinhalt, "INFO");
        
        
        
        //buttontargetmask -> wenn eine ID vorhanden ist, dann link für target_mask ermitteln
        if ($this->button_target_mask <> "") {
            $link_mask_array = getMaskDataById($this->button_target_mask, $this->app_id, $in_pagedata->getSessionUseTempInstallPath());          
            $this->button_target_mask_link = $link_mask_array["link"];
            $this->button_target_mask_link_org = $link_mask_array["link_org"];
            $this->button_target_mask_app = $link_mask_array["app_id"];
        }
        
        
        
        if ($this->required == 1 AND $this->beachtePflichtfeldangabe == TRUE) {
            $this->requiredCode = "required=\"required\""; 
            $this->addClassCode="_required";
        } elseif ($this->required == 2 AND $this->beachtePflichtfeldangabe == TRUE) {
            $this->requiredCode = ""; 
            $this->addClassCode=" nice_to_have";
        } else {
            $this->requiredCode=""; 
            $this->addClassCode="";
        }  
        
        
        //Feld ist readonly muss nach required behandelt werden, da sonst addClassCode falsch bestückt wird.
        if (($this->readonly == 1 AND $in_beachte_readonly == true) OR $in_allways_readonly == true) {
            $this->readonlyCode = "readonly=\"readonly\"";
            $this->addClassCode="_readonly";
            if($this->id == 4217) {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Readonly-Steuerungen für Feld 4217, in_beachte_readonly = ".$in_beachte_readonly.", in_allways_readonly = ".$in_allways_readonly, $this, "INFO");}
        } else {$this->readonlyCode="";}
        
        
        //Zeilenumbruch nach Feld oder nicht:
        If ($this->inline==false) {                                             //Nach dem Feld ein Zeilenumbruch
            $this->class_container = "field_container_default";
            $this->class_content = "field_content_default";
        } else {                                                                // Felder werden in einer Zeile dargestellt, solange pLtz ist (float)
            $this->class_container = "field_container_left";
            $this->class_content = "field_content_left";
        } 
        
        //depends_from_field, $dependsfield_target und affected_to_field in arrays verwandeln, falls es strings sind
        if(is_string($in_field ["feld.depends_from_field"])) {
            $tempString = $in_field ["feld.depends_from_field"];
            if($tempString == "") {
                $this->depends_from_field = array();
            } else {
                $this->depends_from_field = explode(",", $tempString);          //eine Kommaseparierte Liste von FeldIds wird in ein Array gewandelt. 
            }
        }
        if(is_string($in_field ["feld.affected_to_field"])) {
            $tempString = $in_field ["feld.affected_to_field"];
            if($tempString == "") {
                $this->affected_to_field = array();
            } else {
                $this->affected_to_field = explode(",", $tempString);           //eine Kommaseparierte Liste von FeldIds wird in ein Array gewandelt. 
            }
        }
        if(is_string($in_field ["feld.dependsfield_target"])) {
            $tempString = $in_field ["feld.dependsfield_target"];
            if($tempString == "") {
                $this->dependsfield_target = array();
            } else {
                $this->dependsfield_target = explode(",", $tempString);         //eine Kommaseparierte Liste von FeldIds wird in ein Array gewandelt. 
            }
        }
        if(is_string($in_field ["feld.target_forms"])) {
            $tempString = $in_field ["feld.target_forms"];
            if($tempString == "") {
                $this->button_target_forms = array();
            } else {
                $this->button_target_forms = explode(",", $tempString);         //eine Kommaseparierte Liste von FormIds wird in ein Array gewandelt. 
                $this->button_target_form = getFirstValueFromArray($this->button_target_forms); //die erste target_form wird in diese Variable übergeben
            }
            
        }
        
        
        
    }
    
    
    /** ermittelt anhand der Attribute feld.laenge und feld.laenge_label die Maßeinheit (px, % oder auto)
     * sowie die nummerischen Längen der Felder und Beschriftungen
     * 
     * @param   array   $in_field       Ein Datensatz aus der Arraylist $fieldlist
     * @return  array                   Bsp.: array(laenge_measureunit => (%|px|auto), laenge_content => 100, laenge_heading => 50, laenge_sum => 150)
     */
    private function getLaengeFromField($in_field) {
        $feedback = array();
        
        //alle Zeichen, außer Zahlen, entfernen
        $feedback["laenge_content"] = preg_replace('/[^0-9]/','',$in_field ["feld.laenge"]);
        $feedback["laenge_heading"] = preg_replace('/[^0-9]/','',$in_field ["feld.laenge_label"]);
            
        //1. unerlaubte Zeichen entfernen und Maßeinheit ermitteln
        if(strpos($in_field ["feld.laenge"], "px") > 0) {
            $feedback["laenge_measureunit"] = "px";
        } elseif(strpos($in_field ["feld.laenge"], "%") > 0) {
            $feedback["laenge_measureunit"] = "%";
        } elseif(is_numeric($in_field ["feld.laenge"]) AND $in_field ["feld.laenge"] > 0) {
            //Wenn keine Maßeinheit angegeben ist
            $feedback["laenge_measureunit"] = "px";
        } else {
            $feedback["laenge_measureunit"] = "auto";
            $feedback["laenge_content"] = "";
            $feedback["laenge_heading"] = "";
        }
        
        //2. Längen in Abhängigkeit von der Anordnung der Überschrift festlegen
        if($in_field ["feld.pos_header"] == 0) {
            //Überschrift ist neben dem Feld
            $feedback["laenge_sum"] = (int)$feedback["laenge_content"] + (int)$feedback["laenge_heading"];
            if($feedback["laenge_measureunit"] == "px") {
                $feedback["laenge_sum"] = (int)$feedback["laenge_sum"] + 20; //+ 20 ist notwendig, da per css noch Abstände gesetzt werden könnten
            } elseif($feedback["laenge_measureunit"] == "%") {
                //nothing todo (Achtung %-Zahl kann so auch größer als 100 sein.)
                
            } else {
                //auto -> nothing todo
            }
        } else {
            //Überschrift ist über dem Feld; Alle Werte müssen identisch sein, damit Überschrift und Content genau übereinander ausgerichtet sind.
            $feedback["laenge_heading"]   = (int)$feedback["laenge_content"];
            $feedback["laenge_content"]   = (int)$feedback["laenge_content"];
            $feedback["laenge_sum"]       = (int)$feedback["laenge_content"];
        }
        
//        if($in_field["feld.id"]== "199") {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> field 199 ", $in_field, "INFO");
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> field-Längen ", $feedback, "INFO");
//        }
        
        return $feedback;
    }
    
    
    
    /** Gibt die Gesamtlänge des Feldes in Pixeln zurück, wenn die Länge des Feldes und Überschrift in Pixeln vorliegen.
     * Andernfalls wird die Länge pauschal mit 300px angegeben.
     * Die Funktion dient nur dazu die Gesamtbreite eines Formulars berechnen zu können.
     * Die genauen Feldspezifischen Längenangaben befinden sich in den laenge...-Attributen.
     * 
     * @param   integer     $in_form_mode                   Modus der aktuellen Instanz des Formulars. Da manche Felder in bestimmten modi nicht angedruckt werden, wird die Breite eines Feles berücksichtigt, oder eben nicht.
     * @return  integer
     */
    public function getWidth($in_form_mode) {
        
        
        
        if(strpos($this->ausblenden, $in_form_mode) === false) {
            $feedback = 300;
            if($this->laenge_measureunit == "px") {
                if(in_array($this->konstante_id,array(8, 20, 517))) {
                    //Breite wird bei diesen Feldarten nicht beachtet (hidden, Zeilenumbruch, Trennlinie)
                    $feedback = 0;
                } else {
                    $feedback = $this->laenge_sum +25;
                }
            }
        } else {
            //Das Feld wird im aktuellen Modus ausgeblendet
            $feedback = 0;
        }
        return $feedback;
    }
    
    
    /** Diese Funktion erstellt aus dem JavaScript-Funktionsnamen und der Parameterliste 
     * den korrekten Funktionsaufruf für das Attribut javascript in HTML
     * 
     * @param   string  $in_javascriptFunctionName      Name der Javascriptfunktion. 
     * @param   string  $in_javascriptParams            Liste der Parameter
     * @return  string                                  Funktionsname mit Parameterliste; Bsp.: myFunction(param1, param2)
     */
    public function buildJavascriptAttribut($in_javascriptFunctionName, $in_javascriptParams) {
        //Hinweis: Es ist möglich, dass der Funktionsname bereits fix mit Parameter[n] hinterlegt ist (Bsp.: "return hideForm(event)").
        //Alternativ können die Parameter auch in der separaten Spalte "in_xxxxx_params hinterlegt sein.
        //Die verfügbaren Funktionen werden in der Tabelle manager.konstante unter der konstantentyp_id = 7 definiert.
        
        $feedback = "";
        $tempname = "";
        
        if($in_javascriptFunctionName != "") {
        
            if (strpos($in_javascriptFunctionName, '()') !== false AND $in_javascriptParams == "") {
                //Funktion wird bereits mit Klammern angegeben und es gibt keine Parameter.
                $feedback = $in_javascriptFunctionName;
            } elseif (strpos($in_javascriptFunctionName, '()') !== false AND $in_javascriptParams != "") {
                //Funktion wird mit Klammern angegeben, aber es gibt zusätzliche Parameter
                $tempname = str_replace("()", "", $in_javascriptFunctionName);
                $feedback = $in_javascriptFunctionName."(".$in_javascriptParams.")";
            } elseif (strpos($in_javascriptFunctionName, '(') !== false AND $in_javascriptParams == "") {
                //Funktion wird mit Klammern und Parametern (in einem Feld) angegeben -> zusätzliche Parameter werden ignoriert
                $feedback = $in_javascriptFunctionName;
            } elseif ($in_javascriptFunctionName != "") {
                //Funktionsname wird ohne Klammern angebenen. Die Parameter stehen ggf. im separaten Datenbankfeld. -> neue Variante
                $feedback = $in_javascriptFunctionName."(".$in_javascriptParams.")";
            } 
        }
        
        return $feedback;
    }
    
    
    
    /* Gibt den Wert einer Eigenschaft zurück, falls diese Eigenschaft existiert.
     * Wenn die Eigenschaft nicht existiert, wird false zurückgegeben
     * 
     * @param   string  $in_property_name       Name dr Eigenschaft
     * @return  mixed                           Value oder false
     */
    function getProperty($in_property_name) {
        if(isset($this->$in_property_name)) {
            //Wenn diese Eigenschaft existiert
            return $this->$in_property_name;
        } else {
            return false;
        }
    }
    
    
}




class HTMLFieldList {
    
    
    public $fieldlist = array();                    //key = CONCAT(feld.app_id,feld.id);         value = Objekt vom Typ htmlField
    
    /**
     *
     * @var     integer     Summer der Width-Eigenschaft aller Felder in Pixeln. Wenn die Angabe für ein Feld nicht vorlag, dann wird mit einer Pauschale kalkuliert.
     */
    private $width;
    
    /** Erzeugt für eine Liste von Feldern inkl. Attibuten einen Objektbaum. Die Objekte sind über fiellist(CONCAT(feld.app_id,feld.id)) abrufbar
     * 
     * @param   array       $in_fieldlist                   2-Dimensionales Array mit Feldern, wie es die Funktion getFieldList erzeugt
     * @param   boolean     $in_set_vorgabewert             Gibt an, ob der Standardwert eines Feldes gesetzt werden soll
     * @param   boolean     $in_beachte_Pflichtfeldangabe   Gibt an, ob Pflichtfelder beachtet werden sollen. Wenn ja wird die required-Eigenschaft gesetzt.
     * @param   object      $in_pagedata                    Referenz auf das pagedata-object
     * @param   integer     $in_form_mode                   Modus der aktuellen Instanz des Formulars. Da manche Felder in bestimmten modi nicht angedruckt werden, wird die Breite eines Feles berücksichtigt, oder eben nicht.
     * @param   boolean     $in_beachte_readonly            [optional] Gibt an, die Eigenschaft "readonly" beachtet werden soll. Bei Formularen, die im modus "Filter" gezeigt werden, sollte die Eigenschaft nicht beachtet werden. (default = true)
     * @param   boolean     $in_allways_readonly            [optional] Legt fest, dass alle Felder readonly sind. Dieser Parameter überlagert den Parameter $in_beachte_readonly. (default = false)
     */
    function __construct(&$in_fieldlist, $in_set_vorgabewert, $in_beachte_Pflichtfeldangabe, &$in_pagedata, $in_form_mode, $in_beachte_readonly = true, $in_allways_readonly = false) {
        for($i = 0; $i < count($in_fieldlist); $i++) {
            $this->addField($in_fieldlist[$i], $in_set_vorgabewert, $in_beachte_Pflichtfeldangabe, $in_pagedata, $in_beachte_readonly, $in_allways_readonly);
        }
        
        //Breite der gesamten Felderliste berechnen
        $this->calculateWidth($in_form_mode);
    }
    
    
    
    public function getWidth() {
        return $this->width;
    }
    
    
    /**
     * Berechnet die Summe der Width-Attribute aller Felder.
     * @param   integer     $in_form_mode                   Modus der aktuellen Instanz des Formulars. Da manche Felder in bestimmten modi nicht angedruckt werden, wird die Breite eines Feles berücksichtigt, oder eben nicht.
     *
     */
    private function calculateWidth($in_form_mode) {
        $sumWidth = 0;      
        foreach ($this->fieldlist as $currentField) {
            $sumWidth = $sumWidth + $currentField->getWidth($in_form_mode);
        }
        $this->width = $sumWidth;
    }
            
    
    
    /** Fügt der Feldliste ein Feld hinzu.
     * 
     * @param   array   $in_field               Array mit allen Angaben zu einem Feld (siehe getFieldlist)
     * @param   boolean $in_set_vorgabewert     Gibt an, ob Vorgabewerte beachtet werden sollen 
     * @param   type    $in_beachte_Pflichtfeldangabe
     * @param   object  $in_pagedata            Referenz auf das pagedata-object
     * @param   boolean $in_beachte_readonly    Gibt an, die Eigenschaft "readonly" beachtet werden soll. Bei Formularen, die im modus "Filter" gezeigt werden, sollte die Eigenschaft nicht beachtet werden. (default = true)
     * @param   boolean $in_allways_readonly    Legt fest, dass alle Felder readonly sind. Dieser Parameter überlagert den Parameter $in_beachte_readonly. (default = false)
     */
    function addField($in_field, $in_set_vorgabewert, $in_beachte_Pflichtfeldangabe, &$in_pagedata, $in_beachte_readonly = true, $in_allways_readonly = false) {
        $currentField  = new HTMLField();
        $currentField->buildFieldBasedOnFieldArray($in_field, $in_set_vorgabewert, $in_beachte_Pflichtfeldangabe, $in_pagedata, $in_beachte_readonly, $in_allways_readonly);
        $key = $in_field["feld.app_id"].$in_field["feld.id"];
        $this->fieldlist[$key] = $currentField;
    }
    
    
    /** gibt das Feldobjekt für die übergebene id zurück.
     * 
     * @param   integer     $in_id      id eines Feldes (siehe DB-Tabelle feld)
     * @return  object                  objekt vom typ HtmlField or FALSE
     */
    function getField($in_id) {
        foreach ($this->fieldlist as $key => $value) {
            $currentField = $value;
            if($currentField->id == $in_id) {
                return $currentField;
            } 
        }
        
        //Wenn kein Feld mit der genannten id gefunden wurde, wird FALSE zurückgegeben
        return FALSE;
        
    }
    
    
    
    
    
    /**Ermittelt anhand der db_spalte, mit der ein Field verknüpft ist, den Feldinhalt.
     * 
     * @param   string  $in_column      Name der db_spalte (siehe feld.db_spalte)
     * @return  string                  Wenn Feld nicht gefunden werden konnte, wird ein Leerstring zurückgegeben
     */
    function getFieldValueByColumn($in_column) {
        foreach ($this->fieldlist as $key => $currentField) {
            if($currentField->spalte == $in_column) {
                return $currentField->feldinhalt;
            } 
        }
        
        //Wenn kein Feld mit der genannten in_column gefunden wurde, wird ein Leerstring zurückgegeben
        return "";
        
    }
    
    
    
}






?>