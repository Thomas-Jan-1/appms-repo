<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

/**
 * Bietet Methoden zur Steuerung von SOAP-Anfragen
 *
 * @author thomas
 */
class soap_client_appms {
    

    
    /**
     * 
     * @var     object          Soap-Verbindung
     */
    private $soap;
    
    /**
     * 
     * @var     string
     */
    public $username;
    
    /**
     * 
     * @var     string
     */
    public $password;
    
    /**
     * 
     * @var     string
     */
    public $base_url;
    
    /**
     * 
     * @var     string
     */
    public $param_as_string;
    
    /**
     * 
     * @var     string      Default= "SOAP_1_2"
     */
    public $api_method;
    
    
    
    
    
    /** Bietet Methoden zur Steuerung von SOAP-Anfragen. 
     * initiale Arbeitsschritte zur Etablierung der Soap-Verbindung werden ausgeführt, Klassen-Eigenschaften werden vorbelegt.
     * 
     * @param   string  $in_accessdata_name Name des Datensatzes,der Zugangsdaten enthält. Diese müssen zuvor über die Maske "Zugangsdaten API's" hinterlegt werden.
     * @param   string  $in_app_id          APP-ID
     * @param   boolean $in_trace           [optional] Gibt an, ob trace-stack (debug) aktiviert werden soll. Default = false
     * @param   string  $in_uri             [optional] Domäne, i.d.R. identisch zur base_url. Default = base_url
     * @param   string  $in_soap_version    [optional] Version; Default = SOAP_1_2
     * @return  boolean                     Wenn Zugngansdaten vorhanden und Soap-Client initiert werden konnten.
     */
    public function __construct($in_accessdata_name, $in_app_id, $in_trace = false, $in_uri = "", $in_soap_version = "SOAP_1_2") {
        $feedback = false;
        
        
        //Zugangsdaten ermitteln
        $bedingung = "api_name = '".$in_accessdata_name."' and app_id = '".$in_app_id."'";
        $soap_connect_data = getTableData2(global_variables::getAppIdFromSYS01(),
                                           "access_token", 
                                           global_variables::getNameOfDbSchemaSYS01(), 
                                           array(0 => Array("feld.spalte" => "api_username"),1 => Array("feld.spalte" => "api_password"),2 => Array("feld.spalte" => "base_url"),3 => Array("feld.spalte" => "param_as_string"),4 => Array("feld.spalte" => "api_method")), 
                                           false, "", $bedingung, __FUNCTION__);
        
        
        if(count($soap_connect_data) > 0) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Soap-Zugangsdaten', $soap_connect_data);
            
            $this->base_url = $soap_connect_data[0]["access_token.base_url"];
            $this->api_method = $soap_connect_data[0]["access_token.api_method"];
            $this->param_as_string = $soap_connect_data[0]["access_token.param_as_string"];
            $this->password = crypt_class::decryptString($soap_connect_data[0]["access_token.api_password"]);
            $this->username = $soap_connect_data[0]["access_token.api_username"];
            if($in_uri == "") {$in_uri = $this->base_url;}	
        
            
        
            $this->soap = new SoapClient( 
                null, 
                array( 
                      "location" => $this->base_url,
                      "uri" => $in_uri,
                      "soap_version" => $in_soap_version,
                      "trace" => $in_trace
                     ) 
                );
        
            $feedback = true;
        }
        
        
        return $feedback;
    }
    
    
    
    
    
    /** Ermittelt die Zugriffsdaten, welche über die Maske "Zugangsdaten API's" erfasst wurden.
     * 
     * @param string    $in_access_name         Name der Zugangsdaten
     * @param string    $in_app_id              APP-ID der Zugangsdaten
     * @return array                            
     */
    public function get_access_data($in_access_name, $in_app_id) {
        $condition = "api_name = '".$in_access_name."' and app_id = '".$in_app_id."'";
        $soap_connect_data = getTableData2(global_variables::getAppIdFromSYS01(),
                                           "access_token", 
                                           global_variables::getNameOfDbSchemaSYS01(), 
                                           array(0 => Array("feld.spalte" => "api_username"),1 => Array("feld.spalte" => "api_password"),2 => Array("feld.spalte" => "base_url"),3 => Array("feld.spalte" => "param_as_string"),4 => Array("feld.spalte" => "api_method")), 
                                           false, "", $condition, __FUNCTION__);
        return $soap_connect_data;
    }
    
    
    /** ruft eine bestimmte Zielfunktion per SOAP auf
     * 
     * @param   string  $in_target_function     Funktionsname
     * @param   array   $in_paramlist           Liste aller Parameter/Argumente. Wenn die target-function nur einen String akzeptiert, dann muss dieser dennoch in einem Array "gekapselt" werden.
     * @return  mixed                           Rückgabewert ist abhängig von der aufgerufenen target-function; 
     *                                          Falls ein Fehler auftritt, wird dieser in der debug-Tabelle protokolliert. Rückgabewertist dann false.
     */
    public function soap_call($in_target_function, $in_paramlist) {
        try {
            $result = $this->soap->__soapCall($in_target_function, $in_paramlist);
        } catch (SoapFault $fault) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehler Soap '.$fault->faultcode, $fault->faultstring);
            $result = false;
        }
        return $result;
    }
    
    
    
    
}
