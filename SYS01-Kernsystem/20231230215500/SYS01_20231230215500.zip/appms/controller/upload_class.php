<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

/**
 * Description of upload_class
 *
 * @author Thomas
 */
class fileUpload {
    
    /**
     *
     * @var     string          Name der Datei, inkl. Dateiendung 
     */
    protected $filename;
    
    
    
    
    /**
     *
     * @var     string          absoluter Pfad zur Datei 
     */
    protected $targetpath_abs;
    
    
    /**Diese Klasse managed den Umgang mit hochgeladenen Dateien.
     * Diese können ins Filesystem oder in eine Datenbank hochgeladen werden.
     * 
     */
    public function __construct() {
        
        
        
    }    
    
    
    
    
    /**
     * Diese Methode verschiebt eine hochgeladene Datei an den gewünschten Ort im Filesystem.
     * Die Datei wird geprüft und anschließend an den gewünschten Ort verschoben.
     * Sollte der Zielort noch nicht existieren, wird er erstellt.
     * 
     * @param   string  $in_targetpath                  relativer Pfadname
     * @param   string  $in_allowed_filetype_in_field   Erlaubte Dateiendung, laut Felddefinition. Wenn Leer, dann wird ConfigParameter "upload_allowed_filetypes" genutzt.
     * @param   string  $in_app                         ID, der App, in dessen Kontext dr Upload-Vorgang gestartet wurde.
     * @param   array   $in_currentFile                 Ein FileArray aus $_FILES
     * @throws  Exception                               Feedback-Meldung gemäß konstantentyp_id = 35 [150|-150|-151|-152|-153]
     */
    public function moveFileToFilesystem($in_targetpath, $in_allowed_filetype_in_field, $in_app, $in_currentFile) {
        if($in_allowed_filetype_in_field == "") {$in_allowed_filetype_in_field = getConfig("upload_allowed_filetypes", $in_app);}
        
        $this->targetpath_abs = $in_targetpath;
        //targetpath ggf. anlegen
        if(file_exists($in_targetpath) == false) {
            $permission = global_variables::getDefaultPermissionForFolder();
            mkdir($in_targetpath, octdec($permission), true); 
        }
        
        if ($in_currentFile["error"] == UPLOAD_ERR_OK) {
            $tmp_name = $in_currentFile["tmp_name"];
            // basename() verhindert auch  Directory Traversal Angriffe
            $name = basename($in_currentFile["name"]);
            $this->filename = $name;                        
            If($this->checkFile($name, $in_allowed_filetype_in_field, $in_app) == true) {
                if(move_uploaded_file($tmp_name, $in_targetpath.$name) == true) {
                    setFilePermission($in_targetpath, $name, "upload_class");
                    //Datei wurde erfolgreich hochgeladen und in den Upload-Ordner verschoben
                } else {
                    //Datei konnte nicht in den Zielordner verschoben werden
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Datei nicht gefunden', "Error","ERROR");
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Quelldatei', $tmp_name,"ERROR");
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Zieldatei', $in_targetpath.$name,"ERROR");
                    throw new Exception(-150);          
                }
            } else {
                //Datei hat eine unerlaubte Dateiendung oder ist in der Liste dr verbotenen Dateien enthalten
                throw new Exception(-151);
            }
        } elseif ($in_currentFile["error"] == UPLOAD_ERR_INI_SIZE) {   
            //Datei ist zu groß
            throw new Exception(-153); 
        } else {
            //unspezifischer Fehler

            throw new Exception(-150);          
        }
        
        
        if(count($_FILES) == 0) {
            //Es wurde keine Datei hochgeladen. Wahrscheinlich wurd die zulässige Dateigröße überschritten
            throw new Exception(-152);  
        }
    }
    
    
    
    
    
    /** Speichert die Daten und die Datei in der DB-Tabelle des sendenden Formulars.
     * Wenn eine andere DB-Tabelle genutzt werden soll, dann die Verwendung von pagedata.addUploadedFilesAsBase64ToInsertdata prüfen.
     * 
     * @param   array   $in_file                        Ein file aus der Globalen $_FILES
     * @param   string  $in_allowed_filetype_in_field   Erlaubte Dateiendung, laut Felddefinition. Wenn Leer, dann wird ConfigParameter "upload_allowed_filetypes" genutzt.
     * @param   object  $in_internPostObject
     * @param   integer $in_DsID                        ID des Datensatzes des sendenen Fomulars, der gerade verarbeitet wird.
     * @param   array   $in_datensätze                  Liste der Datensätze des sendenden Formulars 
     * @param   object  $in_pagedata                    Referenz zum pagedata-Objekt
     * @return  integer                                 Fehlermeldung wie bei insert.
     */
    public function moveFileToDatabase($in_file, $in_allowed_filetype_in_field, &$in_internPostObject, $in_DsID, $in_datensätze, &$in_pagedata) {
        $myContent = $in_datensätze[$in_DsID]["content"];
        $app_id = $in_pagedata->getActiveRoleAppIdFromSession();
        
        
        if($in_allowed_filetype_in_field == "") {$in_allowed_filetype_in_field = getConfig("upload_allowed_filetypes", $app_id);}
        
        If($this->checkFile($in_file["name"], $in_allowed_filetype_in_field, $app_id) == true) {
            //Datensatz um weitere Attribute des files ergänzen
            $addContent = $in_pagedata->getFileAttributsToNewData($in_file, "", $in_pagedata->getCurrentRoleFromSession());
            //Neue Attribute zu Newdata ergänzen
            $in_internPostObject->setNewDataContent($in_DsID, array_merge($myContent, $addContent));
            //Daten in DB-Tabelle des sendenden Formulars schreiben
            $feedback = $in_pagedata->internFunction_insertData(true, "file");
        } else {
            $feedback = -151;
        }
        
        return $feedback;
    }
    
    
    
    
    /** Prüft, ob der Dateityp mit der Definition des Feldes übereinstimmt und ob er zu den
     * systemweit erlaubten Dateitypen (siehe Config-Parameter "upload_allowed_filetypes) zählt.
     * Außerdem wird auch geprüft, ob die Datei in der Liste der verbotenen Dateien (Config-Param upload_forbidden_files)
     * enthalten ist.
     * Achtung: Funktion ist leicht manipulierbar. Es müsste auch der Inhalt der Datei geprüft werden.
     * 
     * @param   string      $in_filename                                Name der zu prüfenden Datei (Bsp.: MeineDatei.txt
     * @param   string      $in_allowed_filetype_from_fielddefinition   erlaubte Dateiendung (Bsp.: zip, txt, doc}
     * @param   string      $in_app                                     App-ID, in dessen Kontext die Datei geprüft werden soll.
     * @return boolean
     */
    public function checkFile($in_filename, $in_allowed_filetype_from_fielddefinition, $in_app) {
        $feedback = false;
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> hochgeladene Datei', $in_filename,"INFO");
        //Dateiendung extrahieren
        $current_filetype = str_replace(".","",strrchr($in_filename, "."));
        
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> hochgeladener Dateityp', $current_filetype,"INFO");
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> erlaubte Dateitypen', $in_allowed_filetype_from_fielddefinition,"INFO");
        
        //Prüfen, ob die Datei laut der Upload-Felddefinition zulässig ist
        If(strpos($in_allowed_filetype_from_fielddefinition, $current_filetype) !== false) {
            //Prüfen, ob Dateiendung gemäß dem Config-Parameter zulässig ist
            $allowed_filetype_config = getConfig("upload_allowed_filetypes", $in_app);
            If(strpos($allowed_filetype_config, $current_filetype) !== false) {
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Dateityp ist in Config-Parameter enthalten', $allowed_filetype_config,"INFO");
                //Prüfen, ob die Datei in der Liste der verbotenen Dateien enthalten ist
                $forbidden_files = getConfig("upload_forbidden_files", global_variables::getAppIdFromSYS01());
                If(strpos($forbidden_files, $in_filename) === false) {
                    $feedback = true;
                }
            } 
        } 
        return $feedback;
    }
    
    
    /** Gibt den Namen der letzten hochgeladenen Datei zurück.
     * ToDo: Das funktioniert nur so lange fehlerfrei, wie nur eine Datei hochgeladen wird. Wenn es mehrere sind, wird durch die Schleife in _construct nur die letzte Datei abgelegt.
     * @return  string          Bsp.: myZip.zip
     */
    public function getFilename() {
        return $this->filename;
    }
    
    
    /** Gibt den absoluten Pfad zur Datei zurück.
     * 
     * @return  string          Bsp.: /var/www/html/appms/update/
     */
    public function getPath_abs() {
        return $this->getPath_abs();
    }
    
}
