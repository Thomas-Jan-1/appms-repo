<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

/**
 * Die Klasse stellt Funktionen bereit, welche durch javascript mit Elementen der Oberfläche verbunden werden können.
 * Somit können Daten dynamisch nachgeladen werden.
 * 
 *
 * @author Thomas J.
 */
class functions_ajaxrequest {
    
    function __construct() 
    { 
        
    }
    
    
    
    
    /** Dies ist nur Test-Methode, die zur Demonstration der Einbindung dient. Die Methode kann angesprochen werden,
     * indem in einem beliebigen Formular ein Button integriert wird. Dem Button muss im <br />
     *  Feld "JavaScript-OnKlick" der Wert "showMoreData" und im <br />
     *  Feld "JavaScript-onClick-Parameter" der Wert "event,'SYS01.functions_ajaxrequest.demo'" <br />
     * zugeordnet werden.
     * 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. (Bsp.: <br />
     *                                      Array(
                                                    [0] => Array
                                                        (
                                                            [formID] => 1110
                                                            [fieldAppID] => BIM01
                                                            [fieldID] => 7462
                                                            [fieldContent] => 3
                                                            [domID] => 0fin0k_proj_syf0id0Form1110_1_i0
                                                            [ds] => 1
                                                            [instance] => i0
                                                            [name] => ID
                                                            [spalte] => id
                                                            [db_schema] => fin
                                                            [db_table] => k_proj_syf
                                                            [read_only] => 0
                                                            [senderField] => 
                                                        )

                                                    [1] => Array
                                                        (
                                                            [formID] => 1110
                                                            [fieldAppID] => BIM01
                                                            [fieldID] => 7475
                                                            [fieldContent] => 52118846
                                                            [domID] => 0fin0k_proj_syf0proj0Form1110_1_i0
                                                            [ds] => 1
                                                            [instance] => i0
                                                            [name] => Projekt
                                                            [spalte] => proj
                                                            [db_schema] => fin
                                                            [db_table] => k_proj_syf
                                                            [read_only] => 0
                                                            [senderField] => 
                                                        )
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Diese wurden in feld.js_[xxx]_params hinterlegt. Bsp.: <br />
     *                                      Array
                                                (
                                                    [function_app] => SYS01
                                                    [function_class] => functions_ajaxrequest
                                                    [function_name] => demo
                                                    [targetFieldId] => 7488
                                                )
     * @return  string                      HTML-Code einer Tabelle mit den Differenzen
     */
    public function demo($in_params, $in_function_properties) {
        $senderField = getSenderField($in_params);
        $name = $senderField["fieldContent"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> auslösendes Feld: ', $name);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
        
        return "<div><b>Hallo Welt</b> <br />".
                "übergebener Parameter: ".print_r($in_params,TRUE)."</div>";
        
        
        
        //Beispiel für eine Fehlermeldung
        $feedback = "error:-3101:SYS01";
        //Der Klartext für die Fehlermeldung -101 muss in der Tabelle Konstante unter der Konstantentyp_id = 35 angelegt werden.
        //Warum sollte die Fehlermeldung auf diese Weise erfolgen, statt das der Fehlertext direkt zurückgegeben wird?
        //Auf diese Weise werden Fehlertext gesammelt in einer Datenbanktabelle abgelegt, statt verstreut im Programmcode.
        //Das eröffnet perspektivisch die Möglichkiet der Mehrsprachigkeit der Anwendung.
    }
    
    
    
       
  
    
    
    /** Ermittelt eine tabellarische Darstellung der Workflowsteps, inkl. Status für den aktuellen gewählten Vorgang.
     * 
     * @param   array   $in_field_list          alle Werte der aktuellen Datenzeile
     * @param   array   $in_function_properties Array der aufgerufenen Funktion
     * @return  string                          Rückgabewerte in einer Html-Tabelle eingebettet.
     */
    public function getWorkflowstatus($in_field_list, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_field_list);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
              
        $workflow_id = getValueFromFieldInFieldlistFromAjax($in_field_list, "workflow_id");
        $app_id = getValueFromFieldInFieldlistFromAjax($in_field_list, "app_id");
        $version = getValueFromFieldInFieldlistFromAjax($in_field_list, "version");
        $instance_id = getValueFromFieldInFieldlistFromAjax($in_field_list, "instance_id");
//        
//        //Workflow-Status Datensätze aus workflow_status und workflow_step auslesen. Jeder Step ist mindestens 
        //einmal enthalten. Falls es eine Rückwärtsbewegung im Workflow gab (verursacht durch Ablehnen eines Steps),
        //können manche Steps auch mehrfach enthalten sein. Der letzte Step hat den Status 0, wenn der Workflow noch nicht
        //bageschlossen ist. In dem Fall müssen anschließend aus workflow_step alle noch folgenden Steps ebenfalls noch ausgelesen werden.
        $workflow_step_list_atwork = $this->_getWorflowstatusForInstance($workflow_id, $app_id, $version, $instance_id);
        
        
        //prüfen, ob der Workflow abgeschlossen ist
        $workflow_is_closed = true;
        foreach ($workflow_step_list_atwork as $current_step_array) {
            if($current_step_array[".temp_status"]== 0) {
                $workflow_is_closed = false;
                $current_step = $current_step_array["workflow_step.step"];
            }
        }
        
        //falls der Workflow nicht abgeschlossen ist, dann alle noch folgenden Steps ergänzen.
        if($workflow_is_closed === false) {
            $workflow_step_list_waiting = $this->_getWorflowDefaultSteps($workflow_id, $app_id, $version, $instance_id, $current_step);
            $workflow_step_list = array_merge($workflow_step_list_atwork,$workflow_step_list_waiting);
        } else {
            $workflow_step_list = $workflow_step_list_atwork;
        }
        
        
        $feedback = buildHtmlTableHorizontalQuery($workflow_step_list);
        
        
        return $feedback;
    }
    
    
    
    

    
    
    
    
    /** Ermittelt den Status aller Steps einer Workflow-Instanz
     * 
     * @param   integer     $in_workflow_id     ID des Workflows
     * @param   string      $in_appID           APP-ID des Workflows
     * @param   integer     $in_version         Versionsnummer des Workflows
     * @param   integer     $in_instance_id     Vorgangsummer
     * @return  array                           Array mit allen Steps oder leeres array (array())
     */
    private function _getWorflowstatusForInstance($in_workflow_id, $in_appID, $in_version, $in_instance_id) {
        
//        $role_id = getActiveRoleData()["role.id"];
        $role_id = global_variables::getAppManagerRoleId();
//        $role_app_id = getActiveRoleData()["role.app_id"];
        $role_app_id = global_variables::getAppIdFromSYS01();
        $connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();


        /* Select auf eine beliebige Tabelle */
         $querySelectPart =     "case 
                                        when workflow_status.finished = 1 and workflow_status.back_to_step is null then 'zugestimmt'
                                        when workflow_status.finished = 1 and workflow_status.back_to_step is not null then 'abgelehnt' 
                                        else '-' 
                                 end as status
                                , workflow_step.step 
                                , workflow_step.name as workflowschritt
                                , {{{{function_name=date_format?date=workflow_status.timestamp_edit&format=dd.mm.yyyy - HH:MM:SS}}}} as zeitstempel
                                , concat(workflow_status.editor, '(',account.givenname,')') as bearbeiter
                                , array_agg(role.name) as zugriffsberechtigte_Rollen
                                , workflow_status.wkfl_comment as \"Kommentar\"
                                , workflow_status.email_to 
                                , workflow_status.email_cc 
                                , workflow_status.email_from 
                                , coalesce(workflow_status.finished, 0) as temp_status";

        $queryFromPart =        "manager.workflow_step
                                    inner join manager.workflow_status ON workflow_step.app_id = workflow_status.app_id AND workflow_step.workflow_id = workflow_status.workflow_id AND workflow_step.version = workflow_status.version AND workflow_step.step = workflow_status.step and workflow_status.instance_id = $in_instance_id
                                    left join manager.account ON account.app_id = workflow_status.app_id AND account.id = workflow_status.editor
                                    left join manager.workflow_access ON workflow_step.app_id = workflow_access.app_id AND workflow_step.workflow_id = workflow_access.workflow_id AND workflow_step.version = workflow_access.version AND workflow_step.step = workflow_access.step
                                    left join manager.role ON workflow_access.role_app_id = role.app_id and workflow_access.role_id = role.id";

        $queryWherePart =       "workflow_step.workflow_id = $in_workflow_id
                                    and workflow_step.version = $in_version
                                    and workflow_step.app_id = '$in_appID'";
        
        $queryGroupPart =       "case workflow_status.finished when 1 then 'erledigt' else '' end 
                                    , workflow_step.step 
                                    , workflow_step.name 
                                    , workflow_status.timestamp_edit 
                                    , workflow_status.step
                                    , concat(workflow_status.editor, '(',account.givenname,')') 
                                    , workflow_status.wkfl_comment
                                    , workflow_status.email_to 
                                    , workflow_status.email_cc 
                                    , workflow_status.email_from
                                    , workflow_status.finished
                                    , workflow_status.back_to_step";

        $queryOrderbyPart =     "temp_status DESC, workflow_status.timestamp_edit ASC";


        $queryRequest = new sql_request($connection_id, $role_app_id,$role_id, __FUNCTION__);
        $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $queryGroupPart, $queryOrderbyPart);
        $queryRequest->include_function_placeholder = true;         //notwendig, damit Funktionsplatzhalter db-unabhängig ersetzt wird.
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__,true);
        
        
        //Ergebnismenge umformatieren
        if ($result <> false) {
            $feedback = $result;
        } else {
            $feedback = array();
        }
        

        return $feedback;
    }
    
    
    
    
    
    
    /** Listet alle Defaultsteps eines Workflows ab (nach) $in_start_after_step auf.
     * 
     * @param   integer     $in_workflow_id         ID des Workflows
     * @param   string      $in_appID               APP-ID des Workflows
     * @param   integer     $in_version             Versionsnummer des Workflows
     * @param   integer     $in_instance_id         Vorgangsummer
     * @param   integer     $in_start_after_step    ID des Steps, bis zu dem die Steps nicht ermittelt werden sollen.
     * @return  array                               Array mit allen Steps oder leeres array (array())
     */
    private function _getWorflowDefaultSteps($in_workflow_id, $in_appID, $in_version, $in_instance_id, $in_start_after_step) {
        
        $role_id = global_variables::getAppManagerRoleId();
        $role_app_id = global_variables::getAppIdFromSYS01();
        $connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();


        /* Select auf eine beliebige Tabelle */
         $querySelectPart =     "'-' as status
                                    , workflow_step.step 
                                    , workflow_step.name as workflowschritt
                                    , NULL as timestamp_edit 
                                    , '' as bearbeiter
                                    , array_agg(role.name) as zugriffsberechtigte_Rollen
                                    , '' as \"Hinweis für nächsten Bearbeiter\"
                                    , '' as email_to 
                                    , '' as email_cc 
                                    , '' as email_from 
                                    , 0 as temp_status";

        $queryFromPart =        "manager.workflow_step
                                    left join manager.workflow_access ON workflow_step.app_id = workflow_access.app_id AND workflow_step.workflow_id = workflow_access.workflow_id AND workflow_step.version = workflow_access.version AND workflow_step.step = workflow_access.step
                                    left join manager.role ON workflow_access.role_app_id = role.app_id and workflow_access.role_id = role.id";

        $queryWherePart =       "workflow_step.workflow_id = $in_workflow_id
                                    and workflow_step.version = $in_version
                                    and workflow_step.app_id = '$in_appID'
                                    and workflow_step.step > $in_start_after_step";
        
        $queryGroupPart =       "workflow_step.step 
                                    , workflow_step.name";

        $queryOrderbyPart =     "workflow_step.step";


        $queryRequest = new sql_request($connection_id, $role_app_id,$role_id, __FUNCTION__);
        $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $queryGroupPart, $queryOrderbyPart);
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__,true);
        
        
        //Ergebnismenge umformatieren
        if ($result <> false) {
            $feedback = $result;
        } else {
            $feedback = array();
        }
        

        return $feedback;
    }
    
    
    
    
    
    
    
    
    
    /** Nimmt den aktuellen Inhalt ( String) des sendenden Feldes und entfernt alle Zeichen, die in einem Feldnamen nicht enthalten sein dürfen.
     * 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Bsp.: siehe demo-Methode
     * @return  string                      HTML-Code einer Tabelle mit den Differenzen
     */
    public function buildAllowedFieldnames($in_params, $in_function_properties) {
        $senderField = getSenderField($in_params);
        $name = $senderField["fieldContent"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> zu prüfender Feldname: ', $name);
        
        $forbidden_values = array(".", "<", ">", ";");
        $new_name = str_ireplace($forbidden_values, "", $name);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> geänderter Feldname: ', $new_name);
        
        //Rückgabewerte für ajax-Feedback setzen
        $targetField = $in_function_properties["targetFieldId"];
        $feedback = prepareFeedbackForAjaxReqValueForField($targetField, $new_name, $in_params);    
        
        return $feedback;
    }
    
    
    
    
    
    
    /** Die Funktion prüft, ob der übergebene Wert den formalen Vorschriften für eine APP-ID entspricht.
     * D.h., nur Großbuchstaben und Ziffern von 1-9.
     * 
     * 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  der aktuellen
     *                                      Datenzeile enthalten. Der Aufbau des Array ist in der Beschreibung von functions.addMetadataToFields enthalten.
     * @return  string                      Meldung, ob bereits ein Datensatz mit dem gewählten Jahr existiert. 
     *                                      Bsp.: "error|||1_____message|||In der APP-ID <b>Paul</b> sind unerlaubte Zeichen vorhanden. <br />Bitte verwenden Sie nur Großbuchstaben und Ziffern von 1-9. Das erste Zeichen soll ein Buchstabe sein. <br />Zudem muss die APP-ID genau 5 Zeichen lang sein._____target_field|||7995_____deactivate_submitbutton|||1_____target_domID|||0manager0app0id0Form1228_0_i0new_____formID|||1228_____instanceID|||i0new"
     */
    public function checkIfAllowedAppId($in_params, $in_function_properties) {
        $senderField = getSenderField($in_params);
        $app_id = $senderField["fieldContent"];
        $targetField = $in_function_properties["targetFieldId"];
        
        
        
        if(preg_match('/^[A-Z1-9]+$/', $app_id) AND strlen($app_id)==5){
            //Nur Großbuchstaben und die Ziffern 1-9 sind erlaubt.
            $feedback = prepareFeedbackForAjaxReqCheckValueOfAField(false, "ok", $targetField, $senderField["domID"], $senderField["formID"], $senderField["instance"]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> in App-ID sind nur erlaubte Zeichen enthalten: ', $app_id);
        } else {
            $message = "In der APP-ID <b>".$app_id."</b> sind unerlaubte Zeichen vorhanden. <br />".
                       "Bitte verwenden Sie nur Großbuchstaben und Ziffern von 1-9. Das erste Zeichen soll ein Buchstabe sein. <br />Zudem muss die APP-ID genau 5 Zeichen lang sein.";
            $feedback = prepareFeedbackForAjaxReqCheckValueOfAField(true, $message, $targetField, $senderField["domID"], $senderField["formID"], $senderField["instance"]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> in App-ID sind unerlaubte Zeichen enthalten: ', $app_id);
        }
        
       
        
        return $feedback;
    }
    
    
    
    
    /** überträgt den aktuellen Inhalt von sourceField nach targetField
     * 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Bsp.: siehe demo-Methode
     * @return  string                      HTML-Code einer Tabelle mit den Differenzen
     */
    public function pushValueField1ToField2($in_params, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
        
        $valueFromSourceField = $in_params[$in_function_properties["sourceFieldId"]]["fieldContent"];
        
        //Rückgabewerte für ajax-Feedback setzen
        $targetField = $in_function_properties["targetFieldId"];
        $feedback = prepareFeedbackForAjaxReqValueForField($targetField, $valueFromSourceField, $in_params);    
        
        return $feedback;
    }
    
    
    
    /** Setzt in abhängigen Input-Feldern die Werte, welche in field_depends_input definiert sind, wenn eine Änderung in einem Trigger-Feld erfolgt.
     * 
     * @param   array   $in_field_list      Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. 
     *                                      Diese Methode kann bspw. wie folgt aufgerufen werden: event,'SYS01.functions_ajaxrequest.setConstantInField2.const.umgesetzt.targetFieldId.10338.targetFieldUser.10340.targetFieldTime.10343'
     *                                      D.h., es können vier Parameter enthalten sein:
     *                                      const               => [optional] enthält die Konstante, die gesetzt werden soll.
     *                                      targetFieldId       => [optional] FeldID, in das die Konstante eingetragen werden soll
     *                                      targetFieldUser     => [optional] FeldID, in das der angemeldete user eingetragen werden soll
     *                                      targetFieldTime     => [optional] FeldID, in das der Zeitstempel eingetragen werden soll.
     * @return  string                      Liste der Feldvorbelegungen, die von loadDependingData interpretiert werden kann.
     */
    public function setValueForDependingInputField($in_field_list, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_field_list);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
        
        
        //Triggerfield ermitteln
        $senderField = getSenderField($in_field_list);
        $fieldContent = $senderField["fieldContent"];
        $formID = $senderField["formID"];
        $appID = $senderField["fieldAppID"];
        $fieldID = $senderField["fieldID"];
        $instance = $senderField["instance"];
        $ds = $senderField["ds"];
        $kernelSchema = global_variables::getNameOfDbSchemaSYS01();
        $connection = global_variables::getConnectionIdOfDbSchemaSYS01();
        //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> senderFieldArray: ', $senderField);
        
        
        //Value für TargetFields aus DB-table field_depends_input ermittel
        $condition = "app_id = '".$appID."' and form_id = ".$formID." and triggerfield_id = ".$fieldID." and triggervalue = '".$fieldContent."'";
        $depending_fields= getTableData($connection, "field_depends_input", $kernelSchema, false, "", $condition, __FUNCTION__);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> dependingFields: ', $depending_fields);
        
        //Rückgabewerte für mehrere Felder als ajax-Feedback setzen
        $delimiter = global_variables::getDelimiterFieldAttribut();
        $temp_array = array();
        foreach ($depending_fields as $cur_depending_field) {
            $temp_array[]=$cur_depending_field["field_depends_input.targetfield_id"].$delimiter.$cur_depending_field["field_depends_input.targetvalue"];
            if($senderField["read_only"] == 1) {
                //bei geschützten Feldern, muss der neue Wert auch im SessionBackup hinterlegt werden.
                $this->_setNewDataForSecureFieldsInSessionBackup($formID, $instance, $ds, $this->_getDomIdFromFieldlist($in_field_list, $cur_depending_field["field_depends_input.targetfield_id"]), $cur_depending_field["field_depends_input.targetvalue"]);
            }
                
        }
         
        $feedback = implode(global_variables::getdelimiterFields(), $temp_array);
        
        return $feedback;
    }
    
    
    
    
    /** Setzt eine Konstante in ein Ziel-Feld ein
     * 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Bsp.: siehe demo-Methode
     * @return  string                      HTML-Code einer Tabelle mit den Differenzen
     */
    public function setConstantInField($in_params, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
        
        
        //Rückgabewerte für ajax-Feedback setzen
        $constant = $in_function_properties["const"];
        $targetField = $in_function_properties["targetFieldId"];
        $feedback = prepareFeedbackForAjaxReqValueForField($targetField, $constant, $in_params);    
        
        return $feedback;
    }
    
    
    
    
    
    /** Trägt eine Konstante in ein bestimmtes Feld ein. Dabei können auch der aktuelle User und ein Zeitstempel gesetzt werden.
     * 
     * 
     * @param   array   $in_field_list      Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. 
     *                                      Diese Methode kann bspw. wie folgt aufgerufen werden: event,'SYS01.functions_ajaxrequest.setConstantInField2.const.umgesetzt.targetFieldId.10338.targetFieldUser.10340.targetFieldTime.10343'
     *                                      D.h., es können vier Parameter enthalten sein:
     *                                      const               => [optional] enthält die Konstante, die gesetzt werden soll.
     *                                      targetFieldId       => [optional] FeldID, in das die Konstante eingetragen werden soll
     *                                      targetFieldUser     => [optional] FeldID, in das der angemeldete user eingetragen werden soll
     *                                      targetFieldTime     => [optional] FeldID, in das der Zeitstempel eingetragen werden soll.
     * @return  string                      Liste der Feldvorbelegungen, die von loadDependingData interpretiert werden kann.
     */
    public function setConstantInField2($in_field_list, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_field_list);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
 
        
        $delimiter = global_variables::getDelimiterFieldAttribut();
        $first_element = array_key_first($in_field_list);
        $form_id = $in_field_list[$first_element]["formID"];
        $instance = $in_field_list[$first_element]["instance"];
        $ds = $in_field_list[$first_element]["ds"];
            
        
        //Konstante setzen
        if(isset($in_function_properties["targetFieldId"])) { 
            $temp_array[]=$in_function_properties["targetFieldId"].$delimiter.$in_function_properties["const"];
            $this->_setNewDataForSecureFieldsInSessionBackup($form_id, $instance, $ds, $this->_getDomIdFromFieldlist($in_field_list, $in_function_properties["targetFieldId"]), $in_function_properties["const"]);
        }
        
        //Account-ID / User setzen
        if(isset($in_function_properties["targetFieldUser"])) { 
            $user = session_class::$session_object->getUid();
            $temp_array[]=$in_function_properties["targetFieldUser"].$delimiter.$user;
            $this->_setNewDataForSecureFieldsInSessionBackup($form_id, $instance, $ds, $this->_getDomIdFromFieldlist($in_field_list, $in_function_properties["targetFieldUser"]), $user);
        }
        
        //Timestamp setzen
        if(isset($in_function_properties["targetFieldTime"])) { 
            $time_stamp = date("Y-m-d\TH:i:s");
            $temp_array[]=$in_function_properties["targetFieldTime"].$delimiter.$time_stamp;
            $this->_setNewDataForSecureFieldsInSessionBackup($form_id, $instance, $ds, $this->_getDomIdFromFieldlist($in_field_list, $in_function_properties["targetFieldTime"]), $time_stamp);
        }
        
        
                
        $feedback = implode(global_variables::getdelimiterFields(), $temp_array);
            

        
        
        return $feedback;
    }
    
    
    
    
    
    /** Ermittelt aus der Felderliste, welche übergeben wird, Die Dom-ID des gesuchten Feldes
     * 
     * @param   array       $in_field_list      Liste aller Felder des aktuellen Datensatzes
     * @param   integer     $in_search_field    ID des gesuchten Feldes
     * @return  mixed       ID des Feldes im Html-Dom oder false, wenn das Feld nicht gefunden werden konnte.
     */
    protected function _getDomIdFromFieldlist($in_field_list, $in_search_field) {
        foreach ($in_field_list as $key => $current_field) {
            if($current_field["fieldID"] == $in_search_field) {return $current_field["domID"];}
        }
        
        //Wenn nichts gefunden wird, dann wird false zurückgegeben
        return false;
    }
    
    
    
    
    /** Hinterlegt den Wert eines Feldes einer Datarow in der Formulereigenschaft [$in_formID]["form.instances"][$in_instance_id]["valuesSecureFields"]
     * 
     * @param integer   $in_formID          ID des Formulars
     * @param string    $in_instance_id     ID der Instanz des Formulars
     * @param integer   $in_datarow         Nummer der Datenzeile
     * @param integer   $in_fieldId         DomID des Feldes
     * @param string    $in_value           Wert, des Feldes
     */
    protected function _setNewDataForSecureFieldsInSessionBackup($in_formID, $in_instance_id, $in_datarow, $in_fieldId, $in_value) {
        
        session_class::$session_object->setSecureValue($in_formID, $in_instance_id, $in_datarow, $in_fieldId, $in_value);

    }
    
    
    /**
     * Ermittelt für einen übergebenen Account die zugehörige APP-ID.
     * Wenn für einen gegeben Account nur eine App verfügbar ist, wird diese an eine targetField zurückgegeben.
     * Wenn der Account in mehreren APP's existiert wird "chooseOneApp" zurückgegeben.
     * Wenn der Account in keiner APP existiert, dann wird "noAppFound" zurückgegeben 
     * Bsp.: Funktionsaufruf <br />
     * 'SYS01.functions_ajaxrequest.getAppByAccount.accountFieldId.387.targetFieldId.7560'
     * 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Bsp.: siehe demo-Methode
     * @return  string                      HTML-Code einer Tabelle mit den Differenzen
     */
    public function getAppByAccount($in_params, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
        
        $account = $in_params[$in_function_properties["accountFieldId"]]["fieldContent"];
        
        $redirect_array = session_class::$session_object->getRedirect();
        if($redirect_array !== false) {
            //Wenn ein Direktaufruf einer Maske vorliegt, dann App-ID der Target-Maske ermitteln
            $new_value = $redirect_array["request_appid"];
        } else {
        
            //App-ID's des Accounts ermitteln
            $condition = "id = '".$account."'";
            $appId_list = getTableData(global_variables::getConnectionIdOfDbSchemaSYS01(), "account", global_variables::getNameOfDbSchemaSYS01(), 1, "app_id", $condition, __FUNCTION__);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> app_list: ', $appId_list);



            if(count($appId_list) == 0 ) {
                //der Account wurde nicht gefunden
                $new_value = "noAppFound";
            } elseif(count($appId_list) == 1 ) {
                //der Account existiert in genau einer APP
                $new_value = $appId_list[0]["account.app_id"];
            } else {
                //Der Account existiert in verschiedenen App's
                $new_value = "chooseOneApp";
            }
        }
        
        //Rückgabewerte für ajax-Feedback setzen
        $targetField = $in_function_properties["targetFieldId"];
        $feedback = prepareFeedbackForAjaxReqValueForField($targetField, $new_value, $in_params);    
        
        return $feedback;
    }
    
    
    
    
    
    
    
    
    
    
    /**
     * Ermittelt für ein DB-Schema die APP-ID mit Hilfe der Tabelle app_schema.
     * 
     * Bsp.: Funktionsaufruf <br />
     * 'SYS01.functions_ajaxrequest.getAppBySchema.schemaFieldId.387.targetFieldId.7560'
     * 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Bsp.: siehe demo-Methode
     * @return  string                      HTML-Code einer Tabelle mit den Differenzen
     */
    public function getAppBySchema($in_params, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
        
        $db_schema = $in_params[$in_function_properties["schemaFieldId"]]["fieldContent"];
        $connectionId_from_Kernel = global_variables::getConnectionIdOfDbSchemaSYS01();
        $schema_from_kernel = global_variables::getNameOfDbSchemaSYS01();
        
        
        If (is_string($db_schema)) {           
            //App_id aus Tabelle app_schema auslesen
            $condition = "db_schema='".$db_schema."'";
            $appBySchema = getDataFromTableByID($connectionId_from_Kernel, $schema_from_kernel, "app_schema", "app_id", $condition);
            
            
        } else {
            //Es konnte kein Schema-Wert erkannt werden.
            $appBySchema = false;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Für diese Condition konnte keine App-ID/Connection-ID ermittelt werden (".$condition.")", "ERROR");
        
        }
        
        //Rückgabewerte für ajax-Feedback setzen
        $targetField = $in_function_properties["targetFieldId"];
        $feedback = prepareFeedbackForAjaxReqValueForField($targetField, $appBySchema, $in_params);    
        
        return $feedback;
    }
    
    
    
    
    
    
    
    /**
     * 
     * @param   array   $in_field_list      Liste aller Felder des aktuellen Datensatzes
     * @return  type
     */
    public function checkDbConnection($in_field_list) {
        require_once("../controller/model/db_connection_handler_class.php");
        
        $dbms = extractFieldvalueFromRow($in_field_list, "spalte", "dbms");
        $host = extractFieldvalueFromRow($in_field_list, "spalte", "host");
        $port = extractFieldvalueFromRow($in_field_list, "spalte", "port");
        $db = extractFieldvalueFromRow($in_field_list, "spalte", "dbname");
        $user = extractFieldvalueFromRow($in_field_list, "spalte", "user");
        $password = extractFieldvalueFromRow($in_field_list, "spalte", "password");
        $encoding = extractFieldvalueFromRow($in_field_list, "spalte", "encoding");
        
        
        
        $check = db_connection::checkConnection($dbms, $host, $port, $db, $user, $password, $encoding);
        
        if ($check["status"] == true) {
            $feedback = "<div><b>Success</b> <br />".
                $check["reason"]."</div>";
        } else {
            //HINWEIS: Wenn php_error_reporting an ist, dann schlägt die Rückmeldung, aufgrund unerlaubter Zeichen, fehl.
            $feedback = "<div><b>Error</b> <br />".
                $check["reason"]."</div>";
        }
        return $feedback;
        
    }
    
    
    
    /**
     * Gibt die aktuelle Zeit im Format "YYYY:MM:DD hh:mm:ss" zurück
     * Bsp.: Funktionsaufruf <br />
     * 'SYS01.functions_ajaxrequest.getCurrentTimestamp.targetFieldId.7560'
     * 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Bsp.: siehe demo-Methode
     * @return  string                      HTML-Code einer Tabelle mit den Differenzen
     */
    public function getCurrentTimestamp($in_params, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
        
        
        
        $date = new DateTime;
        $new_value = $date->format('Y-m-d H:i:s');
        
        
        
        //Rückgabewerte für ajax-Feedback setzen
        $targetField = $in_function_properties["targetFieldId"];
        $feedback = prepareFeedbackForAjaxReqValueForField($targetField, $new_value, $in_params);    
        
        return $feedback;
    }
    
    
    /**
     * Gibt die des aktuell angemeldeten Users  zurück
     * Bsp.: Funktionsaufruf <br />
     * 'SYS01.functions_ajaxrequest.getCurrentUserId.targetFieldId.7560'
     * 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Bsp.: siehe demo-Methode
     * @return  string                      HTML-Code einer Tabelle mit den Differenzen
     */
    public function getCurrentUserId($in_params, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
        
        
        
        $new_value = session_class::$session_object->getUid();
        
        
        //Rückgabewerte für ajax-Feedback setzen
        $targetField = $in_function_properties["targetFieldId"];
        $feedback = prepareFeedbackForAjaxReqValueForField($targetField, $new_value, $in_params);    
        
        return $feedback;
    }
    
    
    
    /**
     * Gibt eine Meldung entsprechend der Konstantenliste (ID = 35) aus der DB-Tabelle "konstante" zurück.
     * Bsp.: Funktionsaufruf <br />
     * 'SYS01.functions_ajaxrequest.getUserFeedback.SYS01.100'   -> Gibt die Usermeldung mit dem Wert 100 aus der Tabelle konstante zurück
     * 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Bsp.: siehe demo-Methode
     * @return  string                      HTML-Code einer Tabelle mit den Differenzen
     */
    public function getUserFeedback($in_params, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);

        $feedback = "message";

        return $feedback;
    }
    
    
    
    /** Ermittelt eine HTML-Tabelle, welche alle Datensätze enthält, die zu den Kriterien passen, welche in der aktuellen Sucher erfasst wurden.
     * Dabei sind alle übergebenen Spalten (Parameterliste) auch in der Rückgabeliste/-tabelle enthalten.
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Bsp.: siehe demo-Methode 
     * @return  string                      HTML-Code einer Tabelle mit allen Feldern/Spalten, die in $in_params enthalten waren.
     */
    public function getDynamicSearchResult($in_params, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
        
        $first_key = array_key_first($in_params);
        $form_id = $in_params[$first_key]["formID"];
        
        //Suchergebnisse ermitteln
        $search_result = getDynamicSearchResultfromDB($form_id, $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Query_data: ', $search_result);
        
        if(count($search_result) > 0) {
            //Suchergebnisse den Feldern zuordnen
            $Metadata_with_searchResult = addDataToMetadata($search_result, $in_params);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Metadaten mit Datensätzen: ', $Metadata_with_searchResult);

            //Daten in HTML-Syntax aufbereiten
            $SearchResult_formated = changeAjaxQueryresultToNormalArray($Metadata_with_searchResult);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Datensätze formatiert: ', $SearchResult_formated);
        
            $feedback = buildHtmlTableHorizontal($SearchResult_formated);
        } else {
            $feedback = getConfig("note_if_filter_found_no_data", global_variables::getAppIdFromSYS01());
            $feedback = "<div class=\"no_search_result\">".$feedback."</div>";
        }
        
        
        return $feedback;
    }
    
    
    
    
    /** Ermittelt zu einem Datensatz den Wert einer bestimmten Spalte. Die Spalte muss entweder in der Tabelle oder in der Query,
     * die dem Formular zu Grunde liegt, enthalten sein.
     * 
     * Bsp. Aufruf-Parameter:               event,'SYS01.functions_ajaxrequest.getMoreDataFromSingleRow.column.description' 
     * 
     * @param   array   $in_params          Parameterliste; Diese wird von chooseAjaxFunction aufgebaut. Es sind alle Felder, inkl. values,  <br/>
     *                                      der aktuellen Datenzeile enthalten. Außerdem wird das Ereignis-auslösende Feld (senderField) gekennzeichnet. 
     *                                      Bsp.: siehe demo-Methode
     * @param   $in_function_properties     enthält Daten zum Funktionsaufruf. Bsp.: siehe demo-Methode 
     *    
     * @return  string                      HTML-Code einer Tabelle mit allen Feldern/Spalten, die in $in_params enthalten waren.
     */
    public function getMoreDataFromSingleRow($in_params, $in_function_properties) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameterliste: ', $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion: ', $in_function_properties);
        
        $first_key = array_key_first($in_params);
        $form_id = $in_params[$first_key]["formID"];
        
        //Suchergebnisse ermitteln
        $search_result = getDynamicSearchResultfromDB($form_id, $in_params);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Query_data: ', $search_result);
        
        if(count($search_result) > 0) {
            //searchcolumn
            if(isset($in_function_properties["column"])) {
                $searchcolumn = $in_function_properties["column"];
            } else {
                $searchcolumn = false;
            }
            
            //Value der gesuchten Spalte aus der Ergebnisliste ermitteln
            if($searchcolumn !== false) {
                $column_in_result = issetKeyLike($search_result[0], $searchcolumn);
                if($column_in_result !== false) {
                    $feedback = $search_result[0][$column_in_result];
                } else {
                    $feedback = getConfig("note_if_failure_in_form_js_def", global_variables::getAppIdFromSYS01())." Vermutlich wurde der Parameter column falsch angegeben.";
                }
            }
            
            
        } else {
            $feedback = getConfig("note_if_filter_found_no_data", global_variables::getAppIdFromSYS01());
            $feedback = "<div class=\"no_search_result\">".$feedback."</div>";
        }
        
        
        return $feedback;
    }
    
    
    
    
}
