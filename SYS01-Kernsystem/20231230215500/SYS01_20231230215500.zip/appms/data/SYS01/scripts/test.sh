/bin/ls -la >>/var/www/html/appms/data/SYS01/scripts/test_result.txt
