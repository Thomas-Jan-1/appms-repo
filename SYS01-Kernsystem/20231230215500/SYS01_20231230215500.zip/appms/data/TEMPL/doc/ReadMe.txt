Datei: ReadMe.txt im Verzeichnis ../data/%APP_ID%/doc/
Autor: info@appms-it.de
Stand: 24.11.2018
------------------------------------------------------

Diese Datei bzw. dieser Ordner ist f�r anwendungsbezogene Dokumentationen gedacht.
D.h. alle Erl�uterungen, die sich auf eine bestimmte APP_ID beziehen
sind hier abzulegen.



