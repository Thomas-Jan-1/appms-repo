<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

/**
 * Die Klasse stellt Funktionen zum erstellen und verwalten von Applikationen bereit.
 *
 * @author Thomas
 */
class app {
    
    /**
     *
     * @var     object      Referenz auf das pagedata-object 
     */
    protected $pagedata;
    
    /**
     * 
     * @var string
     */
    protected $app_id;
    
    /**
     * 
     * @var string
     */
    protected $name;
    
    /**
     * 
     * @var string
     */
    protected $description;
    
    /**
     * 
     * @var string
     */
    protected $db_schema;
    
    /**
     * 
     * @var string
     */
    protected $logo;
       
    
    /** Die Klasse stellt Funktionen zum erstellen und verwalten von Anwendungen (APP's) bereit.
     * 
     * @param   object  $in_pagedata        Referenz zum pagedata_object
     * @param   int     $in_app_id          ID der APP
     */
    public function __construct(&$in_pagedata, $in_app_id) { 
        require_once("../controller/installer_class.php");
        $this->pagedata = $in_pagedata;
        $this->app_id = $in_app_id ;
    }
    
    
    
    
    
    /** Löscht die APP und damit alle Datensätze aus abhängige Tabellen.
     * 
     * @return  int                             [3|-3|-31] -> [succes|error] -> Fehlerdetails werden in die Debug-Tabelle geschrieben.
     */
    public function deleteAPP() {
        $schema_kernel = global_variables::getNameOfDbSchemaSYS01();
        

        //SQL-Array für Löschbefehl aufbauen
        $sql_daten["schema"] = $schema_kernel;
        $sql_daten["table"] = "app";
        $sql_daten["where"] = "id='".$this->app_id."'";
        $sql_daten['logdata_id_data'] = $this->app_id;
        $sql_daten["logdata"] = "APP ".$this->app_id." inkl. aller abhängiger  gelöscht";

        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = true;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();
        $dummy_form['form.log_id_spalte'] = "id";
        $dummy_form['form.name'] = "APP-Grunddaten";

        $feedback = deleteData($sql_daten, $dummy_form, $this->pagedata->getSessionArray()["uid"], $this->pagedata);
        
        
        //data-Verzeichnis löschen
        
        
        return $feedback;
    }
    
    
    
    
    
    
    
    /** Legt eine neue App mit allen notwendigen Daten (app, app_schema, user, usw.) an.
     * ACHTUNG: Methode ist noch nicht fertig programmiert.
     * 
     * @param   string  $in_name                    Name der App; Es werden nur Buchstaben, Zahlen, Umlaute und ß zugelassen
     * @param   string  $in_description             Beschreibung dr App
     * @param   string  $in_db_schema               initiales DB-Schema, welches in der Tabelle app_schema angelegt werden soll-
     * @param   string  $in_db_schema_extern        Gibt an, ob das DB-Schema extern administriert wird.
     * @param   string  $in_logo                    [optional] Name der Logo-Datei. Default = logo.png
     * @throws Exception
     */
    public function addNewAPP($in_name, $in_description, $in_db_schema, $in_db_schema_extern, $in_dbms, $in_host, $in_port, $in_dbname, $in_user, $in_password, $in_logo = "logo.png") {
        $this->name = preg_replace ( '/[^a-zA-Z0-9äÄöÖüÜß ()-]/i', '', $in_name);
        $this->description = $in_description;
        $kernel_app_id = global_variables::getAppIdFromSYS01();
        $directory_id = global_variables::getInternDirectoryId();
        $install_path = global_variables::getPathForAppmsinstall_abs(false);
        $dir_sep = global_variables::getDirectorySeparator();
        $dir_templ = global_variables::getNameOfTemplateInDatafolder();
        $dir_wiki = global_variables::getNameOfWikiDir();
        $dir_permissions = global_variables::getDefaultPermissionForFolder();



        //App anlegen
        $feedback_app = setNewApp($this->pagedata, $this->app_id, $in_name, $in_description, $in_logo);
        
        if($feedback_app === true) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "APP angelegt: ".$this->app_id);
            //Schema ergänzen (+)
            $feedback_schema = $this->addNewAppschema($in_db_schema, $in_db_schema_extern);
        
        
        
        
            //Default-User anlegen (root und admin)
            //setNewAcoount (+)
                $root = strtolower($this->app_id)."root";
                $feedback_user = setNewAccount($this->pagedata, $this->app_id, $root, $kernel_app_id, $directory_id, strtolower($this->app_id)."%Passwort!", "Root", "", "Entwickleraccount der App", "", "", "", 0);
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Nutzer angelegt: ".$root);
                
                $admin = strtolower($this->app_id)."admin";
                $feedback_user = setNewAccount($this->pagedata, $this->app_id, $admin, $kernel_app_id, $directory_id, strtolower($this->app_id)."%Passwort!", "Admin", "", "fachlicher Admin der App", "", "", "", 1);
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Nutzer angelegt: ".$admin);
            
            

            //Fachadmin-Rolle anlegen (+)
                $rold_id = setNewRole($this->pagedata, $this->app_id, $this->app_id."-Admin");
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Rolle angelegt, ID: ".$rold_id);
                
            //Masken der Rolle zuordnen (+)
            //Startmaske
                $start_mask_id = global_variables::getDefaultMaskId($kernel_app_id, "start_mask");
                $feedback_startmask = setRoleAccessToMask($this->pagedata, $this->app_id, $rold_id, $kernel_app_id, $start_mask_id, 1, 0, 0, 0, 1);
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Startmaske der Rolle zugeordnet, Mask-ID: ".$start_mask_id);

            //Default-Rollen und Fachadmin-Rolle zuordnen (+)
            //setNewAcoountHasRole
                $feedback_account = setNewAcoountHasRole($this->pagedata,$this->app_id,$root,$kernel_app_id, global_variables::getRootRoleInKernel());
                $feedback_account = setNewAcoountHasRole($this->pagedata,$this->app_id,$admin,$kernel_app_id, global_variables::getRootRoleInKernel(), 1);
                $feedback_account = setNewAcoountHasRole($this->pagedata,$this->app_id,$admin,$this->app_id, $rold_id, 1);
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Rollen den Accountszugeordnet: ".$feedback_account);
                
            //data-Verzeichnis anlegen (+)
                $source_path = $install_path.global_variables::getPathForData_rel().$dir_templ;
                $target_path = $install_path.global_variables::getPathForData_rel().$this->app_id;
                $feedback_copy = folder_copy($source_path, $target_path, global_variables::getDefaultPermissionForFolder(), true);
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Data-Verzeichnis kopiert: ".$target_path);
                
            //config-Datei anlegen (+)
                $target_path_config = $target_path.$dir_sep.global_variables::getNameOfConfigInDatafolder().$dir_sep;
                $my_installer = new installer();
                $feedback_config = $my_installer->createNewConfigXml(   
                        $target_path_config, 
                        "config_default.xml", 
                        global_variables::getNameOfConfigFile(), 
                        $this->app_id, 
                        $in_dbms, 
                        $in_host,
                        $in_port, 
                        $in_dbname, 
                        $in_user, 
                        $in_password, 
                        "");
                
                
            //Wiki-Startseite anlegen 
                //mkdir ../appms/wiki/data/pages/[app_id]/
                $target_path = $install_path.$dir_wiki.$dir_sep."data".$dir_sep."pages".$dir_sep.strtolower($this->app_id);
                mkdir($target_path, octdec($dir_permissions), true); 
                
                //Datei anlegen ../appms/wiki/data/pages/[app_id]/start.txt
                $content = "====== ".$this->app_id." ====== \n".
                           "Ergänzen Sie hier den Hilfebereich für die Applikation.";
                writeFile($target_path.$dir_sep, "start.txt", $content);
                
                //Wiki-User anlegen
                $target_path_wikiconf = $install_path.global_variables::getPathForWikiconf_rel();
                $content = strtolower($this->app_id).'root'.':$2y$10$jBYU2vJkpRrjCo7wNyGJbOnO/KRrkCY63MtxT0ZP8fa8mI3fK0eJO:Wiki-Redakteur:wiki@example.com:user';
                appendFile($target_path_wikiconf, "users.auth.php", $content);
                
                
                
                
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "APP konnte nicht angelegt werden!", "ERROR");
            throw new Exception(-2001);
        }
        

    }
    
    
    
    
    
    
    /** Ergänzt ein DB-Schema zur APP
     * 
     * @param   string  $in_schema_name             Name, der verwendet werden soll
     * @param   integer $in_extern_administrated    Kennzeichen, ob Schema extern administriert wird
     * @return  boolean
     */
    public function addNewAppschema($in_schema_name, $in_extern_administrated) {
        $feedback = setNewAppschema($this->pagedata, $this->app_id, $in_schema_name, $in_extern_administrated);
        if($feedback === true) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "DB-Schema ".$in_schema_name." wurde angelegt");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "DB-Schema ".$in_schema_name." konnte nicht angelegt werden.", "ERROR");
        }
        
        return $feedback;
    }
    
    
    
    
}
