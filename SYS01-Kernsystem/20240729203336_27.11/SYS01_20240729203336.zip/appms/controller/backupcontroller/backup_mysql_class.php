<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


/** Für jede DB-spezifische-KLasse muss ein eigener Namespace definiert werden (virtueller Ordner).
 * Der Namespace muss der Dateinamekonvention folgen und er muss mit dem gewählten Namespace in der zugehörigen
 * backup-Klasse übereinstimmen.
 * 
 * Bsp. für Postgres:
 * 
 * DBMS = postgresql
 * Dateiname für die DB-spezifischen Klassen = backup_postgresql_class.php
 * namespace = postgresql
 * Eintrag in konstantenkatalog (konstantentyp_id = 50) = postgresql
 */
namespace mysql;


/** Jede DB-spezifische-Klasse sollte von der namensgleichen Klasse in 
 * backup_universal_class.php erben, sodass der Anpassungsaufwand dauerhaft minimal bleibt.
 * 
 */
//require_once("backup_universal_class.php");
require_once("backup_universal_class.php");

/**
 * Alle Datenbankspezifischen Eigenschaften und Funktionen. Die Klasse erbt von 
 * backupTabele_universal.
 */
class backupTable extends \backupTable_universal {
    
    
    
    /**     Ermittelt alle Columns der Tabelle und wichtige Eigenschaften dieser. Die Column-Eigenschaften werden in Objekten vom Typ backupColumn gespeichert. 
     * 
     * @return  array                                   Zweidimensionales Array mit allen Spalten der aktuellen Tabelle. Pro Column werden folgende Merkmale zurück gegeben: 
     *                                                  columns.table_name 
                                                        , columns.column_name 
                                                        , columns.table_schema 
                                                        , columns.is_nullable 
                                                        , columns.data_type 
                                                        , columns.character_maximum_length
                                                        , columns.ordinal_position
                                                        , columns.column_default    //enthält in postgres die nextval-Eigenschat
                                                        , columns.extra             //enthält in mysql die autoincrement-Eigenschaft
     */
    function getColumnlist() {
        $db_schema_information = \global_variables::getNameOfDbSchemaInformation(); 
        $table = $this->name;
        $schema = $this->_schema;
        $connection_id = $this->_connection_id;
        
        
        
        $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("columns", "table_name");
            $queryRequest->addSelectColumn("columns", "column_name");
            $queryRequest->addSelectColumn("columns", "table_schema");
            $queryRequest->addSelectColumn("columns", "is_nullable");
            //$queryRequest->addSelectColumn("columns", "data_type", "data_type");
            $queryRequest->addSelectColumn("columns", "", "data_type", "", "replace","string=data_type&find_string='double'&replace_with='float'");                 
            $queryRequest->addSelectColumn("columns", "character_maximum_length");
            $queryRequest->addSelectColumn("columns", "ordinal_position");
            $queryRequest->addSelectColumn("columns", "column_default");
            $queryRequest->addSelectColumn("columns", "extra");

            $queryRequest->addTable($db_schema_information, "columns", 1, "BASE", "");

            $queryRequest->addWhereCondition("AND",    "", "columns", "table_schema",  "=", "'".$schema."'", "");
            $queryRequest->addWhereCondition("AND", "", "columns", "table_name",   "=", "'".$table."'", "");
            
            $queryRequest->addOrderbyPart("columns.ordinal_position");
        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
        //        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für getColumnlist-Select', $result);
        //Objekte erzeugen und in _columnlist ablegen
        foreach ($result as $key => $column) {
            //Bezeichnungen von Spalten, die einen alias erhalten haben, müssen angepasst werden. Erwartet wird. dass der Key einer jeden Spalte
            // nach dem Muster table.column bezeichnet wird. Mysql gibt jedoch bei der Verwendung von alias die table nicht an.
            $column["columns.data_type"] = $column[".data_type"];               //neue Spalte mit gleichem Inhalt
            
            //Default-Werte in Hochkommata setzen, wenn data_type = "varchar" oder "date"
            if($column["columns.column_default"] <> "" AND in_array($column["columns.data_type"],array("varchar","date"))) {$column["columns.column_default"] = "'".$column["columns.column_default"]."'";}
            $myColumn = new \backupColumn_universal($column);
            $this->_columnObjects[] = $myColumn;
        }
    }
    
    
    
    /** Ermittelt anhand des Schemas und des Namens der aktuellen Tabelle die Foreign-Key-Daten
     * 
     * @return type
     */
    function getForeignKeydata() {
        $db_schema_information = \global_variables::getNameOfDbSchemaInformation(); 
        
        $table = $this->name;
        $schema = $this->_schema;
        $connection_id = $this->_connection_id;
        $feedback = array();
        
        $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("referential_constraints", "constraint_name");
            $queryRequest->addSelectColumn("key_column_usage", "table_schema");
            $queryRequest->addSelectColumn("key_column_usage", "table_name");
            $queryRequest->addSelectColumn("key_column_usage", "column_name");
            $queryRequest->addSelectColumn("key_column_usage", "referenced_table_schema",    "foreign_table_schema");
            $queryRequest->addSelectColumn("key_column_usage", "referenced_table_name",      "foreign_table_name");
            $queryRequest->addSelectColumn("key_column_usage", "referenced_column_name",     "foreign_column_name");
            $queryRequest->addSelectColumn("referential_constraints", "delete_rule");
            $queryRequest->addSelectColumn("referential_constraints", "update_rule");

            $queryRequest->addTable($db_schema_information, "referential_constraints", 1, "BASE");
            $queryRequest->addTable($db_schema_information, "key_column_usage", 2, "INNER", "key_column_usage");
            
            $queryRequest->addWhereCondition("AND", "", "key_column_usage", "constraint_name",  "=", "referential_constraints.constraint_name", "");
            $queryRequest->addWhereCondition("AND", "", "key_column_usage", "constraint_schema",   "=", "referential_constraints.constraint_schema", "");
            $queryRequest->addWhereCondition("AND", "", "referential_constraints", "constraint_schema",   "=", "'".$schema."'", "");
            $queryRequest->addWhereCondition("AND", "", "key_column_usage", "table_name",   "=", "'".$table."'", "");            
            
            $queryRequest->addOrderbyPart("referential_constraints.constraint_name, key_column_usage.ordinal_position");
        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
      
        
        
        
        //Da manche DBMS in der Ergebnismenge als Identifer die im Array die Table-Aliase benutzen, andere jedoch nicht, 
        //muss eine Standardisierung stattfinden.
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für ForeignData-Select', $result);
        $feedback = $result;
        
        return $feedback;
    }
    
    
    
    
    /** Ermittelt alle Daten, die zur Erstellung der CREATE INDEX-Anweisungen notwendig sind.
     * Zusätzlich wird der CREATE-INDEX-Befehl erstellt und in der Spalte .def ausgegeben.
     * 
     * @return  array   
     * Bsp.: 
     * Array
            (
                [0] => Array
                    (
                        [pg_namespace.schema] => manager
                        [pg_class.table] => form_dependence
                        [pg_class.index] => ifk_rel_71
                        [.def] => CREATE INDEX ifk_rel_71 ON manager.form_dependence (form_id, form_app_id)
                    )

                [1] => Array
                    (
                        [pg_namespace.schema] => manager
                        [pg_class.table] => form_dependence
                        [pg_class.index] => ifk_rel_72
                        [.def] => CREATE INDEX ifk_rel_72 ON manager.form_dependence (mask_id, mask_app_id)
                    )

            )
     * 
     */
    function getIndexdata() {   
        
        $db_schema_information = \global_variables::getNameOfDbSchemaInformation(); 
        $table = $this->name;
        $schema = $this->_schema;
        $connection_id = $this->_connection_id;
        
        
        $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("statistics", "table_schema");
            $queryRequest->addSelectColumn("statistics", "table_name");
            $queryRequest->addSelectColumn("statistics", "index_name");
            $queryRequest->addSelectColumn("statistics", "column_name");

            $queryRequest->addTable($db_schema_information, "statistics", 1, "BASE", "");

            $queryRequest->addWhereCondition("AND", "", "statistics", "table_schema",  "=", "'".$schema."'", "");
            $queryRequest->addWhereCondition("AND", "", "statistics", "table_name",  "=", "'".$table."'", "");
            $queryRequest->addWhereCondition("AND", "", "statistics", "index_name",   "!=", "'PRIMARY'", "");
            
            $queryRequest->addGroupbyPart("table_schema, table_name, index_name, column_name");                 //notwendig, da bspw. in MySql versehentlich identische indexi angelegt werden können.
            
            //$queryRequest->addOrderbyPart("index_name, seq_in_index");
            $queryRequest->addOrderbyPart("index_name");
        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Ergebnis für SQL-GetIndexData für Tabelle: ".$table, $result);
        
        
        
        //2. Schleife über Ergebnis um  def-Spalte zu bauen
        
        if($result == false) {
            return array();
        } else {

            $last_index_name = "";
            $feedbackList = array();
            
            foreach ($result as $key => $resultRow) {
                $current_index_name = $resultRow["statistics.index_name"];
                if($current_index_name <> $last_index_name) {
                    //Wenn ein neuer Index vorliegt.
                    if($last_index_name <> "") {
                        //letzten Index in feedbackList schreiben
                        $currentindexArray["pg_namespace.schema"] = $result[$key-1]["statistics.table_schema"];          
                        $currentindexArray["pg_class.table"] = $result[$key-1]["statistics.table_name"];
                        $currentindexArray["pg_class.index"] = $result[$key-1]["statistics.index_name"];
                        $currentindexArray[".def"] = "CREATE INDEX ".$result[$key-1]["statistics.index_name"]." ON ".$result[$key-1]["statistics.table_schema"].".".$result[$key-1]["statistics.table_name"]." (".$referencelist.")";
                        $feedbackList[] = $currentindexArray;
                    }
                    
                    //Variablen für neuen Index belegen
                    $vorlauf = "";
                    $referencelist = $resultRow["statistics.column_name"];
                    $last_index_name = $current_index_name;
                } else {
                    //Wenn auch dieser Datensatz zum vorherigen Index gehört
                    $vorlauf = ", ";
                    $referencelist = $referencelist.$vorlauf.$resultRow["statistics.column_name"];
                }
  
            }
            
            
            //allerletzten Index in feedbackList schreiben
            $currentindexArray["pg_namespace.schema"] = $resultRow["statistics.table_schema"];
            $currentindexArray["pg_class.table"] = $resultRow["statistics.table_name"];
            $currentindexArray["pg_class.index"] = $resultRow["statistics.index_name"];
            $currentindexArray[".def"] = "CREATE INDEX ".$resultRow["statistics.index_name"]." ON ".$resultRow["statistics.table_schema"].".".$resultRow["statistics.table_name"]." (".$referencelist.")";
            $feedbackList[] = $currentindexArray;
            
            
            return $feedbackList;
        }
        
    }
    
    
    
    
    
    
    
    
    
    /**
     * Erzeugt für die gesamte Tabelle das CreateTable-Kommando
     * 
     * @return string           Create-Befehl für eine Tabelle ohne Constraints.
     */
    function createTableCommand() {
        //CREATE-Beginn
        $createCommand = "CREATE TABLE ".$this->_schema.".".$this->name." ( \n";
        $i = 0;
        //Spalten ergänzen
        foreach ($this->_columnObjects as $key => $myColumnobject) {
            $i = $i +1;
            if($i > 1) {$vorlauf = ", ";} else {$vorlauf = "";}
            
            
            if(strtolower($myColumnobject->datatype) == "text") {$myColumnobject->datatype = "longtext";}
            
            if(strpos($myColumnobject->column_default ?? '', "nextval") !== FALSE) {  //auch bei MySQL-DBMS erscheint nextval, da dies in backup_column_universal vereinheitlicht wird
                //Auto_Increment
                $datatype = "INTEGER";                                           
                $default = "";
                $suffix = "AUTO_INCREMENT";                                     //Attention NO-SQL-Standard: Die  Anweisung entspricht dem Mysql-dialekt. -> Thema = AUTO_INCREMENT
            } else {
                $datatype = $myColumnobject->datatype;
                if($myColumnobject->column_default <> "") {$default = " DEFAULT ".$myColumnobject->column_default." ";} else {$default = "";}
                $suffix = "";
            }
            
            if($myColumnobject->is_nullable == "NO") {$notNull = "NOT NULL";} else {$notNull = "";}
            if($myColumnobject->maxlength <> "") {$length = "(".$myColumnobject->maxlength.")";} else {$length = "";}
            $createCommand = $createCommand."  ".$vorlauf.$myColumnobject->column_name." ".$datatype.$length.$default." ".$notNull." ".$suffix." \n";
        }
        


        //Primary-Keys
        if($this->_primary_columns <> array()) {
            $i = 0;
            $createCommand = $createCommand."    , PRIMARY KEY (";
            foreach ($this->_primary_columns as $key => $primaryColumn) {
                $i = $i +1;
                if($i > 1) {$vorlauf = ", ";} else {$vorlauf = "";}
                $createCommand = $createCommand.$vorlauf.$primaryColumn;
            }
            $createCommand = $createCommand.") ";
        }
        

        
        //Abschluss
        $createCommand = $createCommand." \n )";
        
        //Hinweis: Foreign Keys dürfen nicht direct ins Create-Command integriert werden, sondern müssen in ein separates GRANT-Command,
        //da sonst beim Datenimport u.U. Datensätze nicht importiert werden können. Ursache ist, dass die INSERT-Befehle u.U. in der falschen Reihenfolge erfolgen könnten. 
        //Foreign-Keys würden dann einen Import verhindern.
        
        
        //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Create-Command für ".$this->_name, $createCommand);
        return $createCommand;
    }
    
    
    
    
    
    
    
    
    
    /** Liest aus einer Tabelle alle vorhandenen Daten aus und erstellt INSERT-Befehle.
     * 
     * @param   string  $in_condition       Eine beliebige SQL-Bedingung, welche beim auslesen der Daten angewendet wird (Bsp.: app_id = 'SYS01') Default = ""
     * @param   array   $in_valuelist       [optional] Wenn bereits eine Ergebnismenge vorliegt, kann diese mitgegeben werden. In dem Fall werden die Daten nicht
     *                                      aus der Quell-DB ausgelesen, sondern aus der ValueList genutzt. Verwendungszweck: vQuery
     *                                      Default = array()
     *                                      Syntax: Array(
                                                        [0] => Array(
                                                                [table_name.column1] => Bernd
                                                                [table_name.column2] => Schmid
                                                                [table_name.column3] => Herr)
                                                        [1] => Array(
                                                                [table_name.column1] => Klara
                                                                [table_name.column2] => Augustin
                                                                [table_name.column3] => Frau))
     * @return  array                       Array mit INSERT-Befehelen für jeden Datensatz
     */
    function createInsertCommands($in_condition = "", $in_valuelist = array()) {
        
        
        $insertCommandList = array();
        $mySchema = $this->_schema;
        $myTablename = $this->name;
        
        if($in_valuelist == array()) { 
            $connection_id = $this->_connection_id;
            $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectComplexStatement($myTablename.".*", $mySchema.".".$myTablename, $in_condition, "", "");
            $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        } else {
            $result = $in_valuelist;
        }
        
        
        
        if($result == false) {
            return array();
        } else {

            
            foreach ($result as $resultRow) {
                $fieldlist = "";
                $values = "";
                $vorlauf = "";
                foreach ($resultRow as $fieldname => $value) {
                    $fieldlist = $fieldlist.$vorlauf.substr($fieldname,strpos($fieldname ?? '',".")+1);
                    //Obwohl die nachfolgende Funktion (addslashes) nicht für die Verwendung im SQL-Bereich empfohlen wird,
                    //wird sie hier dennoch bevorzugt, da alle Alternativen eine gültige DB-Connection benötigen.
                    //Das ist aber im konkreten Fall nicht möglich, da Backups auch für DBMS erstellt werden können, 
                    //die auf dem aktuellen Host nicht berfügbar sind.
                    $value = addslashes($value ?? '');                                // maskiert (', ", \ und NUL-Byte) durch einen Slash

                    if($value == "") {$values = $values.$vorlauf."NULL";} else {$values = $values.$vorlauf."'".$value."'";}
                    $vorlauf = ", ";
                }
                $insertCommandList[] = "INSERT INTO ".$mySchema.".".$myTablename." (".$fieldlist.") values (".$values.")";
            }
            
            //ToDo: Prüfen, ob folgende Schritte  nötig sind
                //UTF8-Decodierung - ist das notwendig?
                // leer -> NULL
            
            
            
            return $insertCommandList;
        }
    }
    
    
}





/** Diese Klasse stellt alle Methoden für das Lesen oder Schreiben eines Backups
     * für das DBMS postgresql zur Verfügung. Die Klasse erbt von backup_universal_helper und überschreibt alle
     * Methoden, in denen Postgres-spezifische Anweisungen notwendig sind.
     * 
     */
class backup_helper extends \backup_helper_universal {
    
    
    
    /**
     * Gibt eine Liste von Hinweisen aus, die in an den Beginn einer Backup-Datei, im Bereich "Hinweise",
     * eingefügt werden.
     * 
     * @return string Text, welcher als Hinweis angedruckt werden kann.
     */
    function getNotesForDBMS() {
        $feedback = "-- Wenn dieses Importskript mit der Importfunktion von phpmyadmin eingelesen wird, muss die Fremdschlüsselprüfung deaktiviert werden. \n";
        $feedback = $feedback."-- Dafür bietet phpmyadmin ein Häkchen an.\n";
        $feedback = $feedback."-- \n";
        
        //Die folgende Anweisung wird als Dummy in Backups benötigt. 
        //Ursache: in einem Backup kann es vorkommen, dass gar keine Daten enthalten sind. Beim Einspielen des Backups über
        //PHP kann es dann zu einer missverständlichen Warnung kommen. daher wird der folgende Befehl vorangestellt.
        $feedback = $feedback."select * from information_schema.tables where 1=2; \n";
        
        
        return $feedback;
    }
    
    
    
    
    /** In der Regel ist es sinnvoll einem langen Importskript bestimmte 
     * Konfigurationsparameter voranzustellen. Bspw. maximale-Skriptlaufzeit oder 
     * Prüfung-der-Foraign-Keys-deaktivieren usw. .
     * 
     * Beachte aber, dass die Parameter, in Abhängigkeit von Source- und Target-DBMS unter Umständen
     * nicht gesetzt werden können. Die Entscheidung darüber trifft die Funktion
     * backupmanager_class->setDbmsParams
     * 
     * @return array            Liste mit SQL-Anweisungen 
     */
    function getInitialConfigparamsForDBMS() {
        $feedback = array();
        
        $feedback[] = "SET FOREIGN_KEY_CHECKS = 0; \n";

        return $feedback;
    }
    
    
    /** Wenn in getInitialConfigparamsForDBMS Einstellungen vorgenommen wurden,
     * ist es in der Regel sinnvoll, diese nach dem Datenimport wieder zurückzusetzen.
     * 
     * @return array        Liste der SQL-Commands
     */
    function resetInitialConfigparamsForDBMS() {
        $feedback = array();
        
        $feedback[] = "SET FOREIGN_KEY_CHECKS = 1;";
        
        return $feedback;
    }
    

    
     
    
    
    /** Erstellt für die übergebene Tabellenliste die Drop-Anweisungen und gibt diese als String zurück.
     * 
     * @param   array  $in_tablelist        Zweidimensionales array, wie es getTablelistFromSchema() erzeugt.
     * @return  string                      Liste der Drop-Commandos
     */
    function createTableDropCommand($in_tablelist) {
        $dropTableOrders = array();
        foreach ($in_tablelist as $key => $table) {
            $dropOrder = "DROP TABLE IF EXISTS ".$table["tables.table_schema"].".".$table["tables.table_name"];
            $dropTableOrders[]= $dropOrder;
            
        }
        return  $dropTableOrders;
    }
    
    

    
}