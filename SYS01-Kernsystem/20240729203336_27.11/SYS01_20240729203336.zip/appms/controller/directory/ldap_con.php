<?php		
	
/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


	/** Prüft Account-id (uid) und Passwort mit Hilfe eines Ldap.
         * 
         * @param   String  $in_directory_id    ID des Directories, welches den User validieren soll (siehe DB-Tabelle directory)
         * @param   String  $uid                Account_id
         * @param   String  $password           Passwort
         * @param   String  $in_dummy_appId     Dummy-Parameter, der nur existiert, damit die Funktion kompatibel zur gleichnamigen Funktion des internenen Validators ist.
         * @return  Boolean
         */
	function checkUserAccount($in_directory_id, $uid,$password, $in_dummy_appId) {								
		if (extension_loaded('ldap') == true) {
                    $ldap_uid = $uid;

                    //Daten des Directory (Ldap-Server) ermitteln
                    $directory = getLdapdirParams($in_directory_id);
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Benutzervalidierung via ldap', $directory);

                    $ldap_base = $directory["dir_base"];
                    $ldap_dn = "uid=$ldap_uid, ".$directory["dir_ou"].", $ldap_base";
                    $ldap_password = $password;
                    $ldapServer = $directory["dir_server"];
                    $ldapport = $directory["dir_port"];													//389=ldap;636=ldaps




                    //Benutzeraccount gegen ldap prüfen
                    $ldap_conn = ldap_connect( $ldapServer, $ldapport);

                    // LDAP-Optionen setzen
                    ldap_set_option($ldap_conn, LDAP_OPT_PROTOCOL_VERSION, 3);			
                    ldap_set_option($ldap_conn, LDAP_OPT_TIMELIMIT, 10);
                    ldap_set_option($ldap_conn, LDAP_OPT_NETWORK_TIMEOUT, 10);
                    ldap_set_option($ldap_conn, LDAP_OPT_REFERRALS, 0);       


                    ldap_bind($ldap_conn, $ldap_dn, $ldap_password);                                //ToDo: hier muss auch das expiredate beachtet werden.
                    if (ldap_errno($ldap_conn) or $ldap_password == "") {				//Eingabe eines Passwortes muss erzwungen werden, da sonst eine Anmeldung mit Anoymous erfolgt				
                            //echo "bind war nicht erfolgreich.<br/>".ldap_error($ldap_conn);
                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ldap-Fehler', ldap_err2str(ldap_errno($ldap_conn)), "ERROR");
                            $checkResult = false;
                    } else {
                            //echo "Die Verbindung zum ldap war erfolgreich.<br/>";
                            $checkResult = true;

                    }
                    ldap_close($ldap_conn);
                } else {
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ldap-Fehler', "ldap-extension ist im Webserver nicht geladen. Die php.ini muss entsprechend angepasst werden.", "ERROR");
                    $checkResult = false;
                }
		return $checkResult;
	}		
	
?>