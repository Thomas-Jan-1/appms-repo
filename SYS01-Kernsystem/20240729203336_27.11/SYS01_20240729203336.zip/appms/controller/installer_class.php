<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

/**
 * Description of install_class
 *
 * @author Thomas
 */
class installer {
    
    /**
     *
     * @var     string           absoluter Pfad zum Update-Verzeichnis für alle App's
     */
    protected $updatePath_abs;
    
    
    /**
     *
     * @var     string          absoluter Pfad zum Update-Verzeichnis für die aktuelle APP, inkl. abschließenden Seperator (Bsp.: /var/www/html/appms/update/SYS01/)
     */
    public $updatePathApp_abs;  
    
    
    /**
     * 
     * @var     string          absoluter Pfad zum Wiki-Update-Verzeichnis für die aktuelle APP, inkl. abschließenden Seperator (Bsp.: /var/www/html/appms/update/SYS01/)
     */
    public $updatePathAppWiki_abs;
    
    
    /**
     *
     * @var     string          absoluter Pfad zum Recovery-Verzeichnis 
     */
    protected $recoveryPath_abs;
    
    
    /**
     *
     * @var     string          Name der Updatedatei 
     */
    public $updateFilename;
    
    
    /**
     *
     * @var     string          App, für die das Installationspaket ist.
     */
    public $app_id;
    
    
    /**
     *
     * @var     string          Versionsnummer des Installationspaketes 
     */
    public $versionnumber;
    
    
    /**
     *
     * @var     string          kompatible Versionsnummer des Installationspaketes  (Abwärtskompatibilität)
     */
    protected $versionnumber_compatible;
    
    
    /**
     *
     * @var     string          Benötigte Kernelversion 
     */
    protected $versionnummber_kernel_needed;


    
    /**
     *
     * @var     string          Benötigte mindest-Kernelversion (Abwärtskompatibilität)
     */
    protected $versionnummber_kernel_compatible;
    

    /**
     *
     * @var     string          Die Variable sammelt die Protokollmeldungen für den Nutzer 
     */
    public $userFeedback;
    
    
    /**
     *
     * @var     string          Zeitstempel der Durchfürhung der Prüfung des Versionspaketes (Format: date("YmdHi"))
     */
    protected $checkResultTime;
    
    
    /**
     *
     * @var     string           DBMS der aktuellen Installation (siehe config.xml)
     */
    protected $dbms;
    
    
    /**
     *
     * @var     string          db_user der lokalen Installation (entnommen aus der config.xml) 
     */
    protected $db_user;
    
    
    /**
     *
     * @var     integer         Anzahl der SQL-commands im before_update_script. 
     */
    protected $count_commands_before_script;

    
    /**
     *
     * @var     integer         Anzahl der SQL-commands im after_update_script. 
     */
    protected $count_commands_after_script;
    
    
    /**
     *
     * @var     array          Name des backup_complete-File-A (structure und content); bei SYS01 enthält diese Datei alle Daten.
     */
    protected $backupfile_completeA;
    
    
    /**
     *
     * @var     array          Name des backup_complete-File-B (config und addContent); bei SYS01 enthält diese Datei keine Daten.
     */
    protected $backupfile_completeB;
    
    
    
    /**
     *
     * @var     string          Name des backup_contentA; enthält config und addContent-Daten
     */
    protected $backupfile_contentA;
    
    
     /**
     *
     * @var     string          Name des backup_contentB; enthält content-Daten
     */
    protected $backupfile_contentB;
    
    
    /**
     *
     * @var     boolean         Wenn das Update-Pakte die gleiche Versionsnummer, wie die bereits installierte Version hat, dann wird diese Eigenschaft auf true gesetzt. 
     */
    protected $is_reinstall;
    
    
    /**
     *
     * @var     boolean         Wenn es sich um ein Installationspaket einer bisher nicht installierten App handelt, dann wird diese Eigenschaft auf true gesetzt. 
     */
    protected $is_new_install;
    
    
    /**
     *
     * @var     boolean         Wenn es sich um ein Installationspaket einer bereits installierten App handelt, dann wird diese Eigenschaft auf true gesetzt. 
     */
    protected $is_old_install;
    
    
    /**
     * 
     * @var     boolean         Wenn es sich um ein Installationspaket für ein Wiki handelt, dann wird diese Eigenschaft auf true gesetzt.
     */
    protected $is_wiki_install;

    /**
     * Die Klasse stellt Methoden zur Durchführung einer Installtion/Aktualisierung bereit.
     * 
     */
    public function __construct() {
        
    }
    
    
    
    /** Diese Funktion legt auf Basis der TEMPl-Vorlage (config_default.xml) eine neue config.xml-Datei an.
     * 
     * @param   string $in_app_id
     * @param   string $in_dbms
     * @param   string $in_host
     * @param   string $in_port
     * @param   string $in_dbname
     * @param   string $in_user
     * @param   string $in_password
     * @param   string $in_encoding
     * @return  boolean
     * @throws Exception
     */
    public function prepareNewApp($in_app_id, $in_dbms, $in_host, $in_port, $in_dbname, $in_user, $in_password, $in_encoding) {
        
        //Attribute pflegen
        $this->dbms = $in_dbms;
        $this->app_id = $in_app_id;
        $this->db_user = $in_user;
        $this->is_new_install = true;
        
        
        
        //data-Verzeichnis auf Basis des TEMPL-Verzeichnis erstellen
        $sourcePath = global_variables::getPathForAppmsinstallOrigin_abs().global_variables::getPathForData_rel().global_variables::getNameOfTemplateInDatafolder();
        $targetDataPath = global_variables::getPathForAppmsinstallOrigin_abs().global_variables::getPathForData_rel().$in_app_id;
        $copyResult = folder_copy($sourcePath, $targetDataPath, global_variables::getDefaultPermissionForFolder(), true);
        if($copyResult == false) {throw new Exception(-171);}
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ', "TEMPL-Verzeichnis nach ".$targetDataPath." kopiert.");


        //Config-Datei erstellen
        $dirSep = global_variables::getDirectorySeparator();
        $configDir = $targetDataPath.$dirSep.global_variables::getNameOfConfigInDatafolder();
        $configFile = global_variables::getNameOfConfigFile();
        if($this->createNewConfigXml($configDir, "config_default.xml", $configFile, $in_app_id, $in_dbms, $in_host, $in_port, $in_dbname, $in_user, $in_password, $in_encoding) === false) {
            throw new Exception(-172);
        }
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ', "config.xml angelegt.");
            
        
        //Wenn bis hierhin kein Fehler geworfen wurde, ist alles ok.
        return true;
        
    }
    
    
    
    
    /** Vermerkt, dass die Methode (Update) gewählt wurde.
     * 
     * @return boolean
     */
    public function prepareOldApp() {
        
        //Attribute pflegen
        $this->is_old_install = true;

        //Wenn bis hierhin kein Fehler geworfen wurde, ist alles ok.
        return true;
        
    }
    
    
    
    /** Prüft, anhand der Tabelle manager.app, ob die Anwendung bereits installiert ist
     * 
     * @param type $in_app_id
     */
    public function is_installedApp($in_app_id) {
        $is_installed = getDataFromTableByID(global_variables::getConnectionIdOfDbSchemaSYS01(), global_variables::getNameOfDbSchemaSYS01(), "app", "id", "id = '".$this->app_id."'");
        
        if($is_installed != false) {
            //Ein Datensatz für die APP-ID wurde in manager.app gefunden. Somit ist die Anwendung bereits installiert.
            $feedback = true;   
        } else {
            $feedback = false;
        }
        
        return $feedback;
    }
    
    
    

    
    
    
    
    /**
     * Bereitet das Update oder eine Neuinstallation einer APP vor, indem das Installationspaket aus $_FILES
     * verschoben, entpackt und geprüft wird.
     * 
     * @param  object       $in_pagedata    Referenz auf das pagedata-object
     * @return integer                      Im Erfolgsfall wird der UserFeedback-Code 161 zurückgegeben. Im Fehlerfall wird eine Exception mit Fehlercode geworfen.
     * @throws Exception                    Feedback-Meldung gemäß konstantentyp_id = 35 
     */
    public function prepareInstall(&$in_pagedata) {
        
        
        //FileUpload in den Zielordner verschieben
        $feedback = $this->moveUpdatepacket();
        if($feedback !== 150) {throw new Exception($feedback);}
        
        //Anhand des Dateinamens prüfen, ob es sich um ein Wiki- oder App-Instalationspaket handelt
        $this->is_wiki_install = $this->checkIsWikiInstallpackage($this->updateFilename);
        
        
        if($this->is_wiki_install === true) {
            $feedback = $this->prepareInstallWiki();
        } else {
            $feedback = $this->prepareInstallApp($in_pagedata);
        }
        
        return $feedback;
       
    }
    
    
    
    /** Führt alle vorbereitende Schritte durch, die für das Anwendungsinstallationspaket notwendig sind.
     * Wenn innerhalb der Funktion ein Fehler auftritt, wird eine Exception geworfen.
     * Wenn kein Fehler auftritt, ist der Return-Code dieser Funktion immer 161.
     * 
     * @param   in_pagedata Referenz zum pagedata-object
     * @return  int         161, wenn kein Fehler auftritt
     * @throws  Exception
     */
    protected function prepareInstallApp(&$in_pagedata) {
        
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        //version_info.xml einlesen
        if($this->readVersionInfoFile($this->updatePath_abs) == false) {throw new Exception(-162);}    
        
        //Prüfen, ob der PHP-Meldungs-Debug-Modus eingeschaltet ist.
        if(getConfig("debug_php_errorreporting", global_variables::getAppIdFromSYS01()) != true) {
            throw new Exception(-175);
        }
        
        //Versionsabhängigkeiten prüfen, dabei ggf. Fehler werfen und APP-ID ermitteln
        $this->checkVersionCompatiblity();
        $this->updatePathApp_abs = $this->updatePath_abs.$this->app_id.global_variables::getDirectorySeparator();
        
        //update-Ordner leeren
        if($this->clearUpdateDir() == false) {throw new Exception(-161);}
        
        //recovery-Ordner mit Inhalt neu anlegen. Das muss schon an dieser Stelle passieren, da im Falle des Kernel-Updates, dieser als temporärer Installationspfad genutzt wird.
        if($this->is_new_install === false) {
            if($this->makeRecovery() == false) {throw new Exception(-161);}
        }
        
        //ZIP-Datei in Update-Ordner entpacken.
        if(extractZipFile($this->updatePath_abs.$this->updateFilename, $this->updatePathApp_abs) == false) { 
            $this->addUserFeedback( "Installationspaket entpacken","Das Installationspaket (".$this->updatePath_abs.$this->updateFilename.") konnte nicht entpackt werden.", "error");
        } else {
            $this->addUserFeedback( "Installationspaket entpacken","Das Installationspaket wurde entpackt", "success");
        }
        
        //Forbidden-Files im Installationspaket suchen. -> bspw. htaccess-Dateien durch Drittanbieter unterdrücken
        if($this->search_ForbiddenFiles($this->updatePathApp_abs.global_variables::getNameOfInstallFolder().$my_DIR_SEP, false) == false) {throw new Exception(-160);}
        
        
        //lokale .htaccess-Datei mit neuer Version vergleichen
        if($this->app_id == global_variables::getAppIdFromSYS01()) {
            //nur ein Update des Kernsystems bringt ggf. eine neue htaccess-Datei mit
            if($this->checkHtaccessFile() == false) {
                $this->addUserFeedback( "Änderungen der .htaccess-Datei prüfen","Das notwendige Plugin -diff- konnte nicht geladen werden. Weitere Details können der Debug-Tabelle entnommen werden.", "error");
                throw new Exception(-101);
            }
            
            //Wenn das Kernsystem aktualisiert wird, dann wird der Installationspfad temporär umgelenkt.
            //In dem Fall muss auch die config.xml im temporären Installationsordner bereitgestellt werden.
            $my_DIR_SEP = global_variables::getDirectorySeparator(); 
            $source_path = global_variables::getPathForAppmsinstall_abs(false).$my_DIR_SEP."data".$my_DIR_SEP.global_variables::getAppIdFromSYS01().$my_DIR_SEP."config".$my_DIR_SEP;
            $target_path = $this->updatePathApp_abs.$my_DIR_SEP.global_variables::getNameOfInstallFolder().$my_DIR_SEP."data".$my_DIR_SEP.global_variables::getAppIdFromSYS01().$my_DIR_SEP."config".$my_DIR_SEP;
            $permission = global_variables::getDefaultPermissionForFolder();
            if(folder_copy($source_path, $target_path, $permission, false) == false) {
                $this->addUserFeedback( "Config.xml in temp_install übertragen","Die Datei config.xml konnte nicht in das temporäre Installationsverzeichnis übertragen werden. Damit wäre eine Datenbankverbindung während des Installationsprozesses nicht möglich.", "error");
                throw new Exception(-167);
            }
        }
        
        
        //Wenn bis hierhin kein Fehler geworfen wurde, wird das positive Prüfergebnis im Dateisystem abgelegt, sodass nachfolgende Prozesse darauf zugreifen können.
        $this->createCheckResultFile($this->updatePathApp_abs);
        
        //Wenn ein Update für das Kernsystem durchgeführt wird, dann wird der Installationspfadd von AppMS temporär auf das recovery-Verzeichnis umgestellt.
        //Somit können im eigentlichen Installationspfad Dateien ersetzt werden. 
        //Sollte die Installation nicht direkt im Anschluss erfolgen, wird der Installationspfad automatisch wieder korrigiert.
        if($this->app_id == global_variables::getAppIdFromSYS01()) {
            session_class::$session_object->setSessionUseTempInstallPath(true); 
            //Mask-Array neu aufbauen, da sonst die Masken-Links noch auf das alte Installationsverzeichnis zeigen.
            $in_pagedata->_maskArray = getMaskDataById($in_pagedata->internGetObject->getMaskID(), $in_pagedata->internGetObject->getMaskAppID(),true);  
        }
        
        $this->addUserFeedback( "Prüfung abgeschlossen","Das Installationspaket wurde erfolgreich getestet und die Installation vorbereitet. Die Installation kann nun gestartet werden.", "success");
        $this->userFeedback = "<b>Protokoll der Prüfung des Installationspaketes:</b><br /><br />".$this->userFeedback;
        
        return 161;
    }
    
    
    
    
    
    /** Führt alle vorbereitende Schritte durch, die für das Wiki-Installationspaket notwendig sind.
     * Wenn innerhalb der Funktion ein Fehler auftritt, wird eine Exception geworfen.
     * Wenn kein Fehler auftritt, ist der Return-Code dieser Funktion immer 162.
     * 
     * @return  int             162
     * @throws  Exception
     */
    protected function prepareInstallWiki() {
        
        $myDirSep = global_variables::getDirectorySeparator();
        //version_info.xml einlesen
        if($this->readVersionInfoFile($this->updatePath_abs) == false) {throw new Exception(-162);}       
        
        //Wiki-Installation
        $this->addUserFeedback( "Installationspaket Wiki","Das Wiki der Anwendung ".$this->app_id." wird aktualisiert.", "success");
        $this->updatePathAppWiki_abs = $this->updatePath_abs.$this->app_id.$myDirSep.global_variables::getNameOfWikiDir().$myDirSep;
        
        //ZIP-Datei in Update-Ordner entpacken.
        if(extractZipFile($this->updatePath_abs.$this->updateFilename, $this->updatePathAppWiki_abs) == false) { 
            $this->addUserFeedback( "Installationspaket entpacken","Das Installationspaket (".$this->updatePath_abs.$this->updateFilename.") konnte nicht entpackt werden.", "error");
        } else {
            $this->addUserFeedback( "Installationspaket entpacken","Das Installationspaket wurde entpackt", "success");
        }
        
        //Forbidden-Files im Installationspaket suchen. -> bspw. htaccess-Dateien durch Drittanbieter unterdrücken
        if($this->search_ForbiddenFiles($this->updatePathAppWiki_abs, true) == false) {throw new Exception(-160);}
        
        //Wenn bis hierhin kein Fehler geworfen wurde, wird das positive Prüfergebnis im Dateisystem abgelegt, sodass nachfolgende Prozesse darauf zugreifen können.
        $this->createCheckResultFile($this->updatePathAppWiki_abs);
        
        $this->addUserFeedback( "Prüfung abgeschlossen","Das Wiki-Installationspaket wurde erfolgreich getestet und die Installation vorbereitet. Die Installation kann nun gestartet werden.", "success");
        $this->userFeedback = "<b>Protokoll der Prüfung des Installationspaketes:</b><br /><br />".$this->userFeedback;
        
        return 162;
    }
    
    
    
    /** Prüft, ob es sich bei dem Installpaket um ein Wiki-Update handelt.
     * 
     * @param   string  $in_filename        Name des Updatepaketes
     * @return  boolean
     */
    protected function checkIsWikiInstallpackage($in_filename) {
        if (strpos($in_filename, "_wiki.zip") !== false) {
            $feedback = true;
        } else {
            $feedback = false;
        }
        
        return $feedback;
    }
    
    
    
    
    /** Prüft die htaccess-Datei der neuen Version aus dem data-Verzeichnis der Kernel-APP 
     * gegen die lokale .htaccess-Datei und übergibt Änderungen an addUserFeedback.
     * 
     * Wenn eine der beiden Dateien nicht gefunden wurde, wird das dem User ebenfalls angezeigt.
     * 
     * @return boolean              false, wenn das Plugin "diff" nicht geladen werden konnte.
     */
    protected function checkHtaccessFile() {
        
        //diff-plugin laden
        if(loadPlugin(global_variables::getAppIdFromSYS01(), "diff_class") == true) {
            $myDirSep = global_variables::getDirectorySeparator();
            $localFile = global_variables::getPathForAppmsinstallOrigin_abs().".htaccess";
            if(file_exists($localFile) == false) {$localFile = array("Eine lokale .htaccess-Datei wurde nicht gefunden(".$localFile.").");}
            $newFile = global_variables::getPathForUpdate_abs().$this->app_id.$myDirSep.global_variables::getNameOfInstallFolder().$myDirSep.".htaccess";
            if(file_exists($newFile) == false) {$newFile = array("Eine neue .htaccess-Datei wurde nicht gefunden (".$newFile.").");}
            
            $diff = new diff;
            $text = $diff->inline($localFile,$newFile,null);
            if(count($diff->changes) > 0) {
                $this->addUserFeedback( "prüfe Änderungen in .htaccess-Datei",
                                        "In der neuen .htaccess-Datei wurden Änderungen gegenüber der alten Datei erkannt. ".
                                        "Nachfolgend werden die erkannten Änderungen durch farbige Hervorhebung dargestellt. <br />".
                                        "Eine Kopie der alten Datei bleibt im recovery-Verzeichnis erhalten. <br />".$text, "info");
            } else {
                $this->addUserFeedback( "prüfe Änderungen in .htaccess-Datei","Es liegen keine Änderungen für die .htaccess-Datei vor", "success");
            }
            $feedback = true;
        } else {
            $feedback = false;
        }
        
        return $feedback;
    }
    
    
    
    
    /** Führt die installation des zuletzt geprüften Installationspaketes durch.
     * 
     * @param  object                       Referenz auf das pagedata-object
     * @return integer                      Im Erfolgsfall wird der UserFeedback-Code 160 zurückgegeben. Im Fehlerfall wird eine Exception mit Fehlercode geworfen.
     * @throws Exception                    Feedback-Meldung gemäß konstantentyp_id = 35 
     */
    public function executeInstall(&$in_pagedata) {
        
        require_once("../controller/progressstatus_class.php"); 
        
        $connection_id_progress = global_variables::getConnectionIdOfDbSchemaSYS01();
        session_write_close();             //wichtig, da sonst die parallele Abfrage des Bearbeitungszustandes via Ajax seitens des Clients nicht möglich ist.
	$myProgress = new progressstatus;
        $myProgress->setStatus($connection_id_progress, 1, 100, "Starte Installation", 1);
        
        //Metadaten aus Checkresult einlesen
        if($this->readCheckResult() == false) {
            $this->addUserFeedback( "prüfe check_result", "Die Prüfung des Installationspaktes (".$this->app_id." - ".$this->versionnumber.") hatte Fehler aufgezeigt (siehe version_check.xml). Daher kann dieses Installationspaket nicht verarbeitet werden.", "error");
            throw new Exception(-160);
        } else {
            $this->addUserFeedback( "prüfe check_result", "Verarbeite geprüftes Installationspaket (".$this->app_id." - ".$this->versionnumber.")", "success");
        }
        $myProgress->setStatus($connection_id_progress, 5, 100, "Lese Vorabcheckergebnisse", 1);
        
        //Prüfen, ob checkresult ausreichend aktuell ist und zum vorliegenden Installationspaket passt.
        if($this->checkResultAge() == false) {
            $this->addUserFeedback( "prüfe check_result_age", "Die Prüfergebnisse des Installationspaketes (".$this->app_id." - ".$this->versionnumber.") sind älter als zulässig. Führen Sie die Prüfung erneut durch. Das zulässige Alter wird über den Konfigurationsparameter -install_allowed_checkage- festgelegt.", "error");
            throw new Exception(-160);
        }
        
        
        //Version_Info-File einlesen.
        if($this->readVersionInfoFile($this->updatePath_abs) == false) {throw new Exception(-162);}
        $myProgress->setStatus($connection_id_progress, 10, 100, "Lese Vorabcheckergebnisse", 1);
        
        
        if($this->is_wiki_install == true) {
            //neue Wikidateien in das Installationsverzeichnis kopieren. Dabei alte Dateien nicht löschen.
            if($this->copyWikiFilesToInstallFolder() == false) {
                throw new Exception(-160);
            }
            $myProgress->setStatus($connection_id_progress, 100, 100, "Wiki installiert", 1);
        } else {
            //Prüfen, ob die richtige Methode (Update bzw. NewInstall) gewählt wurde.
            if($this->is_new_install == true AND $this->is_installedApp($this->app_id) == true) {
                //Neuinstallation gewählt, aber APP ist bereits vorhanden
                throw new Exception(-174);
            } elseif($this->is_old_install == true AND $this->is_installedApp($this->app_id) == false) {
                //Update gewählt, aber APP existiert noch nicht
                throw new Exception(-168);
            }
            

            //Vollbackup der DB der App erstellen, falls ein Recovery notwendig wird.
            if($this->is_new_install == false) {
                if($this->makeDB_backup_complete($in_pagedata, "complete") == false) {
                    $this->addUserFeedback( "DB-Backup für Recovery", "DB-Backup für Notfall-Recovery konnte nicht erstellt werden.", "error");
                    throw new Exception(-160);
                } else {
                    $this->addUserFeedback( "DB-Backup für Recovery", "DB-Backup für den Fall, dass die Installation fehlschlägt und der ursprüngliche Zustand wiederhergestellt werden muss, wurde erstellt.", "success");
                }
            }
            $myProgress->setStatus($connection_id_progress, 20, 100, "Komplettsicherung für Recovery erstellt", 1);




            //DB-Korrekturskripte, welche vor dem Entladen der Daten ausgeführt werden müssen, ausführen.
            if($this->is_reinstall != true AND $this->is_new_install == false) {
                //Das before-Script wird nur ausgeführt, wenn die zu installierende Version nicht bereits installiert ist (Reparatur_mdus). 
                //Andernfalls würden Datenbankkorrekturen ausgeführt werden, die bereits ausgeführt wurden.
                if($this->executeScript($in_pagedata, "before") == false) {
                    //addUserFeedback erfolgte bereits in executeScript, da differenzierte Medlungen notwendig sind
                    throw new Exception(-160);
                }
            } elseif($this->is_new_install == true) {
                //Korrekturskripte sind nicht notwendig, da DB noch nicht existiert
            } else {
                $this->addUserFeedback( "DB-Script (before)", "Reparaturmodus - Dieser Prozessschritt entfällt.", "success");
            }
            $myProgress->setStatus($connection_id_progress, 25, 100, "Vorab-Skripte ausgeführt", 1);


            //Content-Backup der DB, damit diese Daten nach dem Einspielen des Updates wiederhergestellt werden können.
            //Wenn eine Anwendung ein external_administrated Schema hat (siehe manager.app_schema), dann werden dessen Daten an dieser Stelle 
            //nicht exportiert und im folgenden Prozess wird das Schema auch an keiner weieren Stelle verändert.
            if($this->is_new_install == false) {
                if($this->makeDB_backup_content($in_pagedata, "content") == false) {
                    $this->addUserFeedback( "DB-Backup für Daten", "DB-Backup zur Übernahme aller lokalen Daten konnte nicht erstellt werden.", "error");
                    throw new Exception(-160);
                } else {
                    $this->addUserFeedback( "DB-Backup für Daten", "DB-Backup zur Übernahme aller lokalen Daten, wurde erstellt.", "success");
                }
            }
            $myProgress->setStatus($connection_id_progress, 30, 100, "Inhalte sichern", 1);

            //neue Versionsdateien in das Installationsverzeichnis kopieren. Dabei alte Dateien nicht löschen, sodass Backups und eigene Bilder usw. erhalten bleiben.
            if($this->copyVersionFilesToInstallFolder("install") == false) {
                $this->rollback($in_pagedata, $myProgress);
                throw new Exception(-160);
            }
            $myProgress->setStatus($connection_id_progress, 35, 100, "Installation in temporäres Verzeichnis", 1);

            //db_user der aktuellen Installation aus der lokalen config.xml ermitteln
            //Der db_user wird in executeScript im main-script eingetragen. Er muss also vor dem Aufruf in executeScript ermittelt werden.
            $this->db_user = getValueFromConfigXml($this->app_id, "user");
            if($this->db_user === false) {
                $this->rollback($in_pagedata, $myProgress);
                throw new Exception(-160);
            }


            //db-new-scripte: DB-User eintragen und ausführen. (Hinweis, bei alten Installationspakten (< 10.01.2021 könnten diese Scripte fehlen.)
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ', "is_new_install: ".$this->is_new_install);

            if($this->is_new_install == true) {
                if($this->executeScript($in_pagedata, "new-install-115") == false) {
                    //addUserFeedback erfolgte bereits in executeScript, da differenzierte Meldungen notwendig sind
                    $this->rollback($in_pagedata, $myProgress);
                    throw new Exception(-173);
                }
            }
            $myProgress->setStatus($connection_id_progress, 40, 100, "Datenbankänderungen durchführen", 1);



            //db_main-script (Installationsskript der Datenbank) ausführen. Dabei wird auch der db_user in das Skript eingetragen
            //Bei external_administrated Schemata enthalten diese Scripte keine Anweisungen.
            if($this->app_id == global_variables::getAppIdFromSYS01()) {
                //In der Kernel-Anwendung gibt es nur ein Main-Install-Skript, da structure- und config-Daten im selben Schema liegen.        
                if($this->executeScript($in_pagedata, "main-install-101") == false) {
                    //addUserFeedback erfolgte bereits in executeScript, da differenzierte Meldungen notwendig sind
                    $this->rollback($in_pagedata, $myProgress);
                    throw new Exception(-160);
                }
            } else {
                //structure-Daten
                if($this->executeScript($in_pagedata, "main-install-111") == false) {
                    //addUserFeedback erfolgte bereits in executeScript, da differenzierte Meldungen notwendig sind
                    $this->rollback($in_pagedata, $myProgress);
                    throw new Exception(-160);
                }
                //config-Daten
                if($this->executeScript($in_pagedata, "main-install-112") == false) {
                    //addUserFeedback erfolgte bereits in executeScript, da differenzierte Meldungen notwendig sind
                    $this->rollback($in_pagedata, $myProgress);
                    throw new Exception(-160);
                }
            }
            $myProgress->setStatus($connection_id_progress, 70, 100, "Datenbankänderungen durchführen", 1);


            //db_content-script (Content-Sicherung) der bestehenden Installation wieder herstellen.
            //Bei external_administrated Schemata enthalten diese Scripte keine Anweisungen.
            if($this->app_id == global_variables::getAppIdFromSYS01()) {
                if($this->executeScript($in_pagedata, "recovery-contentA") == false) {
                    //addUserFeedback erfolgte bereits in executeScript, da differenzierte Medlungen notwendig sind
                    $this->rollback($in_pagedata, $myProgress);
                    throw new Exception(-160);
                }
            } else {
                if($this->is_new_install == false) {
                    if($this->executeScript($in_pagedata, "recovery-contentA") == false) {
                        //addUserFeedback erfolgte bereits in executeScript, da differenzierte Medlungen notwendig sind
                        $this->rollback($in_pagedata, $myProgress);
                        throw new Exception(-160);
                    }
                    if($this->executeScript($in_pagedata, "recovery-contentB") == false) {
                        //addUserFeedback erfolgte bereits in executeScript, da differenzierte Medlungen notwendig sind
                        $this->rollback($in_pagedata, $myProgress);
                        throw new Exception(-160);
                    }
                }
            }
            $myProgress->setStatus($connection_id_progress, 80, 100, "Inhaltsdaten in Datenbank zurückkopieren", 1);



            //DB-Korrektur-Skript nach Installation ausführen
            if($this->executeScript($in_pagedata, "after") == false) {
                //addUserFeedback erfolgte bereits in executeScript, da differenzierte Medlungen notwendig sind
                throw new Exception(-160);
            }
            $myProgress->setStatus($connection_id_progress, 90, 100, "Datenbankänderungen nach Installation", 1);


            //Versionsnummer in Tabelle app eintragen
            if(setVersionNumberIntoTableApp($in_pagedata, $this->versionnumber, $this->versionnumber_compatible, $this->app_id, session_class::$session_object->getUid()) == false) {
                $this->addUserFeedback( "neue Versionsnummer in DB eintragen", "Die neue Versionsnummer konnte nicht in die DB-Tabelle app eingetragen werden.", "error");
                $this->rollback($in_pagedata, $myProgress);
                throw new Exception(-160);
            }
            $myProgress->setStatus($connection_id_progress, 100, 100, "Nacharbeiten", 1);


            //Sicherheitshinweise ausgeben
            $this->addSecurityNotes();

            //Debug-Meldungen auch in Update-Verzeichnis schreiben
             writeDebugToFile($this->updatePathApp_abs, "debug_update_success.html");

            //tempInstallPath deaktivieren
            session_class::$session_object->setSessionUseTempInstallPath(false);
        }
        session_start();                   //alte Session wieder aufnehmen    
            
        return 160;
    }
    
    
    
    
    protected function addSecurityNotes() {
        $securityNotes = "<ul> \n".
                            "<li>1.) Passwörter: <br />Ändern Sie, wenn nicht schon geschehen, die Passwörter von '".strtolower($this->app_id)."root' und '".strtolower($this->app_id)."admin'.</li><br /> \n".
                            "<li>2.) Debug-PHP-Konfigurationsparameter: <br />Stellen Sie sicher, dass der Konfigurationsparameter 'debug_php_errorreporting' i.d.R. auf '0' (aus) gesetzt ist. Somit werden Angreifern keine unnötigen Informationen gegeben.</li><br /> \n".
                            "<li>3.) Test-Accounts: <br />Falls Sie in der Benutzertabelle Test-Accounts angelegt haben sollten, achten Sie darauf, dass diese nur bei Bedarf aktiviert werden (gültig_bis < heute  => deaktiviert).</li><br /> \n".
                        "</ul> ";
        
        $this->addUserFeedback( "Sicherheitshinweise", $securityNotes, "info");
            
    }
    
    
    
    /** Diese Funktion versucht die ursprüngliche Installation wiederherzustellen
     * Dazu werden die gesicherten Installationsdatein wieder zurück kopiert,
     * die Datenbankkomplettsicherung eingespielt und 
     * ggf. der temporäre Installationsordner wieder deaktiviert.
     * 
     * @param type $in_pagedata
     */
    protected function rollback(&$in_pagedata, &$in_progressbar) {
        $this->addUserFeedback( "Starte Recovery-Vorgang", "------------------------------------------", "success");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> rollback', "Starte Recovery-Vorgang", "ERROR");
        $connection_id_progress = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        //Daten aus dem Recovery-Verzeichnis wieder in das Installationsverzeichnis kopieren
        $this->copyVersionFilesToInstallFolder("recovery");
        $in_progressbar->setStatus($connection_id_progress, 30, 100, "Fehler -> Rollback wird durchgeführt!!!", 1);

        
        
        //DB-Daten aus complete-Sicherung wiederherstellen
        if($this->app_id == global_variables::getAppIdFromSYS01()) {
            $this->executeScript($in_pagedata, "recovery-completeA");
        } else {
            $this->executeScript($in_pagedata, "recovery-completeA");
            $this->executeScript($in_pagedata, "recovery-completeB");
        }
        $in_progressbar->setStatus($connection_id_progress, 80, 100, "Fehler -> Rollback wird durchgeführt!!!", 1);
        
        //tempInstallPath deaktivieren
        session_class::$session_object->setSessionUseTempInstallPath(false);
        $in_progressbar->setStatus($connection_id_progress, 90, 100, "Fehler -> Rollback wird durchgeführt!!!", 1);
        
        $this->addUserFeedback( "rollback", "Alle Änderungen wurden wieder rückgängig gemacht. Sie können die Anwendung wieder unverändert nutzen.", "success");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> rollback', "Alle Änderungen wurden wieder rückgängig gemacht. Sie können die Anwendung wieder unverändert nutzen.");
        writeDebugToFile($this->updatePathApp_abs, "debug_update_error.html");
        $in_progressbar->setStatus($connection_id_progress, 100, 100, "Fehler -> Rollback wird durchgeführt!!!", 1);   
        
    }






    /** Führt eines der DB-Scripte, welche sich im Versions-Paket befinden, aus.
     * 
     * @param   object  $in_pagedata    Referenz auf das pagedata-object
     * @param   string  $in_type        Skript-Typ [before|after|main-install|recovery-complete|recovery-content]
     * @return  integer                 Feedbackmeldungen gemäß Konstantentyp 35 [901|-900|-901|-902|-21]
     */
    protected function executeScript($in_pagedata, $in_type) {
        
        $abort = false;
        $connection_id = $this->app_id;
        $filename = false;
        
        
        if       ($in_type == "before" AND $this->count_commands_before_script > 0) {
            $filename = "script_before_update.sql.zip";
            $path = $this->updatePathApp_abs;
        } elseif ($in_type == "after"  AND $this->count_commands_after_script > 0) {
            $filename = "script_after_update.sql.zip";
            $path = $this->updatePathApp_abs;
        } elseif ($in_type == "main-install-101") {
            //Filename aus Versionnumber bilden
            $filename = $this->versionnumber."_101_".$this->app_id."_".$this->dbms.".sql.zip";
            //Bsp.: $filename = "20190619105344_101_SYS01_postgresql.sql";
            $path = $this->updatePathApp_abs;
        } elseif ($in_type == "main-install-111") {
            //Filename aus Versionnumber bilden
            $filename = $this->versionnumber."_111_".$this->app_id."_".$this->dbms.".sql.zip";
            //Bsp.: $filename = "20190619105344_111_CMS11_postgresql.sql";
            $path = $this->updatePathApp_abs;
        } elseif ($in_type == "main-install-112") {
            //Filename aus Versionnumber bilden
            $filename = $this->versionnumber."_112_".$this->app_id."_".$this->dbms.".sql.zip";
            //Bsp.: $filename = "20190619105344_112_CMS11_postgresql.sql";
            $path = $this->updatePathApp_abs;
            $connection_id = global_variables::getAppIdFromSYS01();
        } elseif ($in_type == "new-install-115") {
            //Filename aus Versionnumber bilden
            $filename = $this->versionnumber."_115_".$this->app_id."_".$this->dbms.".sql.zip";
            //Bsp.: $filename = "20190619105344_115_CMS11_postgresql.sql";
            $path = $this->updatePathApp_abs;
        } elseif ($in_type == "recovery-completeA") {
            $filename = $this->backupfile_completeA;
            $path = $this->recoveryPath_abs.global_variables::getPathForBackups_rel($this->app_id); 
        } elseif ($in_type == "recovery-completeB") {
            $filename = $this->backupfile_completeB;
            $path = $this->recoveryPath_abs.global_variables::getPathForBackups_rel($this->app_id); 
            $connection_id = global_variables::getAppIdFromSYS01();
        } elseif ($in_type == "recovery-contentA") {
            $filename = $this->backupfile_contentA;
            $path = $this->recoveryPath_abs.global_variables::getPathForBackups_rel($this->app_id);    
            $connection_id = global_variables::getAppIdFromSYS01();
        } elseif ($in_type == "recovery-contentB") {
            $filename = $this->backupfile_contentB;
            $path = $this->recoveryPath_abs.global_variables::getPathForBackups_rel($this->app_id);    
        } else {
            //keine Aktion notwendig, da entweder ein unbekanntes Skript aufgerufen wurde oder
            //die Anzahl der Befehle im Skript 0 ist
            $feedback = 0;
            $abort = true;
            $this->addUserFeedback( "führe DB-Script (".$in_type.") aus", "Das Skript enthält keine SQL-Commands. Daher ist keine Aktion notwendig.", "success");
        }
        
        //db_user in Dateiinhalt von $filename eintragen, dadurch wird eine Kopie von $filename angelegt und der filename ändert sich 
        if($filename != false) {
            $filename = replaceStringInFile($path, $filename, true, "[db_user]", $this->db_user);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Skriptname: ', $filename);
        
            if($filename === false) {
                $abort = true;
                $feedback = -901;
                $this->addUserFeedback( "führe DB-Script (".$in_type.") aus", "Der Datenbankbenutzer konnte nicht im Script eingetragen werden. Weitere Details zu diesem Fehler wurden in der Debug-Tabelle abgelegt.", "error");
            }
        }
        
        if($abort !== true) {
            if(extractZipFile($path.$filename, $path) == true) {
                //Wenn Datei vorhanden und erfolgreich entpackt werden konnte
                $filename_unzipped = substr($filename, 0, -4);
                $feedback = executeDbScript($in_pagedata, $path, $filename_unzipped, $connection_id, __FUNCTION__);
                if ($feedback == -21) {$this->addUserFeedback( "führe DB-Script (".$in_type.") aus", "Die Ausführung des Skriptes wurde wegen fehlender Berechtigungen des aktuellen Users für die Maske Update unterbunden.", "error");}
                if ($feedback == -900) {$this->addUserFeedback( "führe DB-Script (".$in_type.") aus", "Die Datei (".$path.$filename_unzipped.") konnte nicht eingelesen werden. Prüfen Sie den Pfad und die Berechtigungen", "error");}
                if ($feedback == -901) {$this->addUserFeedback( "führe DB-Script (".$in_type.") aus", "Die Skriptausführung ist fehlgeschlagen. Details siehe Tabelle Debug", "error");}
                if ($feedback == 901) {$this->addUserFeedback( "führe DB-Script (".$in_type.") aus", "Die Skriptausführung war erfolgreich.", "success");}
            } else {
                $this->addUserFeedback( "execute DB-Script (".$in_type.")", "Das Skript (".$path.$filename.") konnte nicht entpackt werden.", "error");
                $feedback = -902;
            }
        }
            
        if ($feedback < 0) {
            return false;
        } else {
            return true;
        }
        
    }
    
    
    
    
    /** Formt die Versionsnummer so um, wie sie in einigen Dateinamen verwendet wird.
     * Bsp.: aus "20181223212241"   wird: "2018-12-23_21-22-41"
     * 
     * @return string
     */
    protected function buildFilenameFromVersionnumber() {
        $version = $this->versionnumber;
        $year = substr($version, 0, 4);
        $month = substr($version, 4, 2);
        $day = substr($version, 6, 2);
        $hour = substr($version, 8, 2);
        $minute = substr($version, 10, 2);
        $second = substr($version, 12, 4);
        $newFormat = $year."-".$month."-".$day."_".$hour."-".$minute."-".$second;
        //Bsp.: $newFormat = "2018-12-23_21-22-41";
        
        return $newFormat;
        
    }
    
    
    
    
    
    
    /** Erstellt ein Vollbackup (Struktur, Daten und Config der App). Die Daten werden in zwei Dateien abgelegt 
     * (backupfile_completeA und backupfile_completeB)
     * KernelAPP und sonstige App's werden unterschiedlich behandelt.
     * 
     * @param   object  $in_pagedata        Referenz auf das pagedata-object
     * @param   string  $filename_präfix    Präfix, welches im Dateinamen verwendet wird. Dieses sollte während des Update-Prozesses genutzt werden, da sonnst alle Backups den gleichen Namen erhalten.
     * @return  boolean                     Außerdem werden die Eigenschaften $this->backupfile_completeA  und $this->backupfile_completeB belegt.
     */
    protected function makeDB_backup_complete(&$in_pagedata, $filename_präfix) {
        
        $targetPath_rel = global_variables::getPathForRecovery_rel($this->app_id).global_variables::getPathForBackups_rel($this->app_id);
        
        
        if($this->app_id == global_variables::getAppIdFromSYS01()) {
            //Für das Kernsystem muss der Backuptyp 102 verendet werden, weil nur bei diesem die addcontent-Tabellen nicht als solche, sondern als normale Content-Tabellen behandelt werden.
            $backup_mode = 102;
            $backup_description = "Recovery-Backup (complete) für Update: ".$this->versionnumber;
            $feedback_backup = $this->makeDB_backup($in_pagedata, $backup_mode, $targetPath_rel, $backup_description, $filename_präfix."_");
            $this->backupfile_completeA = $feedback_backup;
        } else {
            //Es werden zwei getrennte Backup-Dateien erzeugt, da die jeweiligen Inhalte (zum einen Struktur und Content, zum anderen config und AddContent)
            //in unterschiedlichen Schemata liegen können. Indem Fall kann es notwendig werden, diese mit unterschiedlichen Zugriffsrechten auszuführen.
            
            //Backup_type 4 = Struktur und Daten
            $backup_mode = 4;
            $backup_description = "Recovery-Backup (completeA - structure und content) für Update: ".$this->versionnumber;
            $feedback_backup = $this->makeDB_backup($in_pagedata, $backup_mode, $targetPath_rel, $backup_description, $filename_präfix."A_");
            $this->backupfile_completeA = $feedback_backup;
            
            //Backup_type 105 = Struktur und Daten
            $backup_mode = 105;
            $backup_description = "Recovery-Backup (completeB - config und addContent) für Update: ".$this->versionnumber;
            $feedback_backup = $this->makeDB_backup($in_pagedata, $backup_mode, $targetPath_rel, $backup_description, $filename_präfix."B_");
            $this->backupfile_completeB = $feedback_backup;
        }
        
        
        if ($feedback_backup == false) {
            //Backup konnte nicht erstellt werden.
            $feedback = false;
        } else {
            //Backup wurde erstellt
            $feedback = true;
        }
        
        
        
        return $feedback;
    }
    
    
    
    /** Erstellt ein Backup der Daten (Daten inkl. AddContent der App).
     * KernelAPP und sonstige App's werden unterschiedlich behandelt.
     * 
     * @param   object  $in_pagedata        Referenz auf das pagedata-object
     * @param   string  $filename_präfix    Präfix, welches im Dateinamen verwendet wird. Dieses sollte während des Update-Prozesses genutzt werden, da sonnst alle Backups den gleichen Namen erhalten.
     * @return  boolean
     */
    protected function makeDB_backup_content(&$in_pagedata, $filename_präfix) {
        
        $targetPath_rel = global_variables::getPathForRecovery_rel($this->app_id).global_variables::getPathForBackups_rel($this->app_id);
        
        
        if($this->app_id == global_variables::getAppIdFromSYS01()) {
            //Für das Kernsystem muss der Backuptyp 100 verwendet werden (Update-Unterstützung)
            $backup_mode = 100;
            $backup_description = "Recovery-Backup (content) für Update: ".$this->versionnumber;
            $feedback_backup = $this->makeDB_backup($in_pagedata, $backup_mode, $targetPath_rel, $backup_description, $filename_präfix."_");
            $this->backupfile_contentA = $feedback_backup;
        } else {
            //Es werden zwei getrennte Backup-Dateien erzeugt, da die jeweiligen Inhalte (zum einen Struktur und Content, zum anderen config und AddContent)
            //in unterschiedlichen Schemata liegen können. Indem Fall kann es notwendig werden, diese mit unterschiedlichen Zugriffsrechten auszuführen.
            
            //Backup_type 100 = AddContent- und Konfigurationsdaten in Kernel-DB, ohne sys=1 und Update-Befehle für rewriteColumns
            $backup_mode = 100;
            $backup_description = "Recovery-Backup (Insert für addContent, Config und Update für RewriteColumns) für Update: ".$this->versionnumber;
            $feedback_backup = $this->makeDB_backup($in_pagedata, $backup_mode, $targetPath_rel, $backup_description, $filename_präfix."A_");
            $this->backupfile_contentA = $feedback_backup;
            
            //Backup_type 104 = Contentdaten
            $backup_mode = 104;
            $backup_description = "Recovery-Backup (Insert für Content) für Update: ".$this->versionnumber;
            $feedback_backup = $this->makeDB_backup($in_pagedata, $backup_mode, $targetPath_rel, $backup_description, $filename_präfix."B_");
            $this->backupfile_contentB = $feedback_backup;
        }
        
        
        if ($feedback_backup == false) {
            //Backup konnte nicht erstellt werden.
            $feedback = false;
        } else {
            //Backup wurde erstellt
            $feedback = true;
            
        }
        
        
        
        return $feedback;
    }
    
    
    
    
    
    
    
    /** Erstellt ein Backup mit dem gewünschten Backup-type (siehe Klasse backup_mode)
     * und legt das Ergebnis im target_path ab.
     * 
     * @param   object  $in_pagedata            Referenz auf das pagedata-object
     * @param   integer $in_backup_mode         Backuptyp (Bsp.: 102)
     * @param   string  $in_target_path         rrelative Pfadangabe, in der das Backup abgelegt werden soll. (Bsp.: update/SYS01/recovery/appms/
     * @param   string  $in_description         beliebiger Text, der in der Bckupdatei als Beschreibung vornagestellt wird.
     * @param   string  $in_filename_präfix     Präfix, welches im Dateinamen verwendet wird. Dieses sollte während des Update-Prozesses genutzt werden, da sonnst alle Backups den gleichen Namen erhalten.
     * @return  mixed                           Wenn das Backup erfolgreich erstellt werden konnte, dann wird der Dateiname zurückgegeben, ansonsten false.
     */
    protected function makeDB_backup(&$in_pagedata, $in_backup_mode, $in_target_path, $in_description, $in_filename_präfix) {
        //Dummy-Formulardaten erzeugen, da die Backup_klasse das erwartet.
        $my_formArray["form.app_id"] = global_variables::getAppIdFromSYS01();   //nur notwendig, falls Protokollierung genutzt wird                              
        $my_formArray["form.logging"] = false;
        $targetPath_rel = global_variables::getPathForRecovery_rel($this->app_id).global_variables::getPathForBackups_rel($this->app_id);
        
        $sqlLanguage = getValueFromConfigXml($this->app_id, "dbms");
        $this->dbms = $sqlLanguage;
        
        if($sqlLanguage === false) {
            $feedback = false;
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> config.xml nicht gefunden: ', "Parameter dbms konnte nicht aus dem config-file ausgelesen werden.","ERROR");
        } else {
            $myBackupObject = new backup($this->app_id, $in_backup_mode, $in_description, $sqlLanguage, $my_formArray, $targetPath_rel, false, $in_pagedata, true, $in_filename_präfix);
            //Fehlerbehandlung ist an dieser Stelle nicht möglich, da die Klasse backup das nicht unterstützt.
            $feedback = $myBackupObject->_filename;
        }  
        
        return $feedback;
    }
    
    
    
    
    
    /** Prüft das Alter des Ergenisses in version_check.xml und vergleicht dieses mit dem 
     * Konfigurationsparameter "install_allowed_checkage".
     * 
     * @return  boolean
     */
    protected function checkResultAge() {
        $now = floatval(date("YmdHi"));
        $allowedAge = floatval(getConfig("install_allowed_checkage", $this->app_id));
        $age = $now - floatval($this->checkResultTime);
        
        if($age > $allowedAge) {
            //Prüfergebnis ist nicht mehr gültig
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Prüfergebnis ist zu alt: ', 'now: '.$now.' - checkResultTime: '.$this->checkResultTime.' - Alter des Prüfergebnis: '.$age.' - zulässiges Alter: '.$allowedAge, "ERROR"); 
            $feedback = false;
        } else {
            $feedback = true;
        }
        
        return $feedback;
    }








    /**
     * Kopiert den Inhalt des Installationsordners (aller App's) in den 
     * temporären Installationspfad (recovery)
     * 
     * @return   boolean
     */
    protected function makeRecovery() {
        $recoveryPath = global_variables::getPathForRecovery_abs($this->app_id);
        $this->recoveryPath_abs = $recoveryPath;
        $programFolderList = global_variables::getListOfProgramDirs($this->app_id);
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        $source_path = global_variables::getPathForAppmsinstall_abs(false);
        $permission = global_variables::getDefaultPermissionForFolder();
        
        //Alle Ordner im Installationsverzeichnis, inkl. aller Unterordner kopiern
        foreach ($programFolderList as $currentFolder) {
            $feedback1 = folder_copy($source_path.$currentFolder.$my_DIR_SEP, $recoveryPath.$currentFolder, $permission, true);
        }
        
        //zusätzlich die Dateien (ohne Subfolders) der ersten Ebene aus dem Installationsverzeichnis kopieren.
        $feedback2 = folder_copy($source_path, $recoveryPath, $permission, false);
        
        if($feedback1 == false OR $feedback2 == false) {
            $this->addUserFeedback( "Sicherung erstellen", "Die Kopie des bisherigen Installationsverzeichnisses konnte nicht fehlerfrei angelegt werden. Details können der Debug-Tabelle entnommen werden.", "error");
            return false;
        } else {
            $this->addUserFeedback( "Sicherung erstellen", "Die Kopie des bisherigen Installationsverzeichnisses wurde angelegt.", "success");
            return true;
        }
        
    }
    
    
    
    /**
     * Erstellt das checkResultFile. In dieser Datei wird das Ergebnis der Prüfung des Installationspaketes abgelegt,
     * damit es persistent wird.
     * 
     * @param   string  $in_updatePathApp_abs
     */
    protected function createCheckResultFile($in_updatePathApp_abs) {
        
        
        //xml-File erstellen
        $myCheckResult = "".
                "<?xml version='1.0' standalone='yes'?>\r\n".
                    "<category>\r\n".
                        "<checkResult>\r\n".
                            "<app>".$this->app_id."</app>\r\n".	
                            "<version>".$this->versionnumber."</version>\r\n".
                            "<result>success</result>\r\n".
                            "<checkTime>".date("YmdHi")."</checkTime>\r\n".
                            "<is_reinstall>".$this->is_reinstall."</is_reinstall>\r\n".
                            "<is_wikiinstall>".$this->is_wiki_install."</is_wikiinstall>\r\n".
                        "</checkResult>\r\n".
                        "<metadata>\r\n".
                            "<recoverypath_abs>".$this->recoveryPath_abs."</recoverypath_abs>\r\n".
                            "<updatepath_abs>".$this->updatePath_abs."</updatepath_abs>\r\n".
                            "<updatepathapp_abs>".$in_updatePathApp_abs."</updatepathapp_abs>\r\n".
                            "<updatefilename>".$this->updateFilename."</updatefilename>\r\n".
                        "</metadata>\r\n".
                    "</category>\r\n";
        
        
        //xml-Datei in Version-Dir schreiben
        $feedback = writeFile($this->updatePath_abs, global_variables::getNameOfVersionCheckFile(), $myCheckResult);
        
    }
    
    
    
    /** Schreibt eine neue Konfigurationsdatei
     * 
     * @param string $in_path_abs       Pfad zum Config-Ordner innerhalb des data-Verzeichniss der APP
     * @param string $in_fileTemplate   Template der Configdatei (bspw. config_default.xml)
     * @param string $in_fileTarget     Name der Configdatei (bspw. config.xml)
     * @param string $in_app_id         
     * @param string $in_dbms           postgresql | mysql
     * @param string $in_host
     * @param string $in_port
     * @param string $in_dbname
     * @param string $in_user
     * @param string $in_password
     * @param string $in_encoding       [optional] Codierung QL_ASCII, EUC_JP, EUC_CN, EUC_KR, EUC_TW, UNICODE, MULE_INTERNAL, LATINX (X=1...9), KOI8, WIN, ALT, SJIS, BIG5 or WIN1250; Default = UNICODE
     * @return boolean
     */
    public function createNewConfigXml($in_path_abs, $in_fileTemplate, $in_fileTarget, $in_app_id, $in_dbms, $in_host, $in_port, $in_dbname, $in_user, $in_password, $in_encoding ="") {
        $dirSEP = global_variables::getDirectorySeparator();
        
        if (file_exists($in_path_abs.$dirSEP.$in_fileTemplate)) {
            $file_content = file_get_contents($in_path_abs.$dirSEP.$in_fileTemplate);
            $file_content = str_replace("<dbms>postgresql</dbms>", "<dbms>".$in_dbms."</dbms>", $file_content);
            $file_content = str_replace("<host>localhost</host>", "<host>".$in_host."</host>", $file_content);
            $file_content = str_replace("<port>5432</port>", "<port>".$in_port."</port>", $file_content);
            $file_content = str_replace("<dbname>my_database</dbname>", "<dbname>".$in_dbname."</dbname>", $file_content);
            $file_content = str_replace("<user>my_user</user>", "<user>".$in_user."</user>", $file_content);
            $file_content = str_replace("<password>my_password</password>", "<password>".$in_password."</password>", $file_content);
            if($in_encoding != "") {$file_content = str_replace("# <encoding>UNICODE</encoding>", "<encoding>".$in_encoding."</encoding>", $file_content);}
            writeFile($in_path_abs.$dirSEP, $in_fileTarget, $file_content);
            
            $feedback = true;
            
        } else {
            $feedback = false;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ', $in_path_abs.$in_fileTemplate." existiert nicht");
        }
        
 
        
        return $feedback;
        
        
        
    }
    
    
    
    
    
    /** Die Funktion ergänzt eine Meldung zu den vorhanden Meldungen für ein Feld.
     * 
     * @param   string  $in_topic           Thema der Meldung
     * @param   string  $in_Message         Text der Meldung
     * @param   string  $in_Messagetype     Art der Meldung [error|success|other]
     *                                      error -> roter Schriftzug "error" wird ergänzt
     *                                      success -> grüner Schriftzug "ok" wird ergänzt
     *                                      info -> nichts wird ergänzt
     */
    protected function addUserFeedback($in_topic, $in_Message, $in_Messagetype) {
        if($in_Messagetype == "error") {
            $präfix = " -> <b><font color=\"red\">ERROR</font></b>";
            $debug_type = "ERROR";
        } elseif($in_Messagetype == "success") {
            $präfix = " -> <b><font color=\"green\">OK</font></b>";
            $debug_type = "INFO";
        } elseif($in_Messagetype == "info") {
            $präfix = " -> <b><font color=\"orange\">INFO</font></b>";
            $debug_type = "INFO";
        } else {
            $präfix = "";
        }
        
        $suffix = "<b>".$in_topic.": </b>";
        
        
        $this->userFeedback = $this->userFeedback."<li>".$suffix.$präfix."</li>";
        $this->userFeedback = $this->userFeedback."<li>".$in_Message."</li><br />";
        
        //zusätzlich Debug-Meldung, falls Oberfläche nicht mehr reagiert
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Status: ', $in_Message, $debug_type);
        
    }
    
    
    
    /**
     * liest die Prüfergebnisse aus der letzten Installationsvorbereitung aus und
     * legt die in den entsprechenden Eigenschaften dieses Objektes ab..
     * Die Prüfergebnisse sind in der Datei version_check.xml abgelegt.
     * 
     * @return  booelan     true, wenn das Prüfergebnis "success" aus version_check.xml ausgelesen werden konnte
     */
    protected function readCheckResult() {
        $this->updatePath_abs = global_variables::getPathForUpdate_abs();
        $nameOfVersionCheckFile = global_variables::getNameOfVersionCheckFile();
        
        if (file_exists($this->updatePath_abs.$nameOfVersionCheckFile)) {
            $version_check_file = new SimpleXMLElement($this->updatePath_abs.$nameOfVersionCheckFile,0,true);
            
            $this->app_id =             $version_check_file->checkResult->app->__toString();
            $this->versionnumber =      $version_check_file->checkResult->version->__toString();
            $this->checkResultTime =    $version_check_file->checkResult->checkTime->__toString();
            $this->is_reinstall =       $version_check_file->checkResult->is_reinstall->__toString();
            $this->is_wiki_install =    $version_check_file->checkResult->is_wikiinstall->__toString();
            $this->recoveryPath_abs =   $version_check_file->metadata->{'recoverypath_abs'}->__toString();
            $this->updateFilename =     $version_check_file->metadata->{'updatefilename'}->__toString();
            $this->updatePathApp_abs =  $version_check_file->metadata->{'updatepathapp_abs'}->__toString();
            $this->updatePath_abs =     $version_check_file->metadata->{'updatepath_abs'}->__toString();
            
            
            if($version_check_file->checkResult->result->__toString() == "success") {
                $feedback = true;
            } else {
                $feedback = false;
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Prüfergebnis ", "Der vorherige Prozesschritt -Update prüfen' hatte Fehler aufgezeigt." , "INFO");
            }
            
        } else {
            $feedback = false;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> version_check.xml", "Die Datei ".$this->updatePath_abs.$nameOfVersionCheckFile." existiert nicht.", "INFO");
        }
        
 
        
        return $feedback;
    }
    
    
    
    
    /** Diese Funktion prüft die Versionskompatibilität des Installationspaketes zur
     * installierten APP und der Kernel-APP. Bei Problemen wird sofort eine Ausnahme geworfen
     * 
     * @throws Exception
     */
    protected function checkVersionCompatiblity() {

        $compatibleVersionnumber = $this->versionnumber_compatible;
        
        
        //version-compatiblity zur selben App prüfen
        $currentInstalledVersion = getVersionnumberFromApp($this->app_id);
        if($currentInstalledVersion < $compatibleVersionnumber AND $currentInstalledVersion != false) {
            //die aktuell installierte APP ist mit dem Installationspaket nicht kompatibel
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Kompatibilitätsproblem', "APP: ".$this->app_id." - installierte Version: ".$currentInstalledVersion." - Version des Installationspaketes: ".$this->versionnumber." - Installationspaket ist abwärtskompatibel bis: ".$compatibleVersionnumber);
            $this->addUserFeedback( "Versionskompatibilität prüfen","Die installierte Version der APP ".$this->app_id.
                                    " ist nicht kompatibel mit dem Installationspaket. <br />".
                                    "installierte Version: ".$currentInstalledVersion."<br />".
                                    "Abwärtskompatibilität des Installationspaketes: ".$compatibleVersionnumber, "error");
            throw new Exception(-163);
        } elseif($currentInstalledVersion > $this->versionnumber) { 
            //die aktuell installierte APP ist bereits aktueller, als das Installationspaket
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Kompatibilitätsproblem', "APP: ".$this->app_id." - installierte Version: ".$currentInstalledVersion." - Version des Installationspaketes: ".$this->versionnumber." -> die installierte Version ist aktueller.");
            $this->addUserFeedback( "Versionskompatibilität prüfen","Die installierte Version der APP ".$this->app_id.
                                    " ist bereits aktueller, als das Installationspaket. <br />".
                                    "installierte Version: ".$currentInstalledVersion."<br />".
                                    "Version des Installationspaketes: ".$this->versionnumber, "error");
            throw new Exception(-164);
        } else {
            //Installationspaket ist kompatibel oder ist identisch mit der vorhanden Installation (Reparatur)
            if($currentInstalledVersion == $this->versionnumber) {
                $this->is_reinstall = true;
                $this->is_new_install = false;
                $this->addUserFeedback( "Versionskompatibilität prüfen","Das Installationspaket ist bereits installiert. Die Installation kann fortgesetzt werden. Die Installation wird dann im Reparaturmodus durchgeführt. D.h., dass nicht alle Arbeitsschritte ausgeführt werden. Darauf wird jeweils einzeln, während der Installation, hingewiesen.", "success");
            } elseif($currentInstalledVersion === false) {
                $this->is_reinstall = false;
                $this->is_new_install = true;
                $this->addUserFeedback( "Versionskompatibilität prüfen","Installation einer neuen App, daher bestehen keine Kompatibilitätsprobleme zu einer vorherigen Version.", "success");
            } else {
                $this->is_reinstall = false;
                $this->is_new_install = false;
                $this->addUserFeedback( "Versionskompatibilität prüfen","Das Installationspaket ist kompatibel zur installierten Version", "success");
            }
            
        }
        

        //version-compatiblity zur Kernel-App prüfen
        $kernelAppId = global_variables::getAppIdFromSYS01();
        $currentInstalledKernelVersion = getVersionnumberFromApp($kernelAppId);
        $neededKernelVersion = $this->versionnummber_kernel_needed;
        $compatibleKernelVersionnumber = $this->versionnummber_kernel_compatible;
        
        if($currentInstalledKernelVersion < $compatibleKernelVersionnumber) {
            //die aktuell installierte Kernel-APP ist zu alt
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Kompatibilitätsproblem', "APP: ".$this->app_id." - installierte Version der Kernel-APP: ".$currentInstalledKernelVersion." - benötigte Version der Kernel-APP: ".$compatibleKernelVersionnumber);
            $this->addUserFeedback( "Versionskompatibilität (Kernel) prüfen","Die installierte Version der  Kernel-APP ".$kernelAppId.
                                    " ist zu alt. <br />".
                                    "installierte Kernel-Version: ".$currentInstalledKernelVersion."<br />".
                                    "kompatible Version der Kernel-APP: ".$compatibleKernelVersionnumber, "error");
            throw new Exception(-165);
        } elseif($neededKernelVersion < $currentInstalledKernelVersion) { 
            //die aktuell installierte Kernel-APP ist zu neu.
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Kompatibilitätsproblem', "APP: ".$this->app_id." - installierte Version der Kernel-APP: ".$currentInstalledKernelVersion." - benötigte Version der Kernel-APP: ".$neededKernelVersion." -> die Kernel-APP ist zu neu!");
//            $this->addUserFeedback( "Versionskompatibilität (Kernel) prüfen","Die installierte Version der der Kernel-APP ".$kernelAppId.
//                                    " ist zu neu. <br />".
//                                    "installierte Kernel-Version: ".$currentInstalledKernelVersion."<br />".
//                                    "kompatible Version der Kernel-APP: ".$compatibleKernelVersionnumber." bis ".$neededKernelVersion, "error");
//            throw new Exception(-166);
            $this->addUserFeedback( "Versionskompatibilität (Kernel) prüfen","Die installierte Version der der Kernel-APP ".$kernelAppId.
                        " ist neuer, als die mit der das Installationspaket erstellt wurde. <br />".
                        " Sie können mit der Installation fortfahren. Sollte ein Fehler auftreten, wird ein Rollback durchgeführt <br><br>".
                        "installierte Kernel-Version: ".$currentInstalledKernelVersion."<br />".
                        "kompatible Version der Kernel-APP: ".$compatibleKernelVersionnumber." bis ".$neededKernelVersion, "info");
        } else {
            //Installationspaket ist kompatibel
            $this->addUserFeedback( "check compatibility Kernel","Das Installationspaket ist kompatibel zur installierten Kernel-Version", "success");
        }
        
    }
    
    
    
    
    
    
    
    /** Liest die Werte aus der Version_info.xml ein und hinterlegt diese in den 
     * entsprechenden Eigenschaften dieser Klasse.
     * 
     * Voraussetzungen: Die Eigenschaft $this->updateFilename muss bereits belegt sein.
     *                  
     * @param   string  $in_updatepath_abs                       
     * @return  boolean         True, wenn die Werte ausgelesen werden konnten.
     *                          False, wenn die Datei nicht geöffnet werden konnte. 
     */
    protected function readVersionInfoFile($in_updatepath_abs) {
        //version_info.xml entpacken
        $nameOfVersionInfoFile = global_variables::getNameOfVersionInfoFile();
        if(extractZipFile($in_updatepath_abs.$this->updateFilename, $in_updatepath_abs, array($nameOfVersionInfoFile)) == false) {
            $this->addUserFeedback("Version-Info-Datei entpacken","Die Datei (".$in_updatepath_abs.$this->updateFilename.") konnte nicht entpackt werden.", "error");
            $feedback = false;
        } else {
            $this->addUserFeedback("Version-Info-Datei entpacken","Die Datei wurde entpackt.", "success");
            $feedback = true;
        }
        
        //APP des Installtionspaketes ermitteln
        $version_info_file = new SimpleXMLElement(file_get_contents($in_updatepath_abs.$nameOfVersionInfoFile));
        $this->app_id = $version_info_file->version->app->__toString();
        $this->versionnumber = $version_info_file->version->version->__toString();
        $this->versionnumber_compatible = $version_info_file->version->compatible_with_version->__toString();
        $this->versionnummber_kernel_needed = $version_info_file->version->needed_kernel_version->__toString();
        $this->versionnummber_kernel_compatible = $version_info_file->version->compatible_with_kernel->__toString();
        $this->count_commands_before_script = $version_info_file->version->count_commands_before_script->__toString();
        $this->count_commands_after_script = $version_info_file->version->count_commands_after_script->__toString();
        
        
        return $feedback;
    }
    
    
    
    /** holt die hochgeladene Datei aus $_FILES und verschiebt sie an den Zielordner.
     * 
     * @return  integer         Feedback-Meldung gemäß konstantentyp_id = 35 [150|-150|-151]
     */
    protected function moveUpdatepacket() {
        $updatePath = global_variables::getPathForUpdate_abs();
        $this->updatePath_abs = $updatePath;
        
        //FileUpload in den Zielordner verschieben
        try {
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  _FILES', $_FILES);
            reset($_FILES); 
            $current_file = current($_FILES);
            $myUpload = new fileUpload();
            $myUpload->moveFileToFilesystem($updatePath, "zip", $this->app_id, $current_file);
            $this->updateFilename = $myUpload->getFilename();
            $this->addUserFeedback("Installationspaket hochladen","Die Datei (".$this->updateFilename.") wurde hochgeladen", "success");
            $feedback = 150;
        } catch (Exception $exc) {
            $feedback = $exc->getMessage();
            if($feedback == -152) {
                $this->addUserFeedback("Installationspaket hochladen","Es wurde keine Datei am Server empfangen. Möglicherweise hat die gewählte Datei die zulässige Maximalgröße überschritten. Prüfen Sie dazu die Einstellung am Server (php.ini -> post_max_size, upload_max_filesize und memory_limit)", "error");
            } elseif($feedback == -153) {
                $this->addUserFeedback("Installationspaket hochladen","Es wurde keine Datei am Server empfangen. Die Datei hat die zulässige Maximalgröße überschritten. Prüfen Sie dazu die Einstellung am Server (php.ini -> post_max_size, upload_max_filesize und memory_limit)", "error");
            } else {
                $this->addUserFeedback("Installationspaket hochladen","Die Datei (".$this->updateFilename.") konnte nicht hochgeladen werden", "error");
            }
        }
        return $feedback;
    }
    
    
    
   
    
    
    
    /**
     * Kopiert alle Dateien und Unterordner der aus einem Versionsordner (neue Version (install) oder Wiederherstellung (recovery)) in den Original-Installationsordner.
     * Vorhandene Dateien werden nicht gelöscht, sondern ergänzt oder überschrieben.
     * Im Unix-OS werden die Dateien und Ordner mit Standard-Zugriffsrechten  (siehe getDefaultPermissionForFolder)
     * versehen. 
     * Im Windows-OS werden die Rechte nicht angefasst.
     * 
     * @param   string      $in_modus   mögliche Werte: [install|recovery]
     * @return  boolean
     */
    protected function copyVersionFilesToInstallFolder($in_modus) {
        $feedback1 = true;
        $feedback2 = true;
        
        $programFolderList = global_variables::getListOfProgramDirs($this->app_id);
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        
        if($in_modus == "install") {
            //Update-Ordner als Source
            $source_path = $this->updatePathApp_abs.global_variables::getNameOfInstallFolder().$my_DIR_SEP;
            $user_feedback_error = "Die neuen Programmdateien konnten nicht fehlerfrei in das Installationsverzeichnis kopiert werden. Details wurden in der Debug-Tabelle vermerkt.";
            $user_feedback_success = "Die neuen Programmdateien wurden in den Installationsordner kopiert.";
        } else {
            //Recovery-Ordner als Source
            $source_path = $this->recoveryPath_abs;
            $user_feedback_error = "Die alten Programmdatein konnten nicht wiederhergestellt werden. Das System befindet sich vermutlich in einem unstabilen Zustand. Ggf. kann es manuell mit Hilfe der Datensicherung in ".$source_path." wiederhergestellt werden.";
            $user_feedback_success = "Die alten Programmdateien wurden wiederhergestellt.";
        }
        //permission
        $permission = global_variables::getDefaultPermissionForFolder();
        
        //Origin-Install-Ordner als target
        $installPath = global_variables::getPathForAppmsinstallOrigin_abs();
        
        //Alle Ordner im Installationsverzeichnis, inkl. aller Unterordner kopieren
        foreach ($programFolderList as $currentFolder) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> '.$in_modus, "Von: ".$source_path.$currentFolder.$my_DIR_SEP." - nach: ".$installPath.$currentFolder,"INFO");
            $feedback1 = folder_copy($source_path.$currentFolder.$my_DIR_SEP, $installPath.$currentFolder, $permission, true);
            if($feedback1 == false) {break;}
        }
        
        //zusätzlich die Dateien (ohne Subfolders) der ersten Ebene aus dem Installationsverzeichnis kopieren.
        if($this->app_id == global_variables::getAppIdFromSYS01()) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> '.$in_modus, "Von: ".$source_path." - nach: ".$installPath,"INFO");
            $feedback2 = folder_copy($source_path, $installPath, $permission, false);
        }
        
        
        
        if($feedback1 == false OR $feedback2 == false) {
            $this->addUserFeedback( $in_modus, $user_feedback_error, "error");
            return false;            
        } else {
            $this->addUserFeedback( $in_modus, $user_feedback_success, "success");
            return true;
        }
        
    }
    
    
    
    /** Kopiert alle Wiki-Dateien in den Installationsordner
     * 
     * @return boolean
     */
    protected function copyWikiFilesToInstallFolder() {
        $feedback1 = true;
        $feedback2 = true;
        
        $programFolderList = global_variables::getListOfWikiDirs($this->app_id);
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        
        
        //Update-Ordner als Source
        $source_path = $this->updatePathApp_abs;
        $user_feedback_error = "Die neuen Wiki-Dateien konnten nicht fehlerfrei in das Installationsverzeichnis kopiert werden. Details wurden in der Debug-Tabelle vermerkt.";
        $user_feedback_success = "Die neuen Wiki-Dateien wurden in den Installationsordner kopiert.";
        
        //permission
        $permission = global_variables::getDefaultPermissionForFolder();
        
        //Origin-Install-Ordner als target
        $installPath = global_variables::getPathForAppmsinstallOrigin_abs().global_variables::getNameOfWikiDir().$my_DIR_SEP;
        
        //Alle Ordner im Installationsverzeichnis, inkl. aller Unterordner kopieren
        foreach ($programFolderList as $currentFolder) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "Von: ".$source_path.$currentFolder.$my_DIR_SEP." - nach: ".$installPath.$currentFolder,"INFO");
            $feedback1 = folder_copy($source_path.$currentFolder.$my_DIR_SEP, $installPath.$currentFolder, $permission, true);
            if($feedback1 == false) {break;}
        }
        
        //zusätzlich die Dateien (ohne Subfolders) der ersten Ebene aus dem Installationsverzeichnis kopieren.
        if($this->app_id == global_variables::getAppIdFromSYS01()) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "Von: ".$source_path." - nach: ".$installPath,"INFO");
            $feedback2 = folder_copy($source_path, $installPath, $permission, false);
        }
        
        
        
        if($feedback1 == false OR $feedback2 == false) {
            $this->addUserFeedback( "Wiki-Install", $user_feedback_error, "error");
            return false;            
        } else {
            $this->addUserFeedback( "Wiki-Install", $user_feedback_success, "success");
            return true;
        }
        
    }
    
    
    
    
    /** Sucht im entpackten Installationspakte nach forbidden-files (siehe Config-Param upload-forbidden-files)
     * 
     * @param  string   $in_search_path     absoluter Pfad
     * @param  boolean  $in_update_wiki     Gibt an, ob das Wiki aktualisiert wird
     * @return boolean                      Gibt false zurück, wenn forbidden-Files gefunden wurden.
     */
    protected function search_ForbiddenFiles($in_search_path, $in_update_wiki) {
        $feedback1 = true;
        $feedback2 = true;
        
        if($in_update_wiki === true) {
            $add_wiki = "_wiki";
            $programFolderList = global_variables::getListOfWikiDirs($this->app_id);
        } else {
            $add_wiki = "";
            $programFolderList = global_variables::getListOfProgramDirs($this->app_id);
        }
        
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        
        //geprüft wird das entpackte Installationspaket
        $check_path = $in_search_path;
        $user_feedback_error = "Es wurden verbotene Dateien (siehe Konfigurationsparameter upload_forbidden_files) im Installationspaket entdeckt. Hinweis: die htaccess-Datei ist nur auf oberster Ebene erlaubt.";
        $user_feedback_success = "In dem Installationspaket wurden keine unzulässigen Dateien entdeckt (siehe Konfigurationsparameter upload_forbidden_files).";
        
        $forbidden_files = getConfig("upload_forbidden_files".$add_wiki, global_variables::getAppIdFromSYS01());
        
        
        //Alle Ordner im Updateverzeichnis, inkl. aller Unterordner prüfen
        foreach ($programFolderList as $currentFolder) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> ', "Suche forbidden Files in: ".$check_path.$currentFolder.$my_DIR_SEP,"INFO");
            $feedback1 = searchForForbiddenFiles($check_path.$currentFolder.$my_DIR_SEP, $forbidden_files, true);
            if($feedback1 == false) {break;}
        }
        
        //zusätzlich die Dateien (ohne Subfolders) der ersten Ebene aus dem Installationsverzeichnis prüfen.
        //Auf dieser Ebene ist jedoch die htaccess-Datei zulässig
        $forbidden_files = str_replace(".htaccess", "", $forbidden_files);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> ', "Suche forbidden Files in: ".$check_path,"INFO");
        $feedback2 = searchForForbiddenFiles($check_path, $forbidden_files, false);
        
        
        if($feedback1 == false OR $feedback2 == false) {
            $this->addUserFeedback( "Suche nach forbidden-files", $user_feedback_error, "error");
            return false;            
        } else {
            $this->addUserFeedback( "Suche nach forbidden-files", $user_feedback_success, "success");
            return true;
        }
        
    }
    
    
    
    
    /** Leert den Recovery-Ordner oder legt diesen an, falls er noch nicht existiert.
     * 
     * @return  boolean
     */
    protected function clearUpdateDir() {
        $updateDir = $this->updatePathApp_abs;
        
        
        if(file_exists($updateDir) == false) {
            //RecoveryDir anlegen, wenn es noch nicht existiert
            $permission = global_variables::getDefaultPermissionForFolder();
            mkdir($updateDir, octdec($permission), true); 
            $feedback = true;
        } else {
            //Dateien und Verzeichnisse im Ordner löschen
            $feedback = clearFolder($updateDir, true, array());
            if($feedback == true) {
                $this->addUserFeedback( "Update-Verzeichnis aufräumen", "Alte Sicherungen im Recovery-Verzeichnis wurden gelöscht.", "success");
            } else {
                $this->addUserFeedback( "Update-Verzeichnis aufräumen", "Eine alte Sicherung im Recovery-Verzeichnis konnte nicht gelöscht werden.", "error");
            }
        }
        return $feedback;
    }
}
