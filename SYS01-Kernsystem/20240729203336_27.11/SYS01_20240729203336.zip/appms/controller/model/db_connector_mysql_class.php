<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */



/** Für jede DB-spezifische-Connector-KLasse muss ein eigener Namespace definiert werden (virtueller Ordner).
 * Der Namespace muss der Dateinamekonvention folgen und er muss mit dem gewählten Namespace in der zugehörigen
 * backup-Klasse übereinstimmen.
 * 
 * Bsp. Wenn DBMS =  Postgres:
 * 
 * Dann:
 * DBMS-Parameter in config.xml = postgresql
 * Dateiname für die DB-spezifischen Klassen = backup_postgresql_class.php
 * namespace in dieser Datei = postgresql
 * Eintrag in Konstantenkatalog (konstantentyp_id = 50) = postgresql
 */
namespace mysql;



/**
 * Description of db_connector_class
 *
 */
class db_connector implements \db_connector_interface {
    
    /** Verbindung zur Datenbank vom Typ mysqli_connect
     *
     * @var     resource        siehe mysqli_connect 
     */
    protected $_dbConnection;
    
    
    
    
    /** Erstellt eine Verbinudng zur Datenbank und stellt sichere MySqlfunktionen für SELECT, 
     * INSERT, UPDATE und DELETE bereit.
     * 
     * @param string    $in_host
     * @param string    $in_port
     * @param string    $in_db_name
     * @param string    $in_user
     * @param string    $in_password
     * @param string    $in_encoding                Kodierung bei postgresql. Default ist UTF8/UNICODE. Wenn dieser Wert DBMS-unabhängig gewählt werden soll, dann an dieser Stelle inen Leerstring übergeben.
     *                                              Ansonsten, mögliche Werte: SQL_ASCII, EUC_JP, EUC_CN, EUC_KR, EUC_TW, UNICODE, MULE_INTERNAL, LATINX (X=1...9), KOI8, WIN, ALT, SJIS, BIG5 or WIN1250. 
     * @param boolean   $in_force_new_connection    Dieser Parameter hat nur bei postgres eine Funktion.
     */
    public function __construct($in_host, $in_port, $in_db_name, $in_user, $in_password, $in_encoding, $in_force_new_connection = false) {
       
        $dbconn = mysqli_connect($in_host, $in_user, $in_password, $in_db_name, intval($in_port));
        
        /* change character set to utf8 */
        if (!mysqli_set_charset($dbconn, "utf8")) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "MySql-Standard-Codierung konnte nicht auf UTF8 gesetzt werden.","ERROR");
        } 
        $this->_dbConnection = $dbconn;
        
    }
    
    
    
    /** Gibt die Datenbankverbindung als resource zurück
     * 
     * @return  resource            vom Typ mysqli_connect
     */
    public function getDbConnection() {
        return $this->_dbConnection;
    }
    
    
    
    /**
     * Schließt eine Datenbankverbindung wieder.
     * Hinweis aus der PHP-Doku: 
     * Die Verwendung von pg_close() ist normalerweise nicht notwendig, 
     * da geöffnete, nicht-persistente Verbindungen automatisch geschlossen werden, 
     * wenn das Skript beendet wird.
     * 
     * Diese Methode ist hilfreich, wenn die Verbindung lediglich getestet wird.
     */
    public function close_connection() {
        if ($this->_dbConnection) {
            // Database is reachable
            mysqli_close($this->_dbConnection);
        }
        
    }
    

    
    
    /** Sendet einen Select-Befehl an eine Postgres-Datenbank. Dazu muss ein Array mit den Werten schema, table, into und values  übergeben werden.
    * 
    * @param   string $in_sql_string       SQL-Befehl, der ausgeführt werden soll. Der Befehl kann beliebig verschachtelt sein, darf aber nur ein Statement (Semikolon) enthalten. Weitere Semikolon werden aus Sicherheitsgründen entfernt.
    * @param   string $in_callFromFunction Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.
    * @param   bool   $in_print_to_debug   Gibt an, ob der SQL-Befehl in der Debugausgabe abgelegt werden soll.
    * @return  mixed                       Der Rückgabewert ist entweder ein zweidimensionales Array (Tabellenstruktur) oder Boolean (false), wenn kein Ergebnis vorliegt. Auf die Ergebnisse kann mit array[$i] [$table.".".$field] zugegriffen werden.
    */
    function executeSelect($in_sql_string, $in_callFromFunction, $print_to_debug = false) {														
        $lastError = "";
        $query = $in_sql_string;
        //$query = $this->makeSecureSQL($query, $in_callFromFunction);          //führt  zu zu langen Bearbeitungszeiten  
        

        //ACHTUNG: die folgende Debug-Zeile verursacht sehr viele Protokollsätze
        if($print_to_debug == true) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Select; aufrufende Funktion: ', $in_callFromFunction.', SQL-Befehl: '.$query, 'INFO');
        }
        //echo $query."<br />";
        $result = @mysqli_query($this->_dbConnection, $query);
        //Achtung an dieser Stelle kann es ohne @-Zeichen im Browser zur Fehlermeldung kommen, wenn Error_reprting eingeschaltet ist.
        //Dabei muss es sich nicht um echte Fehler handeln, sondern es könnte ich um Queries handeln, welche von Ihren Trigger-Felder keine Werte erhalten haben.
        //Zum Testen in query_class.getResultForSql die Echo-Meldung ausgeben.
        
        
        
        //Resultset in zweidimensionales Array umwandeln
        if ($result != false) {	
                $result_rows = mysqli_num_rows($result);
                $ergebnisList = Array();
                $columnCount = mysqli_num_fields($result);

                for ($i = 0; $i < $result_rows; $i++) {
                        $row = mysqli_fetch_array($result);
                        for ($column = 0; $column < $columnCount; $column++) {
                            
                            $finfo = mysqli_fetch_field_direct($result, $column);
                            $table = $finfo->table;

                            $field = $finfo->name;
                            $ergebnisList[$i] ["$table.$field"] = $row[$column];
                        }
                }


        } else {
            $lastError = mysqli_error($this->_dbConnection);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlermeldung SQL nach Aufruf von: '.$in_callFromFunction, $lastError, "ERROR");
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> fehlgeschlagener SQL-Befehl: '.$query, 'ERROR');
            addToDebugSqlError($lastError, $query, $in_callFromFunction);
            $ergebnisList = false;                                              //Wenn result leer ist, greift diese Bedingung nicht!
        }	
        
        
        
        return $ergebnisList;

    }    
    
    
    
    
    
    
    /** Sendet einen Insert-Befehl an eine Postgres-Datenbank. Dazu muss ein Array mit den Werten schema, table, into und values  übergeben werden.
    * 
    * @param    Array   $in_SqlDaten            Array mit dem Strukturellen Aufbau, wie es die Funktion extractDataFromPostarray erzeugt.
    * @param    string  $in_callFromFunction    Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
    * @param    boolean $in_updateSequence      Dieser Paramter wird im mysql-Connector nicht verwendet. Er ist nur aufgrund der Kompatibilität zu postgres vorhanden.
    * @return   Boolean 
    */
    function executeInsert($in_SqlDaten, $in_callFromFunction, $in_updateSequence = true) {
        //----------------------------------------------------------------------
        //Warnung !!!: 
        //In dieser Funktion niemals addToDebug nutzen, da es sonst 
        //zu einem Zirkelbezug mit den nutzenden Funktionen (bspw. insertDebugData 
        //setLogData) kommt. In der Folge kommt es 
        //zu einem Speicherüberlauf.
        //----------------------------------------------------------------------
        
        
        $schema = $in_SqlDaten["schema"];
        $table = $in_SqlDaten["table"];
        $into = $in_SqlDaten["into"];
        $values = $in_SqlDaten["values"];
        //$where = $in_SqlDaten["where"];

        $query = "INSERT INTO $schema.$table ($into) VALUES ($values)";											//Insert-Befehl
//      ACHTUNG:    hier nicht mit addToDebug arbeiten, da sonst eine Endlosschleife entsteht!
//                  Stattdessen den folgenden ECHO-Befehl nutzen und gleichzeitig den debug-Konfigurationsparameter auf 0 setzen!
//        echo $query."<br /><br />";
        $query = $this->makeSecureSQL($query, $in_callFromFunction); 

        $result = mysqli_query($this->_dbConnection, $query);
        															//Abfrage ausf�hren
//        echo "Feedback für Insert: ".print_r($result)."<br />";
        if ($result == false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlermeldung SQL nach Aufruf von: '.$in_callFromFunction, mysqli_error($this->_dbConnection), "ERROR");
//            echo "Fehler bei SQL-Ausführung: <br />".$query."<br /><br />";   
            return false;
            
        } else {
            return true;
        }

    }
    
    
    
    /** ACHTUNG: Diese Funktion darf nur ausnahmsweise, bspw. während des Update-Prozesses,
     *           genutzt werden. Durch die Ausführung eines Skriptes werden diverse
     *           Sicherheitsmechanismen umgegangen. Es muss sichergestellt werden, dass
     *           nur vertrauenswürdige Scripte ausgeführt werden.
     * 
     * @param   string      $in_Script              Liste von SQL-Befehlen
     * @param   string      $in_callFromFunction    Name der aufrufenden Funktion
     * @return  boolean
     */
    function executeScript($in_Script, $in_callFromFunction) {
        //----------------------------------------------------------------------
        //Warnung !!!: 
        //In dieser Funktion niemals unbedacht addToDebug nutzen, da es sonst 
        //zu einem Zirkelbezug mit den nutzenden Funktionen (bspw. insertDebugData 
        //setLogData) kommen kann. In der Folge kommt es 
        //zu einem Speicherüberlauf.
        //----------------------------------------------------------------------
        
        

        $query = $in_Script;											//Insert-Befehl
//      ACHTUNG:    hier nicht mit addToDebug arbeiten, da sonst eine Endlosschleife entsteht!
//                  Stattdessen den folgenden ECHO-Befehl nutzen und gleichzeitig den debug-Konfigurationsparameter auf 0 setzen!
//        echo $query."<br /><br />";
        
        
        $result = mysqli_query($this->_dbConnection, $query);
//        echo "Feedback für Insert: ".print_r($result)."<br />";
        if ($result == false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlermeldung SQL nach Aufruf von: '.$in_callFromFunction, mysqli_error($this->_dbConnection), "ERROR");
//            echo "Fehler bei SQL-Ausführung: <br />".$query."<br /><br />";  
            return false;
            
        } else {
            return true;
        }

    }
    
    
    
    /** Sendet einen Delete-Befehl an eine Postgres-Datenbank. Dazu muss ein Array mit den Werten schema, table und where  übergeben werden.
    * 
    * @param    Array   $in_SqlDaten            Array mit dem Strukturellen Aufbau, wie es die Funktion extractDataFromPostarray erzeugt.
    * @param    string  $in_callFromFunction    Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
    * @return   Boolean 
    */
    function executeDelete($in_SqlDaten, $in_callFromFunction) {


        $schema = $in_SqlDaten["schema"];
        $table = $in_SqlDaten["table"];
        $where = $in_SqlDaten["where"];
	
	$query = "DELETE FROM $schema.$table WHERE $where";			
	$query = $this->makeSecureSQL($query, $in_callFromFunction); 

        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Delete-Befehl (query): ', $query);
        
        $result = mysqli_query($this->_dbConnection, $query);
        
        if ($result == true) {
            $feedback = true;
        } else {
            $feedback = false;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlermeldung SQL: ', mysqli_error($this->_dbConnection), "ERROR");
        }

	return $feedback;	

    }

    
    
    
    /** Sendet einen Update-Befehl an eine Postgres-Datenbank. Dazu muss ein Array mit den Werten schema, table und where  übergeben werden.
    * 
    * @param    Array   $in_SqlDaten            Array mit dem Strukturellen Aufbau, wie es die Funktion extractDataFromPostarray erzeugt.
    * @param    string  $in_callFromFunction    Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
    * @return   Boolean 
    */
    function executeUpdate($in_SqlDaten, $in_callFromFunction) {


        $schema = $in_SqlDaten["schema"];
        $table = $in_SqlDaten["table"];
	$update = $in_SqlDaten["update"];
        $where = $in_SqlDaten["where"];
	
	$query = "UPDATE $schema.$table SET $update Where $where";			
	$query = $this->makeSecureSQL($query, $in_callFromFunction); 

//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Update-Befehl input (in_SQLDaten)', $in_SqlDaten);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Update-Befehl (query) - caller = '.$in_callFromFunction, $query);
        $result = mysqli_query($this->_dbConnection, $query);
        
        if ($result == true) {
            $feedback = true;
        } else {
            $feedback = false;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlermeldung SQL: ', mysqli_error($this->_dbConnection), "ERROR");
        }
			
	return $feedback;	

    }
    
    
    
    
    
    /** Entfernt schädlichen Code im SQL-Befehl, bspw. ein Semikolon. Diese Funktion wird üblicherweise nur einmal auf den gesamten SQL-Befehl angewendet.
     * (Anders als parseSqlValue). parseSqlValue kann gezielt auf alle Values angewendet werden.
    * 
    * @param    string  $in_value               Ein SQL-Befehl (string odr array), der auf mögliche Sicherheitsrisiken geprüft wird
    * @param    string  $in_callFromFunction    Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
    * @return   mixed                           String oder array, abhängig vom Eingabewert
    */
    public function makeSecureSQL($in_value, $in_callFromFunction) {													

        $feedback = \db_connection_handler::makeSecureSqlGlobalrules($in_value, $in_callFromFunction);
        return $feedback;
    }
    
    
    
    
    /** Entfernt unerlaubt Zeichen bzw. maskiert diese.
     * Funktion wird bereits durch extractDataFromPostarray aufgerufen und kann daher gezielt auf die 
     * Values angesetzt, statt nur auf den gesamten SQL-Befehl, angewendet werden. Damit unterscheidet sie sich zu makeSecureSQL.
     * 
     * 
     * @param   various     $in_value               Ein string oder array Wert, aus dem unerlaubte Zeichen entfernt werden sollen.
     * @param   resource    $in_connection          Parameter wird nur wegen Kompatibilität zu postgres benötigt. (default = null)
     * @return  string
     */
    function getParseSqlValues($in_value) {
        $in_value = str_replace("'","''",$in_value);                            //Hochkommata escapen, damit diese in Datenbank eingefügt werden können. pg_escape_string  wird nicht genutzt, da der Datentyp des übergebenen Values nicht klar ist.
        
        $feedback = $in_value;
        return $feedback;
    }
    
    
    
    /**Gibt die DB-spezifischen Syntax für ein Count-IF-Konstrukt zurück. zurück.
     * Count-If zählt die Anzahl der Datensätze, die eine bestimmte Bedingung erfüllen.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet genau eine Spalte einer Datenbanktabelle, Summe der Werte zurück gegeben  dern soll.
                                            Die Funktion entspricht der Standard-SQL-Funktion "SUM".
     *                                      param_list = array(column => table.column)
                                            Der key-Name muss "column" lauten. 
     * @return  mixed                       String, wenn Parameter stimmt (Bsp.: "SUM(CASE person.sex WHEN "m" THEN 1 ELSE 0 END) as "davon Männer"" oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForCountIf($in_param_list) {
        if(isset($in_param_list["condition"])) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter für Funktion -max-": ', $in_param_list, "INFO");
            $feedback = "SUM(CASE WHEN ".$in_param_list["condition"]." THEN 1 ELSE 0 END)";
        } else {
            //Wenn der Parameter condition nicht vorhanden ist
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter condition für Funktion -CountIf- nicht gefunden": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    /**Gibt die Split-String-Anweisung in der DB-spezifischen Syntax zurück.
     * Bsp.: Postgres -> split_part; MySql -> substring_index
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet genau drei Parameter: <br />
     *                                      string = string (der aufzusplitende Wert)
     *                                      delimiter = delimiter (der Trenn-String)
     *                                      pos = pos (Integer: Position, im String, die ermittelt werden soll)
     * @return  mixed                       String, wenn Parameter stimmt (Bsp.: "split_part(<string>,<delimiter>, <pos>)" oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForSplitstring($in_param_list) {
        if(isset($in_param_list["string"]) AND isset($in_param_list["delimiter"]) AND isset($in_param_list["pos"])) {
            if(is_numeric($in_param_list["pos"])) {
                $feedback = "SUBSTRING_INDEX(".$in_param_list["string"].", ".$in_param_list["delimiter"].", ".$in_param_list["pos"].")";
            } else {
                //Wenn der pos- Parameter keine ganze Zahl ist
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pos-Parameter in Funktion -SplitString- ist keine Zahl": ', $in_param_list, "ERROR");
                $feedback = false;
            }
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -SplitString-": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;

    }
    
    
    
    
    
    
    
    
    /** ermittelt für eine gegebene SQL-Funktion die DB-spezifische Syntax.
     * Bsp.: Die Syntax für interval mit 300 Sekunden latet in 
     * postgres:    "interval '300 SECOND'" und in
     * mysql:       "interval 300 SECOND"
     * 
     * @param   string  $in_function_name   Name der SQL-Funktion; Es können nur Funktionen genutzt werden, die in den DB-Konnektoren bekannt sind. Siehe hierzu 
     * @param   array   $in_param_list      Liste der Parameter. Die Parameter sind abhängig von der gewählten Funktion
                                            Funktion "interval": param_list = array(interval_value => integer, interval_type => [SECOND|MINUTE|HOUR|DAY|MONTH|YEAR])
     * @return boolean
     */
    function parseFunctions($in_function_name, $in_param_list) {
        $feedback = false;
        if      ($in_function_name == "interval")       {$feedback = $this->getSyntaxForInterval($in_param_list); }
        elseif  ($in_function_name == "concat")         {$feedback = $this->getSyntaxForConcat($in_param_list); }
        elseif  ($in_function_name == "count")          {$feedback = $this->getSyntaxForCount($in_param_list); }
        elseif  ($in_function_name == "date_format")    {$feedback = $this->getSyntaxForDateFormat($in_param_list); }
        elseif  ($in_function_name == "case")           {$feedback = $this->getSyntaxForCase($in_param_list); }
        elseif  ($in_function_name == "coalesce")       {$feedback = $this->getSyntaxForCoalesce($in_param_list); }
        elseif  ($in_function_name == "cast")           {$feedback = $this->getSyntaxForCast($in_param_list); }
        elseif  ($in_function_name == "max")            {$feedback = $this->getSyntaxForMax($in_param_list); }
        elseif  ($in_function_name == "length")         {$feedback = $this->getSyntaxForLength($in_param_list); }
        elseif  ($in_function_name == "replace")        {$feedback = $this->getSyntaxForReplace($in_param_list); }
        elseif  ($in_function_name == "countif")        {$feedback = $this->getSyntaxForCountIf($in_param_list); }
        elseif  ($in_function_name == "strpos")         {$feedback = $this->getSyntaxForStrpos($in_param_list); }
        elseif  ($in_function_name == "sum")            {$feedback = $this->getSyntaxForSum($in_param_list); }
        elseif  ($in_function_name == "substring")      {$feedback = $this->getSyntaxForSubstring($in_param_list); }
        elseif  ($in_function_name == "reverse")        {$feedback = $this->getSyntaxForReverse($in_param_list); }
        elseif  ($in_function_name == "right")          {$feedback = $this->getSyntaxForRight($in_param_list); }
        elseif  ($in_function_name == "string_agg")     {$feedback = $this->getSyntaxForStringAgg($in_param_list); }
        elseif  ($in_function_name == "strpos_right")   {$feedback = $this->getSyntaxForStrposRight($in_param_list); }
        elseif  ($in_function_name == "split_string")   {$feedback = $this->getSyntaxForSplitstring($in_param_list); }
        
        
        else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> unbekannter Funktionsname ', 'Funktionsname: '.$in_function_name, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
    }
    
    
    /**Gibt die Intervalanweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet zwei Parameter
                                            param_list = array(interval_value => integer, interval_type => [SECOND|MINUTE|HOUR|DAY|MONTH|YEAR])
     * @return  mixed                       String, wenn Parameter stimmen (BSp.: "interval 300 SECOND") oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForInterval($in_param_list) {
        if(isset($in_param_list["interval_value"]) AND isset($in_param_list["interval_type"])) {
            if(is_numeric($in_param_list["interval_value"])) {
                if(in_array(strtoupper($in_param_list["interval_type"]), array("SECOND","MINUTE","HOUR","DAY","MONTH","YEAR"))){
                    $feedback = "interval ".$in_param_list["interval_value"]." ".$in_param_list["interval_type"];
                } else {
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> 2. Parameter in Funktion -interval- enthält keinen gültigen Wert SECOND|MINUTE|HOUR|DAY|MONTH|YEAR]": ', $in_param_list, "ERROR");
                    $feedback = false;
                }
            } else {
                //Wenn der erste Parameter keine ganze Zahl ist
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> 1. Parameter in Funktion -interval- ist keine Zahl": ', $in_param_list, "ERROR");
                $feedback = false;
            }
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -interval-": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    /**Gibt die CONCAT_Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet mindestens einen oder beliebig viele Parameter
                                            param_list = array(wert1 => "abc", wert2 => app.name, wertn ...).
                                            Die key-Namen sind irrelevant
     * @return  mixed                       String, wenn Parameter stimmen (Bsp.: "CONCAT('abc', app.name)" oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForConcat($in_param_list) {
        if(count($in_param_list) > 0) {
            $separator = "";
            $param_String = "";
            foreach ($in_param_list as $current_param) {
                $param_String = $param_String.$separator.$current_param;
                $separator = ", ";                                              //ab dem 2. Durchlauf wird ein Separator gesetzt
            }
            $feedback = "CONCAT(".$param_String.")";
        } else {
            //Wenn kein Parameter vorhanden ist
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -concat-": ', "Es wurde kein Parameter angeben. Ggf. Spalte query_part_select.function_params prüfen.", "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    /**Gibt die COUNT_Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet genau eine Spalte einer Datenbanktabelle, deren Einträge gezählt dern soll.
                                            Die Funktion entspricht der Standard-SQL-Funktion "Count".
                                            param_list = array(column => table.column).
                                            Es ist auch möglich mit DISTINCT zu arbeiten
     *                                      param_list = array(column => DISTINCT table.column)
                                            Der key-Name muss column lauten.
     * @return  mixed                       String, wenn Parameter stimmt (Bsp.: "COUNT(DISTINCT table.column)" oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForCount($in_param_list) {
        if(isset($in_param_list["column"])) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter für Funktion -count-": ', $in_param_list, "INFO");
            $feedback = "COUNT(".$in_param_list["column"].")";
        } else {
            //Wenn der Parameter column nicht vorhanden ist
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Der Parameter column für Funktion -count- fehlt": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    /**Gibt die Substring-Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet drei Parameter
                                            param_list = array(string => table.column, start => integer, length => integer)
     * @return  mixed                       String, wenn Parameter stimmen (Bsp.: "substring(string, start, length) ") oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForSubstring($in_param_list) {
        if(isset($in_param_list["string"]) AND isset($in_param_list["start"]) AND isset($in_param_list["length"]) ) {
            
            if(is_string($in_param_list["string"]) ) {
                $feedback = "SUBSTRING(".$in_param_list["string"].", ".$in_param_list["start"].", ".$in_param_list["length"].")";
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> 1. Parameter in Funktion -substring- ist kein string: ', $in_param_list["string"], "ERROR");
                $feedback = false;
            }
            
        } elseif(isset($in_param_list["string"]) AND isset($in_param_list["start"]) ) {
            
            if(is_string($in_param_list["string"]) ) {
                $feedback = "SUBSTRING(".$in_param_list["string"].", ".$in_param_list["start"].")";
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> 1. Parameter in Funktion -substring- ist kein string: ', $in_param_list["string"], "ERROR");
                $feedback = false;
            }
            
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -replace-: ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    /**Gibt die SUM_Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet genau eine Spalte einer Datenbanktabelle, Summe der Werte zurück gegeben  dern soll.
                                            Die Funktion entspricht der Standard-SQL-Funktion "SUM".
     *                                      param_list = array(column => table.column)
                                            Der key-Name muss "column" lauten. 
     * @return  mixed                       String, wenn Parameter stimmt (Bsp.: "SUM(table.column)" oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForSum($in_param_list) {
        if(isset($in_param_list["column"])) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter für Funktion -max-": ', $in_param_list, "INFO");
            $feedback = "SUM(".$in_param_list["column"].")";
        } else {
            //Wenn der Parameter column nicht vorhanden ist
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter coulumn für Funktion -sum- nicht gefunden": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    /**Gibt die MAX_Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet genau eine Spalte einer Datenbanktabelle, deren größter Wert zurück gegeben  dern soll.
                                            Die Funktion entspricht der Standard-SQL-Funktion "Max".
     *                                      param_list = array(column => table.column)
                                            Der key-Name muss "column" lauten. 
     * @return  mixed                       String, wenn Parameter stimmt (Bsp.: "MAX(table.column)" oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForMax($in_param_list) {
        if(isset($in_param_list["column"])) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter für Funktion -max-": ', $in_param_list, "INFO");
            $feedback = "MAX(".$in_param_list["column"].")";
        } else {
            //Wenn der Parameter column nicht vorhanden ist
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter coulumn für Funktion -max- nicht gefunden": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    
    
    /**Gibt die LENGTH_Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet genau eine Spalte einer Datenbanktabelle, deren Länge des String-Wertes zurück gegeben  werden soll.
                                            Die Funktion entspricht der Standard-SQL-Funktion "LENGTH".
     *                                      param_list = array(column => table.column)
                                            Der key-Name muss "column" lauten. 
     * @return  mixed                       String, wenn Parameter stimmt (Bsp.: "LENGTH(table.column)" oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForLength($in_param_list) {
        if(isset($in_param_list["column"])) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter für Funktion -length-": ', $in_param_list, "INFO");
            $feedback = "LENGTH(".$in_param_list["column"].")";
        } else {
            //Wenn der Parameter column nicht vorhanden ist
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter coulumn für Funktion -length- nicht gefunden": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
        /**Gibt die REVERSE_Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet genau einen String.
                                            Die Funktion entspricht der Standard-SQL-Funktion "REVERSE".
     *                                      param_list = array(string => 'MyString')
                                            Der key-Name muss "string" lauten. 
     * @return  mixed                       String, wenn Parameter stimmt (Bsp.: "REVERSE('MyString')" oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForReverse($in_param_list) {
        if(isset($in_param_list["string"])) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter für Funktion -reverse-": ', $in_param_list, "INFO");
            $feedback = "REVERSE(".$in_param_list["string"].")";
        } else {
            //Wenn der Parameter column nicht vorhanden ist
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Parameter string für Funktion -reverse- nicht gefunden": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    /**Gibt die COALESCE_Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet mindestens einen oder beliebig viele Parameter
                                            param_list = array(wert1 => 'abc', wert2 => app.name, wertn ...).
                                            Die key-Namen sind irrelevant. D.h. sie können mit wert1-n oder value1-n oder xyz heißen.
     * @return  mixed                       String, wenn Parameter stimmen (Bsp.: "COALESCE('abc', app.name)" oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForCoalesce($in_param_list) {
        if(count($in_param_list) > 0) {
            $separator = "";
            $param_String = "";
            foreach ($in_param_list as $current_param) {
                $param_String = $param_String.$separator.$current_param;
                $separator = ", ";                                              //ab dem 2. Durchlauf wird ein Separator gesetzt
            }
            $feedback = "COALESCE(".$param_String.")";
        } else {
            //Wenn kein Parameter vorhanden ist
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -coalesce-": ', "Es wurde kein Parameter angeben. Ggf. Spalte query_part_select.function_params prüfen.", "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    /**Gibt die Date_Format-Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet zwei Parameter
                                            param_list = array(date => [date], format => [dd.mm.yyyy|dd.mm.yy|mm.yyyy|dd|mm|yyyy|Month|Day])
     * @return  mixed                       String, wenn Parameter stimmen (Bsp.: "to_char(verfahren.posteingang, 'dd.mm.yyyy')") oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForDateFormat($in_param_list) {
        if(isset($in_param_list["date"]) AND isset($in_param_list["format"])) {
            
            if      (strtoupper(trim($in_param_list["format"])) == 'DD.MM.YYYY')  {$feedback = "DATE_FORMAT(".$in_param_list["date"].", '%d.%m.%Y')";} 
            elseif  (strtoupper(trim($in_param_list["format"])) == 'DD.MM.YY')    {$feedback = "DATE_FORMAT(".$in_param_list["date"].", '%d.%m.%y')";}
            elseif  (strtoupper(trim($in_param_list["format"])) == 'MM/YYYY')     {$feedback = "DATE_FORMAT(".$in_param_list["date"].", '%m/%Y')";}
            elseif  (strtoupper(trim($in_param_list["format"])) == 'DD')          {$feedback = "DATE_FORMAT(".$in_param_list["date"].", '%d')";}
            elseif  (strtoupper(trim($in_param_list["format"])) == 'MM')          {$feedback = "DATE_FORMAT(".$in_param_list["date"].", '%m')";}
            elseif  (strtoupper(trim($in_param_list["format"])) == 'YYYY')        {$feedback = "DATE_FORMAT(".$in_param_list["date"].", '%Y')";}
            elseif  (strtoupper(trim($in_param_list["format"])) == 'MONTH')       {$feedback = "DATE_FORMAT(".$in_param_list["date"].", '%M')";}
            elseif  (strtoupper(trim($in_param_list["format"])) == 'DAY')         {$feedback = "DATE_FORMAT(".$in_param_list["date"].", '%W')";}
            elseif  (strtoupper(trim($in_param_list["format"])) == 'DD.MM.YYYY - HH:MM:SS')         {$feedback = "DATE_FORMAT(".$in_param_list["date"].", '%d.%m.%Y - %H:%i:%S')";}
            elseif  (strtoupper(trim($in_param_list["format"])) == 'HH:MM:SS')    {$feedback = "DATE_FORMAT(".$in_param_list["date"].", '%H:%i:%S')";}
            else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> 2. Parameter in Funktion -date_format- enthält keinen gültigen Wert [dd.mm.yyyy|dd.mm.yy|mm.yyyy|dd|mm|yyyy|Month|Day|dd.mm.yyyy - HH:MM:SS|HH:MM:SS]": ', $neededFormat, "ERROR");
                $feedback = false;
            }
            
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -date_format-": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    
    /**Gibt die StringAgg-Anweisung in der DB-spezifischen Syntax zurück. (group_concat)
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet mindestens zwei Parameter
                                            param_list = array(value => [string], 
     *                                      delimiter => [string]),
     *                                      [optional]order => [string]
     * @return  mixed                       String, wenn Parameter stimmen (Bsp.: ("string_agg(app_schema.db_schema,',' order by db_schema asc)") oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForStringAgg($in_param_list) {
        if(isset($in_param_list["value"]) AND isset($in_param_list["delimiter"])) {
            $distinct = "";
            if(isset($in_param_list["distinct"])) {
                if($in_param_list["distinct"] == "true") {$distinct = "distinct ";}
            }
            
            $order = "";
            if(isset($in_param_list["order"])) {
                $order = "order by cast(".$in_param_list["order"]." as char)";
            }
            
            
            $feedback = "group_concat(".$distinct."cast(".$in_param_list["value"]." as char) ".$order." SEPERATOR '".$in_param_list["delimiter"]."')";
            
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -string_agg-": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    /**Gibt die Cast-Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet zwei Parameter
                                            param_list = array(value => table.column, type => [int|char|text|float|date])
     * @return  mixed                       String, wenn Parameter stimmen (Bsp.: "CAST(logdata.log_art AS text) ") oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForCast($in_param_list) {
        if(isset($in_param_list["value"]) AND isset($in_param_list["type"])) {
            
            if      (strtoupper($in_param_list["type"]) == 'INT')  {$feedback = "CAST(".$in_param_list["value"]." as SIGNED)";} 
            elseif  (strtoupper($in_param_list["type"]) == 'CHAR')  {$feedback = "CAST(".$in_param_list["value"]." as CHAR(1))";} 
            elseif  (strtoupper($in_param_list["type"]) == 'TEXT')  {$feedback = "CAST(".$in_param_list["value"]." as CHAR)";} 
            elseif  (strtoupper($in_param_list["type"]) == 'FLOAT')  {$feedback = "CAST(".$in_param_list["value"]." as DECIMAL)";} 
            elseif  (strtoupper($in_param_list["type"]) == 'DATE')  {$feedback = "CAST(".$in_param_list["value"]." as DATE)";} 
            elseif  (strtoupper($in_param_list["type"]) == 'TIMESTAMP')  {$feedback = "CAST(".$in_param_list["value"]." as TIMESTAMP)";} 
            else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> 2. Parameter in Funktion -cast- enthält keinen gültigen Wert [int|char|text|float|date]": ', $in_param_list, "ERROR");
                $feedback = false;
            }
            
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -cast-": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    /**Gibt die Replace-Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet drei Parameter
                                            param_list = array(string => table.column, find_string => text, replace_with => text)
     * @return  mixed                       String, wenn Parameter stimmen (Bsp.: "replace(data_type, 'double', 'float') ") oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForReplace($in_param_list) {
        if(isset($in_param_list["string"]) AND isset($in_param_list["find_string"]) AND isset($in_param_list["replace_with"])) {
            
            if(is_string($in_param_list["string"])) {
                $feedback = "REPLACE(".$in_param_list["string"].", ".$in_param_list["find_string"].", ".$in_param_list["replace_with"].")";
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> 1. Parameter in Funktion -replace- ist kein string: ', $in_param_list["string"], "ERROR");
                $feedback = false;
            }
            
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -replace-: ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    /**Gibt die StrPos-Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet zwei Parameter
                                            param_list = array(string => table.column, find_string => text)
     * @return  mixed                       String, wenn Parameter stimmen (Bsp.: "strpos(form.image, 'img/') ") oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForStrpos($in_param_list) {
        if(isset($in_param_list["string"]) AND isset($in_param_list["find_string"])) {
            
            if(is_string($in_param_list["string"])) {
                $feedback = "LOCATE(".$in_param_list["string"].", ".$in_param_list["find_string"].")";
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> 1. Parameter in Funktion -strpos- ist kein string: ', $in_param_list["string"], "ERROR");
                $feedback = false;
            }
            
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -strpos-: ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    
    /**Gibt eine Kombination aus StrPos- und Reverse-Anweisung in der DB-spezifischen Syntax zurück.
     * Damit kann das letzte Auftreten eines besuchten Strings ermittelt werden.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet zwei Parameter
                                            param_list = array(string => table.column, find_string => text)
     * @return  mixed                       String, wenn Parameter stimmen (Bsp.: "STRPOS(REVERSE(konfiguration.wert), REVERSE('img/')) oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForStrposRight($in_param_list) {
        if(isset($in_param_list["string"]) AND isset($in_param_list["find_string"])) {
            
            if(is_string($in_param_list["string"])) {
                $feedback = "STRPOS(".$in_param_list["string"].", ".$in_param_list["find_string"].")";
                $feedback = "STRPOS(REVERSE(".$in_param_list["string"]."), REVERSE(".$in_param_list["find_string"]."))";
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> 1. Parameter in Funktion -strpos_right- ist kein string: ', $in_param_list["string"], "ERROR");
                $feedback = false;
            }
            
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -strpos-: ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    
    
    /**Gibt die RIGHT-Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet zwei Parameter
                                            param_list = array(string => table.column, length => integer)
     * @return  mixed                       String, wenn Parameter stimmen (Bsp.: "right(form.image, 6) ") oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForRight($in_param_list) {
        if(isset($in_param_list["string"]) AND isset($in_param_list["length"])) {
            
            if(is_string($in_param_list["string"])) {
                $feedback = "RIGHT(".$in_param_list["string"].", ".$in_param_list["length"].")";
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> 1. Parameter in Funktion -right- ist kein string: ', $in_param_list["string"], "ERROR");
                $feedback = false;
            }
            
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -right-: ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
    
    /**Gibt die Case-Anweisung in der DB-spezifischen Syntax zurück.
     * 
     * @param   array   $in_param_list      Liste der Parameter. Die Funktion erwartet mindestens 3 Parameter Parameter (value, when1 und then1).
                                            Es können beliebig viele weitere when-then-Paare folgen, sowie ein else-Parameter.
                                            param_list = array(value => table.column, when1 => 20, then1 => 'zwanzig', when2 => 30, then2 => 'dreizig', else => 'eine unbekannte Zahl')
     * @return  mixed                       String, wenn Parameter stimmen (BSp.: "CASE table.column WHEN 20 THEN 'zwanzig' WHEN 30 THEN 'dreizig' else 'eine unbekannte Zahl' END") oder false, wenn ein Fehler in der Paramterliste gefunden wird. 
     *                                      Die Fehlerart wird in der Debug-Tabelle ausgegeben.
     */
    function getSyntaxForCase($in_param_list) {
        //In dieser Function werden array-keys mit "issetKeyLike" gesucht, da es möglich ist, dass sich in den Keys Leerzeichen und Zeilenumbrüche finden.
        
        if(isset($in_param_list["value"]) AND issetKeyLike($in_param_list,"when") !== false AND issetKeyLike($in_param_list,"then") !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> gefundene Parameter für  Funktion -case-: ', $in_param_list, "ERROR");
            
            $feedback = "CASE ".$in_param_list["value"]." ";
            foreach ($in_param_list as $current_param_name => $current_param_value) {
                if(in_array($current_param_name, array('case', 'else')) == false) {
                    //Theoretisch sollte es sich um einen Paramter handeln, der mit when oder then beginnt
                    if(strpos($current_param_name,"when") !== false) {
                        $feedback = $feedback." WHEN ".$current_param_value;
                    } elseif(strpos($current_param_name,"then") !== false) {
                        $feedback = $feedback." THEN ".$current_param_value;
                    }
                }
            }
            
            if(issetkeyLike($in_param_list,"else") !== false) {
                $myKey = issetkeyLike($in_param_list,"else");
                $feedback = $feedback." ELSE ".$in_param_list[$myKey]." END";
            } else {
                $feedback = $feedback." END";
            }
            
            $feedback = "(".$feedback.")";                                      //Wichtig bei Mysql, für den Fall, dass auch noch ein Alias angehangen wird.
            
            
            
        } else {
            //Wenn ein oder mehr Parameter fehlen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehlende Parameter für Funktion -case-. Alle Parameter müssen klein geschrieben werden.": ', $in_param_list, "ERROR");
            $feedback = false;
        }
        
        return $feedback;
        
    }
    
}
