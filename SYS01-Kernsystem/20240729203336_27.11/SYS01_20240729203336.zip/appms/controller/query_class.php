<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

require_once("../controller/functions_db.php");                                 //nur bei Direktaufruf notwendig
require_once("../controller/global_variables_class.php");                             //globale Variablen
require_once("../controller/backupcontroller/backupmanager_class.php");


$memory = getConfig("temp_memory_limit", global_variables::getAppIdFromSYS01());
if(is_numeric($memory)) {ini_set('memory_limit', $memory.'M'); }


/**
 * Klasse stellt Methoden des Auswertungsgenerators bereit.
 * 
 */
class query {
    
    /**
     * @var     string      enthält das Ausgabedocument (rtf, csv)
     */
    protected $_output_document; 
    
    /**
     * @var     string      SQL-Befehl, mit welchem die benötigten Daten aus der Datenbank abgefragt werden.
     */
    protected $_sql;
    
    /**
     * @var     array       Ergebnismange der Datenbankabfrage 
     */
    protected $_queryresult;
    
    /**
     * @var     string      Name einer query 
     */
    protected $_name;       
    
    /**
     * @var     integer     id einer query 
     */
    protected $_id;
    
    /**
     * @var     string      app_id einer query 
     */
    protected $_app_id;
    
    
    /**
     *
     * @var     string      ID, der Connection, die verwendet werden soll. I.d.R. entspricht diese der App_id 
     */
    protected $_connection_id = "";
    
    /**
     *
     * @var     boolean     Gibt an, ob in der Query Security-Conditions ergänzt wurden.
     */
    protected $_securityConditions_added = false;
    
    /**
     * @var     string      Beschreibung einer query 
     */
    protected $_description;
    
    /**
     * @var     string      Ausgabeformat einer query  (csv|rtf|list|text/html|vquery)
     *                      vquery -> das Ergebnis einer Query soll in einer Datenbank bereitgestellt  werden, ähnlich einer view.
     */
    protected $_output_format;
    
    /**
     * @var     string      Dateiname des Templates, mit dem die Daten ausgegeben werden sollen
     */
    protected $_template_file;
    
    /**
     * @var     array      Liste der verwendeten Kriterienplatzhalter in _sql und deren Metadaten, sowie der zu verwendenen Werte
     */
    protected $_criteriaList;
    
    /**
     * @var     array      Liste der Datensätze, für die die Auswertung erstellt werden soll. Syntax siehe internPostObject->MarkedData oder internPostObject->ChangedData
     */
    protected $_inputDatensaetze;
    
    /**
     * @var     array       Liste der Columns, welche im Select-Part genutzt werden sollen. keys siehe functions_db.getQuerySelectPart 
     */
    protected $_sql_select_list;
    
    /**
     * @var     array       Liste der Tabellen, welche im From-Part genutzt werden sollen. keys siehe functions_db.getQueryFromPart 
     */
    protected $_sql_from_list;
    
    /**
     * @var     array       Liste der Bedingungen, welche im Join-Part genutzt werden sollen. keys siehe functions_db.getQueryJoinPart 
     */
    protected $_sql_joinCondition_list;
    
    /**
     * @var     array       Liste der Bedingungen, welche zusätzlich zu den  Join-Part genutzt werden sollen, bspw. um die Datenmenge einzuschränken. keys siehe functions_db.getQueryAddConditionPart 
     */
    protected $_sql_addCondition_list;
    
    /**
     * @var     array       Liste der Collumns, nach denen sortiert werden soll. keys siehe functions_db.getQueryOrderByPart 
     */
    protected $_sql_OrderBy_list;
    
    /**
     * @var     array       Liste der Collumns, nach denen gruppiert werden soll. keys siehe functions_db.getQueryGroupByPart 
     */
    protected $_sql_GroupBy_list;
    
    /**
     *
     * @var     array       Flexibler Datencontainer, in dem interne Daten, als Parameter für eine Query übergeben werden können. 
     *                      Mögliche Werte werden im Kommentar der Methode initialize_1 erläutert.
     *                      
     */
    protected $_flexInternVariables;
    
    /**
     *
     * @var     integer     [0|1] Wenn 1, dann werden die Security-Conditions der Rollen nicht ergänzt. 
     */
    protected $_deactivate_security;   
    
    /**
     *
     * @var     array       Formular-Array des Formulars, an dem die Query angebunden ist. In Abhängigkeit davon werden die query_criteria ermittelt. Wenn diese Eigenschaft == array(), dann formularunabhängig. 
     */
    public $form_array;
    
    /** Gibt an, ob es ein Format ist, welches an den Client gesendet werden kann.
     * 
     * @var bool
     */
    public $clientrelevant_format;
    
    /**
     *
     * @var     object      Objekt von Typ sqlRequest. Dieses existiert nur, wenn der SQL-Befehl der Query nicht bereits vorgegeben wurde (no-sql) 
     */
    protected $_sqlRequest_object = NULL; 
    
    
    /**
     *
     * @var     string      SQL-Bedingung, wie sie die Methode pagedata->getFormPropertyCondition ermittelt. 
     */
    protected $_formFilterCondition = "";
    

    /**
     * Diese Klasse stellt Methoden des Auswertungsgenerators bereit.
     * Zur Nutzung der Klasse muss anschließend eine der initialize-Methoden verwendet werden.
     */
    public function __construct() {
        
    }



    /** 
     * Diese Methode initialisiert ein Standard-Query-Objekt.
     * 
     * @param   string      $in_query_app_id            App_id der Auswertung, welche ausgefürht werden soll.
     * @param   integer     $in_query_id                ID der Auswertung, welche ausgeführt werden soll (siehe query.id).
     * @param   array|boolean   $in_datensaetze         Liste der im Formular gewählten Datensätze, für die die Auswertung erstellt werden soll. 
     *                                                  Datensätze können genutzt werden, um Platzhalter im where-part (db-table = query_add_condition bzw. query_criteria) zu ersetzen.
     *                                                  Syntax siehe internPostObject->MarkedData oder internPostObject->ChangedData
     *                                                  Wenn $in_datensaetze nicht zur Verfügung gestellt werden können, dann "false" für diesen Parameter übergeben.
     * @param   array       $in_flexInternVariables     Flexibler Datencontainer, in dem interne Daten, als Parameter für eine Query übergeben werden können.
     *                                                  Diese Daten stehen bereits beim Formularaufbau zur Verfügung, anders als der vorherige Parameter ($in_datensaetze). $in_datensaetze kann
     *                                                  nur durch das Absenden eines Formulars über $_POST bereitsgestellt werden.
     *                                                  [optionale Verwendung: Wenn Sie diesen Parameter nicht verwenden wollen, dann übergeben Sie an dieser Stelle "array()".
     *                                                  Syntax: Mehrdimensionales array mit Angabe des Typs des Datencontainers und der Daten selbst.
     *                                                  
     *                                                  ------------------------------
     *                                                  Hinweise zu Typ HTMLFieldList:
     *                                                  Array, indem alle Felder des aktuellen Datensatzes in einem Objekt vom Typ html_class.HTMLFieldList enthalten sind 
     *                                                  und die ID des HTMLFields, dessen Werte als Paramter, gemäß db-table query_add_condition.value_internvariable genutzt werden soll.
     *                                                  Bsp. für das array: array(1 => array(type => "HTMLFieldList", data => html_class.HTMLFieldList, id => 3))
     *                                                  ------------------------------
     *                                                  Hinweise zu Typ formFilterCondition:
     *                                                  String, indem eine gültige SQL-Bedingung, wie sie die Funktion pagedata->getFormPropertyCondition ermittelt
     *                                                  hinterlegt ist.
     *                                                  Die Bedingung wird ohne weitere Prüfung in der Where-Klausel ergänzt
     *                                                  ------------------------------
     *                                                  Hinweise zu Typ FormArray:
     *                                                  Array, in dem alle Daten des Form_arrays enthalten sind. Alle Werte des FormArrays können als Parameter in der query
     *                                                  genutzt werden (siehe db-table query_add_condition.value_internvariable).
     *                                                  Bsp. für das array: array(1 => array("type" => "FormArray", "data" => $in_form))
     *                                                  ------------------------------
     *                                                  Hinweise zu Typ SessionData:
     *                                                  Array mit den öffentlich zugänglichen Sessiondaten. Der Aufbau des Arrays kann der Tabelle Debug entnommen werden.
     *                                                  verfügbare Daten sind bspw. uid und active_role
     *                                                  Bsp. für das array: array(1 => array("type" => "SessionData", "data" => $in_form)) 
     *                                                  ------------------------------
     *                                                  Hinweise zu Typ triggerFieldsCondition:
     *                                                  Array mit dem aktuellen Feldinhalt eines Triggerfeldes. 
     *                                                  Bsp. für das Array: array(1 => array("type" => "triggerFieldsCondition", "data" =>
                                                                                array(
                                                                                    [0] => Array
                                                                                        (
                                                                                            [sourcetable] => account_has_role
                                                                                            [sourcecolumn] => role_app_id
                                                                                            [targettable] => role
                                                                                            [targetcolumn] => app_id
                                                                                            [value] => WIDER
                                                                                        )

                                                                                )))
     *                                                  Array kann bspw. durch getDependsconditionForField erzeugt werden.
     *                                                  -------------------------------                                                                           
     *                                                  Es können auch mehrere interne Variablentypen gleichzeitig übergeben werden.
     *                                                  Bsp. für das array: array(1 => array("type" => "SessionData", "data" => $in_form),
     *                                                                            2 => array("type" => "FormArray", "data" => $in_form)) 
     * 
     * @param   array       $in_form_array              Form-Array des Formulars, für welches die Query ausgeführt werden soll.
     *                                                  In Abhängigkeit von diesem Parameter werden nur die query_criteria geladen, welche sich auf dieses
     *                                                  Formular beziehen. 
     *                                                  Wenn dieser Parameter nicht angegeben werden kann, dann kann  "array()" übergeben werden.
     * @param   string      $in_query_connection_id     [optional] Connection-ID, die genutzt werden soll. Wenn false, dann wird $in_query_app_id als connection_id genutzt.
     *                                                  Verwendungszweck: Bspw. Query
     * @param   String      $in_limit                   [optional] Anzahl der anzuzeigenden Datensätze (default = 0; 0 = deaktiviert)
     * @param   String      $in_offset                  [optional] Anzahl der zu überspringenden Datensätze, bis zum ersten anzuzeigenden (default = 0)
     * @param   boolean     $in_deactivateSecurityCondition [optional] Gibt an, ob die Security-Conditions beim ermitteln der Inhaltsdaten deaktiviert werden sollen. Wenn true, dann überlagert diese Vorgabe $this->deactivate_security
     
     */
    public function initialize_1($in_query_app_id, $in_query_id, $in_datensaetze, $in_flexInternVariables, $in_form_array, $in_query_connection_id = false, $in_limit = 0, $in_offset = 0, $in_deactivateSecurityCondition = false) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  construct Query: ', $in_query_id);
        
        
        
        $this->_app_id = $in_query_app_id;
        $this->_id = $in_query_id;
        
        
        
        $this->_inputDatensaetze = $in_datensaetze;
        $this->_flexInternVariables = $in_flexInternVariables;
        $this->form_array = $in_form_array;
       
        
        
        //Wenn eine abweichende Connection-ID über eine Feldreferenz mitgegeben wurde, dann überlagert diese die Connection-ID aus buildQuery.
        //    D.h.: Das eine Fixe Connection-ID aus query.use_connection durch ein Referenzfeld überlagert wird.
        if($in_query_connection_id !== false AND $in_query_connection_id != "") {
            $this->_connection_id = $in_query_connection_id;
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Connection-ID-Übergabe: ', $in_query_connection_id);
        }
        
        
        //Anhand einer ID die query aufbauen
        $this->buildQuery($in_limit, $in_offset, $in_deactivateSecurityCondition);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Aufruf mit Datensätze: ', $this->_inputDatensaetze);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Aufruf mit flexInternVariables: ', $this->_flexInternVariables);  
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SQL: ', $this->_sql);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Connection-ID: ', $this->_connection_id);
        
        
        //Falls in flexInternVariables Bedingungen vom Typ formFilterCondition mitgegeben wurden, kann es sein, dass darin Aliase angesprochen
        //werden, welche eigentlich auf eine DB-Funktion referenzieren (bspw. concat). Da in der Where-Klausel keine Aliase verwendet werden
        //können, müssen diese durch die Funktion aus dem Select-Part ersetzt werden.
        $this->_sql = $this->_sqlRequest_object->getSelectCommand();
        $temp_sql = $this->replaceAliasInGivenCondition($in_flexInternVariables, $this->_sql);
        $this->_sqlRequest_object->setSqlCommand($temp_sql);
        
        
        //query (Datenbankabfrage ausführen und Ergebnis in this->_queryresult ablegen
        $this->_queryresult = $this->getResultForSql();
        //Durch die Ausführung der Query wurde der finale SQL-Befehl, ohne Funktionsplatzhalter, erzeugt. Dieser wird zurückgeholt, 
        //damit er dem USer präsentiert werden kann.
        $this->_sql = $this->_sqlRequest_object->getSelectCommand();
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Query-Ergebnisliste: ', $this->_sql);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Query-Ergebnisliste: ', $this->_queryresult);
        
        //document_template einlesen
        $this->readTemplatefile();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  templatefile: ', $this->_output_document);
        
        //Ergebnisse mit documenttemplate verknüpfen
        $this->chooseOutputBuilder();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  outputfile: ', $this->_output_document);
        
        
    }
    
    
    
    
    /** Prüft, ob in einer vorgegebenen formFilterCondition (ggf. in $in_flexInternVariables enthalten)
     * ein Alias verwendet wird. Falls ja, wird der Alias durch den eigentlichen Select-Ausdruck ersetzt.
     * 
     * @param   array   $in_flexInternVariables     siehe Beschreibung zu initialize_1
     * @param   string  $in_sql                     bisheriger SQL-Befehl
     * @return  string                              neuer SQL-Befehl
     */
    private function replaceAliasInGivenCondition($in_flexInternVariables, $in_sql) {
        $new_sql = $in_sql;
        $condition_exists = false;
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Select-step 3: ', $in_sql);
        
        //Prüfen, ob mindestens eine formFilterCondition existiert
        foreach ($in_flexInternVariables as $key => $cur_flexVariable) {
            if($cur_flexVariable["type"] == "formFilterCondition") {
                $condition_exists = true;
            }
        }
        
        
        //Wenn eine Condition existiert und im SQL ein Alias verwendet wird, dann in Condition den Alias ersetzen.
        if($condition_exists == true and strpos($new_sql, " as ") !== false) {
            $temp_alias_array = array();
            //Select-Part anhand des "FROM"-Keywords ermitteln
            $sql_parts = explode("FROM", $new_sql);
            $select_part = $sql_parts[0];
            
            //Alles entfernen, was keine Spalte ist
            $select_part = str_replace("SELECT", "", $select_part);
            
            //Spalten anhand des Zeilenumbruches separieren.
            $select_array = explode("\n", $select_part);
            
            //alle Spalten, die einen Alias enthalten selektieren und in $temp_alias_array sammeln
            foreach ($select_array as $key => $cur_col) {
                if(strpos($cur_col, " as ") !== false) {
                    $temp_string = ltrim(ltrim($cur_col, " "),",");
                    $temp_string_array = explode(" as ", $temp_string);
                    $temp_alias_array[$temp_string_array[1]] = $temp_string_array[0];
                }
            }
            
            //Liste der gefunden Aliase
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Select-step 5: ', $temp_alias_array);
            
            //Alle Aliase in der flexCondition ersetzen. Anschließend neue Condition für alte flexcondition setzen.
            foreach ($in_flexInternVariables as $key => $cur_flexVariable) {
                if($cur_flexVariable["type"] == "formFilterCondition") {
                    //Alle Aliase in dieser flexVariable ersetzen
                    $new_cur_flexVariable = $cur_flexVariable;
                    foreach ($temp_alias_array as $alias => $long_term) {
                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  ersetze: '.$alias.' durch:'. $long_term, $new_cur_flexVariable);
                        $new_cur_flexVariable = str_replace($alias, $long_term, $new_cur_flexVariable);
                        //die nächste Zeile sollte eigentlich besser sein. Sie ersetzt den Alias nicht, wenn danach ein Punkt folgt.
                        //Alle Aliase sollte aus dem Select-Bereich kommen, d.h. es jandelt sich um Spalten. Wenn nach dem Alias ein Punkt folgt,
                        //muss es jedoch eine Tabelle sein. 
//                        $new_cur_flexVariable = preg_replace('/' . preg_quote($alias) . '(?!\.)/', $long_term, $new_cur_flexVariable);
                    }
                    //Flexvariable in SQL ersetzen
                    $new_sql = str_replace($cur_flexVariable, $new_cur_flexVariable, $new_sql);
                }
            }
            
            
        }
        
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Select-step 6: ', $new_sql);
            
        return $new_sql;
    }
    
    
    
    
    
    /** 
     * Diese Methode initialisiert ein Dummy-Query-Objekt.
     * Dem Objekt wird ein Result-Set (Query-Ergebnis) als Parameter vorgegeben.
     * Durch das Query-Objekt können dann die Methoden der Druckaufbereitung verwendet werden.
     * 
     * @param string    $in_app_id          APP, aus dessen Verzeichnis das Query_template-Dokument ermittelt werden soll
     * @param array     $in_result          Zweidimensionales Array, welches als Query-Result genutzt wird. Bsp.: <br />
     *                                      Array( <br />
                                                    [0] => Array([feld.id] => 4076 [feld.app_id] => REQ11 [feld.konstante_app_id] => SYS01) <br />
                                                    [1] => Array([feld.id] => 4081 [feld.app_id] => REQ11 [feld.konstante_app_id] => SYS01) <br />
                                                    [2] => Array([feld.id] => 4131 [feld.app_id] => REQ11 [feld.konstante_app_id] => SYS01) <br />
                                            } <br />
     * @param string    $in_templateFile    Name der Datei, welche als Template für die Druckaufebereitung verwendet werden soll.
     * @param string    $in_outputFormat    Format, in dem die Druckaufbereitung erfolgen soll. 
     *                                      In diesem Konstruktor stehen nur die folgenden Formate zur Auswahl: [rtf|csv|text/html].
     * @param array     $in_form_array      Array des Formulars, über welches die Query angestoßen wurde.
     * @param object    $in_pagedata        Referenz zum pagedata-object
     * @return nothing                      Die Methode hat keinen Rückgabewert. Die Query wird ausgeführt und als http-Request an den Client 
     *                                      zurückgegeben. Anschließend wird die Programmausführung per exit() abgebrochen, damit
     *                                      der Client die Maske nicht neu lädt.
     */
    public function initialize_2($in_app_id, $in_result, $in_templateFile, $in_outputFormat, $in_form_array, &$in_pagedata) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Query-constructor1 mit outputFormat: ', $in_outputFormat);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Druckaufbereitung für folgende Daten: ', $in_result);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  template_file: ', $in_templateFile);
        
        $this->_app_id = $in_app_id;
        $this->_template_file = $in_templateFile;
        $this->_output_format = $in_outputFormat;
        $this->_queryresult = $in_result;
        $this->form_array = $in_form_array;
        
        //4. document_template einlesen
        $this->readTemplatefile();
        
        //5. Ergebnisse mit documenttemplate verknüpfen
        $this->chooseOutputBuilder($in_pagedata);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  outputfile: ', $this->_output_document);
        
        
    }
    
    
    
    
    
    
    /** Erstellt für eine Query, welche einem Formular zu Grunde liegt, den variablen Conditioncontainer.
     * 
     * @param   bool    $in_use_sessionArray        Gibt an, ob auch das Session-Array als potenzieller Kriteirenlieferant benötigt wird. Das ist notwendig, wenn in der Query auf Attribute der Session zurückgegriffen wird.
     * @param   array   $in_pagedata                Referenz auf das pagedata-object
     * @param   integer $in_form_id                 ID des aktuellen Formulars
     * @param   string  $in_currentFormInstanceId   ID der Formular-Instanz
     * @param   array   $in_addConditionsFromParent [optional] falls es sich um ein ChildFormular handelt, können hier WerteBedingungen des übergeordneten Formulars 
     *                                              übergeben werden die in der Where-Bedingung zur Ermittlung der Daten in diesem Formular genutzt werden. 
     *                                              Die Syntax wird bspw. durch getConditionForNestedForms erstellt. [default = array()]
         
     * @return  array                               Liste der Zusatzbedingungen, wie sie die Methode query->initialize1 im Attribut $in_flexInternVariables verarbeiten kann.
     */
    public function buildvariableContainerForQuery($in_use_sessionArray, &$in_pagedata, $in_form_id, $in_currentFormInstanceId, $in_addConditionsFromParent = array()) {
        //einschränkende Kriterien für Query ermitteln
        $variablesContainerForQuery = array();
        
        if($in_use_sessionArray === true) {
            //Bereitstellung des SESSION-Arrays, falls diese als Kriterien gelten sollen
            $variablesContainerForQuery[] = array("type" => "SessionData", "data" => session_class::$session_object->getSessionArray());
        }

        if(isset($in_addConditionsFromParent["queryBase"])==true) {
            //Bereitstellung der Daten des ParentFormulars, falls es sich um ein ChildFormular handelt und form_nesting_fieldreference definiert wurden.
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Conditions by triggerForm: ', $in_addConditionsFromParent["queryBase"]);
            //Bei Formularen, die auf einer Query basieren, kann es sein, dass die targetTable im Feld targetColumn integriert ist. Diese beiden Werte müssen getrennt werden.
            for ($i = 0; $i < count($in_addConditionsFromParent["queryBase"]); $i++) {
                if(strpos($in_addConditionsFromParent["queryBase"][$i]["targetcolumn"], ".")<>false) {
                    //Wenn ein Punkt vorhanden ist, dann sind table und column in dem Attribut targetcolumn vorhanden.
                    $tableAndColumn = explode(".", $in_addConditionsFromParent["queryBase"][$i]["targetcolumn"]);
                    $in_addConditionsFromParent["queryBase"][$i]["targettable"] = $tableAndColumn[0];
                    $in_addConditionsFromParent["queryBase"][$i]["targetcolumn"] = $tableAndColumn[1];
                }
            }
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Conditions by triggerForm: ', $in_addConditionsFromParent["queryBase"]);                    
            $variablesContainerForQuery[] = array("type" => "triggerFieldsCondition", "data" => $in_addConditionsFromParent["queryBase"]);   //für den Fall, dass die Werteliste des aktuellen Feldes von den Eingaben in einem vorherigen Feld abhängig sind.
        }


        //Bei abhängigen, aber eigenständigen Formularen, prüfen ob Conditions aus Feldabhängigkeiten (field_depends) übernommen werden müssen
        $form               = $in_pagedata->getFormArray($in_form_id);
        $fielddepends = $in_pagedata->getFormPropertyQueryCondition($in_form_id, $form['form_dependence.trigger_form_id']);
        if($fielddepends <> array()) {
            //Wenn mind. eine Feldabhängigkeit existiert
            //ToDo: die folgende Aktion überschreibt eine bereits vorhande "triggerFieldsCondition". Das ist problematisch, wenn beides auftritt. (siehe etwa 6 Zeilen höher
            $variablesContainerForQuery[] = array("type" => "triggerFieldsCondition", "data" => $fielddepends);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> triggerForm: ', $fielddepends);                    

        }

        //Defaultbedingung der aktuellen Instanz ermitteln (Instanz-Default-Condition)
        $bedingung = $in_pagedata->getFormInstancePropertyCondition($in_form_id, $in_currentFormInstanceId);
        if($bedingung != "") {
            $variablesContainerForQuery[] = array("type" => "formFilterCondition", "data" => $bedingung);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Default-Conditions für Instanz by triggerForm: ', $variablesContainerForQuery);

        }
        
        //Filterbedingung der aktuellen Instanz ermitteln (Instanz-Filter-Condition)
        $bedingung0 = $in_pagedata->getFormInstancePropertyConditionFilter($in_form_id, $in_currentFormInstanceId);
        if($bedingung0 != "") {
            $variablesContainerForQuery[] = array("type" => "formFilterCondition", "data" => $bedingung0);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Filter-Conditions für Instanz: ', $variablesContainerForQuery);

        }
        
        //Defaultbedingung des Formulars ermitteln (Form-Default-Condition)
        $bedingung2 = $in_pagedata->getFormPropertyConditionDefault($in_form_id);
        if($bedingung2 != "") {
            $variablesContainerForQuery[] = array("type" => "formFilterCondition", "data" => $bedingung2);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Default-Conditions by Form: ', $variablesContainerForQuery);

        }
        
        
        
        return $variablesContainerForQuery;
        
    }
    
    
    
    
    
    
    /**
     * Übergibt das Query-Ergebnis in Form eines http-headers an den Client zurück.
     * Anschließend wird der Programmablauf abgebrochen, damit der Client nicht die Seite
     * neu aufbaut, sondern nur das Query-Ergebnis erhält.
     * 
     * ACHTUNG: Bei Änderungen beachte auch die Methode pagedata_class->sendFileToClient
     */
    function showOutputdocument() {
        
        $filename = $this->_template_file;
        $file_format = $this->_output_format;
        header('Content-Type: '.$file_format.';charset=utf-8');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Content-Description: File Transfer');
        
        //vorhandene Zeichen im Header löschen -> wichtig, da sonst einige Fileformate nicht funktionieren
        ob_clean();
        flush();

//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  outputfile: ', $this->_output_document);
        $data = $this->_output_document;
        
        $filename_parts = explode(".",$filename);
        $file_extension = $filename_parts[1];
        
        if(in_array($file_extension, global_variables::getMsOfficeFiletypes())) {
            //Die Office-Programme erwarten ISO-8859
            //print utf8_decode($data);
            print mb_convert_encoding($data, 'UTF-8', mb_list_encodings());
        } else {
            //utf8 wird über das meta-tag im Dokument eingestellt
            print $data;
        }
        
        
        //Nach dem Dateidownload abbrechen, damit alte Webseite stehen bleibt.
        exit();
    }
    
    
    
    
    /**
     * Funktion wählt anhand des  Ausgabeformats die Funktion, welche für das Zusammenführen von Template und Daten verantwortlich ist.
     * 
     * @param   object  $in_pagedata    [optional] Referenz auf das pagedata-object
     */
    protected function chooseOutputBuilder(&$in_pagedata = false) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Ermittle weiter verarbeitende Funktion anhand Ausgabeformat: ', $this->_output_format);
        
        if      (in_array($this->_output_format,array("rtf","html"))) {
            //Datensatz oder Ergebnis einer Query, welches mit einem Dokumententemplate verknüpft werden soll
            $this->buildTemplateFile($in_pagedata);
            $this->clientrelevant_format = true;
        } elseif($this->_output_format == "csv") {
            //Ergebnis einer Query, welches als CSV ausgegeben werden soll
            $this->buildCsvFile(false);
            $this->clientrelevant_format = true;
        } elseif($this->_output_format == "csv_for_excel") {
            //Ergebnis einer Query, welches als CSV (otimiert für Excel; führende Nullen) ausgegeben werden soll
            $this->buildCsvFile(true);
            $this->clientrelevant_format = true;
        } elseif($this->_output_format == "text/html") {
            //Ergebnis einer Query, welches als Tabelle ausgegeben werden soll
            $this->buildHtmlFile();
            $this->clientrelevant_format = true;
        } elseif($this->_output_format == "list") {
            //nothing to do, da $this->_queryresult bereits als Ergebnismenge zurückgegeben werden kann.
            $this->clientrelevant_format = false;
        } elseif($this->_output_format == "vquery") {
            ////Ergebnis einer Query, welches als neue Tabelle in eine Datenbank geschrieben werden soll
            if(occurredAnySqlError() == 0) {
                $this->buildVquery();
            } else {
                //Wenn ein Fehler auftrat, dann kann buildVquery nicht ausgeführt werden. U.U. wird versucht ein Table-Objekt 
                //anzulegen oder Insert-Commands abzustezen. Das könnte im Fehlerfall zu einem Programmabsturz führen.
            }
            $this->clientrelevant_format = false;
        } else {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Ausgabeformat wird nicht unterstützt: ', $this->_output_format);
            $this->clientrelevant_format = false;
        }
    }
    
    
    
    /** ToDo: Derzeit wird nur ein einseitiges Dokument erstellt und somit implizit nur der erste Datensatz verarbeit.
     * Das RTF-Template kann problemlos erweitert werden. Dazu muss es in drei Teile geteilt werden 
     * 1. Vorlauf (Schriftarten usw.) -> endet bei "Dateiname}"
     * 2. Content -> endet vor "{\*\themedata"
     * 3. Nachlauf
     * Der Contenbereich kann beliebig oft neu eingefügt und mit Daten verknüpft werden. Ein Zeilenumbruch wird mit "{\rtf1{\page}}" erzeugt.
     * 
     * Kann das analog auch für HTML realisiert werden?
     * 
     *  
     * Diese Funktion verknüpft die Ergebnismenge der Datenbankabfrage mit einem RTF-Template für die Dokumentenausgabe
     * 
     * @param   object  $in_pagedata        Referenz zum pagedata-object
     */
    protected function buildTemplateFile(&$in_pagedata) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Starte', __FUNCTION__);
        $filecontent = $this->_output_document;
        $queryresult = $this->getQueryResultAsArray();
        
        
        foreach ($queryresult as $key => $datensatz) {
            //ToDo: Für jeden Datensatz kann ein neues Teildokument in das Seriendokument ergänzt werden.
            //      Zurzeit ersetzt bereits der erste DS alle Platzhalter. D.h., die Schleife müsste so verbessert werden,
            //      dass am Ende der Schleife das jeweilige aktuelle Dokument ergänzt wird.
            $filecontent = replacePlaceholderInTemplateBySysdata($this->_output_document, $datensatz, $this->form_array, $in_pagedata);
            $temp_text = "";
            
            //Alle Spalten und Werte des Datensatzes in einer Tabelle untereinander andrucken
            if(strpos($filecontent, '$$all.table_vertical$$') > 0) {
                if($this->_output_format == "html") {
                    $temp_text = buildHtmlTableVertical($datensatz);
                } elseif($this->_output_format = "rtf") {
                    $temp_text = buildRtfTableVertical($datensatz, $this);
                }
            } 
            //Platzhalter ersetzen
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Suche Platzhalter:', '$$all.table_vertical$$'.' für Wert: '.$temp_text);  
            $filecontent = str_replace('$$all.table_vertical$$', $temp_text, $filecontent);
        
        
        }
        
        
        //verbotene Inhalte entfernen
        if($this->_output_format != "rtf") {
            $filecontent = parseSqlValue2($this->_app_id, $filecontent, __FUNCTION__, true, true);
        }
        
        
        
        //Prüfen, ob es Platzhalter gab, die nicht ersetzt werden konnten
            //example:
            //$subs = array('/\[b\](.+)\[\/b\]/Ui' => '<strong>$1</strong>', '/_(.+)_/Ui' => '<em>$1</em>');
            //$raw_text = '[b]this is bold[/b] and this is _italic!_';
	$temp = $filecontent;
	$subs = array('/\$\$(.+)\$\$/' => ' ');
	$filecontent = preg_replace(array_keys($subs), array_values($subs), $filecontent);
        if($filecontent != $temp) {addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  einige Platzhalter konnten nicht ersetzt werden!:', $temp);}
                    
        
        
        
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query - Anzahl Datensätze', count($queryresult));
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query - Datensätze', $queryresult);
        if(count($queryresult) == 0) {
            if($this->_securityConditions_added == true) {$addNote = "\n \n - Es wurden für die aktive Rolle zusätzliche Datensatzeinschränkungen hinterlegt.";} else {$addNote = "";}
            $this->_output_document = "Die Auswertung hat keine Daten ermitteln können. Mögliche Ursachen: \n - Es sind nicht alle notwendigen Maskenfelder gefüllt.".$addNote;
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Kein Ergebnis für query:', $this->_sql);
        } else {
            $this->_output_document = $filecontent;
        }
        
    }
    
    
    
    
    /** Bereitet das Query-Ergebnis im csv-Format vor.
     * Alle Werte werden durch ein Semikolon getrennt in eine Textdatei geschrieben.
     * 
     * @param  boolean  $in_format_for_excel        Wenn true, dann werden alle Werte, die mit einer Null beginnen in das Format
     *                                              ="[value]" übertragen. Bsp.: 0260 => ="0260"
     */
    protected function buildCsvFile($in_format_for_excel) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Starte', "buildCsvFile");
        
        
        
        $filecontent = $this->_output_document;
        $queryresult = $this->getQueryResultAsArray();
        $myTempTable = "";                          //TempTable wird benötigt, da String-Verknüpfung irgendwann gaaanz langsam wird.
        $myTableHelper_array = array();
        $myTable = "";
        $row = 0;
        $headline = "";
        
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query - Anzahl Datensätze', count($queryresult));
        foreach ($queryresult as $key => $datensatz) {
            //Wenn noch keine Zeile geschrieben wurde, dann zuerst die Überschriftenzeile einfügen.
            if($row == 0) {$addHeadline = true;} else {$addHeadline = false;}
            //neue Zeile in CSV
            $row = $row + 1;
            $column = 0;
            $rowContent = "";
            foreach ($datensatz as $feldname => $feldwert) {
                $column = $column + 1;
                $praefix = '';
                $suffix = '';
                //Wenn die erste Spalte bearbeitet/geschrieben wird, wird das Trennzeichen auf "" gesetzt.
                if($column == 1) {$delimiter = ""; } else {$delimiter = ";";}
                //Überschriften sammeln
                if($addHeadline == true) {
                    $my_feldname = getColumnnameFromTableAndColumn($feldname, true);
                    $headline = $headline.$delimiter.$my_feldname;
                }
                //Dateiinhalte sammeln
                if($in_format_for_excel === true) {
                    if(substr($feldwert ?? '', 0, 1) == "0") {
                        $praefix = '="';
                        $suffix = '"';
                    } 
                }
                $rowContent = $rowContent.$delimiter.$praefix.$feldwert.$suffix;
                
                
            }
            //Daten nach filecontent schreiben.
            if($addHeadline == true) {$myTempTable = $myTempTable.$headline."\r\n";}
            $myTempTable = $myTempTable.$rowContent."\r\n";
            
            if($row % 10000 == 0) {
                //Reset $myTempTable
                //wenn zu viele Datensätze via String verknüpft werden, wird das Programm sehr langsam. Daher werden Stringketten in einem 
                //Array zwischengespeichert.
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query - verarbeite Datensatz', $row);
                $myTableHelper_array[] = $myTempTable;
                $myTempTable = "";
            }
        }
        
        //Datensätze, welche nach dem letzten Reset von $myTempTable verarbeitet wurden, ebenfalls an $myTableHelper_array übertragen
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query - verarbeite Datensatz', $row);
        $myTableHelper_array[] = $myTempTable;
        
        
        if(count($queryresult) == 0) {
            $localfeedback = "Die Auswertung hat keine Daten ermitteln können. Möglicherweise sind nicht alle notwendigen Maskenfelder gefüllt.";
            $localfeedback = $localfeedback."\r\n \r\n";
            $localfeedback = $localfeedback."The query was unable to determine any data. maybe not all of the necessary mask fields are filled.";
        } else {
            $myTable = implode("", $myTableHelper_array);
            $start_tag = getConfig("html_start_tag_function_placeholder", global_variables::getAppIdFromSYS01());
            $end_tag = getConfig("html_end_tag_function_placeholder", global_variables::getAppIdFromSYS01());
            $localfeedback = replacePlaceholderInString($filecontent, $start_tag, $end_tag, $myTable);
            //Wenn keine Platzhalter gefunden werden, wird das Template ignoriert und die Query-Daten als CSV-Tabelle stattdessen in die Ergebnisdatei geschrieben.
            if($localfeedback === false) {$localfeedback = $myTable;}
        }
        

        
        //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Query - Dateiinhalt', $this->_output_document);
        
        $this->_output_document = $localfeedback;
    }
    
    
    
    
    /**
     * erstellt in dem gewünschten Schema die Tabelle "vquery_..." und legt dort die 
     * Ergebnisdatenenge ab.
     * Wenn die Tabelle bereits existiert und die Datenstruktur mit der Ergebnismenge übereinstimmt, 
     * werden die vorhandenen Daten aktualisiert.
     * 
     * Wenn die Tabelle bereits existiert, jedoch die Datenstruktur von der Ergebnismenge abweicht, 
     * dann wird die Tabelle gelöscht (drop) und neu angelegt.
     * 
     * @return  boolean
     */
    protected function buildVquery() {
        $abort = false;                 //legt fest, ob die Erstellung der Tabelle abgebrochen werden muss
        $repeat = false;
        $createTableNew = false;        //legt fest, ob die vquery-table neu angelegt werden muss
        $dropTable = false;
        
        //prüfen, ob es sich um einen zulässigen Tabellennamen handelt
        $tableSchemaAndName = $this->isVquerynameAllowed($this->_template_file);
        
        
        //prüfen, ob die vQuery bereits in diesem Programmdurchlauf aktualisiert wurde. Mehrfaches Aktualisieren innerhalb des selben Programmablaufs
        //beeinflusst die Performance negativ und führt nicht zu anderen Daten.
        if(in_array($this->_template_file, global_variables::$usedVquery)==true) {
            //keine weitere Aktivität notwendig
            $feedback = true;
            
        } else {
            if($tableSchemaAndName !== false) {
                //prüfen, ob die Tabelle existiert. Dazu das information_schema nutzen.
                $condition = "table_schema = '".$tableSchemaAndName["schemaname"]."' AND table_name = '".$tableSchemaAndName["tablename"]."'";
    //            $vqueryTableStructure = getTableData($this->_connection_id, "columns", global_variables::getNameOfDbSchemaInformation(), false, "", $condition);
                $vqueryTableStructure = getTableData(global_variables::getAppIdFromSYS01(), "columns", global_variables::getNameOfDbSchemaInformation(), false, "", $condition);

                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  vquery-tablestructure',$vqueryTableStructure);


                if($vqueryTableStructure == array()) {
                    //Es wurden im Information_schema keine Strukturdaten der vquery-Tabelle gefunden. D.h., dass die Tabelle nicht existiert.
                    $createTableNew = true;
                } else {
                    if($this->_queryresult === false) {$columnlist = array();} else {$columnlist = $this->_queryresult[0];}
                    $tableCompatibility = $this->isTableCompatible($vqueryTableStructure, $columnlist, $tableSchemaAndName);
                    if($tableCompatibility == "false") {
                        //Wenn die Struktur der vorhandenen Tabelle nicht zu der Datenstruktur der vQuery passt oder keine Daten einzufügen sind.
                        $createTableNew = true;
                        $dropTable = true;
                    } elseif($tableCompatibility == "noActionNeeded") {
                        $abort = true;
                    }
                }
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Ergebnis Prüfung vquery-Structure', "Neuanlegen? (1 => ja): ".$createTableNew);

                if($abort == false AND $this->_queryresult!= false) {
                    //drop-, delete-, create- und insert-Befehle (je nachdem was gebraucht wird) mit Hilfe der Connection_backup-Class erstellen
    //                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  CreateScript', "Starte CreateScript");
                    $createCommand = $this->getVqueryScript($tableSchemaAndName, $this->_queryresult, $dropTable, $createTableNew);
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  CreateScript', $createCommand);


                    //import-connection-id in Abhängigkeit von target-Schema ermitteln
                    $connection_id_from_targetschema = getAppIdFromSchema($tableSchemaAndName["schemaname"]); //ggf. bei diesem Methodenaufruf noch versuchen den zweiten Parameter zu ergänzen, falls die APP-ID nicht korrekt ermittelt wird.
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Connection-ID: ',$connection_id_from_targetschema);
                    //Script ausführen
                    $script_feedback = db_connection_handler::executeScriptOnDatabase($connection_id_from_targetschema, $createCommand, __FUNCTION__, false);
                    if($script_feedback >= 0) {
                        $feedback = true;
                    } else {
                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Fehler bei Scriptausführung: ',"FeedbackCode: ".$script_feedback);
                        $feedback = false;
                    }
                } else {
                    $feedback = true;
                }
            } else {
                $feedback = false;
            }
            
            if($feedback === true) {
                //vQuery zur Liste der vQueries, die im aktuellen Programmdurchlauf bereits aktualisiert wurden, ergänzen.
                //Dadurch können mehrfache Aktualisierungen vermieden werden.
                global_variables::$usedVquery[] = $this->_template_file;
            }
            
        }
        return $feedback;

    }
    
    
    
    
    /** Gibt den Create-Befehl für eine Tabelle zurück, welche die Daten der vquery aufnehmen kann.
     * 
     * @param   array   $in_tableSchemaAndName      Schema und Tabellenname; Bsp.: array(schemaname => manager, tablename => vquery_app)
     * @param   array   $in_valuelistVQuery         Liste der Daten, die in die Tabelle importiert werden sollen. 
                                                    Bsp.: array([0] => Array(
                                                               [app.id] => SYS01
                                                               [app.name] => Kernsystem
                                                               [app.picture] => blabla
                                                           ))
     * @param   boolean $in_dropTable               Gibt an, ob die vQuery-Tabelle bereits existiert und ersetzt werden soll
     * @param   boolean $in_createTable             Gibt an, ob die vQuery-Tabelle neu erzeugt werden soll
     * @return  string                              Create-Befehl
     */
    private function getVqueryScript($in_tableSchemaAndName, $in_valuelistVQuery, $in_dropTable, $in_createTable) {
        $dropCommand = "";
        
        
        //Tabelle droppen, wenn vorhanden
        if($in_dropTable === true OR $in_createTable === true) {
            $dropCommand = $this->getVqueryDropTableCommand($in_tableSchemaAndName);
            $dropCommand = $dropCommand."\n\n";
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Drop-Table-Command ', $dropCommand);
        }
        
        
        
        
        //Insert-Befehle vorbereiten
        $columnlist = array();
        //Column-Liste für Standard-Spalten erzeugen
        $i = 1;
        $column["columns.table_schema"] = $in_tableSchemaAndName["schemaname"];
        $column["columns.table_name"] = $in_tableSchemaAndName["tablename"];
        $column["columns.column_name"] = "id";
        $column["columns.data_type"] = "int";
        $column["columns.character_maximum_length"] = "";
        $column["columns.ordinal_position"] = $i;
        $column["columns.is_nullable"] = "NO";
        $column["columns.extra"] = "auto_increment";
        $column["columns.column_default"] = "nextval";
        $columnlist[] = $column;
        
        $i = $i +1;
        $column["columns.column_name"] = "connection_id";
        $column["columns.data_type"] = "varchar";
        $column["columns.character_maximum_length"] = "5";
        $column["columns.ordinal_position"] = $i;
        $column["columns.is_nullable"] = "";
        $column["columns.extra"] = "";
        $column["columns.column_default"] = "";
        $columnlist[] = $column;  
        
        
        //Column-Liste für alle Spalten der vQuery erzeugen; Dazu wird der erste Datensatz der valueList als Muster genutzt
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  in_valuelistVQuery ', $in_valuelistVQuery);
        foreach ($in_valuelistVQuery[0] as $tableAndColumn => $value) {
            $i = $i +1;
            $tableAndColumnArray = explode(".", $tableAndColumn);
            $column["columns.column_name"] = $tableAndColumnArray[1];
            $column["columns.data_type"] = "varchar";
            $column["columns.character_maximum_length"] = "10000";
            $column["columns.ordinal_position"] = $i;
            $column["columns.is_nullable"] = "";
            $column["columns.extra"] = "";
            $column["columns.column_default"] = "";
            $columnlist[] = $column;  
        }
        
        //valueList der vQuery muss um die Konstante (connection_id) in jedem Datensatz ergänzt werden, damit die Insert-Befehle diesen Wert enthalten
        //Das darf jedoch nicht vor der vorherigen Schleife erfolgen, da sonst die connection_id zweimal in columnlist existiert.
        $in_valuelistVQuery = addConstToAMultiArray($in_valuelistVQuery, $in_tableSchemaAndName["tablename"]."."."connection_id", $this->_connection_id);
        $primaryKeys = array("id", "connection_id");
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Columnlist ', $columnlist);
        
        //backupTable instanzieren
        //Die Methode createTableDropCommand aus der backup_helper_class erwartet ein Zweidimensionales Array
        $tablearray = array();               
        $tablearray["tables.table_schema"] = $in_tableSchemaAndName["schemaname"];
        $tablearray["tables.table_name"] = $in_tableSchemaAndName["tablename"];

        //create-, delete- und insert-Befehle abfordern
        $sqlLanguage = getValueFromConfigXml($this->_connection_id, "dbms");
        
        $vQueryScript = backup::getScriptForVquery($sqlLanguage, $tablearray, $columnlist, $in_valuelistVQuery, $in_createTable, $primaryKeys, "connection_id ='".$this->_connection_id."'");
        
        
        return $dropCommand.";\n".$vQueryScript;
    }
    
    
    
    
    /** Ermittelt den Drop-Table-Befehl in der Syntax des passenden DBMS.
     * 
     * @param   array   $in_tableSchemaAndName      Schema und Tabellenname; Bsp.: array(schemaname => manager, tablename => vquery_app)
     * @return type
     */
    private function getVqueryDropTableCommand($in_tableSchemaAndName) {
        //Die Methode createTableDropCommand aud der backup_helper_class erwartet ein Zweidimensionales Array
        $tablelist = array();               
        $tablelist[0]["tables.table_schema"] = $in_tableSchemaAndName["schemaname"];
        $tablelist[0]["tables.table_name"] = $in_tableSchemaAndName["tablename"];

        //alte Tabelle droppen
        $sqlLanguage = getValueFromConfigXml($this->_connection_id, "dbms");
        $dropTableCommand = backup::getDropTableCommand($sqlLanguage, $tablelist);
        
        //Da nur ein Tabellenname übergeben wurde, kann es auch nur einen Drop-Befehl geben.
        return $dropTableCommand[0].";";
    }
    
    
    
    /** Prüft ob der templateName für eine vquery zulässig ist.
     * Erwartete Syntax ist schemaname.tablename  .
     * Außerdem muss tablename mit dem Präfix "vquery_" beginnen.
     * 
     * @param   string      $in_templatename        Wert, der in query.template_file
     * @return  mixed                               false, wenn der Name nicht zulässig ist. Ansonsten array mit schemaname und tablename
     *                                              bsp.: array(schemaname => manager, tablename => vquery_app)
     */
    private function isVquerynameAllowed($in_templatename) {
        $feedback = array();
        if(strpos($in_templatename ?? '', ".")) {
            //vor dem Punkt sollte das Schema und nach dem Punkt der Tabellenname stehen
            $target = explode(".", $in_templatename);
            $feedback["schemaname"]  = $target[0];
            $feedback["tablename"] = $target[1];
            $subQueryPräfix = global_variables::getPräfixForVqueryTables();
            if(substr($feedback["tablename"], 0, strlen($subQueryPräfix)) == $subQueryPräfix) {
                //Änderung der Tabelle ist zulässig
            } else {
                $feedback = false;
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Prüfung Tabellennamen', "Die Zieltabelle trägt einen ungültigen Namen. Er beginnt nicht mit ".global_variables::getPräfixForVqueryTables());
            }
            
        } else {
            $feedback = false;
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Prüfung Tabellennamen', "Tabellenname ist uneindeutig. Die Syntax muss schema.table entsprechen.");
        }
        
        return $feedback;
    }
    
    
    
    /** Die Funktion prüft, ob die neuen Daten zur vorhandenen Tabellenstruktur passen.
     * Dazu wird geprüft, ob  die Feldbezeichnungen des ersten Datensatzes der neuen Daten in der
     * Liste der Columns aus dem Informationschema existieren.
     * 
     * @param   array   $in_columnExistingTable                 Liste der Spalten, die mit der gewählten Connection_id aus dem Information_schema ermittelt werden können.
     *                                                              Bsp.: Array(
                                                                                [0] => Array(
                                                                                        [columns.table_schema] => manager
                                                                                        [columns.table_name] => vquery_columns
                                                                                        [columns.column_name] => app_id)
                                                                                [1] => Array(
                                                                                        [columns.table_schema] => manager
                                                                                        [columns.table_name] => vquery_columns
                                                                                        [columns.column_name] => id))
     * @param   array   $in_ColumnListVquery                    Ein Datensatz der Daten, die in die Tabelle importiert werden sollen. 
     *                                                              Bsp.: Array(
                                                                                [app.id] => SYS01
                                                                                [app.name] => Kernsystem
                                                                                [app.picture] => blabla
                                                                            )
     * @param   array   $in_tableSchemaAndName                  Schema- und Tabellenname der Tabelle, welche durch die vQuery erzeugt werden soll
     *                                                              Bsp.: Array(
                                                                            [schemaname] => manager
                                                                            [tablename] => vquery_columns
                                                                        ))
     * @return  string                                          "true"           -> Daten passen zur Tabelle <br />
     *                                                          "false"          -> Daten passen nicht zur Tabelle <br />
     *                                                          "noActionNeeded" -> Es gibt keine Daten zum einfügen, daher ist keine Aktion notwendig
     */
    protected function isTableCompatible($in_columnExistingTable, $in_ColumnListVquery, $in_tableSchemaAndName) {
        $feedback = "";
        
        //prüfen, ob die Tabelle existiert. Dazu das information_schema nutzen.
        if($in_columnExistingTable == array()) {
            //die Tabelle existiert bisher nicht
            $feedback = "false";
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Prüfung, vquery-table', "Tabelle existiert bisher nicht -> neu anlegen");
        } elseif($in_ColumnListVquery == false OR $in_ColumnListVquery == array()) {
            //die Tabelle existiert bisher nicht
            $feedback = "noActionNeeded";
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Prüfung, vquery-table', "es gibt keine Daten einzufügrn -> vquery-Tabelle wird nicht verändert");
        } else {
            //prüfen, ob alle Spalten vorhanden sind
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Ergebnis vquery', $this->_queryresult);
            //die Spalten aus $this->_queryresult und zusätzlich die Spalten id und connection_id müssen in $vqueryTableData existieren
            //Wenn eine Spalte nicht existiert, wurde die zu Grunde liegende Query geändert und die vQuery-Tabelle muss komplett neu angelegt werden.
            $additionalNeededColumns = array();
            $additionalNeededColumns[$in_tableSchemaAndName["tablename"].".connection_id"] = "blabla";                    //Value ist an dieser Stelle irrelevant, der key enthält den Spaltennamen
            $additionalNeededColumns[$in_tableSchemaAndName["tablename"].".id"] = "blabla2";
           
            //Prüfen, ob die Columns von $in_ColumnListVquery in der vquery-Table existieren
            $localfeedback = $this->existColumns($in_ColumnListVquery, $in_columnExistingTable);

            //Wenn bisher alle Spalten gefunden wurden, dann prüfen ob auch die addittionalNeededColumns in der vqueryTable existieren
            if($localfeedback == true) {
                $localfeedback = $this->existColumns($additionalNeededColumns, $in_columnExistingTable);
                if($localfeedback === false) {
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Zwischenergebnis', "additionalColumns fehlen");
                    $feedback = "false";
                } else {
                    $feedback = "true";
                }
            } else {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Zwischenergebnis', "Columns der Query fehlen in der vorhandenen Tabelle");
                $feedback = "false";
            }
            
        }
        

        
        return $feedback;
    }
    
    
    
    
    /** Prüft, ob die SearchColumns in existsColumns vorhanden sind.
     * 
     * @param   array   $in_searchColumns       Syntax Bsp.: 
     *                                              Array(
                                                        [app.connection_id] => SYS01
                                                        [app.id2] => 1234
                                                    ))
     * @param   array   $in_existColumns        Syntax siehe Beschreibung zu $in_columnlistFromInformationSchema in der function isTableCompatible
     * @return  boolean
     */
    protected function existColumns($in_searchColumns, $in_existColumns) {
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SearchedColumns', $in_searchColumns);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  ExistingColumns', $in_existColumns);
            
        $feedback = true;
        foreach ($in_searchColumns as $tableAndColumn => $value) {
            
            $currentTableAndColumnArray = explode(".", $tableAndColumn);    //Tabelle und Array splitten, um nur auf den Spaltennamen zugreifen zu können
            $neededColumn = $currentTableAndColumnArray[1];

            $columnExists = false;
            foreach ($in_existColumns as $key => $ColumnData) {
                
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  vergleiche Spalten', $neededColumn." -> ".$ColumnData["columns.column_name"]);
                if($neededColumn == $ColumnData["columns.column_name"]) {
                    $columnExists = true;
                    // Wenn die Spalte gefunden wurde, kann die Suche nach dieser Spalte abgebrochen werden.
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  vergleiche Spalten', "Spalte gefunden!");
                    break;
                }
            }
            
            //Wenn eine Spalte nicht gefunden wurde, dann Abbruch
            if($columnExists == false) {
                $feedback = false;
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  fehlende Spalte', $neededColumn);
                break; 
            }            
        }
        
        return $feedback;
    }
    
    
    
    
    /** Erstellt aus $this->_queryResult einen String der die Ergebnismenge innerhalt einer html-Tabelle enthält.
     * Das Ergebnis wird in $this->_output_document abgelegt.
     * 
     */
    protected function buildHtmlFile() {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Starte', "buildHtmlFile");
        
        $myTable = "";
        $filecontent = $this->_output_document;
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  File-Template', $this->_output_document);
        $queryresult = $this->getQueryResultAsArray();
        
        
        $myTable = $myTable.buildHtmlTableHorizontalQuery($queryresult)."\n";
        

        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query - Anzahl Datensätze', count($queryresult));
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query - Datensätze', $queryresult);
        if($queryresult == false) {
            $localfeedback = "Die Auswertung hat keine Daten ermitteln können. Möglicherweise sind nicht alle notwendigen Maskenfelder gefüllt.";
        } else {
            $start_tag = getConfig("html_start_tag_function_placeholder", global_variables::getAppIdFromSYS01());
            $end_tag = getConfig("html_end_tag_function_placeholder", global_variables::getAppIdFromSYS01());
            $localfeedback = replacePlaceholderInString($filecontent, $start_tag, $end_tag, $myTable);
            //Wenn keine Platzhalter gefunden werden, wird das Template ignoriert und die Query-Daten als CSV-Tabelle stattdessen in die Ergebnisdatei geschrieben.
            if($localfeedback === false) {$localfeedback = $myTable;}
        }
        
        
        
        
        //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Query - Dateiinhalt', $this->_output_document);
        
        $this->_output_document = $localfeedback;
        
    }
    
    
    
    
    
    
    
    
    
    /** Liest das template in $this->_output_document ein, wenn $this->_template_file <> ""
     * 
     */
    protected function readTemplatefile() {
        
        
        if($this->_template_file <> "" AND $this->_output_format <> "vquery") {
            //Wenn ein Template angegeben wurde und es sich nicht um eine vquery handelt, wird das Template eingelesen
            $myDirSep = global_variables::getDirectorySeparator();
            $query_template_path = "..".$myDirSep.global_variables::getPathForQueryTemplate_rel($this->_app_id);
            $fileWithPath = $query_template_path.$this->_template_file;
            
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  template_file: ', $fileWithPath);
        
            $this->_output_document = file_get_contents($fileWithPath);
            if($this->_output_document === false) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "Datei konnte nicht eingelesen werden","ERROR");
                $this->_output_document = "Fehler: Template konnte nicht gelesen werden! \n\n ".$fileWithPath;
            }
            //php-tags entfernen
            $this->_output_document = str_replace('<?php /*', '', $this->_output_document);
            $this->_output_document = str_replace('?>', '', $this->_output_document);
        }
        
    }
    
    
    
    
    
    /** Funktion ermittelt anhand einer ID (siehe DB-Tabelle query) den SQL-Befehl und die Metadaten für eine Abfrage.
     * Der SQL-Befehl wird in $this->_sql hinterlegt.
     * 
     * @param String    $in_limit                       [optional] Anzahl der anzuzeigenden Datensätze (default = 0; 0 = deaktiviert)
     * @param String    $in_offset                      [optional] Anzahl der zu überspringenden Datensätze, bis zum ersten anzuzeigenden (default = 0)
     * @param boolean   $in_deactivateSecurityCondition [optional] Gibt an, ob die Security-Conditions beim ermitteln der Inhaltsdaten deaktiviert werden sollen. Wenn treu, dann überlagert diese Vorgabe $this->deactivate_security
     * 
     */
    protected function buildQuery($in_limit = 0, $in_offset = 0, $in_deactivateSecurityCondition = false) {
        
                
        //Alle Daten der gewünschten query abfragen und die Query aufbauen. Dabei wird auch ein sqlRequest-Objekt erzeugt, 
        //wenn der SQL-Befehl nicht bereits vorggeben wurde (sql_statement <> no-sql).
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  starte mit limit und offset', $in_limit.",".$in_offset);
        $this->getQueryData($this->_app_id, $this->_id, $in_limit, $in_offset);
        
        //Daten des sendenden Formulars abfragen, um Kriterien, welche nur für dieses Formular gelten ermitteln zu können.
        
        
        
        //Kritereinliste um Values aus this->_inputDatensätze ergänzen
        $this->getCriteriaList($this->_inputDatensaetze);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  um values ergänzte Kriterienliste aus query_criteria in object', $this->_criteriaList);
        
        //Platzhalter in SQL durch values der übergebenen Datensätze ersetzen
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query_sql mit Platzhalter', $this->_sql);
        $this->replacePlaceholderForCriteria();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query_sql mit Values', $this->_sql);
        
        //SqlRequest-Object gleichziehen mit lokalen SQL-Befehl
        if($this->_sqlRequest_object == NULL) {
            //Wenn das sqlRequest-object noch nicht existiert, dann liegt eine Query vom Typ <> no_sql vor.
            //Es wird ein Dummy-sqlRequest-Object angelegt
            if($in_deactivateSecurityCondition === true) {
                //nur wenn $in_deactivateSecurityCondition mit true vorgegeben wurde, dann übernehmen.
                //ansonsten würde der optionale Vorgabewert dieser Methode verwendet werden.
                $this->_deactivate_security = $in_deactivateSecurityCondition;
            }
            $this->_sqlRequest_object = new sql_request($this->_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__, $this->_deactivate_security);
        }
        $this->_sqlRequest_object->setSqlCommand($this->_sql);
        
        
        
    }
    
    
    /** Ermitellt aus der DB-Tabelle query_criteria die Kriterienliste für die aktuelle query. Die Kriterienplatzhalter werden dabei
     * durch die tatsächlichen Werte aus den Datensätzen, welche durch das POST-Objekt übergeben wurden, ersetzt.
     * 
     * @param   array   $in_datensaetze     Liste der Datensätze, die vom POST_Array übergeben wurden. Aus dem/den Datensätzen werden die values für die Kriterien ermittelt 
     * @return  boolean                     Die Kriterienliste wird in $this->_criteriaList abgelegt. Wenn dies scheitert, dann wird false zurückgegeben, sonst true. Der Grund für das scheitern, wird in debug-table abgelegt.          
     */
    protected function getCriteriaList($in_datensaetze) {
        
        //Kritereinliste um Values aus this->_inputDatensätze ergänzen
        
        //Kriterienliste aus der DB-Tabelle query_criteria für die aktuelle query ermitteln
        $criterialist = $this->getQueryCriterialist($this->form_array);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  POST_Datensätze für Query', $in_datensaetze);
        
        $CountFoundValues = 0;       
        
        if($criterialist <> false){ 
            //Kriterien um Werte aus Inputdatensätzen ergänzen
            foreach ($criterialist as $key_criteria => $value_criteria) {
                //Ein Array zur Aufnahme der Kriterinwerte im aktuellen Kriterium ergänzen
                $value_criteria["values"] = array();
                foreach ($in_datensaetze as $key_datensatz => $value_datensatz) {
                    //Prüfen, ob die Kriterien für das aktuelle Formular angegeben wurden   
                    //Für Query-Preview könnte die folgende Bedingung  hinderlich sein.
                    if($value_criteria["feld.form_id"] == $value_datensatz["form"]) {
                        //Prüfen, ob im Datensatz ein Wert für das aktuelle Kriterium vorhanden ist
//                        echo "suche: ".$value_datensatz["content"][$value_criteria["feld.spalte"]]."<br />";
//                        if(strpos($value_criteria["feld.spalte"], "."))  {  
//                            ////Bei Query-basierten Formularen kann es notwendig sein, dass in feld.spalte auch der Tablename angegeben wird.
//                            //Dieser muss hier jedoch ignorert werden.
//                            $tableAndColumn = explode(".", $value_criteria["feld.spalte"]);
//                            $column = $tableAndColumn[1];
//                        } else {
                            $column = $value_criteria["feld.spalte"];
                            if(strpos($column,".") === false) {$column = ".".$column;}       //Dadurch kann die nachfolgende "issetkey-Funktion die Spalte eindeutiger erkennen.
//                        }
                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Kriterium', $value_criteria);
                        
                        
                        $targetColumn = issetKeyLike($value_datensatz["content"], $column);
                        if($targetColumn !== false) {
                            //Den Wert in die kriterienliste übertragen
                            $value_criteria["values"][] = $value_datensatz["content"][$targetColumn];
                            $CountFoundValues = $CountFoundValues +1;
                        } 
                    }
                }
                //Kriterien werden zusätzlich als kommaseparierte Liste ergänzt.
                $value_criteria["valuesAsString"] = arrayToString($value_criteria["values"], "string", ", ");
                //aktuelles Kriterium wieder in die Kriterienliste zurückschreiben, sodass die Ergänzungen erhalten bleiben
                $criterialist[$key_criteria] = $value_criteria; 
            }
            $this->_criteriaList = $criterialist;
        } else { 
            $this->_criteriaList = array(); 
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Kriterien nicht ersetzt', 'keine Post-Variable oder keine Kriterien vorhanden', "INFO");
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Kriterienliste', $criterialist, "INFO");
            
        }
        
//        if(is_null($criterialist)) {$count_criterialist = count($criterialist);} else {$count_criterialist = 0;}    //notwendig, da count($criterialist) einen Fehler wirft, wenn $criterialist nicht definiert ist
        if($criterialist==false) {$count_criterialist = 0;} else {$count_criterialist = count($criterialist);}   //notwendig, da count($criterialist) einen Fehler wirft, wenn $criterialist nicht definiert ist
        
        if($CountFoundValues < $count_criterialist AND $CountFoundValues <> false) {
            //nicht alle Platzhalter für Kriterien konnten ersetzt werden
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  nicht alle Kriterien konnten ersetzt werden. Anzahl Kriterien = '.$count_criterialist.' - Anzahl Platzhalter = '.$CountFoundValues, "mögliche Fehlerursachen: 1. Tabelle query_criteria, \n 2. Felder des Formulars enthielten keine Werte. 3. ...", "ERROR");
            return false;
        } else {
            return true;
        }
    }
    
    
    
    
    /**
     * Ersetzt die Platzhalter für Kriterien in _sql durch die Values der Kriterien
     */
    protected function replacePlaceholderForCriteria() {
        $mySql = $this->_sql;
        $criteriaList = $this->_criteriaList;
        
        foreach ($criteriaList as $key => $criteria) {
            $criteria_id = "$$".$criteria["query_criteria.id"]."$$";
            $mySql = str_replace($criteria_id, $criteria["valuesAsString"], $mySql);
        }
        $this->_sql = $mySql;
    }
    
    
    
    
    
    /** Ermittelt aus der DB-Tabelle query alle Daten zur gewünschten query und erstellt den SQL-Befehl. 
     * Dabei werden Platzhalten für Kriterien (query_criteria oder interne Variablen (query_add_condition.value_internvariable) noch nicht ersetzt.
     * Der SQL-Befehl wird in $this->_sql abgelegt.
     * 
     * @param   string  $in_query_app_id                    APP-ID der query
     * @param   integer $in_query_id                        ID der query
     * @param   String  $in_limit                           [optional] Anzahl der anzuzeigenden Datensätze (default = 0; 0 = deaktiviert)
     * @param   String  $in_offset                          [optional] Anzahl der zu überspringenden Datensätze, bis zum ersten anzuzeigenden (default = 0)
     * 
     * 
     * @return  nothing                                     Es gibt keinen Rückgabewert. Die Ergebnisse werden direkt in die Eigenschaften des query-Objektes ($this) geschrieben.
     */
    protected function getQueryData($in_query_app_id, $in_query_id, $in_limit = 0, $in_offset=0) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        
        if($in_query_app_id == false or $in_query_id == false){
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> query_app_id = '.$in_query_app_id.' | query_id = '.$in_query_id, "FEHLER: Entweder wurde die app_id oder die id  der query nicht angegeben.", "ERROR");
            
        } else {
        
            //Alle Daten der gewünschten query abfragen
            $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
                $queryRequest->addSelectColumn("query", "id");
                $queryRequest->addSelectColumn("query", "app_id");
                $queryRequest->addSelectColumn("query", "name");
                $queryRequest->addSelectColumn("query", "description");
                $queryRequest->addSelectColumn("query", "sql_statement");
                $queryRequest->addSelectColumn("query", "output_format");
                $queryRequest->addSelectColumn("query", "template_file");
                $queryRequest->addSelectColumn("query", "deactivate_security");
                $queryRequest->addSelectColumn("query", "use_connection");
                $queryRequest->addTable($db_schema_manager, "query", 1, "BASE");
                $queryRequest->addWhereCondition("AND", "", "query", "id", "=", $in_query_id, "");
                $queryRequest->addWhereCondition("AND", "", "query", "app_id", "=", "'".$in_query_app_id."'", "");
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Query-ID: ', $in_query_id.', SQL-Befehl: '.$queryRequest->getSelectCommand());
                
            $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);

            //echo "Query-id: ".$in_query_id."<br />";
            if(is_array($result)) {
                //es wird ein zweidimensionales Array zurückgegeben. Theoretisch dürfte dieses jedoch nur einen Datensatz enthalten, daher wird nur dieser verarbeitet
                $this->_name = $result[0]["query.name"];
                $this->_description = $result[0]["query.description"];
                $this->_sql = $result[0]["query.sql_statement"];
                $this->_output_format = $result[0]["query.output_format"];
    //            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Ausgabeformat: ', $this->_output_format);
                $this->_template_file = $result[0]["query.template_file"];
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Query->Template_File: ', $this->_template_file);
                $this->_deactivate_security = $result[0]["query.deactivate_security"];
                if($this->_connection_id == "") {
                    //Wenn die Connection_id noch nicht gesetzt wurde, beispielsweise durch initialen Parameter beim Erzeugen des query-Objektes, dann ...
                    if($result[0]["query.use_connection"] == "from_role") {
                        //Die App-ID der aktuell angemeldeten Rolle als Connection-ID nutzen
//                        $this->_connection_id = getAppIDFromActiveAccount();
                        $this->_connection_id = getAppIDFromActiveRole();
                    } elseif($result[0]["query.use_connection"] == "from_kernel") {
                        $this->_connection_id = global_variables::getAppIdFromSYS01();
                    } elseif($result[0]["query.use_connection"] == "from_user") {
                        $temp_app_id = getAppIDFromActiveUser();
                        if($temp_app_id == "") {
                            //APP-ID users ist nur belegt, wenn es sich um einen intern verwalteten User handelt.
                            $this->_connection_id = getAppIDFromActiveRole();
                        }
                        $this->_connection_id = $temp_app_id;    
                    } else {
                        //Wenn keine Angabe oder "from_query", dann die App-ID der Query als Connection-ID nutzen.
                        $this->_connection_id = $in_query_app_id;
                    }
                }
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Connection_id: ', "use connection: ".$result[0]["query.use_connection"]." -> ".$this->_connection_id);
                if($this->_sql == "no-SQL") {
                    //ToDo: zukünftig soll es nur noch diesen Weg geben
                    //Wenn $this->_sql = "no-SQL", dann SQL aus den query_part-Tabellen bilden. 
                    $this->_sql = $this->buildSqlRequest($in_limit, $in_offset);
                } else {
                    //Limit und Offset werden auch bei vorgegebenen SQL gesetzt
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Limit und Offset', $in_limit.",".$in_offset);
                    $queryRequest->setLimit($in_limit, $in_offset);
                    $this->_sql = $this->_sql." \n ".$queryRequest->buildLimitPartForSqlCommand();
                }
            }
        }
        
        
        
    }
    
    
    
    /** Erstellt auf Basis der DB-Tabellen query_part... und mit Hilfe eines sql_request-Objektes den SQL-Befehl und
     * gibt diesen als String zurück.
     * 
     * @param integer $in_limit     Anzahl der anzuzeigenden Datensätze. Wenn alle Datensätze angezeigt werden sollen, dann sollte kein LImit-Wert gesetzt werden.
     * @param integer $in_offset    Startpunkt, ab dem limit-Datensätze der Ergebnismenge zurückgegeben werden sollen.
     * @return string                                       SQL-Befehl
     */
    protected function buildSqlRequest($in_limit = 0, $in_offset = 0) {
//        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
//        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        $query = "";
        
        //1. Select-Columns ermitteln
        $this->_sql_select_list = getQuerySelectPart($this->_app_id, $this->_id);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SelectColumnList: ', $this->_sql_select_list);
        
        //2. From-Tables ermitteln
        $this->_sql_from_list = getQueryFromPart($this->_app_id, $this->_id);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SelectFromList: ', $this->_sql_from_list);
        
        //3. join-conditions ermitteln
        $this->_sql_joinCondition_list = getQueryJoinPart($this->_app_id, $this->_id);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SelectJoinList: ', $this->_sql_joinCondition_list);
        
        //4. additionals conditions ermitteln
        if(isset($this->form_array["form.id"])) {$temp_form_id = $this->form_array["form.id"];} else {$temp_form_id = false;}
        $addConditionList = getQueryAddConditionPart($this->_app_id, $this->_id, $temp_form_id);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SelectAddConList: mit Platzhalter', $addConditionList);
        
        //5. OrderBy-Columns ermitteln
        $this->_sql_OrderBy_list = getQueryOrderByPart($this->_app_id, $this->_id);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SelectOrderByList: ', $this->_sql_OrderBy_list);
        
        //6. GroupBy-Columns ermitteln
        $this->_sql_GroupBy_list = getQueryGroupByPart($this->_app_id, $this->_id);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SelectGroupByList: ', $this->_sql_GroupBy_list);
       
        

        //7. SQL-Request-Object erstellen
        $queryRequest = new sql_request($this->_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__, $this->_deactivate_security);
            $this->addFromTablesToSqlRequest($queryRequest, $this->_sql_from_list);
            $this->addSelectColumnsToSqlRequest($queryRequest, $this->_sql_select_list);
            $this->addJoinConditionsToSqlRequest($queryRequest, $this->_sql_joinCondition_list);
            //4.1 Für gebenenfalls vorhandene value_internvariable-Einträge in AddConList die gewünschten values ermitteln
            $this->_sql_addCondition_list = $this->setValuesForInternVariables($addConditionList, $queryRequest);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SelectAddConList: mit ersetzten Platzhaltern', $this->_sql_addCondition_list);
            $this->addConditionToSqlRequest($queryRequest, $this->_sql_addCondition_list);
            $queryRequest->addFormFilterCondition($this->_formFilterCondition);
            $this->addOrderByToSqlRequest($queryRequest, $this->_sql_OrderBy_list);
            $this->addGroupByToSqlRequest($queryRequest, $this->_sql_GroupBy_list);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Limit und Offset', $in_limit.",".$in_offset);
            $queryRequest->setLimit($in_limit, $in_offset);
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  position', "vor getSelectCommand");
        $query = $queryRequest->getSelectCommand();    
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  position', "nach getSelectCommand");
        
        //vermerken, ob Security-Conditions ergänzt wurden
        if($queryRequest->getSecurityConditions() <> array()) { $this->_securityConditions_added = true;}
        $this->_sqlRequest_object = $queryRequest;
        
        return $query;
    }
    
    
    
    /** Ermittelt für  $in_addConditionList["query_add_condition.value_internvariable"] die richtigen Werte und überträgt diese 
     * $in_addConditionList["query_add_condition.value"].
     * Zudem wird die $in_addConditionList um weitere Einträge ergänzt, wenn triggerFieldsCondition ermittelt werden können.
     * 
     * @param   array   $in_addConditionList        Array, welches durch getQueryAddConditionPart gebildet wird.
     * @param   object  $in_queryRequest            queryRequest-Object für die aktuelle Query
     * @return  array                               Ergänztes array "$in_addConditionList"
     */
    protected function setValuesForInternVariables($in_addConditionList, &$in_queryRequest) {
        $flexInternVariables = $this->_flexInternVariables;
        
        if($flexInternVariables == array()) {
            //wenn nur ein leeres array vorliegt, gibt es nichts zu tun.
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-Parameter-Info: ', "Query-Aufruf erfolgte ohne Angaben von in_flexInternVariables");
        } else {
            foreach ($flexInternVariables as $containerKey => $currentInternVariableContainer) {

//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-Parameter-Info (query '.$this->_id.'): ', "Query-Aufruf mit Parameter: ".$currentInternVariableContainer["type"]);
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-Parameter-Info (query '.$this->_id.'): CurrentInternVariableContainer', $currentInternVariableContainer);
                
                if($currentInternVariableContainer["type"] == "HTMLFieldList") {
    //                //es wurde eine Liste von Feldern in Form eines Objektes vom Typ HTMLFieldList übergeben
    //                $myField_id = $flexInternVariables["id"];
    //                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-myFieldList: ', $flexInternVariables);
    //                $myField = $flexInternVariables["data"]->getField($myField_id); //Objekt vom Typ HtmlField
    //                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-myField: ', $myField);
    //                foreach ($in_addConditionList as $key => $condition) {
    //                    //Conditionlist durchsuchen, nach Einträgen, in denen ein value in Abhängigkeit von einer value_internVariable-Vorgabe gesetzt werden soll.
    //                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-Condition: ', $condition);
    //                    if ($condition["query_add_condition.value_internvariable"] <> "") {
    //                        //Wenn eine value_internvariable existiert, dann versuchen den tatsächlichen Wert aus $myField zu ermitteln
    //                        $property = explode(".", $condition["query_add_condition.value_internvariable"]);       //siehe db-tabelle query_add_condition.value_internvariable. Die Spalte könnte Einträge wie bspw. field.form_app_id enthalten
    //                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-Property: ', $property);
    //                        $property_name = $property[1];
    //                        $value = $myField->getProperty($property_name);
    //                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-Property-Value: ', $value);
    //                        if($value <> "not found") {
    //                            $in_addConditionList[$key]["query_add_condition.value"] = "'".$value."'";
    //                        }
    //                    }
    //                }
    //                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-newConditionList: ', $this->_sql_addCondition_list);

                } elseif($currentInternVariableContainer["type"] == "FormArray") {             
                    //es wurde eine Liste von Eigenschaften eines Formulars übergeben
                    $in_addConditionList = $this->setValuesForInternVariablesFormOrSeesion($currentInternVariableContainer, $in_addConditionList);
                } elseif($currentInternVariableContainer["type"] == "SessionData") {           
                    //es wurde das Array SESSION übergeben
                    $in_addConditionList = $this->setValuesForInternVariablesFormOrSeesion($currentInternVariableContainer, $in_addConditionList);
                } elseif($currentInternVariableContainer["type"] == "formFilterCondition") {           
                    //es wurde das Array aus einem Suchformuar oder das Formular hat eine Default-Bedingung übergeben
                    $this->_setFormFilterCondition($currentInternVariableContainer["data"]);
                } elseif($currentInternVariableContainer["type"] == "triggerFieldsCondition") {
                    $myTriggerFieldsCondition = $this->addConditionsByFielsdependencies($currentInternVariableContainer, $in_queryRequest);
                    if($myTriggerFieldsCondition <> false) {
                        //Trigerconditions zu den addConditions fügen. Die TriggerConditions werden bewußt vorangestellt, da somit Where-Conditions über den Query-Designer sich auf die Trigger-Conditions beziehen können.
                        //Bsp.: RefList_app zeigt die verfügbaren App's in dem Formular "Maskenelement-Gruppe je Maske" im Feld "APP der Maskenelementgruppe" an. Diese wird eingeschränkt durch 
                        //den Wert aus dem Feld "APP der Maske" (bspw. app_id = 'REQ01'). Über den Query-Designer kann nun ergänzt werden: "OR app_id = 'SYS01'".
                        //Wenn die Conditions andersherum aufgelistet werden, greift die Bedingung nicht.
                        $in_addConditionList = array_merge($myTriggerFieldsCondition, $in_addConditionList);
                    }
                }
            }
        }
        
        return $in_addConditionList;           //Änderungen in Eigenschaft zurückgeben.
    }

    
    
    /** Setzt oder ergänzt eine SQL-Bedingung zu $this->_formFilterCondition.
     * 
     * @param String    $in_condition       ein beliebiger SQL-Ausdruck, der in einer Where-Bedingung verwendet werden kann.
     */
    private function _setFormFilterCondition($in_condition) {
        if($this->_formFilterCondition == "") {
            $this->_formFilterCondition = $in_condition;
        } else {
            $this->_formFilterCondition = $this->_formFilterCondition." AND (".$in_condition.")";
        }
    }
    
    
    
    /** Bildet aus einem TriggerFieldCondition-Array ein Array, welches für jede Condition alle notwendigen Daten enthält, um daraus addConditions zu bilden.
     * 
     * @param type $in_InternVariableContainer
     * @param type $in_queryRequest
     * @return boolean
     */
    protected function addConditionsByFielsdependencies($in_InternVariableContainer, &$in_queryRequest) {
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  currentInternVariableContainer: ', $in_InternVariableContainer);
        $feedback = array();
        foreach ($in_InternVariableContainer["data"] as $key => $triggerfield) {
            //Für den Fall, dass sich ein Formular auf Basis einer Query aufgebaut wurde, ist es möglich, dass der Tabellenname in $triggerfield["targetcolumn"] enthalten ist. Syntax: table.column
            if($triggerfield["targettable"]=="") {
                if(strpos($triggerfield["targetcolumn"], ".")) {
                    $tableAndColumn = explode(".", $triggerfield["targetcolumn"]);
                    $triggerfield["targettable"] = $tableAndColumn[0];
                    $triggerfield["targetcolumn"] = $tableAndColumn[1];
                }
            }
            
            $targetTableID = $in_queryRequest->getTableIdByName($triggerfield["targettable"]);
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  targetTableID: ', $targetTableID);
            $feedback[] = Array
                (
                    "query_add_condition.query_part_from_id" => $targetTableID,
                    "query_add_condition.id" => "",
                    "query_add_condition.calm_open" => "", 
                    "query_add_condition.praefix" => "AND",
                    "query_add_condition.columnname" => $triggerfield["targetcolumn"],
                    "query_add_condition.operator" => "=",
                    "query_add_condition.value" => "'".$triggerfield["value"]."'",
                    "query_add_condition.value_internvariable" => "",
                    "query_add_condition.calm_close" => "",
                    "query_add_condition.sort" => ""
                );
        }
        if($feedback == array()) {
            return false;
        } else {
            return $feedback;
        }
    }


    
    
    
    /** Ermittelt für  $in_addConditionList["query_add_condition.value_internvariable"] die richtigen Werte und überträgt diese 
     * $in_addConditionList["query_add_condition.value"].
     * Beachte: internValues, welche über die Datenbanktabelle role_access_restriction eingegeben wurden, werden in db_connection_handler_class.getSecurityConditionsForTables
     * aufgelöst.
     * 
     * @param array $in_InternVariableContainer  flexibler Container, siehe $this->_flexInternVariables
     * @param array $in_addConditionList         Array, welches durch getQueryAddConditionPart gebildet wird.
     * @return string
     */
    protected function setValuesForInternVariablesFormOrSeesion($in_InternVariableContainer, $in_addConditionList) {
        $myData = $in_InternVariableContainer["data"]; 
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-myForm: ', $myData);
        foreach ($in_addConditionList as $key => $condition) {
            //Conditionlist durchsuchen, nach Einträgen, in denen ein value in Abhängigkeit von einer value_internVariable-Vorgabe gesetzt werden soll.
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-Condition: ', $condition);
            if ($condition["query_add_condition.value_internvariable"] <> "") {
                //Wenn eine value_internvariable existiert, dann versuchen den tatsächlichen Wert aus $myField zu ermitteln
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-Property: ', $condition["query_add_condition.value_internvariable"]);
                if(isset($myData[$condition["query_add_condition.value_internvariable"]])) {
                    $value = $myData[$condition["query_add_condition.value_internvariable"]];
                    if($condition["query_add_condition.operator"] == "in") {
                        $in_addConditionList[$key]["query_add_condition.value"] = "(".$value.")";
                    } elseif($condition["query_add_condition.operator"] == "like") {
                        $in_addConditionList[$key]["query_add_condition.value"] = "'%".$value."%'";
                    } else {
                        $in_addConditionList[$key]["query_add_condition.value"] = "'".$value."'";
                    }

                    
                    
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query-Property-Value: ', $value);
                }
                
                //Besonderheit: wenn active_role-Daten aus der Session-Variable gesucht werden:
                if($condition["query_add_condition.value_internvariable"] == "role.id" OR
                   $condition["query_add_condition.value_internvariable"] == "role.app_id") {
                    if(isset($myData["active_role"])) {
                        $value = $myData["active_role"][$condition["query_add_condition.value_internvariable"]];
                        $in_addConditionList[$key]["query_add_condition.value"] = "'".$value."'";
                    }
                } 
                
                
                //Besonderheit: wenn mask-Daten aus der Session-Variable gesucht werden:
                if($condition["query_add_condition.value_internvariable"] == "mask.id") {
                    if(isset($myData["target_mask"])) {
                        $value = $myData["target_mask"]["id"];
                        $in_addConditionList[$key]["query_add_condition.value"] = "'".$value."'";
                    }
                } 
                
                
                //Besonderheit: wenn mask-Daten aus der Session-Variable gesucht werden:
                if($condition["query_add_condition.value_internvariable"] == "account.directory_id") {
                    if(isset($myData["validator_directory_id"])) {
                        $value = $myData["validator_directory_id"];
                        $in_addConditionList[$key]["query_add_condition.value"] = "'".$value."'";
                    }
                } 
                
            }
        }
        
        return $in_addConditionList;
    }






    /** Legt für jeden Eintrag aus $in_joinConditionList eine joinCondition in $in_sqlRequest an.
     * 
     * @param   object  $in_sqlRequest          Ein Objekt vom Typ sql_request
     * @param   array   $in_joinConditionList   Liste vom Typ $this->_sql_joinCondition_list
     */
    protected function addJoinConditionsToSqlRequest(&$in_sqlRequest, $in_joinConditionList){   
        foreach ($in_joinConditionList as $key => $join_data) {
            $in_sqlRequest->addJoinCondition(   $join_data["query_part_join_condition.praefix"], 
                                                $join_data["query_part_join_condition.calm_open"], 
                                                $join_data["query_part_join_condition.query_part_from_id"],
                                                $join_data["query_part_join_condition.left_column"], 
                                                $join_data["query_part_join_condition.left_column_format"],
                                                $join_data["query_part_join_condition.operator"], 
                                                $join_data["query_part_join_condition.right_table"], 
                                                $join_data["query_part_join_condition.right_column"],
                                                $join_data["query_part_join_condition.right_column_format"],
                                                $join_data["query_part_join_condition.calm_close"]);
        }      
    }


    
    
    
    
    /** Legt für die Liste der OrderBy-Columns einen OrderBy-String in $in_sqlRequest an
     * 
     * @param   object      $in_sqlRequest      Ein Objekt vom Typ sql_request 
     * @param   array       $in_orderByList     Liste vom Typ $this->_sql_OrderBy_list
     */
    protected function addOrderByToSqlRequest(&$in_sqlRequest, $in_orderByList) {
        $orderByString = "";
        $praefix = "";  
        
        foreach ($in_orderByList as $key => $column_data) {
            $tablename = $in_sqlRequest->getTableNameById($column_data["query_part_orderby.query_part_select_query_part_from_id"]);
            if($tablename == false) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Tabelle-ID existiert nicht in $in_sqlRequest->_tablelist: ', $column_data["query_part_orderby.query_part_select_query_part_from_id"], "ERROR");
            }
            
            if($column_data["query_part_select.alias"] == "") {
                //Wenn die Spalte keinen Alias hat, dann den Spaltennamen verwenden
                $tableAndColumnname = $tablename.".".$column_data["query_part_select.columnname"];
            } else {
                //Ansonsten wird der Alias verwendet
                $tableAndColumnname = $column_data["query_part_select.alias"];
            }
            
            if($column_data["query_part_orderby.sortorder"] != "") {
                //wenn Sortorder angegeben wurde ...
                $tableAndColumnname = $tableAndColumnname." ".$column_data["query_part_orderby.sortorder"];
            }
            
            $orderByString = $orderByString.$praefix.$tableAndColumnname;
            $praefix = ", ";                                                    //falls eine weitere Sortierspalte ergänzt wird, wird dieser eine Komma vorangestellt
        } 
        $in_sqlRequest->addOrderbyPart($orderByString);
    }

    
    
    protected function addGroupByToSqlRequest(&$in_sqlRequest, $in_groupByList) {
        $groupByString = "";
        $praefix = "";  
        
        foreach ($in_groupByList as $key => $column_data) {
            $tablename = $in_sqlRequest->getTableNameById($column_data["query_part_groupby.query_part_select_query_part_from_id"]);
            if($tablename == false) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Tabelle-ID existiert nicht in $in_sqlRequest->_tablelist: ', $column_data["query_part_orderby.query_part_select_query_part_from_id"], "ERROR");
            }
            
            if($column_data["query_part_select.alias"] == "") {
                //Wenn die Spalte keinen Alias hat, dann den Spaltennamen verwenden
                $tableAndColumnname = $tablename.".".$column_data["query_part_select.columnname"];
            } else {
                //Ansonsten wird der Alias verwendet
                $tableAndColumnname = $column_data["query_part_select.alias"];
            }
            
            $groupByString = $groupByString.$praefix.$tableAndColumnname;
            $praefix = ", ";                                                    //falls eine weitere Gruppierspalte ergänzt wird, wird dieser eine Komma vorangestellt
        } 
        $in_sqlRequest->addGroupbyPart($groupByString);
    }
    
    

    /** Legt für jeden Eintrag aus $in_fromList eine Tabelle in $in_sqlRequest an.
     * Außerdem werden SubQueries ausgeführt, falls vorhanden.
     * 
     * @param   object      $in_sqlRequest      Ein Objekt vom Typ sql_request 
     * @param   array       $in_fromList        Liste vom Typ $this->_sql_from_list
     */
    protected function addFromTablesToSqlRequest(&$in_sqlRequest, $in_fromList) {
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  fromList ', $in_fromList);
        foreach ($in_fromList as $key => $table_data) {
            //Prüfen, ob es sich um eine SubQuery handelt
            $vqueryPräfix = global_variables::getPräfixForVqueryTables();
            if(substr($table_data["query_part_from.tablename"], 0, strlen($vqueryPräfix)) == $vqueryPräfix) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  refreshVqueryTable ', $table_data);
           
                $this->refreshVqueryTable($table_data);
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  refreshVqueryTable ', "vquery wurde aktualisiert");
            }
            $in_sqlRequest->addTable(   $table_data["query_part_from.db_schema"], 
                                        $table_data["query_part_from.tablename"], 
                                        $table_data["query_part_from.id"], 
                                        $table_data["query_part_from.jointype"], 
                                        $table_data["query_part_from.alias"]);
        }
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->   ', "Ende addFromTable");
    }
    
    
    
    
    /** Führt eine SubQuery aus. Dadurch wird die entsprechende vquery_table mit aktuellen Daten gefüllt (analog einer view, jedoch funktioniert das auch DB-übergreifend).
     * 
     * @param   array   $in_table_data      Daten der Tabelle query_part_from, über welche die SubQuery in einer MainQuery eingebunden ist <br />
     *                                      $table_data["query_part_from.db_schema"], <br />
                                            $table_data["query_part_from.tablename"], <br />
                                            $table_data["query_part_from.id"], <br />
                                            $table_data["query_part_from.jointype"], <br />
                                            $table_data["query_part_from.alias"];<br />
     * 
     */
    protected function refreshVqueryTable($in_table_data) {
        //Query-App-ID und Query-ID ermitteln
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> table_data: ', $in_table_data);
        
        $condition = "template_file = '".$in_table_data["query_part_from.db_schema"].".".$in_table_data["query_part_from.tablename"]."'";
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> condition: ', $condition);
        
        $queryData = getTableData(global_variables::getAppIdFromSYS01(), "query", global_variables::getNameOfDbSchemaSYS01(), false, "", $condition);
        
        //Theoretisch dürfte es nur einen Ergebnisdatensatz geben
        $query_app_id = $queryData[0]["query.app_id"];
        $query_id = $queryData[0]["query.id"];
        //SubQuery ausführen
        $myQuery = new query();
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> starte: ', "Query_initialize_1");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> _flexInternVariables: ', $this->_flexInternVariables);
        
        //formFilterCondition aus _flexInternVariables entfernen, da diese sich nur auf die direkt zugeordnete Query oder Tabelle des Formulars beziehen sollte,
        //nicht jedoch auf eine nachgeordnete vQuery
        $temp_flexInternVariables = $this->_flexInternVariables;
        foreach ($temp_flexInternVariables as $key => $value) {
            if($value["type"] === "formFilterCondition") {unset($temp_flexInternVariables[$key]);}
        }
        $myQuery->initialize_1($query_app_id, $query_id, false, $temp_flexInternVariables, $this->form_array);
    }
    
    
    
    /** Legt für jeden Eintrag aus $in_selectList eine Column in $in_sqlRequest an.
     * 
     * @param   object  $in_sqlRequest      Ein Objekt vom Typ sql_request an
     * @param   array   $in_selectList      Liste vom Typ $this->_sql_select_list
     */
    protected function addSelectColumnsToSqlRequest(&$in_sqlRequest, $in_selectList) {
        foreach ($in_selectList as $key => $column_data) {
            $tablename = $in_sqlRequest->getTableNameById($column_data["query_part_select.query_part_from_id"]);
            if($tablename == false) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Tabelle-ID existiert nicht in $in_sqlRequest->_tablelist: ', $column_data["query_part_select.query_part_from_id"], "ERROR");
            }
            $in_sqlRequest->addSelectColumn(    $tablename, 
                                                $column_data["query_part_select.columnname"], 
                                                $column_data["query_part_select.alias"],
                                                $column_data["query_part_select.const"],
                                                $column_data["query_part_select.function_id"],
                                                $column_data["query_part_select.function_params"],
                                                $column_data["query_part_select.hidden"]);
        } 
    }

    
    
    
    /** Legt für jeden Eintrag aus $in_addConditionList eine Bedingung in $in_sqlRequest an. 
     * Diese wird, wenn möglich zu den join-conditions ergänzt.
     * Unter Umständen wird sie auch als Condition im Where-Part eingefügt.
     * 
     * @param object $in_sqlRequest         Ein Objekt vom Typ sql_request an
     * @param array  $in_addConditionList   Liste von Typ $this->_sql_addCondition_list
     */
    protected function addConditionToSqlRequest(&$in_sqlRequest, $in_addConditionList) {
        foreach ($in_addConditionList as $key => $condition_data) {
            $tablename = $in_sqlRequest->getTableNameById($condition_data["query_add_condition.query_part_from_id"]);
            if($tablename == false) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Tabelle-ID existiert nicht in $in_sqlRequest->_tablelist: ', $condition_data["query_add_condition.query_part_from_id"], "ERROR");
            } else {
                $in_sqlRequest->addWhereCondition(  $condition_data["query_add_condition.praefix"], 
                                                $condition_data["query_add_condition.calm_open"], 
                                                $tablename, 
                                                $condition_data["query_add_condition.columnname"], 
                                                $condition_data["query_add_condition.operator"], 
                                                $condition_data["query_add_condition.value"], 
                                                $condition_data["query_add_condition.calm_close"]);
            }
        } 
    }
    
    



    /** Führt den Sql-Befehl (this->_sql) aus und gibt das Ergebnis zurück
     * 
     * @return  mixed     Entweder zweidimensionales Array mit Ergebnismenge oder false
     */
    protected function getResultForSql() {
        
        
        
        $query = $this->_sql;
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SQL-Command: ', $query);
        $connection_id = $this->_connection_id;                                        //ToDo: dass klappt nur solange es pro app nur eine connection gibt. Wenn von diesem Konzept abgewischen wird, ist hier auch eine Anpassung notwendig.
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Connection-ID: ', $connection_id);
        
        //ToDo: Warum wird hier noch auf die alte Methode (verschachtelt in getResultFromSelect) zurückgegriffen? 
        //  -> nur für die no-sql-Variante. Bei allen anderen Queries wird die neue Variante gewählt.
        $result = getResultFromSelect($connection_id, $query, __FUNCTION__, $this->_sqlRequest_object);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  query_result: ', $result);
        if($result === false) {
            //Fehlerhafte SQL-Query kann regulär auftreten, wenn Feldabhängigkeiten existieren.
            //Bei Feldabhängigkeiten wird ein Kriterium aus einem vorherigen Feld ermittelt.
            //Wenn das vorherige Feld jedoch noch keinen Wert enthält, ist die query fehlerhaft.
//            echo $query."<br />";
            $ergebnisList = false;
            
            //Prüfen, ob ein SQL-Fehler auftrat
            $sql_error = occurredSqlError("getResultForSql");
            if($sql_error !== false) {
                $this->_sql =   "<b>".$sql_error["errorMessage"]."</b><br />".
                                "<br />".
                                "<b>connection_id:</b> ".$connection_id."<br />".
                                "<br />".
                                $sql_error["query"];
            }
       
        } elseif (count($result) > 0) {
            //Ergebnismenge kann zweidimensional sein, wenn es mehrere Ergebnisdatensätze gibt.
            $ergebnisList = $result;

        } else {
            $ergebnisList = false;
        }	
        return $ergebnisList;
        
    }
    
    
    
    /** Gibt das Ergebnis einer query als array zurück.
     * 
     * @return  array       Ergebnismenge als zweidimensionales array (Ebene 1: key = Zeilennummer, value = array(Eben 2); Ebene 2: key = tble.columnname, value = wert); Wenn die Datenbankabfrage keine Daten ermitteln konnte, wird ein leeres array zurückgegeben.
     */
    function getQueryResultAsArray() {
        if($this->_queryresult == false) {
            $feedback = array();
        } else {
            $feedback = $this->_queryresult;
        }
        return $feedback;
    }
    
    
    
    /** Gibt die Anzahl der Datensätze der Ergebnismenge zurück.
     * 
     * @return  integer
     */
    function getCountData() {
        if($this->_queryresult == false) {
            $feedback = 0;
        } else {
            $feedback = count($this->_queryresult);
        }
        return $feedback;
    }
    
    
    
    /** Ermittelt für die Query die Kriterien, fallls vorhanden.
     * 
     * @param   array   $in_form_array          Form_array, der die Query zugeordnet ist. Wenn die Query Formularunabhängig ist, dann hier "array()" übergeben.
     * @return  mixed                           zweidimensionales Array, falls Kriterienplatzhalter existieren, sonst false.
     *                                          Bsp. für Ergebnisliste:
     * 
     */
    protected function getQueryCriterialist(&$in_form_array) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("query",             "id");
            $queryRequest->addSelectColumn("query",             "app_id");
            $queryRequest->addSelectColumn("query_criteria",    "feld_app_id");
            $queryRequest->addSelectColumn("query_criteria",    "feld_id");
            $queryRequest->addSelectColumn("query_criteria",    "id");
            $queryRequest->addSelectColumn("query_criteria",    "description");
            $queryRequest->addSelectColumn("feld",              "name");
            $queryRequest->addSelectColumn("feld",              "spalte");
            $queryRequest->addSelectColumn("feld",              "form_id");
            $queryRequest->addSelectColumn("feld",              "form_app_id");
            
            $queryRequest->addTable($db_schema_manager, "query", 1, "BASE");
            $queryRequest->addTable($db_schema_manager, "feld", 2, "INNER");
            $queryRequest->addTable($db_schema_manager, "query_criteria", 3, "INNER");
            $queryRequest->addTable($db_schema_manager, "query_to_form", 4, "INNER");
            
            
            $queryRequest->addWhereCondition("AND", "", "query",            "id",           "=", "query_to_form.query_id",        "");
            $queryRequest->addWhereCondition("AND", "", "query",            "app_id",       "=", "query_to_form.query_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "query_criteria",   "feld_id",      "=", "feld.id", "");
            $queryRequest->addWhereCondition("AND", "", "query_criteria",   "feld_app_id",  "=", "feld.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "query_to_form",    "query_id",     "=", "query_criteria.query_to_form_query_id", "");
            $queryRequest->addWhereCondition("AND", "", "query_to_form",    "query_app_id", "=", "query_criteria.query_to_form_query_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "query_to_form",    "form_id",      "=", "query_criteria.query_to_form_form_id", "");
            $queryRequest->addWhereCondition("AND", "", "query_to_form",    "form_app_id",  "=", "query_criteria.query_to_form_form_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "query",    "id",  "=", $this->_id, "");
            $queryRequest->addWhereCondition("AND", "", "query",    "app_id",  "=", "'".$this->_app_id."'", "");
            
            if($in_form_array <> array()) {
                //Formularabhängige Kriterien
                $queryRequest->addWhereCondition("AND", "", "query_to_form",    "form_app_id",     "=", "'".$in_form_array["form.app_id"]."'", "");
                $queryRequest->addWhereCondition("AND", "", "query_to_form",    "form_id",     "=", $in_form_array["form.id"], "");
            }
            
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
        
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Kriterienliste: ', $result);
        
        //Ergebnismenge kann zweidimensional sein, wenn es mehrere Kriterien gibt.
        if (count($result) > 0) {
            $ergebnisList = $result;

        } else {
            $ergebnisList = false;
        }	
        return $ergebnisList;
        
    }
    
    
    
    /** Gibt den SQL-Befehl für eine query zurück.
     * 
     * @return string
     */
    function getSqlCommand() {
        return $this->_sql;
    }
}




?>