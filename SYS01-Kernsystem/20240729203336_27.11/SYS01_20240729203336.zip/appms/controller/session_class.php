<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

$global_session_object = new session_class;             //Session-Objekt erzeugen. globaler Zugriff ist über session_class::$session_object möglich
$global_session_object->__initialize();

//echo __FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> läuft <br />';

/**
 * Description of session_class
 *
 * @author thomas
 */
class session_class {
    
    
    private $private_session_array;
    
    
    //----------------------------------------------------------------
    //Session über globale Variable systemweit zur Verfügung stellen
    static $session_object;
    


    //-----------------------------------------------------------------
    
    
    
    
    
    
    
    
    public function __construct() {
        self::$session_object = $this;                    //global verfügbaren Zeiger auf das Objekt setzen
    }
    
    
    /**
     * Destructor, der aktiv aufgerufen wird. Der Standard-Destructor ist nicht ausreichend, 
     * da nicht sicher gesteuert werden kann, wann GC diesen aufruft.
     * 
     * Aufruf: session_class::$session_object->my_destruct();
     */
    public function my_destructer() {
        
        //aktuelle Werte bei der jeweiligen Tab_id in session_storage ablegen
        
        
        $_SESSION = $this->private_session_array;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." SESSION" , $_SESSION);
    }
    
    
    
    /**
     * Legt die relevanten Attribute unter der current-tab_id in SessionStorage ab.
     */
    private function setSessionAttributsInStorage() {
        
    }
    
    
    /* Legt grundlegende Eigenschaften fest und führt bei jedem Serveraufruf die Berechtigungsprüfung durch.
     * 
     */
    public function __initialize() {
        //Grundeinstellungen der Session festlegen
        $this->setSessionSettings();
        // Session starten bzw. vorhandene Session wieder aufnehmen und auf Hijack prüfen
        session_start();
        $_SESSION = $this->protectSessionAgainstHijack($_SESSION);
        $this->setSessionArray($_SESSION);
        
        

        //die folgenden Funktionen dürfen erst nach session_start aufgerufen werden.
        require_once("../controller/functions.php");
        require_once("../controller/debug.php");
        

        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Start: ', '--START-------------------------------------------------------------');
        $this->setErrorLevel();
        
        //SessionStorageID bei Bedarf setzen
        $_SESSION = $this->setSessionStorageID($_SESSION);
        
        if(isset($_SESSION)) {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Aufruf Sessionhandler mit bestehender Session: ', $_SESSION);}
        if(isset($_POST)) {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Aufruf Sessionhandler mit POST: ', $_POST);}
        if(isset($_GET)) {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Aufruf Sessionhandler mit GET: ', $_GET);}
        if(isset($_FILES)) {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Aufruf Sessionhandler mit FILES: ', $_FILES);}
        if($this->checkUrlForForbiddenStrings() === true) {$this->cancelLogin("Seitenaufruf abgebrochen, da unerlaubte Aktion erkannt wurde.", 1, "URL enthält unerlaubten String, daher wurde Nutzer automatisch abgemeldet.", true);};
        if(isset($_SESSION["hijack"])) {
            //Diese Fehlermeldung kann erst jetzt, außerhalb von protectSessionAgainstHijack erfolgen, da session_start vor require_once erfolgen muss.
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Session-Hijack: ', "Session-Manipulation erkannt. Session IP und Browser=".$_SESSION["old_identifier"]." | neuer identifier=". $this->getIpAdress().":".$_SERVER["HTTP_USER_AGENT"],"SECURITY");
        }

        
        //TargetMask ermitteln (es wird ein möglicherweise vorhandener redirect beachtet)
        $target_mask_array = $this->buildTargetMaskArray();



        // Gast-User ermitteln
        $guest_user = getConfig("guest_user", $target_mask_array["app_id"]);
        $guest_userRoleId = getConfig("guest_user_role", $target_mask_array["app_id"]);

//        echo __FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> läuft <br />';

        //Falls noch eine Guest_Session existiert wird diese zerstört, da sonst keine Validierung gegen ein Verzeichnis erfolgen würde.
        if(isset($_SESSION['guest_user'])) {
            
    //        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'vor checkGuestSession', $_SESSION);
            $_SESSION = $this->checkGuestSession($_SESSION, $target_mask_array["app_id"], $target_mask_array["id"]);
    //        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'nach checkGuestSession', $_SESSION);
        }

        
        $this->setSessionArray($_SESSION);
        //------------------------------------------------------------------------------------------------------------
        //--Session-Handler Start-------------------------------------------------------------------------------------
        ////------------------------------------------------------------------------------------------------------------
        // 1. Session starten (Aufruf durch Login-Maske)----------------------------------------------------
        if(issetKeyLike($_POST, "submit_login") !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Pos 1', 'Login');

            //uid, app_id und password aus POST_Array ermitteln; app_id kann auch den Wert false haben
            $accountArray = $this->getAccountdataFromPostArray($_POST);


            //validator ermitteln
            $validator = $this->getValidator($accountArray, $_SESSION, $target_mask_array["app_id"]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'ValidatorArray für Account '.$accountArray["uid"], $validator);
            $_SESSION["validator_process_type"] = $validator["validator_process_type"];
            $_SESSION["validator_directory_id"] = $validator["directory.id"];

            //Rollen ermitteln
            $accountRollen = $this->getRoles($validator, $accountArray, $target_mask_array);

            // Benutzeraccount durch Verzeichnis validieren
            require_once("../controller/directory/".$validator["directory.validator"]);
            $checkAccount=checkUserAccount($validator["directory.id"], $accountArray["uid"], $accountArray["password"], $accountArray["app_id"]);        

            if ($checkAccount==true){
                //Clientidentifier für Prüfung in protectSessionAgainstHijack vorbereiten
                $ip = $this->getIpAdress();
                $browser = $_SERVER["HTTP_USER_AGENT"];
                $_SESSION["identifer"] = $ip.":".$browser;
                //Accountdaten in SESSION ablegen 
                $activeRole = $accountRollen[0];
                $target_mask_array = $this->rebuildTargetMask($target_mask_array, $activeRole);
                $_SESSION = $this->setSessionAttributs($_SESSION, $accountArray["uid"], false, $accountArray["app_id"], $accountRollen, $activeRole, $_SESSION["validator_process_type"], $target_mask_array);


    //            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Session an Pos 121 ', $_SESSION);
            } else {
                //Wenn der Benutzer/Account durch das Verzeichnis nicht validiert werden konnte, dann ...
    //            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Pos 13 ', 'if-Zweig: checkAccount = false');
                $this->cancelLogin("Sie konnten nicht eingeloggt werden.<br>\r\n Benutzername oder Passwort sind möglicherweise falsch, der Account gesperrt oder der Directory-Server nicht erreichbar. Details können der Debug-Tabelle entnommen werden..<br>\n", 1, "Passwort für Benutzer ".$accountArray["uid"]."falsch", true);
            }
        }

        //2.App wechseln
        elseif($this->getUid() !== false AND $this->getGuestuser() == false AND isset($_GET['change_app'])) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'App-wechseln', $_GET['change_app']);
            //Hier ist Platz für weitere Prüfungen, Bsp.: Timestamp.

                $accountArray = array("uid" => $this->getUid(), "app_id" => $_GET['change_app']);
                $validator = $this->getValidator($accountArray, $_SESSION, $target_mask_array["app_id"]);
                $accountRollen = $this->getRoles($validator, $accountArray, $target_mask_array);
                $_SESSION = $this->setSessionAttributs($_SESSION, $accountArray["uid"], false, $accountArray["app_id"], $accountRollen, $accountRollen[0], $validator, $target_mask_array);



        }

        // 3. Sitzung auf Gültigkeit prüfen------------------------------------------------------------
        elseif($this->getUid() !== false AND $this->getGuestuser() == false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Pos 2, Session prüfen', $_SESSION);
            //Hier ist Platz für weitere Prüfungen, Bsp.: Timestamp.

                $accountArray = array("uid" => $this->getUid(), "app_id" => $this->getAppId());
                $validator = $this->getValidator($accountArray, $_SESSION, $target_mask_array["app_id"]);
                $accountRollen = $this->getRoles($validator, $accountArray, $target_mask_array);
                $_SESSION = $this->setSessionAttributs($_SESSION, $accountArray["uid"], false, $accountArray["app_id"], $accountRollen, $_SESSION["active_role"], $_SESSION["validator_process_type"], $target_mask_array);
                
        }


        // 4. Gastzugang -----------------------------------------------------------------------------
        elseif(isset($guest_user)) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Pos 3', 'Gastzugang');
            $myRoles = getRoleByAccount($guest_user, $target_mask_array["app_id"], $target_mask_array["app_id"], $target_mask_array["id"], $target_mask_array["app_id"], $guest_userRoleId);
            
            //Wenn der zuvor verwendete Guest-User keinen Zugriff hat, dann testen, ob der Guest-User des Kernmoduls Zugriff hat.
            if($myRoles == array()) {
                $myRoles = getRoleByAccount(getConfig("guest_user", global_variables::getAppIdFromSYS01()), global_variables::getAppIdFromSYS01(), $target_mask_array["app_id"], $target_mask_array["id"], global_variables::getAppIdFromSYS01(), getConfig("guest_user", global_variables::getAppIdFromSYS01()));
            }
            $_SESSION = $this->setSessionAttributs($_SESSION, $guest_user, true, $target_mask_array["app_id"], $myRoles, $myRoles[0], "roleByAccount", $target_mask_array);
            
        }


        // 5. direkter Aufruf der Seite ohne vorhandene Sitzung----------------------------------------
        //    Dieser Fall tritt auf, wenn zuvor kein Gastaccount ermittelt werden konnte oder wenn die Sitzung abgelaufen ist.
        elseif($this->getUid() === false) {
            //cancelLogin("Ihre Benutzerdaten konnten nicht geprüft werden.<br>\r\n Eventuell ist Ihre Sitzung abgelaufen.", 1, "Session konnte nicht validiert werden. Eventuell ist die Sitzung abgelaufen", false);
            $this->deniedAccess("-134");

        }


        // 6. Logout-----------------------------------------------------------------------------------
        if(isset($_GET["logout"])) { 
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Pos 5', 'Logout');
            if($_GET["logout"]=="true") { 
                $this->cancelLogin("Sie haben sich abgemeldet.<br>\r\n ", 2, "Benutzer hat sich abgemeldet.", true);
            } 
        } else {
                //Ansonsten Logout-Link bereitstellen --> muss in ../controller/functions.showInhaltObererRand() passieren						 													

        }
        
        $this->private_session_array = $_SESSION;
        

    }
    
    
    /** ersetzt die interne Variable private_session_array durch den übergebenen Wert.
     * 
     * @param type $in_session
     */
    private function setSessionArray($in_session) {
        
        //$this->private_session_array = $in_session;
        $this->private_session_array = $in_session;
    }
    
    
    
    /** Ermittelt das aktuelle Session-Array aus der Session-Class
     * 
     * @return Array
     */
    public function getSessionArray() {
        //return $this->private_session_array;
        return $this->private_session_array;
    }
    
    
    
    /** Extrahiert aus einem POST_Array die Werte der Felder, welche uid, app_id oder password enthalten.
     * Sollten mehrere entsprechende Felder enthalten sein, dann wird der jeweils letzte Wert übermittelt.
     * 
     * @param   Array   $in_PostArray   $_POST
     * @return  Array                   Array mit den keys uid, app_id und password; app_id kann auch den boolean-Wert false annehmen
     */
    private function getAccountdataFromPostArray($in_PostArray) {
        $accountdata = array("uid" => "", "app_id" => "", "password" => "");
        foreach ($in_PostArray as $key => $value) {
            if (strpos($key, "uid") !== false) {$accountdata["uid"]=$value;}
            if (strpos($key, "app_id") !== false) {$accountdata["app_id"]=$value;}       //Wenn das Sender-Formular eine App-ID vorgibt
            if (strpos($key, "password") !== false) {$accountdata["password"]=$value;}  
        }
        
        if($accountdata["app_id"] == "") {
            //Wenn das Senderformular keine App-ID vorgegeben hat, dann prüfen, ob es sich um einen internen Account handelt. Wenn ja, liefert dieser die App-ID
            $intern_app_id = getDataFromTableByID(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "account", "app_id", "id = '".$accountdata["uid"]."'");
            if($intern_app_id !== false) {
                $accountdata["app_id"]=$intern_app_id;
            } else {
                require_once("../data/".global_variables::getAppIdFromSYS01()."/plugin/functions_fielddefault.php");
                $accountdata["app_id"]= getCurrentMaskAppID();
            }
        }
        
        return $accountdata;
    }
    
    
    
    /** ACHTUNG: Nur nutzen, wenn keine Zugriff auf das pagedata-Object besteht. Ansonsten
     * pagedata->getActiveUser() verwenden.
     * Ermittelt aus der $_SESSION-Variable die uid.
     * Wenn diese nicht existiert, dann wird false zurückgegeben.
     * 
     * @return  mixed
     */
    public function getUid() {
        if(isset($this->private_session_array["uid"])) {
            $feedback = $this->private_session_array["uid"];
        } else {
            $feedback = false;
        }
        return $feedback;
        
    }
    
    
    /**
     * Prüft, ob in der Session vermerkt ist, dass es sich um einen Guestuser handelt.
     * 
     * @return boolean        
     */
    private function getGuestuser() {
        if(isset($_SESSION["guest_user"])) {
            $feedback = $_SESSION["guest_user"];
        } else {
            $feedback = false;
        }
        return $feedback;
    }
    
    
    /** 
     * Ermittelt aus der $_SESSION-Variable die app_id.
     * Wenn diese nicht existiert, dann wird false zurückgegeben.
     * 
     * @return  mixed
     */
    public function getAppId() {
        if(isset($this->private_session_array["app_id"])) {
            $feedback = $this->private_session_array["app_id"];
        } else {
            $feedback = false;
        }
        return $feedback;
    }
    
    
    
    /**
     * Ermittelt aus der $_SESSION-Variable die id der aufgerufenen Maske.
     * Wenn diese nicht existiert, dann wird false zurückgegeben.
     * 
     * @return  mixed
     */
    public function getTargetMaskId() {
        if(isset($this->private_session_array["target_mask"]["id"])) {
            $feedback = $this->private_session_array["target_mask"]["id"];
        } else {
            $feedback = false;
        }
        return $feedback;
    }
    
    
    
    /**
     * Ermittelt aus der $_SESSION-Variable die id der aktiven Rolle.
     * Wenn diese nicht existiert, dann wird false zurückgegeben.
     * 
     * @return  mixed
     */
    public function getActiveRoleId() {
        if(isset($this->private_session_array["active_role"]["role.id"])) {
            $feedback = $this->private_session_array["active_role"]["role.id"];
        } else {
            $feedback = false;
        }
        return $feedback;
    }
    
    
    
    
    /**
     * Ermittelt aus der $_SESSION-Variable das Redirect-Array. <br/>
     * Bsp.: Array
        (
            [redirect] => 1
            [redirect_handled] => 0
            [reason] => -130_info
            [reason_text] => access_denied
            [request_uri] => /appms/view/page.php?mask=6&maskapp=SYS01
            [request_appid] => SYS01
            [request_maskid] => 6
        )
     * 
     * @return  mixed           Gibt das Array zurück, oder false, falls es nicht existiert.
     */
    public function getRedirect() {
        
        if(isset($this->private_session_array["redirect"])) {
            $feedback = $this->private_session_array["redirect"];
        } else {
            $feedback = false;
        }
        return $feedback;
    }
    
    
    
    /**
     * Setzt den Wert redirect_handled im redirect-Array auf 1.
     * D.h., die Redirect-Vorgabe wurde umgesetzt.
     */
    public function setRedirectDone() {
        if(isset($this->private_session_array["redirect"])) {
            $this->private_session_array["redirect"]["redirect_handled"] = 1;
        }
    }
    
    
    
    /**
     * Ermittelt aus der $_SESSION-Variable die Array  der aktiven Rolle zurück.
     * Array
        (
            [role.id] => 7
            [role.name] => Rootmasken in  SYS01
            [role.app_id] => SYS01
        )
     * Wenn dieses nicht existiert, dann wird false zurückgegeben.
     * 
     * @return  mixed
     */
    public function getActiveRoleArray() {
        if(isset($this->private_session_array["active_role"])) {
            $feedback = $this->private_session_array["active_role"];
        } else {
            $feedback = false;
        }
        return $feedback;
    }
    
    
    /** Trägt einen Wert in die Liste der geschützten Werte ein. Nur so kann per Ajax ein Wert in ein Schreibgeschütztes Feld übertragen werden.
     * Andernfalls würde der Wert nach dem Absenden Formulars auf Serverseite wieder verworfen werden.
     * 
     * @param string    $in_formID
     * @param string    $in_instance_id
     * @param integer   $in_datarow         Datenzeilennummer
     * @param string    $in_fieldId
     * @param string    $in_value
     */
    public function setSecureValue($in_formID, $in_instance_id, $in_datarow, $in_fieldId, $in_value) {
        if(isset($this->private_session_array["forms_backup"][$in_formID])) {
            //ToDo: die erste Zeile entfernen, sobald sichergestellte ist, dass nur noch private_session_array relevant ist (14.12.2023)
            $_SESSION["forms_backup"][$in_formID]["form.instances"][$in_instance_id]["valuesSecureFields"][$in_datarow][$in_fieldId] = $in_value;
            $this->private_session_array["forms_backup"][$in_formID]["form.instances"][$in_instance_id]["valuesSecureFields"][$in_datarow][$in_fieldId] = $in_value;
        }
        
    }
    
    
    
    
    /** Gibt das Formulararray aus dem Session-Array zurück.
     * 
     * @param   string  $in_form_id     ID eines Formulars
     * @return  mixed                   Formulararray oder false, wenn kein Array im backup ermittelt werden konnte.
     */
    public function getFormbackup($in_form_id) {
        if(isset($this->private_session_array["forms_backup"][$in_formID])) {
            $feedback = $this->private_session_array["forms_backup"][$in_formID];
        } else {
            $feedback = false;
        }
        
        return $feedback;
    }
    
    
    
    /** Ergänzt zum Session_Array eine Message für ein Feld. Diese
     * kann später im Feld als Vorgabewert genutzt werden.
     * 
     * @param   string  $in_field_id    Bsp.: "2612"        (Fortschrittsanzeige in Formular Update);<br>
     *                                                      statt Field-ID kann "infobox" oder "click_button" angegeben werden.<br>
     *                                                      Wenn button_click angegeben wird, dann wird nach dem Laden der Maske der Button geklickt, dessen ID als $in_value übergeben wurde.
     * @param   string  $in_value       "blabla..."   
     */
    public function setSessionMessageToField($in_field_id, $in_value) {
        $mySession = $this->getSessionArray();
        if (isset($mySession["Fieldmessages"])) {
            //Attribut existiert
        } else {
            //Attribut anlegen
            $mySession["Fieldmessages"] = array();
        }
        
        If($in_field_id == 'click_button') {
            //Falls bereits ein Wert für click_button gesetzt wurde, wird jeder weitere Wert verworfen.
            //In der Regel ist immer das erste Formular, das steuernde Formular.
            if(isset($mySession["Fieldmessages"]["click_button"])) {
                if($mySession["Fieldmessages"]["click_button"] == "") {
                    //Wenn bisher kein Wert gesetzt wurde, dann kann Klick-Button eingetragen werden
                    $mySession["Fieldmessages"][$in_field_id] = $in_value;
                }
            } else {
                //der erste Klick-Button wird gesetzt
                $mySession["Fieldmessages"][$in_field_id] = $in_value;
            }
        } else {
            $mySession["Fieldmessages"][$in_field_id] = $in_value;
        }
        
        $this->setSessionArray($mySession);
        
    }
    
    
    
    /** Falls die Session-Variable ["Fieldmessages"]["click_button"] gesetzt ist, wird sie auf Leerstring ("") gesetzt.
     * Damit wird verhindert, dass ein Button, nach dem Neuladen einer Seite erneut geklickt wird.
     * 
     */
    public function clearSessionMessageFieldClickbutton() {
        $mySession = $this->getSessionArray();
        if (isset($mySession["Fieldmessages"]["click_button"])) {
            $mySession["Fieldmessages"]["click_button"] = "";
        } 
        
        $this->setSessionArray($mySession);
        
    }
    
    
    
    public function clearSessionMessageForInfobox() {
        $mySession = $this->getSessionArray();
        if (isset($mySession["Fieldmessages"]["infobox"])) {
            unset($mySession["Fieldmessages"]["infobox"]);
        } 
        
        $this->setSessionArray($mySession);
        
    }
    
    
    
    
    /** Setzt den Parameter use_temporary_install_dir in pagedata.session und in SESSION.
     * Wenn true, dann wird allen Buttontargets der temporäre Installationspfad vorangestellt, sodass 
     * AppMS temporär in einem anderen Installationsverzeichnis ausgeführt wird.
     * Dadurch sind Update-Prozessschritte am Kernsystem möglich 
     * 
     * @param   boolean     $in_OnOff           [true|false]
     */
    public function setSessionUseTempInstallPath($in_OnOff) {
        $mySession = $this->getSessionArray();
        if (isset($mySession["use_temporary_update_dir"])) {
            //Attribut existiert
        } else {
            //Attribut anlegen
            $mySession["use_temporary_update_dir"] = false;
        }

        $mySession["use_temporary_update_dir"] = $in_OnOff;
        $this->setSessionArray($mySession);
        
    }
    
    
    /** Wenn beim letzten Maskenaufbau per setSessionMessageToField eine Meldung für eine Feld oder die "infobox" abgelegt wurde,
     * wird diese übergeben.
     * 
     * @param   string  $in_field   ID eines Feldes oder "infobox"
     * @return  mixed               String oder false, wenn keine Meldung vorliegt 
     */
    public function getLastMessageForInfobox($in_field) {
        $mySession = $this->getSessionArray();
        if (isset($mySession["Fieldmessages"][$in_field])) {
            //es liegt eine  Meldung vor
            $feedback = $mySession["Fieldmessages"][$in_field];
        } else {
            $feedback = false;
        }

        return $feedback;
        
    }
    

    
    
     
    /** Setzt den Parameter workflow in Session-class.session.
     * 
     * @param array     $in_workflow    
     */
    public function setSessionWorkflowArray($in_workflow) {
        $mySession = $this->getSessionArray();
        

        $mySession["workflow_serialized"] = $in_workflow;
        $this->setSessionArray($mySession);
        
    }
    
    
    
        
    /** Setzt den Parameter active_role in session-class.session.
     * 
     * @param array     $in_role    Bsp.: Array <br />
      ( <br />
      [role.id] => 1 <br />
      [role.name] => Fach-Admin SYS01 <br />
      [role.app_id] => SYS01 <br />
      ) <br />
     */
    private function setActiveRole($in_role) {
        $mySession = $this->getSessionArray();
        
        
        
        if (isset($mySession["active_role"])) {
            //Attribut existiert
        } else {
            //Attribut anlegen
            $mySession["active_role"] = array();
        }

        $mySession["active_role"] = $in_role;
        $this->setSessionArray($mySession);
        //Die Globale wird ebenfalls bestückt, da aus den user_functions nur darauf zugegriffen werden kann.
        $_SESSION = $mySession;
    }
    
    
    /** Hinterlegt die active Rolle im Session-Attribut "active_role".
     * Dabei wird geprüft, ob der aktuelle User zugriffsberechtigt für die gewünschte Rolle ist.
     * 
     * @param integer $in_role_id       gültige ID einer Rolle, auf die der aktuelle User Zugriff hat
     * @return mixed                    Role_array oder false
     */
    public function setActiveRoleId($in_role_id) {

        $mySession = $this->getSessionArray();
        
        //aus SESSION die Rollendaten für die role_id ermitteln
        $role = $this->getRoleFromSession($mySession, $in_role_id);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> neue role: ", $role);

        //Prüfen, ob der angemeldete User berechtigt ist, die gewünschte Rolle aufzurufen
        if ($role == false) {
            //User ist nicht berechtigt
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Keine Berechtigung für Rolle: " . $in_role_id, "!!! ohne Rollenwechsel Default-Maske neu laden", "ERROR");
            $feedback = false;
        } else {
            //die Rollendaten in SESSION als aktive Rolle setzen
            $this->setActiveRole($role);
            $feedback = $role;
        }

        return $feedback;
    }
    
    
    
    
    /** Ermittelt aus der SESSION-Variable das array mit der angegeben role_id
     * 
     * @param   array   $in_SESSION     Referenz auf SESSION
     * @param   integer $in_role_id     ID der gesuchten Rolle
     * @return  mixed                   Entweder array mit den Angaben zur Rolle oder false
     */
    private function getRoleFromSession(&$in_SESSION, $in_role_id) {
        foreach ($in_SESSION["rollen"] as $key => $currentRole) {
            if($currentRole["role.id"] == $in_role_id) {
                return $currentRole;
            }
        }
        
        return false;
    }
    
    
    /**
     * Ermittelt aus der $_SESSION-Variable die app_id der aktiven Rolle.
     * Wenn diese nicht existiert, dann wird false zurückgegeben.
     * 
     * @return  mixed
     */
    public function getActiveRoleAppId() {
        if(isset($this->private_session_array["active_role"]["role.app_id"])) {
            $feedback = $this->private_session_array["active_role"]["role.app_id"];
        } else {
            $feedback = false;
        }
        return $feedback;
    }
    
    
    /** Ermittelt die aktuelle Tab-ID der Session. Die Tab-ID gibt an, in welchem Reiter eines Browsers der user gerade aktiv ist. 
     * 
     * @return mixed        Tab-ID oder false, falls die Tab-ID nicht vorhanden ist.
     */
    public function getTabId() {
        if(isset($this->private_session_array["curSessionID"])) {
            $feedback = $this->private_session_array["SessionStorage"][$this->private_session_array["curSessionID"]]["id"];
        } else {
            $feedback = false;
        }
        return $feedback;
    }
    
    
    /** Ermittelt aus der Session den Wert des Attributs "last_action_id".
     * Wenn dieses Attribut nicht existiert wird false zurückgegeben.
     * 
     * @return mixed                wenn Attribut existiert, dann string, ansonsten boolean (false)
     */
    public function getLastActionId() {
        if (isset($this->private_session_array["last_action_id"])) {
            $feedback = $this->private_session_array["last_action_id"];
        } else {
            $feedback = false;
        }

        return $feedback;
        
    }
    
    
    
    /** Hinterlegt die action_id im Session-Attribut "last_action_id".
     * 
     * @param string $in_action_id      beliebiger Wert
     */
    public function setLastActionId($in_action_id) {
        $mySession = $this->getSessionArray();
        $mySession["last_action_id"] = $in_action_id;
        $this->setSessionArray($mySession);
        //Die Globale wird ebenfalls bestückt, da aus den user_functions nur darauf zugegriffen werden kann.
        $_SESSION = $mySession;
        
    }
    
    
    
    
    /**
     * Ermittelt aus der $_SESSION-Variable die app_id der aufgerufenen Maske.
     * Wenn diese nicht existiert, dann wird false zurückgegeben.
     * 
     * @return  mixed
     */
    public function getTargetMaskAppId() {
        if(isset($this->private_session_array["target_mask"]["app_id"])) {
            $feedback = $this->private_session_array["target_mask"]["app_id"];
        } else {
            $feedback = false;
        }
        return $feedback;
    }
    
    
    
    /** ergänzt die Session um das Attribut "SessionStorage", falls noch nicht vorhanden.
     * 
     * @param   string  $in_session     Aktuelle Session
     * @return  string                  Session ergänzt um SessionStorage
     */
    private function setSessionStorageID($in_session) {
        $cur_tab_id = "";
        $tab_id_exist = false;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , "start setSessionStorageID");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." SESSION", $in_session);         
        
        
        //wichtig für Abwärtskompatibilität vor Version 27.4. Dieser Abschnitt kann ab Version 29 gelöscht werden.
        if(isset($in_session["SessionStorage"][1])) {
            if($in_session["SessionStorage"][1] == "tab1-Session") {
                $in_session["SessionStorage"][1] = array();
                $in_session["SessionStorage"][1]["id"] = "dummy";
            }
        }
        
        if(isset($in_session["SessionStorage"])===false) {
            $key = 1;
            $in_session["SessionStorage"][$key]["id"] = "dummy";
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , "set Dummy StorageID");
        } else {
            
            
            if(isset($_POST["tab_id"])) {
                //1. tab_id über post ermitteln
                $cur_tab_id = $_POST["tab_id"];             
            } elseif(isset($_GET["tab_id"])) {
                //2. oder tab_id über get ermitteln
                $cur_tab_id = $_GET["tab_id"];
            } else {
                //oder davon ausgehen, dass die letzte genutzte tab_id weiterhin die aktuelle ist.
                $cur_tab_id = $in_session["SessionStorage"][$in_session["curSessionID"]]["id"];
                
            }
            
            
            
            
            //4. prüfen, ob tab_id bereits in Session_storage bekannt ist, falls nicht, dann ergänzen
            for ($i = 1; $i <= count($in_session["SessionStorage"]); $i++) {
                if($in_session["SessionStorage"][$i]["id"] == $cur_tab_id) {
                    //tab_id ist bereits vorhanden
                    $key = $i;
                    $tab_id_exist = true;                    
                    break;
                } elseif($in_session["SessionStorage"][$i]["id"] == "dummy") {
                    //dummy ggf. überschreiben (fllas neuer Wert durch GET oder POST gesendet wurden
                    $key = $i;
                    $in_session["SessionStorage"][$i]["id"] = $cur_tab_id;
                    $tab_id_exist = true;
                    break;
                }
            }
            
         
            
            
            if($tab_id_exist === false) {
                $key = count($in_session["SessionStorage"]) + 1;
                $in_session["SessionStorage"][$key] = array();
                $in_session["SessionStorage"][$key]["id"] = $cur_tab_id;
            }
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , "set StorageID: ".$key);

        }
        //currentSessionID setzen
        $in_session["curSessionID"] = $key;
        
        //globale Variable gleichsetzen. Das Warten auf die Destruct-Methode kann zu lange dauern. Unter Umständen werden vorher bereits Ajax-Requests ausgeführt
//        $_SESSION = $this->private_session_array;
        $this->setSessionArray($in_session);
            
        return $in_session;
    }
    
    
    
    /** Prüft, ob IP und Browserkennung mit den in der Session hinterlegten Werten überinstimmt.
     * Wenn nicht wird die Session zerstört und neu aufgebaut. Das Attribut hijack wird auf true gesetzt, damit es später ausgewertet werden kann.
     * 
     * @return  array                       geprüfte Session
     */
    private function protectSessionAgainstHijack() {
        if(isset($_SESSION["identifer"])) {
            //bestehende Session -> prüfen, ob IP und Browserkennung stimmen.
            //Falls nicht, Session zerstören und somit Neuanmeldung erzwingen
            $ip = $this->getIpAdress();
            $browser = $_SERVER["HTTP_USER_AGENT"];
            if($_SESSION["identifer"] == $ip.":".$browser) {
                //ok, nothing to do
            } else {
                //maybe Session-hijacking
                $old_identifier = $_SESSION["identifer"];
                session_destroy();  //bestehende Session zerstören, damit bisherige Zugriffsrechte verloren gehen und eine Neuanmeldung erzwungen wird.
                session_start();
                $_SESSION["hijack"] = true;   //Fehlermeldung kann erst nach den folgenden Zeilen nach Debug geschrieben werden.
                $_SESSION["old_identifier"] = $old_identifier;

            }
        } else {
            //nothing ToDo, da es sich nur um eine guest-Session handeln kann
        }
        return $_SESSION;
    }
    
    
    
    /** Ermittelt die IP-Adresse des aufrufenden Clients. Wenn ein Proxy erkannt wurde
     * wird versucht die ursprüngliche IP-Adresse zu ermitteln
     * 
     * @return  string          IPv4-Adresse
     */
    public function getIpAdress() {
        if (!empty($_SERVER['HTTP_CLIENT_IP']))   {
            //kein Standard, aber manche Netzwerkkomponenten setzen dieses Attribut
            $client_ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))  {
            //Der Nutzer kam mit Proxy
            $client_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            //Der Nutzer kam ohne Proxy
            $client_ip = $_SERVER['REMOTE_ADDR'];
        }
        
        if($client_ip == "::1") {
            $client_ip = "127.0.0.1";
        }
        return $client_ip;
    }
    
    

    /** Ermittelt auf Basis des Accounts den zu verwendenden Validator.
     * Wenn dies nicht gelingt, wird geprüft, ob anhand der target-Mask oder der Default-Mask
     * der App ein validator ermittelt werden kann.
     * 
     * @param   array   $in_accountArray        Array, mit Daten zum Account (uid, app_id)
     * @param   array   $in_SESSION             aktive SESSION, anhand derer geprüft wird, ob das redirect-Attribut existiert.
     * @param   array   $in_targetMaskApp             MaskApp-ID, welche geöffnet werden soll.
     * @return  array                           Validatorarray mit den Attributen: 
     *                                          array("directory.validator" => "ldap_con.php", "directory.id" => 3, "validator_process_type" => [roleByAccount|roleByMask|undefined])
     */
    private function getValidator($in_accountArray, $in_SESSION, $in_targetMaskApp) {
        $feedback = array();
        
        //versuchen, validator auf Basis des Accounts zu ermitteln
        $validator = getValidatorForAccount($in_accountArray["uid"], $in_accountArray["app_id"]);
	
	
	if ($validator != false) {
            //validator konnte mit Hilfe des Account ermittelt werden
            $feedback = $validator;
            $feedback["validator_process_type"] = "roleByAccount";
		
	} else {	
            //validator konnte nicht anhand des Account ermittelt werden. Daher versuchen, anhand
            //der targetMask einen validator zu ermitteln
            if(isset($in_SESSION["redirect"])) {
                //prüfen, ob die LoginMaske nur aufgrund eines redirects aufgerufen wurde 
                $targetMaskAppId = $in_SESSION["redirect"]["request_appid"];
                $targetMaskId = $in_SESSION["redirect"]["request_maskid"];
            } else {
                //Prüfen, ob für die gewünschte App eine default-Startmaske existiert 
                $targetMaskAppId = global_variables::getDefaultMaskAppId($in_targetMaskApp, "start_mask");
                $targetMaskId = global_variables::getDefaultMaskId($in_targetMaskApp, "start_mask");
            }
            
            //Validator mit Hilfe der targetMask ermitteln. Wenn das misslingt, wird false zurückgegeben.
            $validator = getValidatorForMask($targetMaskAppId, $targetMaskId);
            if($validator == false) {
                $feedback["validator_process_type"] = "undefined";
            } else {
                $validator["validator_process_type"] = "roleByMask";
                $feedback = $validator;
            }	
	}
        
        return $feedback;
    }
    
    
    
    /** Ermittelt eine Liste von Rollen, auf die der aktuelle Account Zugriff hat. Der Zugriff ergibt sich entweder
     * aus den Rollenzuordnungen zum Account oder zur Target-Mask.
     * 
     * @param   array   $in_validator           Angaben zum Validator (validator_process_type => [roleByAccount|roleByMask|undefined], directory.validator)
     * @param   array   $in_accountArray        Angaben zum Account (uid, app_id, 
     * @param   array   $in_target_mask_array   Angaben zur target_mask (app_id, id)
     * @return  array                           Liste der verfügbaren Rollen (role.id, role.app_id, role.name)
     */
    private function getRoles($in_validator, $in_accountArray, $in_target_mask_array) {
        //Rollen ermitteln
	if($in_validator["validator_process_type"] == "roleByAccount") {
            //validator-prozesstype = roleByAccount
            $accountRollen = getRoleByAccount($in_accountArray["uid"], $in_accountArray["app_id"], $in_target_mask_array["app_id"], $in_target_mask_array["id"]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Validator für Account '.$in_accountArray["uid"].' gefunden', $in_validator["directory.validator"]);
       		
	} elseif($in_validator["validator_process_type"] == "roleByMask") {
            //validator-prozesstype = roleByMask
            $accountRollen = getRoleByMask($in_target_mask_array["app_id"], $in_target_mask_array["id"]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Validator für Maske gefunden', $in_validator["directory.validator"]);
               
	} else {
            //cancel login
            $this->cancelLogin("Sie konnten nicht eingeloggt werden.<br>\r\n Benutzername oder Passwort sind falsch.<br>\n", 0, "Validator konnte für Benutzer ".$in_accountArray["uid"]." nicht ermittelt werden.", true);
	}
        
        
        return $accountRollen;
    }
    
    
    
 
    
    /** Ermittelt aus dem Backup (Zustand eines Formulars, bevor es an den Client gesendet wurde) der Feldinhalte der Primarykeys in SESSION den Wert eines Feldes.
     * 
     * @param   string  $in_TableAndColumn  Tabellenname und Spaltenname mit Punkt getrennt des Feldes innerhalb eines Formulars (Bsp.: "bst.id")
     * @param   integer $in_formID          ID eines Formulars (Bsp.: 212)
     * @param   integer $in_datarow         Nummer einer Datenzeile innerhalb eines Formulars (Bsp. 0)
     * @param   string  $in_instance_id     Instance-ID des Formulars
     * @return  mixed                       String, wenn Wert in Backup für das angegeben Feld gefunden wurde oder false
     */
    function getValueFromPrimarykeyField($in_TableAndColumn, $in_formID, $in_datarow, $in_instance_id) {

        $mySession = $this->getSessionArray();
        if (isset($mySession["forms_backup"])) {

            $fromArrayFromSession = $mySession["forms_backup"];
            if (isset($fromArrayFromSession[$in_formID]["form.instances"][$in_instance_id]["valuesPrimarykeyFields"][$in_datarow][$in_TableAndColumn])) {
                $feedback = $fromArrayFromSession[$in_formID]["form.instances"][$in_instance_id]["valuesPrimarykeyFields"][$in_datarow][$in_TableAndColumn];
            } else {
                $feedback = false;
            }
        } else {
            $feedback = false;
        }

        return $feedback;
    }
    
    
    
     
    /**
     * 
     * @param   array     $in_SESSION                 Refernez zum SESSION-Array
     * @param   string    $in_uid             
     * @param   boolean   $in_is_guest_user           Gibt an, ob es sich um einen Guest-User handelt
     * @param   string    $in_app_id                  APP-ID der uid
     * @param   array     $in_roles                   Rollen, auf die uid Zugriff hat. (Zweidimensionales Array: role.id, role.name, role.app_id)
     * @param   array     $in_active_role             die aktive Rolle (role.id, role.name, role.app_id)
     * @param   string    $in_validator_process_type  [roleByAccount|roleByMask|undefined]
     * @param   array     $in_targetMask              Bsp.: Array("app_id" => "SYS01", "id" => "100") 
     * @return  array                                 Session-Array mit neu gesetzten Attributen
     */ 
    private function setSessionAttributs($in_SESSION, $in_uid, $in_is_guest_user, $in_app_id, $in_roles, $in_active_role, $in_validator_process_type, $in_targetMask) {
        $in_SESSION['uid'] = $in_uid;            
        $in_SESSION['guest_user'] = $in_is_guest_user;            
        $in_SESSION['app_id']=$in_app_id;            
        $in_SESSION["rollen"] = $in_roles;		
	$in_SESSION["active_role"] = $in_active_role;                      
        $in_SESSION["validator_process_type"] = $in_validator_process_type;
        
       
        
        //Session-Datensatz in Datenbank anlegen oder aktualisieren
        $local_feedback = $this->writeSessionStatusToDb($in_uid, $in_app_id);

        if(isset($in_SESSION["redirect"])) {
            if($in_SESSION["redirect"]["redirect"]!= 1) {
                $setNewTargetMask = true;
                
            } else {
                $setNewTargetMask = false;
            }
        } else {
            $setNewTargetMask = true;
        }
        
        
        if($setNewTargetMask === true) {
            $in_SESSION["target_mask"] = $in_targetMask;
            //GET-Variable ebenfalls anpassen.
            //Anwendungsfall: Target-Mask wird ursprünglich über die GET-Variable ermittelt. Anschließend könnte die Target-Mask jedoch
            //bspw. durch rebuildTargetMask wieder geändert worden sein.
            $this->setTargetMaskToGET($in_targetMask); 
        }

            
        
        return $in_SESSION;
    }
    
    
    
    
    
    
    /** Erstellt oder aktualisiert einen Datensatz zur aktuellen Session in der Datenbank.
     * 
     * @param string    $in_user       aktueller user
     * @param string    $in_app_id     momentan genutzte APP
     * @return bool
     */
    private function writeSessionStatusToDb($in_user, $in_app_id) {
        
        $feedback = true;
        
        $session_lifetime = getConfig("session_lifetime", global_variables::getAppIdFromSYS01());
        $last_activity_time = date('Y-m-d H:i:s');
        $end_time = date('Y-m-d H:i:s', strtotime("now +".$session_lifetime." minutes"));
        $browser = $_SERVER['HTTP_USER_AGENT'];
        $cur_user = $in_user;
        $cur_app_id = $in_app_id;                //Wert ist veränderlich, da der angemedete user die APP auch wechseln kann.
        $connection_id = global_variables::getAppIdFromSYS01();
        $schema = global_variables::getNameOfDbSchemaSYS01();
        $table = "session";
        
        $SqlArray = array();
        $SqlArray["schema"] = $schema;
        $SqlArray["table"] = $table;
	$SqlArray["into"]   = "   app_id,           session_id,          valid_from,               valid_to,        browser_id,       ip_adress,           account_id,       last_activity";
	$SqlArray["values"] = "'".$cur_app_id."', '".session_id()."', '".$last_activity_time."', '".$end_time."', '".$browser."', '". $this->getIpAdress()."', '".$cur_user."', '".$last_activity_time."'";
        $SqlArray["update"] = "valid_to = '".$end_time."', last_activity = '".$last_activity_time."', app_id = '".$cur_app_id."', account_id= '".$cur_user."'";
        $SqlArray["where"]  = "session_id='".session_id()."'";
	
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = $connection_id;  
        
        
        
        //Prüfen, ob der Session-Datensatz bereits in der Tabelle session existiert
        $exist_ds = getDataFromTableByID($connection_id, $schema, $table, "session_id", $SqlArray["where"]);
        
        if($exist_ds === false) {
            $result = db_connection_handler::insertOnDatabase($connection_id, $SqlArray, __FUNCTION__, false);
        } else {
            $result = db_connection_handler::updateOnDatabase($connection_id, $SqlArray, __FUNCTION__, false);
        }


        if ($result < 0) {
            $feedback = false;
        }  
        
        
        $feedbacktext = getFeedbacktextForFunction($result, global_variables::getAppIdFromSYS01());
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , $feedbacktext);
            
        return $feedback;
    }
    
    
    
    
    

    /** Die Funktion überträgt die Werte mask_id und die mask_app_id von targetMask in die globale
     * GET-Variable. Das ist notwendig, da die GET-Variable noch im späteren Programmverlauf verwendet wird.
     * 
     * @param type $in_targetMask
     */
    private function setTargetMaskToGET($in_targetMask) {
        $_GET["mask"] = $in_targetMask["id"];
        $_GET["maskapp"] = $in_targetMask["app_id"];
    }
    
    

    /**
     * Grundeinstellungen für alle Sessions festelgen.
     */
    private function setSessionSettings() {
        //Session-Einstellungen
        //Session-Lifetime in Sekunden -> 1800 = 30 Minuten; default 1440
        ini_set('session.gc_maxlifetime', 43000);  
        //Muss identisch sein mit session-Lifetime, damit es garantiert funktioniert. 
        //Dadurch verlängert sich die Session jedoch auch nicht bei User-Aktion. Die Session läuft nach erreichen der Zeit ab.
        //Wenn ein anderes Verhalten gewünscht ist, sollte der nachfolgende Parameter nicht oder auf 0 gesetzt werden.
        //session_set_cookie_params(0);  
        
        //Sorgt dafür, dass nach jedem Session_destroy die letzte ID verworfen wird.
        ini_set('session.use_strict_mode', true);
        
        session_set_cookie_params([
                'lifetime' => 43000,                 //in Sekunden
                'path' => '/',                      //übergreifend belassen, da sonst temp-Pfad während Install-Vorgang nicht akzeptiert wird
                'domain' => $_SERVER['HTTP_HOST'],  // leading dot for compatibility or use subdomain
                'secure' => true,
                'httponly' => false,                //Parameter kann leider nicht durch einen Config-Parameter bestimmt werden, da dann Client bereits vor der Session Daten erhält. -> WhiteScreen
                'samesite' => 'Lax'                // None || Lax  || Strict
            ]);


        // gc (Aufräumen) mit einer Wahrscheinlichkeit von 100% aufrufen 
        // Schlägt fehl, wenn Rechte für den Session-Ordner nicht gegeben sind -> daher auskommentiert und Standardeinstellung belassen.
        //   ini_set('session.gc_probability', 100);            
        //   ini_set('session.gc_divisor', 100);
    }
    
    
    
    /**
     * Setzt den ErrorLevel für PHP-Feedback an den Browser entsprechend dem Config-Parameter "debug_php_errorreporting".
     * Kein Rückgabewert.
     */
    private function setErrorLevel() {
        //Fehlermeldungen sollten im Normalfall abgeschaltet sein, damit Anwender keine kryptischen Meldungen und Angreifer keine unterstützenden Informationen erhalten.
        $error_level = getConfig("debug_php_errorreporting", global_variables::getAppIdFromSYS01());
        if($error_level == 0) {$error_level = $error_level;} else {$error_level = E_ALL; ini_set("display_errors", 1);}
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." für PHP-Feedback an den Browser", $error_level);
        error_reporting($error_level); 
        //error_reporting(E_ALL);
        
    }
    
    
    
    /** Bricht den Anmeldevorgang ab, dokumentiert den Grund und führt den Anwender wieder auf die Ausgangsseite zurück
     * 
     * @param string    $in_message         Meldung, die dem Anwender angezeigt wird
     * @param integer   $in_action          Aktion, die dem Anwender angeboten wird <br />
     *                                      0 = Anwender Link zur Ausgangsseite anbieten. <br />
     *                                      1 = Link zur Standard-Anmeldeseite anbieten <br />
     *                                      2 = Link zur Anmeldeseite der App nachdem zuvor ein Button mit diesem Ziel angeklickt wurde
     * @param string    $in_debug_message   Meldung, die im debug-log geschrieben wird.
     * @param boolean $in_destroy_session Gibt an, ob die Session zerstört werden soll
     */
    private function cancelLogin($in_message, $in_action, $in_debug_message, $in_destroy_session) {
        
        
        if          ($in_action == 0) {
            $sender_url = $_SERVER["HTTP_REFERER"];
            $action_message = "Zurück zur <a href=\"$sender_url\">Ausgangsseite</a><br/>";
        } elseif    ($in_action == 1) {
            $target_mask_app_id = $_GET["maskapp"];
            $action_message = "Zurück zur <a href=\"".global_variables::getDefaultMask($target_mask_app_id, "login_mask")."\">Anmeldung</a><br/>";
        } elseif    ($in_action == 2) {
            
            $target_mask_id = $_GET["mask"];
            $target_mask_app_id = $_GET["maskapp"];
            $action_message = "Zurück zur <a href=\"../view/page.php?mask=".$target_mask_id."&maskapp=".$target_mask_app_id."\">Anmeldung</a><br/>";
        }

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Abbruch in Session_Handler', $in_debug_message);
        
        
        
        header('Content-Type: text/html; charset=utf-8');
        echo    $in_message;
        echo    "<br />";
        echo    $action_message;
        
        if($in_destroy_session == true) {
            $this->destroyMySession();
            exit;
        } 
    }
    
    

    /**
     * Leert und zerstört das SESSION-Array. Zudem wird die DB-Tabelle session bereinigt.
     */
    private function destroyMySession() {
        
        
        //eigene und alle abgelaufenen Sessions aus der DB-Tabelle session löschen
        $now = date('Y-m-d H:i:s');
        $connection_id = global_variables::getAppIdFromSYS01();
        $schema = global_variables::getNameOfDbSchemaSYS01();
        
        $sql_daten["schema"] = $schema;
        $sql_daten["table"] = "session";
        $sql_daten["where"] = "session_id='".session_id()."' or valid_to < '".$now."'";

        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();

        
        // SESSION leeren
        $_SESSION = array();
        $this->setSessionArray(array());
        // Session zerstören
        session_unset();

        session_destroy();

        //Session auch aus DB-Tabelle löschen
        $result = db_connection_handler::deleteOnDatabase($connection_id, $sql_daten, __FUNCTION__, false);

       
    }
    
    

    /** Prüft, ob der Gastuser Zugriff hat. Falls nicht, wird die Session zerstört und ein neue erstellt. 
     * Falls ein redirect besteht, bleibt dieser erhalten.
     * Auch form_backup bleibt erhalten.
     * 
     * @param   array   $in_SESSION     Referenz auf das SESSION-Array
     * @param   string  $in_maskApp     App-ID der aufgerufenen Maske
     * @param   integer $in_maskId      ID der Maske
     */
    private function checkGuestSession(&$in_SESSION, $in_maskApp, $in_maskId) {
        //Prüfen, ob guest auf die angeforderte Maske zugreifen darf.
        $Zugriff_erlaubt = checkPermission($in_SESSION["uid"], $in_SESSION["app_id"], $in_maskApp, $in_maskId); 
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'array Zugriff_erlaubt für Masken:', $Zugriff_erlaubt);
            
        //Falls Guest nicht zugreifen darf, wird die Guest-Session zerstört.
        if($in_SESSION['guest_user'] == true AND $Zugriff_erlaubt["access"] != true) {
            $redirect_backup = "";
            $form_backup = "";
            if(isset($in_SESSION["redirect"])){
                //Wenn ein Redirect-Zweig in der Session existiert, wird dieser gesichert
                $redirect_backup = $in_SESSION["redirect"];
            } 
            
            if(isset($in_SESSION["forms_backup"])) {
                //Wenn form_backup vorhanden ist, wird es gesichert. Nur so können Ajax-Abfragen bei abgelaufenen oder zerstörten Sessions noch sinnvolle Ergebnisse liefern.
                $form_backup = $in_SESSION["forms_backup"];
            }
            
            $in_SESSION = array();
            // Session zerstören
            $this->destroyMySession();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, 'destroy_guest_Session:');
            
            session_start();
            if(is_array($redirect_backup)) {$_SESSION["redirect"] = $redirect_backup;}
            if(is_array($form_backup)) {$_SESSION["forms_backup"] = $form_backup;}

        } else {
            //Gastuser = false -> Dieser Fall wird separat behandelt
            //Gastuser = true und access = true -> nothing Todo
        }
        return $_SESSION;
    }
    
    

    /** Prüft, ob in der aufgerufenen URL verbotene Strings enthalten sind.
     * 
     * @return      boolean         True, wenn verbotene Strings erkannt wurden.
     */
    private function checkUrlForForbiddenStrings() {
        $called_url=$_SERVER["REQUEST_URI"];
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ .'aufgerufene URL.', $called_url);

        $forbiddenStrings = array('${', 'jquery{');
        foreach ($forbiddenStrings as $curForbiddenStr) {
            if (strpos($called_url, $curForbiddenStr)) {
                $feedback = true;
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ .'In der aufgerufenen URL wurden verbotene Zeichen entdeckt.', $called_url);
                break;
            } else {
                $feedback = false;
            }
        }
        
        return $feedback;
    }
    
    

    /**
    * Lenkt den Nutzer auf die Login-Maske um, wenn der Zugriff verweigert wurde.
    * Das ursprüngliche URL-Ziel wird in SESSION["redirect"] abgelegt
    * 
    */
    public function deniedAccess($in_reason) {
        
        $redirect_array = array();
        $redirect_array["redirect"] = 1;
        $redirect_array["redirect_handled"] = 0;                                //Merkmal, um zu erkennen, um diese Umleitung schon verarbeitet wurde
        $redirect_array["reason"] = $in_reason;
        $redirect_array["reason_text"] = "access_denied";    
            
        if($in_reason == "-130_info") {
            //-130 -> die Rolle darf nicht auf die gewünschte Ressource zugreifen
            
            //Function-ID in URI deaktivieren, da sonst nach dem Redirect die Funktion aufgerufen wird, obwohl weder POST-Array noch form-Array erhalten sind.
            $requestUriWithoutFunction = str_replace("button_action_function_id", "deactivate_button_action_function_id", $_SERVER['REQUEST_URI']); 
            //Targetmask und mask_app_id in SESSION für redirect hinterlegen
            $redirect_array["request_uri"] = $requestUriWithoutFunction;
            $redirect_array["request_appid"] = $_GET['maskapp'];
            $redirect_array["request_maskid"] = $_GET['mask'];
        
        } elseif($in_reason == "-134") {
            //-134 -> Session abgelaufen oder falsche Anmeldung
            
            cancelLogin("Ihre Sitzung ist abgelaufen.<br>\r\n ", 2, "Bittemelden Sie sich erneut an.", true);
            
        } elseif($in_reason == "132") {
            //-132 -> die IP-Adresse darf nicht auf die gewünschte Ressource zugreifen
            $redirect_array["request_uri"] = global_variables::getDefaultMask(global_variables::getAppIdFromSYS01(), "start_mask");
            $redirect_array["request_appid"] = global_variables::getDefaultMaskAppId(global_variables::getAppIdFromSYS01(), "login_mask");
            $redirect_array["request_maskid"] = global_variables::getDefaultMaskId(global_variables::getAppIdFromSYS01(), "login_mask");
        }
        
        //Loginmaske und Formular ermitteln
        $defaultLoginPage = global_variables::getDefaultMask($redirect_array["request_appid"], "login_mask");
        
        $_SESSION['redirect'] = $redirect_array;
        $_SESSION['guest_user'] = true;                                         //dadurch wird sichergestellt, dass der Aufruf der LoginPage zulässig ist.
        unset($_SESSION['target_mask']);                                        //target_mask wieder entfernen, da sonst Endlosschleife entstehen kann.
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' SESSION_ARRAY', $_SESSION);
        $this->setSessionArray($_SESSION);
        
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' Redirect zur Login-Page', $defaultLoginPage);
        header("Location: ".$defaultLoginPage);
        exit;
        
        
    }
   
    
    
    /** entfernt das redirect-Attribut aus dem Session-Array
     * 
     */
    public function unsetRedirect() {
        $my_session = $this->private_session_array;
        if(isset($my_session["redirect"])) {
            //ToDo: die erste Zeile entfernen, sobald sichergestellte ist, dass nur noch private_session_array relevant ist (14.12.2023)
            unset($_SESSION["redirect"]);
            unset($my_session["redirect"]);
        }
        $this->private_session_array = $my_session;
    }
    
    
    /**
     * Setzt den Wert $_SESSION["Fieldmessages"] auf array(). D.h., alte Meldungen werden gelöscht.
     */
    public function resetFieldMessages() {
        $_SESSION["Fieldmessages"] = array();
    }
    
    
    
    //Hinterlegt das Array mit allen Formularen als backup für den nächsten Maskenaufruf im Session_array
    public function setFormBackup($in_formbackup) {
        $mySession = $this->getSessionArray();
        $mySession["forms_backup"] = $in_formbackup;
        $this->setSessionArray($mySession);
        //Die Globale wird ebenfalls bestückt, da aus den user_functions nur darauf zugegriffen werden kann.
        $_SESSION = $mySession;
    }
   
    
    /** Ermittelt für den aktuellen URL-Aufruf die gewünschte Maske und app_id. Dabei wird ein 
     * möglicherweise vorliegender redirect beachtet
     * 
     * @return  array                   Bsp.: Array("app_id" => "SYS01", "id" => "100") 
     */
    private function buildTargetMaskArray() {
        $my_session = $_SESSION;
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' SESSION_ARRAY', $my_session);
        
        $target_mask_array = array();
        
        if (isset($_GET['maskapp'])) {
            //Normalfall beim Aufruf einer Maske
            $target_mask_array["app_id"] = $_GET['maskapp'];
            $target_mask_array["id"] = $_GET["mask"];      
        } else {
            //$_GET['maskapp'] ist nicht gesetzt, wenn der Aufruf über ajaxRequest.php erfolgt
            $target_mask_array["app_id"] = global_variables::getAppIdFromSYS01();                                         
            $target_mask_array["id"] = 0;                                                            
        }
        
        
        if(isset($my_session["redirect"])) {
            //login-Maske wurde durch einen redirect aufgerufen.
            if($my_session["redirect"]["redirect_handled"] == 1) {
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, ' targetmask aus session-redirect ermitteln');
        
                $target_mask_array["app_id"] = $my_session["redirect"]["request_appid"];
                $target_mask_array["id"] = $my_session["redirect"]["request_maskid"];
            }
        } 
        
        return $target_mask_array;
    }
    
    

    /**Prüft, ob für die APP der aktiven Rolle eine abweichende Start-Maske hinterlegt wurde. Falls ja, wird diese als TargetMask zurückgegeben.
     * Falls nicht, wird $in_targetMask zurückgegeben.
     * 
     * @param   array   $in_targetMask      Bsp.: Array("app_id" => "SYS01", "id" => "100") 
     * @param   array   $in_activeRole      Array(role.id, role.app_id, role.name)
     * @return  array                       Bsp.: Array("app_id" => "INV11", "id" => "775") 
     */
    private function rebuildTargetMask($in_targetMask, $in_activeRole) {
        $new_targetMask = $in_targetMask;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' active Role', $in_activeRole);
        
        if($in_activeRole["role.app_id"] != "") {
            //Startmaske der Target-App
            
            //Prüfen, ob für die Rolle eine start_mask definiert wurde
            $startmask_by_role = getRoleStartmask($in_activeRole["role.app_id"], $in_activeRole["role.id"]);
            if($startmask_by_role != array()) {
                //Start_Mask wurde über Rolle ermittelt
                $new_targetMask["app_id"] = $startmask_by_role["mask_app_id"];
                $new_targetMask["id"] = $startmask_by_role["mask_id"];
            } else {
                $new_targetMask["app_id"] = global_variables::getDefaultMaskAppId($in_activeRole["role.app_id"], "start_mask");
                $new_targetMask["id"] = global_variables::getDefaultMaskId($in_activeRole["role.app_id"], "start_mask");
            }
        }
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' Rückgabe targetMask', $new_targetMask);
        return $new_targetMask;
        
    }
}
