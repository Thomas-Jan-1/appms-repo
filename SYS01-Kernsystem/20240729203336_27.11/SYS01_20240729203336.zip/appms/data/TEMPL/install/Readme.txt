Readme f�r Ordner "Install":
----------------------------


Verwendungszweck des Ordners:
- manuelle Installationsskripte, welche nicht durch da Erstellen einer Version automatisch erzeugt werden.
- DB-Modell, bspw. im XML-Format