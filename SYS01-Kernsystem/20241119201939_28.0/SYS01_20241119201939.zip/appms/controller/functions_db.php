<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


//require_once("../model/_dbconnect.inc");                                        //Datenbankverbindung  Achtung: Irgendwann auch wieder die Datenbankverbindung schlie�en!!!
require_once("../controller/global_variables_class.php");                       //globale Variablen
require_once("../controller/model/db_connection_handler_class.php");








    /** Ermittelt id und und Anzeigename von einer beliebigen Tabelle. Dabei kann eine Sortierbedingung und eine Where-Klausel angegeben werden.
     * Die Where-Klausel muss eine komplette Bedingung enthalten.
     * Die Sortierbedingung kann ebenfalls mehrere Spalten enthalten.
     * 
     * ToDo: Wenn eine Referenz eigentlich aus mehreren PK's bestehen müsste, dann wird die Referenz derzeit eindeutig über eine Condition gemacht. 
     * Funktioniert nur, wenn alls PK's bekannt sind. Bsp.: getFields
     * 
     * @param string $in_connection_id  ID der Connection, welche verwendet werden soll. Mit der Connection muss die benannte Tabelle erreichbar sein.   
     * @param String $in_schema         Datenbankschema, in dem sich die Tabelle befindet
     * @param String $in_table          Datenabnktabellenname
     * @param String $in_idField        Datenbankfeldname (Spalte in der Tabelle)
     * @param String $in_showField      Spaltenname des Feldes, dass neben dem idField im Ergebnisarray übergeben werden soll
     * @param String $in_orderByField   kommaseparierte Liste von Datenbankspalten, nach denen sortiert werden soll (Bsp.: 'tabelle.spalteA, tabelle.spalteB')
     * @param String $in_Condition      [optional] Where-Bedingung, die die Tabellenabfrage einschränkt (Bsp.: 'spalteA = "XYZ" AND spalteB = 2')
     * @return array                    zweidimensional (default = array() ); Bsp.: array([0] => array([table.ref_id] => m, [table.ref_value] = Herr))
     */
    function getReferenceListFromTable($in_connection_id, $in_schema, $in_table, $in_idField, $in_showField, $in_orderByField, $in_Condition = "") {						
	$refList = array();
        
        $queryRequest = new sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        $queryRequest->addSelectComplexStatement($in_table.".".$in_idField.", ".$in_table.".".$in_showField,
                                                $in_schema.".".$in_table,
                                                $in_Condition,
                                                "", 
                                                $in_orderByField);

        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);

        //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Ergebnis der Datenbankabfrage: ', $result);
        if ($result <> false) {
            for($i = 0; $i < count($result); $i++) {
                $refList[$i] = array(
                    $in_table.".ref_id" => $result[$i][$in_table.".".$in_idField],
                    $in_table.".ref_value" => $result[$i][$in_table.".".$in_showField]
                    //$in_table.".value" => $result[$i][$in_table.".".$in_showField]." (".$result[$i][$in_table.".".$in_idField].")"
                );
            }
        }
        return $refList;		

    }

    
    
    
    
    
    
    
    
    
    
    /** Ermittelt aus der DB-Tabelle manager.backup_rewritecolumns die Spalten, deren Werte bei einem Update 
     * vom Altsystem übernommen werden müssen.
     * 
     * @param   string  $in_connection_id       ID der zu nutzenden Connection
     * @param   string  $in_app_id              ID der APP, deren backup_rewriteColumns ermittelt werden sollen
     * @return  array                           Entweder array mit den Ergebnissen oder leeres Array, wenn keine rewrite-Columns vorliegen
     */
    function getBackupRewriteColumns($in_connection_id, $in_app_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        
        $kernelAppId = global_variables::getAppIdFromSYS01();
        $queryRequest = new \sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);    //Slash am Anfang ist wichtig, um aus dem aktuellen namespace heraus zu kommen

            $queryRequest->addSelectColumn("backup_rewritecolumns", "app_id");
            $queryRequest->addSelectColumn("backup_rewritecolumns", "schemaname");
            $queryRequest->addSelectColumn("backup_rewritecolumns", "tablename");
            $queryRequest->addSelectColumn("backup_rewritecolumns", "columnname");
            $queryRequest->addSelectColumn("backup_rewritecolumns", "ctrl");
            $queryRequest->addSelectColumn("backup_rewritecolumns", "sys");
            $queryRequest->addSelectColumn("backup_tabledefinitions", "app_column");
            
            $queryRequest->addTable($db_schema_manager, "backup_rewritecolumns", 1, "BASE", "");
            $queryRequest->addTable($db_schema_manager, "backup_tabledefinitions", 2, "INNER", "");
            
            $queryRequest->addWhereCondition("AND", "(", "backup_rewritecolumns", "app_id", "=", "'$in_app_id'", "");
            $queryRequest->addWhereCondition("OR", "", "backup_rewritecolumns", "app_id", "=", "'$kernelAppId'", ")");
            $queryRequest->addWhereCondition("AND", "", "backup_tabledefinitions", "app_id", "=", "backup_rewritecolumns.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "backup_tabledefinitions", "tablename", "=", "backup_rewritecolumns.tablename", "");
            $queryRequest->addWhereCondition("AND", "", "backup_tabledefinitions", "definition", "in", "('configtable','addIfContentBackupForApp')", "");
            
            $queryRequest->addOrderbyPart("schemaname, tablename, columnname");

        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__,true);
        
        
        if($result == false) {
            $feedback = array();
        } else {
            $feedback = $result;
        }
        
        return $feedback;

    }
    
    
    
    /** Ermittelt für eine Rolle die Startmaske aus der Tabelle role_has_mask.
     * 
     * @param   string  $db_schema_manager_connection_id    ID, mit der die Connection auf das Schema der Kernelapp geöffnet werden soll; i.d.R. SYS01
     * @param   string  $in_role_app_id                     APP der Rolle
     * @param   string  $in_role_id                         ID der Rolle
     * @return  array                                       Array(mask_app_id,mask_id); Wenn keine Maske ermittelt werden konnte, wird ein leeres Array zurückgegeben
     */
    function getRoleStartmask($in_role_app_id, $in_role_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);    

            $queryRequest->addSelectColumn("role_has_mask", "mask_app_id");
            $queryRequest->addSelectColumn("role_has_mask", "mask_id");
             
            $queryRequest->addTable($db_schema_manager, "role_has_mask", 1, "BASE", "");
            
            $queryRequest->addWhereCondition("AND", "", "role_has_mask", "is_startmask", "=", 1, "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask", "role_app_id", "=", "'".$in_role_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask", "role_id", "=", $in_role_id, "");

        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        
        if($result == false) {
            $feedback = array();
        } else {
            $feedback["mask_app_id"] = $result[0]["role_has_mask.mask_app_id"];
            $feedback["mask_id"] = $result[0]["role_has_mask.mask_id"];
        }
        
        return $feedback;

    }
    
    
    
    
    /** Ermittelt für eine APP die Scripts der aktuellen, noch nicht finalisierten Version.
     * 
     * @param   string  $in_connection_id       ID, mit der die Connection auf das Schema der Kernelapp geöffnet werden soll; i.d.R. SYS01
     * @param   string  $in_app_id              APP des Versionsscripte abgerufen werden sollen
     * @param   string  $in_script_type         Typ der Scripte [before|after]
     * @return  array                           Array mit SQL-Anweisungen
     */
    function getVersionScript($in_connection_id, $in_app_id, $in_script_type) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        
        
        $queryRequest = new sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);    

            $queryRequest->addSelectColumn("version", "id");
            $queryRequest->addSelectColumn("version", "versionnumber");
            $queryRequest->addSelectColumn("version_notes", "id");
            $queryRequest->addSelectColumn("version_notes", "topic");
            $queryRequest->addSelectColumn("version_script", "script");
            
            $queryRequest->addTable($db_schema_manager, "version", 1, "BASE", "");
            $queryRequest->addTable($db_schema_manager, "version_notes", 2, "INNER", "");
            $queryRequest->addTable($db_schema_manager, "version_script", 3, "INNER", "");
            
            $queryRequest->addWhereCondition("AND", "", "version_notes", "version_id", "=", "version.id", "");
            $queryRequest->addWhereCondition("AND", "", "version_notes", "app_id", "=", "version.app_id", "");
            $queryRequest->addWhereCondition("AND", "(", "version", "finalized", "is", "NULL", "");
            $queryRequest->addWhereCondition("OR", "", "version", "finalized", "=", "0", ")");
            $queryRequest->addWhereCondition("AND", "", "version", "app_id", "=", "'$in_app_id'", "");
            $queryRequest->addWhereCondition("AND", "", "version_script", "version_id", "=", "version_notes.version_id", "");
            $queryRequest->addWhereCondition("AND", "", "version_script", "app_id", "=", "version_notes.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "version_script", "version_notes_id", "=", "version_notes.id", "");
            $queryRequest->addWhereCondition("AND", "", "version_script", "scripttype", "=", "'$in_script_type'", "");
            
            $queryRequest->addOrderbyPart("version.id, version_notes.sort, version_script.sort");

        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        
        if($result == false) {
            $feedback = array();
        } else {
            $feedback = $result;
        }
        
        return $feedback;

    }
    
    
    
    
    /** Ermittelt die Verbindungsdaten für ein Ldap-Directory
     * 
     * @param   integer $in_directory_id    ID des gesuchten Ldap-Directory, unter der die Parameter in der DB-Tabelle directory abgelegt sind.
     * @return  mixed                       false, wenn keine Parameter gefunden werden konnten oder ein array mit den Parametern
     *                                      Bsp.: array(dir_base => "dc=example,dc=com", dir_ou => "People", dir_server => "192.168.178.45", dir_port => 389) 
     */
    function getLdapdirParams($in_directory_id) {															//Directory-Server aus Eintrag in der appman-DB ermitteln
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
	$result = getTableData($db_schema_manager_connection_id, "directory", "manager", true, "", "id=".$in_directory_id, __FUNCTION__);

        if($result <> false) {
            $directory_array = $result[0];                  //nur der erste Datensatz wird beachtet. Da die Abfrage mit id erfolgte, kann es theoretisch nur einen Antwort-DS geben.
            $ldapParameters = array(
		"dir_base"      => $directory_array["directory.base"],
		"dir_ou"        => "ou=".$directory_array["directory.ou"],
		"dir_server"    => $directory_array["directory.server"],
		"dir_port"      => $directory_array["directory.port"]
		);
        } else {
            $ldapParameters = false;
        }

	return $ldapParameters;
    }
    



    /** Ermittelt für eine Tabelle mit Hilfe des information_schemas die Primary-Keys und gibt sie in der richtigen
     * Reihenfolge als kommaseparierte Liste zurück.
     * 
     * @param   string      $in_connection_id   ID der Connection; I.d.R. aktuelle App_ID
     * @param   String      $in_schema          Name des Schemas, in dem die Tabelle liegt.
     * @param   String      $in_table           Tabellenname
     * @return  array                           Zweidimensionales Array mit der Anzahl der PKeys (key = countIDs) und einer kommaseparierten Liste der PKeys (key = idFields)
     */
    function getPkeysFromTable($in_connection_id, $in_schema, $in_table){
        $db_information_schema = global_variables::getNameOfDbSchemaInformation();
        $idFields = "";
        
        $queryRequest = new sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);

            $queryRequest->addSelectColumn("key_column_usage", "column_name");
            $queryRequest->addSelectColumn("key_column_usage", "ordinal_position");

            $queryRequest->addTable($db_information_schema, "table_constraints", 1, "BASE", "");
            $queryRequest->addTable($db_information_schema, "key_column_usage", 2, "INNER", "");

            $queryRequest->addWhereCondition("AND",    "", "table_constraints", "constraint_catalog",  "=", "key_column_usage.constraint_catalog", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "constraint_schema",   "=", "key_column_usage.constraint_schema", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "constraint_name",     "=", "key_column_usage.constraint_name", "");
            //$queryRequest->addWhereCondition("AND", "", "table_constraints", "table_catalog",       "=", "key_column_usage.table_catalog", "");   //die Spalte table_catalog gibt es nur in postgres
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "table_schema",        "=", "key_column_usage.table_schema", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "table_name",          "=", "key_column_usage.table_name", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "constraint_type",     "=", "'PRIMARY KEY'", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "table_schema",        "=", "'".$in_schema."'", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "table_name",          "=", "'".$in_table."'", "");
            
            $queryRequest->addOrderbyPart("key_column_usage.ordinal_position");

        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);

//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> SQL-Rückgabe ($queryResult) für connection_id '.$in_connection_id.': ', $queryResult);

	
	//Abfrageergebnis in ein Array übertragen
//        echo "Connection-ID: ".$in_connection_id."<br />";
	for($i = 0; $i < count($queryResult); $i++) {
		if($i == 0) {
                    $idFields = $in_table.".".$queryResult[$i]["key_column_usage.column_name"];
                } else {
                    $idFields = $idFields.", ".$in_table.".".$queryResult[$i]["key_column_usage.column_name"];			
                }
	}
        $idFieldsListArray = array("countIDs" => count($queryResult), "idFields" => $idFields);
	return $idFieldsListArray;
    }





    /** Ermittelt die IP-SecureRules, die für eine bestimte APP in den Datenbanktabellen ip und ipgroups hinterlegt wurde.
     * 
     * @param   string  $in_app_id                          APP, deren IP-SecureRules ermittelt werden sollen
     * @return  array                                       zwedimensinales Array Array
                                                                                    (
                                                                                        [0] => Array
                                                                                            (
                                                                                                [app_has_ipgroup.sort] => 1
                                                                                                [app_has_ipgroup.access_type] => allow
                                                                                                [ipgroup.name] => Test (Verwaltungs-PCNULLS)
                                                                                                [ip.iptype] => ipv4
                                                                                                [ip.ip] => 141.89.150.x
                                                                                            ))
     *                                                      Wenn keine Zugriffsrechte gefunden wurden, dann wird ein leeres Array zurückgegeben -> array()
     * 
     */
    function getIpSecureRules($in_app_id){
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);

            $queryRequest->addSelectColumn("app_has_ipgroup", "sort");
            $queryRequest->addSelectColumn("app_has_ipgroup", "access_type");
            $queryRequest->addSelectColumn("ipgroup", "name");
            $queryRequest->addSelectColumn("ip", "iptype");
            $queryRequest->addSelectColumn("ip", "ip");
            
            $queryRequest->addTable($db_schema_manager, "app_has_ipgroup", 1, "BASE", "");
            $queryRequest->addTable($db_schema_manager, "ipgroup", 2, "INNER", "");
            $queryRequest->addTable($db_schema_manager, "ip", 3, "INNER", "");

            $queryRequest->addWhereCondition("AND", "", "ipgroup", "app_id",  "=", "app_has_ipgroup.ipgroup_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "ipgroup", "id",   "=", "app_has_ipgroup.ipgroup_id", "");
            $queryRequest->addWhereCondition("AND", "", "ip", "ipgroup_app_id",     "=", "ipgroup.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "ip", "ipgroup_id",       "=", "ipgroup.id", "");
            $queryRequest->addWhereCondition("AND", "", "app_has_ipgroup", "app_id",        "=", "'".$in_app_id."'", "");
            
            $queryRequest->addOrderbyPart("app_has_ipgroup.sort");

        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);

        //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> SQL-Rückgabe ($queryResult): ', $queryResult);

	
	if($queryResult == false) {
            return array();
        } else {
            return $queryResult;
        }
        
	
    }
    
    
    




/** Ermittelt eine Liste aller verfügbaren Felder, die einer bestimmten form_id zugeordnet sind
 * 
 * @param String    $in_formID                          Schränkt die Datensätze der Tabelle Feld auf Basis der Spalte form_id ein. Wenn $in_formID=all, dann werden alle Felder ausgegeben.
 * @param string    $in_form_app_id                     APP-ID des Formulars
 * @param String    $sort                               [optional] Tabellenspalte, der Tabelle feld, nach der sortiert werden soll. (default = "feld.sort")
 * @param Integer   $in_formModus                       [optional] Gibt den Modus des Formulars an, für das Symbole ermittelt werden sollen (default = 1)
 * @param string    $in_parent_form_app_id              [optional] APP eines übergeordneten Formulars. Das tritt i.d.R. bei Formularen auf, welche eine Symbolleiste darstellen. Symbolleisten haben ein übergeordnetes Formular. (default = "SYS01")
 * @param integer   $in_parent_form_id                  [optional] ID des übergeordneten Formulars (default = 0)
 * @return Array
 */
function getFieldList($in_formID, $in_form_app_id, $sort = "feld.sort", $in_formModus = 1, $in_parent_form_app_id = 'SYS01', $in_parent_form_id = 0) {									
	//Todo: feld.button_target_form -> deprecated, wird durch button_target_forms ersetzt
                
	$db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();


        if ($in_formID == "all") {$andBedingung = "";}									//leere Bedingung und damit keine weitere Einschr�nkung in der Where-klausel
	else {$andBedingung = "AND feld.form_id = ".$in_formID." AND feld.form_app_id = '".$in_form_app_id."'";}								//Einschr�nkung f�r die Where-Klausel
        
	
	$querySelectPart = 	"feld.*,
                                content.content_type_id,
                                content.text,
                                content.intern_variable,
                                form.db_schema, 
                                form.db_table";
 
        $queryFromPart =        "$db_schema_manager.feld
                                        LEFT JOIN $db_schema_manager.feld_has_form_mode ON feld.id = feld_has_form_mode.feld_id AND feld.app_id = feld_has_form_mode.feld_app_id AND feld.form_mode_app_id = feld_has_form_mode.form_mode_app_id AND feld_has_form_mode.form_mode_id = $in_formModus
                                        LEFT JOIN $db_schema_manager.content ON feld.id = content.feld_id AND feld.app_id = content.feld_app_id, 
                                $db_schema_manager.konstante,
                                $db_schema_manager.form";
                                
        $queryWherePart =       "feld.konstante_id = konstante.id
                                AND feld.konstante_app_id = konstante.app_id
                                AND current_date >= konstante.gueltig_ab AND current_date <= konstante.gueltig_bis
                                $andBedingung
                                AND (feld_has_form_mode.mode is null OR feld_has_form_mode.mode <> 0)
                                AND feld.form_id = form.id 
                                AND konstante.id <> 2126       --Feldart = deaktiviert
                                AND feld.form_app_id = form.app_id";

        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, "", $sort);
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);

        //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Fieldlist: ', $result);
        
        if($result == false) {
            return array();
        } else {
            $trigger_fields = getTriggerFields($in_form_app_id);
            $dependsfield_targets = getDependsfieldTarget($in_form_app_id);
            $target_fields = getTargetFields($in_form_app_id);
            $target_forms = getTargetForms($in_parent_form_app_id, $in_parent_form_id);
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> TriggerForms: ', $target_forms);
            $result = mergeListToFieldlist($result, $trigger_fields, "feld.depends_from_field");
            $result = mergeListToFieldlist($result, $dependsfield_targets, "feld.dependsfield_target");
            $result = mergeListToFieldlist($result, $target_fields, "feld.affected_to_field");
            $result = mergeTargetformsToFieldlist($result, $target_forms, "feld.target_forms");
            return $result;
        }

}




/** Ermittelt aus der Tabelle backup_tabledefinitions des Kernel-Schemas alle Tabellen 
 * mit einem bestimmten definitionTyp.
 * 
 * @param   string      $in_definitionTyp           Typ[en] einer backup_tabledefinition  [configtable|addIfContentBackupForApp|ignoreIfContentBackup];
 *                                                  Den Wert in einfachen Hochkommata angeben, Bsp.: "'configtabel'"; 
 *                                                  Bsp. für mehrere Werte: "'configtable', 'ignoreIfContentBackup'"
 * @param   string      $in_app_id                  APP_ID dessen Tabellen-Definitionen ermittelt werden sollen.
 * @return  array                                   zweidimensionales array  oder false, wenn kein Datensatz zurückgeliefert wird    
 *                                                  Bsp.: Array
                                                        (
                                                                [0] => Array
                                                                        (
                                                                                [backup_tabledefinitions.tablename] => app
                                                                                [backup_tabledefinitions.app_column] => id 
                                                                                [backup_tabledefinitions.definition] => configtable
                                                                                [backup_tabledefinitions.app_id] => SYS01
                                                                        )

                                                                [1] => Array
                                                                        (
                                                                                [backup_tabledefinitions.tablename] => debug
                                                                                [backup_tabledefinitions.app_column] => id
                                                                                [backup_tabledefinitions.definition] => ignoreIfContentBackup
                                                                                [backup_tabledefinitions.app_id] => SYS01
                                                                        )

                                                                [2] => Array
                                                                        (
                                                                                [backup_tabledefinitions.tablename] => ipgroup
                                                                                [backup_tabledefinitions.app_column] => app_id
                                                                                [backup_tabledefinitions.definition] => configtable
                                                                                [backup_tabledefinitions.app_id] => SYS01
                                                                        )
 *                                                              }   
 */
function getBackupTabledefinitions($in_definitionTyp, $in_app_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $connectionID = global_variables::getAppIdFromSYS01();
        
        
        $queryRequest = new \sql_request($connectionID, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__, true);    //Slash am Anfang ist wichtig, um aus dem aktuellen namespace heraus zu kommen

            $queryRequest->addSelectColumn("backup_tabledefinitions", "tablename");
            $queryRequest->addSelectColumn("backup_tabledefinitions", "definition");
            $queryRequest->addSelectColumn("backup_tabledefinitions", "app_column");
            $queryRequest->addSelectColumn("backup_tabledefinitions", "app_id");

            $queryRequest->addTable($db_schema_manager, "backup_tabledefinitions", 1, "BASE", "");
            
            $queryRequest->addWhereCondition("AND", "", "backup_tabledefinitions", "definition", "in", "(".$in_definitionTyp.")", "");
            $queryRequest->addWhereCondition("AND", "", "backup_tabledefinitions", "app_id", "=", "'$in_app_id'", "");
            
        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        
        if($result == false) {
            $feedback = array();
        } else {
            $feedback = $result;
        }
        return $feedback;
}


/** Sendet einen Update-Befehl an den DB-Konnektor. Dazu muss ein Array mit den Werten schema, table, update und where  übergeben werden.
 * 
 * @param   array       $in_SqlDaten            Array mit dem Strukturellen Aufbau, wie es die Funktion extractDataFromPostarray erzeugt.
 * @param   Array       $in_formArray           Array, welches die form-Daten (Formulardaten) enthält
 * @param   Array       $in_current_account_id  Name des angemeldeten Nutzers (SESSION['uid'])
 * @param   object      $in_pagedata            Referenz zum pagedata-object
 * @return  integer                             Rückmelde-ID's entsprechend der Konstantentyp_id 35 [1|-1|-12] 
 */
function updateData($in_SqlDaten, $in_formArray, $in_current_account_id, &$in_pagedata) {
	
	$connection_id = $in_formArray["form.connection_id"];                               //ToDo: Besser wäre es, wenn in der DB-Tabelle form eine connection_id verwaltet werden würde, statt, dass die app_id genutzt wird. Dann könnten pro App mehrer connections genutzt werden.															
	$result = db_connection_handler::updateOnDatabase($connection_id, $in_SqlDaten, __FUNCTION__, true, $in_pagedata);
        
        
        if ($result < 0) {
            //Update schlug fehl
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__." Update fehlgeschlagen", $in_SqlDaten, "ERROR");
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> verwendete Connection-ID: ',$connection_id,'ERROR');
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Sender-Form: ',$in_formArray,'ERROR');
            return $result;
        } else {
            //Update war erfolgreich
            if ($in_formArray["form.logging"] == 1) {setLogData($in_SqlDaten, 1, $in_current_account_id, $in_formArray, $in_pagedata);}     //Wenn DB-Zugriffe Protokolliert werden sollen
            return $result;
        }
        
        																	
}



/** Sendet einen Delete-Befehl an eine Datenbank. Dazu muss ein Array mit den Werten schema, table und where  übergeben werden.
 * 
 * @param Array     $in_SqlDaten            Array, wie es von der Funktion extractDataFromPostarray erzeugt wird
 * @param Array     $in_formArray           Array mit allen Angaben zu einem Formular (siehe Tabelle form)
 * @param String    $in_current_account_id  Account_id/UID des aktiven Benutzers
 * @param object    $in_pagedata            Rferenz auf das Pagedata-Objekt
 * @return   integer                         siehe Konstantentyp_id = 35; alle Feedbackmeldungen des 3er-Bereichs 
 *                                           3   => erfolgreich gelöscht
 *                                          -3  => nicht gelöscht (SQL-Fehler)
 *                                          -31 => Zugriffsrecht für aktive Rolle und aktuelle Maske nicht gegeben.
 *                                          ...     
*/
function deleteData($in_SqlDaten, $in_formArray, $in_current_account_id, &$in_pagedata) {

        $connection_id = $in_formArray["form.connection_id"];                               //ToDo: Besser wäre es, wenn in der DB-Tabelle form eine connection_id verwaltet werden würde, statt, dass die app_id genutzt wird. Dann könnten pro App mehrer connections genutzt werden.
        $result = db_connection_handler::deleteOnDatabase($connection_id, $in_SqlDaten, __FUNCTION__, true, $in_pagedata);
	
	if ($result < 0) {
            return $result;
        } else {
            if ($in_formArray["form.logging"] == 1) {setLogData($in_SqlDaten, 3, $in_current_account_id, $in_formArray, $in_pagedata);}                                 //Wenn DB-Zugriffe Protokolliert werden sollen
            return $result;
        }		
																		
}



/** Führt eine SQL-Datei aus.
 * 
 * @param   object  $in_pagedata            Referenz auf das pagedata-object
 * @param   string  $in_path_to_script      relativer oder absoluter Pfad zur Scriptdatei; Wenn $in_script_plain genutzt wird, dann kann hier ein Leerstring angegeben werden.
 * @param   string  $in_script_name         Name der Scriptdatei; Wenn $in_script_plain genutzt wird, dann kann hier ein Leerstring angegeben werden.
 * @param   string  $in_connection_id       Connection-ID
 * @param   string  $in_callFromFunction    Name der Funktion, welche executeDbScript aufruft. Wird zur Fehlerdokumentation benötigt
 * @param   string  $in_script_plain        [optional] Script als Plain-Text. Wenn dieser Parameter angegeben ist, werden die Parameter $in_path_to_script und $in_script_name ignoriert. 
 * @return  integer                         Feedbackmeldungen gemäß Konstantentyp_id 35 [901|-900|-901|-21]
 */
function executeDbScript(&$in_pagedata, $in_path_to_script, $in_script_name, $in_connection_id, $in_callFromFunction, $in_script_plain = false) {
    
    
    If($in_script_plain != false) {
        $script = $in_script_plain;
        
    } else {
        $pathAndFile = $in_path_to_script.$in_script_name;
        $script = file_get_contents($pathAndFile);
    }
    
    if($script !== false) {
        $feedback = db_connection_handler::executeScriptOnDatabase($in_connection_id, $script, $in_callFromFunction, true, $in_pagedata);
    } else {
        $feedback = -900;
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Datei konnte nicht eingelesen werden! ', "Die Datei ".$pathAndFile." konnte nicht eingelesen werden.","ERROR");
    }
    return $feedback;
}





    



/** Reicht einen Insert-Befehl an den DB-Konnetor (db_connection_handler::insertOnDatabase) weiter. 
 * Dazu muss ein Array mit den Werten schema, table, into und values  übergeben werden.
 * Nach dem insert wird sofort ein commit abgesetzt.
 * 
 * @param   Array   $in_SqlDaten            Array mit dem Strukturellen Aufbau, wie es die Funktion extractDataFromPostarray erzeugt.
 * @param   Array   $in_formArray           Array, welches die App-Daten (Maskendaten) enthält
 * @param   Array   $in_current_account_id  Name des angemeldeten Nutzers (SESSION['uid'])
 * @param   object  $in_pagedata            Referenz zum pagedata-object
 * @param   boolean $in_updateSequence      [optional, default = true] Gibt an, ob nach dem Insert die Sequence der Tabelle aktualisiert werden soll.
 * @return  integer                         Rückmelde-ID's entsprechend der Konstantentyp_id 35 [2|-2|-21|-24] 
 */
function insertDataIntoDB($in_SqlDaten, $in_formArray, $in_current_account_id, &$in_pagedata, $in_updateSequence = true) {

        $connection_id = $in_formArray["form.connection_id"];                               //ToDo: Besser wäre es, wenn in der DB-Tabelle form eine connection_id verwaltet werden würde, statt, dass die app_id genutzt wird. Dann könnten pro App mehrer connections genutzt werden.
        $result = db_connection_handler::insertOnDatabase($connection_id, $in_SqlDaten, __FUNCTION__, true, $in_pagedata, $in_updateSequence);                      //Abfrage ausführen
	
        if ($result < 0) {
            //Insert schlug fehl
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Form_array! ", $in_formArray, "ERROR");
            return $result;
        } else {
            
            if ($in_formArray["form.logging"] == 1) {setLogData($in_SqlDaten, 2, $in_current_account_id, $in_formArray, $in_pagedata);}   //Wenn DB-Zugriffe Protokolliert werden sollen
            return $result;
        }
																	
}





/** schreibt einen Protokollsatz über die letzte Datenbanktransaktion
 * 
 * @param   Array       $in_sqlDaten        Mehrdimensionales Array, wie es extractDataFromPostarray() liefert
 * @param   Integer     $in_log_art         1=UPDATE, 2=INSERT, 3=DELETE, 4=OTHER
 * @param   String      $in_current_account_id    Benutzer, der die Änderung durchgeführt hat
 * @param   String      $in_formArray       Array, welches alle Daten des Formulars enthält (Siehe Tabelle form)
 * @param   object      $in_pagedate        Referenz auf pageData-Object
 * @return  boolean 
 */
function setLogData($in_sqlDaten, $in_log_art, $in_current_account_id, $in_formArray, &$in_pagedate) {
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
   
    //ID des zu protokollierenden Datensatzes ermitteln
    //Todo: Prüfen, ob es richtig ist, dass die kommenden 5 Zeilen, durch die darauffolgende Zeile ersetzt wurde.
//    if ($in_log_art == 2) {                                                                                                     //log_art=2 -> Insert
//        $log_id = getMaxValue($in_formArray['form.db_schema'], $in_formArray['form.db_table'], $in_formArray['form.log_id_spalte']);
//    } else {                                                                                                                    //Update, Delete und Sonstiges
//        $log_id = $in_logdata['logdata_id_data'];
//    }
//    
    
    
    $mask_id = $in_pagedate->getMaskProbertyID();
    $log_id = $in_sqlDaten['logdata_id_data'];
    
    $sqlLogdata = array();
    $sqlLogdata["into"] = "app_id                              , db_schema                   , tabelle                    , id_spalte                                , id_data      , log_art      , daten                        , mask_id     , mask_name                       , log_time         , username";
    $sqlLogdata["values"] = "'".$in_formArray['form.app_id']."', '".$in_sqlDaten["schema"]."', '".$in_sqlDaten["table"]."', '".$in_formArray['form.log_id_spalte']."', '".$log_id."', '$in_log_art', '".$in_sqlDaten["logdata"]."', ".$mask_id.", '".$in_formArray["form.name"]."', current_timestamp, '$in_current_account_id'";
    $sqlLogdata["update"] = "parameter='test', beschreibung='test', wert='test'";
    $sqlLogdata["schema"] = $db_schema_manager;
    $sqlLogdata["table"] = "logdata";
    $sqlLogdata["where"] = "";
    $sqlLogdata["logdata"] = "";
    $sqlLogdata["logdata_id_data"] = "";
    
//    echo $query."<br />";
    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Variable sqlLogDaten: ', $in_sqlDaten);                              //ToDo: Anpassen, wenn pro App mehr als eine Connection verwaltet werden soll.
    $result = db_connection_handler::insertOnDatabase($db_schema_manager_connection_id, $sqlLogdata, __FUNCTION__, true, $in_pagedate);		//Abfrage ausführen

    if ($result == FALSE) {return FALSE;} else {return TRUE;}
                                                                                                //FALSE oder TRUE zur�ckgeben
}



/**
 * Schreibt einen Debug-Datensatz in die Datenbank
 * @param   string  $in_connection_id       ID der zu nutzenden Connection
 * @param   String  $in_debug_type          Art des Debug-Datensatzes [INFO | ERROR]
 * @param   String  $in_debugtopic          Überschrift des Debug-Satzes
 * @param   String  $in_debugmessage        Inhalt der Debug-Meldung
 * @param   String  $in_starttime           einheitliche Startzeit des aktuellen Debug-Vorgangs für alle Debug-Meldungen, die zum selben Debug-Vorgang gehören.
 * @param   string  $in_context             Kennung, die in die Spalte debug.context geschrieben wird.
 * @return  boolean
 */
function insertDebugData($in_connection_id, $in_debug_type, $in_debugtopic, $in_debugmessage, $in_starttime, $in_context) {
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    
   
    $escaped_debugmessage = str_replace("'","''",$in_debugmessage ?? ''); 
    $escaped_debugtopic = str_replace("'","''",$in_debugtopic ?? ''); 
    
    
    $sqlDaten = array();
    $sqlDaten["into"] = "debug_time, debug_type, topic, message, start_time, context";
    $sqlDaten["values"] = "current_timestamp, '".$in_debug_type."', '".$escaped_debugtopic."', '".$escaped_debugmessage."', '".$in_starttime."', '".$in_context."'";
//    $sqlDaten["values"] = "current_timestamp, '".$in_debug_type."', '".$in_debugtopic."', '".$in_debugmessage."'";
    $sqlDaten["update"] = "";
    $sqlDaten["schema"] = $db_schema_manager;
    $sqlDaten["table"] = "debug";
    $sqlDaten["where"] = "";
    $sqlDaten["logdata"] = "";
    $sqlDaten["logdata_id_data"] = "";
    
    $result = db_connection_handler::insertOnDatabase($in_connection_id, $sqlDaten, __FUNCTION__, false);				//Abfrage ausführen

    if ($result == false) {return false;} else {return true;}
                                                                                                                                //FALSE oder TRUE zurückgeben
}



/** Ermittelt den höchsten Wert einer Spalte einer DB-Tabelle.
 * 
 * @param   string $in_connection_id    ID der connection, welche verwendet werden soll
 * @param   String $in_schema           DB-Schema
 * @param   String $in_table            DB-Tabelle
 * @param   String $in_id_col           DB-Spalte, deren Max-Wert ermittelt werden soll.
 * @param   String $in_condition        [optional]Bedingung, die in der Where-Bedingung eingefügt werden soll (Bsp.: app_id = 'SYS01')
 * @return  Boolean oder Integer        Wenn kein MAx-Wert ermittelt werden konnte, dann false, ansonsten der maximale Wert.
 */
function getMaxValue($in_connection_id, $in_schema, $in_table, $in_col, $in_condition = "") {
    
    $queryRequest = new sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
    $queryRequest->addSelectComplexStatement("max($in_col)", $in_schema.".".$in_table, $in_condition);
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, false, false);            //use_cache = False, da sonst zuletzt eingefügte Datensätze nicht erkannt werden.
//    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Ergebnis der Datenbankabfrage: getMaxValue', $result);
    
    if ($result <> false) {
        if(issetKeyLike($result[0], ".max")) {
            $feedback = $result[0][issetKeyLike($result[0], ".max")];
        } else {
            $feedback = false;
        }
        
    } else {
        $feedback = false;
    }

    return $feedback;																		//FALSE oder TRUE zur�ckgeben
}


/** Ermittelt alle Daten der Hilfe-Tabelle zu einer übergebenen Feld-ID
 * 
 * @param   integer $in_feldID          ID des Feldes, für das der Hilfetext angezeigt werden soll (feld.id)
 * @param   String  $in_feldAppID       App des Feldes, für das der Hilfetext angezeigt werden soll (feld.app_id)
 * @return  array                       eindimensional
 */
function getHilfe2($in_feldID, $in_feldAppID) {														
	
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
    $queryRequest->addSelectComplexStatement("(CONCAT(feld.app_id,feld.id)) as hilfe_id, feld.app_id as app_id, feld.id as feld_id, feld.helptext as hilfe_inhalt, feld.name, feld.max_zeichen",
                                            $db_schema_manager.".feld",
                                            "feld.id=".$in_feldID." AND feld.app_id = '".$in_feldAppID."'",
                                            "", 
                                            "feld.name");

    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);

    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Ergebnis der Datenbankabfrage: getHilfe2', $result);
    if ($result <> false) {
                                                                                                            //erste Zeile des Ergebnisses in ein Array �bertragen
        $fieldlist = array(
                "hilfe.id" => $result[0][".hilfe_id"],
                "hilfe.feld_id" => $result[0]["feld.feld_id"],
                "hilfe.inhalt" => $result[0]["feld.hilfe_inhalt"],
                "hilfe.name" => $result[0]["feld.name"],
                "hilfe.max_length" => $result[0]["feld.max_zeichen"]
        );

        return $fieldlist;
    }
    else {return array();}									

}



    /** Die Funktion  ermittelt die Abhängigkeiten zwischen zwei Formularen der selben Maske (siehe DB-Tabelle form_dependence, type like 'reference%'). 
     * Dabei muss das sendende Formular bzw. Triggerformular bekannt sein. Die abhängigen Formulare werden ermittelt.
     * Eine Abhängigkeit besteht bspw.  wenn Form B Details für einen markierten Datensatz in Form A zeigen soll. In dem Fall werden Daten des markierten Datensatz
     * als Filterkriterien für Form B genutzt.
     * 
     * @param   string      $in_mask_app_id                 APP der Maske
     * @param   integer     $in_mask_id                     ID der Maske
     * @param   integer     $in_source_form_id              ID des sendenden Formulars
     * @param   integer     $in_button_action_function_id   ID der aufgerufenen Funktion (Zwischen zwei Formularen können mehrere Abhängigkeiten bestehen, 
                                                            die aber je nach aufgerufener Funktion (Button) anders ausgestaltet sein können. 
                                                            default = 0 -> es wird keine Abhängigkeit ermittelt
                                                            "all" -> Abhängigkeiten werden unabhängig von dem Button ermittelt, jedoch nur vom Typ "reference"
     *                                                      "all_references -> Abhängigkeiten werden unabhängig von dem Button ermittelt, jedoch nur von Typen, die mit  "reference" beginnen
     * @return  array oder false                            array mit den Werten source_feld_id, source_feld_schema, source_feld_table, source_feld_column, target_feld_id, target_feld_id, target_feld_schema, target_feld_table, target_feld_column, fd.target_form_id, fd.dependence_type oder false
     */
    function getDependenceForForms($in_mask_app_id, $in_mask_id, $in_source_form_id, $in_button_action_function_id = 0) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

        if ($in_button_action_function_id == "") {
            $in_button_action_function_id = "AND form_dependence.button_action_function_id = 0";
        } elseif($in_button_action_function_id == "all") {
            $in_button_action_function_id = "AND form_dependence.dependence_type = 'reference'";
        } elseif($in_button_action_function_id == "all_references") {
            $in_button_action_function_id = "AND form_dependence.dependence_type like 'reference%'";
        } else {
            $in_button_action_function_id = "AND form_dependence.button_action_function_id = ".$in_button_action_function_id;
        }

        $selectPart =   "form_dependence.feld_id as source_feld_id
                        , source_form.db_schema as source_feld_schema
                        , source_form.db_table as source_feld_table
                        , source_feld.spalte as source_feld_column
                        , form_dependence.target_feld_id
                        , target_form.db_schema as target_feld_schema
                        , target_form.db_table as target_feld_table
                        , target_feld.spalte as target_feld_column
                        , form_dependence.target_form_id
                        , form_dependence.dependence_type";
        
        $fromPart =     "$db_schema_manager.form_dependence
                        , $db_schema_manager.feld as source_feld
                        , $db_schema_manager.form as source_form
                        , $db_schema_manager.feld as target_feld
                        , $db_schema_manager.form as target_form";

                    
        $wherePart =    "form_dependence.feld_app_id = source_feld.app_id
                        AND form_dependence.feld_id = source_feld.id
                        AND source_feld.form_app_id = source_form.app_id
                        AND source_feld.form_id = source_form.id
                        AND form_dependence.mask_app_id = target_feld.app_id
                        AND form_dependence.target_feld_id = target_feld.id
                        AND target_feld.form_app_id = target_form.app_id
                        AND target_feld.form_id = target_form.id
                        AND form_dependence.dependence_type like 'reference%'
                        AND form_dependence.mask_app_id = '$in_mask_app_id'
                        AND form_dependence.mask_id = $in_mask_id
                        AND form_dependence.form_id = $in_source_form_id
                        $in_button_action_function_id";

        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        $queryRequest->addSelectComplexStatement($selectPart, $fromPart, $wherePart);
        $formDependence = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        
        //Ergebnisarray überarbeiten, da nicht alle DBMS in der Ergebnismenge die table-aliases zurückgeben (bswp. postgres)
        //Das ist jedoch notwendig, damit die folgenden Funktionen auch DBMS-unabhängig funktionieren
        if (count($formDependence) > 0) {
            foreach ($formDependence as $key => $current_formDepedence) {
                $formDependence[$key]["form_dependence.source_feld_id"] = $current_formDepedence[issetKeyLike($current_formDepedence, "source_feld_id")];
                $formDependence[$key]["source_form.source_feld_schema"] = $current_formDepedence[issetKeyLike($current_formDepedence, "source_feld_schema")];
                $formDependence[$key]["source_form.source_feld_table"] = $current_formDepedence[issetKeyLike($current_formDepedence, "source_feld_table")];
                $formDependence[$key]["source_feld.source_feld_column"] = $current_formDepedence[issetKeyLike($current_formDepedence, "source_feld_column")];
                $formDependence[$key]["form_dependence.target_feld_id"] = $current_formDepedence[issetKeyLike($current_formDepedence, "target_feld_id")];
                $formDependence[$key]["target_form.target_feld_schema"] = $current_formDepedence[issetKeyLike($current_formDepedence, "target_feld_schema")];
                
                //Wenn in "target_feld_column" Tabellen- und Columnname enthalten sind, dann diese nutzen
                $temp_column = $current_formDepedence[issetKeyLike($current_formDepedence, "target_feld_column")];
                $temp_table = getTablenameFromTableAndColumn($temp_column);
                if($temp_table !== false) {
                    $formDependence[$key]["target_form.target_feld_table"] = $temp_table;
                    $formDependence[$key]["target_feld.target_feld_column"] = getColumnnameFromTableAndColumn($temp_column, false);
                } else {
                    $formDependence[$key]["target_form.target_feld_table"] = $current_formDepedence[issetKeyLike($current_formDepedence, "target_feld_table")];
                    $formDependence[$key]["target_feld.target_feld_column"] = $current_formDepedence[issetKeyLike($current_formDepedence, "target_feld_column")];
                }
                
                
                //Wenn in "source_feld_column" Tabellen- und Columnname enthalten sind, dann diese nutzen
                $temp_column = $current_formDepedence[issetKeyLike($current_formDepedence, "source_feld_column")];
                $temp_table = getTablenameFromTableAndColumn($temp_column);
                if($temp_table !== false) {
                    $formDependence[$key]["form.source_feld_table"] = $temp_table;
                    $formDependence[$key]["source_form.source_feld_table"] = $temp_table;
                    $formDependence[$key]["source_feld.source_feld_column"] = getColumnnameFromTableAndColumn($temp_column, false);
                } else {
                    $formDependence[$key]["source_form.source_feld_table"] = $current_formDepedence[issetKeyLike($current_formDepedence, "source_feld_table")];
                    $formDependence[$key]["source_feld.source_feld_column"] = $current_formDepedence[issetKeyLike($current_formDepedence, "source_feld_column")];
                }
                
                
                $formDependence[$key]["form_dependence.target_form_id"] = $current_formDepedence[issetKeyLike($current_formDepedence, "target_form_id")];
                $formDependence[$key]["form_dependence.dependence_type"] = $current_formDepedence[issetKeyLike($current_formDepedence, "dependence_type")];
            }
        } 
        return $formDependence;
    }
    
    
    
    



    
    /** Ermittelt für ein Triggerfeld alle abhängigen Felder.
     * 
     * @param   array   $in_TriggerField        Array mit den Werten "fieldAppID" und "fieldID" aus der Tabelle feld, bezogen auf das Trigger-Feld.
     * @return  array                           Zweidimensionales Array, in dem für jedes abhängige Feld die Werte "feld_app_id" und "feld_id" aus der Tabelle field_depends enthalten sind.
     */
    function getDependingFields($in_TriggerField) {
        
        $ergebnisList = array();
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

        $triggerfield_app_id = $in_TriggerField["fieldAppID"];
        $triggerfield_id = $in_TriggerField["fieldID"];
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("field_depends", "feld_app_id");
            $queryRequest->addSelectColumn("field_depends", "feld_id");
            $queryRequest->addSelectColumn("target_field", "spalte", "target_column");
            $queryRequest->addSelectColumn("trigger_field", "spalte", "trigger_column");

            $queryRequest->addTable($db_schema_manager, "field_depends", 1, "BASE", "");
            $queryRequest->addTable($db_schema_manager, "feld", 2, "INNER", "target_field");
            $queryRequest->addTable($db_schema_manager, "feld", 3, "INNER", "trigger_field");

            $queryRequest->addWhereCondition("AND", "", "field_depends", "depends_from_feld_app_id", "=", "'".$triggerfield_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "field_depends", "depends_from_feld_id", "=", $triggerfield_id, "");
            $queryRequest->addWhereCondition("AND", "", "target_field", "app_id", "=", "field_depends.feld_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "target_field", "id", "=", "field_depends.feld_id", "");
            $queryRequest->addWhereCondition("AND", "", "trigger_field", "app_id", "=", "field_depends.depends_from_feld_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "trigger_field", "id", "=", "field_depends.depends_from_feld_id", "");

        $tableData = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
            

        if (count($tableData) > 0) {
            $ergebnisList = $tableData;

        }  
            
        return $ergebnisList;
    }
    
    
    
    
    /** Ermittelt für ein Triggerfeld alle Felder, die den Wert des Triggerfields als Connection-ID nutzen.
     * 
     * @param   array   $in_TriggerField        Array mit den Werten "fieldAppID" und "fieldID" aus der Tabelle feld, bezogen auf das Trigger-Feld.
     * @return  array oder false                Zweidimensionales Array, in dem für jedes abhängige Feld die Werte "feld_app_id" und "feld_id" aus der Tabelle field_depends enthalten sind.
     */
    function getDependingFields2($in_TriggerField) {
        
        $ergebnisList = array();
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

        $triggerfield_app_id = $in_TriggerField["fieldAppID"];
        $triggerfield_id = $in_TriggerField["fieldID"];
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("target_field", "app_id", "feld_app_id");
            $queryRequest->addSelectColumn("target_field", "id", "feld_id");
            $queryRequest->addSelectColumn("target_field", "spalte", "target_column");
            $queryRequest->addSelectColumn("trigger_field", "spalte", "trigger_column");

            $queryRequest->addTable($db_schema_manager, "feld", 1, "BASE", "target_field");
            $queryRequest->addTable($db_schema_manager, "feld", 2, "INNER", "trigger_field");

            $queryRequest->addWhereCondition("AND", "", "trigger_field", "app_id", "=", "'".$triggerfield_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "trigger_field", "id", "=", $triggerfield_id, "");
            $queryRequest->addWhereCondition("AND", "", "target_field", "form_app_id", "=", "trigger_field.form_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "target_field", "form_id", "=", "trigger_field.form_id", "");
            $queryRequest->addWhereCondition("AND", "", "target_field", "query_ref_field_connection_id", "=", "trigger_field.id", "");
            
        $tableData = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
            

        if (count($tableData) > 0) {
            //Ergebnissignatur an getDependingFields anpassen
            $i = 0;
            $feedback = array();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> result: ', $tableData);
            foreach ($tableData as $row) {
                $feedback[$i]["field_depends.feld_app_id"] = $row["feld.feld_app_id"];
                $feedback[$i]["field_depends.feld_id"] = $row["feld.feld_id"];
                $feedback[$i]["feld.target_column"] = $row["feld.target_column"];
                $feedback[$i]["feld.trigger_column"] = $row["feld.trigger_column"];
                $feedback[$i]["depending_reason"] = "changed connection_id";
                $i = $i + 1;
            }    
            $ergebnisList = $feedback;

        } 
        
        return $ergebnisList;
    }
    
    
    
    /** Ermittelt für eine gegebene App-ID alle Felder und deren Triggerfields
     * 
     * @param   string  $in_app_id                          App-ID deren Felder und Triggerfelder ermittelt werden soll. 
     * @return  array                                       Liste aller TriggerFields pro Field_ID; Bsp.: Array([396] => 2203, [411] => 412, 89, [608] => 599, [1284] => 1269, 1255, 1260)
     */
    function getTriggerFields($in_app_id) {
        
        $field_list = array();
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("field_depends", "feld_id");
            $queryRequest->addSelectColumn("field_depends", "depends_from_feld_id");
            $queryRequest->addTable($db_schema_manager, "field_depends", 1, "BASE", "");
            $queryRequest->addWhereCondition("AND", "", "field_depends", "feld_app_id", "=", "'".$in_app_id."'", "");
            $queryRequest->addOrderbyPart("field_depends.feld_id"); 
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
            

        if (count($result) > 0) {
            $field_list = changeMultiArrayToSingleArray($result, "field_depends.feld_id", "field_depends.depends_from_feld_id");
        } 	
        return $field_list;
    }

    
    
    
    /** Ermittelt für eine gegebene App-ID alle Felder die von einem anderen Feld abhängig sind und deren targets.
     * Targets sind Datenbankspalten, die zur Einschränkung eines SQL-befehls herangezogen werden.
     * 
     * 
     * @param   string  $in_app_id                          App-ID deren Felder und Triggerfelder ermittelt werden soll. 
     * @return  string                                      Liste aller targets pro Field_ID; Bsp.: Array([396] => account.app_id, [411] => directory.app_id, account_has_role.account_id)
     */
    function getDependsfieldTarget($in_app_id) {
        
        $field_list = array();
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("field_depends", "feld_id");
            $queryRequest->addSelectColumn("field_depends", "dependsfield_target");
            $queryRequest->addTable($db_schema_manager, "field_depends", 1, "BASE", "");
            $queryRequest->addWhereCondition("AND", "", "field_depends", "feld_app_id", "=", "'".$in_app_id."'", "");
            $queryRequest->addOrderbyPart("field_depends.feld_id"); 
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
            

        if (count($result) > 0) {
            $field_list = changeMultiArrayToSingleArray($result, "field_depends.feld_id", "field_depends.dependsfield_target");
        } 	
        return $field_list;
    }
    
    
    
    
    
    /** Ermittelt für eine gegebene App-ID alle TargetFelder und deren auslösende Felder.
     * Diese Funktion ist als Gegenstück zu getTriggerFields zu sehen.
     * 
     * @param   string  $in_app_id                          App-ID deren Felder und Triggerfelder ermittelt werden soll. 
     * @return  string                                      Liste aller targets pro Field_ID; Bsp.: Array([396] => account.app_id, [411] => directory.app_id, account_has_role.account_id)
     */
    function getTargetFields($in_app_id) {
        
        $field_list = array();
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("field_depends", "depends_from_feld_id");
            $queryRequest->addSelectColumn("field_depends", "feld_id");
            $queryRequest->addTable($db_schema_manager, "field_depends", 1, "BASE", "");
            $queryRequest->addWhereCondition("AND", "", "field_depends", "feld_app_id", "=", "'".$in_app_id."'", "");
            $queryRequest->addOrderbyPart("field_depends.depends_from_feld_id"); 
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
            

        if (count($result) > 0) {
            $field_list = changeMultiArrayToSingleArray($result, "field_depends.depends_from_feld_id", "field_depends.feld_id");
        } 	
        return $field_list;
    }
    
    
    
    
    /** Ermittelt für ein gegebenes [Trigger]Formular alle abhängigen Formulare.
     * 
     * 
     * @param   string  $in_form_app_id                     App-ID des Triggerformulars
     * @param   integer $in_form_id                         ID des Triggerformulars
     * @return  array                                       zweidimensionale Liste aller abhängigen Formulare 
     * 
     * Bsp. return:
     * Array
            (
                [0] => Array
                    (
                        [form_dependence.feld_app_id] => SYS01
                        [form_dependence.feld_id] => 198
                        [form_dependence.button_action_function_app_id] => SYS01
                        [form_dependence.button_action_function_id] => 9
                        [form_dependence.target_form_id] => 10
                    )

                [1] => Array
                    (
                        [form_dependence.feld_app_id] => SYS01
                        [form_dependence.feld_id] => 405
                        [form_dependence.button_action_function_app_id] => SYS01
                        [form_dependence.button_action_function_id] => 9
                        [form_dependence.target_form_id] => 10
                    )

                [2] => Array
                    (
                        [form_dependence.feld_app_id] => SYS01
                        [form_dependence.feld_id] => 405
                        [form_dependence.button_action_function_app_id] => SYS01
                        [form_dependence.button_action_function_id] => 9
                        [form_dependence.target_form_id] => 10
                    )
     */
    function getTargetForms($in_form_app_id, $in_form_id) {

        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("form_dependence", "feld_app_id");
            $queryRequest->addSelectColumn("form_dependence", "feld_id");
            $queryRequest->addSelectColumn("form_dependence", "button_action_function_app_id");
            $queryRequest->addSelectColumn("form_dependence", "button_action_function_id");
            $queryRequest->addSelectColumn("form_dependence", "target_form_id");
            $queryRequest->addTable($db_schema_manager, "form_dependence", 1, "BASE", "");
            $queryRequest->addWhereCondition("AND", "", "form_dependence", "form_app_id", "=", "'".$in_form_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "form_dependence", "form_id", "=", "'".$in_form_id."'", "");
            $queryRequest->addOrderbyPart("form_dependence.feld_id"); 
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
	
        if ($result <> false) {
            return $result;
        } else {
            return array();
        }
    }
    
    
    
    
    /** Gibt eine Liste der Formulare, welche eine htmltaggroup enthält zurück.
     * 
     * @param   string  $in_htmltaggroup_app_id             APP-ID der htmltaggroup
     * @param   int     $in_htmltaggroup_id                 ID der htmltaggroup
     * @return  array                                       Zweidimensionales array
     */
    function getFormsFromHtmltaggroup($in_htmltaggroup_app_id, $in_htmltaggroup_id) {

        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("html_tag", "form_app_id");
            $queryRequest->addSelectColumn("html_tag", "form_id");
       
            $queryRequest->addTable($db_schema_manager, "htmltaggroup_has_html_tag", 1, "BASE", "");
            $queryRequest->addTable($db_schema_manager, "html_tag", 2, "INNER", "");
            
            $queryRequest->addWhereCondition("AND", "", "html_tag", "id", "=", "htmltaggroup_has_html_tag.html_tag_id", "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "app_id", "=", "htmltaggroup_has_html_tag.html_tag_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup_has_html_tag", "htmltaggroup_app_id", "=", "'".$in_htmltaggroup_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup_has_html_tag", "htmltaggroup_id", "=", $in_htmltaggroup_id, "");
            
            $queryRequest->addGroupbyPart("html_tag.form_app_id, html_tag.form_id");
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
	
        if ($result <> false) {
            return $result;
        } else {
            return array();
        }
    }
    
    
    
    
    /** Liest für die aktive Rolle die Zugriffsrechte auf die gewünschte Amske aus der Tabelle role_has_mask aus.
     * 
     * @param   string      $in_mask_app_id         APP-ID der Maske, auf die zugegriffen werden soll
     * @param   integer     $in_mask_id             ID der Maske, auf die zugegeriffen werden soll
     * @return  array                               Lsite der Zugriffsrechte. I.d.R. dürfte dieses Array nur einen Datensatz haben. 
     *                                              Wenn das Array keinen Datensatz hat, besteht kein Zugriff und theoretisch muss ein Maipulationsversuch vorliegen, 
     *                                              da der aktive Nutzer die Maske nicht hätte erreichen können.
     */
    function getAccessToMaskByActiveRole($in_mask_app_id, $in_mask_id) {

        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $connection_id = global_variables::getAppIdFromSYS01();
        
        $role_app_id = getActiveRoleData()["role.app_id"];
        $role_id = getActiveRoleData()["role.id"];
        
        $queryRequest = new sql_request($connection_id, $role_app_id,$role_id, __FUNCTION__);
            $queryRequest->addSelectColumn("role_has_mask", "access_insert");
            $queryRequest->addSelectColumn("role_has_mask", "access_update");
            $queryRequest->addSelectColumn("role_has_mask", "access_delete");
            $queryRequest->addTable($db_schema_manager, "role_has_mask", 1, "BASE", "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask", "mask_app_id", "=", "'".$in_mask_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask", "mask_id", "=", $in_mask_id, "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask", "role_app_id", "=", "'".$role_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask", "role_id", "=", $role_id, "");
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
	
        if ($result <> false) {
            return $result;
        } else {
            return array();
        }
    }
    
    
    
     /** Ermittelt eine Liste aller Formulare, die einer Maske zugeordnet sind (außer Symbolleisten).
      * ToDo: beachte bei Anpassungen auch getTaglistFromMask
     * 
     * @param   string  $in_mask_app_id         APP einer Maske (Bsp.: SYS01)
     * @param   integer $in_mask_id             ID einer Maske
     * @return  array oder false                false, wenn kein Formular der Maske zugeordnet ist, ansonsten ein zweidimensionales Feld. 1. Dimension = lfd. Nr. 2. Dimension = array mit fom_app_id, form_id und htmltaggroup_has_html_tag.relationtyp
     */
    function getFormList($in_mask_app_id, $in_mask_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        $default_dummy_form_id = global_variables::getDefaultDummyFormId();

        $role_id = session_class::$session_object->getActiveRoleId();
        $role_app_id = session_class::$session_object->getActiveRoleAppId();


        $selectPart =   "html_tag.form_app_id 
                        , html_tag.form_id
                        , htmltaggroup_has_html_tag.relationtyp";
        
        $fromPart =     "$db_schema_manager.mask 
                        , $db_schema_manager.mask_has_htmltaggroup 
                        , $db_schema_manager.htmltaggroup 
                        , $db_schema_manager.htmltaggroup_has_html_tag 
                        , $db_schema_manager.html_tag 
                            LEFT JOIN $db_schema_manager.form_group_has_form ON form_group_has_form.form_id = html_tag.form_id AND form_group_has_form.form_app_id = html_tag.form_app_id
                            LEFT JOIN $db_schema_manager.form_group ON form_group.app_id = form_group_has_form.form_group_app_id AND form_group.id = form_group_has_form.form_group_id
                            LEFT JOIN $db_schema_manager.role_has_form_group ON form_group.app_id = role_has_form_group.form_group_app_id AND form_group.id = role_has_form_group.form_group_id AND
                                role_has_form_group.role_app_id = '$role_app_id' AND role_has_form_group.role_id = $role_id ";    ;
                    
        $wherePart =    "mask.app_id = mask_has_htmltaggroup.mask_app_id
                        AND mask.id = mask_has_htmltaggroup.mask_id
                        AND mask_has_htmltaggroup.htmltaggroup_app_id = htmltaggroup.app_id
                        AND mask_has_htmltaggroup.htmltaggroup_id = htmltaggroup.id 
                        AND htmltaggroup.id = htmltaggroup_has_html_tag.htmltaggroup_id 
                        AND htmltaggroup.app_id = htmltaggroup_has_html_tag.htmltaggroup_app_id 
                        AND html_tag.id = htmltaggroup_has_html_tag.html_tag_id 
                        AND html_tag.app_id = htmltaggroup_has_html_tag.html_tag_app_id 
                        AND html_tag.form_id != $default_dummy_form_id  
                        AND htmltaggroup_has_html_tag.active in (1,2)  
                        AND mask_app_id = '$in_mask_app_id'
                        AND mask_id = $in_mask_id 
                        AND (role_has_form_group.access_type <> 0 OR role_has_form_group.access_type is null)";
        
        $orderbyPart =  "htmltaggroup_has_html_tag.sort";

        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        $queryRequest->addSelectComplexStatement($selectPart, $fromPart, $wherePart, "", $orderbyPart);
        $formList = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);

        return $formList;
    }
    
    
    
    
    
    /** Liefert eine Liste der htmlgroups (Maskenelemente) einer Maske, die ein Formular enthalten.
     * 
     * @param   string  $in_mask_app_id         APP-ID der Maske
     * @param   int     $in_mask_id             ID der Msske
     * @param   string  $in_condition_for_name  Ein beliebiger String, der als like-Condition für das Feld htmltaggroup.name verwendet wird. <br />
     *                                          Bsp.: wenn der Wert "für Seite" übergeben wird, wird dies zur Where-Bedingung "htmltaggroup.name like '%für Seite%'" umgeformt.
     * @return  mixed                           Mehrdimensionales Ergebnisarray: array(0 => array(htmltaggroup_has_html_tag.htmltaggroup_id => 333, htmltaggroup_has_html_tag.htmltaggroup_app_id => CMS11), 1 => ...)
     * 
     */
    function getHtmltaggroupFromMask($in_mask_app_id, $in_mask_id, $in_condition_for_name) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $connection_id = global_variables::getAppIdFromSYS01();
        
        $role_app_id = getActiveRoleData()["role.app_id"];
        $role_id = getActiveRoleData()["role.id"];
        
        $queryRequest = new sql_request($connection_id, $role_app_id,$role_id, __FUNCTION__);
            $queryRequest->addSelectColumn("htmltaggroup_has_html_tag", "htmltaggroup_id");
            $queryRequest->addSelectColumn("htmltaggroup_has_html_tag", "htmltaggroup_app_id");
            
            $queryRequest->addTable($db_schema_manager, "htmltaggroup_has_html_tag", 1, "BASE", "");
            $queryRequest->addTable($db_schema_manager, "htmltaggroup", 2, "INNER", "");
            $queryRequest->addTable($db_schema_manager, "mask_has_htmltaggroup", 3, "INNER", "");
            
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "htmltaggroup_id", "=", "htmltaggroup.id", "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "htmltaggroup_app_id", "=", "htmltaggroup.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "id", "=", "htmltaggroup_has_html_tag.htmltaggroup_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "app_id", "=", "htmltaggroup_has_html_tag.htmltaggroup_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "name", "like", "'%".$in_condition_for_name."%'", "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "mask_app_id", "=", "'".$in_mask_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "mask_id", "=", $in_mask_id, "");
            
            $queryRequest->addGroupbyPart("htmltaggroup_has_html_tag.htmltaggroup_app_id, htmltaggroup_has_html_tag.htmltaggroup_id");
            
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        return $result;
    }
    
    
    /** Liefert eine Liste der htmlgroups (Maskenelemente) einer Maske. Dabei werden auch Elemente geliefert, die auch auf anderen Masken
     * verwendet werden könnten, wie beispielsweise das Grundgerüst. Nicht jedoch Symbolleisten.
     * Mit Hilfe dieser Funktion kann die htmltaggroup ermittelt werden, welche zur Aufnahme der Formulare gedacht ist,
     * auch wenn die Maske noch keine Formulare enthält.
     * Mit Hilfe des Parameters, kann die Treffermenge sinnvoll eingeschränkt werden. 
     * 
     * @param   string  $in_mask_app_id         APP-ID der Maske
     * @param   int     $in_mask_id             ID der Msske
     * @param   string  $in_condition_for_name  Ein beliebiger String, der als like-Condition für das Feld htmltaggroup.name verwendet wird. <br />
     *                                          Bsp.: wenn der Wert "MEGruppe Seite" übergeben wird, wird dies zur Where-Bedingung "htmltaggroup.name like '%MEGruppe Seite%'" umgeformt.
     * @return  mixed                           Mehrdimensionales Ergebnisarray: array(0 => array(htmltaggroup_has_html_tag.htmltaggroup_id => 333, htmltaggroup_has_html_tag.htmltaggroup_app_id => CMS11), 1 => ...)
     * 
     */
    function getHtmltaggroupFromMask2($in_mask_app_id, $in_mask_id, $in_condition_for_name) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $connection_id = global_variables::getAppIdFromSYS01();
        
        $role_app_id = getActiveRoleData()["role.app_id"];
        $role_id = getActiveRoleData()["role.id"];
        
        $queryRequest = new sql_request($connection_id, $role_app_id,$role_id, __FUNCTION__);
            $queryRequest->addSelectColumn("htmltaggroup", "id");
            $queryRequest->addSelectColumn("htmltaggroup", "app_id");
            
            $queryRequest->addTable($db_schema_manager, "mask_has_htmltaggroup", 1, "BASE", "");
            $queryRequest->addTable($db_schema_manager, "htmltaggroup", 2, "INNER", "");
            
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "id", "=", "mask_has_htmltaggroup.htmltaggroup_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "app_id", "=", "mask_has_htmltaggroup.htmltaggroup_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "name", "like", "'%".$in_condition_for_name."%'", "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "mask_app_id", "=", "'".$in_mask_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "mask_id", "=", $in_mask_id, "");
            
            $queryRequest->addGroupbyPart("htmltaggroup.app_id, htmltaggroup.id");
            
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        return $result;
    }
    
    
    
    /** Liefert die htmltaggroup eines bestimmten Formulars auf einer spezifischen Maske
     * 
     * @param   string  $in_mask_app_id     APP-ID der Maske
     * @param   int     $in_mask_id         ID der Maske
     * @param   string  $in_form_app_id     APP-ID des Formulars
     * @param   int     $in_form_id         ID des Formulars
     * @return  mixed                           Mehrdimensionales Ergebnisarray: array(0 => array(htmltaggroup_has_html_tag.htmltaggroup_id => 333, htmltaggroup_has_html_tag.htmltaggroup_app_id => CMS!!), 1 => ...)
     */
    function getHtmltaggroupFromMaskAndForm($in_mask_app_id, $in_mask_id, $in_form_app_id, $in_form_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $connection_id = global_variables::getAppIdFromSYS01();
        
        $role_app_id = getActiveRoleData()["role.app_id"];
        $role_id = getActiveRoleData()["role.id"];
        
        $queryRequest = new sql_request($connection_id, $role_app_id,$role_id, __FUNCTION__);
            $queryRequest->addSelectColumn("htmltaggroup_has_html_tag", "htmltaggroup_id");
            $queryRequest->addSelectColumn("htmltaggroup_has_html_tag", "htmltaggroup_app_id");
            
            $queryRequest->addTable($db_schema_manager, "htmltaggroup_has_html_tag", 1, "BASE", "");
            $queryRequest->addTable($db_schema_manager, "htmltaggroup", 2, "INNER", "");
            $queryRequest->addTable($db_schema_manager, "mask_has_htmltaggroup", 3, "INNER", "");
            $queryRequest->addTable($db_schema_manager, "html_tag", 4, "INNER", "");
            
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "htmltaggroup_id", "=", "htmltaggroup.id", "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "htmltaggroup_app_id", "=", "htmltaggroup.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "id", "=", "htmltaggroup_has_html_tag.htmltaggroup_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "app_id", "=", "htmltaggroup_has_html_tag.htmltaggroup_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "mask_app_id", "=", "'".$in_mask_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "mask_id", "=", $in_mask_id, "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "app_id", "=", "htmltaggroup_has_html_tag.html_tag_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "id", "=", "htmltaggroup_has_html_tag.html_tag_id", "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "form_app_id", "=", "'".$in_form_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "form_id", "=", $in_form_id, "");
            
            
            
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        if ($result <> false) {
            //Ergebnissignatur an getHtmltaggroupFromMask2 anpassen
            $i = 0;
            foreach ($result as $row) {
                $feedback[$i]["htmltaggroup.id"] = $row["htmltaggroup_has_html_tag.htmltaggroup_id"];
                $feedback[$i]["htmltaggroup.app_id"] = $row["htmltaggroup_has_html_tag.htmltaggroup_app_id"];
                $i = $i + 1;
            }    
        } else {
            //Ergebnissatz hat 0 Zeilen
            $feedback = $result;
        }
        
        return $feedback;
    }
    
    
    
    
    /** Ermittelt die htmlgroup (app_id und id), in dem die gegebene Symbolleiste eingebettet ist.
     * Symbolleiste sind, technisch gesehen, Formulare. Diese Abfrage ist dennoch nur für Symbolleisten verwendbar.
     * Es werden die Tabellen htmltaggroup, htmltaggroup_has_html_tag und html_tag per INNER JOIN miteinander verknüpft.
     * Wenn Symbolleisten gelöscht wurden, kann die htmlgroup weiterhin existieren. Diese Abfrage liefert dann dennoch false.
     * In Verbindung mit der Methode getSymbolgropusFromHtmltagGroup kann geprüft werden, ob die selbe htmltaggroup von mehreren 
     * Symbolleisten genutzt wird.
     * 
     * 
     * @param   string  $in_app_id      APP-ID der Symbolleiste
     * @param   integer $in_form_id     ID der Symbolleiste
     * @return  mixed                   Array, wenn htmlgroup und Symbolleiste existieren, ansonsten false. array("htmltaggroup.id", "htmltaggroup.app_id")
     */
    function getHtmltaggroupFromSymbolgroup($in_app_id, $in_form_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $connection_id = global_variables::getAppIdFromSYS01();
        
        $role_app_id = getActiveRoleData()["role.app_id"];
        $role_id = getActiveRoleData()["role.id"];
        
        $queryRequest = new sql_request($connection_id, $role_app_id,$role_id, __FUNCTION__);
            $queryRequest->addSelectColumn("htmltaggroup", "id");
            $queryRequest->addSelectColumn("htmltaggroup", "app_id");
            
            $queryRequest->addTable($db_schema_manager, "htmltaggroup", 1, "BASE", "");
            $queryRequest->addTable($db_schema_manager, "htmltaggroup_has_html_tag", 2, "INNER", "");
            $queryRequest->addTable($db_schema_manager, "html_tag", 3, "INNER", "");
            
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup_has_html_tag", "htmltaggroup_app_id", "=", "htmltaggroup.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup_has_html_tag", "htmltaggroup_id", "=", "htmltaggroup.id", "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "id", "=", "htmltaggroup_has_html_tag.html_tag_id", "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "app_id", "=", "htmltaggroup_has_html_tag.html_tag_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "is_symbolgroup", "=", 1, "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "form_app_id", "=", "'".$in_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "form_id", "=", $in_form_id, "");
            
            
            
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        
        return $result;
    }
    
    
    /** Ermittelt alle Symbolleisten, die einer htmltaggroup zugeordnet sind.
     * Symbolleiste sind, technisch gesehen, Formulare. Diese Abfrage ist dennoch nur für Symbolleisten verwendbar.
     * Es werden die Tabellen htmltaggroup, htmltaggroup_has_html_tag und html_tag per INNER JOIN miteinander verknüpft.
     * Wenn eine Symbolleiste gelöscht wurde, kann die htmltaggroup weiterhin existieren. Diese Abfrage liefert false, wenn die
     * htmltaggroup keine Formulare enthält. Ansonsten wird die Liste der Formulare zurückgegeben.
     * 
     * 
     * 
     * @param   string  $in_app_id              APP-ID der htmltaggroup
     * @param   integer $in_htmltaggroup_id     ID der htmltaggroup
     * @return  mixed                           Array oder false, wenn ein SQL-Fehler aufgetreten ist. array("html_tag.form_id", "html_tag.form_app_id")
     */
    function getSymbolgropusFromHtmltagGroup($in_app_id, $in_htmltaggroup_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $connection_id = global_variables::getAppIdFromSYS01();
        
        $role_app_id = getActiveRoleData()["role.app_id"];
        $role_id = getActiveRoleData()["role.id"];
        
        $queryRequest = new sql_request($connection_id, $role_app_id,$role_id, __FUNCTION__);
            $queryRequest->addSelectColumn("html_tag", "form_id");
            $queryRequest->addSelectColumn("html_tag", "form_app_id");
            
            $queryRequest->addTable($db_schema_manager, "htmltaggroup", 1, "BASE", "");
            $queryRequest->addTable($db_schema_manager, "htmltaggroup_has_html_tag", 2, "INNER", "");
            $queryRequest->addTable($db_schema_manager, "html_tag", 3, "INNER", "");
            
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup_has_html_tag", "htmltaggroup_app_id", "=", "htmltaggroup.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup_has_html_tag", "htmltaggroup_id", "=", "htmltaggroup.id", "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "id", "=", "htmltaggroup_has_html_tag.html_tag_id", "");
            $queryRequest->addWhereCondition("AND", "", "html_tag", "app_id", "=", "htmltaggroup_has_html_tag.html_tag_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "is_symbolgroup", "=", 1, "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "app_id", "=", "'".$in_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "id", "=", $in_htmltaggroup_id, "");
            
            
            
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        
        
        return $result;
    }
    
    
    
    
    
    /** Löscht einen Datensatz aus der Tabelle htmltaggroup.
     * 
     * @param   integer     $in_id          ID der htmltaggroup
     * @param   string      $in_app_id      APP-ID der htmltaggroup
     * @param   string      $in_account_id  ID des Accounts, welcher die Löschung ausführt
     * @param   object      $in_pagedata    Referenz zum pagedata-Objekt
     * @return  integer                      siehe Konstantentyp_id = 35; alle Feedbackmeldungen des 3er-Bereichs 
 *                                           3   => erfolgreich gelöscht
 *                                          -3  => nicht gelöscht (SQL-Fehler)
 *                                          -31 => Zugriffsrecht für aktive Rolle und aktuelle Maske nicht gegeben.
 *                                          ...     
     */
    function deleteHtmltaggroup($in_id, $in_app_id, $in_account_id, &$in_pagedata) {
        $schema_kernel = global_variables::getNameOfDbSchemaSYS01();
        $feedback = 3;

        //SQL-Array für Löschbefehl aufbauen
        $sql_daten["schema"] = $schema_kernel;
        $sql_daten["table"] = "htmltaggroup";
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();
        
        $sql_daten["where"] = "id=".$in_id." AND app_id = '".$in_app_id."'";
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> sql_daten für delete', $sql_daten);
        $feedback = deleteData($sql_daten, $dummy_form, $in_account_id, $in_pagedata);


        return $feedback;
    }
    
    
    
    
     /** ermittelt für eine übergebene Funktions-ID den Funktions- und den Klassennamen. 
     * 
     * @param   Integer $in_functionID          ID der Funktion (siehe Tabelle button_action_function
     * @param   String  $in_functionAppID       APP der Funktion (siehe Tabelle button_action_function
     * @return  Array oder Boolean              Gibt ein Array mit zwei Werten zurück. Der erste enthält den Funktionsnamen, der zweite enthält den Klassennamen. 
     *                                          Wenn kein Ergebnis ermittelt werden konnte, wird FALSE zurückgegeben.
     */
    function getFunctionNameAndClass($in_functionID, $in_functionAppID) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

        if (!is_numeric($in_functionID)) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Funktions-ID?: '.$in_functionID, "Es wurde der Funktion getFunctionNameAndClass keine Funktion-ID übergeben. Falls der Aufruf über eine Schaltfläche erfolgte, prüfen Sie, ob diese in der Tabelle feld richtig konfiguriert wurde.", "ERROR");
            $functionData = FALSE;

        } else {


            $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
                $queryRequest->addSelectColumn("button_action_function", "*");
                
                $queryRequest->addTable($db_schema_manager, "button_action_function", 1, "BASE");
                
                $queryRequest->addWhereCondition("AND", "", "button_action_function", "id", "=", $in_functionID, "");
                $queryRequest->addWhereCondition("AND", "", "button_action_function", "app_id", "=", "'".$in_functionAppID."'", "");
                
            $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);

            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> SQL-Rückgabe ($queryResult): ', $queryResult);

            
            
            if ($queryResult <> FALSE) {	
                $functionData = Array();
                $functionData["classname"] = $queryResult[0] ["button_action_function.name"];             //aus dem ersten Datensatz wird der Klassenname übernommen
                $functionData["functionname"] = $queryResult[0] ["button_action_function.function_php"];         //aus dem ersten Datensatz wird der Funktionsname übernommen
                //theoretisch kann es nur noch einen Ergebnisdatensatz geben. Bis zum 07.10.2018 wurde auch eine "Sub-Tabelle" (function_params abgefragt, dadurch konnte es mehrere Datensätze geben.
            } else {
                $functionData = FALSE;
            }	
        }
        return $functionData;
    }
    
    
    
    
    /**
     * Ermittelt den Klartext für eine Feedback_id aus der Konstantentabelle für die Konstantentyp_id 35.
     * 
     * @param   string  $in_feedback        Feedback-ID, deren Klartext ermittelt werden soll (Bsp. -1, 1, -2, 2, -3, 2)
     * @param   string  $in_function_app_id Die App-ID der Konstante
     * @return  array                       Zweidimensionales: array{0=>Array{klartext, app_id}}
     */
    function getFeedbacktextForFunction($in_feedback, $in_function_app_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        $kernel_app_id = global_variables::getAppIdFromSYS01();
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> User-Function-Feedback-ID and APP: ', $in_feedback.", ".$in_function_app_id,"INFO");
         
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("konstante", "klartext");
            $queryRequest->addSelectColumn("konstante", "app_id");

            $queryRequest->addTable($db_schema_manager, "konstante", 1, "BASE");

            $queryRequest->addWhereCondition("AND", "", "konstante", "konstantentyp_app_id", "=", "'".$kernel_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "konstante", "konstantentyp_id", "=", 35, "");
            $queryRequest->addWhereCondition("AND", "", "konstante", "gueltig_ab", "<=", "current_date", "");
            $queryRequest->addWhereCondition("AND", "", "konstante", "gueltig_bis", ">", "current_date", "");
            $queryRequest->addWhereCondition("AND", "", "konstante", "wert", "=", "'".$in_feedback."'", "");
            $queryRequest->addWhereCondition("AND", "", "konstante", "app_id", "=", "'".$in_function_app_id."'", "");

        
        $feedbackarray = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        
       
        
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> User-Feedback-Array: ', $feedbackarray,"INFO");
        
        if ($feedbackarray == false OR count($feedbackarray) == 0) {
             //Falls kein Ergebnis ermittelt werden konnte, und aktuell der Text nicht in der Kernel-APP gesucht wurde, wird erneut versucht in der Kernel-APP einen Feedbacktext zu ermitteln
            if($in_function_app_id !== $kernel_app_id) {
                $feedbackarray = getFeedbacktextForFunction($in_feedback, $kernel_app_id);
            } else {
                $feedbackarray =array("0" => array("konstante.klartext" => "", "konstante.app_id" => $kernel_app_id));
            }
            
        }
        
        
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> User-Feedback-Array: ', $feedbackarray,"INFO");
        
        return $feedbackarray;
        
    }
    
    
    
    
    
    
    
    /** Ermittelt die Attribute, welche den HTML-Elementen hinzugefügt werden müssen, die auf der aktuellen Maske verwendet werden.
     * 
     * @param   Integer     $in_maskId          ID der Maske, die aufgerufen wurde.
     * @param   String      $in_maskAppId       APP zu der die Maske gehört
     * @return  Variabel                        zweidimensionales Array (Attributliste) oder false    
     */
    function getHtmlAttributListFromMask($in_maskId, $in_maskAppId) {														
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();


        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("html_tag",      "id");
            $queryRequest->addSelectColumn("html_tag",      "name",     "tag_name");
            $queryRequest->addSelectColumn("html_attribut", "name",     "attribut_name");
            $queryRequest->addSelectColumn("html_attribut", "value",    "attribut_value");
            $queryRequest->addSelectColumn("html_tag",      "app_id");

            $queryRequest->addTable($db_schema_manager, "mask_has_htmltaggroup", 1, "BASE");
            $queryRequest->addTable($db_schema_manager, "html_attribut", 2, "INNER");
            $queryRequest->addTable($db_schema_manager, "html_tag", 3, "INNER");
            $queryRequest->addTable($db_schema_manager, "htmltaggroup_has_html_tag", 4, "INNER");

            $queryRequest->addWhereCondition("AND",    "", "mask_has_htmltaggroup",        "htmltaggroup_id",      "=", "htmltaggroup_has_html_tag.htmltaggroup_id",       "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup",        "htmltaggroup_app_id",  "=", "htmltaggroup_has_html_tag.htmltaggroup_app_id",   "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup_has_html_tag",    "html_tag_id",          "=", "html_tag.id",                                     "");
            $queryRequest->addWhereCondition("AND", "", "htmltaggroup_has_html_tag",    "html_tag_app_id",      "=", "html_tag.app_id",                                 "");
            $queryRequest->addWhereCondition("AND", "", "html_tag",                     "id",                   "=", "html_attribut.html_tag_id",                       "");
            $queryRequest->addWhereCondition("AND", "", "html_tag",                     "app_id",               "=", "html_attribut.html_tag_app_id",                   "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup",        "mask_id",              "=", $in_maskId,                                        "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup",        "mask_app_id",          "=", "'".$in_maskAppId."'",                             "");

            $queryRequest->addOrderbyPart("html_tag.id");
        
        
        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
        addToDebug(__FILE__." Zeile ".__LINE__." -> ".__FUNCTION__." -> SQL-Befehl für Html-Attributliste: ", $queryRequest->getSelectCommand());
        addToDebug(__FILE__." Zeile ".__LINE__." -> ".__FUNCTION__." -> Html-Attributliste für Maske $in_maskId: ", $queryResult);


        if ($queryResult) {	
                $result_rows = count($queryResult);
                $ergebnisList = Array();
                $columnCount = count($queryResult[0]);

                for ($i = 0; $i < $result_rows; $i++) {
                //Ergebnis-Array zeilenweise durchlaufen   
                    //Wenn eine tag_id erstmals auftaucht, wird durch den nachfolgenden Befehl ein neuer Array Eintrag in Dimension 1 erzeugt,
                    //Ansosnten wird nur ein neuer Eintrag in Dimension 2 erzeugt.
                    $ergebnisList[$queryResult[$i] ["html_tag.id"]] [$queryResult[$i] ["html_attribut.attribut_name"]] = $queryResult[$i] ["html_attribut.attribut_value"];
                }


        } else {
                $ergebnisList = false;
        }	
        return $ergebnisList;

    }
    
    
    
    


    /** Ermittelt eine Liste der Rollen pro Benutzer/Account_id. Die Liste wird so sortiert, 
     * dass eine Rolle, welche Zugriff auf die gewünschte Maske hat, ganz oben erscheint.
     * 
     * @param   string  $in_account_id              Name des Accounts/Benutzers (entspricht bei LDAP der uid)
     * @param   string  $in_account_app_id          App-ID des Accounts/Benutzers
     * @param   string  $in_targe_mask_app_id       APP-ID der aktuell aufzurufenen Maske
     * @param   integer $in_target_mask_id          ID der aktuell aufzurufenden Maske
     * @param   string  $in_activeRoleApp_guest     Für den Fall, dass noch keine SESSION existiert oder erstmals die Rollen eines Accounts abgerufen werden müssen, 
     *                                              wird mit dem Gastaccount gearbeitet. Ansonsten wird die aktive Rolle des gerade angemeldeten Accounts erwartet.
     * @param   integer $in_activeRoleId_guest      Für den Fall, dass noch keine SESSION existiert oder erstmals die Rollen eines Accounts abgerufen werden müssen, 
     *                                              wird mit dem Gastaccount gearbeitet. Ansonstn wird die aktive Rolle des gerade angemeldeten Accounts erwartet.
     * @return  array                               zweidimensionale Liste, role.id, role.name und role.app_id
     */
    function getRoleByAccount($in_account_id, $in_account_app_id, $in_targe_mask_app_id, $in_target_mask_id, $in_activeRoleApp_guest="SYS01", $in_activeRoleId_guest = 6) {													
	$db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        $queryRequest = new sql_request($db_schema_manager_connection_id, $in_activeRoleApp_guest,$in_activeRoleId_guest, __FUNCTION__);
        
            $queryRequest->addSelectColumn("role", "id");
            $queryRequest->addSelectColumn("role", "name");
            $queryRequest->addSelectColumn("role", "app_id");

            $queryRequest->addTable($db_schema_manager, "account_has_role"  , 1, "BASE");
            $queryRequest->addTable($db_schema_manager, "account"           , 2, "INNER");
            $queryRequest->addTable($db_schema_manager, "role"              , 3, "INNER");
            $queryRequest->addTable($db_schema_manager, "role_has_mask"     , 4, "LEFT");

            $queryRequest->addWhereCondition("AND", "", "account_has_role"  , "account_id"  , "=", "account.id",       "");
            $queryRequest->addWhereCondition("AND", "", "account_has_role"  , "account_app_id"  , "=", "account.app_id",       "");
            $queryRequest->addWhereCondition("AND", "", "account"           , "id"          , "=", "'".$in_account_id."'","");
            $queryRequest->addWhereCondition("AND", "", "account"           , "app_id"      , "=", "'".$in_account_app_id."'","");
            $queryRequest->addWhereCondition("AND", "", "account_has_role"  , "role_id"     , "=", "role.id",          "");
            $queryRequest->addWhereCondition("AND", "", "account_has_role"  , "role_app_id" , "=", "role.app_id",      "");
            $queryRequest->addWhereCondition("AND", "", "role"              , "app_id"      , "in", "('".global_variables::getAppIdFromSYS01()."','".$in_account_app_id."')",      "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask"     , "role_app_id" , "=", "role.app_id",      "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask"     , "role_id"     , "=", "role.id",      "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask"     , "mask_id"     , "=", $in_target_mask_id,      "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask"     , "mask_app_id" , "=", "'".$in_targe_mask_app_id."'",      "");
            
            $queryRequest->addOrderbyPart("role_has_mask.mask_id");
        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Ergebnismenge: getRoleByAccount', $queryResult);
        
        return $queryResult;
    }




    /** Ermittelt für eine Maske die Standardrollen, wenn diese in der DB-Tabelle mask_has_role_and_directory angelegt wurden.
     * 
     * @param  string   $in_maskAppId                       APP-ID der Maske, für welche die Standardrollen ermittelt werden sollen
     * @param  integer  $in_maskId                          ID der Maske
     * @param   string  $in_activeRoleApp_guest             Für den Fall, dass noch keine SESSION existiert oder erstmals die Rollen eines Accounts abgerufen werden müssen, 
     *                                                      wird mit dem Gastaccount gearbeitet. Ansonstn wird die aktive Rolle des gerade angemeldeten Accounts erwartet.
     * @param   integer $in_activeRoleId_guest              Für den Fall, dass noch keine SESSION existiert oder erstmals die Rollen eines Accounts abgerufen werden müssen, 
     *                                                      wird mit dem Gastaccount gearbeitet. Ansonstn wird die aktive Rolle des gerade angemeldeten Accounts erwartet.
     * @return array                                        zweidimensionale Liste, role.id, role.name und role.app_id
     */
    function getRoleByMask($in_maskAppId, $in_maskId, $in_activeRoleApp_guest="SYS01", $in_activeRoleId_guest = 6) {													
	$db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();



        $queryRequest = new sql_request($db_schema_manager_connection_id, $in_activeRoleApp_guest,$in_activeRoleId_guest, __FUNCTION__);
        
            $queryRequest->addSelectColumn("role", "id");
            $queryRequest->addSelectColumn("role", "name");
            $queryRequest->addSelectColumn("role", "app_id");

            $queryRequest->addTable($db_schema_manager, "mask_has_role_and_directory", 1, "BASE");
            $queryRequest->addTable($db_schema_manager, "role", 2, "INNER");

            $queryRequest->addWhereCondition("AND", "", "mask_has_role_and_directory", "role_app_id",   "=", "role.app_id"          , "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_role_and_directory",     "role_id",   "=", "role.id"              , "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_role_and_directory", "mask_app_id",   "=", "'".$in_maskAppId."'"  , "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_role_and_directory", "mask_id"    ,   "=", $in_maskId             , "");

        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Ergebnismenge: getRoleByMask für mask = '.$in_maskId, $queryResult);
        
        return $queryResult;
    }
    
    
    
    /** Ermittelt alle Rollen, die eine bestimmte Maske aufrufen dürfen.
     * 
     * @param  string   $in_maskAppId                       APP-ID der Maske, für welche die berechtigten Rollen ermittelt werden sollen
     * @param  integer  $in_maskId                          ID der Maske
     * @param  string   $in_activeRoleApp                   APP-ID der Rolle, in dessen Kontext die Tabelle role_has_mask abgefragt wird.
     * @param  integer  $in_activeRoleId                    ID der Rolle, in dessen Kontext die Tabelle role_has_mask abgefragt wird.
     * @return array                                        zweidimensionale Liste, role.id und role.app_id
     */
    function getRolesForMask($in_maskAppId, $in_maskId, $in_activeRoleApp, $in_activeRoleId) {													
	$db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();



        $queryRequest = new sql_request($db_schema_manager_connection_id, $in_activeRoleApp,$in_activeRoleId, __FUNCTION__);
        
            $queryRequest->addSelectColumn("role_has_mask", "role_app_id");
            $queryRequest->addSelectColumn("role_has_mask", "role_id");
            
            $queryRequest->addTable($db_schema_manager, "role_has_mask", 1, "BASE");
            
            $queryRequest->addWhereCondition("AND", "", "role_has_mask", "access_select",   "=", 1                      , "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask",     "mask_id"  ,   "=", $in_maskId             , "");
            $queryRequest->addWhereCondition("AND", "", "role_has_mask", "mask_app_id"  ,   "=", "'".$in_maskAppId."'"  , "");
            
        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Ergebnismenge: getRolesForMask für mask = '.$in_maskId, $queryResult);
        
        return $queryResult;
    }

    
    




    /** Ermittelt für eine Datenbanktabelle alle ID-Felder oder alle Autoincrement-Felder.
     * IDs sind alle Primary-Keys (PKs), die nicht die Eigenschaft "autoincrement" haben. Diese müssen bei einem Insert-Befehl mindestens gefüllt sein.
     * Autoincrement-Felder sind alle Primary-Keys, die die Eigenschaft "autoincrement" haben. Diese können für einen Insert-Befehl nützlich sein, 
     * um den Autoincrement-Wert selbst festlegen zu können.
     * 
     * @param   string  $in_connection_id       ID der connection, welche genutzt werden soll.
     * @param   string  $in_schema              DB-Schema der Tabelle, für die die IDs ermitelt werden sollen
     * @param   string  $in_table               DB-Tabele, für die die IDs ermittelt werden sollen
     * @param   integer $in_type                1 = ID-Felder (default), 2 = Autoincrement-Felder
     * @return  array                           Gibt ein eindimensionales Array mit den IDs zurück. Wenn keine IDs ermittelt werden konnten, wird ein leeres Array zurückgegeben.
     */
    function getIDsForTable($in_connection_id, $in_schema, $in_table, $in_type = 1) {
        $db_schema_information = global_variables::getNameOfDbSchemaInformation(); 
        
        $IDs = array();
 
        
        $queryRequest = new sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("key_column_usage",  "column_name");
            $queryRequest->addSelectColumn("key_column_usage",  "ordinal_position");
            $queryRequest->addSelectColumn("columns",           "column_default");

            $queryRequest->addTable($db_schema_information, "table_constraints", 1, "BASE");  
            $queryRequest->addTable($db_schema_information, "columns", 2, "INNER");
            $queryRequest->addTable($db_schema_information, "key_column_usage", 3, "INNER");

            $queryRequest->addWhereCondition("AND",    "", "table_constraints",    "constraint_catalog",   "=", "key_column_usage.constraint_catalog",  "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints",    "constraint_schema",    "=", "key_column_usage.constraint_schema",   "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints",    "constraint_name",      "=", "key_column_usage.constraint_name",     "");
            //$queryRequest->addWhereCondition("AND", "", "table_constraints",    "table_catalog",        "=", "key_column_usage.table_catalog",       "");     //Spalte table_catalog exisitert nur in postgres
            $queryRequest->addWhereCondition("AND", "", "table_constraints",    "table_schema",         "=", "key_column_usage.table_schema",        "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints",    "table_name",           "=", "key_column_usage.table_name",          "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints",    "constraint_type",      "=", "'PRIMARY KEY'",                        "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints",    "table_schema",         "=", "'".$in_schema."'",                     "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints",    "table_name",           "=", "'".$in_table."'",                      "");
            //$queryRequest->addWhereCondition("AND", "", "key_column_usage",     "table_catalog",        "=", "columns.table_catalog",                "");
            $queryRequest->addWhereCondition("AND", "", "key_column_usage",     "table_schema",         "=", "columns.table_schema",                 "");
            $queryRequest->addWhereCondition("AND", "", "key_column_usage",     "table_name",           "=", "columns.table_name",                   "");
            $queryRequest->addWhereCondition("AND", "", "key_column_usage",     "column_name",          "=", "columns.column_name",                  "");

            if($in_type == 1) {
                //nachfolgende Bedingung schließt PK'S aus, die per autoinkrement gefüllt werden
                //$type_condition = "AND (columns.column_default not like 'nextval%'	OR columns.column_default is null)";
                $queryRequest->addWhereCondition("AND", "(",    "columns",     "column_default",    "not like", "'nextval%'",   "");
                $queryRequest->addWhereCondition("OR",  "",     "columns",     "column_default",    "is",       "null",         ")");
            } else {
                //$type_condition = "AND (columns.column_default like 'nextval%')";
                $queryRequest->addWhereCondition("AND", "",     "columns",     "column_default",    "like",     "'nextval%'",   "");
            }

            $queryRequest->addOrderbyPart("key_column_usage.ordinal_position");
            
        
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        

        if ($result <> false) {
            foreach ($result as $row) {
                $IDs[] = $row["key_column_usage.column_name"];
            }    
        } else {
            //Ergebnissatz hat 0 Zeilen
        }
        
        
        return $IDs;
    }
    





/** Ermittelt eine Liste aller verfügbaren Masken in Abhängigkeit von der Account-ID des angemeldeten Users.
 * 
 * 
 * @param   String  $in_account_id      ID des angemeldeten Accounts
 * @param   String  $account_app_id     App-ID des angemeldeten Accounts
 * @param   string  $in_guest_user      ID des Gast-Users
 * @param   String  $in_menu            [optional] Name des Menüeintrags, der gewählt wurde (default = "")
 * @return  array   $maskList oder false    Es werden alle Felder der DB-Tabelle mask und eine Spalte "uniqueid" (CONCAT(mask.app_id,'_', mask.id) as uniqueid) 
 *                                      in einem array zurückgegeben.
 */
function getMaskListByAccount($in_account_id, $account_app_id, $in_guest_user, $in_menu = "") {														
    
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    $app_id_from_kernel = global_variables::getAppIdFromSYS01();
    
    //Einschränkung für Menüpunkt beachten, falls der Paramter mitgegeben wird
    if ($in_menu == '') {$bedingung_fuer_menue = '';} else { $bedingung_fuer_menue = "AND mask.menu = '$in_menu'";}
    
    
    /* Select auf Tabelle mask, mit Einschränkung auf Rolle */
    $querySelectPart =  "mask.*
                        , CONCAT(mask.app_id,'_',mask.id) as uniqueid";
 
    $queryFromPart =    "$db_schema_manager.mask 
                        , $db_schema_manager.role_has_mask 
                        , $db_schema_manager.role
                        , $db_schema_manager.account_has_role";
 
    $queryWherePart =   "mask.id = role_has_mask.mask_id
                        AND mask.app_id = role_has_mask.mask_app_id
                        AND role_has_mask.role_id = role.id
                        AND role_has_mask.role_app_id = role.app_id
                        AND role_has_mask.access_select = 1
                        AND account_has_role.role_id = role.id
                        AND account_has_role.role_app_id = role.app_id
                        AND (
                                (account_has_role.account_id = 'guest' AND account_has_role.account_app_id = '$app_id_from_kernel')
                                OR (account_has_role.account_id in ('$in_account_id','$in_guest_user') AND account_has_role.account_app_id = '$account_app_id')
                            ) 
                        $bedingung_fuer_menue";

    $queryGroupbyPart = "mask.id
                        , mask.app_id
                        , mask.css_template_id
                        , mask.css_template_app_id
                        , mask.name
                        , mask.link
                        , mask.menu";

    $queryOrderbyPart = "mask.sort";
     

    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__, true);
    $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $queryGroupbyPart, $queryOrderbyPart);
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
	
    return $result;
}

/** Ermittelt eine Liste aller verfügbaren Masken in Abhängigkeit von der Role-ID 
 * 
 * @param   string  $in_role_app_id         APP-ID der Rolle
 * @param   integer $in_role_id             ID der Rolle
 * @param   string  $in_menu_group          [optional] ID der Navigationsmenügruppe, die angedruckt werden soll. [default = 99 => alle MAsken]
 * @return  array   $maskList               Es werden alle Felder der DB-Tabelle mask und eine Spalte "uniqueid" 
 *                                          (CONCAT(mask.app_id,'_',mask.id) as uniqueid) 
 *                                          in einem array zurückgegeben. Wenn kein Eintrag für eine Menügruppe gefunden wird, wird ein leeres Array zurückgegeben
 */
function getMaskListByRole($in_role_app_id, $in_role_id, $in_menu_group = 99) {														
    
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    //Einschränkung für Menüpunkt beachten, falls der Paramter mitgegeben wird
    if ($in_menu_group == 99) {
        $hide_masks = getConfig("hide_mask_from_main_menu", $in_role_app_id);
        $bedingung_fuer_menue = 'AND mask.id not in ('.$hide_masks.')';
        $order = "mask.level, mask.menu, mask.sort";
    } else { 
        $bedingung_fuer_menue = "AND mask.navgroup = '$in_menu_group'";
        $order = "mask.navgroupsort";
    }
    
    
    /* Select auf Tabelle mask, mit Einschränkung auf Rolle */
    $querySelectPart =  "mask.*
                        , CONCAT(mask.app_id,'_',mask.id) as uniqueid";
 
    $queryFromPart =    "$db_schema_manager.mask 
                        , $db_schema_manager.role_has_mask 
                        , $db_schema_manager.role";
 
    $queryWherePart =   "mask.id = role_has_mask.mask_id
                        AND mask.app_id = role_has_mask.mask_app_id
                        AND role_has_mask.role_id = role.id
                        AND role_has_mask.role_app_id = role.app_id
                        AND role_has_mask.access_select = 1 
                        AND role.app_id = '$in_role_app_id' 
                        AND role.id = $in_role_id 
                        $bedingung_fuer_menue";

    $queryGroupbyPart = "mask.id
                        , mask.app_id
                        , mask.css_template_id
                        , mask.css_template_app_id
                        , mask.name
                        , mask.link
                        , mask.menu";

    $queryOrderbyPart = $order;
     

    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__, true);
    $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $queryGroupbyPart, $queryOrderbyPart);
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);

    if($result == false) {$result = array();}
    return $result;
}




/** Ermittelt alle Masken, auf denen das genannte Formular verwendet wird.
 * 
 * @param   string  $in_form_app_id                     APP-ID des Formulars
 * @param   integer $in_form_id                         ID des Formulars
 * @return  array                                       Zweidimensionale LIste der Masken. Bsp.: Array(1 => array(mask.app_id = SYS01, mask.id = 100, navgroup = 1))
 */
function getMaskListByForm($in_form_app_id, $in_form_id) {
       
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);    

        $queryRequest->addSelectColumn("mask", "app_id");
        $queryRequest->addSelectColumn("mask", "id");
        $queryRequest->addSelectColumn("mask", "navgroup");

        $queryRequest->addTable($db_schema_manager, "mask", 1, "BASE", "");
        $queryRequest->addTable($db_schema_manager, "mask_has_htmltaggroup", 2, "INNER", "");
        $queryRequest->addTable($db_schema_manager, "htmltaggroup", 3, "INNER", "");
        $queryRequest->addTable($db_schema_manager, "htmltaggroup_has_html_tag", 4, "INNER", "");
        $queryRequest->addTable($db_schema_manager, "html_tag", 5, "INNER", "");
        $queryRequest->addTable($db_schema_manager, "form", 6, "INNER", "");

        $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "mask_app_id", "=", "mask.app_id", "");
        $queryRequest->addWhereCondition("AND", "", "mask_has_htmltaggroup", "mask_id", "=", "mask.id", "");
        $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "app_id", "=", "mask_has_htmltaggroup.htmltaggroup_app_id", "");
        $queryRequest->addWhereCondition("AND", "", "htmltaggroup", "id", "=", "mask_has_htmltaggroup.htmltaggroup_id", "");
        $queryRequest->addWhereCondition("AND", "", "htmltaggroup_has_html_tag", "htmltaggroup_app_id", "=", "htmltaggroup.app_id", "");
        $queryRequest->addWhereCondition("AND", "", "htmltaggroup_has_html_tag", "htmltaggroup_id", "=", "htmltaggroup.id", "");
        $queryRequest->addWhereCondition("AND", "", "html_tag", "app_id", "=", "htmltaggroup_has_html_tag.html_tag_app_id", "");
        $queryRequest->addWhereCondition("AND", "", "html_tag", "id", "=", "htmltaggroup_has_html_tag.html_tag_id", "");
        $queryRequest->addWhereCondition("AND", "", "form", "app_id", "=", "html_tag.form_app_id", "");
        $queryRequest->addWhereCondition("AND", "", "form", "id", "=", "html_tag.form_id", "");


        $queryRequest->addWhereCondition("AND", "", "form", "id", "=", "'$in_form_id'", "");
        $queryRequest->addWhereCondition("AND", "", "form", "app_id", "=", "'$in_form_app_id'", "");

        $queryRequest->addOrderbyPart("mask.app_id, mask.id");

    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);


    if($result == false) {
        $feedback = array();
    } else {
        $feedback = $result;
    }

    return $feedback;



}



/** Ermittelt alle StepDaten eines Workflows. 
 * 
 * @param   string      $in_app_id                          APP-ID des Workflows
 * @param   integer     $in_workflow_id     
 * @param   integer     $in_version
 * @return  array                                       Liste der StepDaten; Wenn keine Daten ermittelt werden konnten, wird ein leeres array zurückgegeben.
 */
function getWorkflowStepData($in_app_id, $in_workflow_id, $in_version) {
       
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
   
    
    
    /* Select auf Tabelle mask, mit Einschränkung auf Rolle */
    $querySelectPart =  "workflow_step.step
                        ,MAX(ws2.step) as max_step
                        , workflow_step.name
                        , workflow_step.description
                        , workflow_step.default_email_to 
                        , workflow_step.default_email_cc
                        , workflow_step.default_email_from
                        , workflow_step.email_template
                        , workflow_step.back_to_step
                        , workflow_step.content_status_column
                        , workflow_step.content_status_value
                        , files.pathname
                        , files.filename
                        , files.filetype
                        , workflow.name
                        , workflow.description";
                        
    $queryFromPart =    "$db_schema_manager.workflow_step as workflow_step
                            INNER JOIN $db_schema_manager.workflow_step as ws2 ON ws2.app_id = workflow_step.app_id AND ws2.workflow_id = workflow_step.workflow_id AND ws2.version = workflow_step.version 
                            INNER JOIN $db_schema_manager.workflow ON workflow.app_id = workflow_step.app_id AND workflow.workflow_id = workflow_step.workflow_id AND workflow.version = workflow_step.version 
                            LEFT JOIN $db_schema_manager.files ON files.app_id = workflow_step.app_id and files.id = workflow_step.email_template
                            ";
 
    $queryWherePart =   "workflow_step.app_id = '$in_app_id' 
                         and workflow_step.workflow_id = $in_workflow_id
                         and workflow_step.version = $in_version";
    
    $queryGroupBy =     "workflow_step.step
                         , workflow_step.name
                         , workflow_step.description 
                         , workflow_step.default_email_to
                        , workflow_step.default_email_cc
                        , workflow_step.default_email_from
                        , workflow_step.email_template
                        , workflow_step.back_to_step
                        , workflow_step.content_status_column
                        , workflow_step.content_status_value
                        , files.pathname
                        , files.filename
                        , files.filetype
                        , workflow.name
                        , workflow.description
                        ";

    $queryOrderbyPart = "workflow_step.step";
     

    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
    $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $queryGroupBy, $queryOrderbyPart);
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);

    if($result == false) {
        $feedback = array();
        
    } else {
        $feedback = array();
        foreach ($result as $key => $current_step) {
            $feedback[$current_step["workflow_step.step"]]["wkfl_step"] = $current_step["workflow_step.step"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_max_step"] = $current_step[".max_step"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_name"] = $current_step["workflow_step.name"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_description"] = $current_step["workflow_step.description"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_mail_to"] = $current_step["workflow_step.default_email_to"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_mail_cc"] = $current_step["workflow_step.default_email_cc"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_mail_from"] = $current_step["workflow_step.default_email_from"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_email_template"] = $current_step["workflow_step.email_template"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_pathname"] = $current_step["files.pathname"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_filename"] = $current_step["files.filename"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_filetype"] = $current_step["files.filetype"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_name"] = $current_step["workflow.name"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_description"] = $current_step["workflow.description"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_back_to_step"] = $current_step["workflow_step.back_to_step"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_content_status_column"] = $current_step["workflow_step.content_status_column"];
            $feedback[$current_step["workflow_step.step"]]["wkfl_step_content_status_value"] = $current_step["workflow_step.content_status_value"];
        }
        
    }
    return $feedback;



}





/** Ermittelt alle AccessDaten eines Workflows. 
 * 
 * @param   string      $in_app_id                          APP-ID des Workflows
 * @param   integer     $in_workflow_id     
 * @param   integer     $in_version
 * @return  array                                       3-Dimensionale Liste der AccessDaten; Wenn keine Daten ermittelt werden konnten, wird ein leeres array zurückgegeben.
 */
function getWorkflowAccessData($in_app_id, $in_workflow_id, $in_version) {
       
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
   
    
    
    /* Select auf Tabelle mask, mit Einschränkung auf Rolle */
    $querySelectPart =  "workflow_access.step
                        , workflow_access.role_app_id
                        , workflow_access.role_id";
                        
    $queryFromPart =    "$db_schema_manager.workflow_access as workflow_access
                            ";
 
    $queryWherePart =   "workflow_access.app_id = '$in_app_id' 
                         and workflow_access.workflow_id = $in_workflow_id
                         and workflow_access.version = $in_version";

    $queryOrderbyPart = "workflow_access.role_id";
     

    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
    $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, "", $queryOrderbyPart);
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);

    if($result == false) {
        $feedback = array();
        
    } else {
        $feedback = array();
        foreach ($result as $key => $current_step) {
            $feedback[$current_step["workflow_access.step"]] [$key] ["step"] = $current_step["workflow_access.step"];
            $feedback[$current_step["workflow_access.step"]] [$key] ["role_app_id"] = $current_step["workflow_access.role_app_id"];
            $feedback[$current_step["workflow_access.step"]] [$key] ["role_id"] = $current_step["workflow_access.role_id"];
        }
        
    }
    return $feedback;



}










/** Ermittelt den Wert einer bestimmten Zeile und Spalte einer bestimmten Tabelle
 * 
 * @param   string  $in_connection_id   ID der connection, die verwendet werden soll.
 * @param   type    $in_Schema          Datenbankschema
 * @param   type    $in_Table           Datenbanktabelle
 * @param   type    $in_SearchColumn    Spalte in Datenbanktabelle
 * @param   type    $in_Condition       Bedingung, die gelten soll (Bsp.: ID = 1 AND app_id = 'SYS01')
 * @param   string  $in_orderby_part    [optional] kompletter ORDER-BY-Part, in dem auch komplexe Ausdrücke verwendet werden können, ohne "ORDER BY" als Einleitung    
 * @return  mixed                       (string or false) Nur ein inzelner Single-Wert wird zurückgegeben, erster Treffer einer Ergebnismenge
 */
function getDataFromTableByID($in_connection_id, $in_Schema, $in_Table, $in_SearchColumn, $in_Condition, $in_orderby_part = "") {														

    if(strpos($in_SearchColumn,".") != false) {$column = $in_SearchColumn;} else {$column = $in_Table.".".$in_SearchColumn;}
    
    /* Select auf eine beliebige Tabelle */
    $queryRequest = new sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
    $queryRequest->addSelectComplexStatement($column, $in_Schema.".".$in_Table, $in_Condition, "", $in_orderby_part);
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
    
//    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> result: ', $result);
        
    if ($result != false AND $result !== array()) {
        $feedback = $result[0][$in_Table.".".$in_SearchColumn];                             //Nur der erste Werte aus der ersten Zeile wird zurückgegeben
    } else {
        $feedback = false;
    }


    return $feedback;		
}






    /** Ermittelt die abhängigen Felder zwischen einer Parentform und der eingebetteten Childform.
     * Anhand der Felder kann dann eine SQL-Condition für das einegebettete Formular erstellt werden.
     * 
     * @param   string              $in_source_form_app_id  APP der Parentform
     * @param   integer             $in_source_form_id      ID der Parentform
     * @param   integer             $in_form_nesting_id     ID des Datensatzes aus der Tabelle form_nesting (kann über die Abfrage getNestedForms ermittelt werden.
     * @return  array oder boolean                          array oder false; array enthält die keys: form_nesting.child_form_app_id
                                                                                                        * , form_nesting.child_form_id
                                                                                                        * , form_nesting_fieldreference.source_field_id
                                                                                                        * , source_field.spalte as source_field_spalte
                                                                                                        * , source_form.db_table as source_form_table
                                                                                                        * , source_form.db_schema as source_form_schema
                                                                                                        * , form_nesting_fieldreference.target_field_id
                                                                                                        * , target_field.spalte as target_field_spalte
                                                                                                        * , target_form.db_table as target_form_table
                                                                                                        * , target_form.db_schema as target_form_schema
     */
    function getNestedFormFields($in_source_form_app_id, $in_source_form_id, $in_form_nesting_id) {
        $ergebnisList = array();
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("form_nesting",                  "child_form_app_id");
            $queryRequest->addSelectColumn("form_nesting",                  "child_form_id");
            $queryRequest->addSelectColumn("form_nesting_fieldreference",   "source_field_id");
            $queryRequest->addSelectColumn("source_field",                  "spalte",               "source_field_spalte");
            $queryRequest->addSelectColumn("source_form",                   "db_table",             "source_form_table");
            $queryRequest->addSelectColumn("source_form",                   "db_schema",            "source_form_schema");
            $queryRequest->addSelectColumn("form_nesting_fieldreference",   "target_field_id");
            $queryRequest->addSelectColumn("target_field",                  "spalte",               "target_field_spalte");
            $queryRequest->addSelectColumn("target_form",                   "db_table",             "target_form_table");
            $queryRequest->addSelectColumn("target_form",                   "db_schema",            "target_form_schema");

            $queryRequest->addTable($db_schema_manager, "form_nesting",                 1, "BASE");
            $queryRequest->addTable($db_schema_manager, "form",                         2, "INNER", "source_form");
            $queryRequest->addTable($db_schema_manager, "form",                         3, "INNER", "target_form");
            $queryRequest->addTable($db_schema_manager, "feld",                         4, "INNER", "source_field");
            $queryRequest->addTable($db_schema_manager, "feld",                         5, "INNER", "target_field");
            $queryRequest->addTable($db_schema_manager, "form_nesting_fieldreference",  6, "INNER");

            $queryRequest->addWhereCondition("AND", "", "form_nesting",                 "form_app_id",      "=", "form_nesting_fieldreference.form_nesting_form_app_id", "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting",                 "form_id",          "=", "form_nesting_fieldreference.form_nesting_form_id", "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting",                 "id",               "=", "form_nesting_fieldreference.form_nesting_id", "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting",                 "form_app_id",      "=", "source_field.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting_fieldreference",  "source_field_id",  "=", "source_field.id", "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting",                 "form_app_id",      "=", "target_field.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting_fieldreference",  "target_field_id",  "=", "target_field.id", "");
            $queryRequest->addWhereCondition("AND", "", "source_field",                 "form_app_id",      "=", "source_form.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "source_field",                 "form_id",          "=", "source_form.id", "");
            $queryRequest->addWhereCondition("AND", "", "target_field",                 "form_app_id",      "=", "target_form.app_id", "");
            $queryRequest->addWhereCondition("AND", "", "target_field",                 "form_id",          "=", "target_form.id", "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting",                 "form_app_id",      "=", "'".$in_source_form_app_id."'", "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting",                 "form_id",          "=", $in_source_form_id, "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting",                 "id",               "=", $in_form_nesting_id, "");

            $queryRequest->addOrderbyPart("form_nesting.sortorder");
        
        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);


        if (count($queryResult) > 0) {
             //Ergebnisarray überarbeiten, da nicht alle DBMS in der Ergebnismenge die table-aliases zurückgeben (bswp. postgres)
            //Das ist jedoch notwendig, damit die folgenden Funktionen auch DBMS-unabhängig funktionieren
            foreach ($queryResult as $key => $current_row) {
                $queryResult[$key]["source_field.source_field_spalte"] = $current_row[issetKeyLike($current_row, "source_field_spalte")];
                $queryResult[$key]["source_form.source_form_table"] = $current_row[issetKeyLike($current_row, "source_form_table")];
                $queryResult[$key]["source_form.source_form_schema"] = $current_row[issetKeyLike($current_row, "source_form_schema")];
                $queryResult[$key]["target_field.target_field_spalte"] = $current_row[issetKeyLike($current_row, "target_field_spalte")];
                $queryResult[$key]["target_form.target_form_table"] = $current_row[issetKeyLike($current_row, "target_form_table")];
                $queryResult[$key]["target_form.target_form_schema"] = $current_row[issetKeyLike($current_row, "target_form_schema")];
            }
            $ergebnisList = $queryResult;
        } else {
            $ergebnisList = false;
        }

        
        return $ergebnisList;
    }



    
    
    


    /** Ermittelt die eingebetteten Childform für eine Parentform
     * 
     * @param       string              $in_source_form_app_id  APP der Parentform
     * @param       integer             $in_source_form_id      ID der Parentform
     * @return      array oder boolean                          array oder false; array enthält die keys: form_nesting.child_form_app_id
                                                                                                            , form_nesting.child_form_id
                                                                                                            , form_nesting.id
     */
    function getNestedForms($in_source_form_app_id, $in_source_form_id) {
        $ergebnisList = array();
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
  
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("form_nesting",  "child_form_app_id");
            $queryRequest->addSelectColumn("form_nesting",  "child_form_id");
            $queryRequest->addSelectColumn("form_nesting",  "id");

            $queryRequest->addTable($db_schema_manager, "form_nesting", 1, "BASE");

            $queryRequest->addWhereCondition("AND",    "", "form_nesting", "form_app_id",  "=", "'".$in_source_form_app_id."'",    "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting", "form_id",      "=", $in_source_form_id,                "");

            $queryRequest->addOrderbyPart("form_nesting.sortorder");
        
        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);

        if (count($queryResult) > 0) {
            $ergebnisList = $queryResult;
        } else {
            $ergebnisList = false;
        }	
        return $ergebnisList;
    }


    
        
    //ToDo: Es sollte auch die Maske eingebunden werden, ansosnten könnte es unlogische Ergebnisse geben, wenn das selbe Formular auf mehreren Masken benutzt wird.
    /** Ermittelt Referenzinformationen über die Parentform für eine eingebettet Childform
     * 
     * @param       string              $in_nested_form_app_id  APP der Childform
     * @param       integer             $in_nested_form_id      ID der Childform
     * @return      array oder boolean                          zweidimensionales array oder false; array enthält auf erster Ebene einen key (lfd. Nr.) und einen Refernzdatensatz (array)
     *                                                          In der zweiten Ebene sind die folgenden keys enthalten: form_nesting.form_app_id
                                                                                                            , form_nesting.form_id
                                                                                                            , form_nesting.id
     */
    function getParentFormReference($in_nested_form_app_id, $in_nested_form_id) {
        $ergebnisList = array();
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();


        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("form_nesting",  "id");
            $queryRequest->addSelectColumn("form_nesting",  "form_id");
            $queryRequest->addSelectColumn("form_nesting",  "form_app_id");

            $queryRequest->addTable($db_schema_manager, "form_nesting", 1, "BASE");

            $queryRequest->addWhereCondition("AND",    "", "form_nesting", "child_form_app_id",  "=", "'".$in_nested_form_app_id."'",    "");
            $queryRequest->addWhereCondition("AND", "", "form_nesting", "child_form_id",      "=", $in_nested_form_id,                "");

            $queryRequest->addOrderbyPart("form_nesting.sortorder");
        
        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);


        if (count($queryResult) > 0) {
            $ergebnisList = $queryResult;
        } else {
            $ergebnisList = false;
        }	
        return $ergebnisList;
    }
    
    

    
    

    /** ToDo: hier wird controller und view vermischt. Prüfen, ob das besser in html_class integriert werden kann.
     *  
     * Erstellt den HTML-Quellcode für eine Gruppe von Symbolen in allen verfügbaren Modi. 
     * Diese Funktion dient der Präsentation der verschiedenen Zustände einer Symbolgruppe.
     * Eine Gruppe von Symbolen wird selbst auch zu einem Formular 
    * zusammengefasst (Tabelle form), jedoch nicht als html-Formular ausgegeben. Die Ausgabe erfolgt hingegen eingebettet in einem übergeordneten Formular.
    * 
    * @param    array           $in_symbolForm               Formular (die Symbolgruppe), deren Symbole angezeigt werden sollen
    * @param    array           $in_pagedata                 Objekt, siehe pagedata_class
    * @return   string                                       HTML-Code
    */
    function getSymbolGroupForAllModi($in_symbolForm, &$in_pagedata) {			
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01(); 
        $feedback = "";        
        
        //Datenbankabfrage
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("form_mode",  "id");
            $queryRequest->addSelectColumn("form_mode",  "name");
            $queryRequest->addSelectColumn("form_mode",  "description");
            $queryRequest->addTable($db_schema_manager, "form_mode", 1, "BASE");       
        $modi = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        

        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Formular $modi: ', $modi);

        $feedback = $feedback."<b>Symbolleiste: ".$in_symbolForm["form.name"]."</b><br /><br />";
        for ($i=0; $i<count($modi);$i++) {  
            $feedback = $feedback."<div> \r\n";
                $feedback = $feedback."Modus: ".$modi[$i] ["form_mode.id"]." - ".$modi[$i] ["form_mode.name"]." - ".$modi[$i] ["form_mode.description"];
                $feedback = $feedback." <br /> \r\n";
                $feedback = $feedback.getSymbolGroup($in_symbolForm, $in_pagedata, "auto", "0", $modi[$i] ["form_mode.id"], $in_symbolForm["form.app_id"], $i);
            $feedback = $feedback."</div> \r\n <br /><br /><hr /> \r\n";
        }

        return $feedback;
    }
    
    
    
    
    

    /** Ermittelt alle Daten einer beliebigen Datenbanktabelle und gibt diese als zweidimensionales Array zurück
     * 
     * @param string    $in_connection_id  ID der connection, welche genutzt werden soll.
     * @param String    $in_tablename      Name der DB-Tabelle, in der die Daten liegen.
     * @param String    $in_schema         DB-Schema der DB-Tabelle
     * @param boolean   $in_deactivateSecurity  [0|1] Schalter, um Berücksichtigung der Security-Conditions abzuschalten. Das ist notwendig, 
     *                                          wenn die Klasse sql_request sich selbst aufruft. Sonst würde eine Endlosschleife enstehen. Zudem müssen die meisten internen 
     *                                          Funktionen vollen Zugriff auf Daten haben. I.d.R. müssen nur Anwender-Queries und Anwenderdaten (getTableData) eingeschränkt werden.
     * @param String    $in_order_by       [optional] Sortiermerkmal (Spaltennamen der Tabelle, durch Komma getrennt. (default = "")
     * @param String    $in_bedingung      [optional] SQL-Bedingung für die DB-Tabelle, falls nicht alle Daten ermittelt werden sollen. (Bsp.: id > 100 AND name like 'a%'; (default = "")
     * @param String    $in_caller         [optional] Name der aufrufenden Funktion. Dieser kann im Debug-Modus verwendet werden. (default = "")
     * @param String    $in_limit          [optional] Anzahl der anzuzeigenden Datensätze (default = 0; 0 = deaktiviert)
     * @param String    $in_offset         [optional] Anzahl der zu überspringenden Datensätze, bis zum ersten anzuzeigenden (default = 0)
     * @param String    $in_use_cache      [optional] Gibt an, dass der Cache aller bisherigen Abfragen genutzt werden soll. D.h., wenn eine identische Abfrage innerhalb des aktuellen 
     *                                  Maskenaufbaus bereits an die Datenbank gesendet wurde, dann dessen Ergebnis genutzt. (default = true) 
     * @return Array                    zweidimensional Abbild der Tabelle oder array() im Fehlerfall.
     */
    function getTableData($in_connection_id, $in_tablename, $in_schema, $in_deactivateSecurity, $in_order_by = "", $in_bedingung = "", $in_caller = "", $in_limit = 0, $in_offset = 0, $in_use_cache = true) {												
            $ergebnisList = array();
            if($in_schema <> "" AND $in_tablename <> "") {

                $queryRequest = new sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__, $in_deactivateSecurity);
                $queryRequest->addSelectComplexStatement($in_tablename.".*", $in_schema.".".$in_tablename, $in_bedingung, "",$in_order_by);
                $queryRequest->setLimit($in_limit, $in_offset);
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> aufrufende Funktion: ', $in_caller.', SQL-Befehl: '.$queryRequest->getSelectCommand());
                $tableData = db_connection_handler::selectOnDatabase($queryRequest, $in_caller, false, $in_use_cache, true);

                if ($tableData === false) {
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> kein SQL-Ergebnis für aufrufende Funktion: ', $in_caller.', SQL-Befehl: '.$queryRequest->getSelectCommand());
                } elseif (count($tableData) > 0) {
                    $ergebnisList = $tableData;

                } 
            }
            return $ergebnisList;
    }
    
    
    
    /** Ermittelt alle Daten einer beliebigen Datenbanktabelle und gibt diese als zweidimensionales Array zurück.
     * Anders als bei getTableData werden jedoch nur die genannten Spalten abgefragt. Das kann die Performance deutlich verbessern.
     * 
     * @param string    $in_connection_id  ID der connection, welche genutzt werden soll.
     * @param String    $in_tablename      Name der DB-Tabelle, in der die Daten liegen.
     * @param String    $in_schema         DB-Schema der DB-Tabelle
     * @param array     $in_fieldlist      Liste der Felder (columns), des Formulars/der Tabelle. 
     *                                      Mindestaufbau der fieldlist:
     *                                      Array(
                                                        [0] => Array
                                                                (
                                                                        [feld.spalte] => id
                                                                )

                                                        [1] => Array
                                                                (
                                                                        [feld.spalte] => name
                                                                )
                                                )
     * @param boolean   $in_deactivateSecurity  (optional; default = 0) [0|1] Schalter, um Berücksichtigung der Security-Conditions abzuschalten. Das ist notwendig, 
     *                                          wenn die Klasse sql_request sich selbst aufruft. Sonst würde eine Endlosschleife enstehen. Zudem müssen die meisten internen 
     *                                          Funktionen vollen Zugriff auf Daten haben. I.d.R. müssen nur Anwender-Queries und Anwenderdaten (getTableData) eingeschränkt werden.
     * @param String    $in_order_by       [optional] Sortierspalten (Spaltennamen der Tabelle, durch Komma getrennt. (default = "")
     * @param String    $in_bedingung      [optional] SQL-Bedingung für die DB-Tabelle, falls nicht alle Daten ermittelt werden sollen. (Bsp.: id > 100 AND name like 'a%'; (default = "")
     * @param String    $in_caller         [optional] Name der aufrufenden Funktion. Dieser kann im Debug-Modus verwendet werden. (default = "")
     * @param String    $in_limit          [optional] Anzahl der anzuzeigenden Datensätze (default = 0; 0 = deaktiviert)
     * @param String    $in_offset         [optional] Anzahl der zu überspringenden Datensätze, bis zum ersten anzuzeigenden (default = 0)
     * @param bolean    $in_use_cache      [optional] Gibt an, dass der Cache aller bisherigen Abfragen genutzt werden soll. D.h., wenn eine identische Abfrage innerhalb des aktuellen Maskenaufbaus bereits an die Datenbank gesendet wurde, dann dessen Ergebnis genutzt. (default = true) 
     * @param String    $in_group_by       [optional] Gruppierungsspalten (Spaltennamen der Tabelle, durch Komma getrennt, nach denen gruppiert werden soll. (Default = "")
     * @return Array                       zweidimensional Abbild der Tabelle oder array() im Fehlerfall.
     */
    function getTableData2($in_connection_id, $in_tablename, $in_schema, $in_fieldlist, $in_deactivateSecurity, $in_order_by = "", $in_bedingung = "", $in_caller = "", $in_limit = 0, $in_offset = 0, $in_use_cache = true, $in_group_by = "") {												
            $ergebnisList = array();
            $columnlist = array();
            $columnstring = "";
            $column_sys_exists = false;
            
            
            
            //Felderliste bilden
            foreach ($in_fieldlist as $key => $currentField) {
                        
                if($currentField["feld.spalte"] != "") {
                    if($currentField["feld.spalte"] == "sys") {$column_sys_exists = true;}
                    if(strpos($currentField["feld.spalte"], ".")!= false) {$columnlist[$currentField["feld.spalte"]] = $currentField["feld.spalte"];} else {$columnlist[$currentField["feld.spalte"]] = $in_tablename.".".$currentField["feld.spalte"];}   //der Spaltenname wird auch als key verwendet, damit bei Mehrfachverwendung der selben Spalte im Formular, die Spalte nur einmal im Select übernommen wird.
                }
            }
            
            
            //Wenn Schema des Kernsystems abgefragt wird, dann auch die Spalte sys ergänzen, falls sie nicht bereits vorhanden ist und es sich nicht um eine temporäre vquery-Tabelle handelt.
            if($in_schema == global_variables::getNameOfDbSchemaSYS01() AND $column_sys_exists === false AND substr($in_tablename, 0,6)!="vquery") {
                $columnlist["sys"] = $in_tablename.".sys";
            }
            
            //Spalten in einer kommaseparierte Aufzählung in einem String zusammenfassen
            if($columnlist!= array()) {
                $columnstring = implode(",", $columnlist);
            } else {
                $columnstring = $in_tablename.".*";
            }
            
            
            
            if($in_schema <> "" AND $in_tablename <> "") {
                
                $queryRequest = new sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__, $in_deactivateSecurity);
                $queryRequest->addSelectComplexStatement($columnstring, $in_schema.".".$in_tablename, $in_bedingung, $in_group_by, $in_order_by);
                $queryRequest->setLimit($in_limit, $in_offset);
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> aufrufende Funktion: ', $in_caller.', SQL-Befehl: '.$queryRequest->getSelectCommand());
                $tableData = db_connection_handler::selectOnDatabase($queryRequest, $in_caller, false, $in_use_cache);

                if ($tableData === false) {

                } elseif (count($tableData) > 0) {
                    $ergebnisList = $tableData;

                } 
            }
            return $ergebnisList;
    }
    
    
    
    
    /** Ermittelt die Anzahl der Datensätze  einer beliebigen Datenbanktabelle und gibt diese als Integer zurück
     * 
     * @param string $in_connection_id  ID der connection, welche genutzt werden soll.
     * @param String $in_tablename      Name der DB-Tabelle, in der die Daten liegen.
     * @param String $in_schema         DB-Schema der DB-Tabelle
     * @param String $in_column         Name einer DB-Spalte, die zum zählen genutzt werden kann. Ideal ist eine primarykey-column
     * @param String $in_bedingung      [optional] SQL-Bedingung für die DB-Tabelle, falls nicht alle Daten ermittelt werden sollen. (Bsp.: id > 100 AND name like 'a%'; (default = "")
     * @param String $in_caller         [optional] Name der aufrufenden Funktion. Dieser kann im Debug-Modus verwendet werden. (default = "")
     * @param String $in_use_cache      [optional] Gibt an, dass der Cache aller bisherigen Abfragen genutzt werden soll. D.h., wenn eine identische Abfrage innerhalb des aktuellen 
     *                                  Maskenaufbaus bereits an die Datenbank gesendet wurde, dann dessen Ergebnis genutzt. (default = true) 
     * @return Integer                    
     */
    function getTableDataCount($in_connection_id, $in_tablename, $in_schema, $in_column, $in_bedingung = "", $in_caller = "", $in_use_cache = true) {												
            
            $queryRequest = new sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__, false);
            $queryRequest->addSelectComplexStatement("count(".$in_column.") as anzahl", $in_schema.".".$in_tablename, $in_bedingung, "", "");
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> aufrufende Funktion: ', $in_caller.', SQL-Befehl: '.$queryRequest->getSelectCommand());
            $tableData = db_connection_handler::selectOnDatabase($queryRequest, $in_caller, false, $in_use_cache);

            if($tableData !== false) {
                if (count($tableData) > 0) {
                    $countTableData = $tableData[0][".anzahl"];

                } else {
                    $countTableData = 0;
                }
            } else {
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> aufrufende Funktion: ', $in_caller.', SQL-Befehl: '.$queryRequest->getSelectCommand());
                $countTableData = 0;
            }
            return $countTableData;
    }
    


    
    
    /** Ermittelt für eine account_id den zuständigen Validator und das Directory, über das die account_id validiert werden soll.
     * 
     * @param   String  $in_accountId       ID des Accounts, siehe DB-Tabelle account.id
     * @param   String  $in_accountAppId    App-ID des Accounts, siehe DB-Tabelle account.id
     * @return  mixed                       Array, wenn validator gefunden wurde; false, wenn kein Validator ermittelt werden konnte
     *                                      Bsp.: array("account.id" => "Meier", "directory.validator" => "ldap_con.php", "directory.id" => 3)
     */
    function getValidatorForAccount($in_accountId, $in_accountAppId) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
       
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("account",   "id");
            $queryRequest->addSelectColumn("directory", "validator");
            $queryRequest->addSelectColumn("directory", "id");
            $queryRequest->addSelectColumn("directory", "server");
            
            $queryRequest->addTable($db_schema_manager, "account", 1, "BASE");
            $queryRequest->addTable($db_schema_manager, "directory", 2, "INNER");
            
            $queryRequest->addWhereCondition("AND", "", "account", "directory_id",  "=", "directory.id",        "");
            $queryRequest->addWhereCondition("AND", "", "account", "id",            "=", "'".$in_accountId."'", "");
            $queryRequest->addWhereCondition("AND", "", "account", "app_id",            "=", "'".$in_accountAppId."'", "");
        
        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__,true);
        

        if ($queryResult) {	
                $feedback = $queryResult[0];
        } else {
                $feedback = false;
        }	
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Validator/Directory: ', $feedback,"INFO");
       
        return $feedback;
    }
    
    
    
    /** Ermittelt für eine Maske einen Standardvalidator/directory, wenn dieser in der DB-Tabelle mask_has_role_and_directory angelegt wurde. Es kann pro Maske nur ein Standarddirectory geben
     * 
     * @param  string   $in_maskAppId                       MASK-APP-ID der Maske, für welche die Anmeldung erfolgen soll
     * @param  integer  $in_maskId                          MASK-ID der Maske, für welche die Anmeldung erfolgen soll
     * @return mixed                                        Array, wenn validator gefunden wurde; false, wenn kein Validator ermittelt werden konnte
     *                                                      Bsp.: array("directory.validator" => "ldap_con.php", "directory.app_id" => "SYS01", "directory.id" => 3)
     */
    function getValidatorForMask($in_maskAppId, $in_maskId) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
       
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
            $queryRequest->addSelectColumn("directory", "validator");
            $queryRequest->addSelectColumn("directory", "app_id");
            $queryRequest->addSelectColumn("directory", "id");
            $queryRequest->addSelectColumn("directory", "server");
            
            $queryRequest->addTable($db_schema_manager, "mask_has_role_and_directory", 1, "BASE");
            $queryRequest->addTable($db_schema_manager, "directory", 2, "INNER");
            
            $queryRequest->addWhereCondition("AND",    "", "mask_has_role_and_directory", "directory_app_id",  "=", "directory.app_id",        "");
            $queryRequest->addWhereCondition("AND",    "", "mask_has_role_and_directory", "directory_id",  "=", "directory.id",        "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_role_and_directory", "mask_app_id",            "=", "'".$in_maskAppId."'", "");
            $queryRequest->addWhereCondition("AND", "", "mask_has_role_and_directory", "mask_id",            "=", "'".$in_maskId."'", "");
        
        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        

        if ($queryResult) {	
                $feedback = $queryResult[0];
        } else {
                $feedback = false;
        }	
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Validator/Directory für Maske '.$in_maskId.': ', $feedback,"INFO");
       
        return $feedback;
    }
    
    
    
    

    /** Ermittelt alle Daten einer Maske (siehe Tabelle mask).
     * 
     * @param   Integer     $in_id                      ID der Tabelle mask, für die die Daten ermittelt werden sollen
     * @param   String      $in_app                     App der Maske
     * @param   boolean     $in_use_tempInstallPath     Gibt an, ob der temporäre Installationspfad genutzt werden soll. Wenn ja, wird dieser mask.link vorangestellt.
     * @return  Array                                   Zeile der Tabelle mask. Spaltenname = key, Inhalt = value.
     */
    function getMaskDataById($in_id, $in_app, $in_use_tempInstallPath) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("mask", "*");
            $queryRequest->addSelectColumn("workflow_mask", "app_id", "workflow_app_id");
            $queryRequest->addSelectColumn("workflow_mask", "workflow_id");
            $queryRequest->addSelectColumn("workflow_mask", "version", "workflow_version");
            $queryRequest->addTable($db_schema_manager, "mask", 1, "BASE");
            $queryRequest->addTable($db_schema_manager, "workflow_mask", 2, "LEFT");
            $queryRequest->addWhereCondition("AND", "", "mask", "id", "=", $in_id, "");
            $queryRequest->addWhereCondition("AND", "", "mask", "app_id", "=", "'".$in_app."'", "");
            $queryRequest->addJoinCondition("AND", "", 2, "mask_app_id", "", "=", "mask", "app_id", "", "");
            $queryRequest->addJoinCondition("AND", "", 2, "mask_id", "", "=", "mask", "id", "", "");
        $feedback = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        
        
        $myDirSep = global_variables::getDirectorySeparator();
        $viewDir_rel = global_variables::getNameOfViewDir();
        $link_suffix = "..".$myDirSep."..".$myDirSep.global_variables::getPathForAppmsinstall_rel($in_use_tempInstallPath).$viewDir_rel.$myDirSep;
        
        
        if ($feedback) {	
            $ergebnisList = Array();

            foreach ($feedback[0] as $TableAndColumnName => $value) {
                //$feedback ist ein zweidimensionales Array. In der ersten Dimension kann es nur einen 
                //Datensatz geben. Dieser enthält ein zweites array, welches einer Zeile der DB-Tabelle 
                //mask entspricht.
                $TableAndColumnNameArray = explode(".", $TableAndColumnName);
                $ColumnName = $TableAndColumnNameArray[1];
                if($ColumnName == "link") {
                    //ggf. dem Value den temporären Installationspfad voranstellen
                    $ergebnisList["link_org"] = $value;
                    $value = $link_suffix.$value;
                }
                $ergebnisList[$ColumnName] = $value;
            }
            
        } else {
                $ergebnisList = false;
        }	

        return $ergebnisList;
    }



    
    
    



    /** Ermittelt anhand einer Form-ID und der App des Formulars (Primary-Key in der Tabelle form) 
     * alle zugeordneten Formulardaten, ohne Inhalte
     * 
     * @param   Integer $inFormID           ID eines Formulars (siehe Tabelle form)
     * @param   String  $inFromAppId        App des Formulars
     * @return  Array                       Eindimensionales Array mit den  Metadaten des Formulars
     */
    function getFormsdataByFormID($inFormID, $inFormAppId) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();


        $querySelectPart =  "form.*";
        $queryFromPart =    "$db_schema_manager.form 
                                LEFT JOIN $db_schema_manager.feld ON form.id = feld.form_id AND form.app_id = feld.form_app_id";	
        $queryWherePart =   "form.id = $inFormID AND form.app_id ='".$inFormAppId."'";
        $queryGroupbyPart = "form.id, form.app_id";


        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $queryGroupbyPart, "");
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);


        if ($result <> false) {	
            $ergebnisList = Array();

            //Nur die Daten der ersten Zeile der SQL-Rückgabe werden verarbeitet (Theoretisch kann die SQL-Rückgabe auch nur eine Zeile enthalten).
            foreach ($result[0] as $key => $value) {
                $tableAndcolumnName = explode(".",$key);
                $columnName = $tableAndcolumnName[1];
                $ergebnisList["form.".$columnName] = $value;
            }


            //Connection-ID für das Formular hinterlegen
                if($ergebnisList["form.db_schema"] !== "") {
                    //in einigen Fällen kann es sein, dass eine Connection einer anderen App (i.d.R. des Kernmoduls) verwendet werden muss. Dies findet die folgende Methode heraus.
                    $connection_id = getAppIdFromSchema($ergebnisList["form.db_schema"], $ergebnisList["form.app_id"]);
                } 
                //Wenn die Connection-ID nicht emittelt werden konnte, wird die APP-ID des Formulars als Connection-ID verwendet.
                if($connection_id == "" OR $connection_id === false) {$connection_id = $ergebnisList["form.app_id"];}
                $ergebnisList["form.connection_id"] = $connection_id;


            //Primary-Keys werden anhand des information_schema ergänzt
                $ergebnisList["form.primarykey"] = getPkeysFromTable($connection_id, $ergebnisList["form.db_schema"], $ergebnisList["form.db_table"]) ["idFields"];





        } else {
                $ergebnisList = false;
        }	
        return $ergebnisList;
    }


    
    
    /** Ermittelt für ein bestimmtes Feld alle Werte, die bereits in der Datenbank erfasst wurden und den String $in_searchTerm
     * enthalten. Dabei werden die Zugriffsrechte des aktuelle angemeldeten Nutzers und alle conditions des aktuellen
     * Formulars beachtet.
     * 
     * @param   integer     $in_formId      ID des Formulars in dem sich das Feld befindet
     * @param   string      $in_formAppId   APP-ID des Formulars
     * @param   string      $in_searchTerm  String, der in den Werten der Trefferliste enthalten sein muss
     * @param   integer     $in_targetField ID des Feldes
     * @return  mixed       array mit den möglichen Werten oder false. Bsp.: Array(0 => Volvo, 1 => BMW, 2 => Toyota)

     */
    function getSuggestions($in_formId, $in_formAppId, $in_searchTerm, $in_targetField) {
        

        //Form-Array ermitteln
        $formArray = session_class::$session_object->getFormbackup($in_formId);
        //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->formArray: ', $formArray, "INFO");
            
        if($formArray == false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Für dieses Formular ist kein Backup in SESSION vorhanden: ', "Form_ID = ".$formID, "ERROR");
            return false;
        } else {
            $column = getFieldColumnByIdFromSessionBackup($in_formId, $in_formAppId, $in_targetField);
            if(strpos($column, ".") != false) {
                //column entspricht bereits dem Muster table.column
            } elseif($column == "") {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Feld-ID '.$in_targetField, "Es wurde eine AutoComplete-Funktion definiert, aber keine DB-Spalte eingetragen.", "ERROR");
                return false;
            } else {
                $column = $formArray["form.db_table"].".".$column;
            }
            
            $condition = "lower(cast($column as text)) like '%". strtolower($in_searchTerm)."%'";             //column kann bereits in der Syntax table.column vorliegen.
            $limit = getConfig("autocomplete_limit", $in_formAppId);            //Ziel: Datenbankabfrage beschleunigen
            $showMax = getConfig("autocomplete_showmax", $in_formAppId);        //Ziel: Kommunikation zum Client beschleunigen
            
            
            //Wenn am Feld eine Query hinterlegt ist, dann wird diese als Basis für autocomplete verwendet.
            
            
            
            

            If($formArray["form.query_id"] != "") {
            //Wenn Form auf Query bassiert, Query um term ergänzen und Ergebnis abrufen
                
                
                $variablesContainerForQuery = array();
                $variablesContainerForQuery[] = array("type" => "FormArray", "data" => $formArray);             //für den Fall, dass über query_add_condition auf form-Variablen verwiesen wird.
                $variablesContainerForQuery[] = array("type" => "SessionData", "data" => session_class::$session_object->getSessionArrayCurTabAndGlobals());            //für den Fall, dass über query_add_condition auf SESSION-Variablen verwiesen wird.
                $variablesContainerForQuery[] = array("type" => "formFilterCondition", "data" => $condition);   //Einschränkung auf die Zeichen, die der User bisher eingegeben hat.
    //            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> variablesContainerForQuery: ', $variablesContainerForQuery);



                $myQuery = new query();
                $myQuery->initialize_1($formArray["form.query_app_id"], $formArray["form.query_id"], false, $variablesContainerForQuery, $formArray, $formArray["form.connection_id"], false, $limit);
                $result = $myQuery->getQueryResultAsArray();



            } else {
            //Wenn Form auf table bassiert, dann Form-Condition berücksichtigen und Abfrage erstellem
                if($formArray["form.default_condition"] != "") {$condition = $condition." and (".$formArray["form.default_condition"].")";}
                $result = getTableData2($formArray["form.connection_id"], $formArray["form.db_table"], $formArray["form.db_schema"], Array(0 => Array("feld.spalte" => $column)), 0, $column, $condition, __FUNCTION__, $limit);
                
            }
            //Ergebnisliste erstellen (Array, welches nur die Ergebnisse für target-Column enthält.
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> result: ', $result);
            if ($result <> false) {	
                $ergebnisList = Array();
                
                //Ergebnismenge beschränken, da sonst die Performance leidet.
                if(count($result) > $showMax) {
                    $maxErgebnis = $showMax;
                    $addNotice = true;
                } else {
                    $maxErgebnis = count($result);
                    $addNotice = false;
                }
                
                //Nur die Daten der targetColumn der SQL-Rückgabe bleiben erhalten.
                for ($i = 0; $i < $maxErgebnis; $i++) {
                    $row = $result[$i];
                //foreach ($result as $row) {
                    foreach ($row as $col => $value) {
                        if($col == $column) {$ergebnisList[$value] = $value;}
                    }
                }
                if($addNotice == true) {
                    //Hinweis, dass weitere Treffer existieren
                    $more = count($result)-$showMax;
                    if(count($result) == $limit) {
                        $ergebnisList["mehr als ".$limit] = "--mehr als ".$limit."--";
                    } else {
                        $ergebnisList["weitere ".count($result)] = "--weitere ".$more."--";
                    }
                }

            } else {
                $ergebnisList = false;
            }
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ergebnislist: ', $ergebnisList);

            return $ergebnisList;
        
        }
    }

    
    
    
    /** Ermittelt für die übergebenen Daten einer Zeile eines Formulars die Suchergebnismenge.
     * Dabei wird berücksicht, ob das Formular auf einer Tabelle oder einer Query basiert.
     * 
     * @param   integer     $in_formId
     * @param   array       $in_searchTerms     zweidimensioanles Array einer Datenzeiele, wie es standardmäßig allen ajax_request-Funktionen zur Verfügung steht (Parameterliste)
     *                          Bsp.: Array
                                    (
                                        [11505] => Array
                                            (
                                                [formID] => 1842
                                                [fieldAppID] => SYS01
                                                [fieldID] => 11505
                                                [fieldContent] => 
                                                [domID] => 0manager0query_part_select0id0Form1842_1_i0
                                                [ds] => 1
                                                [instance] => i0
                                                [name] => ID
                                                [spalte] => query_part_select.id
                                                [db_schema] => manager
                                                [db_table] => query_part_select
                                                [read_only] => 0
                                                [senderField] => 
                                            )

                                        [11513] => Array
                                            (
                                                [formID] => 1842
                                                [fieldAppID] => SYS01
                                                [fieldID] => 11513
                                                [fieldContent] => ap
                                                [domID] => 0manager0query_part_select0columnname0Form1842_1_i0
                                                [ds] => 1
                                                [instance] => i0
                                                [name] => DB-Spalte
                                                [spalte] => query_part_select.columnname
                                                [db_schema] => manager
                                                [db_table] => query_part_select
                                                [read_only] => 0
                                                [senderField] => 1
                                            )
                                    )
     * @return bool
     */
    function getDynamicSearchResultFromDB($in_formId, $in_searchTerms) {
        $beachte_fieldtype = array(3,5,7,8,15,16,17,18,19,21,48,49,70,71,111,112,636,637,638,639,694,1959);     //Alle Feldtypen, die ein beschreibbares Feld liefern

        //Form-Array ermitteln
        $formArray = session_class::$session_object->getFormbackup($in_formId);
        if($formArray == false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Für dieses Formular ist kein Backup in SESSION vorhanden: ', "Form_ID = ".$formID, "ERROR");
            return false;
        } else {
            $condition = "";
            $delimiter = "";
            $limit = $formArray["form.limit"];
            if($limit == 0) {$limit = getConfig("rows_in_form", global_variables::getAppIdFromSYS01());}
            
            foreach ($in_searchTerms as $field_id => $field_array) {
                if($field_array["fieldContent"] != "" AND in_array($field_array["feldart"] , $beachte_fieldtype)) {
                    $cur_con = "lower(cast(".$field_array["spalte"]." as text)) like '%".strtolower($field_array["fieldContent"])."%'";
                    $condition = $condition.$delimiter.$cur_con;
                    $delimiter = " and ";
                }
            }
            
            
            If($formArray["form.query_id"] != "") {
            //Wenn Form auf Query bassiert, Query um term ergänzen und Ergebnis abrufen
                
                
                $variablesContainerForQuery = array();
                $variablesContainerForQuery[] = array("type" => "FormArray", "data" => $formArray);             //für den Fall, dass über query_add_condition auf form-Variablen verwiesen wird.
                $variablesContainerForQuery[] = array("type" => "SessionData", "data" => session_class::$session_object->getSessionArrayCurTabAndGlobals());            //für den Fall, dass über query_add_condition auf SESSION-Variablen verwiesen wird.
                $variablesContainerForQuery[] = array("type" => "formFilterCondition", "data" => $condition);   //Einschränkung auf die Zeichen, die der User bisher eingegeben hat.
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> variablesContainerForQuery: ', $variablesContainerForQuery);



                $myQuery = new query();
                $myQuery->initialize_1($formArray["form.query_app_id"], $formArray["form.query_id"], false, $variablesContainerForQuery, $formArray, $formArray["form.connection_id"], $limit);
                $result = $myQuery->getQueryResultAsArray();
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> result: ', $result);


            } else {
            //Wenn Form auf table bassiert, dann Form-Condition berücksichtigen und Abfrage erstellem
                if($formArray["form.default_condition"] != "") {$condition = $condition." and (".$formArray["form.default_condition"].")";}
                $result = getTableData($formArray["form.connection_id"], $formArray["form.db_table"], $formArray["form.db_schema"], false, "", $condition, __FUNCTION__, $limit);
            }
            
            
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ergebnislist: ', $result);

            return $result;
        
        }
    }
    
    

    /** Ermittelt die Grunddaten eines Workflows (workflow und workflow_step)
     * Die Ergebnismenge ist nach Steps aufwärts sortiert.
     * Es werden nur Controlforms je Step ermittelt.
     * 
     * @param   string  $in_workflow_app_id     APP-ID des workflows
     * @param   integer $in_workflow_id
     * @param   integer $in_workflow_version
     * @return  mixed                           Array oder false.
     */
    function getWorkflowBasicdata($in_workflow_app_id, $in_workflow_id, $in_workflow_version) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

        $querySelectPart = "workflow.app_id
                            , workflow.workflow_id
                            , workflow.version
                            , workflow.name
                            , workflow.description
                            , workflow_step.step
                            , workflow_step.name
                            , workflow_step.description
                            , workflow_step_form.form_app_id as workflow_controlform_app_id
                            , workflow_step_form.form_id as workflow_controlform_id
                            , workflow_step_form.is_workf_control_form
                            ,MIN(ws2.step) as min_step
                            ,MAX(ws2.step) as max_step";
        
        $queryFromPart =    "$db_schema_manager.workflow
                                INNER JOIN $db_schema_manager.workflow_step as workflow_step ON (1=1) AND workflow_step.app_id = workflow.app_id AND workflow_step.workflow_id = workflow.workflow_id AND workflow_step.version = workflow.version 
                                INNER JOIN $db_schema_manager.workflow_step as ws2 ON (1=1) AND ws2.app_id = workflow.app_id AND ws2.workflow_id = workflow.workflow_id AND ws2.version = workflow.version	
                                INNER JOIN $db_schema_manager.workflow_step_form as workflow_step_form ON (1=1) AND workflow_step_form.app_id = workflow_step.app_id AND workflow_step_form.workflow_id = workflow_step.workflow_id AND workflow_step_form.version = workflow_step.version AND workflow_step_form.step = workflow_step.step and workflow_step_form.is_workf_control_form = 1 "; 
                                        
        $queryWherePart =      "workflow.app_id = '$in_workflow_app_id'
                                and workflow.workflow_id = $in_workflow_id
                                and workflow.version = $in_workflow_version";
        
        $queryGroupbyPart =    "workflow.app_id
                                , workflow.workflow_id
                                , workflow.version
                                , workflow.name
                                , workflow.description
                                , workflow_step.step
                                , workflow_step.name
                                , workflow_step.description
                                , workflow_step_form.form_app_id 
                                , workflow_step_form.form_id 
                                , workflow_step_form.is_workf_control_form";
        
        $queryOrderbyPart =    "workflow_step.step";


        $queryRequest = new sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $queryGroupbyPart, $queryOrderbyPart);
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);


        
        return $result;
    }

    
    
    
    
    /** Ermittelt anhand einer URL-ID einen DS aus der Tabelle workflow_status
     * 
     * @param   string      $in_workflow_app_id     APP-ID des Workflows/Instanz
     * @param   string      $in_url_id              Eindeutiger Identifier eines Status-Satzes aus der Tabelle workflow_status
     * @return  array                               Zeidiemnsionaler Array, der dem Datensatz der Tabelle entspricht, inkl. einzelner Attribute der Tabelle workflow_instance
     */
    function getWorkflowStatus($in_workflow_app_id, $in_url_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

        $querySelectPart =  "workflow_status.app_id
                                , workflow_status.workflow_id
                                , workflow_status.version
                                , workflow_status.step
                                , workflow_status.instance_id
                                , workflow_status.timestamp_edit
                                , workflow_status.editor
                                , workflow_status.con1
                                , workflow_status.con2
                                , workflow_status.con3
                                , workflow_status.wkfl_comment
                                , workflow_status.email_to
                                , workflow_status.email_cc
                                , workflow_status.email_from
                                , workflow_status.email_bcc
                                , workflow_status.finished
                                , workflow_instance.instance_name
                                , workflow_status.repeat_step_count
                                , workflow_status.back_to_step";
        
        $queryFromPart =    "$db_schema_manager.workflow_status
                                INNER JOIN $db_schema_manager.workflow_instance 
                                        ON workflow_instance.app_id = workflow_status.app_id
                                        AND workflow_instance.workflow_id = workflow_status.workflow_id
                                        AND workflow_instance.version = workflow_status.version
                                        AND workflow_instance.instance_id = workflow_status.instance_id"; 
                                        
        $queryWherePart =      "workflow_status.app_id = '$in_workflow_app_id'
                                AND workflow_status.url_id = '$in_url_id'";
        
        $queryGroupbyPart =    "";
        
        $queryOrderbyPart =    "";


        $queryRequest = new sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $queryGroupbyPart, $queryOrderbyPart);
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);


        
        return $result;
    }





    /** Ermittelt für ein Formular, ob es auf einer bestimmten Maske den Dependence-Typ refernce oder refernece_show besitzt.
     * Außerdem wird, bei abhängigen Formularen auch das Source-Formular ermittelt.
     * 
     * @param   string  $in_mask_app_id         APP_id der Maske, auf der sich target_form_id befindet
     * @param   integer $in_mask_id             ID der Maske
     * @param   integer $in_target_form_id      ID des target-Formulars
     * @return  mixed                           $feedback = array(  "dependence_type"       => [reference|reference_show]],
                                                                    "source_form_app_id"    => [SYS01|...],
                                                                    "source_form_id"        => [1|2|3|...]) oder false, wenn keine Abhängigkeit besteht.
     */
    function getFormDependenceType($in_mask_app_id, $in_mask_id, $in_target_form_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        $querySelectPart =  "max(dependence_type) as dependence_type, form_dependence.form_app_id, form_dependence.form_id";
        $queryFromPart =    "$db_schema_manager.form_dependence ";	
        $queryWherePart =   "mask_id = ".$in_mask_id." AND mask_app_id = '".$in_mask_app_id."' AND target_form_id = ".$in_target_form_id;
        $queryGroupbyPart = "dependence_type, form_app_id, form_id ";


        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $queryGroupbyPart, "");
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
    
        if ($result <> false) {	
            $feedback = array(  "dependence_type"       => $result[0][".dependence_type"],
                                "source_form_app_id"    => $result[0]["form_dependence.form_app_id"],
                                "source_form_id"        => $result[0]["form_dependence.form_id"]);
        } else {
            $feedback = false;
        }	
        
        
        return $feedback;
    }




/** Ermittelt für ein Formular die zugeordneten Symbolgruppen.
 * 
 * @param   Integer     $in_FormID              ID des Formulars, für welches die zugeordneten Symbolgruppen ermittelt werden sollen
 * @param   string      $in_formApp             ID einer App (Bsp.: SYS01)
 * @param   Integer     $in_Symbolgroup_type    Type der Symbolgruppen (1 = top, 2 = bottom)
 * @return  mixed                               Zweidimensionales Array. Äußeres Array = Liste von Symbolgruppen; Inneres Array enthält Details zu den Symbolgruppen oder Boolean (false)
 */
function getSymbolgroupsByFormID($in_FormID, $in_formApp, $in_Symbolgroup_type) {
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    $role_id = session_class::$session_object->getActiveRoleId();
    $role_app_id = session_class::$session_object->getActiveRoleAppId();
    
    
    /* Select auf eine beliebige Tabelle */
     $querySelectPart =     "html_tag.form_id
                            , html_tag.form_app_id
                            -- , htmltaggroup.name as symbolgruppe_name
                            -- , htmltaggroup_has_form.form_id as form_id
                            -- , htmltaggroup_has_form.grouptype as symbolgruppe_type
                            -- , htmltaggroup_has_form.sort as sort ";
    
    $queryFromPart =        "$db_schema_manager.htmltaggroup_has_form
                            , $db_schema_manager.htmltaggroup
                            , $db_schema_manager.htmltaggroup_has_html_tag
                            , $db_schema_manager.html_tag
                                LEFT JOIN $db_schema_manager.form_group_has_form ON form_group_has_form.form_id = html_tag.form_id AND form_group_has_form.form_app_id = html_tag.form_app_id
				LEFT JOIN $db_schema_manager.form_group ON form_group.app_id = form_group_has_form.form_group_app_id AND form_group.id = form_group_has_form.form_group_id
				LEFT JOIN $db_schema_manager.role_has_form_group ON form_group.app_id = role_has_form_group.form_group_app_id AND form_group.id = role_has_form_group.form_group_id AND
					role_has_form_group.role_app_id = '$role_app_id' AND role_has_form_group.role_id = $role_id ";
   
    $queryWherePart =       "htmltaggroup_has_form.htmltaggroup_id = htmltaggroup.id 
                            AND htmltaggroup_has_form.htmltaggroup_app_id = htmltaggroup.app_id  
                            AND htmltaggroup.id = htmltaggroup_has_html_tag.htmltaggroup_id 
                            AND htmltaggroup.app_id = htmltaggroup_has_html_tag.htmltaggroup_app_id  
                            AND htmltaggroup.is_symbolgroup = 1 
                            AND htmltaggroup_has_html_tag.html_tag_id = html_tag.id 
                            AND htmltaggroup_has_html_tag.html_tag_app_id = html_tag.app_id   
                            AND htmltaggroup_has_form.form_id = $in_FormID
                            AND htmltaggroup_has_form.form_app_id ='$in_formApp'
                            AND htmltaggroup_has_form.grouptype = $in_Symbolgroup_type
                            AND (role_has_form_group.access_type <> 0 OR role_has_form_group.access_type is null) ";
    
    
    $queryGroupByPart =     "html_tag.form_id, html_tag.form_app_id, htmltaggroup_has_form.sort";
    
    $queryOrderbyPart =     "htmltaggroup_has_form.sort";
       

    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
    $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, $queryGroupByPart, $queryOrderbyPart);
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
    
    
    return $result;
}




/** Ermittelt die Liste der SELECT-Collumns
 * 
 * @param       string  $in_query_app_id                    APP-ID einer query
 * @param       integer $in_query_id                        ID einer query
 * @return      mixed                                       array mit den Werten aus der DB-Tabelle query_part_select oder false
 */
function getQuerySelectPart($in_query_app_id, $in_query_id) {
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
        $queryRequest->addSelectColumn("query_part_select", "query_part_from_id");
        $queryRequest->addSelectColumn("query_part_select", "id");
        $queryRequest->addSelectColumn("query_part_select", "columnname");
        $queryRequest->addSelectColumn("query_part_select", "alias");
        $queryRequest->addSelectColumn("query_part_select", "const");
        $queryRequest->addSelectColumn("query_part_select", "function_id");
        $queryRequest->addSelectColumn("query_part_select", "function_params");
        $queryRequest->addSelectColumn("query_part_select", "sort");
        $queryRequest->addSelectColumn("query_part_select", "hidden");
        
        $queryRequest->addTable($db_schema_manager, "query_part_select", 1, "BASE");
        
        $queryRequest->addWhereCondition("AND",    "", "query_part_select", "query_part_from_query_app_id",  "=", "'".$in_query_app_id."'",        "");
        $queryRequest->addWhereCondition("AND", "", "query_part_select", "query_part_from_query_id",      "=", $in_query_id, "");
        
        $queryRequest->addOrderbyPart("sort");

    $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
     
    
    
    return $queryResult;
}



/** Ermittelt die Liste dr beteiligten Formulare eines WorkflowSteps und kennzeichnet das ControlForm.
 * 
 * @param   string      $in_app_id                          APP-ID des Workflows
 * @param   integer     $in_workflow_id     
 * @param   integer     $in_version
 * @param   boolean     $in_only_control_form               Gibt an, dass nur die Controlform des aktuellen Steps ermittelt werden soll.
 * @return  mixed                                           Array der Formulare (form_app_id, form_id, is_workf_control_form) oder false
 */
function getWorkflowForms($in_app_id, $in_workflow_id, $in_version, $in_only_control_form) {
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
        $queryRequest->addSelectColumn("workflow_step_form", "step");
        $queryRequest->addSelectColumn("workflow_step_form", "form_app_id");
        $queryRequest->addSelectColumn("workflow_step_form", "form_id");
        $queryRequest->addSelectColumn("workflow_step_form", "is_workf_control_form");
        
        $queryRequest->addTable($db_schema_manager, "workflow_step_form", 1, "BASE");
        
        $queryRequest->addWhereCondition("AND", "", "workflow_step_form", "app_id",      "=", "'".$in_app_id."'",        "");
        $queryRequest->addWhereCondition("AND", "", "workflow_step_form", "workflow_id", "=", $in_workflow_id, "");
        $queryRequest->addWhereCondition("AND", "", "workflow_step_form", "version", "=", $in_version, "");
        if($in_only_control_form === true) {$queryRequest->addWhereCondition("AND", "", "workflow_step_form", "is_workf_control_form", "=", 1, "");}

    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
    
    
    if($result == false) {
        $feedback = array();
        
    } else {
        $feedback = array();
        foreach ($result as $key => $current_step) {
            $feedback[$current_step["workflow_step_form.step"]] [$current_step["workflow_step_form.form_id"]] ["step"] = $current_step["workflow_step_form.step"];
            $feedback[$current_step["workflow_step_form.step"]] [$current_step["workflow_step_form.form_id"]] ["form_app_id"] = $current_step["workflow_step_form.form_app_id"];
            $feedback[$current_step["workflow_step_form.step"]] [$current_step["workflow_step_form.form_id"]] ["form_id"] = $current_step["workflow_step_form.form_id"];
            $feedback[$current_step["workflow_step_form.step"]] [$current_step["workflow_step_form.form_id"]] ["is_workf_control_form"] = $current_step["workflow_step_form.is_workf_control_form"];
            $feedback["all_forms"][$current_step["workflow_step_form.form_id"]] = $current_step["workflow_step_form.form_id"];
        }
        
    }
    return $feedback;
    
}





/** Ermittelt die Liste der FROM-Tables
 * 
 * @param       string  $in_query_app_id                    APP-ID einer query
 * @param       integer $in_query_id                        ID einer query
 * @return      mixed                                       array mit den Werten aus der DB-Tabelle query_part_from oder false
 */
function getQueryFromPart($in_query_app_id, $in_query_id) {
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
        $queryRequest->addSelectColumn("query_part_from", "id");
        $queryRequest->addSelectColumn("query_part_from", "db_schema");
        $queryRequest->addSelectColumn("query_part_from", "tablename");
        $queryRequest->addSelectColumn("query_part_from", "alias");
        $queryRequest->addSelectColumn("query_part_from", "jointype");
        $queryRequest->addSelectColumn("query_part_from", "sort");
        
        $queryRequest->addTable($db_schema_manager, "query_part_from", 1, "BASE");
        
        $queryRequest->addWhereCondition("AND",    "", "query_part_from", "query_app_id",  "=", "'".$in_query_app_id."'",        "");
        $queryRequest->addWhereCondition("AND", "", "query_part_from", "query_id",      "=", $in_query_id, "");
        
        $queryRequest->addOrderbyPart("sort");

    $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
     
    
    
    return $queryResult;
}




/** Ermittelt die Liste der Conditions, die im Join-Part ergänzt werden sollen
 * 
 * @param       string  $in_query_app_id                    APP-ID einer query
 * @param       integer $in_query_id                        ID einer query
 * @return      mixed                                       array mit den Werten aus der DB-Tabelle query_part_join oder false
 */
function getQueryJoinPart($in_query_app_id, $in_query_id) {
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
        $queryRequest->addSelectColumn("query_part_join_condition", "query_part_from_id");
        $queryRequest->addSelectColumn("query_part_join_condition", "id");
        $queryRequest->addSelectColumn("query_part_join_condition", "calm_open");
        $queryRequest->addSelectColumn("query_part_join_condition", "praefix");
        $queryRequest->addSelectColumn("query_part_join_condition", "left_column");
        $queryRequest->addSelectColumn("query_part_join_condition", "left_column_format");
        $queryRequest->addSelectColumn("query_part_join_condition", "operator");
        $queryRequest->addSelectColumn("query_part_join_condition", "right_table");
        $queryRequest->addSelectColumn("query_part_join_condition", "right_column");
        $queryRequest->addSelectColumn("query_part_join_condition", "right_column_format");
        $queryRequest->addSelectColumn("query_part_join_condition", "calm_close");
        $queryRequest->addSelectColumn("query_part_join_condition", "sort");
        
        $queryRequest->addTable($db_schema_manager, "query_part_join_condition", 1, "BASE");
        
        $queryRequest->addWhereCondition("AND",    "", "query_part_join_condition", "query_part_from_query_app_id",  "=", "'".$in_query_app_id."'",        "");
        $queryRequest->addWhereCondition("AND", "", "query_part_join_condition", "query_part_from_query_id",      "=", $in_query_id, "");
        
        $queryRequest->addOrderbyPart("query_part_from_id, sort");

    $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
     
    
    
    return $queryResult;
}



/** Ermittelt die Liste der zusätzlichen Conditions, die im Join-Part ergänzt werden sollen
 * AddConditions, welche sich auf die Base-Tabelle beziehen, werden im Where-Part ergänzt
 * 
 * @param       string  $in_query_app_id                    APP-ID einer query
 * @param       integer $in_query_id                        ID einer query
 * @param       string  $in_form_id                         [optional] ID des aktuellen Formulars; Manche add_conditions gelten nur für bestimmte Formulare
 * @return      array                                       array mit den Werten aus der DB-Tabelle query_part_addcondition. Wenn keine AddCondition ermittelt werden konnte wird ein leeres array zurückgegeben.
 */
function getQueryAddConditionPart($in_query_app_id, $in_query_id, $in_form_id = false) {
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
        $queryRequest->addSelectColumn("query_add_condition", "query_part_from_id");
        $queryRequest->addSelectColumn("query_add_condition", "id");
        $queryRequest->addSelectColumn("query_add_condition", "calm_open");
        $queryRequest->addSelectColumn("query_add_condition", "praefix");
        $queryRequest->addSelectColumn("query_add_condition", "columnname");
        $queryRequest->addSelectColumn("query_add_condition", "operator");
        $queryRequest->addSelectColumn("query_add_condition", "value");
        $queryRequest->addSelectColumn("query_add_condition", "value_internvariable");
        $queryRequest->addSelectColumn("query_add_condition", "calm_close");
        $queryRequest->addSelectColumn("query_add_condition", "sort");
        
        $queryRequest->addTable($db_schema_manager, "query_add_condition", 1, "BASE");
        
        $queryRequest->addWhereCondition("AND",    "", "query_add_condition", "query_part_from_query_app_id",  "=", "'".$in_query_app_id."'",        "");
        $queryRequest->addWhereCondition("AND", "", "query_add_condition", "query_part_from_query_id",      "=", $in_query_id, "");
        if($in_form_id != false) {
            $queryRequest->addWhereCondition("AND", "(", "query_add_condition", "form_id",      "=", $in_form_id, "");
            $queryRequest->addWhereCondition("OR", "", "query_add_condition", "form_id",      "is", "NULL", ")");
        }
        
        $queryRequest->addOrderbyPart("query_part_from_id, sort");

    $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
     
    
    if ($queryResult == false) {$feedback = array();} else {$feedback = $queryResult;}
    return $feedback;
}




/** Ermittelt die Liste der Columns, nach denen sortiertwerden soll.
 * 
 * @param       string  $in_query_app_id                    APP-ID einer query
 * @param       integer $in_query_id                        ID einer query
 * @return      mixed                                       array mit den Werten aus der DB-Tabelle query_part_orderby oder false
 */
function getQueryOrderByPart($in_query_app_id, $in_query_id) {
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
        $queryRequest->addSelectColumn("query_part_orderby", "query_part_select_query_part_from_id");
        $queryRequest->addSelectColumn("query_part_orderby", "query_part_select_id");
        $queryRequest->addSelectColumn("query_part_orderby", "sort");
        $queryRequest->addSelectColumn("query_part_select", "columnname");
        $queryRequest->addSelectColumn("query_part_select", "alias");
        $queryRequest->addSelectColumn("query_part_orderby", "sortorder");
        
        $queryRequest->addTable($db_schema_manager, "query_part_orderby", 1, "BASE");
        $queryRequest->addTable($db_schema_manager, "query_part_select", 2, "INNER");
        
        $queryRequest->addWhereCondition("AND",    "", "query_part_orderby", "query_part_select_query_part_from_query_app_id",  "=", "'".$in_query_app_id."'",        "");
        $queryRequest->addWhereCondition("AND", "", "query_part_orderby", "query_part_select_query_part_from_query_id",      "=", $in_query_id, "");
        $queryRequest->addWhereCondition("AND", "", "query_part_orderby", "query_part_select_query_part_from_query_app_id",      "=", "query_part_select.query_part_from_query_app_id", "");
        $queryRequest->addWhereCondition("AND", "", "query_part_orderby", "query_part_select_query_part_from_query_id",      "=", "query_part_select.query_part_from_query_id", "");
        $queryRequest->addWhereCondition("AND", "", "query_part_orderby", "query_part_select_query_part_from_id",      "=", "query_part_select.query_part_from_id", "");
        $queryRequest->addWhereCondition("AND", "", "query_part_orderby", "query_part_select_id",      "=", "query_part_select.id", "");
        
        $queryRequest->addOrderbyPart("sort");

    $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
//    $query = $queryRequest->getSelectCommand();
//    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> query für OrderBy-List: ', $query); 
    
    
    return $queryResult;
}



/** Ermittelt die Liste der Columns, nach denen gruppiert werden soll.
 * 
 * @param       string  $in_query_app_id                    APP-ID einer query
 * @param       integer $in_query_id                        ID einer query
 * @return      mixed                                       array mit den Werten aus der DB-Tabelle query_part_groupby oder false
 */
function getQueryGroupByPart($in_query_app_id, $in_query_id) {
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
        
        $queryRequest->addSelectColumn("query_part_groupby", "query_part_select_query_part_from_id");
        $queryRequest->addSelectColumn("query_part_groupby", "query_part_select_id");
        $queryRequest->addSelectColumn("query_part_groupby", "sort");
        $queryRequest->addSelectColumn("query_part_select", "columnname");
        $queryRequest->addSelectColumn("query_part_select", "alias");
        
        $queryRequest->addTable($db_schema_manager, "query_part_groupby", 1, "BASE");
        $queryRequest->addTable($db_schema_manager, "query_part_select", 2, "INNER");
        
        $queryRequest->addWhereCondition("AND",    "", "query_part_groupby", "query_part_select_query_part_from_query_app_id",  "=", "'".$in_query_app_id."'",        "");
        $queryRequest->addWhereCondition("AND", "", "query_part_groupby", "query_part_select_query_part_from_query_id",      "=", $in_query_id, "");
        $queryRequest->addWhereCondition("AND", "", "query_part_groupby", "query_part_select_query_part_from_query_app_id",      "=", "query_part_select.query_part_from_query_app_id", "");
        $queryRequest->addWhereCondition("AND", "", "query_part_groupby", "query_part_select_query_part_from_query_id",      "=", "query_part_select.query_part_from_query_id", "");
        $queryRequest->addWhereCondition("AND", "", "query_part_groupby", "query_part_select_query_part_from_id",      "=", "query_part_select.query_part_from_id", "");
        $queryRequest->addWhereCondition("AND", "", "query_part_groupby", "query_part_select_id",      "=", "query_part_select.id", "");
        
        $queryRequest->addOrderbyPart("sort");

    $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
     
    
    
    return $queryResult;
}




/** Ermittelt alle CSS-Style-Elemente und deren Attribute eines Templates
 * 
 * @param   Integer $in_templateId      ID des Templates
 * @param   String  $in_template_app_id App_id des Templates 
 * @param   string  $in_mask_app_id     App_ID der Maske, dessen CSS-Attribute geladen werden sollen.
 * @return  Array                       zweidimensionales Array Ebene 1 = Name des Style-Elements, Ebene 2 = zugeordnete Attribute (key = Attributname, value = Attributwert)
 */
function getCssAttributList($in_templateId, $in_templateAppId, $in_mask_app_id) {														
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

    /* Select auf eine beliebige Tabelle */
    $querySelectPart =  "style_element.css_template_id as template_id
                            , style_element.id as style_element_id
                            , style_element.name as style_element_name
                            , style_element.css_type_id as style_element_type
                            , style_element.add_attribut as style_element_add_attribut
                            , style_element.add_attribut_value as style_element_add_attribut_value
                            , css_type.prefix as css_prefix
                            , css_type.type_name as css_type_name
                            , css_type.sufix as css_sufix
                            , css_attribut.id as attribut_id
                            , css_attribut.attribut_name as attribut_name
                            , css_attribut.value as attribut_value
                            , html_tag_has_style_element.html_tag_id
                            , html_tag.name
                            , html_tag.form_app_id
                        , CONCAT(html_tag.name,'_',html_tag_has_style_element.html_tag_id) as test
                            , CASE WHEN css_type.type_name = 'id' THEN 
                                    CASE WHEN html_tag.name is NULL THEN
                                            style_element.name
                                    ELSE CONCAT(html_tag.name,'_',html_tag_has_style_element.html_tag_id) 
                                    END
                              ELSE style_element.name END  as name_for_css";
                     
    $queryFromPart =    "$db_schema_manager.style_element
                            LEFT OUTER JOIN $db_schema_manager.html_tag_has_style_element as html_tag_has_style_element ON style_element.id = html_tag_has_style_element.style_element_id AND style_element.app_id = html_tag_has_style_element.style_element_app_id
                            LEFT OUTER JOIN $db_schema_manager.html_tag ON html_tag_has_style_element.html_tag_id = html_tag.id AND html_tag_has_style_element.html_tag_app_id = html_tag.app_id
                        , $db_schema_manager.css_attribut
                        , $db_schema_manager.css_type";
    
    $queryWherePart =   "style_element.css_template_id = $in_templateId 
                        AND style_element.css_template_app_id = '$in_templateAppId'
                        AND css_attribut.style_element_id = style_element.id 
                        AND css_attribut.style_element_app_id = style_element.app_id
                        AND style_element.css_type_id = css_type.id
                        AND style_element.css_type_app_id = css_type.app_id";
    
    $queryOrderbyPart = "style_element.css_type_id, name_for_css, css_attribut.id";
     
    
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
    $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, "", $queryOrderbyPart);
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
    

    if($result <> false) {
        $ergebnisList = Array();
        for($i = 0; $i < count($result); $i++) {
            if (array_key_exists($result[$i]["style_element.style_element_id"], $ergebnisList)) {
                //Wenn bereits ein key für den Tagname der aktuellen Zeile in $ergebnisList existiert, dann nur die Attributwerte hinzufügen
                $ergebnisList[$result[$i]["style_element.style_element_id"]] ["attribut_list"] [$result[$i]["css_attribut.attribut_name"]] = str_replace("§§app_id§§",$in_mask_app_id,$result[$i]["css_attribut.attribut_value"]);
                //$ergebnisList[$result[$i]["style_element.style_element_id"]] ["attribut_list"] [$result[$i]["css_attribut.attribut_name"]] = $result[$i]["css_attribut.attribut_value"];
            } else {
                //Ansonsten einen neuen Arrayeintrag mit zwei nachgeordneten Arrays  hinzufügen
                $ergebnisList[$result[$i]["style_element.style_element_id"]] = array("style_element_info" => array(), "attribut_list" => array());
                //Die allegemeinen Informationen zum style_element eintragen
                $ergebnisList[$result[$i]["style_element.style_element_id"]] ["style_element_info"] ["name_for_css"] = $result[$i][".name_for_css"];
                $ergebnisList[$result[$i]["style_element.style_element_id"]] ["style_element_info"] ["css_type_name"] = $result[$i]["css_type.css_type_name"];
                $ergebnisList[$result[$i]["style_element.style_element_id"]] ["style_element_info"] ["css_prefix"] = $result[$i]["css_type.css_prefix"];
                $ergebnisList[$result[$i]["style_element.style_element_id"]] ["style_element_info"] ["css_sufix"] = $result[$i]["css_type.css_sufix"];
                $ergebnisList[$result[$i]["style_element.style_element_id"]] ["style_element_info"] ["style_element_add_attribut"] = $result[$i]["style_element.style_element_add_attribut"];
                $ergebnisList[$result[$i]["style_element.style_element_id"]] ["style_element_info"] ["style_element_add_attribut_value"] = $result[$i]["style_element.style_element_add_attribut_value"];
                //Den ersten Attributwert eintragen
                $ergebnisList[$result[$i]["style_element.style_element_id"]] ["attribut_list"] [$result[$i]["css_attribut.attribut_name"]] = str_replace("§§app_id§§",$in_mask_app_id,$result[$i]["css_attribut.attribut_value"]);

            }
        }
    } else {
        $ergebnisList = false;
    }	
//    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> CSS-Attributlist: ', $ergebnisList);
    
    return $ergebnisList;
    
    
    
}





//Todo: Prüfen, ob die Funktionen getTaglistFromMask, buildFormArray und getTagArray redundant sind.
/** Ermittelt eine Liste aller Tags (ohne initiales html-tag), die auf einer Maske verwendet werden (siehe Tabelle html_tag).
 *  Oder ermittelt nur die Angaben des initialen html-tags. Dieses wird benötigt, um ein neues Objekt von HtmlDomTree erzeugen zu können.
 * 
 * @param   Integer $in_maskId          ID der Maske, deren Html_tags ermittelt werden sollen
 * @param   String  $in_maskAppId       ID der App der MAsk, deren tags ermitelt erden sollen
 * @param   Boolean $in_onlyHtmlTag     Gibt an, ob nur das html-Tag ermittelt werden soll, oder alle anderen (ohne html_tag)
 * @param   string  $in_currentuser
 * @return  array                       Zweidimensinales Array
 */
function getTaglistFromMask($in_maskId, $in_maskAppId, $in_onlyHtmlTag, $in_currentuser) {														
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    //prüfen, ob spezielle Formulare für root angedruckt werden sollen
    $is_a_root = strpos($in_currentuser, "root");
    if($is_a_root !== false AND $in_maskAppId == global_variables::getAppIdFromSYS01()) {
        $form_active_values = "1,2";
    } else {
        $form_active_values = "1";
    }
    
    if ($in_onlyHtmlTag == true) {$zusatzbedingung = " html_tag.name = 'html' ";} else {$zusatzbedingung = " html_tag.name <> 'html' ";}
    
    /* Select auf eine beliebige Tabelle */
    $querySelectPart =      "html_tag.*
                            , COALESCE(html_tag.parent_tag,0) as parent
                            , html_tag.form_id
                            , case form_id when 100 then 0 else 1 end as sys_tags";
                            
    $queryFromPart =        "$db_schema_manager.mask_has_htmltaggroup as mhh
			    , $db_schema_manager.htmltaggroup_has_html_tag as hhht
                            , $db_schema_manager.html_tag";

    $queryWherePart =       "mhh.htmltaggroup_id = hhht.htmltaggroup_id
			    AND mhh.htmltaggroup_app_id = hhht.htmltaggroup_app_id
                            AND hhht.html_tag_id = html_tag.id
                            AND hhht.html_tag_app_id = html_tag.app_id
                            AND hhht.relationtyp in (1, 11)                            -- nur eigenständige Formulare
                            AND hhht.active in ($form_active_values) 
                            AND mhh.mask_id = $in_maskId 
                            AND mhh.mask_app_id = '$in_maskAppId'
                            AND $zusatzbedingung";
                           
    $queryOrderbyPart =     "sys_tags, parent, sort";
     
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
    $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, "", $queryOrderbyPart);
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true); 
     


    return $result;
    
}




/** Erstellt das Array für das htmltag der aktuellen Form
 * 
 * @param       string          $in_form_app_id             App ID des Formulars
 * @param       integer         $in_form_id                 ID des Formulars
 * @param       integer         $in_htmltaggroup_id         htmltaggroupID des Formulars
 * @return boolean
 */
function getTagArray( $in_form_app_id, $in_form_id) {														
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    
    //Todo: die Abfrage ist nicht eindeutig, wenn ein Formular in mehreren MAsken zugeordnet ist. Es sollte noch htmltaggroup_id beachtet werden
    /* Select auf eine beliebige Tabelle */
     $querySelectPart =     "html_tag.*
                            , COALESCE(html_tag.parent_tag,0) as parent
                            , html_tag.form_id";

    $queryFromPart =        "$db_schema_manager.htmltaggroup_has_html_tag
                            , $db_schema_manager.html_tag";

    $queryWherePart =       "htmltaggroup_has_html_tag.html_tag_id = html_tag.id
                            AND htmltaggroup_has_html_tag.html_tag_app_id = html_tag.app_id
                            AND html_tag.form_app_id = '$in_form_app_id'
                            AND html_tag.form_id = $in_form_id";      

    $queryOrderbyPart =     "parent, sort";
     
    
     
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
    $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, "", $queryOrderbyPart);
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__); 
    
    

    return $result;
    
}




/** Ermittelt eine Liste html_tag_ids und deren zugehöriger css-Klassen. 
 * 
 * @param   Integer $in_template_Id_list    ID des css-template, dessen Klassen ermittelt werden sollen
 * @param   string  $in_app_id              App_id von DB-Tabelle css_template/ style_element
 * @param   integer $in_mask_id             ID der Maske, dessen classList ermittelt werden soll
 * @param   string  $in_mask_app_id         APP_id der Maske
 * @return  array                           eindimensionales Array (key = html_tag_id, value = Durch Leerzeichen gtrennte Liste aller Klassenname)
 */
function getClasslistforTemplate($in_template_Id_list, $in_app_id, $in_mask_id, $in_mask_app_id) {														
    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    $kernel_app_id = global_variables::getAppIdFromSYS01();
    
    //Template-ID-List in String umwandeln
    $template_list = arrayToString($in_template_Id_list, "integer");
    
    
    /* Select auf eine beliebige Tabelle */
     $querySelectPart =     "style_element.id
                            , style_element.css_template_id
                            , style_element.name
                            , html_tag_has_style_element.html_tag_id
                            , html_tag_has_style_element.html_tag_app_id";
                    
    $queryFromPart =        "$db_schema_manager.style_element
                            , $db_schema_manager.html_tag_has_style_element 
                            , $db_schema_manager.html_tag
                            , $db_schema_manager.htmltaggroup_has_html_tag
                            , $db_schema_manager.htmltaggroup
                            , $db_schema_manager.mask_has_htmltaggroup";
                     
    $queryWherePart =       "style_element.id = html_tag_has_style_element.style_element_id
                            AND style_element.app_id = html_tag_has_style_element.style_element_app_id
                            AND style_element.app_id = '$kernel_app_id'
                            AND style_element.css_template_id in ($template_list) 
                            AND style_element.css_type_id = 2 
                            AND style_element.css_type_app_id = '$kernel_app_id' 
                            AND html_tag_has_style_element.html_tag_id = html_tag.id
                            AND html_tag_has_style_element.html_tag_app_id = html_tag.app_id
                            AND html_tag.id = htmltaggroup_has_html_tag.html_tag_id
                            AND html_tag.app_id = htmltaggroup_has_html_tag.html_tag_app_id
                            AND htmltaggroup_has_html_tag.htmltaggroup_id = htmltaggroup.id
                            AND htmltaggroup_has_html_tag.htmltaggroup_app_id = htmltaggroup.app_id
                            AND htmltaggroup.id = mask_has_htmltaggroup.htmltaggroup_id
                            AND htmltaggroup.app_id = mask_has_htmltaggroup.htmltaggroup_app_id
                            AND mask_has_htmltaggroup.mask_id = $in_mask_id
                            AND mask_has_htmltaggroup.mask_app_id = '$in_mask_app_id'";

    
    $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
    $queryRequest->addSelectComplexStatement($querySelectPart, $queryFromPart, $queryWherePart, "", "");
    $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__); 
     
    
    if ($result <> false) {	
            
            $ergebnisList = Array();
           

            for ($i = 0; $i < count($result); $i++) {
                
                if (isset($ergebnisList[$result[$i]["html_tag_has_style_element.html_tag_id"]])) {   
                    //wenn bereits ein array-Eintrag für den aktuellen Schlüssel (html_tag_id) existiert
                    $ergebnisList[$result[$i]["html_tag_has_style_element.html_tag_id"]] = $ergebnisList[$result[$i]["html_tag_has_style_element.html_tag_id"]]." ".$result[$i]["style_element.name"];
                } else {
                    //wenn noch kein array-Eintrag für den aktuellen Schlüssel (tag_id) existiert
                    $ergebnisList[$result[$i]["html_tag_has_style_element.html_tag_id"]] = $result[$i]["style_element.name"];
                }
                    
            }


    } else {
        $ergebnisList = false;
    }	
    
    
    
    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> CSS-ClassList: ', $ergebnisList);
    return $ergebnisList;
    
}





    //deprecated, da die Funktion mit selectOnDatabase_old , stattdessen getTableData nutzen
    /** Reicht einen vorgegebenen SQL-SELECT-Befehl an den DB-Konnektor (db_connection_handler::selectOnDatabase) weiter.
     * Das Ergebnis wird jedoch in ein Array gewandelt, sodass es leicht durchwandert werden kann. Bei allen nutzenden Funktionen sollte jedoch geprüft werden,
     * ob diese auch direkt auf db_connection_handler::selectOnDatabase zugreifen könnten.
     * 
     * @param   string $in_connection_id        ID der Connection
     * @param   string $in_sql_string           SQL-Befehl, der ausgeführt werden soll. Der Befehl kann beliebig verschachtelt sein, darf aber nur ein Statement (Semikolon) enthalten. Weitere Semikolon werden aus Sicherheitsgründen entfernt.
     * @param   string $in_callFromFunction     Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.
     * @param   object $in_sqlRequest_object    [optional] Object vom Typ sqlRequest
     * @return  Array                           Der Rückgabewert ist entweder ein zweidimensionales Array (Tabellenstruktur) oder Boolean (false), wenn kein Ergebnis vorliegt.
     *                                          Wenn die DB-Abfrage einen Fehler verursacht hat, dann wird ein Array mit der  Fehlermeldung und den abgesendeten SQL-Befehl zurückgegeben.
     */
    function getResultFromSelect($in_connection_id, $in_sql_string, $in_callFromFunction, $in_sqlRequest_object = NULL) {														



        if($in_sqlRequest_object == NULL) {
            //(deprecated) Dieser Zweig wird nur noch bei Queries mit fixem sql (sql_statement <> no-sql) angewendet. 
            $result = db_connection_handler::selectOnDatabase_old($in_connection_id, $in_sql_string, $in_callFromFunction);
        } else {
            $result = db_connection_handler::selectOnDatabase($in_sqlRequest_object, $in_callFromFunction, false, true, true);
        }

        return $result;


    }



    
    /** Entfernt unerlaubte Zeichen (SQL und Javascript) bzw. maskiert diese. Die Maskierung erfolgt abhängig vom Datenbankmanagementsystem
     * Nutzt die Funktion parseSqlValue in db_connection_handler_class
     * 
     * @param   string  $in_connection_id       ID der Connection, welche genutzt werden soll. 
     * @param   various $in_value               Ein string oder array Wert, aus dem unerlaubte Zeichen entfernt werden sollen.
     * @param   string  $in_callFromFunction    Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
     * @param   boolean $in_deleteForbiddenWords    Gibt an, ob verbotene Wörter, wie bspw. onchange, gelöscht werden sollen.
     * @param   boolean $in_allow_semicolon     Gibt an, ob auch das Semikolon entfernt werden soll. Wichtig beim Speichern in DB's, teilweise aber hinderlich für das Erzeugen von HTML-Dokumenten; Default = false
     * @return  mixed                           String oder array, abhängig vom Eingabewert
     */
    function parseSqlValue2($in_connection_id, $in_value, $in_callFromFunction, $in_deleteForbiddenWords, $in_allow_semicolon = false) {
        
        $feedback = db_connection_handler::parseSqlValue($in_connection_id, $in_value, $in_callFromFunction, $in_deleteForbiddenWords, $in_allow_semicolon);
        
        return $feedback;
    }
    
    
    
    
    /** ersetzt Latin-1-Kodierungen in Strings durch Ihre utf8-Entsprechungen
     * 
     * @param   string  $in_string      Latin-1-kodierter String
     * @return  string                  UTF-8-kodierter String    
     */
    function convertLatin1ToUtf8($in_string) {
        
        // Die Zeichen 'ü'  , 'ä'   , 'ö'   , 'ß'   , 'Ü'   , 'Ä'   , 'Ö' in ISO 8859-1
        //$find = array("\xfc", "\xe4", "\xf6", "\xdf", "\xdc", "\xc4", "\xd6"); 
        //$replace = array('ü', 'ä', 'ö', 'ß', 'Ü', 'Ä', 'Ö');
       
        //return (str_replace($find,$replace,$in_string ?? ''));
        
        return mb_convert_encoding($in_string, 'UTF-8', 'ISO-8859-1');
    }




?>
