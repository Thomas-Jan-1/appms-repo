<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

/** kopiert einen Ordner rekursiv
     * 
     * @param string    $in_source_path         absoluter Pfad
     * @param string    $in_target_path         absoluter Pfad
     * @param octdec    $in_permission          Legt die Zugriffsrechte für die target-Folder fest (Bsp.: '0700')
     * @param boolean   $in_copy_subfolders     Gibt an, ob Unterordnern rekursiv kopiert werden sollen.
     * @return boolean                          false, falls Kopiervorgang oder einrichten der Rechte fehlschlug. Details werden in der Tabelle debug abgelegt.
     */
    function folder_copy($in_source_path, $in_target_path, $in_permission, $in_copy_subfolders) { 
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        $source_dir = opendir($in_source_path); 
        $permission = $in_permission;
        $feedback = true;
        $localfeedback = true; 
        
        if(file_exists($in_target_path) == false) {
            $feedback = mkdir($in_target_path, octdec($permission), true); 
            if($feedback == false) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "Der Ordner (".$in_target_path.") konnte nicht angelegt werden.","ERROR");
            }
        }
        
        while(( $file = readdir($source_dir)) !== false ) { 
            if (( $file != '.' ) AND ( $file != '..' )) { 
                if ( is_dir($in_source_path.$my_DIR_SEP.$file) ) { 
                    //Unterordner gefunden
                    if($in_copy_subfolders == true) {
                        $new_source_path = $in_source_path.$my_DIR_SEP.$file.$my_DIR_SEP;
                        $new_target_path = $in_target_path.$my_DIR_SEP.$file.$my_DIR_SEP;
                        $localfeedback = folder_copy($new_source_path, $new_target_path, $permission, $in_copy_subfolders);
                        if($localfeedback == false) {addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "Im Kopiervorgang des Unterordners  (".$new_source_path.") nach (".$new_target_path.") trat ein Fehler auf.","ERROR");}
                    }
                } elseif (is_link($in_source_path.$my_DIR_SEP.$file)) {
                    //symbolischen Link gefunden
                    $localfeedback = symlink(readlink($in_source_path.$my_DIR_SEP.$file), $in_target_path.$my_DIR_SEP.$file);
                    if ($localfeedback == false) {addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "Der Link (".$in_source_path.$my_DIR_SEP.$file.") konnte nicht nach (".$in_target_path.$my_DIR_SEP.$file.") kopiert werden.","ERROR");}
                } else { 
                    //Datei gefunden
                    $localfeedback = copy($in_source_path.$my_DIR_SEP.$file, $in_target_path.$my_DIR_SEP.$file);
                    if ($localfeedback == false) {addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "Die Datei (".$in_source_path.$my_DIR_SEP.$file.") konnte nicht nach (".$in_target_path.$my_DIR_SEP.$file.") kopiert werden.","ERROR");}
                    $localfeedback = setFilePermission($in_target_path, $file, __FUNCTION__, $permission);
                } 
            } 
            if ($localfeedback == false) {
                $feedback = false;
            }
        } 
        closedir($source_dir); 
        //Da das setzen der Permission beim Kopieren nicht fehlerfrei funktioniert, wird es nachfolgend noch einmal mit chmod erledigt.
        if(isWinOS() == false) {
            //Die Zugriffsrechte sollten unter Windows nicht verändert werden, das führt nur zu Chaos
            setFolderPermission($in_target_path, $permission);
        }
        
        return $feedback;
        
    } 
    
    
    
    
    /** Sucht in einem Ordner rekursiv nach verbotenen Dateien
     * 
     * @param string    $in_source_path         absoluter Pfad der durchsucht werden soll
     * @param string    $in_forbidden_files     Liste der verbotenen Dateien (Bsp.: .htaccess, php.ini)
     * @param boolean   $in_check_subfolders     Gibt an, ob Unterordnern rekursiv kopiert werden sollen.
     * @return boolean                          false, falls forbidden-file gefunden wird. Details werden in der Tabelle debug abgelegt.
     */
    function searchForForbiddenFiles($in_source_path, $in_forbidden_files, $in_check_subfolders) { 
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        $source_dir = opendir($in_source_path); 
        $feedback = true;
        $localfeedback = true; 
        
        
        
        while(( $file = readdir($source_dir)) !== false ) { 
            if (( $file != '.' ) AND ( $file != '..' )) { 
                if ( is_dir($in_source_path.$my_DIR_SEP.$file) ) { 
                    //Unterordner gefunden
                    if($in_check_subfolders == true) {
                        $new_source_path = $in_source_path.$my_DIR_SEP.$file.$my_DIR_SEP;
                        $localfeedback = searchForForbiddenFiles($new_source_path, $in_forbidden_files, $in_check_subfolders);
                    }
                } elseif (is_link($in_source_path.$my_DIR_SEP.$file)) {
                    //symbolischen Link gefunden
                } else { 
                    //Datei gefunden
                    if(strpos($in_forbidden_files, $file) !== false) {
                        //forbidden file  gefunden
                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> forbidden file gefunden', $in_source_path.$my_DIR_SEP.$file,"ERROR");
                        $localfeedback = false;
                    }
                } 
            } 
            if ($localfeedback == false) {
                $feedback = false;
            }
        } 
        closedir($source_dir); 
        
        return $feedback;
        
    } 

    
    
    /** Setzt für in_target_path rekursiv inkl. aller Unterordner und Dateien die Zugriffsrechte im Unix-Style.
     * ACHTUNG: die Funktion sollte nicht unter Windows verwendet werden. Das kann ggf. mit isWinOS() geprüft werden.
     * 
     * @param   string  $in_target_path_abs     Target-Dir als absoluter Ordner ohne abschliesenden Separator  
     * @param   string  $in_permission          permission im Unix-Style als Oktal-Zahl, aber als String (Bsp. "0755")
     * @return  boolean                         
     */
    function setFolderPermission($in_target_path_abs, $in_permission) { 
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        //feedback wird noch nicht fehlerfrei bestückt, da es in der While-Schleife mit jedem Durchlauf überschrieben wird.
        $feedback = true;
        if(substr($in_target_path_abs, -1) != $my_DIR_SEP) {
            //wenn am Ende keine Directory-Separator vorhanden ist, dann wird dieser ergänzt
            $in_target_path_abs = $in_target_path_abs.$my_DIR_SEP;
        } elseif (substr($in_target_path_abs, -2) == $my_DIR_SEP.$my_DIR_SEP) {
            //Wenn am Ende zwei Directory-Separatoren sind, dann wird der letzte entfernt
            $in_target_path_abs = substr($in_target_path_abs, 0,-1);
        }
        
    
        if(file_exists($in_target_path_abs) == false) {
            //der Ordner existiert nicht
            $feedback = false;
        } else {
            $target_dir = opendir($in_target_path_abs);
            while(( $file = readdir($target_dir)) !== false ) { 
                if (( $file != '.' ) AND ( $file != '..' )) { 
                    if ( is_dir($in_target_path_abs.$file) ) { 
                        //Unterordner gefunden
                        $new_target_path = $in_target_path_abs.$file.$my_DIR_SEP;
                        //$feedback = chmod($in_target_path_abs.$file, $in_permission);
                        $feedback = setFilePermission($in_target_path_abs, $file, __FUNCTION__, $in_permission);
                        $feedback = setFolderPermission($new_target_path, $in_permission);
                        
                    } elseif (is_link($in_target_path_abs.$file)) {
                        //symbolischen Link gefunden
                        $feedback = true;
                    } else { 
                        //Datei gefunden
                        if($in_target_path_abs.$file <> "") {
//                            echo "starte chmod für: ".$in_target_path_abs.$file."<br />";
                            //$feedback = chmod($in_target_path_abs.$file, $in_permission);
                            $feedback = setFilePermission($in_target_path_abs, $file, __FUNCTION__, $in_permission);
                        }
                    } 
                } 
            } 
            closedir($target_dir);
        }
        return $feedback;
    } 
    
    
    
    /** Setzt in Linux-OS für eine Datei die angegebenen Zugriffsrechte. <br />
     *  Die Funktion wird in Windows-OS nicht ausgeführt, da sie zu unerwarteten Verhalten führen kann.
     * 
     * @param   string      $in_target_path         Pfad, in dem sich die Datei befindet, ohne Angabe des letzten Slash (Bsp.: /var/www/html/appms)
     * @param   string      $in_filename            Dateiname
     * @param   string      $in_caller              Name der Funktion, welche diese Funktion aufgerufen hat.
     * @param   string      $in_permissions         [optional] Permission in Oktal-Schreibweise, abr als String übergeben (Bsp.: 0750). Die führende 0 ist wichtig! <br />
     *                                              Wenn Parameter fehlt, dann wird über global_variables.getDefaultPermissionForFolder der Standardwert ermittelt
     * 
     */
    function setFilePermission($in_target_path, $in_filename, $in_caller, $in_permissions = NULL) {
        $localfeedback = true;
        if(is_null($in_permissions)) {$in_permissions = global_variables::getDefaultPermissionForFolder();}
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        $in_target_path = rtrim($in_target_path,$my_DIR_SEP);         //Falls vorhanden, wird ein dir-Separator am Ende entfernt.
        if(isWinOS() != true) {
            //Die Zugriffsrechte sollten unter Windows nicht verändert werden, das führt nur zu Chaos
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.'Versuche Zugriffsrechte zu setzen.', "target_path: ".$in_target_path."\n File: ".$in_filename."\n permission: ".$in_permissions."\n caller: ".$in_caller,"INFO");
            $localfeedback = chmod($in_target_path.$my_DIR_SEP.$in_filename, octdec($in_permissions));
            if ($localfeedback == false) {addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "Die Zugriffsrechte (".$in_permissions.") konnten für die Datei (".$in_target_path.$my_DIR_SEP.$in_filename.") nicht gesetzt werden. Aufruf erfolgte durch ".$in_caller,"ERROR");}
        }
        
        //Return-Wert definieren
        return $localfeedback;
        
    }
    
    
    
    /** Gibt an, ob es sich bei dem Betriebssystem, in dem die PHP-Umgebung läuft,
     * um Windows handelt oder nicht.
     * 
     * @return  boolean         wenn true, dann Windows
     */
    function isWinOS() {
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            return true;
        } else {
            return false;
        }
    }
    
    
    
    
    /** Schreibt Daten in eine komprimierte .zip-Datei und legt diese im lokalen Dateisystem ab.
     * 
     * @param string    $in_content         Inhalt, der in die Datei geschrieben werden soll.
     * @param string    $in_path            relativer Pfad in der Ordnerstruktur von appms (bspw. "/data/SYS01/install/"). Dafür am einfachsten global_variables nutzen.
     * @param boolean   $in_is_relativ_path Wenn true, dann handelt es sich bei $in_path um einen relativen Pfad, sonst um einen absoluten
     * @param string    $in_filename        Name der Datei mit Dateiendung (Bsp.: text.txt oder test.sql)
     * @param string    $in_caller          Name der aufrufenden Funktion. Wird in der debug-Meldung verwendet.
     * @return array                        Bsp.: array("result" => true, "filename" => "example.sql.gz", "fullFilename" => "C:\appms\data\example.sql.gz", "filesize" => "100Mb")
     */
    function writeZipFile($in_content, $in_path, $in_is_relativ_path, $in_filename, $in_caller) {
        $feedback = array();
        
        //path and filename
        if($in_is_relativ_path === true) {
            $path_absolut = global_variables::getPathForAppmsinstall_abs(false).$in_path;
            $file = $path_absolut.$in_filename.".zip"; 
        } else {
            $path_absolut = $in_path;
            $file = $path_absolut.$in_filename.".zip"; 
        }
        
        

        $zip = new ZipArchive;
        $result = $zip->open($file, ZipArchive::CREATE);
        if ($result === TRUE) {
            $zip->addFromString($in_filename, $in_content);
            $zip->close();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> ZIP-Datei erstellt, caller ".$in_caller, $file, "INFO");
            $feedback["result"] = "true";
            $localfeedback = setFilePermission($path_absolut, $in_filename.".zip", __FUNCTION__);
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> ZIP-Datei konnte nicht erstellt werden, caller ".$in_caller, $file, "ERROR");
            $feedback["result"] = "false";
        }
        

        $feedback["filename"] = $in_filename.".zip";
        $feedback["fullFilename"] = $file;
        $feedback["filesize"] = filesize($file);
        
        
        return $feedback;
        
    }
    
    
    
    /** Ersetzt in einer Datei einen String, durch einen anderen. Die Datei wird dabei gespeichert. 
     * Bei Bedarf, kann die Datei einen neuen Dateinamen erhalten. Der neue Dateiname wird als return zurückgegeben.
     * 
     * @param   string      $in_path_abs        Absoluter Pfad zur Datei, mit abschließenden Directory-Separator (Bsp.: C:\temp\)
     * @param   string      $in_filename        Name der Datei mit Dateiendung (Bsp.: myFile.sql.zip)
     * @param   boolean     $in_is_zipped       Gibt an, ob die Datei gezipped ist. Wenn true, dann muss der Dateiname auf ".zip" enden.
     * @param   string      $in_search_string   String, welcher gesucht d.h. ersetzt werden soll.
     * @param   string      $in_replace_string  String, welcher stattdessen eingesetzt werden soll.
     * @param   boolean     $in_set_new_file    [optional] Wenn true, wird das Ergebnis in eine neue Datei mit dem Präfix "new_" geschrieben. (Default = true).
     * @return  mixed                           Wenn ein Fehler auftritt, dann false. In dem Fall werden Details zu den Fehlern in der Debug-Tabelle ausgegeben. Ansonsten wird der neue Dateiname zurückgegeben. (Präfix = "new_")
     */
    function replaceStringInFile($in_path_abs, $in_filename, $in_is_zipped, $in_search_string, $in_replace_string, $in_set_new_file = true) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Eingangsparameter: ', "path: ".$in_path_abs." | filename: ".$in_filename." | is_zipped: ".$in_is_zipped." | search_string: ".$in_search_string." | replace_string: ".$in_replace_string);
        
        
        
        //Wenn is_zipped file, dann entpacken
        if($in_is_zipped === true) {
            if(extractZipFile($in_path_abs.$in_filename, $in_path_abs) === false) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Datei konnte nicht entpackt werden. ', $in_path_abs.$in_filename,"ERROR");
                return false;
            } else {
                //.zip am Ende des Filenames muss nun entfernt werden.
                $filename = substr($in_filename, 0, -4);
            }
        } else {
            $filename = $in_filename;
        }
        
        
        
        //Dateiinhalt einlesen
        $file_content = file_get_contents($in_path_abs.$filename);
        if($file_content === false) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Datei konnte nicht eingelesen werden! ', $in_path_abs.$filename,"ERROR");
            return false;
        }
        
        
        
        //String ersetzen
        $new_file_content = str_replace($in_search_string, $in_replace_string, $file_content);
        
        
        
        //file speichern (neuer Dateinamen).Wenn is_zipped file, dann auch neu verpacken.
        if ($in_set_new_file === true) {$new_filename = "new_".$filename;} else {$new_filename = $filename;}
        if($in_is_zipped === true) {
            $localfeedback = writeZipFile($new_file_content, $in_path_abs, false, $new_filename, __FUNCTION__);
            if($localfeedback["result"] == false) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Datei konnte nicht geschrieben und gezipped werden! ', $in_path_abs.$new_filename,"ERROR");
                return false;
            } else {
                $new_filename = $new_filename.".zip";
            }
        } else {
            writeFile($in_path_abs, $new_filename, $new_file_content);
        }
        
       
        
        //return: neuer Dateiname
        return $new_filename;
    }
    
    
    
    
    /** Erstellt eine unverschlüsselte Textdatei
     * 
     * @param   string  $in_path        relativer oder absoluter Speicherpfad (Bsp.: /var/www/)
     * @param   string  $in_filename    Dateiname inkl. Dateiendung (Bsp. text.txt)
     * @param   string  $in_content     zu speichernder Inhalt
     */
    function writeFile($in_path, $in_filename, $in_content) {
        $fp = fopen ($in_path.$in_filename,"w"); 
        fwrite ($fp,$in_content); 
        fclose ($fp); 
        setFilePermission($in_path, $in_filename, __FUNCTION__);
    }
    
    
    
    /** Schreibt ans Ende einer Textdatei
     * 
     * @param   string  $in_path        relativer oder absoluter Speicherpfad (Bsp.: /var/www/)
     * @param   string  $in_filename    Dateiname inkl. Dateiendung (Bsp. text.txt)
     * @param   string  $in_content     zu ergänzender Inhalt
     */
    function appendFile($in_path, $in_filename, $in_content) {
        $fp = fopen ($in_path.$in_filename,"a"); 
        fwrite ($fp,$in_content); 
        fclose ($fp); 
    }
    
    
    
    /** Löscht alle Dateien in einem Folder. 
     * 
     * @param   string  $in_folder              absoluter Pfad zum Ordner
     * @param   boolean $in_deleteSubFolders    Wenn true, dann werden auch SubFolders gelöscht
     * @param   array   $in_exceptList          [optional] Liste von Dateien oder Ordnern, welche nicht gelöscht werden sollen. Default = array()
     * @return  boolean                           false, wenn ein Fehler auftrat. Details werden in der tabelle debug abgelegt.
     */
    function clearFolder($in_folder, $in_deleteSubFolders, $in_exceptList = array()) {
        $feedback = true;
        $localfeedback = true;
        $source_dir = opendir($in_folder); 
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        
        if($source_dir !== false) {
            //false erscheint, wenn ugriffsrechte nicht gegeben sind.
            while(( $file = readdir($source_dir)) !== false ) { 
                //alle Dateien und Ordner in source_dir werden in einer Schleife durchlaufen
                if(in_array($file, $in_exceptList) !== true) {
                    //Nur wenn $file nicht in der Ausnahmeliste ist, wird fortgefahren.
                    if (( $file != '.' ) AND ( $file != '..' )) { 
                        if ( is_dir($in_folder.$file) ) { 
                            //SubFolder gefunden
                            if($in_deleteSubFolders == true) {
                                //Wenn Sub-Ordner gelöscht werden sollen
                                $feedback = clearFolder($in_folder.$file.$my_DIR_SEP, $in_deleteSubFolders, array());
                                if($feedback !== false) {
                                    $localfeedback = rmdir($in_folder.$file);
                                } else {
                                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Unterordner löschen", "Unterordner (".$in_folder.$file.$my_DIR_SEP.") konnte nicht gelöscht werden.", "ERROR");
                                    break;
                                }
                            }
                        } else { 
                            //Datei oder symbolischen Link gefunden
                            if(unlink(realpath($in_folder.$file)) == false) {
                                //File oder Folder konnte nicht gelöscht werden.
                                $feedback = false;
                                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Datei löschen", "Datei (".$in_folder.$file.") konnte nicht gelöscht werden.", "ERROR");
                            }
                        } 
                    } 
                }
            } 
            closedir($source_dir); 
        } else {
            //vermutlich sind die Zugriffsrechte unzureichend
            $feedback = false;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Ordner öffnen", "Ordner (".$in_folder.") kann nicht gelesen werden. Eventuell fehlen die berechtigungen oder ein anderer Prozess blockiert den Ordner.", "ERROR");
        }    
        return $feedback;
    }
    
    
    
    
    /** Verpackt einen Ordner in ein Zip-Archiv
     * 
     * @param   string      $in_dir     absoluter Pfad zu dem Ordner, welcher verpackt werden soll
     * @param   string      $in_name    Name, den das ZIP-Archiv erhalten soll (inklusive gewünschter Dateiendung)
     * @return  boolean                 true, wenn keine Fehler auftraten. Wenn Fehler auftraten, werden diese in der debug-Tabelle ausgegeben.
     */
    function createZipFileFromDir($in_dir, $in_name) {
        $feedback = true;
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Starte Zippen ", "Zip: ".$in_dir, "INFO");
        // die maximale Ausführzeit erhöhen
        ini_set("max_execution_time", 300);

        // Objekt erstellen
        $zip = new ZipArchive();
        if ($zip->open($in_dir.$in_name, ZIPARCHIVE::CREATE) !== TRUE) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Keine ZIP-Bibliothek vorhanden ", $in_dir, "ERROR");
            return false;
        } else { 
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> ZIP ", "ZIP-Bibliothek ist vorhanden", "INFO");
            // Gehe durch die Ordner und füge alles dem Archiv hinzu
            $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($in_dir));
            foreach ($iterator as $ObjWithAbsPath=>$value) {
                //relativen Pfad bilden
                $ObjWithRelPath = str_replace("\\", $my_DIR_SEP, $ObjWithAbsPath);
                $ObjWithRelPath = str_replace($in_dir, "", $ObjWithRelPath);
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> ZIP ", "abs: ".$ObjWithAbsPath." | rel: ".$ObjWithRelPath, "INFO");
                if(!is_dir($ObjWithAbsPath)) { 
                    // Objekt ist eine Datei
                    if($zip->addFile($ObjWithAbsPath, $ObjWithRelPath) == false) {
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Konnte Datei zu ZIP nicht hinzufügen ", $ObjWithAbsPath, "ERROR");
                        $feedback = false;
                    }

                } elseif (count(scandir($ObjWithAbsPath)) <= 2) { 
                    // der ordner ist bis auf . und .. leer
                    $zip->addEmptyDir(substr($ObjWithRelPath, -1*strlen($ObjWithRelPath),strlen($ObjWithRelPath)-1));

                } elseif (substr($ObjWithAbsPath, -2)=="/.") { 
                    // ordner .

                } elseif (substr($ObjWithAbsPath, -3)=="/.."){ 
                    // ordner ..

                }
                
            }

            // speichern
            $zip->close();
            // Zugriffsrechte setzen
            if($feedback == true) {setFilePermission($in_dir, $in_name, __FUNCTION__);}
        }
        return $feedback;
        
    }
    
    
    
    /** Entpackt ein ZIP-Archive und legt die Dateien im Zielpfad ab.
     * 
     * @param   string     $in_ZipFile      Name der Zip-Datei, inkl. absoluten Pfad
     * @param   string     $in_targetdir    Zielpfad
     * @param   array      $in_filelist     [optional] Liste von Dateien, welche extrahiert werden sollen. 
     *                                      Wenn dieser Parameter nicht angegeben wird, dann wird das gesamte Archiv entpackt.
     *                                      Bsp.: array('test.gif', 'page.php')
     * @return  boolean
     */
    function extractZipFile($in_ZipFile, $in_targetdir, $in_filelist = array()) {
        $feedback = true;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Starte Entpacken ", "Zip: ".$in_ZipFile, "INFO");
        // die maximale Ausführzeit erhöhen (Seconds)
        ini_set("max_execution_time", 300);

        // Objekt erstellen
        $zip = new ZipArchive();
        $errorcode = $zip->open($in_ZipFile);
        if ($errorcode !== true) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Entweder ist die ZIP-Bibliothek  nicht vorhanden oder die Datei existiert nicht.", $in_ZipFile." - Errorcode: ".$errorcode." -> http://www.php.net/manual/en/zip.constants.php", "ERROR");
            return false;
        } else { 
            If($in_filelist == array()) {
                //das ganze Archiv entpacken
                $feedback = $zip->extractTo($in_targetdir);
            } else {
                //nur einzelne Dateien entpacken
                $feedback = $zip->extractTo($in_targetdir, $in_filelist);
            }
            
            $zip->close();
        }
        
        
        return $feedback;
        
    }
    
    
    
    
    function compareTwoTextfiles() {
        $diff = xdiff_string_diff($old_article, $new_article, 1);
        if (is_string($diff)) {
            echo "Differences between two articles:\n";
            echo $diff;
        }
    }
    

    


?> 

