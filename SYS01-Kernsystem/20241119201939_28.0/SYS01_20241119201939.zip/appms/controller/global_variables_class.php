<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

/**
 * In dieser Klasse werden Attribute und Methoden für globale Konstanten und Variablen zur Verfügung gestellt.
 * Es handelt sich um statische Metheoden, auf welche ohne Instanziierung eines Objektes mit "global_variables::functionName();" 
 * zugegriffen werden kann. 
 */
class global_variables {
    
    public static $debug_mask;
    public static $debug_starttime;
    public static $debug_string;
    public static $debug_param;                            
    public static $debug_array_length;      //Länge (items), bei der Arrays im Protokoll abgeschnitten werden
    public static $debug_SqlErrors = array();  
    public static $usedVquery = array();    //Liste aller vQueries, die bereits im aktuellen Programmdurchlauf genutzt/aktualisiert wurden.
    
    
    /** Gibt den Namen des Datenbankschemas des Kernmoduls (SYS01) zurück
     * 
     * @return  string                  (Bsp.: "manager")
     */
    public static function getNameOfDbSchemaSYS01() {
        return "manager";
    }
    
    
    /** Gibt die ID der Connection für das schema des Kernmoduls zurück
     * 
     * @return string                   (Bsp.: "SYS01!)
     */
    public static function getConnectionIdOfDbSchemaSYS01() {
        return "SYS01";
    }
    

    
    /** Trennzeichens für Attribute in einer Datarow, die per Ajax einer Javascript-Methode bereitsgestellt werden.
     * 
     * @return string   Bsp.: "|||"
     */
    public static function getDelimiterFieldAttribut() {
        return "|||";
    }
    
    
    
    /** Trennzeichens für Felder in einer Datarow, die per Ajax einer Javascript-Methode bereitsgestellt werden.
     * 
     * @return string   Bsp.: "_____"
     */
    public static function getdelimiterFields() {
        return "_____";
    }
    
    
    /** ID der Rolle APP-Manager
     * 
     * @return string   Bsp.: "123"
     */
    public static function getAppManagerRoleId() {
        return "139";
    }
    
    
    
    /**Liefert eine Liste der Dateiendungen, die mit MS-Office vermutlich geöffnet werden.
     * 
     * @return array
     */
    public static function getMsOfficeFiletypes() {
        return array("doc","xls","ppt","docx","docm","dot","dotm","xlsx","xlsm","xlst","pptx","pptm","csv","rtf");
    }
    
    
    
    
    
    
    /** Gibt die App-ID des Kernmoduls zurück
     * 
     * @return string                   (Bsp.: "SYS01!)
     */
    public static function getAppIdFromSYS01() {
        return "SYS01";
    }
    
    
    
    
    /** Gibt den Namen des information_schema (Standard-SQL) zurück.
     * ToDo: Prüfen, ob das auch in anderen DB's (als postgres) so heißt. Falls nein, muss diese Funktion in Abhängigkeit vom DBMS einen anderen Namen liefern.
     * 
     * @return  string                  (Bsp.: "information_schema")
     */
    public static function getNameOfDbSchemaInformation() {
        return "information_schema";
    }
    
    
    
    
    /** Name des Installationsordners
     * 
     * @return string           Bsp.: appms
     */
    public static function getNameOfInstallFolder() {
        $path_to_here = $_SERVER['PHP_SELF'];
        
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        
        $pathList = explode($my_DIR_SEP, $path_to_here);
        $install_path = $pathList[1];                               //diese Variante ist flexibler, als fix davon auszugehen, dass der Installationsordner appms heißt
        
        return $install_path;
    }
    
    
    
    /** Gibt die URL des AppMS-Hosts an.
     * 
     * @return string       Bsp.: http://localhost/appms/view/page.php
     */
    public static function getUrlHost($in_mask_id, $in_mask_app_id) {
        $url = $_SERVER['HTTP_HOST'];
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        $path = $_SERVER['PHP_SELF'];
        
        return $url.$path."?mask=".$in_mask_id."&maskapp=".$in_mask_app_id;
    }
    
    
    
    /** Gibt den, zum Installationspfad relativen, Pfad zu den Vorlagedateien für queries zurück.
     * 
     * @param   string  $in_app_id      id einer app (Bsp.: SYS01)
     * @return  string                  Gibt den relativen Pfad zu den Vorlagedateien zurück (Bsp.: data/SYS01/query/)
     */
    public static function getPathForQueryTemplate_rel($in_app_id) {
        $myDirSep = global_variables::getDirectorySeparator(); 
        $dataDir = global_variables::getPathForData_rel();
        $path = $dataDir.$in_app_id.$myDirSep."query".$myDirSep."document_templates".$myDirSep;
        return $path;
    }
    
    
    
    /** Gibt den, zum Installationsordner, relativen Pfad zum data-Verzeichnis zurück.
     * 
     * @return  string                  Gibt den relativen Pfad zum data-Verzeichnis mit abschließenden Directory-Separator zurück (Bsp.: data/)
     */
    public static function getPathForData_rel() {
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        return "data".$my_DIR_SEP;
    }
    
    
    /** Gibt die ID des internen Directorys zurück
     * 
     * @return int
     */
    public static function getInternDirectoryId() {
        
        return 2;
    }
    
    
    
    /** Gibt den, zum Installationsornder, relativen Pfad zu den Backup-Dateien zurück
     * 
     * @param   string  $in_app_id      ID der APP
     * @return  string                  relativer Pfad, beginnend mit dem Dataverzeichnis ohne vorangestellten Seperatorzeichen
     *                                  Bsp.: "data/SYS01/backup/"
     */
    public static function getPathForBackups_rel($in_app_id) {
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        $dataDir = global_variables::getPathForData_rel();
        $path = $dataDir.$in_app_id.$my_DIR_SEP."backup".$my_DIR_SEP;
        return $path;
    }
    
    
    
    /** Gibt den, zum Installationsordner relativen,  Pfad zu den Config-Dateien zurück
     * 
     * @param   string  $in_app_id      ID der APP
     * @return  string                  relativer Pfad, beginnend mit dem Dataverzeichnis ohne vorangestellten Seperatorzeichen
     *                                  Bsp.: "data/SYS01/config/"
     */
    public static function getPathForConfigs_rel($in_app_id) {
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        $dataDir = global_variables::getPathForData_rel();
        $path = $dataDir.$in_app_id.$my_DIR_SEP."config".$my_DIR_SEP;
        return $path;
    }
    
    
    
    /** Gibt den Betriebssystem abhängigen Verzeichnistrenner an. Die PHP-Variable 
     * DIRECTORY_SEPARATOR arbeitet scheinbar nicht verlässlich, daher gibt es diese Funktion.
     * 
     * @return  string                  Trennzeichen für Ordnerstruktur (Bsp.: "/")
     */
    public static function getDirectorySeparator() {
        //Die Standard-PHP-Konstante DIRECTORY_SEPARATOR scheint nicht fehlerfrei zu funktionieren.
        $path_to_here = $_SERVER['PHP_SELF'];
        if(strpos($path_to_here, '/') !== false) {
            //Windows-Style
            $my_DIR_SEP = '/';
        } else {
            //Linux-Style
//            $my_DIR_SEP = '\\';
            $my_DIR_SEP = '/';      //laut doku verspricht diese Variante die beste Kompatibilität
        }
        
        return $my_DIR_SEP;
    }
    
    
    /** Gibt den, zum Installationsverzeichnis,  relativen Pfad zu den Versions-/Installations-Dateien zurück
     * 
     * @return  string                  relativer Pfad, innerhalb des Installationsordner mit einem abschließenden Seperatorzeichen
     *                                  Bsp.: "version/"
     */
    public static function getPathForVersion_rel() {
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        return "version".$my_DIR_SEP;
    }
    
    
    /** Gibt den, zum Installationsverzeichnis,  relativen Pfad zum Conf-Verzeichnis des Wiki zurück.
     * 
     * 
     * @return  string                  relativer Pfad, innerhalb des Installationsordner
     *                                  Bsp.: "wiki/conf/"
     */
    public static function getPathForWikiconf_rel() {
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        return "wiki".$my_DIR_SEP."conf".$my_DIR_SEP;
    }
    
    
    
     /** Gibt den, zum Installationsverzeichnis relativen, Pfad zum Update-Verzeichnis zurück
     * 
     * @return  string                  relativer Pfad, innerhalb des Installationsordner mit einem abschließenden Seperatorzeichen
     *                                  Bsp.: "update/"
     */
    public static function getPathForUpdate_rel() {
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        return "update".$my_DIR_SEP;
    }
    
    
    
     /** Gibt den Namen des View-Verzeichnisses zurück
     * 
     * @return  string                  Name des view-Verzeichnis
     *                                  Bsp.: "view"
     */
    public static function getNameOfViewDir() {
        return "view";
    }
    
    
     /** Gibt den Namen des Wiki-Verzeichnisses zurück
     * 
     * @return  string                  Name des wiki-Verzeichnis
     *                                  Bsp.: "wiki"
     */
    public static function getNameOfWikiDir() {
        return "wiki";
    }
    
    
    
    /** Gibt den absoluten Pfad zum Update-Verzeichnis zurück
     * 
     * @return  string                  absoluter Pfad, mit einem abschließenden Seperatorzeichen
     *                                  Bsp.: "/var/www/html/update/"
     */
    public static function getPathForUpdate_abs() {
        $installPath = global_variables::getPathForAppmsinstall_abs(false);     //Das Update-Verszeichnis befindet sich immer im Original-Installationsverzeichnis, daher hier false
        $uploadPath = global_variables::getPathForUpdate_rel();
        return $installPath.$uploadPath;
    }
    
    
    
    /** Gibt den Namen des TEMPL-Ordner im data-Verzeichnis zurück
     * 
     * @return  string                  Name des TEMPL-Ordners (Bsp. "TEMPL") 
     */
    public static function getNameOfTemplateInDatafolder() {
        return "TEMPL";
    }
    
    
    /** Gibt den Namen des doc-Ordner im data-Verzeichnis zurück
     * 
     * @return  string                  Name des doc-Ordners (Bsp. "doc") 
     */
    public static function getNameOfDocfolderInData() {
        return "doc";
    }
    
    
    
    /** Gibt den Namen des Config-Ordner im data-Verzeichnis zurück
     * 
     * @return  string                  Name des Config-Ordners (Bsp. "config") 
     */
    public static function getNameOfConfigInDatafolder() {
        return "config";
    }
    
    
    /** gibt den Installationspfad von appms an. 
     * 
     * @param   boolean     $in_beachte_tempInstallPath     Gibt an, ob die Eigenschafte SESSION["use_temporary_update_dir"]
     *                                                      beachtet werden soll. Wenn false, dann wird imm der Installationspfad, welcher sich aus der URL ergibt, zurückgegeben. 
     *                                                      I.d.R. sollte false richtig sein, da in der URL bereist der temporäre Pfad enthalten sein sollte.       
     * @return  string                                      Absoluter Pfad mit abschließenden Seperator; 
     *                                                      Bsp.: "C:/Programme_eigene/xampp/htdocs/appms/" oder 
     *                                                            "\var\www\appms\" oder
     *                                                            auch temp_install_dir, während des Update-Prozesses
     */
    public static function getPathForAppmsinstall_abs($in_beachte_tempInstallPath) {
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        $install_path = global_variables::getPathForAppmsinstall_rel($in_beachte_tempInstallPath);
        return $_SERVER['DOCUMENT_ROOT'].$my_DIR_SEP.$install_path;
        
    }
    
    
    /** Gibt immer den original Installationsordner zurück. Auch wenn sich das System gerade im TempInstall-Ordner befindet.
     * 
     * @return  string          Bsp.: /var/www/html/appms/
     */
    public static function getPathForAppmsinstallOrigin_abs() {
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        $install_path = global_variables::getNameOfInstallFolder();
        return $_SERVER['DOCUMENT_ROOT'].$my_DIR_SEP.$install_path.$my_DIR_SEP;
    }
    
    
    /** gibt den Installationsordner von appms an.
     *  
     * @param   boolean     $in_beachte_tempInstallPath     Gibt an, ob die Eigenschafte SESSION["use_temporary_update_dir"]
     *                                                      beachtet werden soll. Wenn false, dann wird der aufgerufene Installationspfad zurückgegeben. 
     *                                                      Wenn true, wird der aufgerufene Installationspfad + TempDir zurückgegeben       
     * @return  string                                      relativer Pfad mit abschließenden Seperator; 
     *                                                      Bsp.: "appms/"     (Standard) oder
     *                                                            "appms/update/SYS01/recovery/appms/"    (temp_Install_dir während Update-Prozess)
     *                          
     */
    public static function getPathForAppmsinstall_rel($in_beachte_tempInstallPath) {
        $install_path = global_variables::getNameOfInstallFolder();
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        //Prüfen, ob das temporäre Installationsverzeichnis genutzt werden soll
        $use_tempInstall_Path = global_variables::getSessionUseTempInstallPath2();
        
        if($use_tempInstall_Path == true AND $in_beachte_tempInstallPath == true) {
            //Wenn der temporäre Installationspfad genutzt werden soll, dann befindet sich das System gerade im Update-Prozesse der Kernel-App
            //$feedback = $install_path.$my_DIR_SEP.global_variables::getPathForRecovery_rel(global_variables::getAppIdFromSYS01());
            $feedback = $install_path.$my_DIR_SEP.global_variables::getPathForAppmsinstallTemp_rel();
        } else {
            $feedback = $install_path.$my_DIR_SEP;
        }
        
        
        return $feedback;
        
    }
    
    
    /** Liest aus der Globalen SESSION den use_temporary_update_dir aus.
     * Die Funktion ist redundant zu pagedata->getSessionUseTempInstallPath, 
     * da von hier nicht auf pagedata zugegriffen werden kann.
     * 
     * @return boolean
     */
    protected static function getSessionUseTempInstallPath2() {
        $mySession = session_class::$session_object->getSessionArray();
        if(isset($mySession["use_temporary_update_dir"])) {
            //Attribut existiert
            $feedback = $mySession["use_temporary_update_dir"];
        } else {
            //Attribut existiert nicht
            $feedback = false;
        }
        
        return $feedback;
    }
    
    
    /** Gibt den Pfad zu den Plugindateien zurück.
     * 
     * @param   string  $in_app_id      id einer app (Bsp.: SYS01)
     * @return  string                  Gibt den relativen Pfad zu den Vorlagedateien zurück (Bsp.: data/SYS01/query/)
     */
    public static function getPathForPlugins_rel($in_app_id) {
        $dataDir = global_variables::getPathForData_rel();
        $myDirSep = global_variables::getDirectorySeparator();
        return $dataDir.$in_app_id.$myDirSep."plugin".$myDirSep;
    }
    
    
    
    /** Gibt den Pfad zu den Vorlagedateien für images zurück.
     * 
     * @param   string  $in_app_id      id einer app (Bsp.: SYS01)
     * @return  string                  Gibt den relativen Pfad zu den Vorlagedateien zurück (Bsp.: data/SYS01/img/)
     */
    public static function getPathForImages_rel($in_app_id) {
        $dataDir = global_variables::getPathForData_rel();
        $myDirSep = global_variables::getDirectorySeparator();
        return $dataDir.$in_app_id.$myDirSep."img".$myDirSep;
    }
    
    
    
    /** Gibt den Pfad zu den Vorlagedateien für mails zurück.
     * 
     * @param   string  $in_app_id      id einer app (Bsp.: SYS01)
     * @return  string                  Gibt den relativen Pfad zu den Vorlagedateien zurück (Bsp.: data/SYS01/img/)
     */
    public static function getPathForMail_rel($in_app_id) {
        $dataDir = global_variables::getPathForData_rel();
        $myDirSep = global_variables::getDirectorySeparator();
        return $dataDir.$in_app_id.$myDirSep."mail".$myDirSep;
    }
    
    
    
    /** Gibt den Pfad zu den Script-Dateien zurück.
     * 
     * @param   string  $in_app_id      id einer app (Bsp.: SYS01)
     * @return  string                  Gibt den relativen Pfad zu den Vorlagedateien zurück (Bsp.: data/SYS01/img/)
     */
    public static function getPathForScripts_rel($in_app_id) {
        $dataDir = global_variables::getPathForData_rel();
        $myDirSep = global_variables::getDirectorySeparator();
        return $dataDir.$in_app_id.$myDirSep."scripts".$myDirSep;
    }
    
    
    
    /** Gibt den Pfad für temporäre Dateien zurück.
     * 
     * @param   string  $in_app_id      id einer app (Bsp.: SYS01)
     * @return  string                  Gibt den relativen Pfad zurück (Bsp.: data/SYS01/temp/)
     */
    public static function getPathForTemp_rel($in_app_id) {
        $dataDir = global_variables::getPathForData_rel();
        $myDirSep = global_variables::getDirectorySeparator();
        return $dataDir.$in_app_id.$myDirSep."temp".$myDirSep;
    }
    
    
    
    /** Gibt den Pfad und den Namen Konfigurationsdatei einer APP zurück.
     * Konfigurationsdateien können gelesen weden, noch bevor eine Verbindung zur Datenbank besteht.
     * 
     * @param   string  $in_app_id      id einer app (Bsp.: SYS01)
     * @return  string                  Gibt den relativen Pfad und den Namen der Config-Datei zurück (Bsp.: data/SYS01/config/config.xml)
     */
    public static function getPathAndFileForConfigxml_rel($in_app_id) {
        $dataDir = global_variables::getPathForData_rel();
        $myDirSep = global_variables::getDirectorySeparator();
        return $dataDir.$in_app_id.$myDirSep."config".$myDirSep.global_variables::getNameOfConfigFile();
    }
    
    
    
   /** Gibt den Namen der Config-XML-Datei, inkl. Dateiendung, an.
     * 
     * @return  string                  Bsp.: config.xml   
     */
    public static function getNameOfConfigFile() {
        return "config.xml";
    }
    
    
    
    
    /** Gibt den Namen der Versions-Info-Datei, inkl. Dateiendung, an.
     * 
     * @return  string                  Bsp.: version_info.xml   
     */
    public static function getNameOfVersionInfoFile() {
        return "version_info.xml";
    }
    
    
    /** Gibt den Namen der Versions-Check-Datei, inkl. Dateiendung, an.
     * 
     * @return  string                  Bsp.: version_check.xml   
     */
    public static function getNameOfVersionCheckFile() {
        return "version_check.xml";
    }
    
    
    public static function getPräfixForVqueryTables() {
        return "vquery_";
    }
    
    
    
    /** Gibt den Standard-Option-Eintrag für eine Select-Box zurück
     * selected, disabled mit label
     * 
     * @return string
     */
    public static function getOptionChoosesomethinForSelect() {
        return "<option label=\"\" value=\"\"></option>\r\n";
    }
    
    
    /** Gibt den absoluten Pfad des Recovery-Verzeichnis zurück
     * 
     * @return  string                  Bsp.: /var/www/html/appms/update/SYS01/recovery/"
     */
    public static function getPathForRecovery_abs($in_app_id) {
        $myDirSep = global_variables::getDirectorySeparator();
        $recoveryDir = global_variables::getPathForAppmsinstall_abs(false).global_variables::getPathForRecovery_rel($in_app_id);
        return $recoveryDir;
    }
    
    
    /** Gibt den  Pfad des Recovery-Verzeichnis relativ zum Installationsordner zurück
     * 
     * @param   string      $in_app_id  App-ID der aktuelle zu sichernden APP
     * @return  string                  Bsp.: update/SYS01/recovery/appms/"
     */
    public static function getPathForRecovery_rel($in_app_id) {
        $myDirSep = global_variables::getDirectorySeparator();
        $appmsInstallDir_rel = global_variables::getNameOfInstallFolder();
        $recoveryDir = global_variables::getPathForUpdate_rel().$in_app_id.$myDirSep."recovery".$myDirSep.$appmsInstallDir_rel.$myDirSep;
        return $recoveryDir;
    }
    
    
    /** Gibt den relativen Pfad zum temporären Installationsverzeichnis zurück.
     * Das temporäre Installationsverzeichnis wird während des Update-Prozesses
     * des Kernelmoduls im Recovery-Verzeichnis des Update-Ordners angelegt.
     * 
     * @return  string          Bsp.: update/SYS01/recovery/appms/
     */
    public static function getPathForAppmsinstallTemp_rel() {

        $myDirSep = global_variables::getDirectorySeparator();
        $appmsInstallDir_rel = global_variables::getNameOfInstallFolder();
//        $tempInstall_path = global_variables::getPathForRecovery_rel(global_variables::getAppIdFromSYS01());
        //die folgende Variante würde vorsehen, dass die neuen Dateien, des Updates bereits während des Update-Vorgangs
        //als Quelle herangezogen werden. Das funktioniert jedoch noch nicht, da in der Klasse installer
        //teilweise direkt auf den recovery-Ordner verwiesen wird.
        $tempInstall_path = global_variables::getPathForUpdate_rel().global_variables::getAppIdFromSYS01().$myDirSep.$appmsInstallDir_rel.$myDirSep;
        return $tempInstall_path;
    }
    
    
    
    /** Gibt die url zur page, inkl. Angabe der Parameter mask und maskapp, zur Standardmaske der gesamten Anwendung.
     * Diese Maske sollte allen Rollen der Anwendung zur  Verfügung stehen.
     * 
     * @param  string   $in_app_id      APP der Maske, von der der Aufruf erfolgte.
     * @param  string   $in_mask_type   Name des Maskentyps (entspricht Config-Parameter); mögliche Werte: [login_mask|start_mask]
     * @return string                   Bsp.: "page.php?mask=0&maskapp=SYS01"
     */
    public static function getDefaultMask($in_app_id, $in_mask_type) {
        return "page.php?mask=".self::getDefaultMaskId($in_app_id, $in_mask_type)."&maskapp=".self::getDefaultMaskAppId($in_app_id, $in_mask_type)."&masktype=".$in_mask_type;
    }
    
    
    /** Gibt nur die AppID der DefaultStartpage zurück. Diese wird aus dem Config-Parameter "start_mask" ermittelt.
     *  Bei der Kernanwendung wird dies immer gleich der APP-ID der Kernanwendung sein.
     * Bei den anderen APP's könnte es einen eigenen Config-Parameter geben. Ansonsten wird auf den Config-Parameter der Kernanwendung 
     * zurückgeggriffen.
     * Diese Maske sollte allen Rollen der Anwendung zur  Verfügung stehen.
     * 
     * @param  string   $in_app_id      APP der Maske, von der der Aufruf erfolgte.
     * @param  string   $in_mask_type   Name des Maskentyps (entspricht Config-Parameter); mögliche Werte: [login_mask|start_mask]
     * @return string                   Bsp.: "SYS01"
     */
    public static function getDefaultMaskAppId($in_app_id, $in_mask_type) {
        $param = str_replace(" ", "", getConfig($in_mask_type, $in_app_id));       //Parameter enthält Masken-ID und APP-ID durch Komma getrennt
        $param_array = explode(",", $param);
        $mask_id = $param_array[0];
        $mask_app_id = $param_array[1];
        
        return $mask_app_id;
    }
    
    
    
    
    
    
    
    
    /** Gibt in einem array die Angaben zum Standard-Dom-node (Maskenelement) zurück, welches für die Aufnahme von Formularen gedacht ist.
     *  Theoretisch können Formulare in allen nodes eingehangen werden. Bei den meisten Grundgerüsten macht es aber Sinn diese im middlePart zu plazieren..
     *  Pro APP kann es nur ein default_form_parent_node (Konfigurationsparameter) geben.
     * 
     * @param   string $in_app_id       APP-ID, des Formulars.
     * @return  array                   Bsp.: array(id => 5, app_id =>  "CMS11")
     */
    public static function getDefaultDomNodeForForms($in_app_id) {
        $param = str_replace(" ", "", getConfig("default_form_parent_node", $in_app_id));       //Parameter enthält Masken-ID und APP-ID durch Komma getrennt
        $param_array = explode(",", $param);
        $feedback = array();
        $feedback["id"] = $param_array[0];
        $feedback["app_id"] = $app_id = $param_array[1];
        
        return $feedback;
    }
    
    
    /** Gibt in einem array die Angaben zum Standard-Style-Element für das erste Formular einer Maske zurück.
    * 
     * @param   string $in_app_id           APP-ID, der Maske.
     * @return  array                       Bsp.: array(id => 5, app_id =>  "CMS11")
     * @param   string  $in_style_type      Typ des Stle-Elements welches verwendet werden soll. <br />
     *                                      Mögliche Werte: [default_firstform_style|default_secondform_style|default_symbolgroup_style]. <br />
     *                                      Die Werte werden über die gleichnamigen Konfigurationsparameter gesteuert.     
     */
    public static function getDefaultStyleForForm($in_app_id, $in_style_type) {
        $param = str_replace(" ", "", getConfig($in_style_type, $in_app_id));       //Parameter enthält StyleElement-ID und APP-ID durch Komma getrennt
        $param_array = explode(",", $param);
        $feedback = array();
        $feedback["id"] = $param_array[0];
        $feedback["app_id"] = $app_id = $param_array[1];
        
        return $feedback;
    }
    
    
    
    
    
    /** Ermittelt aus der Tabelle "Konfiguration" Defaultparameter einer Maske. Rückgabewert enthält app_id und id der Maske.
     * 
     * @param   string  $in_app_id      APP-ID des Parameters
     * @param   string  $in_mask_type   Name des Parameters. Mögliche Werte (symbolgroup_mask|login_mask|start_mask)
     * @return  array                   Attribute: app_id und id
     */
    public static function getDefaultMaskInfos($in_app_id, $in_mask_type) {
        $param = str_replace(" ", "", getConfig($in_mask_type, $in_app_id));       
        $param_array = explode(",", $param);
        $feedback = array();
        $feedback["id"] = $param_array[0];
        $feedback["app_id"] = $app_id = $param_array[1];
        
        return $feedback;
    }
    
    
    
    
    
    /** Gibt nur die ID der DefaultStartpage zurück.
     * Diese Maske sollte allen Rollen der Anwendung zur  Verfügung stehen.
     * 
     * @param  string   $in_app_id      APP der Maske, von der der Aufruf erfolgte.
     * @param  string   $in_mask_type   Name des Maskentyps (entspricht Config-Parameter); mögliche Werte: [login_mask|start_mask]
     * @return string                   Bsp.: "100"
     */
    public static function getDefaultMaskId($in_app_id, $in_mask_type) {
        $param = str_replace(" ", "", getConfig($in_mask_type, $in_app_id));       //Parameter enthält Masken-ID und APP-ID durch Komma getrennt
        $param_array = explode(",", $param);
        $mask_id = $param_array[0];
        $mask_app_id = $param_array[1];
        
        return $mask_id;
    }
    
    
    /** Gibt nur die ID des DefaultDummyFormulars zurück.
     * Dieses Formular muss für alle HTML-Tags genutzt werden, in denen kein Formular eingebettet werden soll.
     * 
     * @return string                   Bsp.: "100"
     */
    public static function getDefaultDummyFormId() {
        return "100";
    }
    
    
    
    /** Gibt die ID für das versteckte Div zur temporären Ablage von vorbereiteten newLine-Knoten zurück.
     * 
     * @return string           Bsp.: 2166
     */
    public static function getHiddenTagForNewLine() {
        return "2166";
//        return "121";
    }
    
   
    
    
    /** Gibt die Liste der Verzeichniss im Ordner appms an, welche für eine Version 
     * der gewünschten APP notwendig sind.
     * 
     * @return array        Bsp.: array("controller", "css", "data", "js", "view")
     */
    public static function getListOfProgramDirs($in_app_id) {
        
        if($in_app_id == global_variables::getAppIdFromSYS01()) {
            //Kernel-APP
            return array("controller", "css", "data", "js", "view");
        } else {
            //eine beliebige andere APP
            return array("data");
        }

    }
    
    
    
    /** Gibt die Liste der Verzeichniss im Ordner wiki an, welche für eine Version 
     * der gewünschten APP notwendig sind.
     * 
     * @return array        Bsp.: array("bin", "conf", "data")
     */
    public static function getListOfWikiDirs($in_app_id) {
        
        if($in_app_id == global_variables::getAppIdFromSYS01()) {
            //Kernel-APP
            return array("bin", "conf", "data", "inc", "lib", "vendor");
        } else {
            //eine beliebige andere APP
            return array("data");
        }

    }
    
    
    
    public static function getListOfAllowedFilesInRoot($in_app_id) {
        if($in_app_id == global_variables::getAppIdFromSYS01()) {
            //Kernel-APP
            return array(".htaccess", "index.html", "License.txt");
        } else {
            //eine beliebige andere APP
            return array();
        }
    }
    
    
    
    /** Gibt die Standard-Root-Rolle aus dem Kernmodul (SYS01) zurück
     * 
     * @return octdec 
     */
    public static function getRootRoleInKernel() {
        return 7;          //0755 = rwxr-xr-x; 0644 = rw-r--r--; die führende 0 ist wichtig!
    }
    
    
    /** Legt die Standardzugriffsrechte für ein Unix-Like-OS fest, welche in den Ordnern der Versionsbereitstellung 
     * eingerichtet werden sollen.
     * 
     * @return octdec 
     */
    public static function getDefaultPermissionForFolder() {
        return "0750";          //0755 = rwxr-xr-x; 0644 = rw-r--r--; die führende 0 ist wichtig!
    }


}
