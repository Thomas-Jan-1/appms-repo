<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

/**
 * Erstellt und verwaltet einen Explorer-Tree in HTML-Syntax
 *
 * @author thomas
 */
class tree {
    
    /**
     * 
     * @var     array       Liste aller branches (key = id des branch; value = branch-Objekt)
     */
    private array $branchList;
    
    
    /**
     * 
     * @var     array       Enthält nur die branches, die sich im root-Node befinden
     */
    private array $branchListRoot;
    
    
    /**
     * 
     * @var     string      App, in dessen img-Ordner Bilder gesucht werden, die in CSS verwendet werden.
     */
    private string $cssApp;
    
    /** Die Klasse erstellt für eine Liste von Einträgen eine Explorerartige Struktur.
     * D.h., es wird ein Baum aufgebaut. Dabei werden die Einträge innerhalb Ihres Knotens sortiert.
     * Die Ausgabe erfolgt als HTML-Struktur.
     * Die Liste ($in_itemList) muss mindestens folgende Attribute enthalten: <br>
     *  tree_id                             -> eindeutige im Baum <br>
     *  tree_value                          -> Anzeigename des Knotens <br>
     *  tree_icon (default = folder-icon)   -> Name der CSS-Klasse <br>
     *  tree_parent                         -> eindeutige ID des Parent-branch / Node im Baum. Kann auch leer sein, dann wird das Element zum Root-Knoten ergänzt <br>
     *  tree_sort                           -> Sortierung innerhalb eines branches / Knotens <br>
     *  tree_targetForm                     -> ID des Formulars, welches nach Klick auf einen Eintrag mit Conditions eingeschränkt werden soll
     * 
     * @param   array   $in_itemlist
     * @param   array   $in_formArray       Array des aktuellen Formulars
     * @return  string                      Gibt den gesamten Tree in HTML-Syntax inkl. korrekter Sortierung zurück.
     */
    public function __construct($in_itemlist, $in_formArray, $in_cssApp = "") {
        require_once("../controller/treebranch_class.php");
        
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> itemList', $in_itemlist);
        $feedback = "";
        If($in_cssApp == "") {$this->cssApp = global_variables::getAppIdFromSYS01();} else {$this->cssApp = $in_cssApp;}
        
        
        if(count($in_itemlist) > 0) {
            //keys ermitteln
            $col_treeId = issetKeyLike($in_itemlist[0], "tree_id");
            $col_treeIcon = issetKeyLike($in_itemlist[0], "tree_icon");
            $col_treeValue = issetKeyLike($in_itemlist[0], "tree_value");
            $col_treeSort = issetKeyLike($in_itemlist[0], "tree_sort");
            $col_treeParent = issetKeyLike($in_itemlist[0], "tree_parent");
            $col_treeLink = issetKeyLike($in_itemlist[0], "tree_link");
            $col_treeLevel = issetKeyLike($in_itemlist[0], "tree_level");
            $col_treeTargetForm = issetKeyLike($in_itemlist[0], "tree_targetform");
            $col_treeCond1field = issetKeyLike($in_itemlist[0], "tree_cond1field");
            $col_treeCond1value = issetKeyLike($in_itemlist[0], "tree_cond1value");
            
            foreach ($in_itemlist as $cur_item) {

                if($col_treeLink != false) {$tree_link = $cur_item[$col_treeLink];} else {$tree_link = "#";}
                if($col_treeIcon != false) {$tree_icon = $cur_item[$col_treeIcon];} else {$tree_icon = "folder-icon";}
                if($col_treeParent != false) {$parent_id = $cur_item[$col_treeParent];} else {$parent_id = "root";}
                $new_branch = new branch($cur_item[$col_treeId], $cur_item[$col_treeValue], $cur_item[$col_treeSort], $parent_id, $in_formArray, $tree_link, $tree_icon, $cur_item[$col_treeLevel], $cur_item[$col_treeTargetForm], $cur_item[$col_treeCond1field], $cur_item[$col_treeCond1value]);
                $this->addBranch($new_branch);
            }
            
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> branchlist', $this->branchList);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> rootbranchlist', $this->branchListRoot);
            
        }
        
        
        
    }
    
    
    /**
     * 
     * @param   obj     $in_branch      Objekt der Klasse branch
     */
    private function addBranch($in_branch) {
        //branch in branchlist ergänzen (Zeiger); In dieser Liste werden alle branches in flacher Hierarchie ergänzt.
        //Dadurch kann jeder branch anhand seine eindeutigen ID schnell aufgefunden werden.
        //Jeder branch kann dann selbst mitteilen, weches sein parent ist. Dadurch werden langwierige Suchalgorithmen vermieden.
        $this->branchList[$in_branch->getId()] = $in_branch;
        $branch_parent = $in_branch->getParentId();
        
        
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> branchlist bei Einfügen von id '.$in_branch->getId(), $this->branchList);
        
        
        //branch zusätzlich in parent-branch einhängen);
        if($branch_parent == "root") {
            //alle root-Elemente werden auf Root-Ebene gesammelt
            $this->branchListRoot[$in_branch->getId()] = $in_branch;
        } else {
            //alle nachgeordneten branches werden jeweils in ihren parent eingehangen
            $myParentObj = $this->branchList[$branch_parent];
            $myParentObj->addChild($in_branch);
        }
        
    }
    
    
    /**
     * 
     * @return  string      Gesamter Tree in HTML-Syntax und korrekter Sortierung
     */
    public function getTreeAsHtml() {
        $feedback = "";
        
        $feedback = $feedback.$this->getCSS();
        $feedback = $feedback.'<input type="text" id="explorerSearch" placeholder="Knoten suchen">';
        $feedback = $feedback.'<button onclick="return searchExplorerNode()">Suchen</button>';
        $feedback = $feedback.'<div class="tree">';
            //alle branches des root-Nodes durchgehen-> die childs werden dann jeweils durch die Rekursion mit ausgegeben
            foreach ($this->branchListRoot as $key => $cur_branch) {
                $feedback = $feedback.$cur_branch->printHtml();
            }
        $feedback = $feedback.'</div>';
        
        
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> branchlist as HtmlTree', $feedback);
        return $feedback;
        
    }
    
    
    private function getCSS() {
        
        
        $app = $this->cssApp;
        $feedback =  "<style>
                        .tree { margin-top: 20px; }
                        .tree .branch {
                            margin: 0;
                            padding: 0 10px;
                            line-height: 20px;
                            background: #fff;
                            border-bottom: 1px solid #ccc;
                            position: relative;
                        }

                        .tree .branch:last-child {
                            border-bottom: none;
                        }
                        .tree .branch a {
                            text-decoration: none;
                            color: #666;
                            display: block;
                        }
                        .tree .branch a:hover, .tree .branch a:focus {
                            color: #f00;
                        }
                        .tree .toggle {
                            cursor: pointer;
                        }
                        .tree .active .branch {
                            display: block;
                        }
                        .tree .active > .toggle {
                            background: url('../data/".$app."/img/menu_close.png') no-repeat;
                        }
                        .tree .house-icon_empty::before {
                            content: url('../data/".$app."/img/house_empty_16.png');
                            padding-right: 5px;
                        }
                        .tree .house-icon_full::before {
                            content: url('../data/".$app."/img/house_full_16.png');
                            padding-right: 5px;
                        }
                        .tree .people-icon_empty::before {
                            content: url('../data/".$app."/img/people_empty_16.png');
                            padding-right: 5px;
                        }
                        .tree .people-icon_full::before {
                            content: url('../data/".$app."/img/people_full_16.png');
                            padding-right: 5px;
                        }
                        .tree .folder-icon_empty::before {
                            content: url('../data/".$app."/img/folder_empty_16.png');
                            padding-right: 5px;
                        }
                        .tree .folder-icon_full::before {
                            content: url('../data/".$app."/img/folder_full_16.png');
                            padding-right: 5px;
                        }
                        .tree .branch .branch { display: none; }
                        .explorerhighlight { background-color: yellow; }
                    </style>";
        return $feedback;
        
        
    }
    
    
}
