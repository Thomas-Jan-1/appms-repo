<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

/**
 * Klasse stellt Methoden zur Verwaltung von Workflows zur Verfügung
 *
 * @author Thomas J.
 */
class workflow {
    
    
    
    
    
    private $app_id;
    private $name;
    private $id;
    private $version;
    private $current_step;
    private $current_step_name;
    private $current_step_formlist;
    private $current_step_controlform_app_id;
    private $current_step_controlform_id;
    private $current_status_ds;                 //anahnd der url_id, aufgerufener Statusdatensatz
    private $current_con1 = "";
    private $current_con2 = "";
    private $current_con3 = "";
    private $current_repeat_step_count;         //wird hochgezählt, sobald ein step einmalig wiederholt wird. somit entsteht ein neuer PK
    private $current_back_to_step;
    private $max_step;
    private $instance_id;
    private $instance_name;
    private $instance_finished;
    private $description;
    private $current_step_description;
    private $url_id;
    private $url_id_nextstep;
    private $mask_id;
    private $mask_app_id;
    private $pagedata_object;
    private $workflow_control_form_array;       //Array(step => 1, form_app_id=> SYS01, form_id => 1304, is_workf_control_form => 1)
    private $step_list;                         //array(step=>array(step,max_step, name, description))
    private $access_list;                       //array(step=>array(13=>array(step,role_app_Id, role_id))) Achtung: Dreidimensional
    private $form_list;                         //array(step=>array(56=>array(step,form_app_Id, form_id))) Achtung: Dreidimensional
    private $feedback_code;                     //letzte Rückmeldung (siehe konstant.konstantentyp_id = 35
    private $current_step_wkfl_meta_data;       //Array der aktuell verwendeten dynamischen Metadaten (wkfl_step_mail_to], wkfl_step_mail_cc, wkfl_step_mail_from, wkfl_step_comment, ...)
    private $message_to_current_step;  
    private $url;
    private $call_undefined_url_id;             //bool: Aufruf einer nicht existierenden url_id
    private $is_call_to_reject = false;         //bool: gibt an, ob ein Step abgelehnt wurde. [Default = false]
    
    
    
    /**
     * Druckt alle Eigenschaften des Objektes in einem Array aus.
     * @return array
     */
    public function print_as_array() {
        $feedback = array();
        $feedback["app_id"] = $this->app_id;
        $feedback["name"] = $this->name;
        $feedback["id"] =  $this->id;
        $feedback["version"] =  $this->version;
        $feedback["current_step"] =  $this->current_step;
        $feedback["current_step_name"] =  $this->current_step_name;
        $feedback["current_step_description"] =   $this->current_step_description;
        $feedback["current_step_controlform_app_id"] = $this->current_step_controlform_app_id;
        $feedback["current_step_controlform_id"] = $this->current_step_controlform_id;
        $feedback["current_status_ds"] = $this->current_status_ds;
        $feedback["current_con1"] = $this->current_con1;
        $feedback["current_con2"] = $this->current_con2;
        $feedback["current_con3"] = $this->current_con3;
        $feedback["current_repeat_step_count"] = $this->current_repeat_step_count;
        $feedback["current_back_to_step"] = $this->current_back_to_step;
        $feedback["current_step_form_list"] = $this->current_step_formlist;
        $feedback["formlist_all_steps"] = $this->form_list;
        $feedback["max_step"] =  $this->max_step;
        $feedback["instance_id"] =  $this->instance_id;
        $feedback["instance_name"] =  $this->instance_name;
        $feedback["instance_finished"] = $this->instance_finished;
        $feedback["decription"] =   $this->description;
        $feedback["url_id"] =   $this->url_id;
        $feedback["url_id_nextstep"] = $this->url_id_nextstep;
        $feedback["url"] = $this->url;
        $feedback["mask_id"] =   $this->mask_id;
        $feedback["mask_app_id"] =   $this->mask_app_id;
        $feedback["workflow_control_form_array"] =   $this->workflow_control_form_array;
        $feedback["step_list"] = $this->step_list;
        $feedback["access_list"] = $this->access_list;
        $feedback["current_step_wkfl_meta_data"] = $this->current_step_wkfl_meta_data;
        $feedback["call_undefined_url_id"] = $this->call_undefined_url_id;
        
        
        return $feedback;
        
    }
    
    
    
    /** Gibt den FeedbackCode zurück
     * 
     * 
     * @return  integer         0 = alles ok, <br />
     *                          -4001 = aktuelle Rolle ist für den aktuellen Step nicht zugriffsberechtigt, <br />
     *                          -4002 = Workflow kann nicht weiter zurückgesetzt werden, da er sich bereits im ersten step befindet <br />
     *                          -4003 = Workflow fortsetzen, nicht möglich, da Speichern in Tabelle workflow_status fehlgeschlagen ist. <br />
     *                          -4004 = instance mit gegebener url_id existiert nicht <br />
     */
    public function getFeedbackCode() {
        return $this->feedback_code;
    }
    
    
    
    /** Setzt den FeedbackCode 
     * 
     * 
     * @param   integer $in_feedback_code       0 = alles ok; -4001 = aktuelle Rolle ist für den aktuellen Step nicht zugriffsberechtigt, -4002 = instance mit gegebener url_id existiert nicht
     */
    public function setFeedbackCode($in_feedback_code) {
        $this->feedback_code = $in_feedback_code;
    }
    
    

    /** Klasse stellt Methoden zur Verwaltung von Workflows zur Verfügung
    * 
    * @param   string   $in_workflow_url_id     Wert des GET-Parameters "urlid" (siehe workflow_status.url_id); Wenn neuer Vorgang angelegt wird, dann "false" angeben.
    * @return  Array                            Gibt das Workflow-Objekt zurück
    */
    function __construct($in_workflow_url_id, &$in_pagedata) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> workflow_url_id: ', $in_workflow_url_id);
        
        $this->setFeedbackCode(0);
        $this->pagedata_object = $in_pagedata;
        $postdata = $in_pagedata->getPostObject();
        $this->url_id = $in_workflow_url_id;
        $maskarray = $in_pagedata->getMaskArray();
        $this->url = global_variables::getUrlHost($maskarray["id"],$maskarray["app_id"]);
        
        //Metadaten des Workflows ermitteln
        $this->buildWorkflowBasicMetadata($in_pagedata, $this->url_id);
            
        
        
        
        //Workflow-StepData ergänzen
        $this->step_list = getWorkflowStepData($this->app_id, $this->id, $this->version);

        //Workflow-AccessData ergänzen
        $this->access_list = getWorkflowAccessData($this->app_id, $this->id, $this->version);
        //Workflow-FormList für alle steps ergänzen
        $this->form_list = getWorkflowForms($this->app_id, $this->id, $this->version, false);
        //form_list des aktuellen Steps herausfiltern       
        $this->current_step_formlist = $this->form_list[$this->current_step];
        //Liste der beteiligten Control-Formulare des aktuellen Steps ermitteln
        $this->workflow_control_form_array = $this->getWorkflowControlform($this->current_step_formlist);
        //Controlform im FormArray kennzeichnen
        $in_pagedata->setFormPropertyWorkflowControlform($this->current_step, $this->workflow_control_form_array);
        //Workflow_metadata des aktuellen Steps von last_postdata holen, falls Daten per Post übertragen wurden.
        $this->current_step_wkfl_meta_data = $postdata->getWkflMetaDataFromPost();
        //Maskenformulare, die mit dem aktuellen Workflow-Step nicht angezeigt werden dürfen, aus pagedata->formlist wieder entfernen.
        $this->blockforbiddenForms($in_pagedata);
        
        


        if($this->url_id === false) {
            //Neuer Workflow(Instanz) wird gestartet

            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> workflow: '.$this->id.", step: ".$this->current_step, "Starte neuen Vorgang");
            $flat_form_list = $this->getFormListAsArray();
            $in_pagedata->setFormModeForGivingFormList($flat_form_list,2);    //formmodus auf insert setzen

        } else {
            //vorhandene Instanz aufrufen
            $feedback_readStatus = $this->readWorkflowCurrentStep($this->app_id, $this->url_id);
            
            //$this->current_step_wkfl_meta_data ergänzen/überschreiben, falls entsprechende Attribute in current_status_ds bereits vorhanden sind
            $this->addExistingWkflMetadata();
            
            //identifier_condition anhand url_id ermitteln und in Control_form hinterlegen.
            $this->setFormConditionToCurrentStep($in_pagedata);

            //Comment vom letzten Bearbeiter zu current_step_wkfl_meta_data ergänzen
            $this->step_list[$this->current_step]["wkfl_comment_from_last_step"] = $this->getCommentFromlastStep();
            
            
        }


        
        //Wenn Instanz.finished = true, dann alle Formulare in den Modus only_read versetzen
        if($this->instance_finished == true) {
            $flat_form_list = $this->getFormListAsArray();
            $in_pagedata->setFormModeForGivingFormList($flat_form_list,7);    //formmodus auf only_read setzen
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> workflow: ', "workflow.instance_finisehd = true");
        }
        
        
         //Prüfen, ob die angemeldete Rolle zugriffsberechtigt ist oder ob eine ungültige url_id aufgerufen wurde.
        $check_access = $this->checkAccess();
        if($check_access == 0) {
            //Zugriff auf den aktuellen Workflow_Step unterdrücken.
            $flat_form_list = $this->getFormListAsArray();
            $in_pagedata->setFormModeForGivingFormList($flat_form_list,5);    //formmodus auf empty setzen
            $this->setFeedbackCode(-4001);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> workflow: ', "Zugriff verweigert");
            
        } elseif($check_access == 2) {
            //Zugriff auf den aktuellen Workflow_Step nur lesend zulassen.
            $flat_form_list = $this->getFormListAsArray();
            $in_pagedata->setFormModeForGivingFormList($flat_form_list,7);    //formmodus auf only_read setzen
            $this->setFeedbackCode(-4004);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> workflow: ', "Zugriff nur lesend erlaubt");
            
        }

        
        
        $this->pagedata_object->setMessageInInfobox($this->getFeedbackCode());
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Workflow-Attribute: ',$this->print_as_array());

        
        
        
    }
    
    
    
    
    
    /** Falls für den aktuellen Step bereits Metadaten in workflow_status gespeichert wurden,
     * werden diese geladen.
     * 
     * 
     * @param type $param
     */
    public function addExistingWkflMetadata() {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Workflow-Current-DS: ',$this->current_status_ds);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> current_step_wkfl_meta_data: ',$this->current_step_wkfl_meta_data);

        
        if($this->current_step_wkfl_meta_data !== array()) {
            //Werte durch vorab gespeicherten Werte ersetzen, es sei denn, es wurden neue Werte erfasst
            if($this->current_status_ds["workflow_status.wkfl_comment"] != "" AND $this->current_step_wkfl_meta_data["wkfl_step_comment"] == ""){$this->current_step_wkfl_meta_data["wkfl_step_comment"] = $this->current_status_ds["workflow_status.wkfl_comment"];}
            if($this->current_status_ds["workflow_status.email_to"] != "" AND $this->current_step_wkfl_meta_data["wkfl_step_mail_to"] == "")    {$this->current_step_wkfl_meta_data["wkfl_step_mail_to"] = $this->current_status_ds["workflow_status.email_to"];}
            if($this->current_status_ds["workflow_status.email_cc"] != "" AND $this->current_step_wkfl_meta_data["wkfl_step_mail_cc"] == "")    {$this->current_step_wkfl_meta_data["wkfl_step_mail_cc"] = $this->current_status_ds["workflow_status.email_cc"];}
            if($this->current_status_ds["workflow_status.email_from"] != "" AND $this->current_step_wkfl_meta_data["wkfl_step_mail_from"] == ""){$this->current_step_wkfl_meta_data["wkfl_step_mail_from"] = $this->current_status_ds["workflow_status.email_from"];}
        } else {
            //Werte durch neue Werte ersetzen, wenn vorhanen
            if($this->current_status_ds["workflow_status.wkfl_comment"] != "" ){$this->current_step_wkfl_meta_data["wkfl_step_comment"] = $this->current_status_ds["workflow_status.wkfl_comment"];}
            if($this->current_status_ds["workflow_status.email_to"] != "" )    {$this->current_step_wkfl_meta_data["wkfl_step_mail_to"] = $this->current_status_ds["workflow_status.email_to"];}
            if($this->current_status_ds["workflow_status.email_cc"] != "" )    {$this->current_step_wkfl_meta_data["wkfl_step_mail_cc"] = $this->current_status_ds["workflow_status.email_cc"];}
            if($this->current_status_ds["workflow_status.email_from"] != "" )  {$this->current_step_wkfl_meta_data["wkfl_step_mail_from"] = $this->current_status_ds["workflow_status.email_from"];}
        }
        
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> current_step_wkfl_meta_data: ',$this->current_step_wkfl_meta_data);

    }








    /** blockiert alle Formulare der Maske, welche in dem aktuellen Step nicht genutzt werden dürfen.
     * 
     * @param object $in_pagedata       Referenz zum pagedata-object
     */
    private function blockforbiddenForms(&$in_pagedata) {
        $allWorkflow_forms = $this->form_list["all_forms"];
        $forbiddenForms = array_diff_key($allWorkflow_forms, $this->current_step_formlist);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> drop forms, which not allowed in current workflowstep', $forbiddenForms);
        foreach ($forbiddenForms as $form_id => $value) {
            $in_pagedata->blockForm($form_id);
        }
            
    }
    
    
    
    /** Array der aktuell verwendeten dynamischen Metadaten
     * Array <br />
        ( <br />
            [wkfl_step] => 1 <br />
            [wkfl_max_step] => 3 <br />
            [wkfl_step_name] => Grunddaten erfassen <br />
            [wkfl_step_description] => Erfassen Sie mindestens alle Pflichtfelder einer Kostenstelle. Anschließend wird der Vorgang zur Mitzeichnung an D1-Ltg weitergeleitet. <br />
            [wkfl_step_mail_to] => test@uni-potsdam.de <br />
            [wkfl_step_mail_cc] => bim01admin@uni-potsdam.de <br />
            [wkfl_step_mail_from] => bim01admin@uni-potsdam.de <br />
            [wkfl_step_comment] => Hinweis <br />
            [wkfl_step_email_template] => 70 <br />
            [wkfl_step_pathname] => data/BIM01/mail/ <br />
            [wkfl_step_filename] => form_972_template_step1.mail <br />
            [wkfl_step_filetype] => application/octet-stream <br />
            [wkfl_name] => Kostenstelle anlegen <br />
            [wkfl_description] => Dieser Workflow dient der Erfassung und Mitzeichnung neuer Kostenstellen. <br />
            [wkfl_step_decision] => Hinweis <br />
        ) <br />
     * 
     * @return array        Wenn keine Werte vorhanden sind, wird ein leeres Array zurückgegeben.
     */
    public function getWkflMetadata() {
        $feedback = array();
        
        //if($this->call_undefined_url_id === false) {
            $default_metadata = $this->step_list[$this->current_step];

            //Fügt die default-Daten des aktuellen Steps mit den tatsächlich verwendeten zusammen. Die Reihenfolge ist wichtig, damit 
            //vorhandene, tatsächlich verwendete Werte, die Defaultwerte überschreiben können.
            $feedback = array_merge($default_metadata, $this->current_step_wkfl_meta_data);
        //}
        
        return $feedback;
    }
    
    
    
    /**
     * Setzt den Wert des Attributs current_step_wkfl_meta_data auf den übergebenen Wert.
     * 
     * @param   array   $in_metadata
     */
    public function setWkflMetadata($in_metadata) {
        $this->current_step_wkfl_meta_data = $in_metadata;
    }
    
    
    
    /** Funktion prüft, ob die aktuell angemeldete Rolle Zugriff auf den aktuellen Workflow_Step hat.
     * Dazu wird die active_role aus der Session mit workflow_access_list verglichen.
     * 
     * 
     * @return  integer             0 => kein Zugriff; 
     *                              1 => Zugriff auf diesen Step erlaubt; 
     *                              2 => Zugriff auf den Workflow, nicht jedoch auf diesen Step erlaubt
     */
    private function checkAccess() {
        
        $current_role = $this->pagedata_object->getCurrentRoleFromSession();

        //1. Prüfen, ob der angemeldte user (role) auf den aktuellen Step zugreifen darf
        $access_list_for_current_step = $this->access_list[$this->current_step];
        foreach ($access_list_for_current_step as $key => $current_allowed_role) {
            if($current_allowed_role["role_app_id"]== $current_role["role.app_id"] AND $current_allowed_role["role_id"] == $current_role["role.id"]) {
                return 1;
            }
        }
        
        //Position wird nur erreicht, wenn zuvor return nicht ausgelöst wird.
        //2. Prüfen, ob der angemeldete user (role) zumindest auf einen anderen Step dieses Workflows zugreifen darf.
        foreach ($this->access_list as $step => $access_for_step) {
            foreach ($access_for_step as $key2 => $current_allowed_role) {
                if($current_allowed_role["role_app_id"]== $current_role["role.app_id"] AND $current_allowed_role["role_id"] == $current_role["role.id"]) {
                    return 2;
                }
            }
        }
        
        
        //Diese Position wird nur erreicht, wenn zuvor keine andere return-Anweisung ausgelöst wurde.
        return 0;
    }
    
    
    
    
    /** ermittelt alle Rollen, die auf den aktuellen Workflow-Step Zugriff haben 
     * 
     * @return array
     */
    public function getRoleWithAccessFromCurrentUser() {
        
        //if($this->call_undefined_url_id === false) {
            $access_list_for_current_step = $this->access_list[$this->current_step];
        //} else {
            //undefinierte url_id -> niemand hat Zugriff
        //    $access_list_for_current_step = array();
        //}
        
        return $access_list_for_current_step;
    }
    
    
    
    
    /** Die Funktion prüft, ob aufgrund eines Workflowsteps für das übergebene Feld, ein Vorgabewert gesetzt werden soll.
     * 
     * @param   string  $in_field_column    Column-Angabe des Feldes. Es kann jeder beliebiger String übergeben werden. Jedoch werden nur für wkfl_-Felder
     *                                       Rückgabewerte angeboten; Bsp.: <br />
     *                                      - wkfl_mail_to<br />
     *                                      - wkfl_mail_cc<br />
     *                                      - wkfl_mail_from<br />
     *     
     * @return  string                      Vorgabewert. Das kann auch eine dynamische Feldfunktion sein, wie sie gemäß Vorgabewert eines Feldes zulässig ist.                                 
     */
    public function getDefaultValueForField($in_field_column) {
        $feedback = "";
        $existing_columns = array("wkfl_max_step"
                                , "wkfl_step_name"
                                , "wkfl_step_description"
                                , "wkfl_step_mail_to"
                                , "wkfl_step_mail_cc"
                                , "wkfl_step_mail_from"
                                , "wkfl_step_email_template"
                                , "wkfl_step_pathname"
                                , "wkfl_step_filename"
                                , "wkfl_step_filetype"
                                , "wkfl_name"
                                , "wkfl_description"
                                , "wkfl_step_comment"
                                , "wkfl_comment_from_last_step");
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> suche Field in Workflow ", $in_field_column, "INFO");
        
        //Suche nach Step-Attributen
        if(in_array($in_field_column, $existing_columns) === true) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> suche Field in Workflow ", "gefunden: ".$in_field_column, "INFO");
            
            if(isset($this->current_step_wkfl_meta_data[$in_field_column]) AND $in_field_column != "wkfl_step_mail_from") {
                //Wenn für den Step bereits Metadaten gespeichert wurden, werden diese genutzt. 
                //Ausnahme wkfl_step_mail_from: Für dieses Attribut muss immer der Default-Wert (angemeldeter User)genutzt werden.
                $feedback = $this->current_step_wkfl_meta_data[$in_field_column];
            } elseif(isset($this->step_list[$this->current_step][$in_field_column])) {
                //Ansonsten werden die Defaultdaten des Steps genutzt.
                $feedback = $this->step_list[$this->current_step][$in_field_column];
            }
        }
        
        return $feedback;
    }
    
    
    
    /** Die Funktion prüft, ob aufgrund eines Workflowsteps für das übergebene Feld, ein bestimmter Wert verwendet wurde.
     * 
     * @param   string  $in_field_column    Column-Angabe des Feldes. Es kann jeder beliebiger String übergeben werden. Jedoch werden nur für folgende
     *                                      Columns Rückgabewerte angeboten<br />
     *                                      - wkfl_mail_to<br />
     *                                      - wkfl_mail_cc<br />
     *                                      - wkfl_mail_from<br />
     *                                      - wkfl_step_comment<br />
     *                                      - wkfl_url_nextstep<br />
     *     
     * @return  string                      Vorgabewert. Das kann auch eine dynamische Feldfunktion sein, wie sie gemäß Vorgabewert eines Feldes zulässig ist.                                 
     */
    public function getUsedValueForField($in_field_column) {
        $feedback = "";
        $existing_columns = array("wkfl_step_mail_to"
                                , "wkfl_step_mail_cc"
                                , "wkfl_step_mail_from"       
                                , "wkfl_step_comment"
                                , "wkfl_url_nextstep");
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> suche Field in Workflow ", $in_field_column, "INFO");
        
        //Suche nach Step-Attributen
        if(in_array($in_field_column, $existing_columns) === true) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> suche Field in Workflow ", "gefunden: ".$in_field_column, "INFO");
       
            $feedback = $this->current_step_wkfl_meta_data[$in_field_column];
        }
        
        return $feedback;
    }








    /** Ermittelt Informationen eines workflow_status-Datensatzes, der über eine URL-ID identifiziert wird.
     * Folgende Attribute werden gesetzt:
     *  - $this->current_status_ds
     *  - $this->instance_id
     *  - $this->instance_name
     *  - $this->current_con1 
        - $this->current_con2 
        - $this->current_con3
     * 
     * @param   string  $in_workflow_app_id     APP-ID des Workflows/der Instanz
     * @param   string  $in_url_id              URL-ID, die den Staus-Dtanesatz eindeutig identifiziert
     * @return  boolean
     */
    private function readWorkflowCurrentStep($in_workflow_app_id, $in_url_id) {
        $my_status  = getWorkflowStatus($in_workflow_app_id, $in_url_id);
        
        if($my_status != array()) {
            //Wenn ein Status-Datensatz ermittelt werden konnte
            $this->current_status_ds = $my_status[0];                           //Theoretisch dürfte das Array nur genau einen Datensatz enthalten, den die URL-ID eindeutig identifiziert.
            $this->instance_id = $this->current_status_ds["workflow_status.instance_id"];
            $this->instance_name = $this->current_status_ds["workflow_instance.instance_name"];
            $this->current_con1 = $this->current_status_ds["workflow_status.con1"];
            $this->current_con2 = $this->current_status_ds["workflow_status.con2"];
            $this->current_con3 = $this->current_status_ds["workflow_status.con3"];
            $this->current_back_to_step = $this->current_status_ds["workflow_status.back_to_step"];
            $this->current_repeat_step_count = $this->current_status_ds["workflow_status.repeat_step_count"];
            $this->message_to_current_step = $this->current_status_ds["workflow_status.wkfl_comment"];
            $this->instance_finished = $this->current_status_ds["workflow_status.finished"];        //wenn der aktuelle Step zu diesem Zeitpunkt bereits abgeschlossen ist, dann ist auch die instance abgeschlossen
            $feedback = true;
        } else {
            //Für die übergebene URL-ID konnte kein Status-DS ermittelt werden.
            $feedback = false;
        }
        
        return $feedback;
    }
    
    
    
    /** ermittelt für den aktuellen Workflow_step das Mail_template. Wenn keins angegeben wurde, dann wird false zurückgegeben.
     * 
     * @return  array   Name der Datei als array Bsp.: array(filename => mail_test.html, path_rel=>"data/REQ11/mail/"); Wenn kein Wert ermittelt werden konnte wird ein leeres array zurückgegeben.
     */
    public function getMailTemplate() {
        $mail_template = array();
        $connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        $condition = "app_id = '".$this->app_id."' and workflow_id = ".$this->id." and version = ".$this->version." and step = ".$this->current_step;
        if($this->is_call_to_reject === true) {$mail_template_column = "email_template_reject";} else {$mail_template_column = "email_template";}
        //ID der Vorlage aus workflow_step ermitteln
        $mail_template_id = getDataFromTableByID($connection_id, global_variables::getNameOfDbSchemaSYS01(), "workflow_step", $mail_template_column, $condition);
        
        
        if($mail_template_id != false) {
            //anhand der id den Namen und den Pfad der Vorlagendatei aus manager.files ermitteln
            $condition = "app_id = '".$this->app_id."' and id = ".$mail_template_id;
            $path = getDataFromTableByID($connection_id, global_variables::getNameOfDbSchemaSYS01(), "files", "pathname", $condition);
            $filename = getDataFromTableByID($connection_id, global_variables::getNameOfDbSchemaSYS01(), "files", "filename", $condition);
            
            if($path!=false AND $filename!= false) {
                $mail_template["filename"] = $filename;
                $mail_template["path_rel"] = $path;
            }
        
        }
        
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> email_template für condition: '.$condition, $mail_template);
        return $mail_template;
    }
    
    
    
    
    /** Hinterlegt die url_id als Form_condition für das Control-Formular. Das Control-Formular ist wiederrum über die con1-con3-Felder mit 
     * abhängigen Formularen verknüpft und schränkt so deren Inhaltsdaten ein.
     * Das Control-Formular muss sich in $this->current_step_formlist befinden.
     * 
     * @param object    $in_pagedata        Referenz zum zentralen pagedata-object
     */
    private function setFormConditionToCurrentStep(&$in_pagedata) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> workflow: '.$this->id.", step: ".$this->current_step, "lade vorhandenen Workflow (url_id: ".$this->url_id.")");


        foreach ($this->current_step_formlist as $key => $current_form) {
            if($current_form["is_workf_control_form"] == true) {
                //Controlform: 
                $in_pagedata->setFormPropertyCondition($current_form["form_id"], "i0", "url_id = '".$this->url_id."'", false, "default", "AND");
            } 
        }
        
        
    }
    
    
    
    
    
    
    /** Erstellt eine neue Instanz (Vorgang) eines Workflows oder aktualisiert eine vorhandene Instanz.
     * Wenn eine neue Instanz erstellt wird, dann werden ein Datensatz in workflow-Instance und zwei 
     * Datensätze (1. Step = finished, 2. Step = vorbereitet) angelegt.
     * Wenn eine vorhandene Instanz aktualisiert werden soll, dann wird der aktuelle Step in workflow_status beendet
     * und ein neuer angelegt.
     * Wenn sich eine vorhandene Instanz im letzten Step befindet, dann wird dieser beendet und auch die Instanz als beendet gekennzeichnet.
     * 
     * 
     * 
     * @param   array   $in_insertdata      Array der eingefügten Daten aus dem post-object
     * @param   array   $in_primarykeys     pRimary-keys der Zieltabelle
     * @param   boolean $in_only_save       Wenn true, wird der Workflow-Status nicht verändert. 
     *                                      Falls jedoch noch kein Vorgang (Instance) existiert, wird dieser angelegt.
     *                                      Wenn es sich um einen neuen Workflow handelt, wird dieser angelegt, aber im Step 1 belassen.
     * @return  boolean
     */
    public function setNewOrUpdateInstance($in_insertdata, $in_primarykeys, $in_only_save) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> inserted_data', $in_insertdata);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> in_primarykeys', $in_primarykeys);
        
        $feedback_con_values = $this->extractConValuesFromInsertdata($in_insertdata, $in_primarykeys);
        $current_user = $this->pagedata_object->getActiveUser();
            
        $mail_to = $this->current_step_wkfl_meta_data["wkfl_step_mail_to"];
        $mail_cc = $this->current_step_wkfl_meta_data["wkfl_step_mail_cc"];
        $mail_from = $this->current_step_wkfl_meta_data["wkfl_step_mail_from"];
        $comment = $this->current_step_wkfl_meta_data["wkfl_step_comment"];
        
        if($this->current_step == 1 AND $this->current_repeat_step_count == 0) {
            //neuer Vorgang (neuer Datensatz für workflow_instance)
            $feedback_setInstance = $this->setNewInstance($in_insertdata, $in_only_save);
            
            //aktuellen Step in workflow_status anlegen
            $feedback_setStatus = $this->setNewStatus($in_only_save, $current_user, $mail_to, $mail_cc, $mail_from, $comment);
            
            //aktuelle Instanz-ID als Condition in Control-Formular hinterlegen, damit Daten der geraden erzeugten Instanz wieder geladen werden.
            $this->setFormConditionToCurrentStep($this->pagedata_object);
                
        } elseif ($this->current_step == $this->max_step AND $in_only_save == false) {
            //letzter Stepp eines Workflows wird abgeschlossen
            
            //aktuellen Step in workflow_status abschließen (finished = 1)
            $feedback_setStatus = setWorkflowStatus($this->pagedata_object, $this->app_id, $this->id, $this->version, $this->current_step, $this->instance_id, $current_user, $mail_to, $mail_cc, $mail_from, $comment, 1);
            //instance abschließen
            $feedback_setFinished = setWorkflowInstanceStatus($this->pagedata_object, $this->app_id, $this->id, $this->version, $this->instance_id, 1);
            $this->instance_finished = 1;
            //nächster Step wird nicht mehr benötigt
            $this->current_step_wkfl_meta_data["wkfl_url_nextstep"] = "";
            
            
        } elseif($in_only_save == false) {
            //aktuellen Step in workflow_status abschließen (finished = 1)
            $feedback_setStatus = setWorkflowStatus($this->pagedata_object, $this->app_id, $this->id, $this->version, $this->current_step, $this->instance_id, $current_user, $mail_to, $mail_cc, $mail_from, $comment, 1);
            
            //nächsten Step in workflow_status vorbereiten (finished = 0)
            $this->url_id_nextstep = getRandomString(64);
            $next_step = $this->current_step + 1;
            $condition = "app_id = '".$this->app_id."' and workflow_id = ".$this->id." and version = ".$this->version." and step = ".$next_step." and instance_id = ".$this->instance_id;
            $next_step_repeat_count = getMaxValue(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "workflow_status", "repeat_step_count", $condition) + 1;
            $feedback_setStatus = setNewWorkflowStatus($this->pagedata_object, $this->app_id, $this->id, $this->version, $next_step, $this->instance_id, "", $this->url_id_nextstep, $this->current_con1, $this->current_con2, $this->current_con3, "", "", "", "", 0, "NULL", $next_step_repeat_count);
            
            //url_id in nextstep hinterlegen
            $this->current_step_wkfl_meta_data["wkfl_url_nextstep"] = $this->url."&url_id=".$this->url_id_nextstep;
                
        } else {
            //Wenn Instanz bereits existiert und $in_only_save == true,
            //dann Statussatz aktualisieren. 
            //Die Inhaltsdaten wurden bereits gespeichert.
            $feedback_setStatus = setWorkflowStatus($this->pagedata_object, $this->app_id, $this->id, $this->version, $this->current_step, $this->instance_id, $current_user, $mail_to, $mail_cc, $mail_from, $comment, 0);
            //Workflow-Status-ID ermitteln, damit folgende Prozesse darauf zugreifen können
            $existing_status = $this->getWkflExistingStatus();
            if($existing_status !== false) {$this->url_id = $existing_status;}
        }
        
        
        if(($in_only_save == false) ) { 
            $this->current_step_wkfl_meta_data["wkfl_step_decision"] = "zugestimmt";
//            //Formularstatus aller Formular auf only_read setzen
//            $flat_form_list = $this->getFormListAsArray();
//            $this->pagedata_object->setFormModeForGivingFormList($flat_form_list,7);    //formmodus auf only_read setzen
        } else {
            $this->current_step_wkfl_meta_data["wkfl_step_decision"] = "";
        }
        
        
        
        
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Workflow-Attribute: ',$this->print_as_array());
        
        if ($feedback_setStatus == true) {
            $feedback = true;
        } else {
            $feedback = false;
        }
        
        
        return $feedback;
        
    }
    
    
    
    
    
    /** Ermittelt den Status, welcher nach Abschluss des aktuellen Workflow-Step, 
     * in die Content-Tabelle übertragen werden soll. Wenn kein übertrag erfolgen soll, wird false zurückgegeben.
     * 
     * @return  mixed                   rray("column" => $column, "status" => $status) oder false
     */
    public function getWorkflowStepStatusForContenttable() {
        //Workflow-Status für den aktuellen Step ergänzen
        if($this->step_list[$this->current_step]["wkfl_step_content_status_column"] != "" 
           AND $this->step_list[$this->current_step]["wkfl_step_content_status_value"] != "do nothing") {
            //Wenn der aktuelle Workflow-Status auch in der Workflow-Comtent-Tabelle gespeichert werden soll
            
            if($this->step_list[$this->current_step]["wkfl_step_content_status_value"] === "") {
                //Es wurde keine Kosntante als Value für den Status angegeben. Daher wird der Status der instance verwendet
                if($this->current_step == $this->max_step) {$status = 1;} else {$status = 0;}
            } else {
                //Es liegt eine Konstante vor.
                $status = $this->step_list[$this->current_step]["wkfl_step_content_status_value"];
            }
            
            $column = $this->step_list[$this->current_step]["wkfl_step_content_status_column"];
            return array("column" => $column, "status" => $status);
        } else {
            return false;
        }
    }
    
    
    
    /** Löscht die eine Instanz eines Workflows, inkl. aller nachgeordneter Workflow-Daten.
     * 
     * @return  integer     4005 -> Instanz gelöscht
     *                      -4005 -> Löschen nicht möglich, da workflow-Step>1
     *                      -4001 -> Löschen nicht möglich, da aktuelle Rolle nicht auf diesen Workflow-step zugreifen darf.
     */
    public function deleteInstance() {
        
        $feedback = 0;
        
        //Zugriffsberechtigung prüfen
        If($this->checkAccess()==1) {

            //Voraussetzungen prüfen. Instance darf nur im ersten step gelöscht werden.
            $first_step = array_key_first($this->step_list);
            If($this->current_step > $first_step) {
                //Abbruch, die Instance darf nicht mehr gelöscht werden. 
                //Hinweis an Anwender, dass stattdessen abgelehnt werden muss.
                $feedback = -4005;
            } else {
                //Instance löschen
                $feedback_deleteInstance = $this->deleteInstanceHelper();
                $feedback = 4005;
            }
            
        } else {
            //Zugriff nicht gestattet
            $feedback = -4001;
        }
        
        
        return $feedback;
        
    }
    
    
    
    
    /** Löscht die Instance aus der DB-Tabelle workflow_instance.
     * Aufgrund der Datenbank-Constraints werden alle abhängigen Workflow-Tabellen ebenfalls gelöscht.
     * 
     * @return type
     */
    public function deleteInstanceHelper() {
        $schema_kernel = global_variables::getNameOfDbSchemaSYS01();
        

        //SQL-Array für Löschbefehl aufbauen
        $sql_daten["schema"] = $schema_kernel;
        $sql_daten["table"] = "workflow_instance";
        $sql_daten["where"] = "app_id='".$this->app_id."' and workflow_id = ".$this->id." and version = ".$this->version." and instance_id = ".$this->instance_id;
        $sql_daten['logdata_id_data'] = $this->instance_id;
        $sql_daten["logdata"] = "Workflow-Vorgang ".$this->instance_id." inkl. aller abhängiger Daten gelöscht";

        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = true;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();
        $dummy_form['form.log_id_spalte'] = "instance_id";
        $dummy_form['form.name'] = "Workflow-Instanz";

        $feedback = deleteData($sql_daten, $dummy_form, $this->pagedata_object->getCurrentUserFromSession(), $this->pagedata_object);

        
        return $feedback;
    }
    
    
    
    
    
    /** Erstellt einen neuen Datensatz in der Tabelle workflow_status.
     * Wenn $in_only_save == false, dann wird dieser Datensatz auf finished = 1 gesetzt und es wird 
     * zudem ein neuer Datensatz für den nächsten Step mit finished = 0 angelegt.
     * 
     * 
     * HINWEIS: Es werden die Object-Attribute 
     *  $this->url_id,
     *  $this->step_list[$this->current_step]["wkfl_url"] 
     *  $this->url_id_nextstep und
     *  $this->current_step_wkfl_meta_data["wkfl_url_nextstep"]
     * gesetzt.
     * 
     * @param   bool    $in_only_save       Gibt an, ob der Anwender die Daten des aktuellen Steps nur speichern oder gleich den nächsten Step erreichen möchte.
     * @param   string  $in_current_user    id des aktuellen accounts
     * @param   string  $in_mail_to
     * @param   string  $in_mail_cc
     * @param   string  $in_mail_from
     * @param   string  $in_comment
     * @return  bool                        Wenn der Datensatz angelegt werden konnte, dann true, ansonsten False.
     */
    private function setNewStatus($in_only_save, $in_current_user, $in_mail_to, $in_mail_cc, $in_mail_from, $in_comment) {
        if($in_only_save == true) {$finished = 0;} else {$finished = 1;}
        
        $existing_status = $this->getWkflExistingStatus();
          
        
        if($existing_status === false) {
            //der Statussatz existiert nicht. Er wird daher für current_step neu gesetzt.
            $this->url_id = getRandomString(64);
            $feedback_setStatus = setNewWorkflowStatus($this->pagedata_object, $this->app_id, $this->id, $this->version, $this->current_step, $this->instance_id, $in_current_user, $this->url_id, $this->current_con1, $this->current_con2, $this->current_con3, $in_mail_to, $in_mail_cc, $in_mail_from, $in_comment, $finished);
        } else {
            //der Statussatz existiert bereits. Er wird aktualisiert, ggf. sogar beendet.
            $feedback_setStatus = setWorkflowStatus($this->pagedata_object, $this->app_id, $this->id, $this->version, $this->current_step, $this->instance_id, $in_current_user, $in_mail_to, $in_mail_cc, $in_mail_from, $in_comment, $finished);
            $this->url_id = $existing_status;
        }
        $this->step_list[$this->current_step]["wkfl_url"] = $this->url."&url_id=".$this->url_id;

        if($this->instance_finished == 0 AND $in_only_save == false) {
            //nächsten Step in workflow_status vorbereiten (finished = 0)
            $this->url_id_nextstep = getRandomString(64);
            $feedback_setStatus = setNewWorkflowStatus($this->pagedata_object, $this->app_id, $this->id, $this->version, $this->current_step + 1, $this->instance_id, "", $this->url_id_nextstep, $this->current_con1, $this->current_con2, $this->current_con3, "", "", "", "", 0);
            //url_id in nextstep hinterlegen
            $this->current_step_wkfl_meta_data["wkfl_url_nextstep"] = $this->url."&url_id=".$this->url_id_nextstep;
        }
        
        
        return $feedback_setStatus;
    }
    
    
    
    /** Ermittelt die URL-ID, falls diese existiert
     * 
     * @return  mixed           Url-ID des aktuellen Satusdatensatzen, falls dieser existiert, oder false
     */
    private function getWkflExistingStatus() {
        $existing_status = false;
        $connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        $schema = global_variables::getNameOfDbSchemaSYS01();
        
        //wenn im gleichen step zuvor bereits gespeichert wurde, dann existiert bereits ein status-Datensatz für diesen step.
        $condition = "app_id = '".$this->app_id."' and finished = 0 and workflow_id = ".$this->id." and instance_id = '".$this->instance_id."' and step = ".$this->current_step;
        $existing_status = getDataFromTableByID($connection_id, $schema, "workflow_status", "url_id", $condition);
        return $existing_status;
    }
    
    
    
    /** Erstellt einen neuen Datensatz in der Tabelle workflow_instance.
     * Dabei wird geprüft, wenn $in_only_save = true, ob die Instanz bereits existiert
     * 
     * HINWEIS: Es werden die Object-Attribute 
     *  $this->instance_id,
     *  $this->instance_name und
     *  $this->instance_finished
     * gesetzt.
     * 
     * @param   array   $in_insertdata      Array der eingefügten Daten aus dem post-object
     * @return  bool                        Wenn der Datensatz angelegt werden konnte, dann true, ansonsten False.
     */
    private function setNewInstance($in_insertdata, $in_only_save) {
        
        $connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        $schema = global_variables::getNameOfDbSchemaSYS01();
        $this->instance_name = $this->buildInstanceName($in_insertdata[0]);
        $existing_instance = false;
        
        //wenn im ersten step zuvor bereits gespeichert wurde, kann es sein, dass eine entsprechende instance bereits existiert,
        //aber der Workflow-Aufruf dennoch ohne url_id erfolgte
        $condition = "app_id = '".$this->app_id."' and finished = 0 and workflow_id = ".$this->id." and instance_name = '".$this->instance_name."'";
        $existing_instance = getDataFromTableByID($connection_id, $schema, "workflow_instance", "instance_id", $condition);
            
        
        
        
        if($existing_instance === false) {
            $max_instance_id = getMaxValue($connection_id, $schema, "workflow_instance", "instance_id");
            $this->instance_id = $max_instance_id + rand(1,10);
            if($this->current_step == $this->max_step) {
                //für den Fall, dass ein Workflow nur genau einen Step hat
                $this->instance_finished = 1;
            } else {
                $this->instance_finished = 0;
            }
            $feedback = setNewWorkflowInstance($this->pagedata_object, $this->app_id, $this->id, $this->version, $this->instance_id, $this->instance_name, $this->instance_finished);
        } else {
            $this->instance_id = $existing_instance;
            $this->instance_finished = 0;
            $feedback = true;
        }
        
        return $feedback;
    }
    
    
    
    
    
    /** schließt den aktuellen Step ab und setzt als nächsten Step jedoch wieder den vorherigen an.
     * Dazu wird in workflow_step ein neuer Datensatz angelegt, der die vorherige Step-Nummer erhält.
     * 
     * @param   array   $in_insertdata      Array der eingefügten Daten aus dem post-object
     * @return  integer                     4002 = erfolgreich, -4002, -4003 = Fehler
     * @throws  Exception
     */
    public function rejectWorkflowstep(&$in_insertdata) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> inserted_data', $in_insertdata);
        $current_user = $this->pagedata_object->getActiveUser();
        $this->is_call_to_reject = true;
        
        if($this->instance_finished == 1) {
            //Fehler werfen, wenn Vorgang bereits abgeschlossen ist
            $this->setFeedbackCode(-4007);
            throw new Exception(-4007);
        }
            
        $mail_cc = $this->current_step_wkfl_meta_data["wkfl_step_mail_cc"];
        $mail_from = $this->current_step_wkfl_meta_data["wkfl_step_mail_from"];
        $comment = $this->current_step_wkfl_meta_data["wkfl_step_comment"];
        
        //Zielstep ermitteln
        $back_to_step = $this->step_list[$this->current_step]["wkfl_back_to_step"];
        if($back_to_step == "") {$go_back_to_step = $this->current_step-1;} else {$go_back_to_step = $back_to_step;}
        
        //Wenn Zielstep < 1, dann Fehler ausgeben.
        if($go_back_to_step<1) {
            //Fehler werfen, wenn Vorgang bereits am Anfang stand. Weiter zurück geht nicht ...
            $this->setFeedbackCode(-4002);
            throw new Exception(-4002);
        }
        
        
        //Mail-To ermitteln (=> From-Mail des Zielsteps)
        $mail_to = $this->getFrommailFromStep($go_back_to_step);
        $this->current_step_wkfl_meta_data["wkfl_step_mail_to"] = $mail_to;
        
        //Mail-To auch in in_insertdata hinterlegen, damit nachfolgende Funktionen darauf zugreifen können
        //Theoretisch gibt es nur einen einzelnen DS in in_insertdata
        $in_insertdata[0]["workflow"]["wkfl_step_mail_to"] = $mail_to;
        
        
        //Anzahl des erneuten Aufrufes des "alten" Steps angeben
        $condition = "app_id = '$this->app_id' and workflow_id = $this->id and version = $this->version and step = $go_back_to_step and instance_id = $this->instance_id ";
        $order_by = "repeat_step_count DESC";           //absteigend, damit höchster Wert oben steht.
        $used_step_count = getDataFromTableByID(global_variables::getConnectionIdOfDbSchemaSYS01(), global_variables::getNameOfDbSchemaSYS01(), "workflow_status", "repeat_step_count", $condition, $order_by);
        $new_step_count =  $used_step_count + 1;
        
        //aktuellen Step in workflow_status abschließen (finished = 1) und neuen Zielstep vermerken
        $feedback_setStatus = setWorkflowStatus($this->pagedata_object, $this->app_id, $this->id, $this->version, $this->current_step, $this->instance_id, $current_user, $mail_to, $mail_cc, $mail_from, $comment, 1, $go_back_to_step);

        //nächsten/vorherigen Step in workflow_status vorbereiten (finished = 0)
        $this->url_id_nextstep = getRandomString(64);
        $feedback_setStatus = setNewWorkflowStatus($this->pagedata_object, $this->app_id, $this->id, $this->version, $this->current_step - 1, $this->instance_id, "", $this->url_id_nextstep, $this->current_con1, $this->current_con2, $this->current_con3, "", "", "", "", 0, $back_to_step, $new_step_count);

        //url_id in nextstep hinterlegen
        $this->current_step_wkfl_meta_data["wkfl_url_nextstep"] = $this->url."&url_id=".$this->url_id_nextstep;

        
        
        //Formularstatus aller Formular auf only_read setzen
        $flat_form_list = $this->getFormListAsArray();
        $this->pagedata_object->setFormModeForGivingFormList($flat_form_list,7);    //formmodus auf only_read setzen
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Workflow-Attribute: ',$this->print_as_array());
        
        if ($feedback_setStatus == true) {
            $this->setFeedbackCode(4002);
        } else {
            $this->setFeedbackCode(-4003);
        }
        
        $this->current_step_wkfl_meta_data["wkfl_step_decision"] = "abgelehnt";
        
        return $this->getFeedbackCode();
        
    }
    
    
    
    /** Gibt die url_id des aktuellen Steps zurück.
     *  Diese wird mit dem GET-Parameter url_id weitergegeben.
     * @return  string
     */
    public function getUrlid() {
        return $this->url_id;
    }
    
    
    
    /** Bildet aus den ersten beiden values von insertdata einen Namen für die Workflow-Instanz
     * 
     * @param   array   $in_insertdata          Array eines insertdata-Datensatzes (ACHTUNG, nur den ersten Datensatz übergeben.
     * @return  string
     */
    private function buildInstanceName($in_insertdata) {
        $feedback = "";
        $delimiter = "";
        $countFields = 0;
        foreach ($in_insertdata["content"] as $key => $current_field) {
            $feedback = $current_field.$delimiter.$feedback;
            $delimiter = " - ";
            $countFields = $countFields + 1;
            if($countFields >= 2) {break;}
        }
        return $feedback;
    }
    
    
    
    /** Ermittelt aus Insertdata die Values der Primary-Keys und übergibt diese an 
     * current_con1, current_con2 und current_con3
     * 
     * @param   array   $in_insertdata      Liste der eingefügten Daten, inkl. Values für PK-Spalten  
     * @param   string  $in_primarykeys     Liste der Primarykeys aus dem Formular-Array
     * @return  integer                     siehe Konstantenliste 35; -222 -> keine PK's gefunden, 222 PKs ermittelt.  
     */
    private function extractConValuesFromInsertdata($in_insertdata, $in_primarykeys) {
        //PKs in array umwandeln
        $pk_list = explode(",", $in_primarykeys);
        
        
        
        if($in_primarykeys == "") {
            //Es sind keine PKs vorhanden
            $feedback = -222;
        } else {
            //Values für primaryKeys aus dem ersten DS von Insertdata ermitteln
            $this->current_con1 = $in_insertdata[0]["content"][$pk_list[0]];
            if(isset($pk_list[1])) {$this->current_con2 = $in_insertdata[0]["content"][$pk_list[1]];}
            if(isset($pk_list[2])) {$this->current_con3 = $in_insertdata[0]["content"][$pk_list[2]];}
            $feedback = 222;
        }
        
        
        return $feedback;
        
    }
    
    
    
    /** Ermittelt die grundlegenden Daten eines Workflows, auch dann, wenn noch kein Vorgang existiert.
     * Als current_step wird der erste Workflow_step gesetzt.
     * 
     * @param object    $in_pagedata        Referenz auf das pagedata-Object
     * @param mixed     $in_workflow_url_id Url-ID, anhand dessen der aktuelle Step aus workflow_status ermittelt werden kann
     */
    private function buildWorkflowBasicMetadata(&$in_pagedata, $in_workflow_url_id) {													
        
        
        
        //Workflow-Grunddaten aus dem MaskArray ermitteln
        $_mask_array = $in_pagedata->getMaskArray();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> mask_array: ', $_mask_array);
        $metadata_array = getWorkflowBasicdata($_mask_array["workflow_app_id"], $_mask_array["workflow_id"], $_mask_array["workflow_version"]);
        
        
        if($in_workflow_url_id === false) {
            //es soll ein neuer Workflow angelegt werden. Daher wird der erste Step des Workflows als current_step genutzt
            $key_from_current_step = 0;
        } else {
            //current_step muss anhand der url_id ermittelt werden.
            $this->current_step = getDataFromTableByID(global_variables::getConnectionIdOfDbSchemaSYS01(), global_variables::getNameOfDbSchemaSYS01(), "workflow_status", "step", "url_id='".$in_workflow_url_id."'");
                
            if($this->current_step === false) {
                //Workflowaufruf erfolgte mit einer nicht existierenden URL-ID
                $this->call_undefined_url_id = true;
                $key_from_current_step = 0;
            } else {
                $this->call_undefined_url_id = false;
                foreach ($metadata_array as $key => $value) {
                    If($value["workflow_step.step"] == $this->current_step) {$key_from_current_step = $key; break;}
                }
            }
        }
        
        
        
        if($metadata_array !== false) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> workflow_data: ', $metadata_array);
        
            //$metadata_array enthält so viele Datensätze enthalten, wie es Steps in einem Workflow gibt. 
            $data = $metadata_array[$key_from_current_step];  
            $this->url_id = $in_workflow_url_id;
            $this->app_id = $data["workflow.app_id"];
            $this->name = $data["workflow.name"];
            $this->id = $data["workflow.workflow_id"];
            $this->version = $data["workflow.version"];
            $this->current_step = $data["workflow_step.step"];                 
            $this->current_step_name = $data["workflow_step.name"];
            $this->max_step = $data[".max_step"];
            $this->instance_id = false;
            $this->description = $data["workflow.description"];
            $this->current_step_description = $data["workflow_step.description"];
            $this->mask_id = $_mask_array["id"];
            $this->mask_app_id = $_mask_array["app_id"];
            $this->current_step_controlform_app_id = $data["workflow_step_form.workflow_controlform_app_id"];
            $this->current_step_controlform_id = $data["workflow_step_form.workflow_controlform_id"];
               
            
        } 
    }	
    
    
    
    /**
     * Ermittelt aus der  Liste aller Formulare des aktuellen Workflow-Steps das Control-Formular.
     * 
     * @param  boolean  $in_workflowFormsFromCurrentStep        Array der Formulare des aktuellen Steps; Bsp.:
     *                                                          Array
                                                                    (
                                                                        [972] => Array
                                                                            (
                                                                                [step] => 1
                                                                                [form_app_id] => BIM01
                                                                                [form_id] => 972
                                                                                [is_workf_control_form] => 0
                                                                            )

                                                                        [1304] => Array
                                                                            (
                                                                                [step] => 1
                                                                                [form_app_id] => SYS01
                                                                                [form_id] => 1304
                                                                                [is_workf_control_form] => 1
                                                                            )

                                                                    )
     * @return array                                            Array des Controlformulars; Bsp.:
     *                                                          Array
                                                                    (
                                                                        [step] => 1
                                                                        [form_app_id] => SYS01
                                                                        [form_id] => 1304
                                                                        [is_workf_control_form] => 1
                                                                    )
     */
    private function getWorkflowControlform($in_workflowFormsFromCurrentStep) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Workflow_forms from current Step: ', $in_workflowFormsFromCurrentStep);  
        $feedback = array();
        
        foreach ($in_workflowFormsFromCurrentStep as $key => $current_form) {
            if($current_form["is_workf_control_form"] == true) {
                $feedback = $current_form;
            }
        }
                
            
        
        return $feedback;
    }
    
    
    
    
    /** Gibt die Liste der Formulare des aktuellen Steps zurück.
     * 
     * @return array            Bsp.: array{23=>23, 45=>45}
     */
    public function getFormListAsArray() {
        $feedback = array();
        foreach ($this->current_step_formlist as $key => $current_form) {
            $feedback[$current_form["form_id"]] = $current_form["form_id"];
        }
        return $feedback;
        
    }
    
    
    
    /** Gibt den Namen/die Bezeichnung eines Workflows zurück.
     * 
     * @return string
     */
    public function getName() {
        return $this->name;
    }
    
    
    
    /** Gibt die Beschreibung eines Workflows zurück.
     * 
     * @return string
     */
    public function getDescription() {
        return $this->description;
    }
    
    
    
    
    /** Gibt die Beschreibung des aktuellen Steps zurück.
     * 
     * @return string
     */
    public function getStepDescription() {
        return $this->current_step_description;
    }
    
    
    
    /** Gibt die maximale Anzahl von Steps des Workflows zurück.
     * 
     * @return string
     */
    public function getMaxStep() {
        return $this->max_step;
    }
    
    
    
    
    /** ermittelt die From-Adresse aus workflow_status, welche beim ersten Step verwendet wurde.
     * 
     * @return  string      Bsp.: example@my_domain.de
     */
    public function getFrommailFromFirstStep() {
        $first_step = array_key_first($this->step_list);
        $mail = $this->getFrommailFromStep($first_step);
        return $mail;
    }
    
    
    
    /** ermittelt die From-Adresse aus workflow_status, welche einem bestimmten Step verwendet wurde.
     * 
     * @param   integer     Step-Number, dessen verwendete From-Mail ermittelt werden soll.
     * @return  string      Bsp.: example@my_domain.de, Wenn keine Mailadresse ermittelt werden kann, wird ein Leerstring zurückgegeben.
     */
    public function getFrommailFromStep($in_step) {
        //in der folgenden condition stellt die Teilbedingung "back_to_step is null" sicher, dass bei mehreren Ablehnungen, die letzte positive Wiederholung des steps gefunden wird.
        $condition = "app_id = '".$this->app_id."' and workflow_id = ".$this->id." and version = ".$this->version." and step = ".$in_step." and instance_id = ".$this->instance_id." and finished = 1 and back_to_step is null";
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> condition: ', $condition);
      
        $mail = getDataFromTableByID(global_variables::getConnectionIdOfDbSchemaSYS01(), global_variables::getNameOfDbSchemaSYS01(), "workflow_status", "email_from", $condition);
        if($mail === false) {$mail = "";}
        return $mail;
    }
    
    
    
    
    
    
    /** Ermittelt den Kommentar, der vom Bearbeiter des vorherigen Steps erfasst wurde aus der Tabelle workflow_status.
     * Wenn kein Kommentar ermittelt werden konnte, wird ein Leerstring zurückgegeben.
     * 
     * @return string
     */
    public function getCommentFromlastStep() {
        
        //key des vorherigen Steps ermitteln
        $prev_key = -1;
        foreach ($this->step_list as $key => $value) {
            if($key == $this->current_step) {
                $prev_step = $prev_key;
                break;
            }
            $prev_key = $key;
        }
        
        
        //comment aus workflow_status auslesen
        $condition = "app_id = '".$this->app_id."' and workflow_id = ".$this->id." and version = ".$this->version." and step = ".$prev_step." and instance_id = ".$this->instance_id;
        $wkfl_comment = getDataFromTableByID(global_variables::getConnectionIdOfDbSchemaSYS01(), global_variables::getNameOfDbSchemaSYS01(), "workflow_status", "wkfl_comment", $condition, "repeat_step_count desc");
        if($wkfl_comment === false) {$wkfl_comment = "";}
        return $wkfl_comment;
    }
    
    
    
    
    /** Gibt den Namen des aktuellen Workflow-Step zurück.
     * 
     * @return string
     */
    public function getCurrentStepName() {
        return $this->current_step_name;
    }
    

    
    
}
