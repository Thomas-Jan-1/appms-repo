<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

/**
 * Die Klasse stellt Funktionen bereit, welche mit Button-Clicks verbunden werden können.
 * Dazu müssen die Funktionen in der Datenbanktabelle manager.button_functions registriert werden.
 * 
 * Als Beispiele können alle Methoden in ../controller/pagedata_class.php dienen, die mit dem Präfix
 * "internFunction_" beginnen. Einziger zu beachtender Unterschied ist dabei, dass diese sich bereits 
 * in dem Objekt  pagedata befinden und daher auf andere Methoden desselben Objektes  mit "$this" zugreifen.
 * Hier erfolgt der Zugriff auf das pagedata-Objekt über den Übergabeparameter "$in_pagedata".
 * 
 *
 * @author Thomas J.
 */
class functions_buttonclick {
    
    function __construct() 
    { 
        
    }
    
    /** Geben Sie dieser Funktion einen sinnvollen Namen und registrieren sie diese in der
	 *  Datenbanktabelle manager.button_functions. Anschließend kann sie bei der Konfiguration
	 *  eines Formulars über die Tabelle "Felder" einem beliebigen Button zugeordnet werden.
     * 
     * @param   object      $in_pagedate        Referenz auf pageData-Object
     * @return  integer                     	Beispiel für Reaktionen: 2 = erfolgreich ; -2 = fehlgeschlagen
     */
    public function myButtonExampleFunction(&$in_pagedate) {
        $feedback = 0;
		
		//lesender Zugriff auf Session-Daten
        $mySession = $in_pagedate->getSessionArrayCurTab();
        //PostObjekt holen
        $internPostObject = $in_pagedate->getPostObject();
        //Formulardaten des sendenden Formulars ermitteln
        $senderform_id = $internPostObject->getSenderformId();
        $senderInstance_id = $in_pagedate->getPostObject()->getSenderInstanceId();
        
        //Daten der Senderform ermitteln
        $senderFormData = $internPostObject->getFormContent($senderform_id);
        
	addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte Funktion', __FUNCTION__);	
		
        //---------------
	//hier Ihren Code einfügen
		
	//---------------
        
        
        return $feedback;
    }
    
    
}

?>
