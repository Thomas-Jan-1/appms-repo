<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


/** Jede DB-spezifische-KLasse muss in einem eigenen Namespace liegen (virtueller Ordner).
 * Der Namespace muss der Dateinamekonvention folgen.
 * 
 * Bsp. für Postgres:
 * 
 * DBMS = postgresql
 * Dateiname für die DB-spezifischen Klassen = backup_postgresql_class.php
 * namespace = postgresql
 * Eintrag in konstantenkatalog (konstantentyp_id = 50) = postgresql
 */
//namespace postgresql;


/**
 * Description of backup_postgresql_class
 * Diese Klasse ist datenbankspezifisch. D.h. sie muss pro DBMS angelegt werden. Eine Datei für das DBMS Oracle
 * müsste den Namen backup_oracle_class.php tragen (vgl. hierzu auch die Dokumentation).
 * In der Klasse backupTable_universal können Methoden auch ausprogrammiert werden, wenn sie mit Standard-SQL-Methoden
 * realisiert werden können und somit eben nicht datenbankspezifisch benötigt werden oder zumindest für mehrere DBMS anwendbar sind.
 * Die Methoden in dieser Klasse beziehen sich immer auf eine einzelne Tabelle. Wenn Methoden SQL-Befehler für viele Tabellen erzeugen sollen,
 * dann sind diese in backuphelper_universal unterzubringen. 
 * 
 * Alle Funktionen, die vermutlich datenbankabhängig angelegt werden müssen, sind mit "Attention NO-SQL-Standard" gekennzeichnet.
 */
class backupTable_universal {
    
    /**
     *
     * @var     string      Datenbankschema der Tabelle 
     */
    protected $_schema;
    
    /**
     *
     * @var     string      ID der zu verwendedden Connection 
     */
    protected $_connection_id;
     
    
    /** 
     *
     * @var     array       Zugriffsrechte der Tabelle als Array
     */
    public $grants;
    
    /**
     *
     * @var     string      Name der Tabelle 
     */
    public $name;
    
    /**
     *
     * @var     string      Art der Tabelle, wird aus information_schema übernommen. Derzeit kann nur der Wert "BASE TABLE" enthalten sein. 
     */
    protected $_tabletype;
    
    /**
     *
     * @var     array       Liste von Column-Objekten 
     */
    protected $_columnObjects;
    
    
    /**
     *
     * @var     string       Name der Spalte, die auf die app_id referenziert
     */
    protected $_column_app_id;
    
    
    /**
     *
     * @var     array       Liste dr Primary-Keys 
     */
    protected $_primary_columns = array();
    
    /**
     *
     * @var     array       Liste der Foreign-Keys und aller zugehörigen Daten 
     *                      Felder: referential_constraints.constraint_name
                            , key_column_usage_a.table_schema
                            , key_column_usage_a.table_name
                            , key_column_usage_a.column_name
                            , key_column_usage_b.table_name as foreign_table_name
                            , key_column_usage_b.column_name as foreign_column_name
     */
    protected $_foreignkeys_data = array();
    
    
    /**
     *
     * @var     string      enthält den Create-Befehl für die aktuelle Tabelle, jedoch ohne den GRANT-Teil. 
     */
    protected $_createTableCommand = "";
    
    
    /**
     *
     * @var     array       Liste der GRANT-Commands 
     */
    protected $_grantCommands = array();
    
    
    /**
     *
     * @var     array      enthält den oder die Alter-Table-Befehl zum Anlegen der ForeignKeys 
     */
    protected $_createConstraintCommand = array();
    
    
    /**
     *
     * @var     array      enthält den oder die Alter-Table-Befehl zum Droppen der ForeignKeys 
     */
    protected $_dropConstraintCommand = array();
    
    
    /**
     *
     * @var     array      enthält alle Daten der Indexe 
     */
    protected $_index_data = array(); 
    
    
    /**
     *
     * @var     array       Liste der CREATE-INDEX-Befehle 
     */
    protected $_createIndexCommands = array();
    
    
    /**
     *
     * @var     array       Liste der INSERT-Kommandos 
     */
    protected $_insertCommands = array();
    
    
    /**
     *
     * @var     array       Liste der INSERT-Kommandos für Konfigurationsdaten 
     */
    protected $_insertCommandsConfigtable = array();
    
    
    /**
     *
     * @var     array       view-Definition
     */
    protected $_viewDefinition = "";
    
    
    /**
     *
     * @var     array       function-Definition
     */
    protected $_functionDefinition = "";
    
    
    /**
     *
     * @var     array       Liste der Update-Sequence-Commands. Diese werden nicht in allen DBMS benötigt. 
     */
//    protected $_updateSequenceCommands = array();
    
    
    /**
     *
     * @var     string      SQL-Delete-Command für die aktuelle Tabelle
     */
    public $deleteCommand = "";
    
    
    /**
     *
     * @var     boolean     Gibt an, ob es sich bei der aktuellen Tabelle um eine Konfigurationstabelle aus dem Kernmodul handelt und diese aktuell auch als solche gesichert werden soll. 
     */
    public $is_configTable = false;
    
    
    /**
     *
     * @var     boolean     Gibt an, ob es sich bei der aktuellen Tabelle um eine Inhaltstabelle handelt 
     */
    public $is_contentTable = false;
    
    
    /**
     *
     * @var     boolean     Gibt an, ob es sich bei der aktuellen Tabelle um eine Tabelle mit Inhaltsdaten handelt, welche jedoch in einer anderen APP (i.d.R. SYS01) liegt. 
     */
    public $is_addContentTable = false;
    
    
    /**
     *
     * @var     boolean     Gibt an, ob es sich um eine vquery-Table handelt. 
     *                      vquery-Tables werden beim Backup weder benötigt, noch beachtet. 
     *                      Sie nutzen allerdings die Backup-Klasse als Hilfsklasse, um Table-Create- und 
     *                      INSERT-Befehl in der jeweils notwendigen DB-Syntax zu generieren. 
     */
    public $is_vqueryTable = false;     
    
    
    /**
     *
     * @var     boolean     Gibt an, ob es sich bei der aktuellen Tabelle um eine Tabelle der DB-Struktur handelt (zu jeder Strukturtabelle sollte es auch ein äquivalent ebi den Content-tabellen geben)
     */
    public $is_structureTable = false;
    
    /**
     *
     * @var     string      Enthält den Value aus der Datenbanktabelle "backup_tabledefinitions.definition.  
     */
    public $_backupTableDefinition = "";
    
    
    
    
    
    
    
    
    /**
     * Eine backupTable enthält alle Daten und Methoden, um das Backup für eine Tabelle
     * zu erstellen. Es muss anschließend mit Hilfe der initialize-Methoden noch entschieden 
     * werden, ob es sich um eine Source- oder ein TargetObjekt handelt.
     * Bsp.: Wenn ein Backup von Postgres für MySql erstellt wird. Dann wird für jede Tabelle
     * ein Source-Objekt aus dem Postgres-Treiber und
     * ein Target-Objekt aus dem MySql-Treiber benötigt.
     * 
     */
    function __construct() {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , "starte constructor", "INFO");
    }
    
    
    /** Erzeugt alle Daten, die aus dem Quellsystem für eine Tabelle ermittelt werden müssen (columns, constraints, indexi usw.)
     * 
     * @param string    $in_connection_id           ID der connection
     * @param array     $in_table                   array welches den Namen und das Schema der Tabelle enthält (Array(tables.table_schema => "widerspruch", tables.table_name => "kanzlei"))
     * @param boolean   $in_isStructureTable    Gibt an, ob die Tabellenstruktur (CREATE TABLE, INDEX, PK usw) gesichert werden soll.
     * @param boolean   $in_isConfigTable           Gibt an, ob die aktuelle Tabelle als Konfigurationstabelle gekennzeichnet werden soll.
     * @param boolean   $in_isAddContentTable       Gibt an, ob die aktuelle Tabelle als AddContenttabelle gekennzeichnet werden soll.
     * @param boolean   $in_isContentTable          Gibt an, ob die aktuelle Tabelle als Contenttabelle gekennzeichnet werden soll.
     * 
     */
    function initializeAsSourceTable($in_connection_id, $in_table, $in_isStructureTable, $in_isConfigTable, $in_isAddContentTable, $in_isContentTable) {
        
        $this->_schema = $in_table["tables.table_schema"];
        $this->name = $in_table["tables.table_name"];
        $this->_tabletype = $in_table["tables.table_type"];
        $this->is_configTable = $in_isConfigTable;
        $this->is_addContentTable = $in_isAddContentTable;
        If($in_table["backup_tabledefinitions.definition"] <> "ignoreIfContentBackup") {$this->is_contentTable = $in_isContentTable;}
        $this->is_structureTable = $in_isStructureTable;
        $this->_backupTableDefinition = $in_table["backup_tabledefinitions.definition"];
        $this->_connection_id = $in_connection_id;
        $this->_column_app_id = $in_table["backup_tabledefinitions.app_column"];
        
        
        
        //Columns ermitteln (analog der Ermittlung der Tabellenliste
        $this->getColumnlist();
        
//        if($in_isStructureTable == true) {
            //Primary-Keys aus dem information_schema ermitteln
            $this->_primary_columns = $this->getConstraintKeys("PRIMARY");

            //INDEXI über DB-spezifische Methode ermitteln 
            $this->_index_data = $this->getIndexdata();
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für getIndexData', $this->_index_data);
            
            //GRANTS aus Information_schema ermitteln
            $this->grants = $this->getGrantsForTable();
//        } 
        

        //Foreign-Keys aus information_schema.table_constraints ermitteln
        $this->_foreignkeys_data = $this->getForeignKeydata();
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für foreignkeys', $this->_foreignkeys_data);
        
    }
    
    
    
    
    
    /** Erzeugt alle Daten, die aus dem Quellsystem für eine view ermittelt werden müssen (Create-Command und Grant-Commmand.)
     * Die Ergebnisse werden in den Eigenschaften _grantCommands und _viewDefinition hinterlegt
     * 
     * @param string    $in_connection_id           ID der connection
     * @param array     $in_view                    array welches den Namen und das Schema der Tabelle enthält (Array(tables.table_schema => "widerspruch", tables.table_name => "kanzlei"))
     * @param object    $in_Backup_object           übergeordnetes Backup-Objekt
     * 
     */
    function initializeAsView($in_connection_id, $in_view, $in_Backup_object) {
        
        $this->_schema = $in_view["views.view_schema"];
        $this->name = $in_view["views.view_name"];
        $this->_viewDefinition = $in_view["views.view_definition"];
        $this->_tabletype = $in_view["views.view_type"];
        $this->_connection_id = $in_connection_id;
        
        
        //view-Definition ermitteln
        $this->_viewDefinition = $this->createViewCommand();
        
        //GRANTS aus Information_schema ermitteln
        if($this->_tabletype == 'view') {
            //normale view
            $this->grants = $this->getGrantsForTable();
        } else {
            //materialized view
            $this->grants = $this->getGrantsForMatView();
            //INDEXI über DB-spezifische Methode ermitteln 
            $this->_index_data = $this->getIndexdata();
            $this->_createIndexCommands = $this->createIndexCommand();
        }
        //Grant-Commands erzeugen
        $this->_grantCommands = $this->createGrantCommands($this->grants, $in_Backup_object->backup_mode->grantsToUser, $this->_tabletype);
            

    }
    
    
    
    
    /** Erzeugt alle Daten, die aus dem Quellsystem für eine function ermittelt werden müssen (Create-Command und Grant-Commmand.)
     * Die Ergebnisse werden in den Eigenschaften _grantCommands und _functionDefinition hinterlegt
     * 
     * @param string    $in_connection_id           ID der connection
     * @param array     $in_function                array welches den Namen und das Schema der Funktion enthält (Array(function.schema => "widerspruch", function.name => "kanzlei"))
     * @param object    $in_Backup_object           übergeordnetes Backup-Objekt
     * 
     */
    function initializeAsFunction($in_connection_id, $in_function, $in_Backup_object) {
        
        $this->_schema = $in_function["function.schema"];
        $this->name = $in_function["function.name"];
        $this->_functionDefinition = $in_function["function.def"];
        $this->_tabletype = "function";
        $this->_connection_id = $in_connection_id;
        
        
        //GRANTS aus Information_schema ermitteln
        $this->grants = $this->getGrantsForFunctions();
        //Grant-Commands erzeugen
        $this->_grantCommands = $this->createGrantCommands($this->grants, $in_Backup_object->backup_mode->grantsToUser, "function");
            

    }
    
    
    
    
    /** Initialisiert das Table-Objekt als vQuery-Table.
     * In den Eigenschaften
     *      $this->_createTableCommand und
     *      $this->_insertCommands
     * werden die entsprechenden Befehle abgelegt.
     * 
     * @param   array       $in_table           Array mit grundlegenden Tabellendaten; Bsp.: array("tables.table_schema" => manager, "tables.table_name" => app)
     * @param   array       $in_columnlist      Zweidiemansionale Liste der Tabellen  (Bsp.: array( 0 => Array("tables.table_schema" => manager, "tables.table_name" => vquery_app))
     * @param   array       $in_valueList       [optional] Wenn bereits eine Ergebnismenge vorliegt, kann diese mitgegeben werden. In dem Fall werden die Daten nicht
     *                                          aus der Quell-DB ausgelesen, sondern aus der ValueList genutzt. Verwendungszweck: vQuery
     *                                          Default = array()
     *                                          Syntax: Array(
                                                        [0] => Array(
                                                                [table_name.column1] => Bernd
                                                                [table_name.column2] => Schmid
                                                                [table_name.column3] => Herr)
                                                        [1] => Array(
                                                                [table_name.column1] => Klara
                                                                [table_name.column2] => Augustin
                                                                [table_name.column3] => Frau))
     * @param   array       $in_primaryKeys     Liste der PrimaryKeys; Bsp.: array("id", "app_id", "sys")
     * @param   string      $in_deleteCondition SQL-Condition, die in der Where-Klausel eines Delete-Befehls für die Tabelle ergänzt werden soll.
     * @return  boolean                         
     */
    function initializeAsVqueryTable($in_table, $in_columnlist, $in_valueList, $in_primaryKeys, $in_deleteCondition) {
        $this->_schema = $in_table["tables.table_schema"];
        $this->name = $in_table["tables.table_name"];
        $this->_backupTableDefinition = "";
        $this->is_vqueryTable = true;
        $this->_primary_columns = $in_primaryKeys;
        
        
        //Objekte erzeugen und in _columnlist ablegen
        foreach ($in_columnlist as $key => $column) {
            $myColumn = new backupColumn_universal($column);
            $this->_columnObjects[] = $myColumn;
        }
        
       
        $this->deleteCommand = $this->createDeleteCommand($in_deleteCondition);
        $this->_createTableCommand = $this->createTableCommand();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "TableCommand erzeugt");
        
        $this->_insertCommands = $this->createInsertCommands("", $in_valueList);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "InsertCommands erzeugt");
        
        return true;
        
    }
    
    
    
    
    
    /** Ermittelt für eine Tabelle alle Zugriffsrechte aus information_schema.table_priveleges
     * 
     * @return  array                                   Zweidiemnsionales array, sortiert nach grantee (Bsp. 
     *                                                  array(
     *                                                          [0] => array([grantee]=>"user1", [privilege_type] => "SELECT"),
     *                                                          [1] => array([grantee]=>"user1", [privilege_type] => "INSERT"))
     */
    function getGrantsForTable() {

        $db_schema_information = global_variables::getNameOfDbSchemaInformation(); 
        $connection_id = $this->_connection_id;
        
        
        $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);    //Slash am Anfang ist wichtig, um aus dem aktuellen namespace heraus zu kommen

            $queryRequest->addSelectColumn("table_privileges", "grantee");
            $queryRequest->addSelectColumn("table_privileges", "privilege_type");
            
            $queryRequest->addTable("$db_schema_information", "table_privileges", 1, "BASE", "");
            
            $queryRequest->addWhereCondition("AND", "", "table_privileges", "table_schema",  "=", "'".$this->_schema."'", "");
            $queryRequest->addWhereCondition("AND", "", "table_privileges", "table_name",  "=", "'".$this->name."'", "");
            $queryRequest->addWhereCondition("AND", "", "table_privileges", "privilege_type",  " in ", "('SELECT','INSERT','UPDATE','DELETE','REFERENCES','TRIGGER','EXECUTE','USAGE')", "");      //Bedingung ist notwendig, um auf Standard-SQL-einzuschränken
            
            $queryRequest->addOrderbyPart("table_privileges.grantee");

        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für getGrantsForTable', $result);
        
        
        if($result == false) {
            $feedback = array();
        } else {
            $feedback = $result;
        }
        
        return $feedback;
        
        
    }
    
    
    
    
        
    
    /** Ermittelt für eine materialized View alle Zugriffsrechte aus information_schema.table_priveleges
     * Attention NO-SQL-Standard
     * 
     * @return  array                                   Zweidiemnsionales array, sortiert nach grantee (Bsp. 
     *                                                  array(
     *                                                          [0] => array([grantee]=>"user1", [privilege_type] => "SELECT,INSERT"),
     *                                                          [1] => array([grantee]=>"user2", [privilege_type] => "INSERT"))
     */
    function getGrantsForMatView() {

        
        return array();
        
        
    }
    
    
    
    /** Ermittelt für eine Funktion alle Zugriffsrechte aus information_schema.role_routine_grants
     * 
     * @return  array                                   Zweidiemnsionales array, sortiert nach grantee (Bsp. 
     *                                                  array(
     *                                                          [0] => array([grantee]=>"user1", [privilege_type] => "EXECUTE"),
     *                                                          [1] => array([grantee]=>"user2", [privilege_type] => "EXECUTE"))
     */
    function getGrantsForFunctions() {

        $db_schema_information = global_variables::getNameOfDbSchemaInformation(); 
        $connection_id = $this->_connection_id;
        
        
        $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);    //Slash am Anfang ist wichtig, um aus dem aktuellen namespace heraus zu kommen

            $queryRequest->addSelectColumn("role_routine_grants", "grantee");
            $queryRequest->addSelectColumn("role_routine_grants", "privilege_type");
            
            $queryRequest->addTable("$db_schema_information", "role_routine_grants", 1, "BASE", "");
            
            $queryRequest->addWhereCondition("AND", "", "role_routine_grants", "routine_schema",  "=", "'".$this->_schema."'", "");
            $queryRequest->addWhereCondition("AND", "", "role_routine_grants", "routine_name",  "=", "'".$this->name."'", "");
            //$queryRequest->addWhereCondition("AND", "", "role_routine_grants", "privilege_type",  " in ", "('SELECT','INSERT','UPDATE','DELETE','REFERENCES','TRIGGER','EXECUTE','USAGE')", "");      //Bedingung ist notwendig, um auf Standard-SQL-einzuschränken
            
            $queryRequest->addOrderbyPart("role_routine_grants.grantee");

        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für getGrantsForTable', $result);
        
        
        if($result == false) {
            $feedback = array();
        } else {
            $feedback = $result;
        }
        
        return $feedback;
        
        
    }
    
    
    
    
    
    
    /** Erzeugt ein Targettable-Objekt (bspw. für MySql), welches alle Daten aus dem Source-Table-Objekt (bspw. postgres)  enthält,
     * aber die SQL-Befehle in der Syntax der TargetTable-DBMS erzeugen kann.
     * 
     * @param   object  $in_sourceTableObject       Objekt vom Typ backup_table
     * @param   String  $in_condition               Eine beliebige SQL-Bedingung, welche beim auslesen der Daten angewendet wird (Bsp.: app_id = 'SYS01'); Wenn nicht benötigt, dann Leerstring übergeben
     * @param   object  $in_Backup_object           übergeordnetes Backup-Objekt
     */
    function initializeAsTargetTable($in_sourceTableObject, $in_condition, $in_Backup_object) {
        $this->_connection_id = $in_sourceTableObject->_connection_id;
        $this->_schema = $in_sourceTableObject->_schema;
        $this->name = $in_sourceTableObject->name;
        $this->_tabletype = $in_sourceTableObject->_tabletype;
        $this->is_configTable = $in_sourceTableObject->is_configTable;
        $this->is_addContentTable = $in_sourceTableObject->is_addContentTable;
        $this->is_contentTable = $in_sourceTableObject->is_contentTable;
        $this->is_structureTable = $in_sourceTableObject->is_structureTable;
        $this->_backupTableDefinition = $in_sourceTableObject->_backupTableDefinition;
        $this->_column_app_id = $in_sourceTableObject->_column_app_id;
        
        
        //Columns ermitteln aus dem Source-Table-Objekt übernehmen
        $this->_columnObjects = $in_sourceTableObject->_columnObjects;
        
        //Foreign-Keys aus dem Source-Table-Objekt übernehmen
        $this->_foreignkeys_data = $in_sourceTableObject->_foreignkeys_data;
        $this->_createConstraintCommand = $this->createAlterTableCommand("add");
        $this->_dropConstraintCommand = $this->createAlterTableCommand("drop");
        
        //if(($in_Backup_object->backup_mode->readAppStructure == true OR $in_Backup_object->backup_mode->add_constraints == true OR $in_Backup_object->backup_mode->drop_constraints == true) AND $this->is_structureTable == true) {
            //Primary-Keys aus dem Source-Table-Objekt übernehmen
            $this->_primary_columns = $in_sourceTableObject->_primary_columns;

            //INDEXI aus dem Source-Table-Objekt übernehmen
            $this->_index_data = $in_sourceTableObject->_index_data;
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für getIndexData', $this->_index_data);
            $this->_createIndexCommands = $this->createIndexCommand();

            //CreateTableCommand erzeugen
            $this->_createTableCommand = $this->createTableCommand();
            
            //Grant-Commands erzeugen
            $this->_grantCommands = $this->createGrantCommands($in_sourceTableObject->grants, $in_Backup_object->backup_mode->grantsToUser, "table");
            
            
        //} 
        

        $this->_insertCommands = $this->createInsertCommands($in_condition);
        $this->deleteCommand = $this->createDeleteCommand($in_condition);
        
        
    }
    
    
    /** Gibt den SQL-Befehl zum Löschen alter Daten in der Tabelle zurück.
     * 
     * @return  string
     */
    function getDeleteCommand() {
        return $this->deleteCommand;
    }
    
    
    /** Gibt den SQL-Befehl zum Erstellen der Tabelle zurück.
     * Mit diesem Befehl werden nicht die Foreign-Keys angelegt. Dazu muss getConstraintCommand genutzt werden.
     * 
     * @return  string
     */
    function getCreateTableCommand() {
        return $this->_createTableCommand;
    }
    
    
    /** Gibt den SQL-Befehl zum Erstellen der view zurück.
     * 
     * @return  string
     */
    function getCreateViewCommand() {
        return $this->_viewDefinition;
    }
    
    
    /** Gibt den SQL-Befehl zum Erstellen der function zurück.
     * 
     * @return  string
     */
    function getCreateFunctionCommand() {
        return $this->_functionDefinition;
    }
    
    
    /** Gibt die Liste der CREATE-INDEX-Anweisungen zurück
     * 
     * @return  array
     */
    function getCreateIndexCommand() {
        return $this->_createIndexCommands;
    }
    
    
    
    /** Gibt die Definition (Create-Anweisungen) einer view  zurück
     * 
     * @return  string
     */
    function getViewDefinition() {
        return $this->_viewDefinition;
    }
    
    
    
    
    
    
    /** Gibt die Liste der SQL-Befehle zum Erstellen der Constraints (ALTER TABLE Anweisungen) zurück.
     * 
     * 
     * @return  array
     */
    function getCreateConstraintCommand() {
        return $this->_createConstraintCommand;
    }
    
    
    
    
    
    
    
    
    
    /** Gibt den SQL-Befehl zum Droppen der Constraints (ALTER TABLE Anweisungen) zurück.
     * 
     * 
     * @return  string
     */
    function getDropConstraintCommand() {
        return $this->_dropConstraintCommand;
    }
    
    
    
    /** Gibt die INSERT-Kommandos zurück.
     * 
     * @return  array
     */
    function getInsertCommands() {
        return $this->_insertCommands;
    }
    
    
    /** Gibt die GRANT-Kommandos zurück.
     * 
     * @return  array
     */
    function getGrantCommands() {
        return $this->_grantCommands;
    }
    
    
    /** Gibt die INSERT-Kommandos für Konfigurationsdaten zurück.
     * 
     * @return  array
     */
    function getInsertCommandsForConfigTable() {
        return $this->_insertCommandsConfigtable;
    }
    
    
    
    /**
     * Fragt die Primary- oder Foreign-Keys für die aktuelle Tabelle aus dem information_schema ab
     * und gibt diese in einem Array zurück .
     * ACHTUNG: Wenn für Foreign-Keys Zusatzinformationen, wie bspw. target-column, benötigt werden,
     * dann besser die Funktion $this->getForeignKeydata nutzen.
     * 
     * @param string $in_type Constrainttype (PRIMARY | FOREIGN)  default = PRIMARY
     * 
     */
    protected function getConstraintKeys($in_type) {
        $db_schema_information = global_variables::getNameOfDbSchemaInformation(); 
        
        
        if($in_type == "FOREIGN") {$constrainttype = "FOREIGN KEY";} else {$constrainttype = "PRIMARY KEY";}
        $table = $this->name;
        $schema = $this->_schema;
        $connection_id = $this->_connection_id;
        $feedback = array();

        
        
        $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("key_column_usage", "column_name");
            
            $queryRequest->addTable($db_schema_information, "table_constraints", 1, "BASE");
            $queryRequest->addTable($db_schema_information, "key_column_usage", 2, "INNER");

            $queryRequest->addWhereCondition("AND",    "", "table_constraints", "constraint_catalog",  "=", "key_column_usage.constraint_catalog", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "constraint_schema",   "=", "key_column_usage.constraint_schema", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "constraint_name",   "=", "key_column_usage.constraint_name", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "table_schema",   "=", "key_column_usage.table_schema", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "table_name",   "=", "key_column_usage.table_name", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "constraint_type",   "=", "'".$constrainttype."'", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "table_schema",   "=", "'".$schema."'", "");
            $queryRequest->addWhereCondition("AND", "", "table_constraints", "table_name",   "=", "'".$table."'", "");            
            
            $queryRequest->addOrderbyPart("key_column_usage.ordinal_position");
        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
        //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für Constraint-Column-Select', $result);
        
        
        //Primary-Columns in einem Array ablegen
        foreach ($result as $key => $primaryKey) {
            $feedback[] = $primaryKey["key_column_usage.column_name"];
        }
        
        return $feedback;
    }
    
    
    
   
    
    
    
    /**
     * Erstellt auf Basis von $this->_foreignkeys_data einen oder mehrere ALTER-TABLE-Befehl zur Erstellung oder zum Droppen der ForeignKeys
     * 
     * @param       type            [add|drop] -> Entscheidet, ob die add-Constraint-Commands oder die drop-Commands zurückgegeben werden sollen
     * @return      array          Array kann keine oder mehrere ALTER-TABLE-Anweisungen enthaletn (ALTER TABLE ... ADD CONSTRAINT ...)
     */
    function createAlterTableCommand($in_type) {
        $sourceFields = "";
        $targetFields = "";
        $i = 0;
        $command_add_constraint = "";
        $command_add_constraint_Array = array();
        $command_drop_constraint = "";
        $command_drop_constraint_Array = array();
        $lastConstraintName = "";
        
        foreach ($this->_foreignkeys_data as $key => $foreignKey) {    
            $i = $i +1;
            
            if($lastConstraintName <> $foreignKey["referential_constraints.constraint_name"] AND $i > 1) {
                //Wenn ein neuer Constraint für die gleiche Tabelle vorliegt und die Schleife sich nicht im ersten Durchlauf befindet wird alles wieder auf default gesetzt
                $sourceFields = "";
                $targetFields = "";
                $i = 1;
                $command_add_constraint_Array[] = $command_add_constraint; 
                $command_drop_constraint_Array[] = $command_drop_constraint;
            }  
            if($i > 1) {$vorlauf = ", ";} else {$vorlauf = "";}
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ForeignKey', $foreignKey);
            $sourceFields = $sourceFields.$vorlauf.$foreignKey["key_column_usage.column_name"];
            $targetFields = $targetFields.$vorlauf.$foreignKey["key_column_usage.foreign_column_name"];
            $command_add_constraint = "ALTER TABLE ".$foreignKey["key_column_usage.table_schema"].".".$foreignKey["key_column_usage.table_name"]." ADD CONSTRAINT ".$foreignKey["referential_constraints.constraint_name"]." FOREIGN KEY(".$sourceFields.") REFERENCES ".$foreignKey["key_column_usage.foreign_table_schema"].".".$foreignKey["key_column_usage.foreign_table_name"]."(".$targetFields.") ON DELETE ".$foreignKey["referential_constraints.delete_rule"]." ON UPDATE ".$foreignKey["referential_constraints.update_rule"];
            $command_drop_constraint = "ALTER TABLE ".$foreignKey["key_column_usage.table_schema"].".".$foreignKey["key_column_usage.table_name"]." DROP CONSTRAINT IF EXISTS ".$foreignKey["referential_constraints.constraint_name"];
            $lastConstraintName = $foreignKey["referential_constraints.constraint_name"];
        }
        
        //Anweisung des letzten Schleifendurchlaufes dem Array hinzufügen
        if($command_add_constraint <> "") {
            $command_add_constraint_Array[] = $command_add_constraint;
            $command_drop_constraint_Array[] = $command_drop_constraint;
        }                        
        
        
        If($in_type == "add") {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ALTER-TABLE Constraint Anweisung[en]', $command_add_constraint_Array);
            return $command_add_constraint_Array;
        
        } else {
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ALTER-TABLE Constraint Anweisung[en]', $command_drop_constraint_Array);
            return $command_drop_constraint_Array;
            
        }
    }
    
    
    
    
    /** Liest aus einer Tabelle alle vorhandenen Daten aus und erstellt INSERT-Befehle.
     * 
     * @param   string  $in_condition       Eine beliebige SQL-Bedingung, welche beim auslesen der Daten angewendet wird (Bsp.: app_id = 'SYS01') Default = ""
     * @param   array   $in_valuelist       [optional] Wenn bereits eine Ergebnismenge vorliegt, kann diese mitgegeben werden. In dem Fall werden die Daten nicht
     *                                      aus der Quell-DB ausgelesen, sondern aus der ValueList genutzt. Verwendungszweck: vQuery
     *                                      Default = array()
     *                                      Syntax: Array(
                                                        [0] => Array(
                                                                [table_name.column1] => Bernd
                                                                [table_name.column2] => Schmid
                                                                [table_name.column3] => Herr)
                                                        [1] => Array(
                                                                [table_name.column1] => Klara
                                                                [table_name.column2] => Augustin
                                                                [table_name.column3] => Frau))
     * @return  array                       Array mit INSERT-Befehlen für jeden Datensatz
     */
    function createInsertCommands($in_condition = "", $in_valuelist = array()) {
        
        
        $insertCommandList = array();
        $mySchema = $this->_schema;
        $myTablename = $this->name;
        
        if($in_valuelist == array()) {    
            $connection_id = $this->_connection_id;
            $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectComplexStatement($myTablename.".*", $mySchema.".".$myTablename, $in_condition, "", "");
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> lebe noch', 'vor selectOnDB');
            
            $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> lebe noch', 'nach selectOnDB');
            
        } else {
            $result = $in_valuelist;
        }
        
        
        
        if($result == false) {
            return array();
        } else {

            foreach ($result as $resultRow) {
                $fieldlist = "";
                $values = "";
                $vorlauf = "";
                foreach ($resultRow as $fieldname => $value) {
                    $fieldlist = $fieldlist.$vorlauf.substr($fieldname ?? '',strpos($fieldname,".")+1);
                    $value = str_replace("'","''",$value ?? '');                      //Falls in einem String bereits ein einfaches Hochkommata existiert, muss dieses durch ein zweites maskiert werden.
                    //$value = str_replace("\","\\",$value);                      //Falls in einem String bereits ein einfaches Hochkommata existiert, muss dieses durch ein zweites maskiert werden.
                    if($value == "") {$values = $values.$vorlauf."NULL";} else {$values = $values.$vorlauf."'".$value."'";}
                    $vorlauf = ", ";
                }
                $insertCommandList[] = "INSERT INTO ".$mySchema.".".$myTablename." (".$fieldlist.") values (".$values.")";
            }
            
            //ToDo: Prüfen, ob folgende Schritte  nötig sind
                //UTF8-Decodierung - ist das notwendig?
                // leer -> NULL
            
            
            return $insertCommandList;
        }
    }
    
    
    
    
    
    
    
    
    
    /** Erstellt auf Basis von $this->_index_data einen oder mehrere CREATE-INDEX-Befehle
     * 
     * @return  array
     */
    public function createIndexCommand() {
        $indexDataList = $this->_index_data;
        $feedback = array();
        foreach ($indexDataList as $myIndexData) {
            $feedback[] = $myIndexData[".def"];
        }
        return $feedback;
    }
    
    
    
    
    /** Erzeugt für die aktuelle Tabelle den Delete-Befehl zum Löschen der vorhandenen Datensätze
     * 
     * @param   string  $in_condition       SQL-Condition, welche als WHERE-Part verwendet werden soll (ohne das Schlüsselwort "WHERE")
     * @return  string                      SQL-Delete-Command.
     */
    function createDeleteCommand($in_condition) {
        
        if($in_condition == "") {$wherePart = "";} else {$wherePart = " WHERE ".$in_condition;}        
        $deleteCommand = "DELETE FROM ".$this->_schema.".".$this->name.$wherePart;
        
        return $deleteCommand;
    }
    
    
    
    /** Ermittelt anhand des Schemas und des Namens der aktuellen Tabelle die Foreign-Key-Daten
     * 
     * @return type
     */
    function getForeignKeydata() {
        $db_schema_information = global_variables::getNameOfDbSchemaInformation(); 
        
        $table = $this->name;
        $schema = $this->_schema;
        $connection_id = $this->_connection_id;
        $feedback = array();
        
        $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("referential_constraints", "constraint_name");
            $queryRequest->addSelectColumn("key_column_usage_a", "table_schema");
            $queryRequest->addSelectColumn("key_column_usage_a", "table_name");
            $queryRequest->addSelectColumn("key_column_usage_a", "column_name");
            $queryRequest->addSelectColumn("key_column_usage_b", "table_schema",    "foreign_table_schema");
            $queryRequest->addSelectColumn("key_column_usage_b", "table_name",      "foreign_table_name");
            $queryRequest->addSelectColumn("key_column_usage_b", "column_name",     "foreign_column_name");
            $queryRequest->addSelectColumn("referential_constraints", "delete_rule");
            $queryRequest->addSelectColumn("referential_constraints", "update_rule");

            $queryRequest->addTable($db_schema_information, "referential_constraints", 1, "BASE");
            $queryRequest->addTable($db_schema_information, "key_column_usage", 2, "INNER", "key_column_usage_a");
            $queryRequest->addTable($db_schema_information, "key_column_usage", 3, "INNER", "key_column_usage_b");

            $queryRequest->addWhereCondition("AND",    "", "key_column_usage_a", "constraint_name",  "=", "referential_constraints.constraint_name", "");
            $queryRequest->addWhereCondition("AND", "", "key_column_usage_a", "constraint_schema",   "=", "referential_constraints.constraint_schema", "");
            $queryRequest->addWhereCondition("AND", "", "key_column_usage_b", "ordinal_position",   "=", "key_column_usage_a.position_in_unique_constraint", "");
            $queryRequest->addWhereCondition("AND", "", "key_column_usage_b", "constraint_name",   "=", "referential_constraints.unique_constraint_name", "");
            $queryRequest->addWhereCondition("AND", "", "key_column_usage_b", "constraint_schema",   "=", "referential_constraints.unique_constraint_schema", "");
            $queryRequest->addWhereCondition("AND", "", "referential_constraints", "constraint_schema",   "=", "'".$schema."'", "");
            $queryRequest->addWhereCondition("AND", "", "key_column_usage_a", "table_name",   "=", "'".$table."'", "");            
            
            $queryRequest->addOrderbyPart("referential_constraints.constraint_name, key_column_usage_a.ordinal_position");
        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
      
        
        
        
        //Da manche DBMS in der Ergebnismenge als Identifer die im Array die Table-Aliase benutzen, andere jedoch nicht, 
        //muss eine Standardisierung stattfinden.
        foreach ($result as $key => $currentRow) {
            if(isset($currentRow["key_column_usage_a.column_name"])) {
                //Wenn Table-Aliase durch das DBMS in der Ergebnismenge zurückgegeben werden, dann auch die Variante ohne Table-Alias ergänzen
                $result[$key]["key_column_usage.column_name"] = $currentRow["key_column_usage_a.column_name"];
                $result[$key]["key_column_usage.table_schema"] = $currentRow["key_column_usage_a.table_schema"];
                $result[$key]["key_column_usage.table_name"] = $currentRow["key_column_usage_a.table_name"];
                $result[$key]["key_column_usage.foreign_column_name"] = $currentRow["key_column_usage_b.foreign_column_name"];
                $result[$key]["key_column_usage.foreign_table_schema"] = $currentRow["key_column_usage_b.foreign_table_schema"];
                $result[$key]["key_column_usage.foreign_table_name"] = $currentRow["key_column_usage_b.foreign_table_name"];
            }
        }
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Result für ForeignData-Select', $result);
        $feedback = $result;
        
        return $feedback;
    }
    
    
    
    

    
    
    
    /**     Ermittelt alle Columns der Tabelle und wichtige Eigenschaften dieser. Die Column-Eigenschaften werden in Objekten vom Typ backupColumn gespeichert. 
     * 
     * @return  array                                   Zweidimensionales Array mit allen Spalten der aktuellen Tabelle. Pro Column werden folgende Merkmale zurück gegeben: 
     *                                                  columns.table_name 
                                                        , columns.column_name 
                                                        , columns.table_schema 
                                                        , columns.is_nullable 
                                                        , columns.data_type 
                                                        , columns.character_maximum_length
                                                        , columns.ordinal_position
                                                        , columns.column_default    //enthält in postgres die nextval-Eigenschat
     */
    function getColumnlist() {
        $db_schema_information = global_variables::getNameOfDbSchemaInformation(); 
        $table = $this->name;
        $schema = $this->_schema;
        $connection_id = $this->_connection_id;
        
        
        
        $queryRequest = new \sql_request($connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("columns", "table_name");
            $queryRequest->addSelectColumn("columns", "column_name");
            $queryRequest->addSelectColumn("columns", "table_schema");
            $queryRequest->addSelectColumn("columns", "is_nullable");
            $queryRequest->addSelectColumn("columns", "column_type", "data_type");                  
            $queryRequest->addSelectColumn("columns", "character_maximum_length");
            $queryRequest->addSelectColumn("columns", "ordinal_position");
            $queryRequest->addSelectColumn("columns", "column_default");

            $queryRequest->addTable($db_schema_information, "columns", 1, "BASE", "");

            $queryRequest->addWhereCondition("AND",    "", "columns", "table_schema",  "=", "'".$schema."'", "");
            $queryRequest->addWhereCondition("AND", "", "columns", "table_name",   "=", "'".$table."'", "");
            
            $queryRequest->addOrderbyPart("columns.ordinal_position");
        $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
        
        //Objekte erzeugen und in _columnlist ablegen
        foreach ($result as $key => $column) {
            $myColumn = new backupColumn_universal($column);
            $this->_columnObjects[] = $myColumn;
        }
    }
    
    
    
    
    /**
     * Erzeugt für die gesamte Tabelle das CreateTable-Kommando
     * 
     * @return string           Create-Befehl für eine Tabelle ohne Constraints.
     */
    function createTableCommand() {
        //Attention NO-SQL-Standard: Dieses Klasse muss Datenbankspezifisch im jeweiligen Konnektor (bspw. backup_postgresql_class.php definiert werden.
        
    }
    
    
    
        
    /** Erstellt für die übergebene view oder materialized view die Create-Anweisungen und gibt diese als Strings zurück.
     * 
     * @return  string                       Create-Command für die aktuelle view
     */
    function createViewCommand() {
        
        if($this->_tabletype == 'view') {
            //normale view
            $praefix = "CREATE OR REPLACE VIEW ";
            $suffix = "";
        } else {
            //materialized view
            $praefix = "CREATE MATERIALIZED VIEW ";
            $suffix = "";
        }
        $command = $praefix.$this->_schema.".".$this->name." AS \n".$this->_viewDefinition.$suffix."\n\n";

        return $command;
    }
    
    
    
    
    /** Erstellt aus der Array-Liste grant die GRANT-Commands
     * 
     * @param   array   $in_grantList       Array mit den Grants (Erwartet wird array([0}=>array("grantee"=>"userA", "privilege_type"=>"SELECT"))
     * @param   string  $in_grantsToUser    Eigenschaft des backup_modes (grantsToUser) [olduser|newuser]; Wenn newUser oder wenn kein alter User ermittelt werden konnte, dann wird im SQL-Skript der Platzhalter "[db_user]" hinterlegt
     * @param   string  $in_type            [function|matview|table|view] 
     * @return  array                       Array, welches die GRANT-Commands enthält
     */
    function createGrantCommands($in_grantList, $in_grantsToUser, $in_type) {
        $grantCommands = array();
        
        If($in_type == "table") {
            $type = "";
            $privileges_table = "table_privileges";
        } elseif($in_type == "view") {
            $type = "";
            $privileges_table = "table_privileges";
        } elseif($in_type == "matview") {
            $type = "";
            $privileges_table = "";
        } elseif($in_type == "function") {
            $type = "FUNCTION ";
            $privileges_table = "role_routine_grants";
        } else {addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> unbekannter GRANT-Typ', $in_type,"ERROR"); }
        
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> grantList for table', $in_grantList);
        foreach ($in_grantList as $key => $currentGrant) {
            if($in_grantsToUser == "oldUser") {
                $grantee = str_replace(array("@", "'", "%"), "", $currentGrant[$privileges_table.".grantee"]);                    //Sonderzeichen entfernen, die bspw. innerhalb des MySql-DBMS autom. in information_schema.table_privileges ergänzt werden.
                if($grantee == "") {$grantee = "[db_user]";}
            } else {
                $grantee = "[db_user]";
            }
            
            $grantCommands[] = "GRANT ".$currentGrant[$privileges_table.".privilege_type"]." ON ".$type.$this->_schema.".".$this->name." TO ".$grantee."";
        }
        return $grantCommands;
    }
    
    
    
    
    
    
    
}



class backupColumn_universal {
    
    
    public $schema;
    public $table;
    public $column_name;
    public $datatype;
    public $maxlength;
    public $ordinal_position;
    public $is_nullable;
    public $column_default;
    
    
    
    
    /**
     * Eine backupColumn enthält alle Informationen über eine Column.
     * Die Informationen werden aus dem information_schema (SQL-Standard) ausgelesen.
     * 
     * @param   array   $in_columnatributs          Liste der Eigenschaften einer Spalte:
     *                                              columns.table_name 
                                                    , columns.column_name 
                                                    , columns.table_schema 
                                                    , columns.data_type 
                                                    , columns.character_maximum_length
                                                    , columns.ordinal_position
                                                    , columns.is_nullable
                                                    , columns.column_default
     * 
     */
    function __construct($in_columnattributs) {
        
        $this->schema = $in_columnattributs["columns.table_schema"];
        $this->table = $in_columnattributs["columns.table_name"];
        $this->column_name = $in_columnattributs["columns.column_name"];
        $this->datatype = $in_columnattributs["columns.data_type"];
        $this->maxlength = $in_columnattributs["columns.character_maximum_length"];
        $this->ordinal_position = $in_columnattributs["columns.ordinal_position"];
        $this->is_nullable = $in_columnattributs["columns.is_nullable"];
        
        //In columns_default werden unnötige datenbankspezifische Ergänzungen entfernt 
        $search  = array('::character varying', '::date', '0000-00-00 00:00:00');
        $replace = array('', '');
        $subject = $in_columnattributs["columns.column_default"];
        $this->column_default = str_replace($search, $replace, $subject ?? '');       
        
        
        
        if(isset($in_columnattributs["columns.extra"])) {
            //In manchen DBMS, wie bspw. MySql, existiert diese Spalte
            if($in_columnattributs["columns.extra"] == "auto_increment") {
                $this->column_default = "nextval";                              //MySql-Syntax an Postgres anpassen, damit weitere Verarbeitung vereinheitlicht werden kann.
            }
        }
    }
}




class backup_helper_universal {
    
   
    
    
    /** Diese Klasse stellt alle Methoden für das Lesen oder Schreiben eines Backups
     * für das DBMS postgresql zur Verfügung. Die Klasse erbt von backup_universal_helper und überschreibt alle
     * Methoden, in denen Postgres-spezifische Anweisungen notwendig sind.
     * 
     */
    function __construct() {
        
    }
    
    
    /**
     * Gibt eine Liste von Hinweisen aus, die in an den Beginn einer Backup-Datei, im Bereich "Hinweise",
     * eingefügt werden.
     * Attention NO-SQL-Standard
     * 
     * @return string Text, welcher als Hinweis angedruckt werden kann.
     */
    function getNotesForDBMS() {
        //Diese Funktion ist DB-spezifisch und sollte daher, bei Bedarf, in den erbenden Klassen überlagert werden.
        
        return "";
    }
    
    
    /** Ermittelt eine Liste aller UpdateSequence-Commands
     * Attention NO-SQL-Standard
     * 
     * @param   string  $in_connection_id       ID der Connection, welche genutzt werden soll.
     * @param   array   $in_schemaList          Liste aller DB-Schemas dessen Tabellen ermittelt werden sollen.
     * @return  array                           Wenn keine Update-Commands ermittelt werden konnten, wird ein leeres array zurückgegeben
     */
    function getUpdateSequenceCommands($in_connection_id, $in_schemaList) {
        
        //Die Sequencen (nextValue für incrementelle Columns) müssen nicht in allen
        //DBMS aktualisiert werden. Daher wird diese Methode in DBMS-spezifischen Connectoren 
        //überlagert.
        return array();
        
    }
    
   
    
     /** Ermittelt eine Liste aller Tabellen eines Schemas
      * Attention NO-SQL-Standard
     * 
     * @param   string  $in_connection_id       ID der Connection, welche genutzt werden soll.
     * @param   array   $in_schemaList          Liste aller DB-Schemas dessen Tabellen ermittelt werden sollen.
     * @return  array                           Wenn keine Tabellen ermittelt werden konnten, wird ein leeres array zurückgegeben
     */
    function getTablelistFromSchema($in_connection_id, $in_schemaList) {

        $db_schema_information = global_variables::getNameOfDbSchemaInformation(); 
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        
        
        if($in_schemaList <> array()) {
            //Schema-Array in String umwandeln
            $schema_list = arrayToString($in_schemaList);

            $queryRequest = new \sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);    //Slash am Anfang ist wichtig, um aus dem aktuellen namespace heraus zu kommen

                $queryRequest->addSelectColumn("tables", "table_schema");
                $queryRequest->addSelectColumn("tables", "table_name");
                $queryRequest->addSelectColumn("tables", "table_type");

                $queryRequest->addTable($db_schema_information, "tables", 1, "BASE", "");

                $queryRequest->addWhereCondition("AND", "", "tables", "table_type",  "=", "'BASE TABLE'", "");
                $queryRequest->addWhereCondition("AND", "", "tables", "table_schema",          "in", "(".$schema_list.")", "");

            $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        } else {
            $result = false;
        }
        
        
        
        
        
        
        if($result == false) {
            $feedback = array();
        } else {
            //zusätzlich ignoreIfContentBackup-Definitionen ergänzen
            $tableDefinitionlist = getBackupTabledefinitions("'ignoreIfContentBackup'", $in_connection_id);
            
            foreach ($result as $keyResult => $currentTable) {
                foreach ($tableDefinitionlist as $keytableDefinition => $currentTableDefinition) {
                    if($currentTable["tables.table_name"] == $currentTableDefinition["backup_tabledefinitions.tablename"]){
                        $result[$keyResult]["backup_tabledefinitions.app_column"] = $currentTableDefinition["backup_tabledefinitions.app_column"];
                        $result[$keyResult]["backup_tabledefinitions.definition"] = $currentTableDefinition["backup_tabledefinitions.definition"];
                        break;      //Abbruch der inneren Schleife
                    }
                } 
                if(isset($result[$keyResult]["backup_tabledefinitions.app_column"]) == false) {
                    //Wenn keine Werte in $currentTableDefinition für $currentTable gefunden wurden, werden Leerstrings eingefügt
                    $result[$keyResult]["backup_tabledefinitions.app_column"] = "";
                    $result[$keyResult]["backup_tabledefinitions.definition"] = "";
                }
            }
            $feedback = $result;
        }
        
        return $feedback;
        
        
    }
    
 
    
    
    
    
     /** Ermittelt eine Liste aller Views und deren SQL-Definition eines Schemas
     * 
     * @param   string  $in_connection_id       ID der Connection, welche genutzt werden soll.
     * @param   array   $in_schemaList          Liste aller DB-Schemas dessen views ermittelt werden sollen.
     * @return  array                           Wenn keine Tabellen ermittelt werden konnten, wird ein leeres array zurückgegeben
     *                                          Zweidimensionales Array: array(0=>array(views.view_name, views.view_definition, views.view_schema))
     */
    function getViewlistFromSchema($in_connection_id, $in_schemaList) {
        $db_schema_information = global_variables::getNameOfDbSchemaInformation(); 
        
        if($in_schemaList <> array()) {
            //Schema-Array in String umwandeln
            $schema_list = arrayToString($in_schemaList);

            $queryRequest = new \sql_request($in_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);    //Slash am Anfang ist wichtig, um aus dem aktuellen namespace heraus zu kommen

                $queryRequest->addSelectColumn("views", "table_name");
                $queryRequest->addSelectColumn("views", "view_definition");
                $queryRequest->addSelectColumn("views", "table_schema");
                $queryRequest->addSelectColumn("views", "table_schema", "view_type", "view");

                $queryRequest->addTable($db_schema_information, "views", 1, "BASE", "");

                $queryRequest->addWhereCondition("AND", "", "views", "table_schema", "in", "(".$schema_list.")", "");

            $result = \db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__, true);
        } else {
            $result = false;
        }
        
        
        if($result == false) {
            $feedback = array();
        } else {
            foreach ($result as $key => $value) {
                $cur_func["views.view_schema"] = $value["views.table_schema"];
                $cur_func["views.view_name"] = $value["views.table_name"];
                $cur_func["views.view_definition"] = $value["views.view_definition"];
                $cur_func["views.view_type"] = $value[".view_type"];
                $feedback[] = $cur_func;
            }
        }
        
        return $feedback;
    }
    
    
    
    
    
    
     /** Ermittelt eine Liste aller Materialized Views und deren SQL-Definition eines Schemas
      * Hinweis: Materilized-Views existieren nicht in allen DBMS. Daher muss diese Methode DB-spezifisch programmiert werden.
      * Sollte ein DBMS keine Materialized views anbieten, dann ist es nicht notwendig eine DB-spezifische Methode anzubieten. 
      * In dem Fall wird immer ein leeres Array zurückgegeben.
      * Attention NO-SQL-Standard
     * 
     * @param   string  $in_connection_id       ID der Connection, welche genutzt werden soll.
     * @param   array   $in_schemaList          Liste aller DB-Schemas dessen views ermittelt werden sollen.
     * @return  array                           Wenn keine Tabellen ermittelt werden konnten, wird ein leeres array zurückgegeben
     *                                          Zweidimensionales Array: array(0=>array(views.view_name, views.view_definition, views.view_schema))
     */
    function getMatViewlistFromSchema($in_connection_id, $in_schemaList) {
        //Diese Methode muss DB-spezifisch überlagert werden.
        
        return array();
    }
    
    
    
    
        
     /** Ermittelt eine Liste aller Trigger und deren SQL-Definition eines Schemas
      * Attention NO-SQL-Standard
     * 
     * @param   string  $in_connection_id       ID der Connection, welche genutzt werden soll.
     * @param   array   $in_schemaList          Liste aller DB-Schemas dessen views ermittelt werden sollen.
     * @return  array                           Wenn keine Tabellen ermittelt werden konnten, wird ein leeres array zurückgegeben
     *                                          Zweidimensionales Array: array(0=>array(function.name, function.schema, .function_def))
     */
    function getTriggerlistFromSchema($in_connection_id, $in_schemaList) {
        //Diese Methode muss DB-spezifisch überlagert werden.
        
        return array();
    }
    
    
    
    
     /** Ermittelt eine Liste aller Views und deren SQL-Definition eines Schemas
     * 
     * @param   string  $in_connection_id       ID der Connection, welche genutzt werden soll.
     * @param   array   $in_schemaList          Liste aller DB-Schemas dessen views ermittelt werden sollen.
     * @return  array                           Wenn keine Tabellen ermittelt werden konnten, wird ein leeres array zurückgegeben
     *                                          Zweidimensionales Array: array(0=>array(views.view_name, views.view_definition, views.view_schema))
     */
    function getFunctionlistFromSchema($in_connection_id, $in_schemaList) {
        //Diese Methode muss DB-spezifisch überlagert werden.
        
        return array();
    }
    
    
    
    
    /** Erstellt für die übergebene Tabellenliste die Drop-Anweisungen und gibt diese als String zurück.
     * 
     * @param   array  $in_tablelist        Zweidimensionales array, wie es getTablelistFromSchema() erzeugt.
     * @return  array                       Liste der Drop-Commandos, ohne Semikolon am Ende
     */
    function createTableDropCommand($in_tablelist) {
        $dropTableOrders = array();
        foreach ($in_tablelist as $key => $table) {
            $dropOrder = "DROP TABLE IF EXISTS ".$table["tables.table_schema"].".".$table["tables.table_name"]." CASCADE";
            $dropTableOrders[]= $dropOrder;
            
        }
        return  $dropTableOrders;
    }
    
    
    
    /** Erstellt für die übergebene Viewliste oder Matviewliste die Drop-Anweisungen und gibt diese als String zurück.
     * 
     * @param   array  $in_viewlist         Zweidimensionales array, wie es getViewlistFromSchema() erzeugt.
     * @return  array                       Liste der Drop-Commandos, ohne Semikolon am Ende
     */
    function createViewDropCommand($in_viewlist) {
        $dropViewCommands = array();
        
        foreach ($in_viewlist as $key => $view) {
            if($view["views.view_type"] == "matview") {$praefix = "MATERIALIZED ";} else {$praefix = "";}
            $dropCommand = "DROP ".$praefix."VIEW IF EXISTS ".$view["views.view_schema"].".".$view["views.view_name"]." CASCADE";
            $dropViewCommands[]= $dropCommand;
            
        }
        return  $dropViewCommands;
    }
    
    
    /** Erstellt für die übergebene Functionliste die Drop-Anweisungen und gibt diese als String zurück.
     * 
     * @param   array  $in_Functionlist         Zweidimensionales array, wie es getFunctionlistFromSchema() erzeugt.
     * @return  array                       Liste der Drop-Commandos, ohne Semikolon am Ende
     */
    function createFunctionDropCommand($in_Functionlist) {
        $dropFunctionCommands = array();
        foreach ($in_Functionlist as $key => $Function) {
            $dropCommand = "DROP FUNCTION IF EXISTS ".$Function["function.schema"].".".$Function["function.name"]." CASCADE";
            $dropFunctionCommands[]= $dropCommand;
            
        }
        return  $dropFunctionCommands;
    }
    
    
    
     /** Erstellt für die übergebene Triggerliste die Create-Anweisungen und gibt diese als Array zurück.
     * 
     * @param   array  $in_Triggerlist              Zweidimensionales array, wie es getFunctionlistFromSchema() erzeugt.
     * @return  array                               Liste der Drop-Commandos, ohne Semikolon am Ende
     */
    function createTriggerCommand($in_Triggerlist) {
        $triggerCommands = array();
        foreach ($in_Triggerlist as $key => $Trigger) {
            $triggerCommands[]= $Trigger["trigger.def"];
        }
        return  $triggerCommands;
    }
    
    
    /** Erstellt für die übergebene Schemataliste die Drop-Anweisungen und gibt diese als String zurück.
     * Attention NO-SQL-Standard
     * 
     * @param   array  $in_schemalist       Eindimensionales array, wie es getSchemaList() erzeugt.
     * @return  string                      Liste der Drop-Commandos
     */
    function createSchemaDropCommand($in_schemalist) {
        $dropSchemaOrders = array();
        foreach ($in_schemalist as $key => $schema) {
            $dropOrder = "DROP SCHEMA IF EXISTS ".$schema;
            $dropSchemaOrders[]= $dropOrder;
            
        }
        return $dropSchemaOrders;
    }
    
    
    
    /** Erstellt für die übergebene Schemataliste die Create-Anweisungen und gibt diese als Strings in einem Array  zurück.
     * 
     * @param   array  $in_schemalist       Eindimensionales array, wie es getSchemaList() erzeugt.
     * @return  array                       Liste der Create-Commands (key = Nr., value = command)
     */
    function createSchemaCommand($in_schemalist) {
        $SchemaOrders = array();
        foreach ($in_schemalist as $key => $schema) {
            $order = "CREATE SCHEMA IF NOT EXISTS ".$schema;
            $SchemaOrders[]= $order;
            
        }
        return $SchemaOrders;
    }
    
    
    
    
    
    
    
    /** Erstellt für die übergebenen Schema und Owner-Angaben die GRANT-Anweisungen und gibt diese als Strings in einem Array zurcük.
     * Attention NO-SQL-Standard
     * 
     * @param   array   $in_schemaOwnerlist Eindimensionales Array, wie es getSchemaOwner() erzeugt.
     * @param   string  $in_grantsToUser    Eigenschaft des backup_modes (grantsToUser) [olduser|newuser]; Wenn newUser oder wenn kein alter User ermittelt werden konnte, dann wird im SQL-Skript der Platzhalter "[db_user]" hinterlegt
     * @return  array                       Liste der GRANT-commands (key = schema., value = command)
     */
    function createSchemaOwnerCommand($in_schemaOwnerlist, $in_grantsToUser) {
        $SchemaOrders = array();
        foreach ($in_schemaOwnerlist as $currentSchema => $currentOwner) {
            if($in_grantsToUser == "oldUser" AND $currentOwner != "") {
                $user = $currentOwner;
            } else {
                $user = "[db_user]";
            }
            $order = "GRANT ALL PRIVILEGES ON ".$currentSchema.".* TO ".$user;
            $SchemaOrders[$currentSchema]= $order;
            
        }
        return $SchemaOrders;
    }
    
    
    
    /** In der Regel ist es sinnvoll einem langen Importskript bestimmte 
     * Konfigurationsparameter voranzustellen. Bspw. maximale-Skriptlaufzeit oder 
     * Prüfung-der-Foraign-Keys-deaktivieren usw. .
     * 
     * Beachte aber, dass die Parameter, in Abhängigkeit von Source- und Target-DBMS unter Umständen
     * nicht gesetzt werden können. Die Entscheidung darüber trifft die Funktion
     * backupmanager_class->setDbmsParams
     * 
     * @return array            Liste mit SQL-Anweisungen 
     */
    function getInitialConfigparamsForDBMS() {
        
    }
        
    
    /** Wenn in getInitialConfigparamsForDBMS Einstellungen vorgenommen wurden,
     * ist es in der Regel sinnvoll, diese nach dem Datenimport wieder zurückzusetzen.
     * Attention NO-SQL-Standard
     * 
     */
    function resetInitialConfigparamsForDBMS() {
        
    }
    
        
    
    /** Erstellt für eine Liste von Tabellen die DELETE-Befehle, die den zu sichernden Daten vorangestellt werden.
     * So wird sicher gestellt, dass beim Import des Backups, die Daten nicht bereits vorhanden sind.
     * 
     * @param   array   $in_tableObjectList         Liste der Tabellenobjekte
     * @return  array                               Liste der Delete-Commands
     */
    function getDeleteCommands($in_tableObjectList) {
        $deleteTableOrders = array();
        
        //Tableliste absteigend sortieren, da sie im Standard für create sortiert ist. 
        //Beim Löschen muss genau umgekehrt vorgegangen werden, da aufgrund der Datenbankunabhängigkeit nicht mit CASCADE gearbeitet werden ksnn.
        $tablelist = array_reverse($in_tableObjectList, true);
        

        foreach ($tablelist as $key => $table) {
            $deleteTableOrders[]= $table->deleteCommand;
        }
        return $deleteTableOrders;
    }
    
    
    
    
    
    
    /** Erstellt für die in $in_backupRewriteColumns enthaltene Spalten die UpdateBefehle, welche die "Altdaten" wiederherstellen.
     * 
     * 
     * @param   $in_backupRewriteColumns    $in_backupRewriteColumns    Liste der zu sichernden Spalten. Diese können über getBackupRewriteColumns ermittelt werdn.
     * @param   string                      $in_app_id                  APP-ID der zu sichernden Anwendung
     * @return  array                                                   Array enthält die Update-Befehle
     */
    function createUpdateCommand($in_backupRewriteColumns, $in_app_id) {
        $updateOrders = array();
        $condition = "";

        
        //1. $in_backrwriteColumns gruppieren nach table, sodass pro Tabelle nur ein DB-Zugriff notwendig wird
        $backupRewriteTables = $this->changeBackupRewriteColumnlistToTablelist($in_backupRewriteColumns);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> backuprewriteColumns formatiert! ", $backupRewriteTables, "INFO");
        
        //2. Pro table in $in_backrwriteColumns die DB-Daten abrufen
        foreach ($backupRewriteTables as $key => $currentTable) {
            $bedingung = $currentTable["app_column"]." = '".$in_app_id."' AND sys = 1";
            $datalist = getTableData($currentTable["app_id"], $currentTable["tablename"], $currentTable["schemaname"], true, "", $bedingung, __FUNCTION__." Zeile: ".__LINE__);  
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Update-Data mit bedingung ermitteln ", $bedingung, "INFO");  
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Update-Data! ", $datalist, "INFO"); 
            
            //Primary-Keys der aktuellen Tabelle ermitteln, als Basis für Where-Condition
            $primaryKeys = getPkeysFromTable($currentTable["app_id"], $currentTable["schemaname"], $currentTable["tablename"]);
            $primaryKeys = explode(", ", $primaryKeys["idFields"]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Primary-Keys von Tabelle ".$currentTable["tablename"], $primaryKeys, "INFO");  
            
            //2.2 Update-Commands pro table erzeugen
            foreach ($datalist as $key => $currentDatarow) {
                //Set-Part: alle Spalten, für die ein Update-Befehl erzeugt werden soll, mit Werten versehen
                $setCommand = "";
                $delimiter = "";        //vor dem ersten Durchlauf wird kein Trennzeichen gesetzt
                foreach($currentTable["columns"] as $key => $currentColumn) {
                    //Alle Spalten-Sets für den aktuellen Datensatz ermitteln
                    If($currentDatarow[$currentTable["tablename"].".".$currentColumn] <> "") {
                        $parsedSetValue = parseSqlValue2($in_app_id, $currentDatarow[$currentTable["tablename"].".".$currentColumn], __FUNCTION__, false);
                        $currentSet = $currentColumn." = '".$parsedSetValue."'";
                    } else {
                        $currentSet = $currentColumn." = NULL";
                    }
                    $setCommand = $setCommand.$delimiter.$currentSet;
                    $delimiter = ", ";
                }
                
                
                //Where-Condition für den aktuellen Datensatz erzeugen (Primary-Keys nutzen)
                $whereCommand = "";
                $delimiter = "";        //vor dem ersten Durchlauf wird kein Trennzeichen gesetzt
                foreach($primaryKeys as $key => $keyColumn) {
                    //Alle Key-Spalten-Werte für den aktuellen Datensatz ermitteln
                    $currentCondition = $keyColumn." = '".$currentDatarow[$keyColumn]."'";
                    $whereCommand = $whereCommand.$delimiter.$currentCondition;
                    $delimiter = " AND ";
                }
                
                
                $currentUpdateOrder = "UPDATE ".$currentTable["schemaname"].".".$currentTable["tablename"]." SET ".$setCommand." WHERE ".$whereCommand;
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Update-Command ".$currentTable["tablename"], $currentUpdateOrder, "INFO");  
                
                $updateOrders[]= $currentUpdateOrder;

            }
        }
        
        return $updateOrders;
    }
    
    
    
    /** Wandelt die backupRewriteColumnList, so um, dass Columns, welche zur gleichen DB-Tabelle gehören, zusammengefasst werden.
     * 
     * @param   array $in_backuprewriteColumns    Liste, wie sie die Funktion getBackupRewriteColumns ermittelt
     * @return  array                               Bsp.:
     *                                              Array
                                                        (
                                                            [manager.account] => Array
                                                                (
                                                                    [app_id] => SYS01
                                                                    [schemaname] => manager
                                                                    [tablename] => account
                                                                    [app_column] => app_id
                                                                    [columns] => Array
                                                                        (
                                                                            [0] => directory_app_id
                                                                            [1] => directory_id
                                                                            [2] => email
                                                                            [3] => expiredate
                                                                            [4] => organisation
                                                                            [5] => password_hash
                                                                        )

                                                                )

                                                            [manager.app] => Array
                                                                (
                                                                    [app_id] => SYS01
                                                                    [schemaname] => manager
                                                                    [tablename] => app
                                                                    [app_column] => id
                                                                    [columns] => Array
                                                                        (
                                                                            [0] => logo
                                                                        )

                                                                )

                                                            [manager.konfiguration] => Array
                                                                (
                                                                    [app_id] => SYS01
                                                                    [schemaname] => manager
                                                                    [tablename] => konfiguration
                                                                    [app_column] => app_id
                                                                    [columns] => Array
                                                                        (
                                                                            [0] => beschreibung
                                                                        )

                                                                )
     *                                                      }
     */
    private function changeBackupRewriteColumnlistToTablelist($in_backuprewriteColumns) {
        $newList = array();
        $lastTable = "";
        $app_id_from_kernel = global_variables::getAppIdFromSYS01();


        foreach ($in_backuprewriteColumns as $key => $currentColumn) {
            if( $currentColumn["backup_rewritecolumns.app_id"]  == $app_id_from_kernel AND $currentColumn["backup_rewritecolumns.sys"] == 1 AND $currentColumn["backup_rewritecolumns.ctrl"] == 1) {
                //Wenn die Spalte beachtet werden soll
                $currentTable = $currentColumn["backup_rewritecolumns.schemaname"].".".$currentColumn["backup_rewritecolumns.tablename"];
                if( $lastTable  == $currentTable) {
                    //Wenn die Spalte zur vorherigen Tabelle gehört
                    $newList[$lastTable]["columns"][]= $currentColumn["backup_rewritecolumns.columnname"];
                } else {
                    //Wenn eine neue Tabelle vorliegt
                    $newList[$currentTable]["app_id"] = $currentColumn["backup_rewritecolumns.app_id"];
                    $newList[$currentTable]["schemaname"] = $currentColumn["backup_rewritecolumns.schemaname"];
                    $newList[$currentTable]["tablename"] = $currentColumn["backup_rewritecolumns.tablename"];
                    $newList[$currentTable]["app_column"] = $currentColumn["backup_tabledefinitions.app_column"];
                    $newList[$currentTable]["columns"][] = $currentColumn["backup_rewritecolumns.columnname"];
                    $lastTable = $currentTable;
                }
                
            }
        }
        
        return $newList;
    }
    
    
}