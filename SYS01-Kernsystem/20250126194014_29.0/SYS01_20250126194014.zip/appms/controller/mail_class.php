<?php

/*
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */





/**
 * Description of mail_class
 *
 * @author Tom
 */
class mail_appms {
    
    /**
     *
     * @var     array       Liste der TO-EMail-Adressen 
     */
    protected $_mailTO;
    
    
    /**
     *
     * @var     string      Kommaseparierte Liste der CC-Adressen 
     */
    protected $_mailCC;
    
    
    /**
     *
     * @var     string      Absenderadresse 
     */
    protected $_mailFrom;
    
    
    
    /** 
     *
     * @var     string       AppID des sendenden Formulars
     */
    protected $_senderFormAppId;
    
    
    
    /** 
     *
     * @var     string       AppID des sendenden Formulars
     */
    protected $_senderFormId;
    
    
    /**
     *
     * @var     string      Template für Content der E-Mail 
     */
    protected $_mailContentTemplate;
    
    
    
    /**
     *
     * @var     string      Rahmen (Einzäunung) für Mail-Parts 
     */
    protected $_boundary;
    
    
    /**
     *
     * @var     string      Content der E-Mail 
     */
    protected $_mailContent;
    
    
    
    /** 
     *
     * @var     string      Name der Datei, welche die E-Mailvorlage enthält. 
     */
    protected $_template_file;
    
    
    /**
     *
     * @var     string      relativer Pfad zur Template-Datei 
     */
    protected $_template_path_rel;
    
    
    /**
     *
     * @var     integer     Rückmeldung für status <br />
     *                      0       -> noch keine Mail versendet, aber auch noch kein Fehler <br />
     *                      220     -> Mail erfolgreich versendet  <br />
     *                      -220    -> Templatedatei konnte nicht ermittelt werden. <br />
     *                      -221    -> Fehler beim senden <br />
     */
    public $feedbackCode = 0;






    /**
     *
     * @var     array       Liste der Felder und deren Werte, die übermittelt wurden. <br />
     *                      Bsp.: Array <br />
                                    ( <br />
                                        [id] => 150 <br />
                                        [Bildschirmgröße] => 21 Zoll <br />
                                        [gewünschtes Lieferdatum] => 2020-09-09 <br />
                                        [Aufstellort - Gebäude] => 01 <br />
                                        [Aufstellort - Raum] => 01.1.02 <br />
                                        [Begründung des Bedarfs (optional)] =>  <br />
                                        [Antrag weiterleiten an] => test@test.de <br />
                                        [Kopie senden an] =>  <br />
                                        [Absender] => req11admin@example.de <br />
                                        [form_app_id] => REQ11 <br />
                                        [form_id] => 864 <br />
                                        [Antragsteller] => req11admin <br />
                                        [Antragszeit] => 2020-09-06 07:23:03 <br />
                                    ) <br />
     */
    protected $_formValues;
    
    
   
    /**
     *
     * @var     array       Array des sendenden Formulars 
     */
    protected $_form_array;
    
    
    
    /**
     *
     * @var     string          Betreff der Mail 
     */
    protected $_mailSubject;
    
    
    /**
     *
     * @var     array           Liste der Dateianhänge. Bsp.: <br />
     *                                                      Array( <br />
                                                                    [0] => Array( <br />
                                                                            [name] => AppMS_Update-Verfahren.pdf <br />
                                                                            [mimetype] => application/pdf <br />
                                                                            [filesize] => 543953 <br />
                                                                            [filebase64] => "R0lGODdhAQABAPAAAP8AAAAAACwAAAAAAQABAAACAkQBADs=" <br />
                                                                            [datastore_id] => <br />
                                                                            [tmp_name] => /var/www/html/.../example.pdf <br />
                                                                        ) <br />
                                                                ) <br />  
     */
    protected $_attachements;
    
    
    
    /**
     *
     * @var     string          Enthält den Header (From, CC, Attachments usw.) 
     */
    protected $_header;
    
    
    
    
            
    
    
    
    
    /** erzeugt ein Mailobjekt und versendet die Mail
     * 
     * @param   object      $in_pagedata        Referenz auf das pagedata-Objekt
     * @param   integer     $in_form_id         ID des Sendenden Formulars
     * @return  integer                         220 = erfolgreich; -220|-221 es ist ein Fehler aufgetreten (siehe konstantentyp_id = 35
     */
    public function __construct(&$in_pagedata, $in_form_id) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , "starte Mail_class");
        $dir_sep = global_variables::getDirectorySeparator();
        loadPlugin(global_variables::getAppIdFromSYS01(), "phpmailer".$dir_sep."src".$dir_sep."Exception");
        loadPlugin(global_variables::getAppIdFromSYS01(), "phpmailer".$dir_sep."src".$dir_sep."PHPMailer");
        
        
        $feedback = 0;
        $this->_senderFormId = $in_form_id;
        $this->_senderFormAppId = $in_pagedata->getFormPropertyAppId($this->_senderFormId);
        $this->_form_array = $in_pagedata->getFormArray($this->_senderFormId);
        $this->_attachements = $in_pagedata->filesBase64;
        
        //Template ermitteln
        $existMailTemplate = $this->setTemplatefileAndPath($in_form_id, $this->_senderFormAppId, $in_pagedata);
        
        if($existMailTemplate === true) {
            
       
            //Mailadressen für TO and CC aus den eingegebenen Daten ermitteln
            $this->getMailAdresses($in_pagedata, $this->_senderFormId, $this->_senderFormAppId);
            
            //Subject 
            $this->_mailSubject = $this->buildMailSubject($in_pagedata, $this->_senderFormId, $this->_senderFormAppId, $this->_form_array);
            

            //Feldnamen zu _formArray[last_insert} ergänzen und anschließend Feldnamen und Inhalte in _formValues übernehmen
            $in_pagedata->addFieldnameAndIdToLastInsertedData($this->_senderFormId, $this->_senderFormAppId); 
            $this->_formValues = $in_pagedata->getFormPropertyDataFromLastInsert($this->_senderFormId);
            
            //Create a new PHPMailer instance
            $mail = new PHPMailer();
            $mail->setFrom($this->_mailFrom);
            
            //Mail-TO:
            foreach ($this->_mailTO as $key => $current_mail_to) {
                $mail->addAddress($current_mail_to);
            }
            
            //Mail-CC:
            foreach ($this->_mailCC as $key => $current_mail_cc) {
                $mail->addCC($current_mail_cc);
            }
            
            //Replay-To-Adress
            $mail->addReplyTo($this->_mailFrom);
            
            $mail->Subject = $this->_mailSubject;
            
            
            //Body
            $this->_mailContentTemplate = $this->readTemplatefile($this->_template_path_rel, $this->_template_file);
            $this->_mailContent = $this->buildMailContent($this->_mailContentTemplate, $this->_formValues, $in_pagedata);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  mailContent mit ersetzten Platzhaltern', $this->_mailContent, "INFO");
            $mail->msgHTML($this->_mailContent);
            $mail->CharSet = 'UTF-8';
            
            //Attachments
            foreach ($this->_attachements as $key => $current_file) {
                $mail->addAttachment($current_file["tmp_name"], $current_file["name"], PHPMailer::ENCODING_BASE64, $current_file["mimetype"]);
            }
            
            $this->feedbackCode = 220;
            if (!$mail->send()) {
                $feedback = -221;
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Mail-Error', $mail->ErrorInfo, "ERROR");
            } else {
                $feedback = 220;
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Mail', "Message send");
            }
        } else {
            $feedback = -220;
        }
        
        
         $this->feedbackCode = $feedback;
    }
    
    
    /** Erstellt den Betreff einer E-Mail
     * 
     * @param   array   $in_form_array      Array des sendenden Formulars
     * @return  string
     */
    protected function buildMailSubject($in_pagedata, $in_senderFormId, $in_senderFormAppId, $in_form_array) {
        
        
        //Subject aus den eingegenen Daten in einem MailSubject-Field ermitteln
        $subject = $in_pagedata->getMailSubjectFromLastInsertedData($in_senderFormId, $in_senderFormAppId);

        
        if($subject == "") {
            //Wenn im Formular kein MailSubject-Field existiert
            $feedback = $in_form_array["form.name"];
        } else {
            $feedback = $subject;
        }
        
        return $feedback;
    }
    
    
    




    /** Liest den Inhalt der Template-Datei ein und gibt ihn als String zurück
     * 
     * @param   string  $in_template_path       relationaler Pfad zur Datei mit abschließenden Slash.
     * @param   string  $in_template_file       Name der Template-Datei
     * @return  string
     */
    protected function readTemplatefile($in_template_path, $in_template_file) {
        $feedback = "";
        $dir_sep = global_variables::getDirectorySeparator();
        
            
        $feedback = file_get_contents('..'.$dir_sep.$in_template_path.$in_template_file);
        //php-tags entfernen
        $feedback = str_replace('<?php /*', '', $feedback);
        $feedback = str_replace('?>', '', $feedback);
        return $feedback;
        
    }
    
    
    
    /** Funktion ersetzt in $in_mailContentTemplate alle Platzhalter durch die entsprechenden Werte 
     * aus $in_datensatz.
     * 
     * @param   string      $in_mailContentTemplate
     * @param   array       $in_datensatz               Liste aller Felder eines Datensatzes; Bsp. <br />
     *                                                      Array
                                                                (
                                                                    [k_bst_pre.id] => Array
                                                                        (
                                                                            [field.id] => 9121
                                                                            [field.name] => ID
                                                                            [field.value] => 134
                                                                            [field.valueplaintext] => 
                                                                        )

                                                                    [k_bst_pre.bst] => Array
                                                                        (
                                                                            [field.id] => 6272
                                                                            [field.name] => Haushaltskostenstellennummer
                                                                            [field.value] => 02601283
                                                                            [field.valueplaintext] => 
                                                                        )
                                                                }
     * @param   object      $in_pagedata                Referenz zum pagedata-object
     * @return  String
     */
    protected function buildMailContent($in_mailContentTemplate, $in_datensatz, &$in_pagedata) {
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Starte', "buildMailContent");
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  übergebene Daten', $in_datensatz);
        
        
        $feedback = replacePlaceholderInTemplateBySysdata($in_mailContentTemplate, $in_datensatz, $this->_form_array, $in_pagedata);
        
        
        

        //Alle Spalten und Werte des Datensatzes in einer Tabelle untereinander andrucken
        if(strpos($feedback, '$$all.table_vertical$$') > 0) {
            $temp_datensatz = array();
            foreach ($in_datensatz as $feldkey => $feldarray) {
                if($feldarray != array()) {             //Situation kann bspw. eintreten, wenn durch Workflow das Feld "Status" ergänzt wird.
                    if(isHiddenField($this->_form_array["form.id"], $this->_form_array["form.app_id"], $feldarray["field.name"]) != true) {
                        $temp_datensatz[$feldkey] = $feldarray;
                    }
                }
            }
            $temp_text = buildHtmlTableVertical($temp_datensatz);

            //Platzhalter ersetzen
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Suche Platzhalter:', '$$all.table_vertical$$'.' für Wert: '.$temp_text);
            $feedback = str_replace('$$all.table_vertical$$', $temp_text, $feedback);
        }
        
        

        return $feedback;
        
        
    }
    
    
    
    
    
    
    /** Ermittelt Pfad und Dateiname des Mail-Templates und legt die Werte in den 
     * Attributen _template_file und _template_path_rel ab. Es wird geprüft, ob das Template existiert.
     * Wenn kein Template ermittelt werden konnte wird false zurückgegeben, ansonsten true.
     * 
     * @param   integer     $in_form_id         ID des sendenden Formulars
     * @param   string      $in_form_app_id     APP-ID des sendenden Formulars
     * @param   objact      $in_pagedata        Rferenz zum pagedata-object
     * @return  boolean
     */
    protected function setTemplatefileAndPath($in_form_id, $in_form_app_id, &$in_pagedata) {
        $feedback = false;
        
        $myDirSep = global_variables::getDirectorySeparator();
        $temp_template = "form_".$in_form_id."_template.mail";
        $temp_template_path = global_variables::getPathForMail_rel($in_form_app_id);
        $temp_default_template_fromApp = getConfig("mail_default_template", $in_form_app_id);
        
        if($in_pagedata->existWorkflow() === true) {
            //Wenn ein Workflow existiert, dann prüfen, ob für den aktuellen Step ein speizielles Template angegeben wurde.
            $workflow = $in_pagedata->getWorkflow();
            $workflow_template_array = $workflow->getMailTemplate();
            if ($workflow_template_array != array()) {
                //wenn ein Template für den aktuellen worklfow-stepvorliegt ...
                $temp_template = $workflow_template_array["filename"];
                $temp_template_path = $workflow_template_array["path_rel"];
            }
        }
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> mail_template" , "..".$myDirSep.$temp_template_path.$temp_template);
        
        
        
        if(file_exists("..".$myDirSep.$temp_template_path.$temp_template)) {
            //Es existiert ein spezielles Template für das sendende Formular.
            $this->_template_file= $temp_template;
            $this->_template_path_rel = $temp_template_path;
            $feedback = true;
        } elseif(file_exists("..".$myDirSep.$temp_template_path.$temp_default_template_fromApp)) {
            //Es existiert ein Defaulttemplate für die aktuelle App-ID
            $this->_template_file= $temp_default_template_fromApp;
            $this->_template_path_rel = $temp_template_path;
            $feedback = true;
        } else {
            //es wird das Defaulttemplate aus dem Kernmodul (SYS01) genutzt.
            $this->_template_file= getConfig("mail_default_template", global_variables::getAppIdFromSYS01());
            $this->_template_path_rel = global_variables::getPathForMail_rel(global_variables::getAppIdFromSYS01());
            $feedback = true;
        }
        
        return $feedback;
    }
    
    
    /** Ermittelt die Werte für die Parameter _mailTo, mailCC und mailFrom.
     * 
     * @param   object      $in_pagedata        Referenz zum pagedata-object
     * @param   integer     $in_senderFormId    ID des sendenden Formulars
     * @param   string      $in_senderFormAppId App-ID des sendenden Formulars
     */
    protected function getMailAdresses(&$in_pagedata, $in_senderFormId, $in_senderFormAppId) {
        
        
        //Mailadressen für TO and CC aus den eingebenen Daten ermitteln
        $mailList = $in_pagedata->getMailTargetsFromLastInsertedData($in_senderFormId, $in_senderFormAppId);
        $mailList = $this->rebuildMaillistForWorkflow($mailList, $in_pagedata);
        
        
        
        $this->_mailTO = $mailList["TO"];
        $this->_mailCC = $mailList["CC"];
        if($mailList["From"] == array()) {
            //eine Absenderadresse wurde nicht erkannt.
            $this->_mailFrom = "no-response@". getConfig("mail_domain", $in_senderFormAppId);
        } else {
            //eine oder mehrere Absenderadressen sind vorhanden. Nur die erste wird verwendet.
            $this->_mailFrom = $mailList["From"][0];
        }
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  mailTO', $this->_mailTO, "INFO");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  mailCC', $this->_mailCC, "INFO");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  mailFROM', $this->_mailFrom, "INFO");
        
            
    }
    
    
    
    /** Falls ein Workflow existiert und Wkfl_Metadaten vorhanden sind, werden die Attribute TO, CC und From
     * durch die äquivalente Werte aus Wkfl_Metadaten ergänzt.
     * 
     * @param array     $in_maillist    array(TO,CC,From)
     * @param array     $in_pagedata    pagedata-object
     * @return array                    array(TO,CC,From)
     */
    private function rebuildMaillistForWorkflow($in_maillist, &$in_pagedata) {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> maillist" , $in_maillist);
        
        if($in_pagedata->existWorkflow() == true) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> " , "Workflow erkannt");
            //Falls ein Workflow existiert, dann müssen die Werte für TO, CC und From von diesem ermittelt werden.
            $wkflMetaData = $in_pagedata->getWorkflow()->getWkflMetadata();
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> wkfl_metadata" , $wkflMetaData);
            
            if($wkflMetaData != array()) {
                //$in_maillist["TO"][] = $wkflMetaData["wkfl_step_mail_to"];
                $in_maillist["TO"] = array_merge($in_maillist["TO"], $in_pagedata->putMailsInListHelper($wkflMetaData["wkfl_step_mail_to"]));
                //$in_maillist["CC"][] = $wkflMetaData["wkfl_step_mail_cc"];
                $in_maillist["CC"] = array_merge($in_maillist["CC"], $in_pagedata->putMailsInListHelper($wkflMetaData["wkfl_step_mail_cc"]));
                
                $in_maillist["From"][] = $wkflMetaData["wkfl_step_mail_from"];
            }
        }
        
        return $in_maillist;
    }
    
    
}
