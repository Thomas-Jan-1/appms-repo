<?php

/*
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


require_once("../controller/query_class.php");
require_once("../controller/backupcontroller/backupmanager_class.php");
require_once("../controller/global_variables_class.php");                             //globale Variablen
require_once("../controller/progressstatus_class.php");

setlocale(LC_TIME, getConfig("localisation", global_variables::getAppIdFromSYS01())); //wichtig für die Arbeit mit Datum-Funktionen, bspw. buildRtfFile

/**
 * Klasse zu Verwaltung von allen Eigenschaften, Methoden und eingebetteten Objekte der aufgerufenen page. Dadurch kann jederzeit auf die Daten der Maske, der enthaltenden Formulare und sonstige Variablen zugegriffen werden.
 * 
 */
class pagedata {

    public $_maskArray = array();                   //Array, welches alle Angaben zu einer Maske enthält
    protected $_formsArray = array();               //Array, welches alle Formulare der aktuellen Maske und deren Eigenschaften enthält  ToDo: Umbauen zu einem Objekt; Zugriffe müssen steuerbar sein (protected)
    protected $_functionArray = array();            //Array, welches alle Angaben zur aufgerufenen Funktion enthält. Eine Funktion wird durch den Klick auf einen Button aufgerufen. siehe feld.button_action_function_id
    public $internPostObject;                       //Objekt vom Typ POST_Data; Stellt alle Daten von $_POST in verschiedenen Formen zur Verfügung.
    public $internGetObject;                        //Objekt vom Typ GET_Data; Stellt alle erlaubten Daten von $_GET in verschiedenen Formen zur Verfügung.
    protected $_modus = 1;                          //1 = default, wenn nichts anderes angegeben wurde
    public $infobox;                                //Infobox-Objekt, in dem alle Meldungen für den Anwender abgelegt werden können.
    public $hiddenbox;                              //HiddenBox-Objekt, in dem versteckte Elemente abgelegt werden können, bereitstellen.
    protected $_app_id_from_kernel;                 //APP-ID der Kernanwendung
    protected $_html_dom_object;                    //Object des HTML-DOM'S
    public $form_list_with_fix_mode = array();      //Array, Liste aller form_ids, bei denen der mode fix durch eine button_function gesetz wurde.
    
    /**
     *
     * @var     array           Falls Dateien hochgeladen werden, enthält diese Variable die Metadaten und die Datei im Format base64
     *                          Array( <br />
      [0] => Array( <br />
      [name] => AppMS_Update-Verfahren.pdf <br />
      [mimetype] => application/pdf <br />
      [filesize] => 543953 <br />
      [filebase64] => "R0lGODdhAQABAPAAAP8AAAAAACwAAAAAAQABAAACAkQBADs=" <br />
      [datastore_id] => <br />
      ) <br />
      ) <br />
     */
    public $filesBase64 = array();

    /**
     *
     * @var     array           Enthält die AutoIncrement-Column-Value-Paare, wenn die Funktion insert aufgerufen wurde. Bsp.: array( id => 56, id2 => 8)
     */
    protected $_autoincrementValues;

    /**
     * 
     * @var     object          Für den Fall, dass ein Workflow aktiv ist, enthält dieses Attribut das Workflow-Objekt.
     */
    protected $_my_workflow_object;
    
    /**
     * 
     * @var     array           Liste des angefragten Formulares, inkl. der abhängigen Formulare
     */
    public array $_requested_forms = array();
    
    /**
     * 
     * @var     array           Liste der angefragten Formulare, inkl. umscließendes Container-Objekt. Es wird jeweils der HTML-Code unter der ID des Containers abgelegt.
     */
    private array $_requestedFormTagsHtml = array();
    
    /**
     * 
     * @var     string          Name einer aktualisierten Datei; temporäres Attribut. Es ist möglich, dass mehrere Dateien gleichzeitig aktualisiert werden.
     */
    protected $updateFilename;

    /** Konstruktor, 
     * Klasse zur Verwaltung von allen Eigenschaften, Methoden und eingebetteten Objekten der aufgerufenen page. Dadurch kann jederzeit auf die Daten der Maske, der enthaltenden Formulare und sonstige Variablen zugegriffen werden.
     * 
     * @param   Integer $in_GET         $_GET -> es werden mindestens die Parameter "mask" und "maskapp" erwartet
     */
    function __construct(&$in_GET) {
        // die maximale Ausführzeit erhöhen (Seconds) -> wichtig für Query-Designer-Masken mit aktivierten Debug-Mode
        ini_set("max_execution_time", 120);

        $this->_app_id_from_kernel = global_variables::getAppIdFromSYS01();
        
        session_class::$session_object->clearSessionMessageFieldClickbutton();
        
        

        //Mask-Array aufbauen
        If(session_class::$session_object->getTargetMaskId() !== false) {
            $target_mask_id = session_class::$session_object->getTargetMaskId();
            $target_mask_app_id = session_class::$session_object->getTargetMaskAppId();
        } else {
            $target_mask_id = $_GET["mask"];
            $target_mask_app_id = $_GET["maskapp"];
        }
        $this->_maskArray = getMaskDataById($target_mask_id, $target_mask_app_id, $this->getSessionUseTempInstallPath());       //Mask-Array aufbauen
        
        
        //Prüfen, ob Debug-Modus auf Login-Maske aktiv ist
        if($target_mask_id == global_variables::getDefaultMaskId($target_mask_app_id, "login_mask")) {
            if(getConfig("debug",$target_mask_app_id) == true) {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Debug-Warnung: ', "HINWEIS: Der Debug-Modus ist aktiviert. Dieser kann auf der LOgin-Maske zu unerwarteten Fehlern führen, da die Ajax-Antworten teilweise zu spät eintreffen.","ERROR");
            }
        }
        
        //InternPost-object und InternGet-object erstellen
        $this->internPostObject = new POST_Data($_POST);                        //wandelt das Array $_POST in eine andere Form um (internPostArray) und bildet ein zweites Array, in dem sich nur die geänderten Datensätze befinden (changedData) das 
        $this->internGetObject = new GET_Data($in_GET);

        //Function-Array erstellen
        $feedbackBuildFunctionArray = $this->buildFunctionArray($this->internPostObject->getSenderformId(),
                $this->internPostObject->getSenderInstanceId(),
                $this->internPostObject->getSenderButtonName());

        //Prüfen, ob die Anwendung sich im temporären Installationspfad befindet (Installationsprozess). 
        $this->checkTemporaryInstallPath();

        //Formulare aufbauen
        $this->infobox = new InfoBox();
        $this->hiddenbox = new HiddenBox();
        $this->buildFormArray($in_GET);

        //Nachdem alle Daten geladen wurden, wird Form_Mode für Target_Form gesetzt  
        $this->setFormModeForAllInstances($this->getFunctionProp("target_form_id"), $this->getFunctionProp("form_mode"));                        //ACHTUNG: das muss nach buildFunctionArray und vor setAdditionalFormAttributs erfolgen
        //Einige Formulareigenschaften werden in Abhängigkeit von der gewählten Funktion (ausgelöst durch einen Button-Klick) noch einmal angepasst---------------------
        if ($this->getFunctionProp("form_mode") == 6) {
            //Wenn der Modus des target_form nach dem Button-Klick default (6) sein soll, dann wird der default_form_mode des target_form genutzt.
            $target_form_id = $this->getFunctionProp("target_form_id");
            $default_form_mode = $this->getFormArray($target_form_id)["form.default_form_mode"];
            $this->setFormModeForAllInstances($target_form_id, $default_form_mode);
        }


        //Falls eine Maske einen Workflow enthält...
        if ($this->existWorkflow() == true) {

            require_once("../controller/workflow_class.php");
            if ($this->internGetObject->callWorkflowUrlid() == true) {
                //Falls eine Maske im Kontext eines Workflow-Vorganges aufgerufen wurde, dann die zugehörigen Vorgangsdaten laden
                $this->_my_workflow_object = new workflow($this->internGetObject->getWorkflowUrlID(), $this);
            } else {
                //Wenn kein vorhandener Vorgang aufgerufen werden soll, dann Formulare für neuen Vorgang vorbereiten.
                //Form_mode = 2 (insert) für alle Workflow-Formulare, inklusive ControlForm, setzen.
                //$this->setFormModeForAllForms(2);

                $this->_my_workflow_object = new workflow(false, $this);
                $this->setFormModeForGivingFormList($this->_my_workflow_object->getFormListAsArray(), 2);
            }
            
            
            //Falls beim Aufbau des Workflow-Objektes der Return-Code 
            //-4001 (Zugriff für die aktuelle Rolle im aktuellen Step nicht gestattet) oder
            //-4004 (
            //dann prüfen, ob eine andere Rolle des gleichen users zugriffsberechtigt ist.
            if($this->_my_workflow_object->getFeedbackCode() == -4004) {
            //if(in_array($this->_my_workflow_object->getFeedbackCode(), array(-4001,-4004))) {
                //zugriffsberechtigte Rolle ermitteln
                $role_with_access = getRoleWithAccessToMask($target_mask_app_id, $target_mask_id, $this);
                if($role_with_access != false) {
                    //Rollenwechsel und Maske neuladen
                    $get_url_param["url_id"]=$this->_my_workflow_object->getUrlid();
                    $this->changeRoleAndReloadMask($role_with_access["role.id"], $target_mask_app_id, $target_mask_id, $get_url_param, "");
                } else {
                    $this->_my_workflow_object->setFeedbackCode(-4001);
                }
            }
            
            
            
            
        } else {
            $this->_my_workflow_object = false;     //dadurch können Workflow-Control-Formulare, die außerhalb eines Workflow-Kontextes aufgerufen werden, eine entsprechende Fehlermeldung geben.
        }


        //Alle Aktionen, die mit einem Funktionsaufruf (Button-Klick) verbunden sind, ausführen
        $this->executeFunction($feedbackBuildFunctionArray);

        //Ende Anpassung der Formulareigenschaften-----------------------------------------------------------------------------------------------------------------------



        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->FormArray: ', $this->_formsArray);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->MaskArray: ', $this->_maskArray);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->functionArray: ', $this->_functionArray);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->internPostArray: ', $this->internPostObject->getInternPostArray());
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->internGetArray: ', $this->internGetObject->getInternGetArray());
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->changedData: ', $this->internPostObject->getChangedData());
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->NewData: ', $this->internPostObject->getNewData());
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->markedData: ', $this->internPostObject->getMarkedData());
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->mergedMarkedData: ', $this->internPostObject->getMergedMarkedData());
        if ($this->existWorkflow() == true) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->workflowArray: ', $this->_my_workflow_object->print_as_array());
            session_class::$session_object->setSessionWorkflowArray($this->_my_workflow_object->getWkflMetadata());
        }

        //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> pagedata->SESSION: ', $in_SESSION);
    }
    
    
    
    public function getRequestedFormTagsHtml() {
        return $this->_requestedFormTagsHtml;
    }
    
    
    
    /** Legt den HTML-Code des jeweiligen Tags in 
     * 
     * @param type $in_tagId
     * @param type $in_html
     */
    public function setRequestedFormTagsHtml($in_tagId, $in_html) {
        $this->_requestedFormTagsHtml[$in_tagId] = $in_html;
    }
    
    

    /** Gibt eine Refernz auf das Workflow-Objekt zurück, wenn vorhanden.
     * 
     * @return object       Referenz auf das Workflow-Objekt
     */
    public function getWorkflow() {
        return $this->_my_workflow_object;
    }

    /**
     * legt eine übergebene HtmlDom-Object-<b>Referenz</b> in der Eigenschaft $this->_html_dom_object ab
     * 
     * @param object    $in_dom_object      Objekt vom Typ HtmlDomTree
     */
    public function setHtmlDomObject(&$in_dom_object) {
        $this->_html_dom_object = $in_dom_object;
    }

    /**
     * Gibt das Html-Dom-Objekt, des aktuellen pagedata-objectes zurück.
     */
    public function getHtmlDomObject() {
        //legt das übergebene HtmlDom-Object in der Eigenschaft $this->_html_dom_object ab
        if (isset($this->_html_dom_object) === true) {
            return $this->_html_dom_object;
        } else {
            return false;
        }
    }

    /**
     * Prüft, ob der temporäre Installationspfad aktiv ist und weiterhin benötigt wird.
     * Falls aktiv und nicht mehr benötigt, wird der SESSION["use_temporary_update_dir"] auf false
     * gesetzt und ein reload ausgelöst.
     */
    protected function checkTemporaryInstallPath() {
        if (strpos($_SERVER['PHP_SELF'], global_variables::getPathForAppmsinstallTemp_rel()) > 0) {
            //Die Anwendung befindet sich im temporären Pfad
            if ($this->getFunctionProp("button_action_function_id") != 24) {
                //SESSION["use_temporary_update_dir"] muss auf false gesetzt werden, da im Installationsprozess plötzlich eine andere oder gar keine Funktion statt 24 gewählt wurde
                session_class::$session_object->setSessionUseTempInstallPath(false);
                $myDirSep = global_variables::getDirectorySeparator();
                $countDirs = substr_count($_SERVER['REQUEST_URI'], $myDirSep);
                $präfix = str_repeat(".." . $myDirSep, $countDirs);
                $neededUri = str_replace(global_variables::getPathForAppmsinstallTemp_rel(), "", $_SERVER['REQUEST_URI']);
                $newTargetUrl = $präfix . $neededUri;
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> URL-redirect wegen Abbruch des Installationsprozesses:', $newTargetUrl);
                header("Location: " . $newTargetUrl);
                exit;
            }
        }
    }

    /** Fügt die Daten eines Formulars im formArray hinzu
     * 
     * @param   Integer $in_formID      ID des Formulars, dessen Daten hinzugefügt werden sollen
     * @param   String  $in_formAppId   App des Formulars
     * @param   string  $in_relationtyp Art der Beziehung; 1 = eigenständiges Formular, 2 = eingebettetes Formular
     */
    public function addForm($in_formID, $in_formAppId, $in_relationtyp) {

        $instance_id = "i0";                                                    //Default-Instanz
        $this->_formsArray[$in_formID] = getFormsdataByFormID($in_formID, $in_formAppId);                   //Grundgerüst des formArrays aufbauen
        //Formularabhängigkeit ermitteln und im Formulararray hinterlegen
        $formDependenceArray = getFormDependenceType($this->getMaskProbertyAppid(), $this->getMaskProbertyID(), $in_formID);
        if ($formDependenceArray !== false) {
            $this->setFormPropertyDependenceType($in_formID, $formDependenceArray["dependence_type"]);
            $this->setFormPropertyDependenceTriggerForm($in_formID, $formDependenceArray["source_form_id"]);
        } else {
            $this->setFormPropertyDependenceType($in_formID, "");
            $this->setFormPropertyDependenceTriggerForm($in_formID, "");
        }


        if ($this->_formsArray[$in_formID]["form.default_limit"] == "") {
            $this->_formsArray[$in_formID]["form.limit"] = getConfig("rows_in_form", $this->_formsArray[$in_formID]["form.app_id"]);
        } else {
            //ansonsten wird der individuelle default-limit-Wert des Formulars genutzt
            $this->_formsArray[$in_formID]["form.limit"] = $this->_formsArray[$in_formID]["form.default_limit"];
        }
        
        
        //falls per GET-Parameter weitere einschränkende Bedingungen übergeben wurden, dann diese ergänzen
        $addConditionByGET = $this->internGetObject->getFormConditions($in_formID);
        $this->setFormPropertyConditionDefault($in_formID, $addConditionByGET);

        //currentDate aus Session_backup übernehmen, wenn vorhanden oder auf heute einstellen
        $this->_formsArray[$in_formID]["currentDate"] = $this->getFormPropertyCurrentDate($in_formID);

        $this->_formsArray[$in_formID]["form.relationtyp"] = $in_relationtyp;
        if (in_array($in_relationtyp, array(2,21,22))) {
            $this->_formsArray[$in_formID]["form.is_nested_form"] = true;
        } else {
            $this->_formsArray[$in_formID]["form.is_nested_form"] = false;
        }

        $connection_id = $this->_formsArray[$in_formID]["form.connection_id"];
        $this->_formsArray[$in_formID]["form.id_fields"] = getIDsForTable($connection_id, $this->_formsArray[$in_formID]["form.db_schema"], $this->_formsArray[$in_formID]["form.db_table"], 1);
        $this->_formsArray[$in_formID]["form.id_fields_autoincrement"] = getIDsForTable($connection_id, $this->_formsArray[$in_formID]["form.db_schema"], $this->_formsArray[$in_formID]["form.db_table"], 2);

        //Default-Instanz anlegen                                                   //1. Formular, beim ersten Aufbau der Maske
        $this->createFormInstance($in_formID, $instance_id, true);

//        if($this->_formsArray[$in_formID]["form.constructor"] == "TableData" AND $this->_formsArray[$in_formID]["form.db_table"] <> "") {
        if ($this->_formsArray[$in_formID]["form.db_table"] <> "") {

            $countData = $this->calculateFormCountData($in_formID, $instance_id, $this->getFormPropertyOffset($in_formID, $instance_id), true);
        }
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Interne Variable formArray: ', $this->_formsArray[$in_formID]);
        
        
    }
    
    
    
    /** Prüft, ob für das aktuelle Formular eine Aktualsierung angefragt wurde. Wenn ja,
     * wird die Formularnummer (inkl. aller abhängigen Formulare) in $this->_requested_forms abgelegt.
     * 
     * @param   string  $in_formID      ID des aktuellen Formulars
     */
    public function addDependingFormstoRequestedForms($in_formID) {
        $my_GET = $this->internGetObject;
        $my_form_array = $this->getFormArray($in_formID);
        If($my_GET->_loadOnlyTargetForm == true) {
            If($my_GET->targetForm == $in_formID) {
                $this->_requested_forms[$in_formID] = $in_formID;
                if(isset($my_form_array["form_dependence.target_forms"])) {
                    foreach ($my_form_array["form_dependence.target_forms"] as $form_key => $value) {
                        $this->_requested_forms[$form_key] = $form_key;
                    }
                }
            }
        }
    }
    
    

    /**
     * Führt die vom Anwender gewählte Funktion aus. Das Ergebnis wird an Message-Box gemeldet.
     * 
     * @param   array   $in_SESSION                     SESSION-Variable; nur für den aktuellen Browser-Tab (Storage-ID
     * @param   boolean $in_feedbackBuildFunctionArray  Gibt an, ob das FunctionArray erfolgreich aufgebaut werden konnte.
     */
    protected function executeFunction($in_feedbackBuildFunctionArray) {


        $my_session = session_class::$session_object->getSessionArray();
        $currentActtionID = $this->getPostObject()->getActionIDFromControlData();
        $lastActionID = session_class::$session_object->getLastActionId();

        if ($currentActtionID <> $lastActionID OR $currentActtionID == "") {
            //Prüfen, ob die Funktion mit den gleichen Daten bereits zuvor ausgeführt wurde.
            //$currentActtionID == "" tritt ein, wenn die Startmaske aufgerufen wird, während noch eine alte Session existiert.
            //Funktionen ausführen ---------------------------------------------------------------------------------------------------------------------------
            $feedback = $this->callFunction($this->getFunctionProp("button_action_function_app_id"), $this->getFunctionProp("button_action_function_id"), $in_feedbackBuildFunctionArray);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Tab-SESSION bei  functionfeedback: ', $my_session);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> functionfeedback: ', $feedback);
            
            //Meldungen, die in SESSION abgelegt wurden, prüfen
            if (isset($my_session["redirect"])) {
                if ($my_session["redirect"]["redirect_handled"] == 1) {
                    //Wenn die redirect-Anweisung bereits beim letzten Maskenaufruf abgearbeitet wurde, wird sie aus der SESSION-Variable gelöscht
                    session_class::$session_object->unsetRedirect();
                } elseif ($my_session["redirect"]["redirect"] == 1) {
                    //Anwender wurde auf die Loginmaske umgeleitet
                    $feedback = $my_session["redirect"]["reason"];
                }
            }
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> feedback nach Sessionredirect-Handling: ', $feedback);
            //Maske als frisch geladen kennzeichnen
            session_class::$session_object->setLastActionId($currentActtionID);
        } else {
            //Die Funktion wurde mit den gleichen Parametern bereits aufgerufen.
            // Das ist der Fall, wenn der User den Reload-Button des Browsers nutzt
            $feedback = -110;
            $this->setDefaultFormProperties();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Funktion unterdrücken, da reload-Button geklickt wurde: ', "current action_id = " . $currentActtionID . " | last action_id = " . $lastActionID);
        }



        //Anwender über Ergebnis informieren
        $this->setMessageInInfobox($feedback);
    }
    
    
    
    /** Wandelt den Feedback_code in den Klartext um und übergibt diesen an die Info-Box
     * 
     * @param   string     $in_feedback_code            Feedbackcode gemäß konstante.konstantentyp_id = 35;
     *                                                  I.d.R. numerischer Code. Es ist aber auch die Angabe des Feedbacktypes möglich.
     *                                                  Bsp.: 100_E -> Feedbackcode = 100, type = Error
     *                                                  mögliche Types: [I|E|S] Info, Error, Succes
     */
    public function setMessageInInfobox($in_feedback_code) {
        
        if(is_null($in_feedback_code)) {$in_feedback_code = 0;}
        $code = $in_feedback_code;
        if(is_numeric($in_feedback_code) === false) {
            //Type wurde mit angegeben
            $code_and_type = explode("_", $in_feedback_code);
            $type = strtolower($code_and_type[1]);
            if(in_array($type, array("info","error","success")) === false) {
                $type = "info";
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' Feedbackcode enthält einen ungültigen Type (zulässige Werte: error, success, info) ', $in_feedback_code, "ERROR");
            }
        } else  {
            if ($code < 0) {
                $type = "error";
            } elseif ($code == 0) {
                $type = "info";
            } elseif ($code > 0) {
                $type = "success";
            }
        }
        
        
        
        //$feedbacktext = getFeedbacktextForFunction($feedback, $this->getFunctionProp("button_action_function_app_id"));
        $feedbacktext = getFeedbacktextForFunction($code, $this->getMaskProbertyAppid());
        $feedbacktext = $this->replacePlaceholderInUserFeedback($feedbacktext);
        $this->infobox->addMessage($feedbacktext[0]["konstante.klartext"], $type, $feedbacktext[0]["konstante.app_id"]);
    }
    
    
    
    
    
    /** Ersetzt Platzhalter in userFeedback-Meldungen, die sich auf das Form-Array des sendenden Formulars beziehen.
     * 
     * @param   array      $in_message_array        Message-array, wie es die Funktion getFeedbacktextForFunction ermittelt, mit Platzhaltern. ($$examplePlaceholder$$)
     * @return  array                               Zweidimensionales: array{0=>Array{klartext, app_id}}
     */
    private function replacePlaceholderInUserFeedback($in_message_array){
        //form_array ermitteln
        $postObject = $this->getPostObject();
        $form_id = $postObject->getSenderformId();
        $form_array = $this->getFormArray($form_id);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> FormArray von SenderForm: ', $form_array);
        
        //$in_message_array ist ein Zweidimensionales Array, welches mehrere Meldungen enthalten kann.
        $temp_array = array();
        foreach ($in_message_array as $key => $cur_message) {
            //Platzhalter, die sich auf das form_array beziehen, ersetzen
            $temp_array[] = replacePlaceholderInDataset($form_array, $cur_message);
        }
        
        
        return $temp_array;
        
        
    }
    
    
    

    /** Setzt den Formularmodus aller eingebetteten Formulare (is_nested_form) auf den übergebenen Wert.
     * 
     * @param integer $in_form_mode         Modus, siehe DB-Tabelle form_mode
     */
    protected function setFormModeForAllNestedForms($in_form_mode) {
        $allForms = $this->getFormList();
        foreach ($allForms as $key => $currentForm) {
            if ($currentForm["form.is_nested_form"] == true) {
                $this->setFormModeForAllInstances($currentForm["form.id"], $in_form_mode);
            }
        }
    }

    /** Setzt für alle Target_forms der übergebenen Liste den Wert des Attribut "hide_me" auf true.
     * 
     * @param   array   $in_form_list       Array, mit den ID's der Formulare, welche unterdrückt werden sollen (Bsp.: array(12 => 12, 35 => 35, 56 => 56) )
     * @param   integer $in_except_form     [optional] ID eines Formulars, welches in der Liste $in_form_list enthalten sein könnte, aber ignoriert werden soll. I.d.R. ist das sinnvoll, um das aktuelle Formular auszuschließen. Default = ""
     */
    function setFormPropertyHide($in_form_list, $in_except_form = "") {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Hide dependend forms:', $in_form_list);
        foreach ($in_form_list as $form_id => $value) {
            if($in_except_form != $form_id) { 
                //$currentForm = $this->getFormArray($form_id);
                $this->_formsArray[$form_id]["form.hide_me"] = true;
            }
        }
    }

    /** Setzt die Eigenschaft "form_dependence.dependence_type" für ein Formular
     * 
     * @param integer   $in_form_id
     * @param string    $in_dependence_type         [reference|reference_show|false]
     */
    protected function setFormPropertyDependenceType($in_form_id, $in_dependence_type) {
        $this->_formsArray[$in_form_id]["form_dependence.dependence_type"] = $in_dependence_type;
    }

    /** Gibt die Eigenschaft "form_dependence.dependence_type" für ein Formular auf der aktuellen Maske zurück
     * 
     * @param   integer     $in_form_id
     * @return  string                      [reference|reference_show]
     */
    protected function getFormPropertyDependenceType($in_form_id) {
        return $this->_formsArray[$in_form_id]["form_dependence.dependence_type"];
    }

    /** Setzt die Eigenschaft "form_dependence.trigger_form_id" für ein Formular
     * 
     * @param integer   $in_form_id
     * @param integer   $in_trigger_form_id         [1|2|3] ID eines Formulars, von dem das aktueller Formular abhängig ist.
     */
    protected function setFormPropertyDependenceTriggerForm($in_form_id, $in_trigger_form_id) {
        $this->_formsArray[$in_form_id]["form_dependence.trigger_form_id"] = $in_trigger_form_id;
    }

    /** Gibt die Eigenschaft "form_dependence.trigger_form_id" für ein Formular auf der aktuellen Maske zurück, wenn diese dem angegeben reference_type entspricht.
     * 
     * @param   integer     $in_form_id
     * @param   string      $in_dependence_type     Typ der Abhängigkeit [reference|reference_show]
     * @return  integer                             [1|2|3] ID eines Formulars, von dem das aktueller Formular abhängig ist.
     */
    protected function getFormPropertyDependenceTriggerForm($in_form_id, $in_dependence_type) {
        if ($this->_formsArray[$in_form_id]["form_dependence.dependence_type"] == $in_dependence_type) {
            return $this->_formsArray[$in_form_id]["form_dependence.trigger_form_id"];
        }
    }

    /** Setzt den Formularmodus aller Formulare auf den übergebenen Wert.
     * 
     * @param integer $in_form_mode         Modus, siehe DB-Tabelle form_mode
     */
    protected function setFormModeForAllForms($in_form_mode) {
        $allForms = $this->getFormList();
        foreach ($allForms as $key => $currentForm) {
            $this->setFormModeForAllInstances($currentForm["form.id"], $in_form_mode);
        }
    }

    /** Setzt den Formularmodus aller Formulare auf den vorherigen aus Tab-SESSION_Backup, falls vorhanden.
     * Wenn aus dem Session_Backup kein Formularmodus ermittelt werden kann, wird 1 (default) verwendet.
     * 
     * @param array     $in_except      [optional] Ausnahmen; Liste aller Fomulare für welche die alten Werte nicht übernommen werden sollen. (default = array())
     */
    public function setFormModeToPreviousValueForAllForms($in_except = array()) {
        $allForms = $this->getFormList();
        foreach ($allForms as $key => $currentForm) {
            if (isset($currentForm["form.id"])) {
                if (in_array($currentForm["form.id"], $in_except)) {
                    //nichts tun, da form.id in der Liste der ausgenommen Formulare enthalten ist.
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Nichts tun', "Form ".$old_form_id." in Ausnahmeliste enthalen");
                } else {
                    $form_mode = $this->takeOldValueFromForm($currentForm["form.id"],"i0", "form.form_mode");
                    if ($form_mode == false) {
                        $form_mode = 1;
                    }
                    $this->setFormModeForAllInstances($currentForm["form.id"], $form_mode);
                }
            } else {
                //Dieser Fall tritt bspw. auf, wenn Lösch-Button ohne Auswahl eines Datensatzes angeklickt wurde.
            }
        }
    }

    /** Setzt den Formularmodus aller Instanzen eines Formulare auf den übergebenen Wert.
     * 
     * @param integer $in_form_id           ID des Formulars
     * @param integer $in_form_mode         Modus, siehe DB-Tabelle form_mode
     */
    public function setFormModeForAllInstances($in_form_id, $in_form_mode) {
        $form = $this->getFormArray($in_form_id);
        if (isset($form["form.instances"])) {
            $instances = $form["form.instances"];
        } else {
            $instances = array();
        }
        foreach ($instances as $instance_id => $instance) {
            $this->setFormMode($in_form_id, $instance_id, $in_form_mode);
        }
    }

    /** Setzt für eine Liste von Form_id's den Formularmodus auf den übergebenen Wert
     * 
     * @param   array   $in_depending_form_list     Liste mit Formular-IDs (Bsp.: array(1,34, 67) )
     * @param   integer $in_form_mode               ID des gewünschten Formularmodus (siehe DB-Tabelle form_mode)
     * @param   array   $in_ignore_forms            Liste der Formulare (form.id), deren mode nicht geändert werden soll. (bSp.: araay(12,35)
     */
    function setFormModeForGivingFormList($in_depending_form_list, $in_form_mode, $in_ignore_forms = array()) {
        foreach ($in_depending_form_list as $form_id => $value) {
            if(in_array($form_id, $in_ignore_forms)) {
                //nichts tun
            } else {
                $this->setFormModeForAllInstances($form_id, $in_form_mode);
            }
        }
    }

    /** Wenn für ein Formular im internPost-Array Werte gefunden werden, 
     * die zu einem ID-Feld von targetForm gehören, werden diese als defaultValue 
     * für für die entsprechenden Felder in targetForm hinterlegt.
     * Zudem wird der ID-Wert in die Condition-Eigenschaft eingetragen.
     * 
     * @param integer   $in_targetForm      ID des Formulars
     * @param integer   $in_instance_id     ID der Instanz des Formulars
     */
    protected function takeOldIDsFromPost($in_targetForm, $in_instance_id) {
        $tempArray = array();
        $targetForm = $this->getFormArray($in_targetForm);
        $PostContentForTargetform = $this->getPostObject()->getFormContent($in_targetForm);
        //$targetTable = $targetForm["form.db_table"];
        //Wenn in der Post-Variablen ein Inhalt (content) für ein ID-Feld gefunden wird, dann wird dieser Wert als defaultValue im TargetForm hinterlegt
        foreach ($targetForm["form.id_fields"] as $key => $idField) {
            if (isset($PostContentForTargetform["content"] ["$idField"])) {
                //Wenn für das idFiels ein Wert im PostArray existiert, wird dieser als defaultValue in das Formular übertragen
                $tempArray[$idField] = $PostContentForTargetform["content"] ["$idField"];

                //Zudem wird der Wert in die Condition-Eigenschaft eingetragen.
                $this->setFormPropertyCondition($in_targetForm, $in_instance_id, $idField . " = '" . $PostContentForTargetform["content"] ["$idField"] . "'", true, "default");
            }
        }
        $this->setFormPropertyDefaultValueForInsert($in_targetForm, $in_instance_id, $tempArray);
    }

    

    /**
     * alte Conditions aller Formulare aus SESSION  in die gleichen Formulare für den nächsten Maskenaufbau übertragen. 
     * 
     * @param array     $in_except      [optional] Ausnahmen; Liste aller Fomulare für welche die alten Werte nicht übernommen werden sollen. (default = array())
     * @param string    $join_type      [optional] Verknüpfungstyp der alten mit der aktuellen condition. Mögliche Werte [AND|OR]; (default = "AND")
     * 
     */
    public function takeOldConditions($in_except = array(), $join_type = "AND") {

        $my_formsBackup = session_class::$session_object->getFormsbackup();
        if ($my_formsBackup !== false) {
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> forms aus session_backup: ', $my_formsBackup);

            foreach ($my_formsBackup as $current_form_id => $current_form) {
                if (in_array($current_form_id, $in_except)) {
                    //wenn das aktuelle Formular in der Liste der Ausnahmen enthalten ist, wird keine Daten aus dem backup übernommen.
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> form '.$current_form_id.' in Ausnahmeliste', $in_except);
                } else {
                    //Nur wenn das aktuelle Formular nicht in der Liste der Ausnahmen enthalten ist, werden die alten conditions übertragen
                    if (isset($current_form["form.instances"])) {
                        foreach ($current_form["form.instances"] as $instance_id => $instance) {
                            if (isset($instance["form.default_condition"])) {
//                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> alte condition gefunden', $instance["form.default_condition"]);
                                $oldConditionForInstance = $instance["form.default_condition"];                         //ACHTUNG: hier kann nicht mit $this->getFormPropertyCondition gearbeitet werden, da diese Formulare aus SESSION kommen und nicht aus $this
                                $this->setFormPropertyCondition($current_form_id, $instance_id, $oldConditionForInstance, false, "default", $join_type);
                            }
                            if (isset($instance["form.filter_condition"])) {
//                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> alte condition gefunden', $instance["form.default_condition"]);
                                $oldConditionForInstance = $instance["form.filter_condition"];                         //ACHTUNG: hier kann nicht mit $this->getFormPropertyCondition gearbeitet werden, da diese Formulare aus SESSION kommen und nicht aus $this
                                $this->setFormPropertyCondition($current_form_id, $instance_id, $oldConditionForInstance, false, "filter", $join_type);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * alte Conditions eines Formulare aus SESSION   für den nächsten Maskenaufbau übertragen. 
     * 
     * @param integer   $in_form_id     ID des Formulars
     * 
     */
    protected function takeOldConditionsForForm($in_form_id) {

        $my_formBackup = $this->getFormArrayFromSessionBackup($in_form_id);
        if ($my_formBackup !== false) {
            foreach ($my_formBackup["form.instances"] as $instance_id => $instance) {
                if (isset($instance["form.default_condition"])) {
                    $oldConditionForInstance = $instance["form.default_condition"];                         //ACHTUNG: hier kann nicht mit $this->getFormPropertyCondition gearbeitet werden, da diese Formulare aus SESSION kommen und nicht aus $this
                    $this->setFormPropertyCondition($in_form_id, $instance_id, $oldConditionForInstance, false, "default");
                }
            }
        }
    }

    /**
     * 
     * alte DefaultValuesForInsert aller Formulare aus Tab-SESSION  in die gleichen Formulare für den nächsten Maskenaufbau übertragen.
     * 
     * @param array $in_except      [optional] Ausnahmen; Liste aller Fomulare für welche die alten Werte nicht übernommen werden sollen. (default = array())
     * 
     */
    public function takeOldDefaultValuesForInsert($in_except = array()) {

//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Ausnahmeliste', $in_except);
        $form_backups = session_class::$session_object->getFormsbackup();
        if ($form_backups !== false) {

            foreach ($form_backups as $old_form_id => $old_form) {
                if (in_array($old_form_id, $in_except)) {
                    //nichts tun, da old_form in der Liste der ausgenommen Formulare enthalten ist.
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Nichts tun', "Form ".$old_form_id." in Ausnahmeliste enthalen");
                } else {
                    //Nur wenn das aktuelle Formular nicht in der Liste der Ausnahmen enthalten ist, werden die alten defaultValues übertragen
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> ', "Form ".$old_form_id." -> Werte übertragen");
                    if (isset($old_form["form.instances"])) {
                        foreach ($old_form["form.instances"] as $old_instance_id => $old_instance) {
                            if (isset($old_instance["form.tempDefaultValuesForInsert"])) {
                                //Wenn alte defaultValues in Backup vorhanden sind, werden diese in die aktuelle Variante der Instanz übertragn
                                $this->setFormPropertyDefaultValueForInsert($old_form_id, $old_instance_id, $old_instance["form.tempDefaultValuesForInsert"]);
                            }
                        }
                    }
                    //Im Trigger-Formular des Formulars, in dem die insert-Funktion ausgelöst wurde, die Default-Insert-Values aller abhängigen Formulare aus dem Session-Backup übernehmen
                    if (isset($old_form["form_dependence.trigger_form_id"])) {
                        $myTriggerFormId = $old_form["form_dependence.trigger_form_id"];
                        if (is_numeric($myTriggerFormId) === true) {
                            //Nur Wenn es sich um ein abhängiges Formular handelt, wird die Funktion ausgelöst.
                            //eingebettete Formulare haben die Eigenschaft ["form_dependence.trigger_form_id"] nicht belegt.
                            $myTargetFormId = $old_form["form.id"];
                            $this->takeDefaultValueForInsertFromBackup($myTriggerFormId, $myTargetFormId);
                        }
                    }
                }
            }
        }
    }

    /** Setzt einen neuen Form-mode-Wert und passt alle abhängigen Attribute an.
     * 
     * 
     * @param integer $in_form_id       ID des Formulars
     * @param string  $in_instance_id   Instanz eines Formulars
     * @param integer $in_form_mode     Mögliche Werte: 
     *                                              1 = default
     *                                              2 = insert
     *                                              3 = filter
     *                                              4 = activeFilter
     *                                              5 = empty
     *                                              6 = default_from_target_form
     *                                              7 = only_read
     */
    function setFormMode($in_form_id, $in_instance_id, $in_form_mode) {
        if (isset($this->_formsArray[$in_form_id])) {

            //$form = $this->_formsArray[$in_form_id];
            $this->setFormProperty($in_form_id, $in_instance_id, "form.form_mode", $in_form_mode);

            //Eigenschaften in Abhängigkeit von form_mode festlegen
            //SCHTUNG: Das darf erst passieren, wenn der GET-parameter form_mode der target_form zugeordnet wurde
            if ($in_form_mode == 1) {            //1 = default
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_data", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_readonly", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_requireFlag", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.allways_readonly", false);
                //$this->setFormProperty($in_form_id, $in_instance_id, "form.hide_if_insert", false); 
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_default_content", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_mark_field", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_nested_forms", true);
            } elseif ($in_form_mode == 2) {      //2 = insert
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_data", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_readonly", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_requireFlag", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.allways_readonly", false);
                //$this->setFormProperty($in_form_id, $in_instance_id, "form.hide_if_insert", true); 
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_default_content", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_mark_field", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_nested_forms", false);
            } elseif ($in_form_mode == 3) {      //3 = filter
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_data", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_readonly", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_requireFlag", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.allways_readonly", false);
//                $this->setFormProperty($in_form_id, $in_instance_id, "form.hide_if_insert", false); 
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_default_content", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_mark_field", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_nested_forms", true);
            } elseif ($in_form_mode == 4) {      //4 = activefilter
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_data", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_readonly", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_requireFlag", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.allways_readonly", false);
//                $this->setFormProperty($in_form_id, $in_instance_id, "form.hide_if_insert", false); 
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_default_content", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_mark_field", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_nested_forms", true);
            } elseif ($in_form_mode == 5) {      //5 = empty
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_data", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_readonly", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_requireFlag", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.allways_readonly", true);
//                $this->setFormProperty($in_form_id, $in_instance_id, "form.hide_if_insert", false); 
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_default_content", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_mark_field", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_nested_forms", true);
            } elseif ($in_form_mode == 6) {      //6 = default_from_target_form
            } elseif ($in_form_mode == 7) {      //7 = only_read
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_data", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_readonly", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_requireFlag", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.allways_readonly", true);
//                $this->setFormProperty($in_form_id, $in_instance_id, "form.hide_if_insert", false); 
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_default_content", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_mark_field", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_nested_forms", true);
            } elseif ($in_form_mode == 8) {      //8 = filter_with_required
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_data", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_readonly", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.note_requireFlag", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.allways_readonly", false);
//                $this->setFormProperty($in_form_id, $in_instance_id, "form.hide_if_insert", false); 
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_default_content", false);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.set_mark_field", true);
                $this->setFormProperty($in_form_id, $in_instance_id, "form.show_nested_forms", true);
            }
        }
    }

    /**
     * Setzt für die Instanz alle Formular-Attribute, die in Abhängigkeit von form_mode gesetzt werden müssen.
     * 
     * @param integer   $in_form_id
     * @param string    $in_instance_id
     */
    function setInitialFormModeAttributs($in_form_id, $in_instance_id) {
        $abort = false;
        $currentForm = $this->getFormArray($in_form_id);
        if ($currentForm <> false) {
            $instance = $currentForm["form.instances"][$in_instance_id];
//            echo "Form_id: ".$in_form_id."<br />";
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Form_array für id: " . $in_form_id, $currentForm, "INFO");
            if (isset($instance["form.form_mode"])) {
                $form_mode = $instance["form.form_mode"];
            } else {
                if (isset($currentForm["form.default_form_mode"]) == false) {
//                    echo "Formular ist nicht vorhanden: ".$in_form_id."<br />";
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  ", "Formular " . $in_form_id . " ist nicht vorhanden. Vermutlich ist es über role_has_form_group für die aktuelle Rolle deaktiviert.", "INFO");
                    $abort = true;
                } else {
                    $form_mode = $currentForm["form.default_form_mode"];
                }
            }
            //abhängige Attribute setzen
            if ($abort == false) {
                $this->setFormMode($currentForm["form.id"], $in_instance_id, $form_mode);
            }
        }
    }

    /** Gibt das Array für die aktuelle Maske zurück
     * 
     * @return array    siehe DB-Tabelle mask (Spaltenname = key, Wert = value)
     */
    public function getMaskArray() {
        return $this->_maskArray;
    }

    /** Gibt an. ob die aktuelle Maske einen Workflow enthält.
     * 
     * @return  boolean
     */
    public function existWorkflow() {
        //Wenn die Maske in der DB-Tabelle workflow_mask als Teil eines Workflows definiert wurde.
        
        
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> pagedata->MaskArray: ', $this->_maskArray);
        
        if ($this->_maskArray["workflow_id"] == "") {
            return false;
        } else {
            return true;
        }
    }

    /** Legt die Werte für css_template_app_id_temp und css_template_id_temp im Mask_array fest.
     * 
     * @param   string  $in_css_app_id
     * @param   integer $in_css_id
     */
    public function setMaskCSS($in_css_app_id, $in_css_id) {
        $this->_maskArray["css_template_app_id_temp"] = $in_css_app_id;
        $this->_maskArray["css_template_id_temp"] = $in_css_id;
    }

    /** Gibt anhand einer Form_ID (siehe Tabelle form) alle Daten eines Formulars zurück.
     * 
     * @param   integer     $in_formID  
     * @return  array oder false                      
     */
    public function getFormArray($in_formID) {
        //echo "form_id: ".print_r($in_formID)."<br />";
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID];
        } else {
            return false;
        }
    }
    
    
    
    
    
    /** Kennzeichnet ein Formular als blockiert, da es im aktuellen workflow_step nicht enthalten ist.
     * Dazu wird die Eigenschaft "block_by_workflow_step" auf true gesetzt.
     * 
     * 
     * @param integer   $in_formID      ID des zu entfernenden Formulars
     */
    public function blockForm($in_formID) {
        //echo "form_id: ".print_r($in_formID)."<br />";
        if (isset($this->_formsArray[$in_formID])) {
            $this->_formsArray[$in_formID]["block_by_workflow_step"] = true;
        } 
    }
    

    /** Gibt anhand einer Form_ID (siehe Tabelle form) alle Daten eines Formulars zurück. 
     * Das FormArray wird jedoch aus dem Session_Backup ermittelt. D.h. es wird der Zustand vor dem letzten ButtonKlick aufgerufen.
     * 
     * @param   integer     $in_formID  
     * @return  array oder false                      
     */
    public function getFormArrayFromSessionBackup($in_formID) {
        //echo "form_id: ".print_r($in_formID)."<br />";
        return session_class::$session_object->getFormbackup($in_formID);
        
    }

    /** Gibt die Daten von $_POST in Form von einem POST-Data-Objekt zurück
     * 
     * @return type
     */
    public function getPostObject() {
        return $this->internPostObject;
    }

    /** Gibt die gesamte Liste der Formulare als Array zurück
     * 
     * @return array
     */
    public function getFormList() {
        return $this->_formsArray;
    }

    /** Legt die Daten des letzten Inserts eines Formulars im form_array ab. (_formsArray[$in_formID]["last_insert"])
     * 
     * @param   integer     $in_formID      ID des Formulars
     * @param   array       $data           Bsp.:
     *                                      Array(
      [id] => 16
      [form_app_id] => FREQM
      [form_id] => 178
      [requesttime] => 2017-07-09 20:58:45
      [field1] => Umzug
      [field2] => Faxanschluss
      [applicant] => testuser)
     * 
     * 
     * 
     * Achtung: Das Array kann auch wie folgt aussehen, wenn es zuvor durch $this->addFieldnameAndIdToLastInsertedData verändert wurde:
     * 
     * Array
        (
            [k_bst_pre.id] => Array
                (
                    [field.id] => 9121
                    [field.name] => ID
                    [field.value] => 27
                    [field.valueplaintext] => 
                )

            [k_bst_pre.ueberkey] => Array
                (
                    [field.id] => 6245
                    [field.name] => übergeordnete Institution/Überkey
                    [field.value] => 02600000
                    [field.valueplaintext] => 02600000 ZIM ))
     * 
     * 
     * 
     */
    public function setFormPropertyDataFromLastInsert($in_formID, $data) {
        if (isset($this->_formsArray[$in_formID])) {
            $this->_formsArray[$in_formID]["last_insert"] = $data;
        }
    }

    /** Gibt das Array der zuletzt eingefügten Daten zurück. Format siehe "setFormPropertyDataFromLastInsert".
     * 
     * @return array
     */
    public function getFormPropertyDataFromLastInsert($in_formID) {
        return $this->_formsArray[$in_formID]["last_insert"];
    }

    /** Gibt das Array der zuletzt eingefügten Daten aus dem Session_backup zurück. 
     * Format siehe "setFormPropertyDataFromLastInsert".
     * 
     * @return mixed            array, wenn last_insert vorhanden, ansonsten false. 
     */
    public function getFormPropertyDataFromLastInsert_fromBackup($in_formID) {
        $feedback = false;

        $my_formArray = $this->getFormArrayFromSessionBackup($in_formID);
        if ($my_formArray !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> formsarray from backup', $my_formArray);

            if (isset($my_formArray["last_insert"])) {
                $feedback = $my_formArray["last_insert"];
            } else {
                $feedback = false;
            }
        } else {
            $feedback = false;
        }

        return $feedback;
    }

    /** Setzt oder ergänzt die condition-Eigenschaft eines Formulars, um einen SQL-Ausdruck
     * 
     * @param   integer     $in_formID                      ID eines Formulars
     * @param   string      $in_instance_id                 Instanz des Formulars
     * @param   string      $in_condition                   SQL-Ausdruck für den Where-Zweig. Wenn schon eine Bedingung existiert, wird diese mit AND ergänzt.
     * @param   bollean     $in_delete_old_value            Wenn true, wird ein bereits vorhandener Wert gelöscht.
     * @param   string      $in_condition_type              "default" oder "filter"; je nachdem welcher Filter-Speicherplatz im Form-Array genutzt wrden soll.
     * @param   string      $in_addType_to_old_condition    [optional; default = AND] Gibt an, ob die neue Condition zur alten per AND oder per OR ergänzt werden. 
     *                                                      Mögliche Wert: [OR|AND].
     *                                                      Dieser Parameter wird nur ausgewertet, wenn $in_delete_old_value = false ist.
     * @return  mixed                                       Gibt die aktuell eingestellte Condition zurück oder false, wenn instanz in form_array nicht gefunden wurde.
     */
    public function setFormPropertyCondition($in_formID, $in_instance_id, $in_condition, $in_delete_old_value, $in_condition_type, $in_addType_to_old_condition = "AND") {
        $feedback = "";
        $myCondition = "";

        if (isset($this->_formsArray[$in_formID]) AND $in_condition <> "") {
            
            if ($in_condition_type == "filter") {
                $condition_type = "form.filter_condition";
                
            } else {
                $condition_type = "form.default_condition";
            }

            //Abbruch, falls die angegebene Instanz nicht existiert. In dem Fall sind im Session_backup inzwischen ungültige Daten gefunden worden.
            if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]) == false) {
                return false;
            }

            //Defaultwert anlegen, falls dieser noch nicht existiert oder alte Condition gelöscht werden soll
            if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id][$condition_type]) == false OR $in_delete_old_value == true) {
                $myCondition = "1=1";
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> OldCondition = Null", $this->_formsArray[$in_formID]);
            
            } else {   
            //} elseif (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id][$condition_type]) == true) {
                $myCondition = $this->_formsArray[$in_formID]["form.instances"][$in_instance_id][$condition_type];
            }

            
            if ($in_addType_to_old_condition == "AND") {
                //die neue Condition soll per AND zur alten ergänzt werden
                $myCondition = $myCondition . " AND " . $in_condition;
            } elseif ($myCondition == "1=1") {
                //wenn bisher nur die Defaultcondition existiert und keine AND-Verknüpfung gewünscht ist, wird Default-Bedingung ersatzlos ersetzt.
                //Andernfalls könnte es bei einer OR-Verknüpfung zu einer Aufhebung der Conditions kommen.
                $myCondition = "(" . $in_condition . ")";
            } elseif ($in_addType_to_old_condition == "OR") {
                //die neue Condition soll per OR zur alten ergänzt werden.
                $myCondition = "((" . $myCondition . ") OR (" . $in_condition . "))";
            }
            
            
            
            //Condition bereinigen
            while(strpos($myCondition, "1=1 AND 1=1 AND") !== false) {
                $myCondition = str_replace("1=1 AND 1=1 AND", "1=1 AND", $myCondition);
            }
            $this->_formsArray[$in_formID]["form.instances"][$in_instance_id][$condition_type] = $myCondition;
            $feedback = $myCondition;
        }
        
        
        
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> formArray with new condition", $this->_formsArray[$in_formID]);

        return $feedback;
    }
    
    
    
    
    
    /** Setzt oder ergänzt die condition-Eigenschaft eines Formulars, um einen SQL-Ausdruck, ohne dabei die Instanz-ID zu beachten
     * 
     * @param   integer     $in_formID                      ID eines Formulars
     * @param   string      $in_condition                   SQL-Ausdruck für den Where-Zweig. Wenn schon eine Bedingung existiert, wird diese mit AND ergänzt.
     *                                                      Mögliche Wert: [OR|AND].
     *                                                      Dieser Parameter wird nur ausgewertet, wenn $in_delete_old_value = false ist.
     * @return  mixed                                       Gibt die aktuell eingestellte Condition zurück oder false, wenn instanz in form_array nicht gefunden wurde.
     */
    public function setFormPropertyConditionDefault($in_formID, $in_condition) {
        $feedback = "";
        $myCondition = "";

        if (isset($this->_formsArray[$in_formID]) AND $in_condition <> "") {
            

            //Defaultwert anlegen, falls dieser noch nicht existiert oder alte Condition gelöscht werden soll
            if (isset($this->_formsArray[$in_formID]["form.default_condition"]) == false ) {
                $myCondition = "1=1";
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> OldCondition = Null", $this->_formsArray[$in_formID]);
            
            } else {   
                $myCondition = $this->_formsArray[$in_formID]["form.default_condition"];
            }


            //die neue Condition wird per AND zur alten ergänzt werden
            $myCondition = $myCondition . " AND (" . $in_condition.")";
            
            
            //Condition bereinigen
            while(strpos($myCondition, "1=1 AND 1=1 AND") !== false) {
                $myCondition = str_replace("1=1 AND 1=1 AND", "1=1 AND", $myCondition);
            }
            $this->_formsArray[$in_formID]["form.default_condition"] = $myCondition;
            $feedback = $myCondition;
        }

//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> formArray with new condition", $this->_formsArray[$in_formID]);

        return $feedback;
    }
    
    
    
    

    

    /** Hinterlegt den Wert eines Feldes einer Datarow in der Formulereigenschaft [$in_formID]["form.instances"][$in_instance_id]["valuesSecureFields"]
     * 
     * @param integer   $in_formID          ID des Formulars
     * @param string    $in_instance_id     ID der Instanz des Formulars
     * @param integer   $in_datarow         Nummer der Datenzeile
     * @param integer   $in_fieldId         ID des Feldes
     * @param string    $in_value           Wert, des Feldes
     */
    public function setFormDatarowValuesForSecureFields($in_formID, $in_instance_id, $in_datarow, $in_fieldId, $in_value) {


        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id])) {

            $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["valuesSecureFields"][$in_datarow][$in_fieldId] = $in_value;
        }
    }

    /** Hinterlegt den Wert eines Passwort-Feldes einer Datarow in der Formulereigenschaft [$in_formID]["form.instances"][$in_instance_id]["valuesPasswordFields"]
     * 
     * @param integer   $in_formID          ID des Formulars
     * @param string    $in_instance_id     ID der Instanz des Formulars
     * @param integer   $in_datarow         Nummer der Datenzeile
     * @param integer   $in_fieldId         ID des Feldes
     * @param string    $in_value           Wert, des Feldes
     */
    public function setFormDatarowValuesForPasswordFields($in_formID, $in_instance_id, $in_datarow, $in_fieldId, $in_value) {


        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id])) {

            $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["valuesPasswordFields"][$in_datarow][$in_fieldId] = $in_value;
        }
    }
    
    
    
    /** Hinterlegt den Wert eines String-Feldes einer Datarow in der Formulereigenschaft [$in_formID]["form.instances"][$in_instance_id]["valuesEncryptedFields"]
     * 
     * @param integer   $in_formID          ID des Formulars
     * @param string    $in_instance_id     ID der Instanz des Formulars
     * @param integer   $in_datarow         Nummer der Datenzeile
     * @param integer   $in_fieldId         ID des Feldes
     * @param string    $in_value           Wert, des Feldes
     */
    public function setFormDatarowValuesForEncryptedFields($in_formID, $in_instance_id, $in_datarow, $in_fieldId, $in_value) {


        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id])) {

            $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["valuesEncryptedFields"][$in_datarow][$in_fieldId] = $in_value;
        }
    }

    /** Prüft, ob es sich bei einem Feld (Spalte) eines Formulars um ein Feld vom Typ Passwort handelt.
     * Wenn ja, wird der alte Feldinhalt zurückgegeben
     * 
     * @param   interger        $in_formID          ID des Formulars
     * @param   string          $in_instance_id     ID der Instanz
     * @param   integer         $in_ds              ID des Datensatzes
     * @param   string          $in_fieldname       Name des Feldes (Columnname)
     * @return  mixed                               false, wenn nein. Ansonsten wird der alte Feldinhalt zurückgegeben
     */
    public function isPasswordField($in_formID, $in_instance_id, $in_ds, $in_fieldname) {
        $feedback = false;

        $my_formArray = $this->getFormArrayFromSessionBackup($in_formID);
        if ($my_formArray !== false) {
            if (isset($my_formArray["form.instances"][$in_instance_id]["valuesPasswordFields"][$in_ds][$in_fieldname])) {
                $feedback = $my_formArray["form.instances"][$in_instance_id]["valuesPasswordFields"][$in_ds][$in_fieldname];
            } else {
                $feedback = false;
            }
        } else {
            $feedback = false;
        }

        return $feedback;
    }
    
    
    
    /** Prüft, ob es sich bei einem Feld (Spalte) eines Formulars um ein Feld vom Typ Encrypted handelt.
     * Wenn ja, wird der alte (verschlüsselte) Feldinhalt zurückgegeben
     * 
     * @param   interger        $in_formID          ID des Formulars
     * @param   string          $in_instance_id     ID der Instanz
     * @param   integer         $in_ds              ID des Datensatzes
     * @param   string          $in_fieldname       Name des Feldes (Columnname)
     * @return  mixed                               false, wenn nein. Ansonsten wird der alte Feldinhalt zurückgegeben
     */
    public function isEncryptedField($in_formID, $in_instance_id, $in_ds, $in_fieldname) {
        $feedback = false;

        $my_formArray = $this->getFormArrayFromSessionBackup($in_formID);
        if ($my_formArray !== false) {
            if (isset($my_formArray["form.instances"][$in_instance_id]["valuesEncryptedFields"][$in_ds][$in_fieldname])) {
                $feedback = $my_formArray["form.instances"][$in_instance_id]["valuesEncryptedFields"][$in_ds][$in_fieldname];
            } else {
                $feedback = false;
            }
        } else {
            $feedback = false;
        }

        return $feedback;
    }

    /** Hinterlegt den Wert eines Feldes einer Datarow in der Formulereigenschaft [$in_formID]["form.instances"][$in_instance_id]["valuesPrimarykeyFields"]
     * 
     * @param integer   $in_formID          ID des Formulars
     * @param string    $in_instance_id     ID der Instanz des Formulars
     * @param integer   $in_datarow         Nummer der Datenzeile
     * @param integer   $in_fieldId         ID des Feldes
     * @param string    $in_value           Wert, des Feldes
     */
    public function setFormDatarowValuesForPrimarykeyFields($in_formID, $in_instance_id, $in_datarow, $in_fieldId, $in_value) {


        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]) == true) {

            $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["valuesPrimarykeyFields"][$in_datarow][$in_fieldId] = $in_value;
        }
    }

    /** Hinterlegt in der Eigenschaft "form.default_fields" den Wert der übergebenen Variablen $in_fieldList
     * 
     * @param   string  $in_formID      ID, des Formulars
     * @param   araay   $in_fieldList   Defalut-Fieldlist des Formulars
     */
    public function setFormPropertyDefaultFieldlist($in_formID, $in_fieldList) {

        if (isset($this->_formsArray[$in_formID])) {
            $this->_formsArray[$in_formID]["form.default_fields"] = $in_fieldList;
        }
    }

    /** Die Funktion prüft, ob der aktuelle Datensatz Sys-Daten enthält und für den Fall, dass der 
     * aktuelle User nicht [App-ID]root ist, geschützt werden muss.
     * 
     * @param   array   $in_fieldlist       Array der Felder, inkl. Feldwerte, des aktuellen Datensatzes. 
     *                                      Die Fieldliste muss bereits über die Eigenschaft $in_fieldlist[0]["datensatz.sys"] verfügen
     * @return  boolean                     true, wenn der Datensatz geschützt werden muss. False, wenn die geplante Formular-Vorgabe beibehalten werden kann.
     */
    public function protectSysData($in_fieldlist) {
        $feedback = false;
        $activeRole = $this->getActiveRoleIdFromSession();
        $activeRoleAppId = $this->getActiveRoleAppIdFromSession();
        $currentuser = $this->getCurrentUserFromSession();
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> fieldlist", $in_fieldlist);

        if (isset($in_fieldlist[0]["datensatz.sys"])) {
            //Es reicht aus  dem 1. Datensatz fieldlist[0] zu analysieren, da die APP-ID aller Felder eines Datensatzes identisch ist.
            if ($activeRoleAppId == global_variables::getAppIdFromSYS01() AND $activeRole == global_variables::getAppManagerRoleId() AND isUserRoot($currentuser) == true) {
                //Wenn die Rolle APP-Manager zugreift, dann werden System datensätze nicht geschützt.
            } else {
                if ($in_fieldlist[0]["datensatz.sys"] == true) {
                    if ($in_fieldlist[0]["form.db_table"] <> "") {

                        If (isUserRoot($currentuser) == true) {
                            $appID_from_user = $this->getCurrentUserAppFromSession();
                            $schemaOfSYS01 = global_variables::getNameOfDbSchemaSYS01();
                            $table = $in_fieldlist[0]["form.db_table"];
                            $appID_column = getDataFromTableByID(global_variables::getAppIdFromSYS01(), $schemaOfSYS01, "backup_tabledefinitions", "app_column", "tablename = '" . $table . "' AND definition = 'configtable'");
                            $appID_from_fieldlist = getValueFromFieldInFieldlist($in_fieldlist, $appID_column);
                            if ($appID_from_fieldlist == "") {
                                //Wenn keine app_id ermittelt werden konnte, ist der Datensatz leer und muss und darf nicht geschützt werden. Andernfalls funktionieren Suchformulare nicht.
                                //                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Zugriff erlauben", "App-ID des DS: ".$appID_from_fieldlist." |App-D des User: ".$appID_from_user);
                                $feedback = false;
                            } elseif (strtoupper($appID_from_fieldlist) == strtoupper($appID_from_user)) {
                                //Wenn die App_ID des aktuellen Datensatzes, der APP-ID des root entspricht, darf dieser den Datensatz ändern
                                $feedback = false;
                                //                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Zugriff erlauben", "App-ID des DS: ".$appID_from_fieldlist." |App-D des User: ".$appID_from_user);
                            } else {
                                //alle anderen Nutzer dürfen nicht auf die sys-Datensätze schreibend zugreifen
                                $feedback = true;
                                //                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Zugriff verbieten", "App-ID des DS: ".$appID_from_fieldlist." |App-D des User: ".$appID_from_user);
                            }
                        } else {
                            //currentUser ist nicht root -> Datensatz schützen
                            $feedback = true;
                        }
                    }
                }
            }
        }
        return $feedback;
    }

    /** Die Funktion prüft, ob es sich um einen neuen Config-Datensatz, welcher mit dem User [App-ID]root erfasst wurde.
     * 
     * @param   array   $in_SqlDaten       Array von Typ SqlDaten, wie es die Funktion extractDataFromPostarray erstellt. <br />
     *                                      Bsp.:  <br />
     *                                      Array  <br />
      ( <br />
      [into] => id, app_id, parameter, beschreibung, wert <br />
      [values] => '119', 'SYS01', 'test4', 'test4', 'test4' <br />
      [update] => id='119', app_id='SYS01', parameter='test4', beschreibung='test4', wert='test4' <br />
      [schema] => manager <br />
      [table] => konfiguration <br />
      [where] => id='7' AND app_id='SYS01' <br />
      [where_insert] => id='119' AND app_id='SYS01' <br />
      [logdata] => id=119, app_id=SYS01, parameter=test4, beschreibung=test4, wert=test4 <br />
      [logdata_id_data] => 119 <br />
      )
     * @return  boolean                     true or false
     */
    public function isSysData($in_SqlDaten) {
        $feedback = false;
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , "starte ");
        //Prüfen, ob der Datensatz im Schema des Kenmoduls gespeichert werden soll. Nur dort liegen sys=1-Daten
        if (isset($in_SqlDaten["schema"])) {
            $schema = $in_SqlDaten["schema"];
            $schemaOfSYS01 = global_variables::getNameOfDbSchemaSYS01();
            if ($schema == $schemaOfSYS01) {
                //App-ID ermitteln; Dazu über die Tabelle backup_tabledefinition die app_id Spalte ermitteln
                if (isset($in_SqlDaten["table"])) {
                    $table = $in_SqlDaten["table"];
                    $appID_column = getDataFromTableByID(global_variables::getAppIdFromSYS01(), $schemaOfSYS01, "backup_tabledefinitions", "app_column", "tablename = '" . $table . "' AND definition = 'configtable'");
                    //Aus into- und value die App_ID des aktuellen Datensatzes ermitteln
                    $into_string = str_replace(" ", "", $in_SqlDaten["into"]);
                    $my_into_fields = explode(",", $into_string);
                    $pos_app_id = issetValue($my_into_fields, $appID_column);
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> pos_app_id: " . $pos_app_id, $my_into_fields);

                    if ($pos_app_id !== false) {
                        //Wenn die Column mit der app_id vorhanden ist, dann deren value auslesen
                        $my_value_fields = explode(",", $in_SqlDaten["values"]);
                        $app_id = str_replace(array("'", " "), "", $my_value_fields[$pos_app_id]);
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> appID-column", $appID_column . " value: " . $app_id);
                        $currentuser = $this->getCurrentUserFromSession();
                        if (isUserRoot($currentuser) == true AND $app_id == $this->getCurrentUserAppFromSession()) {
                            //es handelt sich um Daten,welche mit dem User [App-ID]root im Schema manager angelegt werden sollen
                            $feedback = true;
                        }
                    }
                }
            }
        }
        return $feedback;
    }

    /** Legt für jede Instanz eines Fomulars innerhalb des Attributs "form.instances" ein array für die Daten, welche von Instanz zu Instanz verschieden sind,  an.
     * 
     * @param integer   $in_formID
     * @param string    $in_instanceID
     * @param bool      $in_is_default_instance         Gibt an, ob die Instanz als default_instanz gekennzeichnet werden soll. Die Default-Instanz wird durch die erste folgende Instanz überschrieben/ aktualisiert
     */
    public function createFormInstance($in_formID, $in_instanceID, $in_is_default_instance) {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Form-id und instance-id ", $in_formID." und ".$in_instanceID);
        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instanceID])) {
            //Instanz existiert schon
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Form-id und instance-id existiert schon!", $in_formID . " und " . $in_instanceID, "ERROR");
        } else {
            //neue Instanz anlegen
            $this->_formsArray[$in_formID]["form.instances"][$in_instanceID] = array("instance_id" => $in_instanceID);
            if ($in_is_default_instance == true) {
                $this->_formsArray[$in_formID]["form.instances"][$in_instanceID]["default_instance"] = true;
            } else {
                $this->_formsArray[$in_formID]["form.instances"][$in_instanceID]["default_instance"] = false;
            }
            $this->_formsArray[$in_formID]["form.instances"][$in_instanceID]["form.offset"] = 0;                                                 //initial
        }

        $this->setInitialFormModeAttributs($in_formID, $in_instanceID);
    }

    /** aktualisiert die Instanzliste. Wenn noch eine default-Instanz existiert, wird diese durch die neue id ersetzt und das default-
     * Kennzeichen entfernt. Ansonsten wird eine neue Instanz ergänzt.
     * 
     * @param type $in_formID
     * @param type $in_instanceID
     */
    public function updateFormInstanceList($in_formID, $in_instanceID) {

        if (isset($this->_formsArray[$in_formID]["form.instances"]["i0"])) {
            //Wenn noch die i0-Instanz existiert, welche in addForm gesetzt wurde:
            if ($this->_formsArray[$in_formID]["form.instances"]["i0"]["default_instance"] == true) {
                //Wenn i0 noch als Default-Instanz gekennzeichnet ist: 

                $this->_formsArray[$in_formID]["form.instances"]["i0"]["default_instance"] = false;     //default-instance wird ab jetzt zu einer dedizierten instanz
                $temp = $this->_formsArray[$in_formID]["form.instances"]["i0"];                         //bisherige Werte zwischenspeichern, für den Fall, dass die instanz-id geändert wird
                unset($this->_formsArray[$in_formID]["form.instances"]["i0"]);                          //instanz entfernen
                $this->_formsArray[$in_formID]["form.instances"][$in_instanceID] = $temp;                //Werte unter neuer Instanz-ID wieder ablegen. Es ist möglich, dass die neue Instanz-id auch wieder "i0" lautet.
            }
        } else {
            //neue Instanz anlegen
            $this->_formsArray[$in_formID]["form.instances"][$in_instanceID] = array("instance_id" => $in_instanceID);
            $this->_formsArray[$in_formID]["form.instances"][$in_instanceID]["default_instance"] = false;
            $this->_formsArray[$in_formID]["form.instances"][$in_instanceID]["form.offset"] = 0;
            $this->setInitialFormModeAttributs($in_formID, $in_instanceID);
        }
    }

    /** Setzt die DefaultValueForInsert-Eigenschaft eines Formulars für eine bestimmte Instanz.
     * Diese Variante ist in erster Linie für lose  abhängige Formulare (reference_show) gedacht, 
     * um bspw. die Auswahl eines Datensatzes in einem Suchformular auf ein anderes selbständiges Formular zu übertragen.
     * Abhängige Formulare werden indirekt durch setFormPropertyValueForDependingForm bestückt.
     * 
     * @param   integer     $in_formID          ID eines Formulars
     * @param   integer     $in_instance_id     ID der Instanz des Formulars
     * @param   string      $in_DefaultValue    Array-Eintrag, key = db-spalte, value = Inhalt
     */
    public function setFormPropertyDefaultValueForInsert($in_formID, $in_instance_id, $in_DefaultValue) {

        if (isset($this->_formsArray[$in_formID])) {
            if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id])) {
                $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.tempDefaultValuesForInsert"] = $in_DefaultValue;
            }
        }
    }

    /** Setz oder ergänzt die Metadaten eines Buttons zu einem Formular im Form_Aray
     * 
     * @param   string      $in_btn_name        Name-Attribut, welches der Button im HTML-Dom hat.
     * @param   integer     $in_btn_id          ID des Buttons, gemäß der DB-Tabelle manger.feld
     * @param   string      $in_btn_caption     Beschriftung des Buttons
     * @param   string      $in_btn_app_id      App-ID des Buttons, gemäß der DB-Tabelle manger.feld
     * @param   integer     $in_function_id     ID der Funktion, die durch den Button aufgerufen wird. (siehe manager.button_action_function)
     * @param   string      $in_function_app_id App-ID der Funktion, die durch den Button aufgerufen wird. (siehe manager.button_action_function)
     * @param   integer     $in_button_target   Worauf bezieht sich der Button (siehe Konstantyp_id = 17 -> [4=form_other|1=form_self|3=nothing|2=post_array]
     * @param   integer     $in_form_mode       Modus, in dem das naächste Formular durch den Button-Klick aufgerufen werden soll. (siehe Tabelle form_mode)
     * @param   integer     $in_formID          ID des Formulars
     * @param   string      $in_instance_id     ID der Instanz
     * @param   string      $in_btn_column      Column, welche in button->feld.db_spalte hinterlegt ist
     * @param   string      $in_btn_vorgabe     Wert, der in button->feld.vorgabewert hinterlegt ist
     */
    public function setFormPropertyButton($in_btn_name, $in_btn_id, $in_btn_caption, $in_btn_app_id, $in_function_id, $in_function_app_id, $in_button_target, $in_form_mode, $in_formID, $in_instance_id, $in_btn_target_form_id, $in_btn_column, $in_btn_vorgabe) {

        if (isset($this->_formsArray[$in_formID])) {
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Form ('.$in_formID.') für Button setzen ', $in_button_name, "INFO");
            if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id])) {

                $my_button = array();
                $my_button["caption"] = $in_btn_caption;
                $my_button["button_id"] = $in_btn_id;
                $my_button["button_app_id"] = $in_btn_app_id;
                $my_button["button_action_function_id"] = $in_function_id;
                $my_button["button_action_function_app_id"] = $in_function_app_id;
                $my_button["button_target"] = $in_button_target;
                $my_button["form_mode"] = $in_form_mode;
                $my_button["target_form_id"] = $in_btn_target_form_id;
                $my_button["feld.db_column"] = $in_btn_column;
                $my_button["feld.vorgabewert"] = $in_btn_vorgabe;

                $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["buttons"][$in_btn_name] = $my_button;
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Form ('.$in_formID.'), Instanz ('.$in_instance_id.') für Button nicht gefunden ', $in_button_name, "INFO");
            }
        } else {
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Form ('.$in_formID.') für Button nicht gefunden ', $in_button_name, "ERROR");
        }
    }

    /** Ermittelt die Metadaten eines Buttons asu dem Backup_Form_Array der Session
     * 
     * @param   integer     $in_formID          ID des Formulars
     * @param   string      $in_instance_id     ID der Instanz
     * @param   string      $in_button_name     Name-Attribut, welches der Button im HTML-Dom hat.
     * @return  array                           Bsp.: Array( <br />
      [caption] => Schließen <br />
      [button_id] => 922 <br />
      [button_app_id] => SYS01 <br />
      [button_action_function_id] => 0 <br />
      [button_action_function_app_id] => SYS01 <br />
      [button_target] =>  <br />
      [form_mode] => 1) <br />
      [feld.db_column] => 1) <br />
      [feld.vorgabewert] => 1) <br />
     */
    public function getFormPropertyButton($in_form_id, $in_instance_id, $in_button_name) {
        $feedback = false;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> suche button-Attribute form (' . $in_form_id . '), instance (' . $in_instance_id . ')', $in_button_name);
        $formArray = $this->getFormArrayFromSessionBackup($in_form_id);
        if ($formArray != false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> formarray', $formArray);
            if (isset($formArray["form.instances"][$in_instance_id])) {       
                if (isset($formArray["form.instances"][$in_instance_id]["buttons"][$in_button_name])) {
                    $feedback = $formArray["form.instances"][$in_instance_id]["buttons"][$in_button_name];
                }
            }
        }

        return $feedback;
    }

    /** Setzt in der Multivalue-die Eigenschaft "form_dependence.target_forms" auf Formularebene die Attribute "dependencies" und <br />
     * "queryDependenceCondition". Die Funktion ergänzt jeweils genau einen Wert.<br />
     * Bei der Eigenschaft "form_dependence.target_forms" handelt es sich um ein Array, welches bspw. folgende Werte annehmen kann: <br />
     * [form_dependence.target_forms] => Array( <br />
      [59] => Array( <br />
      [dependencies] => Array([bew_antrag.bew_id] => 21702840 ) <br />
      [queryDependenceCondition] => Array( <br />
      [0] => Array( <br />
      [sourcetable] => bew <br />
      [sourcecolumn] => id <br />
      [targettable] => bew_antrag <br />
      [targetcolumn] => bew_id <br />
      [value] => 21702840 <br />
      ) <br />
      ) <br />
      ) <br />
      [116] => Array( <br />
      [dependencies] => Array([akte_bewegung.bew_id] => 21702840) <br />
      [queryDependenceCondition] => Array( <br />
      [0] => Array(<br />
      [sourcetable] => bew
      [sourcecolumn] => id
      [targettable] => akte_bewegung
      [targetcolumn] => bew_id
      [value] => 21702840
      ) <br />

      ) <br />
      ) <br />
     * Das Array wird beim Trigger-Formular abgelegt. Die Keys 59 und 116 entsprechen den ID's der abhängigen Formulare
     * 
     * @param   integer     $in_formID                                  ID des Formulars, für dessen abhängiges Formular die Abhängigkeitsbedingungen gesetzt werden soll.
     * @param   integer     $in_target_form_id                          ID des abhängigen Formulars, auf das sich die Bedingung bezieht.
     * @param   string      $in_target_table_and_column                 Tabelle und Spalte, auf die sich im abhängigen Formular ein Wert beziehen soll (Bsp.: "mytable.mycolumn" oder "auto.name")
     * @param   string      $in_Value                                   Wert, der als Wert eingetragen werden soll (Bsp.: "mercedes")
     * @param   array       $in_dependenceConditionForQuerybasedForm    Condition für Formulare hinterlegen, die auf einer Query basieren (SQL-Syntax: auto.name) = 'mercedes'
     *                                                                  array( "sourcetable" => $source_tablename,
      "sourcecolumn" => $source_columnname,
      "targettable" => $target_tablename,
      "targetcolumn" => $target_columnname,
      "value" => $source_fieldcontent);
     */
    public function setFormPropertyValueForDependingForm($in_formID, $in_target_form_id, $in_target_table_and_column, $in_Value, $in_dependenceConditionForQuerybasedForm) {

        if (isset($this->_formsArray[$in_formID])) {

            $this->_formsArray[$in_formID]["form_dependence.target_forms"][$in_target_form_id]["dependencies"][$in_target_table_and_column] = $in_Value;
            $this->_formsArray[$in_formID]["form_dependence.target_forms"][$in_target_form_id]["queryDependenceCondition"][] = $in_dependenceConditionForQuerybasedForm;
        }
    }

    /** Gibt die Eigenschaft ["form_dependence.target_forms"][form_id]["dependencies"] für ein Triggerformular und ein abhängiges Formular (Target-Formular) zurück.
     * 
     * @param   integer     $in_trigger_form_id     ID des Trigger-Formulars
     * @param   integer     $in_target_form_id      ID des abhängigen Formulars
     * @return  array                               Array mit den Abhängigkeitsbedingungen oder Leerarray, wenn keine Abhängigkeit existiert.
     *                                              Bsp.: Array
      (
      [auto.hersteller] => "Mercedes"
      [auto.typ] => "Coupe"
      )
     */
    public function getFormPropertyValueForDependingForm($in_trigger_form_id, $in_target_form_id) {
        $feedback = array();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> ', 'trigger_form: '.$in_trigger_form_id.' | target_form: '.$in_target_form_id);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> form_array ', $this->_formsArray);
        if (isset($this->_formsArray[$in_trigger_form_id])) {
            if (isset($this->_formsArray[$in_trigger_form_id]["form_dependence.target_forms"][$in_target_form_id]["dependencies"])) {
                $feedback = $this->_formsArray[$in_trigger_form_id]["form_dependence.target_forms"][$in_target_form_id]["dependencies"];
            }
        }


        if ($feedback == "") {
            $feedback = array();
        }

        return $feedback;
    }

    /** Ermittelt über das Triggerformular aus dem FormArray die DefaultdatenForInsert
     * 
     * @param  integer  $in_trigger_form_id     ID des Formulars, von dem das aktuelle Formular abhängt       
     * @param  integer  $in_form_id             ID des aktuellen Formulars
     * @param  string   $in_instance_id         ID der aktuellen Instanz
     * @param  bool     $in_with_tablename      Gibt an, ob bei der Rückgbae der key die Syntax tablename.columnname oder nur columnname hat
     * @param  bool     $in_is_nested_form      Gibt an, ob es sich um ein eingebettetes Formular handelt oder nicht.
     * @return array                            Bsp.:
     *                                          Array { <br>
                                                        [auto.name] => "Mercedes",  <br>
                                                        [auto.type] => "Coupe"      <br>
                                                        [isDefaultInsert] => true   <br>
                                                      ) <br>
     */
    function getFormPropertyDefaultValueForInsert($in_trigger_form_id, $in_form_id, $in_instance_id, $in_with_tablename, $in_is_nested_form) {
        $dummyData = array();

        if ($in_is_nested_form == true) {
            //eingebettetes Formular

            if (isset($this->_formsArray[$in_form_id])) {
                if (isset($this->_formsArray[$in_form_id]["form.instances"][$in_instance_id]["form.tempDefaultValuesForInsert"])) {
                    //Wenn Vorgabewerte für leere Datensätze existieren, wird daraus ain dummy-Datensatz generiert                        
                    foreach ($this->_formsArray[$in_form_id]["form.instances"][$in_instance_id]["form.tempDefaultValuesForInsert"] as $spalte => $value) {
                        if ($in_with_tablename == true) {
                            $dummyData[$this->_formsArray[$in_form_id]["form.db_table"] . "." . $spalte] = $value;
                        } else {
                            $dummyData[$spalte] = $value;
                        }
                    }
                }
            }
        } else {
            //nicht eingebettete Formulare
            if (isset($this->_formsArray[$in_trigger_form_id])) {
                if (isset($this->_formsArray[$in_trigger_form_id]["form_dependence.target_forms"][$in_form_id]["dependencies"])) {
                    //Wenn Vorgabewerte für leere Datensätze existieren, wird daraus ein dummy-Datensatz generiert                        
                    foreach ($this->_formsArray[$in_trigger_form_id]["form_dependence.target_forms"][$in_form_id]["dependencies"] as $table_and_column => $value) {
                        if ($in_with_tablename == true) {
                            $dummyData[$table_and_column] = $value;
                        } else {
                            $table_and_column_array = explode(".", $table_and_column);
                            $column = $table_and_column_array[1];
                            $dummyData[$column] = $value;
                        }
                    }
                }
            }
        }
        
        $dummyData["isDefaultInsert"] = true;
        return $dummyData;
    }

    /** Ermittelt über das Backup in der SessionVariable die Vorgabewerte für in_form_id, welche von einem Triggerformular übernommen wurden
     * 
     * @param   integer     $in_form_id             ID des Formulars
     * @param   string      $in_instance_id         ID der Instanz
     * @param   boolean     $in_with_tablename      Wenn true, dann wird im Array des Rückgabewertes table.spalte als key genutzt; bei false wird spalte als key genutzt
     * @return  array                               Bsp.: Array
      (
      [auto.name] => "Mercedes",
      [auto.type] => "Coupe"
      )
     */
    function getFormPropertyDefaultValueForInsert2($in_form_id, $in_instance_id, $in_with_tablename) {
        $dummyData = array();

        $myFormArray = session_class::$session_object->getFormbackup($in_form_id);
        

        if ($myFormArray !== false) {
            if (isset($myFormArray["form.instances"][$in_instance_id]["form.tempDefaultValuesForInsert"])) {
                //Wenn Vorgabewerte für leere Datensätze existieren, wird daraus ain dummy-Datensatz generiert                        
                foreach ($myFormArray["form.instances"][$in_instance_id]["form.tempDefaultValuesForInsert"] as $spalte => $value) {
                    if ($in_with_tablename == true) {
                        $dummyData[$myFormArray["form.db_table"] . "." . $spalte] = $value;
                    } else {
                        $dummyData[$spalte] = $value;
                    }
                }
            }
        }


        return $dummyData;
    }

    /** Die Funktion überträgt die Eigenschaft "form_dependence.target_forms" des Trigger-Formulars, wenn vorhanden,
     *  für ein Target-Formular aus dem Session-Backup für das genannte Formular in das aktuelle Formular-Array.
     *  
     * @param integer  $in_triggerform_id              ID des Trigger-Formulars, dessen Eigenschaft übertragen werden soll
     * @param integer  $in_targetform_id               im Trigger-Formular können "form_dependence.target_forms" für mehrere
     *                                                  Target-Formulare hinterlegt sein. Es werden nur die, die sich auf
     *                                                  $in_targetform_id beziehen, übertragen.
     */
    function takeDefaultValueForInsertFromBackup($in_triggerform_id, $in_targetform_id) {

        $myFormArray = session_class::$session_object->getFormbackup($in_triggerform_id);
        
        if ($myFormArray !== false) {
            if (isset($myFormArray["form_dependence.target_forms"][$in_targetform_id])) {
                //Wenn Vorgabewerte für die targetForm im Backup für leere Datensätze existieren, werden diese im gleichen, aber aktuellen Trigger-Formular übertragen                     
                $this->_formsArray[$in_triggerform_id]["form_dependence.target_forms"][$in_targetform_id] = $myFormArray["form_dependence.target_forms"][$in_targetform_id];
            }
        }
    }

    /**
     * Gibt das Array der Instanzen zurück.
     * 
     * @param   integer     $in_formID      ID des Formulars, dessen Instanzen zurückgegeben werden sollen
     * @return  array                       Liste der Instancen mit allen Eigenschaften. Wenn keine Instanz existiert, wird array() zurückgegeben.
     */
    function getFormPropertyInstances($in_formID) {
        $feedback = array();

        if (isset($this->_formsArray[$in_formID])) {
            if (isset($this->_formsArray[$in_formID]["form.instances"])) {
                $feedback = $this->_formsArray[$in_formID]["form.instances"];
            }
        }
        return $feedback;
    }

    /** Gibt die Default-Condition einer Instanz eines Formulars zurück. Wenn keine Condition vorhanden ist wird ein Leerstring ("") zurückgegeben.
     * 
     * @param   intger  $in_formID
     * @param   string  $in_instance_id
     * @return  string                      SQL-String, der in der Where-Klausel verwendet werden kann
     */
    function getFormInstancePropertyCondition($in_formID, $in_instance_id) {
        $feedback = "";

        if (isset($this->_formsArray[$in_formID])) {
            if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.default_condition"])) {
                $feedback = $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.default_condition"];
            }
        }
        return $feedback;
    }
    
    
    
    /** Gibt die Filter-Condition einer Instanz eines Formulars zurück. Wenn keine Condition vorhanden ist wird ein Leerstring ("") zurückgegeben.
     * 
     * @param   intger  $in_formID
     * @param   string  $in_instance_id
     * @return  string                      SQL-String, der in der Where-Klausel verwendet werden kann
     */
    function getFormInstancePropertyConditionFilter($in_formID, $in_instance_id) {
        $feedback = "";

        if (isset($this->_formsArray[$in_formID])) {
            if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.filter_condition"])) {
                $feedback = $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.filter_condition"];
            }
        }
        return $feedback;
    }

    /** Gibt die Default-Condition, welche immer für ein Formular gilt, zurück.
     * Diese wird in der Datenbanktabelle form definiert. Wenn keine Condition vorhanden ist wird ein Leerstring ("") zurückgegeben.
     * 
     * @param   intger  $in_formID
     * @return  string                      SQL-String, der in der Where-Klausel verwendet werden kann
     */
    function getFormPropertyConditionDefault($in_formID) {
        $feedback = "";

        if (isset($this->_formsArray[$in_formID])) {
            
           
            
            if (isset($this->_formsArray[$in_formID]["form.default_condition"])) {
                
                
                
                //Prüfen ob eine Plugin-Funktion enthalten ist
                if (strpos($this->_formsArray[$in_formID]["form.default_condition"], '$$function.') !== false) {
                    $default_condition = $this->_formsArray[$in_formID]["form.default_condition"];
                    //Startposition der Funktion
                    //$startpos
                    $startposition = strpos($default_condition, '$$function.');
                    //endposition
                    $endposition = strpos($default_condition, '$$', $startposition + 1);
                    $length = $endposition - $startposition;
                    //Funktionsname
                    $functionname = substr($default_condition, $startposition, $length);
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> functionname ", $functionname, "INFO");

                    //Wert ersetzen
                    $myValue = getValueFromPluginFunction($functionname);
                    $new_condition = str_replace($functionname . "$$", $myValue, $default_condition);
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> new condition ", $new_condition, "INFO");
                    $this->_formsArray[$in_formID]["form.default_condition"] = $new_condition;
                }
                $feedback = $this->_formsArray[$in_formID]["form.default_condition"];
            }
        }
        return $feedback;
    }

    /** Setzt nach einer Funktionsausführung für die wichtigsten Formulardaten die Standardwerte,
     * sodass nach dem nächsten Formularaufbau die Standardfunktione, wie Save, Insert, delete usw. 
     * wieder funktionieren können.
     * 
     * Dabei werden folgende Funktionen aufgerufen <br />
      $this->takeOldConditions($in_SESSION); <br />
      $this->takeOldDefaultValuesForInsert($in_SESSION);   <br />
      $this->setFormModeToPreviousValueForAllForms($in_SESSION); <br />
     * @param array     $in_except      [optional] Ausnahmen; Liste aller Fomulare für welche die alten Werte nicht übernommen werden sollen. (default = array())
     */
    public function setDefaultFormProperties($in_except=array()) {
        $this->takeOldConditions($in_except);
        $this->takeOldDefaultValuesForInsert($in_except);
        //$this->setFormModeForAllForms(1);
        $this->setFormModeToPreviousValueForAllForms($in_except);
    }

    /** Speichert die geänderten Datensätze, die mit dem Post-Array übergeben wurden 
     * und versendet sie zusätzlich an die übergebene Mailadresse
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  integer                     22  = erfolgreich gespeichert und per Mail versendet; 
     *                                      -22 = erfolgreich gespeichert, aber Mailversand gescheitert
     *                                      -2  = Speichern fehlgeschlagen, keine Mail versendet
     */
    public function internFunction_insertDataAndSendMail() {
        require_once("../controller/mail_class.php");

        $feedback = 0;
        $form_id = $this->getPostObject()->getFormIDFromControlData();          //ID des Formulars, in dem der Button geklickt wurde

        $feedbackForInsert = $this->internFunction_insertData();

        if ($feedbackForInsert == 2) {
            //Wenn die Daten erfolgreich gespeichert wurden
            $myMail = new mail_appms($this, $form_id);
            $feedbackForMail = $myMail->feedbackCode;

            if ($feedbackForMail > 0) {
                //Mailversand war vermutlich erfolgreich             
                $feedback = 22;
            } else {
                //Mailversand ist gescheitert
                $feedback = -22;
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Fehler bei Mailversand', 'Feedback-Code = ' . $feedbackForMail);
            }
        } else {
            //Wenn die Daten nicht gespeichert werden konnten
            $feedback = $feedbackForInsert;
        }

        return $feedback;
    }
    
    
    
    
    /** Speichert die geänderten Datensätze, die mit dem Post-Array übergeben wurden 
     * und versendet sie zusätzlich an die übergebene Mailadresse. Außerdem wird ein Workflow angelegt.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * 
     * @param   boolean     $in_only_save               Wenn true, werden nur die Inhaltsdaten gespeichert, der Workflowstep wird jedoch nicht verändert.
     *                                                  Wenn es sich um einen neuen Workflow handelt, wird dieser angelegt, aber im Step 1 belassen.
     * @param   boolean     $in_addFileToDS0            [optional] Gibt an, ob auch die Files im base64-Format selbst zum ersten Datensatz ergänzt werden sollen. [true|false] -> default = false
     * @param   string      $in_columnForFile           [optional] Falls die Dateien zum neuen Datensatzergänzt werden sollen, dann wird $in_fileColumn als Attribut genutzt.
     * @return  integer                                 22  = erfolgreich gespeichert und per Mail versendet; 
     *                                                  -22 = erfolgreich gespeichert, aber Mailversand gescheitert
     *                                                  -2  = Speichern fehlgeschlagen, keine Mail versendet
     */
    public function internFunction_insertDataAndUpdateWorkflow($in_only_save = false, $in_addFileToDS0 = false, $in_columnForFile = "file") {
        require_once("../controller/mail_class.php");

        $feedback = 0;
        $form_id = $this->getPostObject()->getFormIDFromControlData();          //ID des Formulars, in dem der Button geklickt wurde
        
        
        
        //Daten einfügen oder speichern
        $feedbackForInsert = $this->internFunction_insertDataOrUpdate($in_addFileToDS0, $in_columnForFile);        

        if ($feedbackForInsert > 0) {
            //Wenn die Daten erfolgreich gespeichert wurden
            
            //New_data einlesen, da nun auch die Auto-Increment-Werte enthalten sind.
            $datensätze = $this->getPostObject()->getNewData();
            
            if($this->getFormPropertyIsnested($form_id) == false) {
                //Wenn es sich um ein eigenständiges Formular handelt, dann auch Workflow aktualisieren.
                //Wenn hingegen Daten in einem nested Formular erfasst wurden, dann hat sich am führenden Datensatz und somit am Workflow nichts geändert.
                try {


                    //Primary-Keys des aktuellen Formulars ermitteln, damit diese dem Workflow-Object mitgeteilt werden können
                    $primarykeys = $this->getFormPropertyPrimaryKeys($form_id);

                    //Workflow-Object holen und neuen Vorgang anlegen oder aktualisieren.
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  vor setNewOrUpdateInstance', "vor setNewOrUpdateInstance");
                    $feedback_instance = $this->_my_workflow_object->setNewOrUpdateInstance($datensätze, $primarykeys, $in_only_save);
                    //URL-ID in Get-Object übertragen, damit in showFields._getFieldSubmitbutton darauf zugegriffen werden kann.
                    $this->internGetObject->setWorkflowUrlID($this->_my_workflow_object->getUrlid());





                    if($in_only_save == false) {
                        //Wenn ein Status in die Content-Table eingetragen werden soll
                        $wkfl_content_status = $this->_my_workflow_object->getWorkflowStepStatusForContenttable();
                        if($wkfl_content_status !== false) {
                            $this->getPostObject()->addAttributToNewOrChangedData(0, $wkfl_content_status["column"], $wkfl_content_status["status"]);
                            $this->internFunction_saveData();
                        }
                        //Formularstatus aller Formulare auf only_read setzen
                        $flat_form_list = $this->_my_workflow_object->getFormListAsArray();
                        $this->setFormModeForGivingFormList($flat_form_list,7);    //formmodus auf only_read setzen

                        //nächsten Bearbeiter per Mail informieren
                        $myMail = new mail_appms($this, $form_id);
                        $feedbackForMail = $myMail->feedbackCode;

                        if ($feedbackForMail > 0) {
                            //Mailversand war vermutlich erfolgreich             
                            $feedback = 22;
                        } else {
                            //Mailversand ist gescheitert
                            $feedback = -22;
                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Fehler bei Mailversand', 'Feedback-Code = ' . $feedbackForMail);
                        }
                        
                        //aktuelle Workflow-ID in GET-Object übergeben. Darauf wird bei den submit-Buttons zurückgegriffen und die Wkfl-ID für den nächsten Maskenaufruf verwendet.
                        //$in_pagedata->internGetObject->setWorkflowUrlID();
                    } else {
                        $feedback = 4004;
                    }


                } catch (Exception $exc) {
                    $feedback = $exc->getMessage();
                }  
            } else {
                //nur die Workflow-Metadaten (Mail-TO, Mail-CC, Message) weiterreichen
                //$this->_my_workflow_object->addExistingWkflMetadata();    -> values sind zu diesem Zeitpunkt null
                
            }
            
        } else {
            //Wenn die Daten nicht gespeichert werden konnten
            $feedback = $feedbackForInsert;
        }

        return $feedback;
    }
    
    
    
    /** Speichert einen Workflow, ohne den Status zu ändern. Auch die Neuanlage eines Workflows ist damit möglich.
     * Der Status bleibt dann jedoch auf dem ersten Step.
     * 
     * @return  integer     Feddbackcodes gemäß Konstantentyp_id; [4004|-22]
     */
    public function internFunction_saveWorkflow() {
        $feedback = $this->internFunction_insertDataAndUpdateWorkflow(true);
        
        
        //Welche Feedbacks müssen gesetzt werden?
        return $feedback;
    }
    
    
    
    
    /** Setzt den Fortschritt eines Workflows auf einen vorherigen Step zurück. Wenn in workflow_step.back_to_step etwas definiert ist,
     * dann wird dieser Step als neuer Step gesetzt. Ansonsten wird der Vorgänger des aktuellen Steps gesetzt.
     * 
     * @return  integer     Feedbackcodes, gemäß Konstantentyp_id 35 (4000er-Bereich)
     */
    public function internFunction_rejectWorkflowstep() {
        require_once("../controller/mail_class.php");

        $feedback = 0;
        $form_id = $this->getPostObject()->getFormIDFromControlData();          //ID des Formulars, in dem der Button geklickt wurde
           
        //New_data mit changeddate gleichsetzen, da die Mail-Klasse zurzeit nur mit newdata arbeitet.
        $datensätze = $this->getPostObject()->getChangedData();
               
            
        
        try {
            //Workflow-Object holen und vorherigen Status wieder einsetzen.
            $feedback = $this->_my_workflow_object->rejectWorkflowstep($datensätze);
            
            //in rejectWorkflowstep wurde $datensätze (mindestens Mail_to aktualisiert) -> daher erneut in Postobject hinterlegen
            $this->getPostObject()->setNewData($datensätze);
            $this->setFormPropertyDataFromLastInsert($form_id, $datensätze[0]["content"]);                     //Daten ablegen, damit später, bspw. beim Mailversand wieder darauf zugegriffen werden kann.
         
            
            //Mailversand
            $myMail = new mail_appms($this, $form_id);
            $feedbackForMail = $myMail->feedbackCode;

            if ($feedbackForMail > 0) {
                //Mailversand war vermutlich erfolgreich             
                $feedback = 22;
            } else {
                //Mailversand ist gescheitert
                $feedback = -22;
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Fehler bei Mailversand', 'Feedback-Code = ' . $feedbackForMail);
            }
        } catch (Exception $exc) {
            $feedback = $exc->getMessage();
        }    
            
            
       

        return $feedback;
    }
    
    
    
    
    public function internFunction_deleteWorkflowInstance() {
        
        $feedback = 0;
            
        
        //Workflow-Object holen und Instance löschen.
        $feedback = $this->_my_workflow_object->deleteInstance();
        
        
        //Fachdaten aus dem sendenden Formular löschen
        if($feedback > 0) {
            $feedback_temp = $this->internFunction_deleteDataset();
            if($feedback_temp < 0) {$feedback = -4006;}
        }
            
       

        return $feedback;
    }
    
    
    
    
    
    
    

    /** ergänzt die Dateinamen der hochgeladenen Dateien in $internPostObject->_newDataArray in die entsprechenden, 
     * laut Felderkatalog des sendenen Formulars, vorgesehenen Spalten.
     * Wenn keine Dateien in $_FILES vorhanden sind, wird nichts ergänzt.
     * Zusätzlich werden die Dateien in base64-Format als Array zurückgegeben. Die Dateien bleiben in $_FILES
     * und im temporären Ordner des Webservers erhalten.
     * Im Return-Array sind folgende Attribute vorhanden: <br />
     * Array( <br />
      [0] => Array( <br />
      [name] => AppMS_Update-Verfahren.pdf <br />
      [mimetype] => application/pdf <br />
      [filesize] => 543953 <br />
      [filebase64] => "R0lGODdhAQABAPAAAP8AAAAAACwAAAAAAQABAAACAkQBADs=" <br />
      [datastore_id] => <br />
      [tmp_name] =>
      ) <br />
      ) <br />
     * 
     * @param   boolean     $in_addFileToNewData        Gibt an, ob auch die Files im base64-Format selbst zum Datensatz ergänzt werden sollen. [true|false]
     * @param   string      $in_fileColumn              Falls die Dateien zum neuen Datensatzergänzt werden sollen, dann wird $in_fileColumn als Attribut genutzt.
     *                                                  Wenn mehrere Files vorhanden sind, dann $in_fileColumn hochgezählt. 
     *                                                  D.h., die erste Datei landet in $in_fileColumn, die zweite in $in_fileColumn1, die dritte in $in_fileColumn1, usw.
     * @return  mixed                                   Array, wenn Upload zulassig. Ansonsten false. Wenn keine Datei hochgeladen wurde, wird ein leeres Array zurückgegeben. <br />
     *                                                  Bsp.:
     *                                                      Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [name] => kleinePDF.pdf
                                                                            [mimetype] => application/pdf
                                                                            [filesize] => 7983
                                                                            [tmp_name] => /tmp/phptuJw9p
                                                                            [filebase64] => JVBERi0xLjYK...
                                                                        )

                                                                )
     *    
     */
    public function addUploadedFilesAsBase64ToInsertdata($in_addFileToNewData, $in_fileColumn) {
        //Alle Files in base64 codieren und in das InsertArray ergänzen

        require_once("../controller/upload_class.php");
        $tempBase64Array = array();
        $i = "";

        //PostObjekt holen
        $internPostObject = $this->getPostObject();
        $datensätze = $internPostObject->getNewData();
        $form_id = $internPostObject->getSenderformId();
        $app_id = $this->getFormPropertyAppId($form_id);
        

        $myDsID = 0;
        if (isset($datensätze[$myDsID])) {
            //Wenn es NewData gibt
            $myContent = $datensätze[$myDsID]["content"];
            $table = $datensätze[$myDsID]["table"];
            
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ergänze Files ausschließlich zu Datensatz mit ID=0: ', $datensätze[$myDsID]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  _FILES', $_FILES);

            if (is_array($_FILES) and $_FILES != array()) {
                $myUpload = new fileUpload();
                
                foreach ($_FILES as $key => $currentFile) {
                    
                    //Prüfen, ob die Datei hochgeladen werden darf.
                    $allowed_filetypes = $this->getAllowedFiletypeFromForm($form_id);
                    $is_upload_allowed = $myUpload->checkFile($currentFile["name"], $allowed_filetypes, $app_id);
                    
                    if($is_upload_allowed === true) {
                        //Target-Fieldname der Datei ermitteln  (Bsp. key: 0appms_req110datastore0field120Form621_0_i0)
                        $keyparts = explode("0", $key);
                        $targetFieldname = $keyparts[3];

                        if ($currentFile["name"] != "") {
                            //Schleife über alle Files und in Zielfeld integrieren
                            // Dateieigenschaften und Inhalt (im base64-Format) in eine Variable übernehmen
                            $myBase64File = array();
                            $myBase64File["name"] = $currentFile["name"];
                            $myBase64File["mimetype"] = $currentFile["type"];
                            $myBase64File["filesize"] = $currentFile["size"];
                            $myBase64File["tmp_name"] = $currentFile["tmp_name"];
                            //                    $myBase64File["filebase64"] = base64_encode(file_get_contents("..". global_variables::getDirectorySeparator().$targetpath.$currentFile["name"]));
                            $myBase64File["filebase64"] = base64_encode(file_get_contents($currentFile["tmp_name"]));
                            $tempBase64Array[] = $myBase64File;

                            //Insertdata um Dateinamen erweitern
                            if(isset($myContent[$targetFieldname])) {
                                //Wenn die Spalte für den Dateinamen bereits im Datensatz existiert, dann wird diese genutzt
                                $myContent[$targetFieldname]= $currentFile["name"];
                            } else {
                                //ansonsten wird eine neue Spalte für den Dateinamen ergänzt
                                $myContent[$table.".".$targetFieldname] = $currentFile["name"];
                            }
                            if ($in_addFileToNewData === true) {
                                $myContent[$in_fileColumn . $i] = $myBase64File["filebase64"];
                                if ($i == "") {
                                    $i = 0;
                                }
                                $i = $i + 1;
                            }
                            $this->getPostObject()->setNewDataContent(0, $myContent);
                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  ergänze Feld zu Contentarray', $targetFieldname . "=" . $currentFile["name"]);
                        }
                    } else {
                        $tempBase64Array = false;
                    }
                }
            }
        }
        return $tempBase64Array;
    }
    
    
    
    
    
    
    
    
    
    

    /** Lädt eine Datei hoch, legt sie im Filesystem ab und schreibt einen entsprechenden Datensatz in die Tabelle des sendenden Formulars.
     * Diese Funktion kann nur genau einen Datensatz, mit genau einer Datei verarbeiten. Werden mehrere Datensätze und
     * Dateien hochgeladen, dann wird jeweils nur der erste Datensatz und die erste Datei beachtet. 
     * Die DB-Tabelle, welche den Datensatz aufnimmt, muss mindestens die Spalten (upload_date, upload_user, 
     * upload_role, upload_mask, filename, filesize, filetype und filesize) besitzen
     * 
     * @return  integer     Fehlermeldung wie bei insert.
     */
    protected function internFunction_insertDataAndAddFileToFS() {

        $feedback = $this->chooseFileHandler("filesystem");

        return $feedback;
    }

    /** Lädt eine Datei hoch, schreibt einen entsprechenden Datensatz in die Tabelle des sendenden Formulars, inkl. der Datei im base64-Format, ab.
     * Diese Funktion kann nur genau einen Datensatz, mit genau einer Datei verarbeiten. Werden mehrere Datensätze und
     * Dateien hochgeladen, dann wird jeweils nur der erste Datensatz und die erste Datei beachtet. 
     * Die DB-Tabelle, welche den Datensatz aufnimmt, muss mindestens die Spalten (upload_date, upload_user, 
     * upload_role, upload_mask, filename, filesize, filetype und filesize) besitzen
     * 
     * @return  integer     Fehlermeldung wie bei insert.
     */
    public function internFunction_insertDataAndAddFileToDB() {

        $feedback = $this->chooseFileHandler("database");

        return $feedback;
    }

    /** Wählt die weiterverarbeitende Methode für die Speicherung von Datensätzen mit einem Dateianhang.
     * Wenn $in_target = filesystem und gleichzeitig eine ID je file angegeben wurde, dann werden vorhandene Dateien erst gelöscht,
     * bevor neue Dateien angelegt werden.
     * 
     * @param   string  $in_target  Ziel für die Ablage der Datei; [database|filesystem]
     * @return  integer             Fehlermeldung wie bei insert.
     */
    protected function chooseFileHandler($in_target) {
        require_once("../controller/upload_class.php");

        //PostObjekt holen
        $internPostObject = $this->getPostObject();
        $datensätze = $internPostObject->getNewData();
        $form_id = $internPostObject->getFormIDFromControlData();

        $myDsID = 0;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte mit Datensätze: ', $datensätze);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  _FILES', $_FILES);

        $firstFile = array_values($_FILES)[0];

        //erlaubte Dateitypen ermitteln
        $allowed_filetypes = $this->getAllowedFiletypeFromForm($form_id);
        
        
        

        if ($in_target == "filesystem") {
            //Falls im ersten DS eine zu ersetzende Datei angegeben wurde, dann existiert diese Angabe vermutlich in allen Datensätzen
            if(isset($datensätze[0]["content"]["files.id"])) {
                if($datensätze[0]["content"]["files.id"] != "") {
                    //alle angegebenen Dateien zuerst löschen, damit die neuen Dateien die vorgegebenen ID's erhalten können
                    $this->internFunction_deleteFile($datensätze);
                } else {
                    //key "files.id" entfernen, da sonst Fehler bei folgenden insert auftreten kann
                    foreach ($datensätze as $key => $cur_ds) {
                        unset($datensätze[$key]["content"]["files.id"]);
                    }
                }
            }
            
            //neue Datei anlegen
            $feedback = $this->insertDataAndAddFileToFS($firstFile, $allowed_filetypes, $internPostObject, $myDsID, $datensätze);
        } elseif ($in_target == "database") {
            $myUpload = new fileUpload();
            $feedback = $myUpload->moveFileToDatabase($firstFile, $allowed_filetypes, $internPostObject, $myDsID, $datensätze, $this);
        }

        return $feedback;
    }

    /** Speichert die Daten in der DB-Tabelle des sendenden Formulars und verschiebt die Datei in den targetpath, 
     * welcher in Abhängigkeit vom Dateityp ermittelt wird.
     * 
     * @param   array   $in_file                Ein file aus der Globalen $_FILES
     * @param   string  $in_allowedFiletypes    kommaseparierte Liste der erlaubten Dateiendungen
     * @param   object  $in_internPostObject
     * @param   integer $in_DsID                ID des Datensatzes des sendenen Fomulars, der gerade verarbeitet wird.
     * @param   array   $in_datensätze          Liste der Datensätze des sendenden Formulars 
     * @return  integer                         Fehlermeldung wie bei insert.
     */
    protected function insertDataAndAddFileToFS($in_file, $in_allowedFiletypes, &$in_internPostObject, $in_DsID, $in_datensätze) {
        $myContent = $in_datensätze[$in_DsID]["content"];
        $app_id = $myContent["files.app_id"];

        //Targetpath ermitteln
        $targetpath = $this->getTargetPathForFileUpload($in_file, $app_id);

        //hochgeladene Datei in den Zielordner verschieben
        $feedback = $this->moveUploadFile($targetpath, $in_allowedFiletypes, $app_id, $in_file);
        //$_FILES leeren, da Dateien bereits verschoben wurden. So wird sichergestellt, dass nachfolgende Funktionen,
        //bspw. internFunction_insertData nicht in einen Fehler laufen.
        $_FILES = array();

        //Newdata, inkl. File-Attribute, in der DB-Tabelle des sendenden Formulars ablegen
        if ($feedback >= 0) {
            //Datensatz um weitere Attribute des files ergänzen
            $addContent = $this->getFileAttributsToNewData($in_file, $targetpath, $this->getCurrentRoleFromSession());
            //Neue Attribute zu Newdata ergänzen
            $in_internPostObject->setNewDataContent($in_DsID, array_merge($myContent, $addContent));
            //Daten in DB-Tabelle des sendenden Formulars schreiben
            $feedback = $this->internFunction_insertData();
        }

        return $feedback;
    }

    /** Bildet ein Array, welches zu den vorhandenen Content-Attributen von NewData ergänzt werden kann,
     * um auch $in_file mit dem insert von NewData an die Datenbank zu übergeben.
     * 
     * @param   array   $in_file        Ein Array (File) aus der Globalen $_FILES.
     * @param   string  $in_targetpath  Pfad, in dem die Datei abgelegt ist. Wenn $in_targetpath == "", dann wird dieses Attribut nicht angelegt. 
     *                                  Das ist sinnvoll, wenn die Datei selbst in newData, d.h. in der DB, gespeichert wird.
     * @param   array   $in_activeRole  Array der aktiven Rolle mit den Attributen "role.app_id" und "role.id"
     * @return  array                   
     */
    public function getFileAttributsToNewData($in_file, $in_targetpath, $in_activeRole) {
        $addContent = array();

        //Datensatz um weitere Attribute der Tabelle files ergänzen
        $addContent["filename"] = $in_file["name"];
        if ($in_targetpath != "") {
            $addContent["pathname"] = $in_targetpath;
        }
        $addContent["upload_date"] = date('Y-m-d H:i:s');
        $addContent["upload_user"] = $this->getCurrentUserFromSession();
        $addContent["upload_role"] = $in_activeRole["role.app_id"] . "/" . $in_activeRole["role.id"];
        $addContent["upload_mask"] = $this->getMaskProbertyID();
        $addContent["filetype"] = $in_file["type"];
        ;
        $addContent["filesize"] = $in_file["size"];

        return $addContent;
    }

    /** Ermittelt den Speicherpfad im Filesystem zur Ablage einer hochgeladenen Datei.
     * 
     * @param   array   $in_file        Eine einzelne Datei aus der globalen Variable $_FILES
     * @param   string  $in_app_id      APP-ID der Maske
     * @return  string                  relativer Pfad zur Datei, OS-abhängig; bspw.: data/SYS01/img/
     */
    protected function getTargetPathForFileUpload($in_file, $in_app_id) {
        if (strpos($in_file["type"], "/")) {
            $filetypeAttributs = explode("/", $in_file["type"]);
        } else {
            $filetypeAttributs = $in_file["type"];
        }
        $filetype = $filetypeAttributs[0];
        $filetypeAttributsByName = explode(".", $in_file["name"]);
        $filetypeByName = $filetypeAttributsByName[1];

        if ($filetype == "image") {
            $targetpath = global_variables::getPathForImages_rel($in_app_id);
        } elseif ($filetype == "application" and $filetypeByName == "mail") {
            $targetpath = global_variables::getPathForMail_rel($in_app_id);
        } else {
            $targetpath = global_variables::getPathForQueryTemplate_rel($in_app_id);
        }

        return $targetpath;
    }

    /** verschiebt eine Datei aus $_FILES von temporären WebserverOrdner in den target-Ordner
     * 
     * @param   string      $in_targetpath_rel      relativer Pfad zum Zielordner mit abschließenden Slash/Backslash
     * @param   string      $in_allowed_filetyps    Liste der erlaubten Dteitypen laut Felddefinition
     * @param   string      $in_app_id              ID der App
     * @param   array       $in_currentFile         Ein File-Array aus $_FILES
     * @return  integer                             ID der Fehlermeldung, gemäß konstantentyp_id = 35 [150|-150|-151|-152|-153]
     */
    protected function moveUploadFile($in_targetpath_rel, $in_allowed_filetyps, $in_app_id, $in_currentFile) {
        $targetpath_abs = global_variables::getPathForAppmsinstall_abs(false) . $in_targetpath_rel;

        //FileUpload in den Zielordner verschieben
        try {
            $myUpload = new fileUpload();
            $myUpload->moveFileToFilesystem($targetpath_abs, $in_allowed_filetyps, $in_app_id, $in_currentFile);
            $this->updateFilename = $myUpload->getFilename();
            $feedback = 150;
        } catch (Exception $exc) {
            $feedback = $exc->getMessage();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Fehler bei Dateiupload', $feedback);
        }
        return $feedback;
    }

    /** Ergänzt _formArray[last_insert], welches jeweils die Spaltennamen und deren values enthält, um die Feldnamen und Klartext für Referenzfelder.
     * Bei Datumsfeldern wird der Wert in das Format "d.m.Y" (TT.MM.JJJJ) übertragen.
     * 
     * @param integer   $in_form_id     ID des Formulars
     * @param string    $in_app_id      APP_ID des Formulars
     */
    function addFieldnameAndIdToLastInsertedData($in_form_id, $in_app_id) {
        //Feldnamen ergänzen für alle Felder ergänzen. Die Felder der Tabelle request haben sonst nicht-sprechende Bezeichnungen
        $requestData = $this->getFormPropertyDataFromLastInsert($in_form_id);
        $requestDataNew = array();
        
        //Schleife über alle Werte und dabei Feldnamen in value ergänzen
        foreach ($requestData as $key => $value) {
            //$key = tabelle.spalte
            $fieldarray = getFieldNameAndIdBySpalteFromSessionBackup($in_form_id, $in_app_id, $key);
            
            if($fieldarray != false) {
                $fieldarray["field.value"] = $value;

                //Klartext für values von Referenzfeldern ergänzen
                $fieldarray["field.valueplaintext"] = $this->getPlainTextFromOptionlist($in_form_id, $fieldarray);
                
                //Prüfen, ob ein Datumsformat vorliegt. Falls ja, Datum TT.MM.JJJJ nutzen
                if($fieldarray["field.valueplaintext"] == "") {
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> field.value" , $fieldarray["field.value"]);
        
                    if (isDate($fieldarray["field.value"],"d.m.Y") !== false) {
                        $fieldarray["field.valueplaintext"] = isDate($fieldarray["field.value"],"d.m.Y");
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> field.value (überarbeitet)" , $fieldarray["field.valueplaintext"]);
                        
                    }
                }
            } else {
                $fieldarray = array();
            }
            
            $requestDataNew[$key] = $fieldarray; 
        }

        //geänderte Daten wieder zurückschreiben
        $this->setFormPropertyDataFromLastInsert($in_form_id, $requestDataNew);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> übergebene Daten (überarbeitet)" , $requestDataNew);
        
    }
    
    
    
    /**Falls für eine Selectbox ein Value aufgelöst werden kann (plaintext), wird der Plaintext 
     * zurückgegeben. Ansonsten wird ein Leerstring zurückgegeben.
     * 
     * @param   integer $in_form_id     ID des Formulars
     * @param   array   $in_fieldarray  Zweidimensionales Array mit allen Feldern <br />
     *                                  Bsp.: Array
                                                (
                                                    [k_bst_pre.id] => Array
                                                        (
                                                            [field.id] => 9121
                                                            [field.name] => ID
                                                            [field.value] => 203
                                                        )

                                                    [k_bst_pre.bst] => Array
                                                        (
                                                            [field.id] => 6272
                                                            [field.name] => Haushaltskostenstellennummer
                                                            [field.value] => 02601263
                                                        )
     *                                           )
     * @return type
     */
    private function getPlainTextFromOptionlist($in_form_id, $in_fieldarray) {
        //Klartext für values von Referenzfeldern ergänzen
        $feedback = "";
        $my_formsBackup = session_class::$session_object->getFormbackup($in_form_id);
        
        if(isset($in_fieldarray["field.id"])) {
            $field_id = $in_fieldarray["field.id"];
            if(isset($my_formsBackup["optionlists"][$field_id])) {
                $optionlist = $my_formsBackup["optionlists"][$field_id];
                $ref_id = issetKeyLike($optionlist[0], "ref_id");
                $ref_value = issetKeyLike($optionlist[0], "ref_value");
                foreach ($optionlist as $key => $current_option) {
                    if($current_option[$ref_id] == $in_fieldarray["field.value"]) {
                        $feedback = $current_option[$ref_value];
                        break;
                    }
                }
            }
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> field.id in array nicht vorhanden" , $in_fieldarray, "ERROR");
        
        }
        return $feedback;
    }
    
    
    
    

    /** Ermittelt aus _formArray[last_insert} die Mailadressen, welche angeschrieben werden sollen
     * 
     * @param   integer     $in_form_id     ID des Formulars
     * @param   string      $in_app_id      APP_ID des Formulars
     * @return  array                       Array mit den TO-, CC- und From-Adressen array(TO=>array(test@mail.de, test2@mail.de), CC => array(), From => array())
     */
    function getMailTargetsFromLastInsertedData($in_form_id, $in_app_id) {
        $mailAdresslist = array("TO" => array(), "CC" => array(), "From" => array());

        //die zuletzt eingefügten Daten ermitteln
        $requestData = $this->getFormPropertyDataFromLastInsert($in_form_id);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> übergebene Daten" , $requestData);
        
        //Schleife über alle Werte und dabei Felder vom Typ 
        foreach ($requestData as $key => $value) {
            //$key = feld.spalte
            $fieldtype = getFieldTypeBySpalteFromSessionBackup($in_form_id, $in_app_id, $key);
            if ($fieldtype == 636) {
                //Mail-TO:
                $mailAdresslist["TO"] = array_merge($mailAdresslist["TO"], $this->putMailsInListHelper($value));
            } elseif ($fieldtype == 637) {
                //Mail-CC:
                $mailAdresslist["CC"] = array_merge($mailAdresslist["CC"], $this->putMailsInListHelper($value));
            } elseif ($fieldtype == 638) {
                //Mail-From:
                $mailAdresslist["From"][] = $value;
            }
        }

        return $mailAdresslist;
    }
    
    
    
    
    
    /** Wandelt einen String mit einer oder mehreren Mail-Adressen in ein Array um.
     * Die Mail-Adressen müssen per Komma separiert sein. Leerzeichen werden entfernt.
     * 
     * @param   string  $in_mailvalue       eine oder mehrere, kommaseparierte, Mailadressen
     * @return  array
     */
    public function putMailsInListHelper($in_mailvalue) {
        $mailAdresslist = array();
        
        if(strpos($in_mailvalue ?? '', ",") !== false) {
            $in_mailvalue = str_replace(" ", "", $in_mailvalue);
            $temp_list = explode(",", $in_mailvalue);
            foreach($temp_list as $singlevalue) {
                $mailAdresslist[] = $singlevalue;
            }
        } else {
            $mailAdresslist[] = $in_mailvalue;
        }
        
        return $mailAdresslist;
        
    }
    
    
    
    

    /** Ermittelt aus _formArray[last_insert} das Mailsubject
     * 
     * @param   integer     $in_form_id     ID des Formulars
     * @param   string      $in_app_id      APP_ID des Formulars
     * @return  string                      String des Feldes MailSubject
     */
    function getMailSubjectFromLastInsertedData($in_form_id, $in_app_id) {
        $mailSubject = "";

        //die zuletzt eingefügten Daten ermitteln
        $requestData = $this->getFormPropertyDataFromLastInsert($in_form_id);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  InsertData', $requestData);

        //Schleife über alle Werte und dabei Felder vom Typ Subject
        foreach ($requestData as $key => $value) {
            //$key = feld.spalte
            $fieldtype = getFieldTypeBySpalteFromSessionBackup($in_form_id, $in_app_id, $key);
            if ($fieldtype == 639) {
                //Mail-Subject:
                $mailSubject = $value;
            }
        }

        return $mailSubject;
    }

    /** Führt die aus einer Auswahlliste gewählte Auswertung aus.
     * Welche Auswertung ausgeführt werden soll, wird aus internPostarray ermittelt.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  int                         5 = Auswertung erfolgreich ausgeführt, 
     *                                      -5 = Auswertung konnte nicht ausgeführt werden., 
     *                                      -56 = keine Datensätze gewählt
     */
    protected function internFunction_executeQuery() {
        $mySession = session_class::$session_object->getSessionArrayCurTabAndGlobals();

        $feedback = 0;
        $abort = false;
        $datensaetze = false;

        //PostObjekt holen
        $internPostObject = $this->getPostObject();

        //Formulartyp (constructor) ermitteln
        $form_id = $internPostObject->getSenderformId();
        $form_array = $this->getFormArray($form_id);
        $form_constructor = $form_array["form.constructor"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Formulartyp (constructor) von form $form_id: ", $form_constructor);

        //gewählte Auswertung ermitteln
        $query_appAndId = $internPostObject->getQueryIDFromListBox($form_id);

        if ($query_appAndId == false) {

            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "query_id konnte in internPostObject nicht ermittelt werden", "ERROR");
            $feedback = -55;
            $abort = true;
        } else {
            $query_appAndId = explode("__", $query_appAndId);
            $query_app_id = $query_appAndId[0];
            $query_id = $query_appAndId[1];
            $count_query_criteria = getTableDataCount(global_variables::getConnectionIdOfDbSchemaSYS01(), "query_criteria", global_variables::getNameOfDbSchemaSYS01(), "id", "query_to_form_query_id = " . $query_id . " and query_to_form_query_app_id = '" . $query_app_id . "'");
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> query_id: ", $query_id);
        }

        
        //betroffene Datensätze ermitteln
        if ($count_query_criteria > 0) {
            //wenn query_criteria für die aktuelle query existieren, müssen diese Variablen in query_ad_condition ersetzen
            $datensaetze = $this->getMarkedDataFromPostarray();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Datensätze für Auswertung: ", $datensaetze, "INFO");
            if ($datensaetze == array()) {
                $feedback = -56;                                      //kein Datensatz ausgewählt
                $abort = true;
            }
        } else {
            //wenn keine Kriterien zu ersetzen sind
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " query:" . $query_id, "Query enthält keine Kriterien, daher müss keine Datensatz des Formulars ausgewählt werden. Die Query kann ausgefürht werden.", "INFO");
        }



        if ($abort == false) {
            //Wenn zuvor die Abbruchbedingung nicht auf true gesetzt wurde, wird die Auswertung ausgeführt.
            //Auswertung erstellen und Ergebnis darstellen
            $variablesContainerForQuery = array();
            $variablesContainerForQuery[] = array("type" => "FormArray", "data" => $form_array);                               //für den Fall, dass über query_add_condition auf form-Variablen verwiesen wird.
            //$variablesContainerForQuery[] = array("type" => "triggerFieldsCondition", "data" => $triggerFieldsCondition);   //für den Fall, dass die Werteliste des aktuellen Feldes von den Eingaben in einem vorherigen Feld abhängig sind.
            $variablesContainerForQuery[] = array("type" => "SessionData", "data" => $mySession);                            //für den Fall, dass über query_add_condition auf SESSION-Variablen verwiesen wird.

            $myQueryObject = new query();
            $myQueryObject->initialize_1($query_app_id, $query_id, $datensaetze, $variablesContainerForQuery, $form_array);
            $feedback = 5;                                                       //Feedback kann zurzeit dem User nicht präsentiert werden, da Neuladen der Maske unterbunden wird.
            $myQueryObject->showOutputdocument();
            //Achtung: in query->showOutputdocument wird "exit()" aufgerufen, um das Query-Ergebnis zu präsentieren,
            //aber den alten Maskenzustand stehen zu lassen. 
        } else {
            //Maske wieder im alten Zustand laden, aber Feedbacknachricht einblenden
            $this->setDefaultFormProperties();
        }

        //Wenn $abort == false, kommt die Programmausführung nicht bis zu dieser Stelle, da zuvor eine exit()-Anweisung in query->showOutputdocument ausgeführt wird.
        return $feedback;
    }

    /** Führt Auswertung aus, welche mit dem gedrückten Button verbunden ist.
     * Die Auswertung wird über die Buttoneigenschaft (feld.query_id) ermittelt.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" dieser Funktion wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  int                         5 = Auswertung erfolgreich ausgeführt, -5 = Auswertung konnte nicht ausgeführt werden.
     */
    protected function internFunction_executeReferenzQuery() {
        $mySession = session_class::$session_object->getSessionArrayCurTabAndGlobals();
        $datensaetze = array();             //derzeit ist nicht vorgesehen, dass sich die verknüpften Queries auf ausgewählte Datensätze beziehen.

        $feedback = 0;
        $abort = false;
        $my_connection_id = false;

        //PostObjekt holen
        $internPostObject = $this->getPostObject();

        //Formulardaten ermitteln
        $form_id = $internPostObject->getSenderformId();
        $form_array = $this->getFormArray($form_id);

        //Query ermitteln aus Button-Eigenschaften (feld.query_id) ermitteln
        $query_data = $internPostObject->getQueryIDFromButton();
        if ($query_data == false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "query_id konnte über Button nicht ermittelt werden", "ERROR");
            $feedback = -55;
            $abort = true;
        } else {
            $query_app_id = $query_data["query_app_id"];
            $query_id = $query_data["query_id"];
            if ($query_data["query_ref_field_connection_id"] <> "") {
                //Wenn eine fixe Connection_id für die Query hinterlegt wurde, dann wird diese genutzt.
                $my_connection_id = $query_data["query_ref_field_connection_id"];
            }
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> query_id / abweichende connection_id: ", $query_id . " / " . $my_connection_id);
            $count_query_criteria = getTableDataCount(global_variables::getConnectionIdOfDbSchemaSYS01(), "query_criteria", global_variables::getNameOfDbSchemaSYS01(), "id", "query_to_form_query_id = " . $query_id . " and query_to_form_query_app_id = '" . $query_app_id . "'");
        
            
            //betroffene Datensätze ermitteln
            if ($count_query_criteria > 0) {
                //wenn query_criteria für die aktuelle query existieren, müssen diese Variablen in query_ad_condition ersetzen
                $datensaetze = $this->getMarkedDataFromPostarray();
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Datensätze für Auswertung: ", $datensaetze, "INFO");
                if ($datensaetze == array()) {
                    $feedback = -56;                                      //kein Datensatz ausgewählt
                    $abort = true;
                }
            } else {
                //wenn keine Kriterien zu ersetzen sind
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " query:" . $query_id, "Query enthält keine Kriterien, daher müss keine Datensatz des Formulars ausgewählt werden. Die Query kann ausgefürht werden.", "INFO");
            }
        }

        
        



        if ($abort == false) {
            //Wenn zuvor die Abbruchbedingung nicht auf true gesetzt wurde, wird die Auswertung ausgeführt.
            //Auswertung erstellen und Ergebnis darstellen
            $variablesContainerForQuery = array();
            $variablesContainerForQuery[] = array("type" => "FormArray", "data" => $form_array);                               //für den Fall, dass über query_add_condition auf form-Variablen verwiesen wird.
            //$variablesContainerForQuery[] = array("type" => "triggerFieldsCondition", "data" => $triggerFieldsCondition);   //für den Fall, dass die Werteliste des aktuellen Feldes von den Eingaben in einem vorherigen Feld abhängig sind.
            $variablesContainerForQuery[] = array("type" => "SessionData", "data" => $mySession);                            //für den Fall, dass über query_add_condition auf SESSION-Variablen verwiesen wird.

            $myQueryObject = new query();
            $myQueryObject->initialize_1($query_app_id, $query_id, $datensaetze, $variablesContainerForQuery, $form_array, $my_connection_id);
            $feedback = 5;                                                       //Feedback kann zurzeit dem User nicht präsentiert werden, da Neuladen der Maske unterbunden wird.
            if($myQueryObject->clientrelevant_format === true) {$myQueryObject->showOutputdocument();}
        }

        //Maske wieder im alten Zustand laden, aber Feedbacknachricht einblenden  
        $this->setDefaultFormProperties();

        //Wenn $abort == false, kommt die Programmausführung nicht bis zu dieser Stelle, da zuvor eine exit()-Anweisung in query->showOutputdocument ausgeführt wird.
        return $feedback;
    }

    protected function internFunction_executeScript() {
        require_once("../controller/script_class.php");

        
        $feedback = 0;

        //PostObjekt holen
        $internPostObject = $this->getPostObject();

        //Formulardaten ermitteln
        $form_id = $internPostObject->getSenderformId();
        $form_array = $this->getFormArray($form_id);

        //Query ermitteln aus Button-Eigenschaften (feld.query_id) ermitteln
        $script_file = $this->getScriptFromButton();
        if ($script_file == false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Script, welches der Button aufrufen sollte, konnte nicht ermittelt werden. Feld.vorgabewert des Buttons prüfen.", "ERROR");
            $feedback = -103;
        } else {
            $path = global_variables::getPathForAppmsinstall_abs(true) . global_variables::getPathForScripts_rel($form_array["form.app_id"]);
            $myScript = new script($path, $script_file);
            $local_feedback = $myScript->run();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Script return-code: ", $feedback["return_code"]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Script output: ", $feedback["output"]);
        }


        //Maske wieder im alten Zustand laden, aber Feedbacknachricht einblenden  
        $this->setDefaultFormProperties();

        //Wenn $abort == false, kommt die Programmausführung nicht bis zu dieser Stelle, da zuvor eine exit()-Anweisung in query->showOutputdocument ausgeführt wird.
        return $feedback;
    }
    
    
    
    
    /**Ruft die Funktion internFunction_getLogdataQuery mit dem 885 (Query-ID) auf.
     * 
     */
    protected function internFunction_getLogdataQuery885() {
        $this->internFunction_getLogdataQuery(885);
        
    }
    
    
    
    
    /** Führt die Query 92 (Änderungsprotokoll) aus.
     * Über den Eingangsparameter $in_query_id kann auch ein anderes Änderungsprotokoll aufgerufen werden (bspw. 885).
     * 
     * Dabei werden die aktuellen Daten als einschränkende Parameter genutzt.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     * 
     * @param   integer     $in_query_id    [optional] Query_id, welche gestartet werden soll. Default = 92
     * @return  int                         5 = Auswertung erfolgreich ausgeführt, -56 = Auswertung konnte nicht ausgeführt werden, da kein Datensatz gewählt wurde.
     */
    protected function internFunction_getLogdataQuery($in_query_id = 92) {
        $mySession = session_class::$session_object->getSessionArrayCurTabAndGlobals();

        $feedback = 0;
        $abort = false;

        //PostObjekt holen
        $internPostObject = $this->getPostObject();

        //Formulartyp (constructor) ermitteln
        $form_id = $internPostObject->getSenderformId();
        $form_array = $this->getFormArray($form_id);
        $form_constructor = $form_array["form.constructor"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Formulartyp (constructor) von form $form_id: ", $form_constructor);

        //gewählte Auswertung ermitteln
        $query_app_id = "SYS01";
        $query_id = $in_query_id;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> query_id: ", $query_id);

        //Logdata_id_column den aktuellen Value des Formulars ermitteln
        $id_column = $form_array["form.log_id_spalte"];
        if(strpos($id_column,".") === false){
            //Wenn in id_column keine Table angegeben wurde, dann wird angenommen, dass sich id_column in der Basisdtabelle des Formulars befindet.
            $id_column = $form_array["form.db_table"].".".$id_column;
        }
        

        //betroffene Datensätze ermitteln
        if ($form_constructor == "SingleData") {
            //wenn formtype = Singledata, dann changeddata & markedData prüfen
            $datensaetze = $this->getChangedDataFromPostarray();
            if ($datensaetze == array()) {
                $datensaetze = $this->getMarkedDataFromPostarray();
            }
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Datensätze für Auswertung; query_id = " . $query_id, $datensaetze, "INFO");
        } elseif ($form_constructor == "TableData" OR
                $form_constructor == "RectanglesForTable" OR
                $form_constructor == "RectanglesForTable2" OR
                $form_constructor == "getFormTableForQuery" OR
                $form_constructor == "explorerQuery" OR
                $form_constructor == "exploerTable" OR
                $form_constructor == "RectanglesForQuery") {
            //wenn formtype = Tabledata, dann markedData
            $datensaetze = $this->getMarkedDataFromPostarray();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Datensätze für Auswertung; query_id = " . $query_id, $datensaetze, "INFO");
            if ($datensaetze == array()) {
                $feedback = -56;                                      //kein Datensatz ausgewählt
                $abort = true;
            }
        } else {
            //wenn formtype = unbekannt, dann Fehlermeldung in debug
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> für diesen Formulartyp (constructor) ist noch keine Routine vorgesehen ", "keine Daten für Query ermittelt.", "ERROR");
        }




        if ($abort == false) {
            //Wenn zuvor die Abbruchbedingung nicht auf true gesetzt wurde, wird die Auswertung ausgeführt.
            //ToDo: hier Schleife einbauen, wenn alle markierten Datensätze verarbeitet werden sollen.
            //Value für ID-Column aus dem ersten Datensatz ermitteln und im Form_array ablegen
            $temp = array();
            foreach ($datensaetze as $key => $current_datensatz) {
                $temp[] = "'" . $current_datensatz["content"][$id_column] . "'";
            }
            $form_array["form.log_id_spalte.value"] = implode(",", $temp);

            //Auswertung erstellen und Ergebnis darstellen
            $variablesContainerForQuery = array();
            $variablesContainerForQuery[] = array("type" => "FormArray", "data" => $form_array);                               //für den Fall, dass über query_add_condition auf form-Variablen verwiesen wird.
            //$variablesContainerForQuery[] = array("type" => "triggerFieldsCondition", "data" => $triggerFieldsCondition);   //für den Fall, dass die Werteliste des aktuellen Feldes von den Eingaben in einem vorherigen Feld abhängig sind.
            $variablesContainerForQuery[] = array("type" => "SessionData", "data" => $mySession);                            //für den Fall, dass über query_add_condition auf SESSION-Variablen verwiesen wird.

            $myQueryObject = new query();
            $myQueryObject->initialize_1($query_app_id, $query_id, $datensaetze, $variablesContainerForQuery, $form_array);
            $feedback = 5;                                                       //Feedback kann zurzeit dem User nicht präsentiert werden, da Neuladen der Maske unterbunden wird.
            $myQueryObject->showOutputdocument();
            //Achtung: in query->showOutputdocument wird "exit()" aufgerufen, um das Query-Ergebnis zu präsentieren,
            //aber den alten Maskenzustand stehen zu lassen. 
        } else {
            //Maske wieder im alten Zustand laden, aber Feedbacknachricht einblenden
            $this->setDefaultFormProperties();
        }

        //Wenn $abort == false, kommt die Programmausführung nicht bis zu dieser Stelle, da zuvor eine exit()-Anweisung in query->showOutputdocument ausgeführt wird.
        return $feedback;
    }

    /** Erstellt eine Backup-Datei
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  int                         6 = Backup erstellt, -65 = Backup konnte nicht erstellt werden, da sendendes Formular nicht erkannt wurde
     */
    protected function internFunction_createBackup() {
        //PostObjekt holen
        $internPostObject = $this->getPostObject();

        //Formulardaten des sendenden Formulars ermitteln
        $form_id = $internPostObject->getSenderformId();
        $form = $internPostObject->getFormContent($form_id);                    //Daten ermitteln, die POST_ARRAY übermittelt wurden
        $form_metadata = $this->getFormArray($form_id);                         //Meta- und Konfigurationsdaten eines Formulars ermitteln
        $instance_id = $this->getPostObject()->getSenderInstanceId();
        //"new"-Kürzel von instanz abschneiden
        $instance_id = substr($instance_id, 0, strlen($instance_id) - 3);

        //Backup-Auftrag auslesen
        if ($form_id == false) {
            //sendendes Formular konnte nicht erkannt werden
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> kein Backup erstellt", "Backup konnte nicht erstellt waren, da sendendes Formular nicht ermittelt werden konnte.", "ERROR");
            $feedback = -65;
        } else {
            //Backup-Auftrag ermitteln
            $safe_path = global_variables::getPathForBackups_rel($form["content"]["backup.app_id"]);
            $myBackupObject = new backup($form["content"]["backup.app_id"], $form["content"]["backup.contenttype"], $form["content"]["backup.description"], $form["content"]["backup.sql_language"], $form_metadata, $safe_path, true, $this, true);
            $this->calculateFormCountData($form_id, $instance_id, $this->getFormPropertyOffset($form_id, $instance_id), false);
            $feedback = 6;
        }


        $this->setDefaultFormProperties();
        //Wenn Backup erstellt wurde, dann Formularmodus für den Fall, dass das Formular vorher leer war, auf default umstellen. Andernfalls wird das erste Backup nicht angezeigt, da Formular im Modus empty verbleibt.
        if ($feedback == 6) {
            $this->setFormMode($form_id, $instance_id, 1);
        }


        return $feedback;
    }

    /**
     * Liest eine Datei im base64-Format aus der DB aus, decodiert diese und sendet sie an den Client.
     * Dabei wird der Header mit dem korrekten mimetype versehen, sodass der Client erkennen kann,
     * welche Anwendung die Datei öffnen kann.
     * 
     * Voraussetzung ist, dass die Datei in einer Tabelle gespeichert ist,
     * welche mindestens folgende Merkmale/Spalten enthält: <br />
     * - id -> eindeutiger Identifier der Datei in der DB-Tabelle<br />
     * - filetype -> mimetyp der Datei <br />
     * - filename -> Name der Datei inkl. Dateiendung <br />
     * - file  -> Datei im base64-Format <br />
     * 
     * 
     * @return int
     */
    protected function internFunction_showBase64File() {

        //PostObjekt holen
        $internPostObject = $this->getPostObject();
        $form_id = $internPostObject->getSenderformId();
        $app_id = $this->getFormPropertyAppId($form_id);
        $senderDS = $internPostObject->getDSwhereButtonUsed();

        if ($senderDS != false) {
            //Daten des gesuchten Files aus der Tabelle des Sender-Formulars ermitteln
            $id_column = issetKeyLike($senderDS["content"], ".id");
            $condition = "id=" . $senderDS["content"][$id_column];
            $myFile = getTableData($app_id, $senderDS["table"], $senderDS["schema"], 0, "", $condition, __FUNCTION__);

            if ($myFile != array()) {
                $data = base64_decode($myFile[0][$senderDS["table"] . ".file"]);                
                $file_format = $myFile[0][$senderDS["table"] . ".filetype"]; 
                $filename = $myFile[0][$senderDS["table"].".filename"];
                $this->sendFileToClient($file_format, $filename, $data);
            }
//        //Nach dem Dateidownload abbrechen, damit alte Webseite stehen bleibt.
            exit();
        }

        //Dieser Abschnitt wird nur erreicht, wenn die Datei nicht gefunden wurde.
        $feedback = -4;    //->kein Datensatz gewählt


        return $feedback;
    }
    
    
    
    
    /** sendet Daten als Datei, mit Hilfe der header-Methode zum Client.
     * ACHTUNG: Bei Änderungen beachte auch die Methode query_class->showOutputdocument
     * 
     * @param   string  $in_file_format     Format der Datei; Bsp.:  image/png
     * @param   string  $in_filename        Name, mit der die Datei übertragen werden soll. Bsp.: logo.png
     * @param   string  $in_data            gesamter Inhalt der Datei als Referenz
     */
    private function sendFileToClient($in_file_format, $in_filename, &$in_data) {
        //                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> File: ", $in_file, "INFO");

        header('Content-Type: '.$in_file_format.';charset=utf-8');
        header('Content-Disposition: attachment; filename="'.$in_filename.'"');
        header('Content-Description: File Transfer');

        //vorhandene Zeichen im Header löschen -> wichtig, da sonst einige Fileformate nicht funktionieren
        ob_clean();
        flush();
        
        
        $filename_parts = explode(".",$in_filename);
        $file_extension = $filename_parts[1];
        
        if(in_array($file_extension, global_variables::getMsOfficeFiletypes())) {
            //Die Office-Programme erwarten ISO-8859
            //print utf8_decode($in_data);
            print mb_convert_encoding($in_data, 'UTF-8', mb_list_encodings());
        } else {
            //utf8 wird über das meta-tag im Dokument eingestellt
            print $in_data;
        }
    }
    
    

    
    
    
    
    
    /**
     * Setzt den Offset-Parameter in formArray in Abhängigkeit vom limit-Parameter vorwärts. Falls ein neuer Limit-Parameter
     * übergeben wurde, wird dieser auch gesetzt.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     */
    protected function internFunction_offsetForward() {
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Button geklickt", "Offset-Forward gestartet", "INFO");

        //PostObjekt holen
        $internPostObject = $this->getPostObject();

        //Formulardaten des sendenden Formulars ermitteln
        $form_id = $internPostObject->getSenderformId();
        $instance_id = $internPostObject->getSenderInstanceId();
        
        //limit ermitteln
        $limit = $this->getNavLimit($internPostObject,$form_id);

        //alte Conditions aud SESSION-form_backup in alle Formulare, außer dem sendenden Formular übertragen
        $this->setDefaultFormProperties();

        //new offset-Value auf Basis der Daten des Formulars beim letzten Aufruf errechnen
        $LastDs_before_clickForward = $this->takeOldValueFromForm($form_id, $instance_id, "form.current_last_ds");
        
        $newOffset = $LastDs_before_clickForward;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Offset: ', $newOffset, "INFO");

        $countData = $this->calculateFormCountData($form_id, $instance_id, $newOffset, true);

        //$newOffset wird auf den alten Wert gesetzt, falls größer als countData sein sollte
        if ($newOffset >= $countData) {
            $newOffset = $this->takeOldValueFromForm($form_id, $instance_id, "form.offset");
            $countData = $this->calculateFormCountData($form_id, $instance_id, $newOffset, true);
        }
    }
    
    
    
    
    /**
     * Setzt den Offset-Parameter in formArray in Abhängigkeit vom limit-Parameter vorwärts. Falls ein neuer Limit-Parameter
     * übergeben wurde, wird dieser auch gesetzt.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     */
    protected function internFunction_offsetUpdate() {
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Button geklickt", "Offset-Update gestartet", "INFO");

        //PostObjekt holen
        $internPostObject = $this->getPostObject();

        //Formulardaten des sendenden Formulars ermitteln
        $form_id = $internPostObject->getSenderformId();
        $instance_id = $internPostObject->getSenderInstanceId();
        
        //limit und offset ermitteln und einstellen
        $limit = $this->getNavLimit($internPostObject, $form_id);
        $offset = $this->getNavOffset($internPostObject, $form_id, $instance_id);
        
        //alte Conditions aud SESSION-form_backup in alle Formulare, außer dem sendenden Formular übertragen
        $this->setDefaultFormProperties();

        //$new_offset wird auf 0 gesetzt, falls es sich nicht um eine positive Ganzzahl handelt
        if (filter_var($offset, FILTER_VALIDATE_INT) == false OR $offset < 0) {
            $offset = 0;
        }

        $countData = $this->calculateFormCountData($form_id, $instance_id, $offset, true);
    }
    
    
    
    

    /** Berechnet und setzt die Werte für "form.current_first_ds" und "form.current_last_ds" und
     * setzt zudem die Eigenschaft "form.offset"
     * 
     * @param integer $in_formID
     * @param string  $in_instance_id  
     * @param integer $in_offset            
     * @param integer $in_limit
     * @param integer $in_countData
     */
    private function setCurrentDSValuesInForm($in_formID, $in_instance_id, $in_offset, $in_limit, $in_countData) {

        $countData = $in_countData;
        $this->setFormProperty($in_formID, $in_instance_id, "form.offset", $in_offset);

        //current_first_ds - gibt den offset-Wert für den ersten Datensatz, der aktuell angezeigt wird.
        $current_first_ds = $in_offset + 1;
        if ($current_first_ds < 0) {
            $current_first_ds = 0;
        }
        $this->setFormProperty($in_formID, $in_instance_id, "form.current_first_ds", $current_first_ds);

        //current_last_ds - gibt den offset-Wert für den letzten Datensatz, der aktuell angezeigt wird.
        $current_last_ds = $in_offset + $in_limit;
        if ($current_last_ds > $countData) {
            $current_last_ds = $countData;
        }
        $this->setFormProperty($in_formID, $in_instance_id, "form.current_last_ds", $current_last_ds);
    }

    /** Ermittelt einen beliebigeb Wert aus Tab-SESSION[forms_backup] einer Instanz eines  Formulars
     * 
     * @param   integer $in_form_id         ID des Formulars
     * @param   string  $in_instance_id     ID der Instanz des Formulars
     * @param   string  $in_keyname         key innerhalb eines form_arrays
     * @return  mixed                       Rückgabewert entspricht entweder dem valus, passend zum key, oder es wird false zurückgegeben
     */
    protected function takeOldValueFromForm($in_form_id, $in_instance_id, $in_keyname) {
        
        $my_formBackup = $this->getFormArrayFromSessionBackup($in_form_id);

        if ($my_formBackup !== false) {
            //Wenn das gesuchte Formular im Backup vorhanden ist
            if (isset($my_formBackup["form.instances"][$in_instance_id][$in_keyname])) {
                //Wenn  key  vorhanden sind
                return $my_formBackup["form.instances"][$in_instance_id][$in_keyname];
            }
        }
        

        //Wenn eine Bedingung nicht erfüllt wurde, dann false
        return false;
    }

    /** Ermittelt einen beliebigeb Wert aus Tab-SESSION[forms_backup] eines  Formulars. Der Wert gehört jedoch nicht zu den Eigenschaften einer Instanz, sondern zu den allgemeinen Daten des Formulars
     * 
     * @param   integer $in_form_id         ID des Formulars
     * @param   string  $in_keyname         key innerhalb eines form_arrays
     * @return  mixed                       Rückgabewert entspricht entweder dem valus, passend zum key, oder es wird false zurückgegeben
     */
    protected function takeOldValueFromForm2($in_form_id, $in_keyname) {
        $my_formBackup = $this->getFormArrayFromSessionBackup($in_form_id);
        
        if ($my_formBackup !== false) {
            //Wenn das gesuchte Formular im Backup vorhanden ist
            if (isset($my_formBackup[$in_keyname])) {
                //Wenn  key  vorhanden sind
                return $my_formBackup[$in_keyname];
            }
        }

        //Wenn eine Bedingung nicht erfüllt wurde, dann false
        return false;
    }

    /**
     * Setzt den Offset-Parameter in formArray in Abhängigkeit vom limit-Parameter rückwärts
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     * 
     * Todo: Rückgabewert einbauen
     */
    protected function internFunction_offsetBackward() {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Button geklickt", "Offset-Backward gestartet", "INFO");

        //PostObjekt holen
        $internPostObject = $this->getPostObject();

        //Formulardaten des sendenden Formulars ermitteln
        $form_id = $internPostObject->getSenderformId();
        $instance_id = $internPostObject->getSenderInstanceId();
        
        //limit ermitteln
        $limit = $this->getNavLimit($internPostObject, $form_id);
        
        //alte Conditions aud SESSION-form_backup in alle Formulare, außer dem sendenden Formular übertragen
        $this->setDefaultFormProperties();

        //new offset-Value auf Basis der Daten des Formulars beim letzten Aufruf errechnen
        $FirstDs_before_clickBackward = $this->takeOldValueFromForm($form_id, $instance_id, "form.current_first_ds");
        //$limit = $this->getFormPropertyLimit($form_id);
        $newOffset = $FirstDs_before_clickBackward - $limit - 1;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Offset: ', $newOffset, "INFO");

        //$new_offset wird auf 0 gesetzt, falls es sich nicht um eine positive Ganzzahl handelt
        if (filter_var($newOffset, FILTER_VALIDATE_INT) == false OR $newOffset < 0) {
            $newOffset = 0;
        }

        $countData = $this->calculateFormCountData($form_id, $instance_id, $newOffset, true);
    }
    
    
    
    
    /** Ermittelt und setzt den aktuellen Limit-Wert in folgender Reihenfolge
     * a) aus Navigationsleiste
     * b) aus Formular (default) über getFormPropertyLimit
     * c) aus Konfigurationsparameter über getFormPropertyLimit
     * 
     * @param   object  $in_PostObject
     * @param   string  $in_form_id     ID des akteullen Formulares
     * @return  integer
     */
    private function getNavLimit($in_PostObject, $in_form_id) {
        $POST_Array_controldata = $in_PostObject->getInternPostArray()["controlData"];
        
        //mögliche limit-Fields aus Nav-Leisten ermitteln
        $limit_Fields = getConfig("nav_limit_fields", global_variables::getAppIdFromSYS01());
        $limit_Fields = str_replace("0", "o", $limit_Fields);
        $limit_fields_array = explode(",", str_replace(" ", "", $limit_Fields));
        foreach ($limit_fields_array as $cur_field_id) {
            $limit_key = issetKeyLike($POST_Array_controldata, "000".$cur_field_id."0Form");   
            if($limit_key !== false) {break;}
        }
        
        if($limit_key !== false) {
            $my_limit = $POST_Array_controldata[$limit_key];   
        } else {
            $my_limit = "not set";
        }
            
        if(is_numeric($my_limit)) {
            $limit = $my_limit;
            $this->setFormPropertyLimit($in_form_id, $limit);
        } else  {
            $limit = $this->getFormPropertyLimit($in_form_id);
        }
        return $limit;
    }
    
    
    
    /** Ermittelt und setzt den aktuellen Offset-Wert aus der Navigationsleiste
     * 
     * @param   object  $in_PostObject
     * @param   string  $in_form_id     ID des akteullen Formulares
     * @return  integer
     */
    private function getNavOffset($in_PostObject, $in_form_id, $in_instance_id) {
        $POST_Array_controldata = $in_PostObject->getInternPostArray()["controlData"];
        
        //mögliche offset-Fields aus Nav-Leisten ermitteln
        $offset_Fields = getConfig("nav_offset_fields", global_variables::getAppIdFromSYS01());
        $offset_Fields = str_replace("0", "o", $offset_Fields);
        $offset_fields_array = explode(",", str_replace(" ", "", $offset_Fields));
        foreach ($offset_fields_array as $cur_field_id) {
            $offset_key = issetKeyLike($POST_Array_controldata, "000".$cur_field_id."0Form");   
            if($offset_key !== false) {break;}
        }
        
        if($offset_key !== false) {
            $my_offset = $POST_Array_controldata[$offset_key];   
        } else {
            $my_offset = "not set";
        }
            
        if(is_numeric($my_offset)) {
            $offset = $my_offset;
            $this->setFormProperty($in_form_id, $in_instance_id, "form.current_first_ds", $offset);
        } else  {
            $offset = $this->getFormPropertyCurrentFirstDS($in_form_id, $in_instance_id);
        }
        return $offset -1;
    }
    
    
    

    /** Bereitet das Formular für die Erfassung eines neuen Datensatzes vor
     * 
     * @param   integer     $in_form_id                     ID des Formulars, welches vorbereitet werden soll
     * @param   string      $in_instance_id                 ID der Instanz, welche vorbereitet werden soll
     * @param   array       $in_defaultValuesForInsert      Liste der Defaultwerte, die beim insert pro Feld genutzt werden sollen;<br /> 
     *                                                      Bsp.: array("bew_id" => 123) -> Wenn ain dem Formular das Feld bew_id existiert, <br />
     *                                                      wird dieses mit dem value "123" vorbelegt.
     * @return int      9 = success, -9 = fail
     */
    function prepareFormForNewRow($in_form_id, $in_instance_id, $in_defaultValuesForInsert) {


        //DefaultValues in form_array hinterlegen
        $this->setFormPropertyDefaultValueForInsert($in_form_id, $in_instance_id, $in_defaultValuesForInsert);

        //Instanz, welche zur Erfassung des neuen Datensatzes gedacht ist, wird auf modus = 2 (insert) gesetzt.
        $this->setFormMode($in_form_id, $in_instance_id, 2);

        return 9;
    }

    /** Löscht die Dateien und die dazugehörigen Einträge in der jeweiligen DB-Tabelle (Bspw.: backup und files).
     * Die Funktion kann generisch für weitere Tabellen genutzt werden. Voraussetzung ist, dass die Tabellen und die zugehörigen
     * Formulare die Spalten app_id, id, filename und pathname enthalten. Die jeweilige Tabelle muss sich über form.table ermitteln lassen.
     * 
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @param   array       $in_toDeleteDataset     Array des zu löschenden Datensatzes. Bspw. postobject->markeddata
     * @return  integer                             User-Function-Feedback-Codes entsprechend den Konstanten der konstantentyp_id 35.
     */
    protected function internFunction_deleteFile($in_toDeleteDataset = false) {
        
        if ($in_toDeleteDataset == false) {
            $deleteDatensaetze = $this->getToDeleteDataset();
        } else {
            $deleteDatensaetze = $in_toDeleteDataset;
        }
        //PostObjekt holen
        $internPostObject = $this->getPostObject();
        $currentUser = $this->getCurrentUserFromSession();

        //Formulardaten des sendenden Formulars ermitteln
        $form_id = $internPostObject->getSenderformId();
        $form_app_id = $this->getFormPropertyAppId($form_id);
        if($form_app_id == false) {$form_app_id = "";}
        $instance_id = $this->getPostObject()->getSenderInstanceId();

        if ($deleteDatensaetze == false) {
            //es wurde kein Datensatz zum löschen markiert.
            $result = -35;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> zu löschende Datensätze: ', "Es wurde kein Datensatz zum Löschen markiert.", "ERROR");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> zu löschende Datensätze: ', $deleteDatensaetze);
            $countErrors = 0;
            foreach ($deleteDatensaetze as $key => $cur_ds) {
                //notwendige Daten ermitteln, falls diese nicht vorhanden sind (pathname, filename)
                if(!isset($cur_ds["content"][issetKeyLike($cur_ds["content"], "filename")]) or 
                   !isset($cur_ds["content"][issetKeyLike($cur_ds["content"], "pathname")])) {
                    //Wenn ein notwendiges Merkmal fehlt, dann dieses aus der DB auslesen
                    $connection_id = getAppIdFromSchema($cur_ds["schema"], $form_app_id);
                    $in_bedingung = "id = ".$cur_ds["content"][$cur_ds["table"].".id"];
                    $necessary_data = getTableData($connection_id, $cur_ds["table"], $cur_ds["schema"], false, "", $in_bedingung, __FUNCTION__);
                    $cur_ds["content"]["pathname"] = $necessary_data[0][issetKeyLike($necessary_data[0], "pathname")];
                    $cur_ds["content"]["filename"] = $necessary_data[0][issetKeyLike($necessary_data[0], "filename")];
                    //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ergänzter Datensatz: ', $cur_ds);
            
                }
                //Datensätze aus der Tabelle des sendenden Formulars löschen
                $feedback_for_delete = $this->deleteTabledataOneRow($cur_ds, $currentUser);
                if ($feedback_for_delete > 0) {
                    //Datei aus dem Filesystem löschen
                    $path = global_variables::getPathForAppmsinstall_abs(false) . $cur_ds["content"][issetKeyLike($cur_ds["content"], "pathname")];
                    $file = $cur_ds["content"][issetKeyLike($cur_ds["content"], "filename")];
                    if (file_exists($path . $file)) {
                        $feedback_fileDelete = unlink($path . $file);
                    } else {
                        $feedback_fileDelete = false;
                    }
                    if ($feedback_fileDelete == true) {
                        //Datensatz und Datei wurden gelöscht.
                        $result = 7;
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Datei wurde gelöscht", "Datei im Filesystem und Tabelle " . $cur_ds["table"] . " gelöscht", "INFO");
                    } else {
                        //Datensatz wurde gelöscht, aber die zugehörige Datei war nicht mehr vorhanden. Da das Ziel des Users erreicht wurde, wird auch dieses Ereignis als Erfolg gewertet
                        $result = 76;
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Datei konnte nicht gelöscht werden", "Datensatz in Tabelle " . $cur_ds["table"] . " wurde gelöscht, aber die zugehörige Datei im Dateisystem wurde nicht gefunden.", "INFO");
                    }
                } else {
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Datei konnte nicht gelöscht werden", "Der Datensatz aus der DB-Tabelle konnte nicht gelöscht werden.", "ERROR");
                    $result = -75;
                    $countErrors = $countErrors + 1;
                }
            }
            //countErrors wird benötigt, da mehr als ein Datensatz markiert sein kann. Pro Datensatz kann der Erfolg unterschiedlich sein. 
            //Dem Nutzer wird lediglich angezeigt, dass ein Fehler auftrat. In der Debug-Tabelle wird vermerkt bei welchem Datensatz der Fehler auftrat.
            if ($countErrors > 0) {
                $result = -7;
            }
            $this->calculateFormCountData($form_id, $instance_id, $this->getFormPropertyOffset($form_id, $instance_id), false);
        }

        $this->setDefaultFormProperties();

        return $result;
    }
    
    
    
    
    
    
    
    

    /** Ermittelt die zu löschenden Datensätze und ruft dann die Funktion deleteTabledate auf. Das funktioniert auch für Singledata 
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  integer                         Return-Code, der den Erfolg mitteilt (-3|-31|-35|3) -> siehe Konstantentyp 35
     */
    function internFunction_deleteDataset() {
        $deleteDatensaetze = $this->getToDeleteDataset();
        $form_id = $deleteDatensaetze[0]["form"];
        $internPostObject = $this->getPostObject();
        $instance_id = $internPostObject->getSenderInstanceId();

        if ($deleteDatensaetze == false) {
            $feedback_for_delete = -35;
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> zu löschende Datensätze: ', $deleteDatensaetze);
            $feedback_for_delete = $this->deleteTabledata($deleteDatensaetze, $this->getActiveUser());
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Delete->feedback_for_delete: ', $feedback_for_delete);
        }

        $countData = $this->calculateFormCountData($form_id, $instance_id, $this->getFormPropertyOffset($form_id, $instance_id), false);
        $this->setDefaultFormProperties();

        return $feedback_for_delete;
    }
    
    
    
    
    

    /** Ermittelt ein Array, in dem die zu löschenden Datensätze enthalten sind.
     * 
     * @return  mixed         false, wenn kein markierter Datensatz gefunden wurde oder Array, welches die zu löschenden Datensätze enthält. 
     */
    public function getToDeleteDataset() {
        //PostObjekt holen
        $internPostObject = $this->getPostObject();
        $senderform_id = $internPostObject->getSenderformId();
        $senderform_constructor = $this->getFormPropertyConstructor($senderform_id);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Senderform: ', "ID: " . $senderform_id . ", constructor: " . $senderform_constructor);
        if (strpos($senderform_constructor, "Table") !== false) {
            $deleteDatensaetze = $internPostObject->getMarkedData();
            if (count($deleteDatensaetze) == 0) {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Delete->Abbruch: ', "Es konnte kein markierter Datensatz ermittelt werden.");
                return false;
            }
        } elseif (strpos($senderform_constructor, "Single") !== false) {
            //$deleteDatensaetze = $this->getPostObject()->getChangedData();
            $deleteDatensaetze = $internPostObject->getMarkedData();
        }


//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> zu löschende Datensätze: ', $deleteDatensaetze);
        return $deleteDatensaetze;
    }

    /** Löscht alle Daten eines übergebenen Dataset. Wird auch für Singledata genutzt!
     * 
     * @param Array     $in_datensaetze             Zweidimensionales Array, welches eine Liste von Datensätzen enthält. Es sollten nur die Sein, in denen Änderungen auftreten.
     * @param String    $in_current_account_id      Name des aktuellen Benutzers/Accounts
     * @return   integer                         siehe Konstantentyp_id = 35; alle Feedbackmeldungen des 3er-Bereichs 
     *                                           3   => erfolgreich gelöscht
     *                                          -3  => nicht gelöscht (SQL-Fehler)
     *                                          -31 => Zugriffsrecht für aktive Rolle und aktuelle Maske nicht gegeben.
     *                                          ...     
     */
    function deleteTabledata(&$in_datensaetze, $in_current_account_id) {
        $feedback = false;                                                                   //Default-Wert, für den Fall, dass der User auf Löschen klickt, obwohl es keine Änderungen gibt.
        //    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Zu löschende Datensätze: ', $in_datensaetze);
        //    echo "zu löschende Datensätze: <br />".print_r($in_datensaetze);

        foreach ($in_datensaetze as $key => $datensatz) {
            $formArray = $this->getFormArray($datensatz["form"]);
            $sql_basis_daten = extractDataFromPostarray($datensatz["content"], $formArray, $datensatz["instance_id"], $datensatz["ds"], $this);

            if ($sql_basis_daten["table"] == "mask") {
                //Löschroutine für die Tabelle mask; Voraussetzung: Datensatz müssen app_id und id enthalten sein.
                require_once("../controller/mask_class.php");
                $my_mask = new mask($this, $datensatz["content"]["mask.app_id"], $datensatz["content"]["mask.id"]);
                $feedback = $my_mask->deleteMask($datensatz["content"]["mask.name"]);
            } elseif ($sql_basis_daten["table"] == "form") {
                //Löschroutine für die Tabelle form; Voraussetzung: Datensatz müssen app_id und id enthalten sein.
                require_once("../controller/form_class.php");
                $my_form = new form($this, $datensatz["content"]["form.app_id"], $datensatz["content"]["form.id"]);
                $feedback = $my_form->deleteForm();
            } else {
                //Standardlöschroutine
                $feedback = deleteData($sql_basis_daten, $formArray, $in_current_account_id, $this);
            }
        }


        return $feedback;
    }

    /** WIe deleteTabledata, jedoch wird nur genau ein Datensatz erwartet.
     * 
     * @param Array     $in_datensatz             Zweidimensionales Array, welches eine Liste von Datensätzen enthält. Es sollten nur die Sein, in denen Änderungen auftreten.
     * @param String    $in_current_account_id    Name des aktuellen Benutzers/Accounts
     * @return  integer                           Return-Code, der den Erfolg mitteilt (-3|-31|-35|3) -> siehe Konstantentyp 35
     */
    function deleteTabledataOneRow(&$in_datensatz, $in_current_account_id) {

        $formArray = $this->getFormArray($in_datensatz["form"]);
        $sql_basis_daten = extractDataFromPostarray($in_datensatz["content"], $formArray, $in_datensatz["instance_id"], $in_datensatz["ds"], $this);
        $feedback = deleteData($sql_basis_daten, $formArray, $in_current_account_id, $this);

        return $feedback;
    }

    /** Ändert den Formularmodus des Target-Formulars (Senderform) auf den Default-Modus. 
     * D.h. die Bearbeitung wird aktiviert. Die Formularmodi aller anderen Formulare bleiben unverändert.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  Integer                             120 -> Bearbeiten-Modus aktiviert
     */
    function internFunction_setFormModeToDefault() {
        $this->setFormModeForSenderform(1, false);
        return 120;
    }

    /** Ändert den Formularmodus des Target-Formulars (Senderform) auf den Only_read-Modus. 
     * D.h. die Bearbeitung wird deaktiviert. Die Formularmodi aller anderen Formulare bleiben unverändert.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  Integer                             125 -> Bearbeiten-Modus deaktiviert
     */
    function internFunction_setFormModeToOnlyread() {
        $this->setFormModeForSenderform(7, false);
        return 125;
    }
    
    
    
    /** Ändert den Formularmodus des Target-Formulars (Senderform) auf den insert-Modus. 
     * D.h. die Neuanlage eines Datensatzes wird ermöglicht. Die Formularmodi aller anderen Formulare bleiben unverändert.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  Integer                             121 -> erfolgreich den Form_Modus gewechselt
     */
    function internFunction_setFormModeToInsert() {
        $this->setFormModeForSenderform(2, false);
        return 121;
    }
    
    
    
    /** Ändert den Formularmodus des Target-Formulars (Senderform) auf den filter-Modus. 
     * D.h. die Suche eines Datensatzes wird ermöglicht. Die Formularmodi aller anderen Formulare bleiben unverändert.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  Integer                             121 -> erfolgreich den Form_Modus gewechselt
     */
    function internFunction_setFormModeToFilter() {
        $this->setFormModeForSenderform(3, true);
        
        return 123;
    }
    
    
    
    
    /** Ändert den Formularmodus des sendenden Formulars auf den gewünschten Modus.
     * 
     * @param   integer     $in_target_mode         Siehe Tabelle form_mode
     * @param   boolean     $in_set_form_mode_fix   Wenn true, wird der Parameter $pagedata->form_list_with_fix_mode um die aktuelle form_id ergänzt
     * @return  boolean
     */
    private function setFormModeForSenderform($in_target_mode, $in_set_form_mode_fix) {
        //PostObjekt holen
        $internPostObject = $this->getPostObject();
        //Formulardaten des sendenden Formulars ermitteln
        $senderform_id = $internPostObject->getSenderformId();
        $senderInstance_id = $this->getPostObject()->getSenderInstanceId();

        //In alle Formulare die alten Werte übernehmen -> Bei Form_mode 3 und 8 (Filter), sollen die Werte nicht in das sendende und die abhängigen Formular übernommen werden
        if(in_array($in_target_mode, array(3,8)) == true) {
            $depending_forms = $this->getDependedForms($senderform_id);
            $except_form_list = array_keys($depending_forms + array($senderform_id=>$senderform_id));
        } else {
            $except_form_list = array();
        }
        $this->setDefaultFormProperties($except_form_list);
        
        //FormMode für SenderForm auf targetmode setzen
        $this->setFormMode($senderform_id, $senderInstance_id, $in_target_mode);
        
        //Kennzeichnen, das mode durch spätere Methoden, bspw. setFormModeForGivingFormList nicht wieder überschrieben werden soll
        if($in_set_form_mode_fix === true) {
            $this->form_list_with_fix_mode[] = $senderform_id;
        }
        
        
        return true;
        
        
    }
    
    

    /** Die Funktion ermittelt die Daten, welche zuletzt mit dem aktiven Formular (Antrag/Request) eingefügt wurden
     * und schreibt diese mit Hilfe der query_class in ein Dokument.
     * 
     * @return  integer                     	Beispiel für Reaktionen: 2 = erfolgreich ; -2 = fehlgeschlagen
     */
    public function internFunction_writeRequestdataToDocument() {
        $feedback = 0;
        
        //lesender Zugriff auf Session-Daten
        if($this->getWorkflowFromSessionbackup() != false) {
            $this->_my_workflow_object->setWkflMetadata($this->getWorkflowFromSessionbackup());
        }
        
        //PostObject holen
        $internPostObject = $this->getPostObject();
        //Formulardaten des sendenden Formulars ermitteln
        $senderform_id = $internPostObject->getSenderformId();
        $senderform_array = $this->getFormArray($senderform_id);
        
        

        //Daten der Senderform ermitteln
//        $senderFormData = $internPostObject->getFormContent($senderform_id);
        //zuletzt eingefügte Daten des gleichen Formulars ermitteln
        $lastInsertedData = $this->getFormPropertyDataFromLastInsert_fromBackup($senderform_id);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte Funktion', "writeRequestdataToRtf");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> lastInsertedData:', $lastInsertedData);
        if($lastInsertedData == false) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> markedData:', $internPostObject->getMarkedData());
            $this->setFormPropertyDataFromLastInsert($senderform_id, $internPostObject->getMarkedData()[0]["content"]);
            $this->addFieldnameAndIdToLastInsertedData($senderform_id, $senderform_array["form.app_id"]);
            $lastInsertedData = $this->getFormPropertyDataFromLastInsert($senderform_id);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> markedData:', $lastInsertedData);
        }
        

        //Requestdaten holen
        //die id, welche erst im Insert-Prozess entstand, wurde unter dem array-key [0] eingefügt und wird nun in den key "id" umgehangen.
        if (isset($lastInsertedData[0])) {
            $lastInsertedData["id"] = $lastInsertedData[0];
            unset($lastInsertedData[0]);
        }
        $myresult = array();
        $myresult[] = $lastInsertedData;

        
        //Document-template ermitteln
        $document_template_array = $this->getFileTemplate($senderform_array);
        $document_template = $document_template_array["filename"];
        $document_template_type = $document_template_array["filetype"];
        
        

        //Query-Objekt instanzieren und Requestdaten als resultset vorgeben    
        //Template vorgeben
        $myQuery = new query();
        $myQuery->initialize_2($senderform_array["form.app_id"], $myresult, $document_template, $document_template_type, $senderform_array, $this);
        $myQuery->showOutputdocument();

        //Achtung: in query->showOutputdocument wird "exit()" aufgerufen, um das Query-Ergebnis zu präsentieren,
        return $feedback;
    }
    
    
    
    
    /** Ermittelt für ein Formular das Standardtemplate aus form.filename oder aus dem Konfigurationsparameter
     * "Default-request-summary_template".
     * 
     * @param   array   $in_form_array      Array des Formulars
     * @return  array                       Bsp.: array(filename => "example.html", filetype=>"html"); Wenn kein filetype ermittelt werden konnte, wird "unknown" zurückgegeben.
     */
    private function getFileTemplate($in_form_array) {
        $feedback = array();
        
        //file-template ermitteln
        if ($in_form_array["form.filename"] == "") {
            $feedback["filename"] = getConfig("Default-request-summary_template", $in_form_array["form.app_id"]);;
        } else {
            $feedback["filename"] = $in_form_array["form.filename"];
        }
        
        
        //filetype ermitteln
        $temp = explode(".", $feedback["filename"]);
        if(isset($temp[1])) {
            $feedback["filetype"] = $temp[1];
        } else {
            $feedback["filetype"] = "unknown";
        }
        
        return $feedback;
    }
    
    
    

    /** Erstellt ein Versions-/Release-Package
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  int                         ToDo: noch anpassen 6 = Backup erstellt, -65 = Backup konnte nicht erstellt werden, da sendendes Formular nicht erkannt wurde
     */
    function internFunction_finalizeVersion() {
        //PostObjekt holen
        $internPostObject = $this->getPostObject();
        //Formulardaten des sendenden Formulars ermitteln
        $senderform_id = $internPostObject->getSenderformId();
        $senderInstance_id = $this->getPostObject()->getSenderInstanceId();

        //Daten der Senderform ermitteln
        $senderFormData = $internPostObject->getFormContent($senderform_id);

//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  starte finalizeVersion mit folgenden Daten des sendenden Formulars', $senderFormData);
        require_once("../controller/version_class.php");

        if ($senderFormData !== false) {
            try {
                //Version und nächsten vorbereitenden Datensatz anlegen
                $myVersion = new version($senderFormData, false, $this);
                $result = 140;              //Version wurde erfolgreich erstellt
            } catch (Exception $exc) {
                $result = $exc->getMessage();
            }
        } else {
            //aus dem sendenden Formular konnten keine Daten ermittelt werden. D.h. es gab keinen vorbereiteten Versionsdatensatz
            try {
                //nur einen vorbereitenden Datensatz anlegen
                $defaultValuesFromForm = $this->getFormPropertyDefaultValueForInsert2($senderform_id, $senderInstance_id, false);
                $dummyFormdata = array();
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  DefaultValues', $defaultValuesFromForm);
                $dummyFormdata["content"]["version.app_id"] = $defaultValuesFromForm["app_id"];
                $dummyFormdata["content"]["version.versionnumber_compatible"] = "";
                $myVersion = new version($dummyFormdata, true, $this);
                $result = 141;              //vorbereitender Datensatz wurde erfolgreich erstellt
            } catch (Exception $exc) {
                $result = $exc->getMessage();
            }
        }



        //alte Conditions übertragen, damit nach dem Speichern wieder die gleichen Datensätze angezeigt werden
        $this->setDefaultFormProperties();
//        $this->takeOldConditions($mySession);


        return $result;
    }

    /** Die Funktion übernimmt eine hochgeladene Datei als Update-Paket und prüft deren Kompatibilität.
     * Bei Erfolg, wird das Installationspaket in den Update-Ordner entpackt.
     * 
     * @return  integer                 Fehlermeldungen gemäß konstantentyp_id = 35 [-150|-160 bis 150|160]
     */
    protected function internFunction_checkUpdate() {
        require_once("../controller/upload_class.php");
        require_once("../controller/installer_class.php");
        $feedback = 0;

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  _FILES', $_FILES);

        try {
            //installer starten
            $myInstaller = new installer();
            $feedback = $myInstaller->prepareInstall($this);
            //Formular Installation "freischalten"
            $this->setFormModeForAllInstances(356, 2);                          //form_id 356 => Formular (Update installieren); form_mode 2 => insert
        } catch (Exception $exc) {
            $feedback = $exc->getMessage();
            //alte Werte wieder laden, damit Formular im ursprünglichen Zustand geladen wird.
//            $this->setDefaultFormProperties($mySession);      
            //Befehl kann nicht genutzt werden, da User-Feedback-Meldungen über Vorgabewerte für Felder
            //realisiert wurden. Diese werden nur im Form_modus (insert) angezeigt.
            //Dieser Modus wird jecoch nicht erreicht, wenn die Default-Werte gesetzt werden.
            //Stattdessen muss die Workflow-Funktionalität erreicht werden, um eine brauchbare Lösung zu erhalten.
        }


        //Protokoll als Message zum Feld ergänzen
        $userFeddback = "<ol type=\"1\">" . $myInstaller->userFeedback . "</ol>";
        session_class::$session_object->setSessionMessageToField(2635, $myInstaller->versionnumber);
        session_class::$session_object->setSessionMessageToField(2636, $myInstaller->app_id);
        session_class::$session_object->setSessionMessageToField(2655, $myInstaller->app_id);
        session_class::$session_object->setSessionMessageToField(2647, $userFeddback);

        return $feedback;
    }

    /** Die Funktion übernimmt eine hochgeladene Datei als Install-Paket und prüft deren Kompatibilität zum Kernmodul.
     * Zudem wird sichergestellt, dass diese App noch nicht existiert. Wenn doch muss ein Update erfolgen.
     * Bei Erfolg, wird das Installationspaket in den Update-Ordner entpackt.
     * 
     * @return  integer                 Fehlermeldungen gemäß konstantentyp_id = 35 [-150|-160 bis 150|160]
     */
    protected function internFunction_checkInstallApp() {
        require_once("../controller/upload_class.php");
        require_once("../controller/installer_class.php");
        $feedback = 0;

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  _FILES', $_FILES);

        try {
            //installer starten
            $myInstaller = new installer();
            $feedback = $myInstaller->prepareInstall($this);
            //Formular Installation "freischalten"
            $this->setFormModeForAllInstances(1032, 2);                          //form_id 1032 => Formular (App installieren); form_mode 2 => insert
        } catch (Exception $exc) {
            $feedback = $exc->getMessage();
            //alte Werte wieder laden, damit Formular im ursprünglichen Zustand geladen wird.
//            $this->setDefaultFormProperties($mySession);      
            //Befehl kann nicht genutzt werden, da User-Feedback-Meldungen über Vorgabewerte für Felder
            //realisiert wurden. Diese werden nur im Form_modus (insert) angezeigt.
            //Dieser Modus wird jecoch nicht erreicht, wenn die Default-Werte gesetzt werden.
            //Stattdessen muss die Workflow-Funktionalität erreicht werden, um eine brauchbare Lösung zu erhalten.
        }


        //Protokoll als Message zum Feld ergänzen
        $userFeddback = "<ol type=\"1\">" . $myInstaller->userFeedback . "</ol>";
        session_class::$session_object->setSessionMessageToField(6897, $myInstaller->versionnumber);
        session_class::$session_object->setSessionMessageToField(6906, $myInstaller->app_id);
        session_class::$session_object->setSessionMessageToField(6884, $myInstaller->app_id);
        session_class::$session_object->setSessionMessageToField(6888, $userFeddback);
        
        return $feedback;
    }

    /** Ermittelt, dass Script welches ein Button starten soll. Der Scriptname wird in feld.vorgabewert erwartet. 
     * 
     * @return mixed        Name des Scriptes oder false
     */
    function getScriptFromButton() {

        $intern_post_object = $this->getPostObject();
        $intern_post_array = $intern_post_object->getInternPostArray();
        //button ermitteln
        $button_name = $intern_post_array["controlData"]["buttonname_that_call_function"];
        $button_field_id = $intern_post_object->getFieldidFromButtonname($button_name);
        $form_id = $intern_post_array["controlData"]["form_id_that_call_function"];
        $form_app_id = $this->getFormPropertyAppId($form_id);

        $condition = "app_id = '" . $form_app_id . "' AND id = " . $button_field_id;
        $FieldList = getTableData(global_variables::getAppIdFromSYS01(), "feld", global_variables::getNameOfDbSchemaSYS01(), 0, "", $condition);
        if (isset($FieldList[0])) {
            $myField = $FieldList[0];       //theoretisch sollte diese Liste nur genau einen Datensatz (ein Feld) enthalten
        } else {
            $myField = false;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Felddaten für Button konnte nicht ermittelt werden.: ', "condition: " . $condition, "ERROR");
        }



        if (isset($myField["feld.vorgabewert"])) {
            $feedback = $myField["feld.vorgabewert"];
        } else {
            $feedback = false;
        }

        return $feedback;
    }

    /** Ermittelt von einem Upload-Feld (konstanten_id = 945) eines Formulars die erlaubten Dateitypen.
     * Die Erlaubten Dateitypen werden im Felderkatalog in der Spalte "Vorgabewert" erwartet.
     * Wenn ein Formular mehrere Upload-Felder hat und in_searchfield_column nicht angegeben wird, werden nur die erlaubten Datentypen des letzten
     * Upload-Feldes ausgelesen. Ansonsten werden die erlaubten Dateitypen des gesuchten Feldes zurückgegeben.
     * 
     * @param   integer     $in_form_id     ID des Formulars
     * @return  mixed                       Wenn das Attribut gefunden wird, dann der Eintrag aus feld.vorgabewert, ansonsten ein Leerstring.
     */
    private Function getAllowedFiletypeFromForm($in_form_id, $in_searchfield_column = "") {
        $feedback = "";

        //Form-Array ermitteln
        $formArray = $this->getFormArrayFromSessionBackup($in_form_id);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> formarray von ID: ' . $in_form_id, $formArray);

        //Feld vom Typ 945 (Upload)   aus form.default_fields ermitteln
        foreach ($formArray["form.default_fields"] as $key => $currentField) {
            if ($currentField["feld.konstante_id"] == 945 and $in_searchfield_column == "") {
                //Wenn ein Upload-Feld gefunden wurde, aber kein explizites Feld gesucht wird.
                $feedback = $currentField["feld.vorgabewert"];
            } elseif ($currentField["feld.konstante_id"] == 945 and $currentField["feld.spalte"] == $in_searchfield_column) {
                //Wenn ein bestimmtes Upload-Feld gesucht und gefunden wird
                $feedback = $currentField["feld.vorgabewert"];
            }
        }

        return $feedback;
    }

    /** Führt die Installation eines zuvor geprüften Update-Paketes, ggf. aus dem temporären Installationspfad heraus, aus.
     * 
     * @return  integer             
     */
    protected function internFunction_startUpdate() {
        require_once("../controller/installer_class.php");
        $feedback = 0;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ', "install Update läuft 1");
//        echo "install Update läuft 1 <br />";
//        echo global_variables::getPathForAppmsinstall_abs()."<br />";



        try {
            //installer starten
            $myInstaller = new installer();
            $myInstaller->prepareOldApp();
            $feedback = $myInstaller->executeInstall($this);

            //Beide Formulare auf Modus insert setzen, da sonst die Anzeige des zweiten Formulars (Update installieren) unterdrückt wird.
            $this->setFormModeForAllInstances(356, 2);                          //form_id 356 => Formular (Update installieren); form_mode 2 => insert
            $this->setFormModeForAllInstances(349, 2);                          //form_id 339 => Formular (Update prüfen); form_mode 2 => insert
        } catch (Exception $exc) {
            $feedback = $exc->getMessage();
        }



        //Protokoll als Message zum Feld ergänzen
        $userFeddback = "<ol type=\"1\">" . $myInstaller->userFeedback . "</ol>";
        session_class::$session_object->setSessionMessageToField(2643, $userFeddback);
        session_class::$session_object->setSessionMessageToField(2635, $myInstaller->versionnumber);
        session_class::$session_object->setSessionMessageToField(2636, $myInstaller->app_id);
        session_class::$session_object->setSessionMessageToField(2655, $myInstaller->app_id);
        

        //temporären Installations-Pfad wieder deaktivieren
        session_class::$session_object->setSessionUseTempInstallPath(false);
        return $feedback;
    }

    /** Führt die Installation eines zuvor geprüften APP-Install-Paketes aus.
     * 
     * @return  integer             
     */
    protected function internFunction_startInstallApp() {
        require_once("../controller/installer_class.php");
        $feedback = 0;

        $internPostObject = $this->getPostObject();
        $newData = $internPostObject->getNewData();
        $newDataContent = $newData[0]["content"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ', "install APP: " . $newDataContent["app_id"]);

        try {
            //installer starten.$newDataContent["app_id"]
            $myInstaller = new installer();
            $myInstaller->prepareNewApp($newDataContent["app_id"], $newDataContent["dbms"], $newDataContent["host"], $newDataContent["port"], $newDataContent["dbname"], $newDataContent["user"], $newDataContent["password"], $newDataContent["encoding"]);
            $feedback = $myInstaller->executeInstall($this);

            //Beide Formulare auf Modus insert setzen, da sonst die Anzeige des zweiten Formulars (Update installieren) unterdrückt wird.
            $this->setFormModeForAllInstances(1032, 2);                          //form_id 1032 => Formular (APP installieren); form_mode 2 => insert
            $this->setFormModeForAllInstances(1026, 2);                          //form_id 339 => Formular (Update prüfen); form_mode 2 => insert
        } catch (Exception $exc) {
            $feedback = $exc->getMessage();
        }



        //Protokoll als Message zum Feld ergänzen
        $userFeddback = "<ol type=\"1\">" . $myInstaller->userFeedback . "</ol>";
        session_class::$session_object->setSessionMessageToField(6908, $userFeddback);
        session_class::$session_object->setSessionMessageToField(6897, $myInstaller->versionnumber);
        session_class::$session_object->setSessionMessageToField(6906, $myInstaller->app_id);
        session_class::$session_object->setSessionMessageToField(6884, $myInstaller->app_id);
        
        //temporären Installations-Pfad wieder deaktivieren
        session_class::$session_object->setSessionUseTempInstallPath(false);
        return $feedback;
    }

    /** Setzt bei abhängigen Formularen die Werte des sendenden Formulars als SQL-Bedingung (condition) im empfangenen Formular ein.
     * Anwendungsfall:  Im ersten Formular wird ein Datensatz (Bsp. ein Account) markiert, zu dem im zweiten Formular Details (Bsp. alle zugeordneten Rollen) angezeigt werden.
     * Dabei wird der markierte Datensatz im Formular 1 als Filter für Formular 2 genutzt.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @param   string  $in_source              Datenquelle im Post-Array für FilterConditions (mögliche Werte: [markedData|changedData])
     * @return  Integer $user_feedback          4 = erfolgreich Bedingungen hinterlegt; -4 = es war kein Datensatz markiert.
     */
    protected function internFunction_setConditionForDetaileddata($in_source = "markedData") {
        $internPostObject = $this->getPostObject();
        $senderForm_id = $internPostObject->getSenderformId();

        if ($in_source == "markedData") {
            $markedData = $this->getPostObject()->getMarkedData();
            if (count($markedData) > 0) {
                $myDatensatz = $markedData[0];
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> markierte Datensätze ermitteln ', "es wurde kein Datensatz ausgewählt!");
                return -4;
            }
        } else {
            //ToDo: Wie kann es sein, dass dieser Zweig zutrifft? Es geht in dieser Methode  um markierte und nicht um geänderte Datensätze?!?
            $myDatensatz = $this->getPostObject()->getChangedData()[0];
        }

        if ($myDatensatz <> false) {
            //der erste wird für Feldwertvorbelegung genutzt weiter verwendet
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> erster markierter Datensatz, dieser dieser wird für Feldvorbelegungen bei abhängigen Formularen genutzt: ', $myDatensatz);
            //mergedMarkedData wird für Conditions der abhängigen Formulare verwendet
            $mergedMarkedData = $this->getPostObject()->getMergedMarkedData();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> mergedMarkedData, diese dienn als condition für abhängige Formulare: ', $mergedMarkedData);

            $sender_instance_id = $this->getPostObject()->getSenderInstanceId();    //ToDo: dies ist vermutlich ein Fehler, da teilweise die instance_id von Target_form, statt von sender_form benötigt wird.
            //Merkmale, welche die passende Abhängigkeit aus der Tabelle form_dependence ermitteln können, zusammentragen.
            $app_id = $this->getMaskArray()["app_id"];
            $mask_id = $this->getMaskArray()["id"];
            $button_action_function_id = $this->getFunctionProp("button_action_function_id");
            $button_target_form_mode = $this->getFunctionProp("form_mode");
            $form_array = $this->getFormArray($senderForm_id);

            //Auslesen, welche Merkmale des sendenden Formulars als Filterkriterien für das empfangene Formular genutzt werden sollen
            $formDependencearray = getDependenceForForms($app_id, $mask_id, $senderForm_id, $button_action_function_id);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ergebnismenge FormDependenceArray: ', $formDependencearray);

            //Condition und Vorgabewerte für target_form erstellen und in pagedata->form hinterlegen
            $formCondition = "";                                             //Condition, welche die Ergebnismenge, welche in abhängige Formulare geladen werden soll, einschränkt.
            $deleteOldTargetCondition = true;                                //gibt an, ob eine alte Fomular-Condition gelöscht werden soll. Nur beim ersten Schleifendurchlauf = true
            $formDependenceDefaultValues = array();                          //Vorgabewerte, welche in abhängigen Formularen im Modus insert genutzt werden können.
            foreach ($formDependencearray as $key => $value) {
                //key = lfd. Nr.; $value = array mit einer Abhängigkeit zwischen zwei Formularen (siehe getDependenceForForms)
                $currentDependence = $value;
                $source_tablename = $currentDependence["form.source_feld_table"];
                $source_fieldname = $currentDependence["source_feld.source_feld_column"];
                $source_fieldcontent = $myDatensatz["content"][$source_tablename . "." . $source_fieldname];
                $source_fieldcontentMerged = $mergedMarkedData[0]["content"][$source_tablename . "." . $source_fieldname];
                $target_form_id = $currentDependence["form_dependence.target_form_id"];
                $target_tablename = $currentDependence["target_form.target_feld_table"];
                $target_fieldname = $currentDependence["target_feld.target_feld_column"];
                $dependence_type = $currentDependence["form_dependence.dependence_type"];
                //condition für abhängige Formulare
                if ($target_tablename != "") {
                    $formCondition = $target_tablename . "." . $target_fieldname . " in (" . $source_fieldcontentMerged . ")";
                } else {
                    $formCondition = $target_fieldname . " in (" . $source_fieldcontentMerged . ")";
                }
                //condition für Trigger-Formular
                if ($source_tablename != "") {
                    $triggerFormCondition = $source_tablename . "." . $source_fieldname . " in (" . $source_fieldcontentMerged . ")";
                } else {
                    $triggerFormCondition = $source_fieldname . " in (" . $source_fieldcontentMerged . ")";
                }

                //Schleife über alle Instanzen des target_form
                $target_instances = $this->getFormPropertyInstances($target_form_id);
                foreach ($target_instances as $target_instance_key => $target_instance) {

                    $this->setFormPropertyCondition($target_form_id, $target_instance_key, $formCondition, $deleteOldTargetCondition, "default");  //condition im formarray bei targetforms hinterlegen
                    $this->setFormMode($target_form_id, $target_instance_key, $button_target_form_mode);                                //form_mode entsprechend der gwählten Funktion anpassen


                    if ($form_array["form.behavior_after_insert"] == "lastInsert" OR $form_array["form.behavior_after_insert"] == "oldConditionAndLastInsert") {
                        //Variante A): Condition in Trigger-Formular übernehmen (damit wird nur noch der ausgewählte Datensatz angezeigt)
                        $this->setFormPropertyCondition($senderForm_id, $sender_instance_id, $triggerFormCondition, false, "default");                   //condition im Trigger-Formular hinterlegen
                    } else {
                        //Variante B): alte Condition in Trigger-Formular belassen (damit bleibt das Suchergebnis weiterhin bestehen)
                        $this->takeOldConditionsForForm($senderForm_id);
                    }

                    $this->setFormMode($senderForm_id, $sender_instance_id, 4);

                    //die gleichen Merkmale auch als Vorgabewerte für targetforms hinterlegen . Diese können als Defaultwerte beim Einfügen eines neuen Datensatzes in einem abhängigen Formular genutzt werden.
                    $formDependenceDefaultValues[$target_fieldname] = $source_fieldcontent;
                    $this->setFormPropertyDefaultValueForInsert($target_form_id, $target_instance_key, $formDependenceDefaultValues);
                    //$this->setFormProperty($target_form_id, $target_instance_key, "form.dependence_type", $dependence_type);



                    $dependenceConditionArray = array("sourcetable" => $source_tablename,
                        "sourcecolumn" => $source_fieldname,
                        "targettable" => $target_tablename,
                        "targetcolumn" => $target_fieldname,
                        "value" => $source_fieldcontent);
                    $this->setFormPropertyValueForDependingForm($senderForm_id, $target_form_id, $target_tablename . "." . $target_fieldname, $source_fieldcontent, $dependenceConditionArray);

                    //Anzahl der Datensätze in targetform ermitteln
//                        $countData = $this->calculateFormCountData($target_form_id, $target_instance_key, 0, true);
                }
                $deleteOldTargetCondition = false;                          //in allen folgenden Durchläufen sollen die vorhandenen Conditions nicht gelöscht werden, da sonst, die gerade eingefügten Conditions gelöscht werden.
            }
            $user_feedback = 4;
            //Anzahl der Datensätze in targetform ermitteln
            $countData = $this->calculateFormCountData($target_form_id, $target_instance_key, 0, true);
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> erster markierter oder geänderter Datensatz: ', 'Es wurde kein Datensatz ausgewählt');
            $user_feedback = -4;
        }

        return $user_feedback;
    }

    /** Ermittelt für ein abhängiges Formular die Condition, welche sich aufgrund des aktuellen Datensatzes im Trigger-Formular ergibt.
     * 
     * @param   integer     $in_form_id         ID des abhängigen Formulars
     * @return  string                          Condition in SQL-Syntax (Bsp.: "auto.name = 'Mercedes' AND auto.type = 'Coupe'"
     */
    protected function getConditionForDependigForm($in_form_id) {
        $app_id = $this->getMaskArray()["app_id"];
        $mask_id = $this->getMaskArray()["id"];
        $condition = "";

        //Referenz zum übergeordneten Formular ermitteln
        $trigger_form_id = $this->getFormPropertyDependenceTriggerForm($in_form_id, "reference");
        if ($trigger_form_id <> "") {
            $dependencies = $this->getFormPropertyValueForDependingForm($trigger_form_id, $in_form_id);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Dependencies von Form ' . $trigger_form_id . ' für Form: ' . $in_form_id, $dependencies);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Form_array zu dieser Zeit: ', $this->getFormList());

            //Mit Hilfe der Values den Condition-String erstellen
            $operator = "";                                                         //operator wird erst ab der zweiten Bedingung in "AND" geändert
            foreach ($dependencies as $table_and_column => $value) {
                $condition = $condition . " " . $operator . " " . $table_and_column . " = '" . $value . "'";
                $operator = "AND";
            }
        }
        return $condition;
    }

    /** Hinterlegt im aktuellen Formular die Conditions, inkl. values, für abhängige Formulare.
     * 
     * @param   Integer  $in_form_id             ID des sendenden Formulars (trigger_form)
     * @param   array    $in_data                zweidimensionales array mit den Inhaltsdaten eines Formulars, wie es bspw. die Funktion getTableData ermittelt. Bsp.:
     *                                           Array
      (
      [0] => Array
      (
      [bew.id] => 21702840
      [bew.kanzlei_id] => 8
      [bew.bewsem] => 20172
      [bew.anrede] => Frau
      )

      )
     *                                          Es wird jedoch nur der erste Datensatz verarbeitet        
     */
    function setFormPropertyConditionForDependingForms($in_form_id, $in_data) {

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> form-ID: ' . $in_form_id, "starte setFormPropertyConditionForDependingForms");

        if (isset($in_data[0])) {
            //nur der erste Datensatz wird  verwendet
            $myDatensatz = $in_data[0];
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> erster Datensatz, dieser dient als condition für abhängige Formulare: ', $myDatensatz);

            if ($myDatensatz <> array()) {
                //Merkmale, welche die passende Abhängigkeit aus der Tabelle form_dependence ermitteln können, zusammentragen.
                $app_id = $this->getMaskArray()["app_id"];
                $mask_id = $this->getMaskArray()["id"];

                //Auslesen, welche Merkmale des sendenden Formulars als Filterkriterien für das empfangene Formular genutzt werden sollen
                $formDependencearray = getDependenceForForms($app_id, $mask_id, $in_form_id, "all");
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ergebnismenge FormDependenceArray: ', $formDependencearray);

                //Condition und Vorgabewerte für target_form erstellen und in pagedata->form hinterlegen
                $formDependenceValues = array();                                 //Werte, welche in abhängigen Formularen als Condition genutzt werden.
                foreach ($formDependencearray as $key => $value) {
                    //key = lfd. Nr.; $value = array mit einer Abhängigkeit zwischen zwei Formularen (siehe getDependenceForForms)
                    $currentDependence = $value;
                    $source_columnname = $currentDependence["source_feld.source_feld_column"];
                    $source_tablename = $currentDependence["source_form.source_feld_table"];
                    $source_fieldcontent = $myDatensatz[$source_tablename . "." . $source_columnname];
                    $target_form_id = $currentDependence["form_dependence.target_form_id"];
                    $target_tablename = $currentDependence["target_form.target_feld_table"];
                    $target_columnname = $currentDependence["target_feld.target_feld_column"];

                    $dependenceConditionArray = array("sourcetable" => $source_tablename,
                        "sourcecolumn" => $source_columnname,
                        "targettable" => $target_tablename,
                        "targetcolumn" => $target_columnname,
                        "value" => $source_fieldcontent);

                    //Conditions für abhängige Formulare im aktuellen Formular zum Abruf bereitstellen
                    $this->setFormPropertyValueForDependingForm($in_form_id, $target_form_id, $target_tablename . "." . $target_columnname, $source_fieldcontent, $dependenceConditionArray);
                }
            }
        }
    }

    /** Ermittelt den HTML-Code für alle Symbolleisten eines Formulars.
     * 
     * @param   integer     $in_position    [1|2] 1 = top; 2 = bottom
     * @param   array       $in_form        Array des Formulars
     * @param   string      $in_instanceId
     * @return  string                      HTML-Code
     */
    public function getSymbolgroupHtml($in_position, $in_form, $in_instanceId) {
        $feedback = "";
        $form_id = $in_form["form.id"];
        if ($in_position === 1) {
            $class = "form_nav_top";
        } else {
            $class = "form_nav_bottom";
        }

        $feedback = $feedback . "<div class=\"" . $class . "\" >\r\n";     //Beginn der Navigationszeile   
        //Todo: getSymbolgroupsByFormID geht auf die Datenbank. Mehrfacher DB-Zugriff könnte vermieden werden, 
        //wenn die Daten der Symbolgruppen nach dem ersten Aufruf in pagedata zwischengespeichert werden würden.
        $symbolgroups = getSymbolgroupsByFormID($form_id, $in_form["form.app_id"], $in_position);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> symbolgroups_' . $class . ': ', $symbolgroups);
        for ($i = 0; $i < count($symbolgroups); $i++) {
            //Todo: getFormsdataByFormID geht auf die Datenbank. Mehrfacher DB-Zugriff könnte vermieden werden, 
            //wenn die Formulare der Symbolgruppen nach dem ersten Aufruf in pagedata zwischengespeichert werden würden.
            $feedback = $feedback . getSymbolGroup(getFormsdataByFormID($symbolgroups[$i] ["html_tag.form_id"], $symbolgroups[$i] ["html_tag.form_app_id"]), $this, "auto", $form_id, $this->getFormPropertyFormmode($form_id, $in_instanceId), $in_form["form.app_id"], $in_instanceId) . " \r\n";
        }
        $feedback = $feedback . "</div>\r\n";                                                    //Ende der Navigationszeile

        return $feedback;
    }

    /** Erstellt den HTML-Code für die Tabellenstruktur für ein Formular, inkl. gefüllter Datenfelder.
     * Sollten keine Datenfelder vorliegen, kann dennoch ein leeres Formular, bspw. für die Modi insert oder filter, erstellt werden.
     * 
     * @param   integer     $in_form_id                 ID des Formulars
     * @param   string      $in_currentFormInstanceId   Instanz des Formulars
     * @param   boolean     $in_buildTable              Gibt an, ob eine Tabellen-artige Struktur (true) oder eine Single-Data-Eingabemaske (false) erzeugt werden soll.
     * @param   string      $in_datasource              Wie wurden die Daten ermittelt [query|table|noData]; Bei noData werden immer, unabhängig vom Formularmodus, die Vorgabewerte im Feld angedruckt.
     * @param   array       $in_fieldlist               Liste aller Felder, wie sie die Funktion getFieldList ermittelt
     * @param   array       $in_data                    Datenliste, die bspw. mit getTableData ermittelt wurde
     * @param   boolean     $in_addIDToFieldname        Gibt an, ob name und id eines HTML-Elements um eine eindeutige Kennung erweitert werden sollen.
     * @param   boolean     $in_hide_markfield          Gibt an, ob die Markierungsfelder ausgeblendet werden sollen. 
     * @param   string      $in_add_constructor_class   Name einer css-Klasse die zu allen Dom-Elementen ergänzt wird.
     * @return  string                                  HTML-Code für ein table- oder div-Element
     */
    public function getFormHtmlStructure($in_form_id, $in_currentFormInstanceId, $in_buildTable, $in_datasource, $in_fieldlist, $in_data, $in_addIDToFieldname, $in_hide_markfield, $in_add_constructor_class) {
        

        
        $form = $this->getFormArray($in_form_id);
        $current_date = $this->getFormPropertyCurrentDate($in_form_id);
        $feedback = "";
        $formID_and_Instance = $in_form_id."_".$in_currentFormInstanceId;
        $show_RowManageButtonAdd = false;
        $show_RowManageButtonHide = false;
        $tab_id = session_class::$session_object->getTabId();

        //Sonstige Felder, die noch nicht zu den Datensätzen gehören. Die Datensätze werden erst ab dem ersten Feld, dass mit datensatzstartattribut beginnt, erkannt
        $feedback = $feedback . "<div><input id=\"tab_id_$formID_and_Instance\" name=\"tab_id\" type=\"hidden\" value=\"$tab_id\"></div>\r\n";       //Zur Übergabe der aktuellen Tab-ID zwischen Browser und Server
        $feedback = $feedback . "<div><input id=\"hidden_current_date_$formID_and_Instance\" name=\"hidden_current_date\" type=\"hidden\" value=\"$current_date\"></div>\r\n";       //Zur Übergabe des aktuellen Stichtages
        $feedback = $feedback . "<div><input id=\"form_id_$formID_and_Instance\" name=\"form_id\" type=\"hidden\" value=\"" . $in_form_id . "\"></div>\r\n";
        $feedback = $feedback . "<div><input id=\"instance_id_$formID_and_Instance\" name=\"instance_id\" type=\"hidden\" value=\"" . $in_currentFormInstanceId . "\"></div>\r\n";
        $feedback = $feedback . "<div><input id=\"form_modus_$formID_and_Instance\" name=\"last_form_modus\" type=\"hidden\" value=\"" . $this->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId) . "\"></div>\r\n";
        $feedback = $feedback . "<div><input id=\"action_id_$formID_and_Instance\" name=\"action_id\" type=\"hidden\" value=\"" . microtime() . "\"></div>\r\n";                         //anhand der Action-Id kann nach dem Absenden des Formulars durch den Nutzer, serverseitig geprüft werden, ob die Formulardaten erneut gesendet wurden.
        //altes Relikt, welches als Erinnerung erhalten bleiben soll! Die Variante, table-tag zu nutzen, hat sich als zu unflexibel erwiesen.
        //Überschriften konnten nicht exakt ausgerichtet werden und Überschrift links vom Feld zu platzieren führte zu Layout-Verschiebungen.
        $build_tag_table = false;
        
        //Anzahl der Zeilen für aria (Barrierefreiheit) ermitteln. Die Überschriftenzeile muss mitgezählt werden.
        if(count($in_data) > 0) {$count_aria_rows = count($in_data)+1;} else {$count_aria_rows = -1;}
        
        

        //div-Struktur beginnen
        $feedback = $feedback . "<div id=\"table_data_$formID_and_Instance\" role=\"grid\" aria-rowcount=\"".$count_aria_rows."\" aria-colcount=\"".count($in_fieldlist)."\" aria-label=\"".$form["form.name"]."\" class=\"table_data table_data_" . $in_add_constructor_class . "\">\r\n";

        if (count($in_data) > 0) {
            //Wenn Daten gefunden wurden, werden pro Datensatz alle Felder angedruckt
            //Hinweis: auch im Modus = 2 (insert) ist immer ein Datensatz vorhanden. Dieser enthält dann Defaultwerte
            addToDebug(__FILE__ . " Zeile " . __LINE__ . " -> " . __FUNCTION__ . " -> Datensätze ", $in_data);
            addToDebug(__FILE__ . " Zeile " . __LINE__ . " -> " . __FUNCTION__ . " -> Datenquelle ", $in_datasource);
            addToDebug(__FILE__ . " Zeile " . __LINE__ . " -> " . __FUNCTION__ . " -> fieldlist ", $in_fieldlist);
            
            //Wenn das Formular im Modus 2 (insert) dargestellt werden soll und mehr als eine Datenzeile angeboten werden soll, dann Buttons zur Verwaltung der Datenzeilen ergänzen.
            if($this->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId) == 2 AND isset($in_data[1]["isDefaultInsert"]) === true) {
                $show_RowManageButtonAdd = true;
                $show_RowManageButtonHide = false;
            } else {
                $show_RowManageButtonAdd = false;
                $show_RowManageButtonHide = false;
            }
        

            for ($i = 0; $i < count($in_data); $i++) {                                                  //Jeder Datensatz wird einzeln bearbeitet
                // Prüfen, ob zusätzlich Feldvorbelegungswerte mit $_GET übergeben wurden.
                if ($this->internGetObject->existGetFields() == true) {
                    $in_fieldlist = matchFieldsToGetdata($in_fieldlist, $this->internGetObject->getFieldlist());
                }

//                addToDebug(__FILE__." Zeile ".__LINE__." -> ".__FUNCTION__." -> matched_in_fieldlist (a) in Formular ".$form['form.name']." in Datensatz $i: ", $in_fieldlist);

                if ($in_datasource == "query") {
                    //Daten des aktuellen Datensatzes einer Query in in_fieldlist übertragen
                    $matched_in_fieldlist = matchFieldsToQuerydata($in_fieldlist, $in_data[$i]);
                } elseif ($in_datasource == "table") {
                    //Daten des aktuellen Datensatzes einer Tabelle in in_fieldlist übertragen
                    $matched_in_fieldlist = matchFieldsTodata($in_fieldlist, $in_data[$i]);
                } elseif ($in_datasource == "noData") {
                    //Prüfen, ob Variablenplatzhalter ersetzt werden müssen
                    $matched_in_fieldlist = replaceInternVariables($this, $in_form_id, $in_currentFormInstanceId, $in_fieldlist);
                }
                
                //RowManageButtons prüfen
                if($show_RowManageButtonAdd === true and $i== count($in_data)-1) {$show_RowManageButtonAdd = false;}
                if($show_RowManageButtonAdd === true and $i> 0) {$show_RowManageButtonHide = true;}

//                addToDebug(__FILE__." Zeile ".__LINE__." -> ".__FUNCTION__." -> matched_in_fieldlist (b) in Formular ".$form['form.name']." in Datensatz $i: ", $matched_in_fieldlist);

                //----Row-Start------------------------
                $localfeedback = $this->getFormHtmlStructureForARow($in_form_id, $in_currentFormInstanceId, $in_buildTable, $i, $in_add_constructor_class, $in_addIDToFieldname, $matched_in_fieldlist, $in_hide_markfield, $in_datasource, $show_RowManageButtonAdd, $show_RowManageButtonHide);            
                
                If($i > 0 and isset($in_data[$i]["isDefaultInsert"])) {
                    //Ab der 2. Zeile werden Datensätze, welche "nur" DefaultInsert-Daten enthalten, in dem HiddenPart eingehangen
                    $myHtmlDom = $this->getHtmlDomObject();
                    $temp_cur_id = "hiddenrowcontainer_form".$in_form_id."_instance".$in_currentFormInstanceId."_row".$i;
                    $myHtmlDom->addTagNewHiddenRow($temp_cur_id, $form["form.app_id"], $in_form_id, $localfeedback, $i);
                } else {
                    $feedback = $feedback.$localfeedback;
                }
                //----Row-End--------------------------
                
            }


            //div-Struktur nach der letzten Zeile beenden
            $feedback = $feedback . "</div> <!-- End: div_tbody --> \r\n";
        } else {
            //Wenn das Formular im Modus "Filter" dargestellt werden soll
            if (in_array($this->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId), array(3, 8))) {
                //form_mode: 3 -> Filter; 8 -> Filter with required fields
                $feedback = $feedback . $this->getFormHtmlStructureForARow($in_form_id, $in_currentFormInstanceId, $in_buildTable, -1, $in_add_constructor_class, $in_addIDToFieldname, $in_fieldlist, $in_hide_markfield, $in_datasource, $show_RowManageButtonAdd, $show_RowManageButtonHide);
                
            } elseif (in_array($this->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId), array(1, 5, 7))) {
                //form_mode: 1 -> default; 5 -> empty; 7 -> only_read
                $feedback = $feedback . _getNoDataDefaultText($form["form.app_id"]);
            }
        }



        //div-Struktur beenden  -> Anfang der Struktur findet sich in getFormHtmlStructureForARow
        $feedback = $feedback . "</div> <!-- End: table_data --> \r\n";

        return $feedback;
    }
    
    
    
    
    /** Erstellt den HTML-Code für eine einzelne Datenzeile.
     * 
     * @param   integer     $in_form_id                     ID des Formulars
     * @param   string      $in_currentFormInstanceId       Instanz des Formulars
     * @param   boolean     $in_buildTable                  Gibt an, ob eine Tabellen-artige Struktur (true) oder eine Single-Data-Eingabemaske (false) erzeugt werden soll.
     * @param   integer     $in_row                         Zeilennummer / Datensatznummer innerhalb des Formulars.
     * @param   string      $in_add_constructor_class       Name einer css-Klasse die zu allen Dom-Elementen ergänzt wird.
     * @param   boolean     $in_addIDToFieldname            Gibt an, ob name und id eines HTML-Elements um eine eindeutige Kennung erweitert werden sollen.
     * @param   array       $in_matched_fieldlist           Liste aller Felder, wie sie die Funktion getFieldList ermittelt, inkl. ergänzter Daten.
     * @param   boolean     $in_hide_markfield              Gibt an, ob die Markierungsfelder ausgeblendet werden sollen. 
     * @param   string      $in_datasource                  Wie wurden die Daten ermittelt [query|table|noData]; Bei noData werden immer, unabhängig vom Formularmodus, die Vorgabewerte im Feld angedruckt.
     * @param   boolean     $in_show_RowManageButtonAdd     Gibt an, ob im Formularmodus (insert) der Buttons zum Ergänzen einer neuen Zeile angedruckt werden sollen.
     * @param   boolean     $in_show_RowManageButtonHide    Gibt an, ob im Formularmodus (insert) der Buttons zum Entfernen einer neuen Zeile angedruckt werden sollen.
     * @return  string                                      HTML-Code für ein table- oder div-Element
     */
    private function getFormHtmlStructureForARow($in_form_id, $in_currentFormInstanceId, $in_buildTable, $in_row, $in_add_constructor_class, $in_addIDToFieldname, $in_matched_fieldlist, $in_hide_markfield, $in_datasource, $in_show_RowManageButtonAdd, $in_show_RowManageButtonHide) {
        
        //Variablen festlegen
        $feedback = "";
        $set_default_content = $this->getFormPropertySetDefaultContent($in_form_id, $in_currentFormInstanceId);
        $note_requireFlag = $this->getFormPropertyNoteRequireFlag($in_form_id, $in_currentFormInstanceId);
        $note_readonly = $this->getFormPropertyNoteReadonly($in_form_id, $in_currentFormInstanceId);
        $allways_readonly = $this->getFormPropertyAllwaysReadonly($in_form_id, $in_currentFormInstanceId);
        $show_nested_forms = $this->getFormPropertyShowNestedForms($in_form_id, $in_currentFormInstanceId);
        if ($in_hide_markfield !== true) {
            $showMarkField = $this->getFormPropertySetMarkField($in_form_id, $in_currentFormInstanceId);
        } else {
            $showMarkField = false;
        }
        $app_id_from_kernel = global_variables::getAppIdFromSYS01();
        $db_trennzeichen = getConfig("db_trennzeichen", $app_id_from_kernel);
        $maskArray = $this->getMaskArray();
        $form = $this->getFormArray($in_form_id);
        
        if ($in_datasource == "noData") {
            //bei Constructoren ohne Datenbindung (bspw. internVariables) werden die Vorgabewerte immer angedruckt.
            $set_default_content = true;
        }
        
        
        
        //Ggf. Überschriftenzeile voranstellen
        if ($in_row == 0) {
            //1. Zeile, daher bei tabellenartiger Struktur Überschriftenzeile voranstellen
            if ($in_buildTable == true) {
                //Vor dem ersten Datensatz wird eine Tabellenzeile ergänzt, welche nur die Überschriften enthält
                $feedback = $feedback . "<div class=\"div_thead div_thead_" . $in_add_constructor_class . "\" role=\"rowgroup\">\r\n";
                $feedback = $feedback . _getDatensatzStartsequenz($in_buildTable, $in_row . "_head_", false, true, $in_add_constructor_class, $in_form_id, $in_currentFormInstanceId, $in_row + 1);
                if ($in_addIDToFieldname == true) {
                    $addID = "Form" . $in_form_id . "_" . $in_row . "head_" . $in_currentFormInstanceId;
                } else {
                    $addID = "";
                }           //eindeutige ID für jedes Feld im Formular erzwingen
                $feedback = $feedback . getFieldsOfRow($in_matched_fieldlist, 2, $addID, $this, $in_currentFormInstanceId, $in_add_constructor_class, $in_row . "head_", false, $db_trennzeichen, $set_default_content, $note_requireFlag, $maskArray, $form, $showMarkField, __FUNCTION__ . "_1", $in_buildTable, $note_readonly, $allways_readonly) . "\r\n";
                $show_headlines = 0;                //nach dem ersten Durchlauf, werden headlines nicht mehr angedruckt.
                $feedback = $feedback . _getDatensatzEndsequenz();
                $feedback = $feedback . "</div> <!-- End: div_thead --> \r\n";

                if (in_array($in_add_constructor_class, array("rectanglequery_constructor", "rectangletable_constructor"))) {
                    //bei diesen Constructoren darf die Breite nicht fix vorgegeben werden, da sie auf kleineren Bildschirmen automatisch umbrechen dürfen/sollen.
                    $style = "";
                } else {
                    //Breite der Zeile als Style-Anweisung mitgeben, damit scrollable Table möglich wird.
                    $width_calculated = $this->getFormPropertyCalculatedWidth($in_form_id);
                    $style = "style=\"width:" . $width_calculated . "\"";
                    
                }
            } else {
                $show_headlines = 1;
                $style = "";
            }
            $div_id = "id=\"div_tbody_form" . $in_form_id . "instance" . $in_currentFormInstanceId . "\"";
            //$feedback = $feedback . "<div role=\"rowgroup\" class=\"div_tbody div_tbody_" . $in_add_constructor_class . "\" $style $div_id >\r\n";
            $feedback = $feedback . "<div role=\"rowgroup\" class=\"div_tbody div_tbody_" . $in_add_constructor_class . "\" $div_id >\r\n";
        
        } elseif($in_row == -1) {
            //Der Wert -1 wird nur im Filtermodus (3 und 8) übergeben
            $show_headlines = 1;
            $in_row = 1;
            
        } elseif($form["form.constructor"] == "RectanglesForTable2") {
            //dieser Constructor ist wie Singledata (jedes Feld soll eine Überschrift haben), stellt jedoch mehrere Datensätze dar.
            $show_headlines = 1;
            
        } else {
            //jede weitere Datenzeile
            $show_headlines = 0;
            
        }
        
        
                
        //Datenfelder andrucken
        $feedback = $feedback._getDatensatzStartsequenz($in_buildTable, $in_row, false, false, $in_add_constructor_class, $in_form_id, $in_currentFormInstanceId, $in_row + 2);
                
        $addID = "Form" . $in_form_id . "_" . $in_row . "_i0";                                        //eindeutige ID für jedes Feld im Formular erzwingen
        if ($in_addIDToFieldname == true) {
            $addID = "Form" . $in_form_id . "_" . $in_row . "_" . $in_currentFormInstanceId;
        } else {
            $addID = "";
        }           //eindeutige ID für jedes Feld im Formular erzwingen	
        $feedback = $feedback . getFieldsOfRow($in_matched_fieldlist, $show_headlines, $addID, $this, $in_currentFormInstanceId, $in_add_constructor_class, $in_row, true, $db_trennzeichen, $set_default_content, $note_requireFlag, $maskArray, $form, $showMarkField, __FUNCTION__ . "_2", $in_buildTable, $note_readonly, $allways_readonly, $in_show_RowManageButtonAdd, $in_show_RowManageButtonHide) . "\r\n";
        $show_headlines = 0;                //nach dem ersten Durchlauf, werden headlines nicht mehr angedruckt.
        if ($show_nested_forms == true) {
            $nestedForm = getHTMLCodeForNestedForms($form["form.app_id"], $in_form_id, $in_matched_fieldlist, $this, $in_row, $in_add_constructor_class, $in_currentFormInstanceId);
            $feedback = $feedback . $nestedForm;
            if ($nestedForm <> "") {
                //Wenn eingebettete Formulare vorliegen, werden im Parentformular auch in allen folgenden Zeilen die Überschriften angedruckt.
                $show_headlines = 1;
            }
        }
        $feedback = $feedback . _getDatensatzEndsequenz();
        
        return $feedback;
    }
    
    
    
    
    

    /** Gibt für eine übergebene FOrm-ID alle abhängigen Fomular-ID's zurück.
     * 
     * @param   integer     $in_form_id         ID des Formulars, für welches die abhängigen Formulare auf der gleichen Maske ermittelt werden sollen.
     * @return  array                           Array mit den ID's der abhängigen Formulare. Bsp.: array(1, 4, 56); Wenn kein abhängiges Formular gefunden wurde, 
     *                                          dann wird ein leeres Array zurückgegeben.
     */
    function getDependedForms($in_form_id) {

        $sender_instance_id = $this->getPostObject()->getSenderInstanceId();    //ToDo: dies ist vermutlich ein Fehler, da teilweise die instance_id von Target_form, stat von sender_form benötigt wird.
        //Merkmale, welche die passende Abhängigkeit aus der Tabelle form_dependence ermitteln können, zusammentragen.
        $app_id = $this->getMaskArray()["app_id"];
        $mask_id = $this->getMaskArray()["id"];

        //Auslesen, welche Merkmale des sendenden Formulars als Filterkriterien für das empfangene Formular genutzt werden sollen
        $formDependencearray = getDependenceForForms($app_id, $mask_id, $in_form_id, "all");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ergebnismenge FormDependenceArray für form: ' . $in_form_id, $formDependencearray);

        //Condition und Vorgabewerte für target_form erstellen und in pagedata->form hinterlegen
        $formList = array();                                             //Condition, welche die Ergebnismenge, welche in abhängige Formulare geladen werden soll, einschränkt.
        foreach ($formDependencearray as $key => $value) {
            //key = lfd. Nr.; $value = array mit einer Abhängigkeit zwischen zwei Formularen (siehe getDependenceForForms)
            $currentDependence = $value;
            $formList[$currentDependence["form_dependence.target_form_id"]] = array();                     //das array wird später durch setFormPropertyConditionForDependingForms mit Werten aufgefüllt
        }

        return $formList;
    }

    /** Ruft für die übergebene functionID die entsprechende PHP-Funktion auf und gibt User-Function-Feedback-Code zurück.
     * Die möglichen User-Function-Feedback-Code's können dr Tabelle "konstante" (konstantentyp 35) entnommen werden.
     * 
     * @param   string      $in_functionAppID               APP-ID der Funktion
     * @param   integer     $in_functionID                  function_ID, die aus der URL ausgelesen wurde
     * @param   boolean     $in_feedbackBuildFunctionArray  Gibt an, ob das FunctionArray erfolgreich aufgebaut werden konnte.
     * @return  integer                                     User-Function-Feedback-Code
     */
    protected function callFunction($in_functionAppID, $in_functionID, $in_feedbackBuildFunctionArray) {

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> call Function: ', $this->_functionArray);

        $core_app_id = global_variables::getAppIdFromSYS01();

        $feedback = 0;
        if ($in_functionID <> 0) {
            $function_name = $this->getFunctionProp("functionname");

            if ($in_functionAppID == $core_app_id) {
                //Wenn eine Funktion aus dem Kernmodul aufgerufen werden soll, befindet sich diese in dieser Klasse
                $feedback = $this->$function_name();
            } else {
                //wenn eine Funktion aus einem anderen Modul aufgerufen werden soll, befindet sich diese in einer Plugin-Klasse
                $function_class = $this->getFunctionProp("classname");
                if (loadPlugin($in_functionAppID, $function_class) == true) {
                    $function_object = new $function_class();
                    $feedback = $function_object->$function_name($this);
                } else {
                    //Plugin konnte nicht geladen werden
                    //button_action_function_app_id auf Kernel-App setzen, damit der richtige Fehlertext ermittelt wird.
                    $this->setFunctionProperty("button_action_function_app_id", $core_app_id);
                    $feedback = -101;
                }
            }
        } elseif ($in_feedbackBuildFunctionArray == false) {
            //es wurde keine Funktion übergeben
            $feedback = -102;
            $this->setFunctionProperty("button_action_function_app_id", $core_app_id);
        } else {
            //Es wurde kein Button, d.h. keine Funktion aufgerufen, sondern ein Link
        }

        return $feedback;
    }

    /** Diese Funktion hinterlegt in der SESSION in der Eigenschaft "active_role" die gewählte Rolle
     * und lädt anschließend die Maske neu. Dadurch wird die Ausführung der laufenden PHP-Prozesse abgebrochen !!!
     * Wenn eine Rolle gewählt wurde, auf die der User keinen Zugriff hat (Manipulationsversuch)
     * wird das in der Tabelle debug protokolliert.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *  
     * @return  nothing                     Ein Returnwert ist nicht auswertbar, da die Fortführung der PHP-Ausführung in dieser Funktion abgebrochen wird. (ToDo: prüfen, ob der Returncode ebenfalls in SESSION bereitgestellt werden könnte.
     */
    public function internFunction_changeRole() {

        $internPostObject = $this->getPostObject();
//        $POST_Array_controldata = $internPostObject->getInternPostArray()["controlData"];
        $POST_Array_controldata = $internPostObject->getMarkedData();
        $POST_Array_controldata = $POST_Array_controldata[0]["content"];

        //aus Post die gewählte role_id auslesen
        if (issetKeyLike($POST_Array_controldata, "role_id") <> false) {
            //gewünschte role_id auslesen
            $role_key = issetKeyLike($POST_Array_controldata, "role_id");
            $role_id = $POST_Array_controldata[$role_key];

            $role_array = session_class::$session_object->setActiveRoleId($role_id);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> role_array: ', $role_array);

            if ($role_array !== false) {
                //Prüfen, ob für die Rolle eine start_mask definiert wurde
                $startmask_by_role = getRoleStartmask($role_array["role.app_id"], $role_id);
                if($startmask_by_role != array()) {
                    //Start_Mask wurde über Rolle ermittelt
                    $default_mask_app_id = $startmask_by_role["mask_app_id"];
                    $default_mask_id = $startmask_by_role["mask_id"];
                } else {
                    //Startmaske wird über den Konfigurationsparameter (start_mask) ermittelt
                    $default_mask_app_id = global_variables::getDefaultMaskAppId($role_array["role.app_id"], "start_mask");
                    $default_mask_id = global_variables::getDefaultMaskId($role_array["role.app_id"], "start_mask");
                }
                
                $this->reloadMask($default_mask_app_id, __FUNCTION__, $default_mask_id, "Die Rolle wurde gewechselt.");
                //reloadMask bricht Skript ab, damit weitere Funktionen nicht ausgeführt werden
            }
        }


        //return -100; -> es wurde keine Rolle gewählt.
    }
    
    
    
    /** Wechselt die Rolle und führt einen Reload aus.
     * Die Funktion hat keinen Rückgabewert, da durch den reload die Scriptausführung abgebrochen wird.
     * 
     * @param   integer     $in_role_id             ID der gewünschten Rolle
     * @param   string      $in_target_mask_app_id  APP-ID der zu ladenden Maske
     * @param   integer     $in_target_mask_id      ID der zu ladenden Maske
     * @param   array       $in_further_get_params  Liste der zu ergänzenden GET-Parameter; key = Name des Parameters, value = Wert des Parameters; Bsp.: array("id" => 123, "logout" => true); Wenn nicht benötigt, dann leeres array übergeben.
     * @param   string      $in_user_message        Meldung, die an die Feedbackbox übergeben werden soll. Wenn nicht notwendig, dann Leerstring übergeben.
     */
    public function changeRoleAndReloadMask($in_role_id, $in_target_mask_app_id, $in_target_mask_id, $in_further_get_params, $in_user_message) {


            $role_array = session_class::$session_object->setActiveRoleId($in_role_id);
            if ($role_array !== false) {
                
                $this->reloadMask($in_target_mask_app_id, __FUNCTION__, $in_target_mask_id, $in_user_message, $in_further_get_params);
                //reloadMask bricht Skript ab, damit weitere Funktionen nicht ausgeführt werden
            }
        


        //return -100; -> es wurde keine Rolle gewählt.
    }
    
    
    
    
    

    /** Bricht die aktuelle Skriptausführung ab und lädt die Maske neu
     * 
     * @param   string  $in_mask_app_id     APP-ID der target-Mask
     * @param   string  $in_caller          Name der Funktion, welche diese Funktion aufruft. Wird für Debug-Meldung verwendet.
     * @param   int     $target_mask_id     ID der Maske, welche aufgerufn werden soll
     * @param   string  $in_user_feedback   Meldung, welche dem User präsentiert wird. Wenn keine Meldung erscheinen soll, dann Leerstring übergeben
     * @param   string  $in_further_get_params  [optional] Liste weiterer GET-Parameter; key = param_name, value = param_value; Bsp.: array(id => "123")
     */
    public function reloadMask($in_mask_app_id, $in_caller, $target_mask_id = "", $in_user_feedback = "", $in_further_get_params = array()) {

        if ($target_mask_id == "") {
            $targetUrl = global_variables::getDefaultMask($in_mask_app_id, "start_mask");
        } else {
            $targetUrl = "page.php?mask=" . $target_mask_id . "&maskapp=" . $in_mask_app_id;
        }
        
        if($in_further_get_params != array()) {
            //Wenn weitere GET-Parameter angegebn wurden, dann werden diese an die URL angehangen
            foreach ($in_further_get_params as $key => $value) {
                $targetUrl= $targetUrl."&".$key."=".urlencode($value);
            } 
        }


        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Abbruch in Function " . $in_caller, "Maske neu laden mit neuen Parametern: " . $targetUrl);
        session_class::$session_object->setSessionMessageToField("infobox", $in_user_feedback);

        header("Refresh:0; url=" . $targetUrl);
        exit();             //Skript abbrechen, damit weitere Funktionen nicht ausgeführt werden
    }

    /** Weist den Anwender darauf hin, dass diese Funktion über Javascript ausgeführt wird.
     * Wenn dieser Funktionsaufruf zutrifft, dann ist Javascript deaktiviert.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  int                         -100 = Javascript ist nicht aktiviert
     */
    public function internFunction_requireJavascript() {
        //alte Conditions übertragen, damit nach dem Speichern wieder die gleichen Datensätze angezeigt werden
        $this->setDefaultFormProperties();

        return -100;
    }

    /** Speichert die geänderten Datensätze, die mit dem Post-Array übergeben wurden. 
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  integer                     1 = erfolgreich gespeichert, -1 = speichern fehlgeschlagen, -11 = Fehler, weil kein DS markiert war oder weil eine Manipulation vorliegt
     */
    public function internFunction_saveData() {

        $geaenderteDatensaetze = $this->getChangedDataFromPostarray();
        //PostObjekt holen
        $internPostObject = $this->getPostObject();
        $senderForm_id = $internPostObject->getSenderformId();
        $instance_id = $internPostObject->getSenderInstanceId();           //Instanz des Formulars, in dem der Button gedrückt wurde



        if ($geaenderteDatensaetze <> array()) {
            //wenn  mindestens ein geänderter Datensatz vorhanden ist
            $form_id = $geaenderteDatensaetze[0]["form"];
            $hiddenCurrentDate = $this->getFormPropertyCurrentDate($form_id);

            //Datensätze bereinigen -> In kombinierten Parent+Child-Formularen kann es vorkommen, dass auch Daten von 
            //Query-basierten Formularen übersandt werden. Diese können durch updateTableData nicht verarbeitet werden,
            //da sie sich i.d.R. nicht nur auf eine DB-Tabelle beziehen. Die Datensätze sind an der fehlenden Schema- und
            //Table-Angabe erkennbar.
            $clearedDatensaetze = $this->clearDatensaetze($geaenderteDatensaetze);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> bereinigte Datensätze", $clearedDatensaetze);

            if (count($clearedDatensaetze) > 0) {
                $feedback_for_update = updateTabledata($clearedDatensaetze, $this, $this->getActiveUser(), $hiddenCurrentDate);
                if ($feedback_for_update > 0) {
                    $updateresult = 1;
                } else {
                    $updateresult = -1;
                }
            } else {
                $feedback_for_update = -11;
            }
        } else {
            //es ist möglich, dass keine geänderten Datensätze erkannt werden, wenn der Anwender geschützte Felder manipuliert hat (siehe buildArrayWithChangedData)
            $feedback_for_update = -11;                    //Dem Anwender wird bewußt kein Grund genannt. Der Grund kann der Debug-Tabelle entnommen werden.
            $form_id = $senderForm_id;
        }
        //alte Conditions übertragen, damit nach dem Speichern wieder die gleichen Datensätze angezeigt werden
        $this->setDefaultFormProperties();
        
        //prüfen, ob ein geänderter form_mode gesetzt werden soll (siehe feld(button).form_mode_id
        $current_form_mode = $this->getFormPropertyFormmode($form_id, $instance_id);
        $target_form_mode = $this->getFunctionProp("form_mode");
        if($current_form_mode != $target_form_mode AND $target_form_mode !== false) {
            $this->setFormMode($form_id, $instance_id, $this->getFunctionProp("form_mode"));    //Für den Fall, dass das Formular noch im Modus empty war, wird es nun auf targetFormMode gesetzt.
        }

        $Offset = $this->takeOldValueFromForm($form_id, $instance_id, "form.offset");
        $countData = $this->calculateFormCountData($form_id, $instance_id, $Offset, true);
        
        return $feedback_for_update;
    }
    
    
    
    
    
    
    
    
    /** setzt in einer bestimmten Zielspalte den gleichen Wert für alle markierten Datensätze. 
     * Die DB-Spalte ergibt aich aus button->feld.db_spalte. Der Value ergibt sich aus button->feld.vorgabewert.
     * 
     * @return integer      Rückgabewerte gemäß konstantentyp_id = 35 (1|-1|-11|0)
     */
    public function internFunction_setSameValueForAllMarkedData() {

        $markedDS = $this->getMarkedDataFromPostarray();
        //PostObjekt holen
        $internPostObject = $this->getPostObject();
        $senderForm_id = $internPostObject->getSenderformId();
        $instance_id = $internPostObject->getSenderInstanceId();           //Instanz des Formulars, in dem der Button gedrückt wurde



        if ($markedDS <> array()) {
            //wenn  mindestens ein markierter Datensatz vorhanden ist
            $form_id = $markedDS[0]["form"];
            $hiddenCurrentDate = $this->getFormPropertyCurrentDate($form_id);
            $button_name = $internPostObject->getSenderButtonName();
            $button_properties = $this->getFormPropertyButton($form_id, $instance_id, $button_name);
            $target_column = $button_properties["feld.db_column"];
            $target_value = $button_properties["feld.vorgabewert"];

            //Datensätze bereinigen -> In kombinierten Parent+Child-Formularen kann es vorkommen, dass auch Daten von 
            //Query-basierten Formularen übersandt werden. Diese können durch updateTableData nicht verarbeitet werden,
            //da sie sich i.d.R. nicht nur auf eine DB-Tabelle beziehen. Die Datensätze sind an der fehlenden Schema- und
            //Table-Angabe erkennbar.
            $clearedDatensaetze = $this->clearDatensaetze($markedDS);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> bereinigte Datensätze", $clearedDatensaetze);
            $newDatensaetze = $this->setNewValueInEachDS($clearedDatensaetze, $target_column, $target_value);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Datensätze mit neuem value in Spalte " . $target_column, $newDatensaetze);

            if (count($newDatensaetze) > 0) {
                $feedback_for_update = updateTabledata($newDatensaetze, $this, $this->getActiveUser(), $hiddenCurrentDate);
                if ($feedback_for_update > 0) {
                    $updateresult = 1;
                } else {
                    $updateresult = -1;
                }
            } else {
                $feedback_for_update = -11;
            }
        } else {
            //es ist möglich, dass keine geänderten Datensätze erkannt werden, wenn der Anwender geschützte Felder manipuliert hat (siehe buildArrayWithChangedData)
            $feedback_for_update = -11;                    //Dem Anwender wird bewußt kein Grund genannt. Der Grund kann der Debug-Tabelle entnommen werden.
            $form_id = $senderForm_id;
        }
        //alte Conditions übertragen, damit nach dem Speichern wieder die gleichen Datensätze angezeigt werden
        $this->setDefaultFormProperties();

        $Offset = $this->takeOldValueFromForm($form_id, $instance_id, "form.offset");
        $countData = $this->calculateFormCountData($form_id, $instance_id, $Offset, true);

        return $feedback_for_update;
    }

    /** Entfernt aus dem Array $in_datensaetze alle Elemente, die keine Schema haben.
     * 
     * @param   array  $in_datensaetze  Bsp.: Array
      (
      [0] => Array
      (
      [ds] => 0
      [form] => 684
      [content] => Array
      (
      [app_id] => REQ11
      [id] => 789
      [] => http://localhost/appms/view/page.php?mask=353&maskapp=REQ11&css_app=SYS01&css_id=10
      )

      [schema] =>
      [table] =>
      [hash] => 15f2e8f0afb29dde8bec565dc7eb25eb
      [instance_id] => i0
      [button_used] => 1
      [button_name] => button__id263_0000Form694_1_imaskid353ANDmaskappidREQ11
      )

      [1] => Array
      (
      [ds] => 0
      [form] => 694
      [content] => Array
      (
      [mask_app_id] => REQ11
      [mask_id] => 353
      [role_app_id] => REQ11
      [role_id] => 7
      [access_select] => 1
      [access_update] => 1
      [access_insert] => 0
      [access_delete] => 1
      )

      [schema] => manager
      [table] => role_has_mask
      [hash] => 95f83d30d3213dc9acd8b72d75023930
      [instance_id] => imaskid353ANDmaskappidREQ11
      )

      )
     * @return array                
     */
    private function clearDatensaetze($in_datensaetze) {
        $temp_datensaetze = $in_datensaetze;
        foreach ($temp_datensaetze as $key => $current_datensatz) {
            if ($current_datensatz["schema"] == "") {
                unset($in_datensaetze[$key]);
            }
        }
        return $in_datensaetze;
    }

    /** Setzt für jeden Datensatz in content für die übergebene Spalte ($in_target_column) den Wert von $in_values
     * 
     * @param   array  $in_datensaetze  Bsp.: Array
      (
      [0] => Array
      (
      [ds] => 0
      [form] => 684
      [content] => Array
      (
      [app_id] => REQ11
      [id] => 789
      [] => http://localhost/appms/view/page.php?mask=353&maskapp=REQ11&css_app=SYS01&css_id=10
      )

      [schema] =>
      [table] =>
      [hash] => 15f2e8f0afb29dde8bec565dc7eb25eb
      [instance_id] => i0
      [button_used] => 1
      [button_name] => button__id263_0000Form694_1_imaskid353ANDmaskappidREQ11
      )


      )
     * @return array                
     */
    private function setNewValueInEachDS($in_datensaetze, $in_target_column, $in_value) {
        $temp_datensaetze = $in_datensaetze;
        foreach ($temp_datensaetze as $key => $current_datensatz) {
            foreach ($current_datensatz["content"] as $column => $old_value) {
                if ($column == $in_target_column) {
                    $temp_datensaetze[$key]["content"][$column] = $in_value;
                }
            }
        }
        return $temp_datensaetze;
    }

    /** Ergänzt die Filtercondition zu form.condition(instance)
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @return  int
     */
    public function internFunction_setConditionForFilter() {
        $internPostObject = $this->getPostObject();
        $senderForm_id = $internPostObject->getSenderformId();
        $instance_id = $internPostObject->getSenderInstanceId();           //Instanz des Formulars, in dem dr Button gedrückt wurde
        $connection_id = $this->getFormPropertyConnectionId($senderForm_id);
        $senderForm_app_id = $this->getFormPropertyAppId($senderForm_id);

        $condition_filter = getFilterCondition($connection_id, $internPostObject->getInternPostArray(), $senderForm_app_id, "SQL");
//        $array_filter = getFilterCondition($connection_id, $this->getPostObject()->getInternPostArray(), "ARRAY");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> filter_condition: ', $condition_filter);

        
        
        $this->setDefaultFormProperties();
        
        //Filtercondition zur normalen Condition ergänzen
        $this->setFormPropertyCondition($senderForm_id, $instance_id, $condition_filter, true, "filter");
        
        //Form_mode für aktuelles Formular auf active_filter setzen
        $this->setFormMode($senderForm_id, $instance_id, 4);
        //Formmode für abhängige Formulare auf empty setzen, da noch kein Datensatz gewählt wurde
        $formDependencearray = getDependenceForForms($senderForm_app_id, $this->getMaskProbertyID(), $senderForm_id, "all_references");
        $formDependenceString = changeMultiArrayToSingleArray($formDependencearray, "form_dependence.target_form_id", "form_dependence.target_form_id");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> abhängige Formulare, die auf empty gesetzt werden: ', $formDependenceString);
        $this->setFormModeForGivingFormList($formDependenceString, 5, array($senderForm_id));
        
        

        //Anzahl der Datensätze ermitteln
        $countData = $this->calculateFormCountData($senderForm_id, $instance_id, 0, true);

        if ($countData > 0) {
            return 8;
        } else {
            return -8;
        }
    }

    /** Gibt für eine bestimmte Spalte den AutoIncrement-Wert des letzten Inserts zurück.
     * 
     * @param   string      $in_column      Spaltenname einer AutoIncrement-Spalte
     * @return  mixed                       ID oder false, falls kein Wert für die angegeben Spalte vorhanden ist.
     */
    public function getIdFromAutoIncrementColumn($in_column) {
        if (isset($this->_autoincrementValues[$in_column])) {
            $feedback = $this->_autoincrementValues[$in_column];
        } else {
            $feedback = false;
        }

        return $feedback;
    }

    /** Fügt einen neuen Datensatz, der von einem Formular übergeben wurde, ein. <br />
     * Wenn parallel auch Dateien in der Globalen $_FILES enthalten sind, dann werden die Metadaten der files zu den insert-Daten ergänzt.
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @param   boolean     $in_addFileToDS0            [optional] Gibt an, ob auch die Files im base64-Format selbst zum ersten Datensatz ergänzt werden sollen. [true|false] -> default = false
     * @param   string      $in_columnForFile           [optional] Falls die Dateien zum neuen Datensatzergänzt werden sollen, dann wird $in_fileColumn als Attribut genutzt.
     *                                                  Wenn mehrere Files vorhanden sind, dann $in_fileColumn hochgezählt. 
     *                                                  D.h., die erste Datei landet in $in_fileColumn, die zweite in $in_fileColumn1, die dritte in $in_fileColumn2, usw.
     * @return  integer                                 2 = erfolgreich eingefügt <br>
     *                                                  -2 = insert fehlgeschlagen <br>
     *                                                  -21 = für eine Spalte fehlt die Berechtigung <br>
     *                                                  -23 = Einfügen fehlgeschlagen, Datensatz existiert möglicherweise schon <br>
     *                                                  -24 = für mindestens ein Feld wurde die DB-Spalte nicht angegeben <br>
     *                                                  -151 = Upload einer Datei mit unerlaubten Dateityp <br>
     */
    public function internFunction_insertData($in_addFileToDS0 = false, $in_columnForFile = "file") {
        $mySession = session_class::$session_object->getSessionArrayCurTabAndGlobals();
        //$datensätze = $this->getPostObject()->getChangedData();
        $datensätze = $this->getPostObject()->getNewData();
        $dependedForms = array();
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte mit Datensätze: ', $datensätze);

        if ($datensätze <> array()) {
            //wenn  mindestens ein geänderter Datensatz vorhanden ist



            $firstdatensatz = $datensätze[0];
            $form_id = $firstdatensatz["form"];
            $formArray = $this->getFormArray($form_id);

            //falls Dateien hochgeladen wurden, dann die Dateinamen zu NewData ergänzen und die Dateien in $this->filesBase64 ablegen
            $this->filesBase64 = $this->addUploadedFilesAsBase64ToInsertdata($in_addFileToDS0, $in_columnForFile);
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> FileBase64-Array: ', $this->filesBase64);
            
            if($this->filesBase64 !== false) {                                  //fileBase64 ist nur dann false, wenn ein Problem auftrat. Wenn keine Datei hochgeladen wurde, wird ein leeres Array zurückgegeben
                //datensätze noch einmal neu laden, da durch addUploadedFilesAsBase64ToInsertdata eventuell en Upload-Feld ergänzt wurde.
                $datensätze = $this->getPostObject()->getNewData();

                $instance_id = $this->getPostObject()->getSenderInstanceId();
                if (strpos($instance_id, "new") === false) {
                    //es gibt nichts zu tun
                } else {
                    //"new"-Kürzel von instanz abschneiden
                    $instance_id = substr($instance_id, 0, strlen($instance_id) - 3);
                }





                foreach ($datensätze as $key => $datensatz) {
                    //Datensätze einzeln einfügen (insert)
    //                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> aktueller Datensatz:', $datensatz);

                    //neue Werte für autoincrement-Spalten ermitteln und in $datensatz ergänzen
                    $autoincrementValues = getNextValuesForAutoincrementPKs($formArray);
                    $datensatz_content = array_merge($autoincrementValues, $datensatz["content"]);                  //wenn keys bereits in in_datensatz enthalten sind, werden die autoincrement-Werte nicht übernommen. Dies ist das gewünschte Verhalten, da es sonst zu Problemen beim Update-Modus kommt.
                    $this->_autoincrementValues = $autoincrementValues;
    //                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> datensatz und autoincrementarray für IDs: ', $datensatz_content);



                    //Platzhalter in bestimmten Feldtypen ersetzen
                    $datensatz_content = replacePlaceholderInDataset($formArray, $datensatz_content);

                    //Daten, mit ergänzten autoincrement-Werten wieder im POST-Objekt (changedData und newData) einfügen.
                    $this->getPostObject()->setChangedDataContent($key, $datensatz_content);
                    $this->getPostObject()->setNewDataContent($key, $datensatz_content);

                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Datensatz für InsertData: ', $datensatz_content);
                    $this->setFormPropertyDataFromLastInsert($form_id, $datensatz_content);                     //Daten ablegen, damit später, bspw. beim Mailversand wieder darauf zugegriffen werden kann.
                    $daten = extractDataFromPostarray($datensatz_content, $formArray, $instance_id, $datensatz["ds"], $this);
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Insert Daten: ', $daten);

                    $feedback_for_insert = insertDataIntoDB($daten, $formArray, $mySession['uid'], $this);
                    if ($feedback_for_insert > 0) {
                        $result = $feedback_for_insert;
                        //Liste der abhängigen Formulare ermitteln
                        $dependedForms = $this->getDependedForms($form_id);
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Abhängige Formulare (von dem Formular, in dem Daten eingefügt wurden): ', $dependedForms);
                    } else {
                        $result = $feedback_for_insert;
                    }
                }
            } else {
                $result = -151;     //Datei hat unerlaubten Dateityp
            }
        } else {
            //es ist möglich, dass keine neuen Datensätze erkannt werden, wenn der Anwender geschützte Felder manipuliert hat (siehe buildArrayWithChangedData)
            $result = -23;                    //Dem Anwender wird bewußt kein Grund genannt. Der Grund kann der Debug-Tabelle entnommen werden.
            $form_id = $this->getPostObject()->getSenderformId();
            $formArray = $this->getFormArray($form_id);
            $instance_id = $this->getPostObject()->getSenderInstanceId();
            //"new"-Kürzel von instanz abschneiden
            $instance_id = substr($instance_id, 0, strlen($instance_id) - 3);
            $daten["where_insert"] = $this->getFormInstancePropertyCondition($form_id, $instance_id);   //alte Bedingung wieder herstellen
        }




        //----------------------------------------------------------------------------------------------------------------------
        //Vorbereiten des nächsten Maskenaufrufs. Dabei wird jedoch nur der zuletzt eingefügte Datensatz als condition verwendet
        //----------------------------------------------------------------------------------------------------------------------
        //Formulare für nächsten Aufruf wieder vorbereiten
        $this->setFormModeToPreviousValueForAllForms();                           //alle Formulare
        $this->setFormMode($form_id, $instance_id, $this->getFunctionProp("form_mode"));    //Für den Fall, dass das Formular noch im Modus empty war, wird es nun auf targetFormMode gesetzt.


        if ($formArray["form.behavior_after_insert"] == "lastInsert") {
            //Die eben eingefügten Daten sollen als Conditions für den nächsten Maskenaufbau gelten.

            if ($this->getFormPropertyIsnested($form_id) <> true) {
                $condition = $this->setFormPropertyCondition($form_id, $instance_id, $daten["where_insert"], true, "default");
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Conditions = eben eingefügte Daten in Instanz: ' . $instance_id, $condition);
                //jedoch nicht in abhängige und das aktive Formular
            }
            //alte Filtereinstellungen übernehmen (In refernece-show-Formularen darf jedoch nicht die letzte Condition übernommen werden, da diese der letzten Suche entspricht.)
            $this->takeOldConditions(array_keys($dependedForms + array($form_id => $form_id)));                 //in dem aktuellen und in allen davon abhängigen Formularen dürfen die alten Conditions nicht übertragen werden, da dort der aktuell eingefügt Datensatz, als Condition verwendet werden muss.
            $this->takeOldDefaultValuesForInsert(array_keys($dependedForms + array($form_id => $form_id)));
        } elseif ($formArray["form.behavior_after_insert"] == "oldConditionAndLastInsert") {
            //Die eben eingefügten Daten und die alten Conditions sollen gemeinsam als Conditions für den nächsten Maskenaufbau gelten.

            if ($this->getFormPropertyIsnested($form_id) <> true) {
                //nun den eben eingefügten Datensatz zusätzlich mit OR-Verknüpfung ergänzen
                $condition = $this->setFormPropertyCondition($form_id, $instance_id, $daten["where_insert"], false, "default", "OR");
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Conditions = eben eingefügte Daten und alte Condition in Instanz: ' . $instance_id, $condition);
            }

            if ($formArray["form_dependence.dependence_type"] != "") {
                //(in refernece-show-Formularen darf jedoch nicht die letzte Condition übernommen werden, da diese der letzten Suche entspricht.)
                //in dem aktuellen und in allen davon abhängigen Formularen dürfen die alten Conditions nicht übertragen werden, da dort der aktuell eingefügt Datensatz, als Condition verwendet werden muss.
                $additional_dependedForms = array($form_id => $form_id);
            } else {
                $additional_dependedForms = array();
            }
            //alte Filtereinstellungen übernehmen 
            $this->takeOldConditions(array_keys($dependedForms + $additional_dependedForms), "OR");
            $this->takeOldDefaultValuesForInsert(array_keys($dependedForms));               //jedoch nicht in abhängige Formulare
        } else {
            //die alten Conditions sollen weiter gelten
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Conditions', "alte Conditions in allen Formularen und Instanzen übertragen");
            $this->takeOldConditions();
            $this->takeOldDefaultValuesForInsert();
        }



        $Offset = $this->takeOldValueFromForm($form_id, $instance_id, "form.offset");
        $countData = $this->calculateFormCountData($form_id, $instance_id, $Offset, false);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Formular mit Condition: ', $this->getFormArray($form_id));

        return $result;
    }

    /** Fügt einen neuen Datensatz ein. Wenn dieser bereits existiert, dann wird ein Update versucht<br />
     * Die Funktion nutzt die Funktionen <br />
     * - internFunction_insertData und <br />
     * - internFunction_saveData <br />
     * <br />
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @param   boolean     $in_addFileToDS0            [optional] Gibt an, ob auch die Files im base64-Format selbst zum ersten Datensatz ergänzt werden sollen. [true|false] -> default = false
     * @param   string      $in_columnForFile           [optional] Falls die Dateien zum neuen Datensatzergänzt werden sollen, dann wird $in_fileColumn als Attribut genutzt.
     *                                                  Wenn mehrere Files vorhanden sind, dann $in_fileColumn hochgezählt. 
     *                                                  D.h., die erste Datei landet in $in_fileColumn, die zweite in $in_fileColumn1, die dritte in $in_fileColumn1, usw.
      @return  integer                                   Alle Returncodes von saveData oder insertData
     */
    public function internFunction_insertDataOrUpdate($in_addFileToDS0 = false, $in_columnForFile = "file") {
        //Wenn neue Datensätze vorhanden sind, dann insert, ansonsten update
        $datensätze = $this->getPostObject()->getNewData();
        if (count($datensätze) > 0) {
            //neue Datensätze sind vorhanden. Daher klassischen insert durchführen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "neue Datensätze vorhanden, daher insert");
            $feedback = $this->internFunction_insertData($in_addFileToDS0, $in_columnForFile);
        } else {
            //changedData als Basis für neue Datensätze verwenden 
            $datensätze = $this->getPostObject()->getChangedData();
            if (count($datensätze) > 0) {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "es sind keine neuen Datensätze, jedoch geänderte Datensätze vorhanden. Dennoch wird insert versucht.");
                $this->getPostObject()->setNewData($datensätze);
                $feedback = $this->internFunction_insertData($in_addFileToDS0, $in_columnForFile);
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "es sind keine neuen oder geänderten Datensätze vorhanden.", "ERROR");
                $feedback = -11;
            }

            if ($feedback < 0 AND $feedback != -11) {
                //insert schlug fehl. Daher Update versuchen
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Insert war nicht erfolgreich. Dennoch wird update versucht.");
                $feedback = $this->internFunction_saveData();
            }
        }

        return $feedback;
    }
    
    
    
    /** Speichert einen Datensatz, wenn dieser existiert, auch wenn er als neuer Datensatz übergeben wird. Falls er nicht existiert, wird ein Insert versucht.<br />
     * Die Funktion nutzt die Funktionen <br />
     * - internFunction_insertData und <br />
     * - internFunction_saveData <br />
     * <br />
     * 
     * ACHTUNG: Die Suche nach "Verwendung" wird möglicherweise zu keinem Treffer in dem Programmcode führen.
     * Die Funktion wird über die DB-Tabelle "button_function" einem Button zugeordnet und dann über $this->callFunction aufgerufen.
     *
     * @param   boolean     $in_addFileToDS0            [optional] Gibt an, ob auch die Files im base64-Format selbst zum ersten Datensatz ergänzt werden sollen. [true|false] -> default = false
     * @param   string      $in_columnForFile           [optional] Falls die Dateien zum neuen Datensatzergänzt werden sollen, dann wird $in_fileColumn als Attribut genutzt.
     *                                                  Wenn mehrere Files vorhanden sind, dann $in_fileColumn hochgezählt. 
     *                                                  D.h., die erste Datei landet in $in_fileColumn, die zweite in $in_fileColumn1, die dritte in $in_fileColumn1, usw.
      @return  integer                                   Alle Returncodes von saveData oder insertData
     */
    public function internFunction_updateDataOrInsert($in_addFileToDS0 = false, $in_columnForFile = "file") {
        //Wenn neue Datensätze vorhanden sind, wird dennoch zuerst update versucht.
        $datensätze = $this->getPostObject()->getNewData();
        if (count($datensätze) > 0) {
            //neue Datensätze sind vorhanden. Daher klassischen insert durchführen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "neue Datensätze sind vorhanden, dennoch zuerst update versuchen ");
            $this->getPostObject()->setChangedData($datensätze);
            $feedback_save = $this->internFunction_saveData();
            
            //if ($feedback < 0) {
                //Trotz Update-Versuch wird Insert versucht. Das kann notwendig sein, da Update auch 0 Änderungen vorgenommen haben kann.
                //Wenn Update erfolgreich war, dann sollte der folgende Insert-Befehl einen Fehler verursachen und somit keine Wirkung haben.
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Update durchgeführt, dennoch Insert versuchen, update 0 Treffer gehabt haben kann.");
                $feedback_insert = $this->internFunction_insertData($in_addFileToDS0, $in_columnForFile);

            //}
        } else {
            //es gibt keine neuen Datensätze, daher Update durchführen.
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Es sind keine neuen Daten vorhanden, daher Update versuchen.");
            $feedback_save = $this->internFunction_saveData();
        }
        
        
        if(isset($feedback_save)) {
            $feedback = $feedback_save;
        } else {
            $feedback = $feedback_insert;
        }
        
        return $feedback;
    }
    
    
    

    /** Ergänzt eine neue Maske/Seite
     * Dabei werden folgende Schritte ausgeführt:
     * 1. neue Maske anlegen
     * 2. Maske für gewünschte Rolle freischalten
     * 3. Maskenelementgruppe wird anlegen
     * 4. Maskenelementgruppe der neuen Maske zuordnen
     * 5. Grundgerüst (ebenfalls eine Maskenelementgruppe) wird der Maske zugeordnet
     * 
     * @return  integer                     	2010 = erfolgreich ; -2010 = fehlgeschlagen; Details werden in die Debug-Tabelle geschrieben
     */
    public function internFunction_addNewMask() {
        require_once("../controller/mask_class.php");

        $feedback = 0;
        $result = 0;

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Starte Funktion', __FUNCTION__);

        //Daten aus Post (von Formular "neue Seite") auslesen
        $newMaskdata = $this->getMarkedDataFromPostarray();
        $newMaskdata = $newMaskdata[0]["content"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> newMaskdata: ', $newMaskdata);
        $new_app_id = $newMaskdata["app_id"];
        //Schema der neuen Maske anhand der app_id ermitteln -> wenn eine app mehrere Schemata hat, wird das erste ermittelt.
        $dbSchema_from_new_mask = getDataFromTableByID(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "app_schema", "db_schema", "app_id = '" . $new_app_id . "'");
        $css_template_app_id = $newMaskdata["css_template_app_id"];
        $template_id = $newMaskdata["css_template_id"];
        $name = $newMaskdata["site_name"];
        $link = "page.php";
        $parent_site = $newMaskdata["parent_site"];
        $sort = $newMaskdata["sort"];
        $navgroup = "";             //Könnte auch dynamisch übergeben werden. -> $newMaskdata["nav_menu_group"];
        $navgroupsort = "";         //Könnte auch dynamisch übergeben werden. -> $newMaskdata["nav_group_sort"];
        //1. Maske in Tabelle mask anlegen und id aufnehmen; 
        //   Dabei wird auch eine htmltaggroup für weitere Maskenelemente angelegt sowie
        //   Die Maskenelementgruppe "Grundgerüst" zugeordnet.
        try {
            $my_site = new mask($this);
            $my_site->addNewMask($new_app_id, $css_template_app_id, $template_id, $name, $link, $new_app_id, $parent_site, $sort, $navgroup, $navgroupsort);
            $mask_id = $my_site->getMaskID();
            $htmltaggroupForForms_id = $my_site->getHtmltaggroupIDForForms();
        } catch (Exception $exc) {
            $result = $exc->getMessage();
        }





        if ($result >= 0) {
            //2. Zugriffsrecht für Rolle setzen
            $role_id = $newMaskdata["role"];
            if ($my_site->addAccessToMask($this, $new_app_id, $role_id, true, true, true, true) == false) {
                $feedback = -2011;
            }
        }






        if ($result < 0) {
            //99. wieder aufräumen
            $my_site->deleteMask($name);
            $feedback = $result;
        } else {

            //Wenn die active-role des angemeldeten Users der gerade zugeordneten Rolle entspricht, dann kann die neue Maske  aufgerufen werden.
            if ($this->getActiveRoleAppIdFromSession() == $new_app_id AND $this->getActiveRoleIdFromSession() == $role_id) {
                $feedback = 2010;
                $feedbacktextarray = getFeedbacktextForFunction($feedback, global_variables::getAppIdFromSYS01());
                $feedbacktext = $feedbacktextarray[0]["konstante.klartext"];

                $this->reloadMask($my_site->getMaskAppID(), __FUNCTION__, $my_site->getMaskID(), $feedbacktext);
            } else {
                $feedback = 2011;
            }
        }


        return $feedback;
    }

    /** Ergänzt eine neue APP
     * Dabei werden folgende Schritte ausgeführt:
     * 1. neuen Datensatz in Tabelle APP anlegen
     * 2. neuen Datensatz in Tabelle app_Schema anlegen
     * 3. Systemnutzer (app_id]root und [app_id]admin anlegen
     * 4. Systemrollen zuordnen
     * 5. Fachadminrolle anlegen und zuordnen
     * 
     * @return  integer                     	2010 = erfolgreich ; -2010 = fehlgeschlagen; Details werden in die Debug-Tabelle geschrieben
     */
    public function internFunction_addNewAPP() {
        require_once("../controller/app_class.php");

        $feedback = 0;
        $result = 0;

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Starte Funktion', __FUNCTION__);

        //Daten aus Post (von Formular "neue Seite") auslesen
        $newData = $this->getMarkedDataFromPostarray();
        $newData = $newData[0]["content"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> newAppdata: ', $newData);
        $new_app_id = $newData["app.id"];

        //1. APP in Tabelle app anlegen
        //   Dabei werden auch app_schema, Default-user und Rollenzuordnung, das data-Verzeichnis und die Config-Datei angelegt.
        Try {
            $my_app = new app($this, $new_app_id);
            
            $my_app->addNewAPP( $newData["app.name"], 
                                $newData["app.description"], 
                                $newData["app_schema.name"], 
                                $newData["app_schema.external_administrated"],
                                $newData["dbms"],
                                $newData["host"],
                                $newData["port"],
                                $newData["dbname"],
                                $newData["user"],
                                $newData["password"]);
        } catch (Exception $exc) {
            $result = $exc->getMessage();
        }








        if ($result >= 0) {
            //99. wieder aufräumen
//            $my_site->deleteMask($name);
            $feedback = 2001;
        } else {


            $feedback = -2001;
        }


        return $feedback;
    }
    
    
    
    
    
    
    /** Lädt eine Datei herunter, die sich in im Dateisystem des Servers befindet.
     * Dem Formular, welches die Funktion aufruft, muss auf der Datenbanktabelle basieren, in der die Dateien verwaltet werden.
     * Bsp.: manager.files. Im Datensatz müssen mindestens die Spalten id, filetype und filename enthalten sein.
     * Darüber hinaus sollte eine Spalte enthalten sein, über die der relative Pfad, inkl. Dateiname, enthalten ist.
     * Default: path_and_filename. Abweichende Spalten können über den Vorgabewert des Buttons angelegt werden .
     * Bsp.: path+filename => der relative Pfad ergibt sich aus der Spalte "path", der Dateiname ist in der Spalte "filename" enthalten.
     * 
     * @return type
     */
    public function internFunction_downloadFile() {
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Starte Funktion', __FUNCTION__);

        
        
        //PostObjekt holen
        $internPostObject = $this->getPostObject();
        $form_id = $internPostObject->getSenderformId();
        $app_id = $this->getFormPropertyAppId($form_id);
        $senderDS = $internPostObject->getDSwhereButtonUsed();

        if ($senderDS != false) {
            //Daten des gesuchten Files aus der Tabelle des Sender-Formulars ermitteln
            $id_column = issetKeyLike($senderDS["content"], ".id");
            $condition = "id=" . $senderDS["content"][$id_column];
            $myFileList = getTableData($app_id, $senderDS["table"], $senderDS["schema"], 0, "", $condition, __FUNCTION__);
                
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__."myFileList: ", $myFileList);
            
            if ($myFileList != array()) {
                $myFile = $myFileList[0];
                
                //Pfad und Dateiname ermitteln
                $in_fileAndPathColumn = $this->getFunctionProp("feld.vorgabewert");
                $pathAndFilename = $this->getPathAndFileFromDS($in_fileAndPathColumn, $myFile); //ToDo: Macht diese flexible Lösung Sinn, wenn später ohnehin fix die Spalte filename erwartet wird?
                
                //File prüfen
                $install_path = global_variables::getPathForAppmsinstall_abs(true);
                if(file_exists($install_path.$pathAndFilename)) {
                    //Datei senden
                    $data = file_get_contents($install_path.$pathAndFilename);
                    $file_format = $myFile[$senderDS["table"] . ".filetype"]; 
                    $filename = $myFile[$senderDS["table"].".filename"];
                    $this->sendFileToClient($file_format, $filename, $data);
                } else {
                    //Datei nicht gefunden
                    $feedback = -154;
                }
                
                
                
            }
//        //Nach dem Dateidownload abbrechen, damit alte Webseite stehen bleibt.
            exit();
        }

        //Dieser Abschnitt wird nur erreicht, wenn die Datei nicht gefunden wurde.
        $feedback = -4;    //->kein Datensatz gewählt


        return $feedback;

        
    }
    
    
    
    
    /** ermittelt aus einem Datensatz, Pfad und Dateiname. 
     * 
     * @param   string  $in_fileAndPathColumn       Enthält die Angabe, aus welchen Spalten path und filenmae ermittelt werden sollen.
     *                                              Wenn false angegeben wird, dann wird die Spalte path_and_file gesucht.
     *                                              Ansonsten kann bspw. pathname+filename angegeben werden. Dann werden die values dieser 
     *                                              beiden Spalten zusammengefügt. Es können beliebig viele Spalten mit "+" kombiniert werden.
     * @param   array   $in_fileData                Datensatz, anhand dessen path and filename gebildet werden. Der Datensatz sollte bspw. wie folgt aussehen:
                                                    Array
                                                           (
                                                               [files.id] => 57
                                                               [files.filename] => logo.png
                                                               [files.pathname] => data/SYS01/img/
                                                               [files.filetype] => image/png
                                                           )
     * @return type
     */
    private function getPathAndFileFromDS($in_fileAndPathColumn, $in_fileData) {
        //path_and_file ermitteln
        If($in_fileAndPathColumn === false) {$in_fileAndPathColumn = "path_and_file";}    //Defaultwert
        //hier weiter: path and file muss aus Vorgabewert ermittelt werden. Laut Query ist es vorhanden, fehlt jedoch im Datensatz -> neues Feld schaffen
        if(strpos($in_fileAndPathColumn, "+")) {
            //Wenn path and file aus mehreren Spalten zusammengesetzt werden soll
            $columnlist = explode("+", $in_fileAndPathColumn);
            foreach ($columnlist as $column) {
                //Spalte im aktuellen DS suchen
                $columnname = issetColumnnameLike($in_fileData, $column);
                if($columnname !== false) {
                    $path_and_file = $path_and_file.$in_fileData[$columnname];
                }
            }
        } else {
            $path_and_file = $in_fileData[$in_fileAndPathColumn];
        }
        
        return $path_and_file;
    }
    
    
    

    /** Ergänzt ein neues Formular
     * Dabei werden folgende Schritte ausgeführt:
     * 1. neues Formular anlegen
     * 2. Html-Tag anlegen
     * 3. Zuordnung zur Maskenelementgruppe der gewünschten Maske
     * 4. Zuordnung eines Styles
     * 5. Zuordnung von Symbolleisten
     * 6. [ggf.] Erstellung eines ersten labels mit Hinweis auf Erstellung von neuen Feldern. Vielleicht kann das auch ein einfacher
     *    Standardtext sein, der bei bestimmten Konstruktoren immer erscheint, wenn keine Felder gefunden werden.
     * 
     * @return  integer                     	2010 = erfolgreich ; -2010 = fehlgeschlagen; Details werden in die Debug-Tabelle geschrieben
     */
    public function internFunction_addNewForm() {
        require_once("../controller/mask_class.php");
        require_once("../controller/form_class.php");

        $feedback = 0;
        $result = 0;

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Starte Funktion', __FUNCTION__);

        //Daten aus Post (von Formular "neues Formular") auslesen
        $newFormdata = $this->getMarkedDataFromPostarray();
        $newFormdata = $newFormdata[0]["content"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> newFormdata: ', $newFormdata);
        $app_id = $newFormdata["app_id"];

        $form_name = $newFormdata["name"];
        $neightbore_form_id = $newFormdata["after_form_id"];
        $place_relative_to_neightbore = 'after';
        $mask_id = $newFormdata["mask_id"];

        $parent_dom_node_array = global_variables::getDefaultDomNodeForForms($app_id);
        $parent_dom_node = $parent_dom_node_array["id"];

        //1. Formular anlegen und id aufnehmen; 
        try {
            $my_form = new form($this);
            $my_form->addNewForm($app_id,
                    $form_name,
                    $newFormdata["headline_activate"],
                    $newFormdata["constructor"],
                    "",
                    $newFormdata["db_schema"],
                    $newFormdata["db_table"],
                    $newFormdata["query_app_id"],
                    $newFormdata["query_id"],
                    $newFormdata["order_by"],
                    $newFormdata["default_condition"],
                    0,
                    "",
                    "",
                    $newFormdata["logging"],
                    $newFormdata["log_id_spalte"],
                    $newFormdata["default_form_mode"],
                    $newFormdata["default_limit"],
                    $newFormdata["behavior_after_insert"],
                    $newFormdata["width"],
                    $parent_dom_node,
                    "",
                    "");
            $form_id = $my_form->getFormID();
            $htmltag_id = $my_form->getHtmltagID();

            //2. Maskenobjekt verknüpfen
            $my_mask = new mask($this, $app_id, $mask_id);

            //3. htmltag des Formulars der Maskenelemtgruppe der Maske hinzufügen
            // Htmltaggroup, in dem das Formular/ der Artikel eingebunden werden soll, ermitteln.
            if ($neightbore_form_id != "") {
                //Wenn bereits ein Formular der htmlgroup bekannt ist
                $htmltaggroupForForms = getHtmltaggroupFromMaskAndForm($app_id, $mask_id, $app_id, $neightbore_form_id);
            } else {
                //wenn kein Formular angegeben wurde
                $htmltaggroupForForms = getHtmltaggroupFromMask2($app_id, $mask_id, "MEGruppe Seite");
            }
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> htmltaggroupForForms_data: ', $htmltaggroupForForms);
            $htmltaggroupForForms_id = $htmltaggroupForForms[0]["htmltaggroup.id"];
            if ($my_mask->addHtmlTagToHtmlTaggroup($htmltaggroupForForms_id, $app_id, $app_id, $htmltag_id, 1, 1, 1) == false) {
                $feedback = -2016;
            }

            //4. ggf. Formulare neu Sortieren
            if ($neightbore_form_id != "") {

                //Sortierung neu festlegen
                $htmltag_id_from_neighbore = getDataFromTableByID(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "html_tag", "id", "form_app_id = '" . $app_id . "' AND form_id = " . $neightbore_form_id);
                if (reSortInHtmlTagGroup($this, $htmltag_id, $htmltag_id_from_neighbore, $place_relative_to_neightbore, $htmltaggroupForForms_id, $app_id) == false) {
                    $feedback = -2031;
                }
            }

            //5. Dem Formular ein Style-Element zuordnen
            $my_form->addStyleElement($newFormdata["style_element_app_id"], $newFormdata["style_element_id"]);

            //6. Symbolleisten ergänzen
            for ($i = 1; $i <= 4; $i++) {
                if ($newFormdata["symbolrow_top_" . $i] <> "") {
                    $my_form->addSymbolgroup($newFormdata["app_symbolleisten"], $newFormdata["symbolrow_top_" . $i], $i, 1);
                }
                if ($newFormdata["symbolrow_bottom_" . $i] <> "") {
                    $my_form->addSymbolgroup($newFormdata["app_symbolleisten"], $newFormdata["symbolrow_bottom_" . $i], $i, 2);
                }
            }
        } catch (Exception $exc) {
            $result = $exc->getMessage();
        }


        return $feedback;
    }
    
    
    
    
    
    /**
     * 
     * @return integer          siehe Konstantentyp_id = 35 -> mögliche Werte [-2|910|-910]
     */
    public function internFunction_copyFormFields() {
        require_once("../controller/form_class.php");
        

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Starte Funktion', __FUNCTION__);

        //Daten aus Post (von Formular "neues Formular") auslesen
        $markedData = $this->getMarkedDataFromPostarray();
        $formdata = $markedData[0]["content"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Formdata: ', $formdata);
        $source_app_id = $formdata["source_app_id"];
        $source_form_id = $formdata["source_form_id"];
        $target_app_id = $formdata["form.app_id"];
        $target_form_id = $formdata["form.id"];
        


        if($source_app_id != "" AND $source_form_id != "") {
            $my_form = new form($this);
            $feedback = $my_form->copyFieldsToForm($source_app_id, $source_form_id, $target_app_id, $target_form_id);
        } else {
            $feedback = -2;
        }
        
        
        //alte Conditions übertragen, damit nach dem Speichern wieder die gleichen Datensätze angezeigt werden
        $this->setDefaultFormProperties();
        

        return $feedback;
    }
    
    
    
    

    /** Ergänzt eine neue Symbolleiste.
     * Dabei werden folgende Schritte ausgeführt <br />
     * 1. neuen Datensatz in form (Symbolleiste) anlegen <br />
     * 2. Symbolleiste mit Maske "Symbolleisten prüfen" verknüpfen <br />
     * 3. htmltaggroup (Maskenelement) für Symbolleiste anlegen <br />
     * 4. Der Symbolleiste ein Style-Element zuordnen <br />
     * @return  integer                     	2013 = erfolgreich ; -2013/-2019 = fehlgeschlagen; Details werden in die Debug-Tabelle geschrieben
     */
    public function internFunction_addNewSymbolgroup() {
        require_once("../controller/mask_class.php");
        require_once("../controller/form_class.php");

        $feedback = 0;
        $result = 0;

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Starte Funktion', __FUNCTION__);

        //Daten aus Post (von Formular "neue Symbolleiste") auslesen
        $newSymbolgroup = $this->getNewDataFromPostarray();
        $newSymbolgroup = $newSymbolgroup[0]["content"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> newSymbolgroup:', $newSymbolgroup);
        $app_id = $newSymbolgroup["form.app_id"];

        $form_name = $newSymbolgroup["form.name"];

//Symbolleisten werden fix der Maske 37 (Symbolleisten prüfen) zugeordnet.
        $mask_for_check_symbolgroup = global_variables::getDefaultMaskInfos($app_id, "symbolgroup_mask");
        $mask_id = $mask_for_check_symbolgroup["id"];
        $mask_app_id = $mask_for_check_symbolgroup["app_id"];

        $parent_dom_node_array = global_variables::getDefaultDomNodeForForms($app_id);
        $parent_dom_node = $parent_dom_node_array["id"];

        //1. Formular anlegen und id aufnehmen; 
        try {
            $my_form = new form($this);
            $my_form->addNewForm($app_id,
                    $form_name,
                    1,
                    "SymbolGroup",
                    $newSymbolgroup["form.description"],
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    0,
                    "",
                    "",
                    0,
                    "",
                    1,
                    "",
                    "oldCondition",
                    "",
                    $parent_dom_node,
                    "",
                    "");
//            $form_id = $my_form->getFormID();
            $htmltag_id = $my_form->getHtmltagID();

            //2. Maskenobjekt verknüpfen (Symbolleisten prüfen)
            $my_mask = new mask($this, $mask_app_id, $mask_id);
            // Htmltaggroup, in dem Symbolleiste eingebunden werden soll, ermitteln.
            // Alle Symbolleisten werden ab 23.07.2020 in der Maskenelementgruppe der Maske "Symbolleisten prüfen" eingebunden. Ältere 
            // Symbolleisten wurden über jeweils eigene Maskenelemntgruppen der gleichen Maske zugeordnet.
            $htmltaggroupForForms = getHtmltaggroupFromMask2($mask_app_id, $mask_id, "MEGruppe Seite Symbolleisten prüfen");
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> htmltaggroupForForms_data: ', $htmltaggroupForForms);
            $htmltaggroupForForms_id = $htmltaggroupForForms[0]["htmltaggroup.id"];
            if ($my_mask->addHtmlTagToHtmlTaggroup($htmltaggroupForForms_id, $mask_app_id, $app_id, $htmltag_id, 1, 1, 1) == false) {
                $feedback = -2019;
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Symbolleiste wurde der Maske Symbolleisten-prüfen hinzugefügt.");
            }


            //3. eigene Maskenelementgruppe für die Symbolleiste erzeugen, damit dieses später anderen Masken/Formularen zugeordnet werden kann.
            $htmltaggroup_id = setNewHtmlTagGroup($this, $app_id, $form_name, 1);
            if ($htmltaggroup_id !== false) {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "HtmlTagGroup angelegt: " . $htmltaggroup_id);
                $feedback = setHtmlTagToHtmlTaggroup($this, $htmltaggroup_id, $htmltag_id, $app_id, $app_id, 1, 1, 1);
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "HtmlTagGroup konnte nicht angelegt werden!", "ERROR");
                $feedback = -2013;
            }

            //4. Dem Formular ein Style-Element zuordnen
            $style = global_variables::getDefaultStyleForForm($app_id, "default_symbolgroup_style");
            $my_form->addStyleElement($style["app_id"], $style["id"]);
        } catch (Exception $exc) {
            $result = $exc->getMessage();
        }

        return $feedback;
    }

    /** Fügt einem Formular eine beliebige Eigenschaft hinzu.
     * 
     * @param   integer     $in_formID          ID des Formulars, zu dem eine Eigenschaft ergänzt werden soll
     * @param   string      $in_instanceID      ID der Instanz des Formulars
     * @param   string      $in_propertyname    Beliebiger Name, unter dem die Eigenschaft abgespeichert werden soll
     * @param   mixed       $in_value           Ein Wert, der abgespeichert werden soll
     */
    public function setFormProperty($in_formID, $in_instanceID, $in_propertyname, $in_value) {
        $this->_formsArray[$in_formID]["form.instances"][$in_instanceID][$in_propertyname] = $in_value;
    }

    /** Fügt dem Formular eine Breite im Attribut form.width_calculated im Format ###px hinzu.
     * 
     * @param   integer     $in_formID
     * @param   integer     $in_value       Breite in Pixeln
     */
    public function setFormPropertyCalculatedWidth($in_formID, $in_value) {
        $this->_formsArray[$in_formID]["form.width_calculated"] = $in_value . "px";
    }

    /** Fügt dem Formular die Formulareigenschaft "controlform" hinzu.
     * 
     * @param   integer     $in_step        Workflow-Step  
     * @param   array       $in_value       Array mit den Angaben zum Controlform; Array ( step => 1, form_app_id=> SYS01, form_id => 1304, is_workf_control_form => 1)
     */
    public function setFormPropertyWorkflowControlform($in_step, $in_value) {
        $this->_formsArray["workflow"][$in_step]["controlform"] = $in_value;
    }

    /** Gibt das Controlformular für einen bestimmten Workflow-Step zurück.
     * 
     * @param   integer     $in_step        Workflow-Step  
     * @return  mixed                       Array mit den Angaben zum Controlform; Array ( step => 1, form_app_id=> SYS01, form_id => 1304, is_workf_control_form => 1) oder false, wenn Control-Form nicht vorhanden.
     */
    public function getFormPropertyWorkflowControlform($in_step) {
        if (isset($this->_formsArray["workflow"][$in_step]["controlform"])) {
            return $this->_formsArray["workflow"][$in_step]["controlform"];
        } else {
            return false;
        }
    }

    /** Gibt die Breite eines Formulars in Pixeln zurück; Format = ###px.
     * Die Breite wird aus der Eigenschaft form.width_calculated entnommen.
     * Wenn die Eigenschaft nicht existiert wird "auto" zurückgegeben.
     * 
     * @param   integer     $in_formID
     * @return  string      Bsp.: "1000px" oder "auto"
     */
    public function getFormPropertyCalculatedWidth($in_formID) {
        if (isset($this->_formsArray[$in_formID]["form.width_calculated"])) {
            return $this->_formsArray[$in_formID]["form.width_calculated"];
        } else {
            return "auto";
        }
    }

    /** Gibt das Multi-Array der Eigenschaft queryDependenceCondition zurück. Wenn die Eigenschaft für das gegebene Formular
     * nicht ermittelt werden kann, wird ein leeres Array zurückgegeben.
     * 
     * @param   integer     $in_form_id                 ID des Formulars, zu dem eine Eigenschaft ergänzt werden soll
     * @param   integer     $in_trigger_form_id         ID des Trigger-Formulars. Wenn es kein Triggerformular gibt, dann Leerstring übergeben. In dem Fall bit die Funktion ein leeres Array als Ergebnis zurück.
     * @return  array                                   Array mit folgendem Aufbau: 
     *                                                  Array(0) =>
      (
      [sourcetable] => account_has_role
      [sourcecolumn] => role_app_id
      [targettable] => role
      [targetcolumn] => app_id
      [value] => WIDER
      )
     * 
     */
    public function getFormPropertyQueryCondition($in_form_id, $in_trigger_form_id) {

        if ($in_trigger_form_id <> "") {
            //Trigger_form_id existiert nur bei abhängigen Formularen
            if (isset($this->_formsArray[$in_trigger_form_id]["form_dependence.target_forms"][$in_form_id]["queryDependenceCondition"])) {
                return $this->_formsArray[$in_trigger_form_id]["form_dependence.target_forms"][$in_form_id]["queryDependenceCondition"];
            }
        }

        return array();
    }

    /** Setzt die Eigenschaft CountData für eine Instanz eines Formulars
     * 
     * @param integer   $in_formID
     * @param string    $in_instanceID
     * @param integer   $in_countData
     */
    public function setFormPropertyCountData($in_formID, $in_instanceID, $in_countData) {
        $this->_formsArray[$in_formID]["form.instances"][$in_instanceID]["form.countData"] = $in_countData;
    }

    /** Initialisiert die Eigenschaft ["form_dependence.target_forms"][target_form_id] für ein Formular
     * Diese Multivalue-Eigenschaft ist vorerst nur eine leere Hülse, welche später durch 
     *    - setFormPropertyValueForDependingForm()
     * weiter aufgefüllt wird.
     * 
     * @param integer   $in_formID
     * @param array     $in_targetForms             Array der abhängigen Formulare; Bsp.: array(23, 35, 78)
     */
    public function setFormPropertyTargetForms($in_formID, $in_targetForms) {
        if (isset($this->_formsArray[$in_formID]["form_dependence.target_forms"]) == true) {
            //Wenn schon ein Array an der Stelle existiert, bspw. aus der Funktion internFunction_setConditionForDetaileddata, dann mit dem neuen zusammenführen
            //Die Funktion array_merge kann dafür nicht genutzt werden, da diese neu indexiert und damit die Information der target_form_id verloren gehen würde.
            $this->_formsArray[$in_formID]["form_dependence.target_forms"] = $this->_formsArray[$in_formID]["form_dependence.target_forms"] + $in_targetForms;
        } else {
            $this->_formsArray[$in_formID]["form_dependence.target_forms"] = $in_targetForms;
        }
    }

    /** Gibt den OffsetWert für die übergebene Form_id zurück.
     * 
     * @param   integer     $in_formID          ID des Formulars
     * @param   string      $in_instance_id     Instanz des Formulars
     * @return  integer                         aktueller Offset-Wert des Formulars.
     */
    public function getFormPropertyOffset($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.offset"])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.offset"];
        } else {
            return 0;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt den OffsetBackWert für die übergebene Form_id zurück.
     * 
     * @param   integer     $in_formID          ID des Formulars
     * @param   string      $in_instance_id     Instanz des Formulars
     * @return  mixed                           aktueller Offset-Back-Wert des Formulars oder false.
     */
    public function getFormPropertyOffsetBack($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.offset_back"])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.offset_back"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt den OffsetForwardWert für die übergebene Form_id zurück.
     * 
     * @param   integer     $in_formID          ID des Formulars
     * @param   string      $in_instance_id     Instanz des Formulars
     * @return  mixed                           aktueller Offset-Forward-Wert des Formulars oder false.
     */
    public function getFormPropertyOffsetForward($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.offset_forward"])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.offset_forward"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die Eigenschaft current_first_ds für die übergebene Form_id zurück.
     * 
     * @param   integer     $in_formID          ID des Formulars
     * @param   string      $in_instance_id     Instanz des Formulars
     * @return  mixed                           aktueller current_first_ds des Formulars oder false.
     */
    public function getFormPropertyCurrentFirstDS($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.current_first_ds"])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.current_first_ds"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die Eigenschaft current_last_ds für die übergebene Form_id zurück.
     * 
     * @param   integer     $in_formID          ID des Formulars
     * @param   string      $in_instance_id     Instanz des Formulars
     * @return  mixed                           aktueller current_first_ds des Formulars oder false.
     */
    public function getFormPropertyCurrentLastDS($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.current_last_ds"])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.current_last_ds"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die Eigenschaft currentDate für die übergebene Form_id zurück. Wenn im aktuellen Array kein Wert vorhanden ist, wird das currentDate aus dem Session_backup für das Formular
     * ermittelt. Ist auch dort kein Wert vorhanden, wird das heutige Datum zurückgegeben.
     * 
     * @param   integer     $in_formID          ID des Formulars
     * @return  date                            aktuelles currentDate des Formulars oder aktuelles Tagesdatum, wenn currentDate im Form_array oder Session_backup nicht vorhanden ist.
     */
    public function getFormPropertyCurrentDate($in_formID) {
        if (isset($this->_formsArray[$in_formID]["currentDate"])) {
            //Wenn die Eigenschaft im aktuellen Formular existiert, wird sie zurückgegeben
            return $this->_formsArray[$in_formID]["currentDate"];
        } else {
            $oldCurrentDate = $this->takeOldValueFromForm2($in_formID, "currentDate");
            if ($oldCurrentDate <> false) {
                //Wenn im Session_backup ein currentDate ermittelt werden konnte
                return $oldCurrentDate;
            } else {
                //Wenn kein Datum ermittelt werden konnte, wird das heutige Datum zurückgegeben
                return date("Y-m-d");
            }
        }
    }

    /** Gibt den limit-Wert für die übergebene Form_id zurück.
     * 
     * @param   integer     $in_formID          ID des Formulars
     * @return  integer                         aktueller limit-Wert des Formulars.
     */
    public function getFormPropertyLimit($in_formID) {
        if (isset($this->_formsArray[$in_formID]["form.limit"])) {
            return $this->_formsArray[$in_formID]["form.limit"];
        } else {
            return 0;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }
    
    
    
    /** Setzt die Eigenschaften form.limit und form.default_limit werden auf $in_limit gesetzt.
     * 
     * @param   string  $in_formID      ID des aktuellen Formulares
     * @param   integer $in_limit       Limit-Wert
     */
    public function setFormPropertyLimit($in_formID, $in_limit) {
        if(is_numeric($in_limit)) {
            $this->_formsArray[$in_formID]["form.limit"] =  $in_limit; 
            $this->_formsArray[$in_formID]["form.default_limit"] =  $in_limit;
        }
    }
    
    
    

    /** Gibt den countData-Wert für die übergebene Instanz und Form_id zurück.
     * Wenn das Formular nicht existiert, wird 0 zurückgegeben.
     * 
     * @param   integer     $in_formID          ID des Formulars
     * @param   string      $in_instance_id     Instanz des Formulars
     * @return  integer                         Anzahl der anzuzeigenden Datensätze
     */
    public function getFormPropertyCountData($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID])) {
            if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.countData"])) {
                return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.countData"];
            }
        } else {
            return 0;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt den form_mode-Wert für die Instanz des Formulars zurück.
     * Wenn das Formular nicht existiert, wird 1 zurückgegeben (Default)
     * 
     * @param   integer     $in_formID
     * @param   string      $in_instance_id
     * @return  integer
     */
    public function getFormPropertyFormmode($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID])) {
            if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.form_mode"])) {
                return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.form_mode"];
            }
        } else {
            return 1;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    
    
    
    
    /** Ermittelt das aktuelle Array aus der Session-Class für den aktuellen BrowserTab (Storage-ID)
     * 
     * @return Array
     */
    public function getSessionArrayCurTab() {
        return session_class::$session_object->getSessionArrayCurTabAndGlobals();
    }
    
    
    
    /** Ermittelt das aktuelle Array aus der Session-Class
     * 
     * @return Array
     */
    public function getSessionArray() {
        return session_class::$session_object->getSessionArray();
    }
    
    
    
    
    
    
    /** Liest aus der Session ein Wert für ein Feld aus.
     * 
     * @param   string  $in_field_id        ID eines Feldes (siehe feld.id) oder die Konstante "click_button" oder die Konstante "infobox"
     * @return  string
     */
    public function getSessionMessageForField($in_field_id) {
        $mySession = session_class::$session_object->getSessionArrayCurTab();
        $feedback = "";
        if (isset($mySession["Fieldmessages"][$in_field_id])) {
            //Attribut existiert
            $feedback = $mySession["Fieldmessages"][$in_field_id];
        } 

        return $feedback;
    }
    
    

    
    
    
    /** Ergänzt die Optionsliste eines Feldes im entsprechenden formArray
     * form["optionlists"][$in_field_id]
     * 
     * @param type $in_form_id
     * @param type $in_field_id
     * @param type $in_optionlist
     */
    public function addOptionlistToFormarray($in_form_id, $in_field_id, $in_optionlist) {
        $myForm = $this->getFormArray($in_form_id);
        $myForm["optionlists"][$in_field_id] = $in_optionlist;
        $this->setFormArray($in_form_id, $myForm);
        
           
    }
    

    
    
    /** Ermittelt ein Workflow-Array aus dem Session-Backup, falls dieses vorhanden ist.
     * 
     * @return mixed        Array des letzten Workflows oder false
     */
    private function getWorkflowFromSessionbackup() {
        $my_tabSession = session_class::$session_object->getSessionArrayCurTab();
        if(isset($my_tabSession["workflow_serialized"])) {
            return $my_tabSession["workflow_serialized"];
        }
        
        return false;
    }
    
    
    
    
    /** Gibt die Einstellungd es Attributs 
     * SESSION["use_temporary_update_dir"] zurück
     * 
     * @return      boolean              
     */
    public function getSessionUseTempInstallPath() {
        $mySession = $this->getSessionArray();
        if (isset($mySession["use_temporary_update_dir"])) {
            //Attribut existiert
            $feedback = $mySession["use_temporary_update_dir"];
        } else {
            //Attribut existiert nicht
            $feedback = false;
        }

        return $feedback;
    }

    /** Gibt die Eigenschaft show_data zurück. Diese steuert, ob Daten im Formular angezeigt werden sollen.
     * 
     * @param   integer     $in_formID
     * @param   string      $in_instance_id
     * @return  boolean
     */
    public function getFormPropertyShowData($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.show_data"])) {

            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.show_data"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die Eigenschaft set_default_content zurück. Diese steuert, ob die Default_Werte vorgegeben werden sollen..
     * 
     * @param   integer     $in_formID
     * @param   string      $in_instance_id
     * @return  boolean
     */
    public function getFormPropertySetDefaultContent($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.set_default_content"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die Eigenschaft note_requireFlag  zurück. Diese steuert, ob die Angabe der Pflichtfelder beachtet werden soll.
     * 
     * @param   integer     $in_formID
     * @param   string      $in_instance_id
     * @return  boolean
     */
    public function getFormPropertyNoteRequireFlag($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.note_requireFlag"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die Eigenschaft form.set_mark_field  zurück. Diese steuert, ob ein Markierungsfeld gesetzt werden soll.
     * 
     * @param   integer     $in_formID
     * @param   string      $in_instance_id
     * @return  boolean
     */
    public function getFormPropertySetMarkField($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.set_mark_field"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die Eigenschaft note_readonly  zurück. Diese steuert, ob im Formular die readonly-Eigenschaft beachtet werden soll
     * 
     * @param   integer     $in_formID
     * @param   string      $in_instance_id
     * @return  boolean
     */
    public function getFormPropertyNoteReadonly($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.note_readonly"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die ID der aktuellen Maske zurück
     * 
     * @return  integer
     */
    public function getMaskProbertyID() {
        return $this->_maskArray["id"];
    }

    /** Gibt die APP-ID der aktuellen Maske zurück
     * 
     * @return  string
     */
    public function getMaskProbertyAppid() {
        return $this->_maskArray["app_id"];
    }

    /** Gibt die Eigenschaft allways_readonly  zurück. Diese steuert, ob das Formular komplett im readOnly-Modus geöffnet werden soll.
     * 
     * @param   integer     $in_formID
     * @param   string      $in_instance_id
     * @return  boolean
     */
    public function getFormPropertyAllwaysReadonly($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.allways_readonly"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die Eigenschaft show_nested_forms  zurück. Diese steuert, ob eingebettete Formulare angedruckt werden sollen..
     * 
     * @param   integer     $in_formID
     * @param   string      $in_instance_id
     * @return  boolean
     */
    public function getFormPropertyShowNestedForms($in_formID, $in_instance_id) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID]["form.instances"][$in_instance_id]["form.show_nested_forms"];
        } else {
            return false;                   //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt an, ob ein Formular eingebettet ist
     * 
     * @param   integer $in_formID
     * @return  boolean
     */
    public function getFormPropertyIsnested($in_formID) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID] ["form.is_nested_form"];
        } else {
            return false;               //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }
    
    
    
    /** Gibt die Liste der PrimaryKeys des Formulars zurück
     * 
     * @param   integer $in_formID
     * @return  mixed               Kommaseparierte Liste der Primary-Keys oder Leerstring, wenn kein PK existiert.
     *                              Es sind keine Leerzeichen enthalten
     *                              Wenn das Formular nicht existiert, dann wird false zurückgegeben
     */
    public function getFormPropertyPrimaryKeys($in_formID) {
        if (isset($this->_formsArray[$in_formID])) {
            return str_replace(" ", "", $this->_formsArray[$in_formID] ["form.primarykey"]);
        } else {
            return false;               //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }
    
    

    /** Gibt den constructor eines Formulars an.
     * 
     * @param   integer     $in_formID      ID des Formulars, von dem der constructor ermittelt werden soll
     * @return  string or boolean           Bei Erfolg wird der constructorname in einem String zurückgegeben, sonst false.
     */
    public function getFormPropertyConstructor($in_formID) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID] ["form.constructor"];
        } else {
            return false;               //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die Eigenschaft time_to_delete eines Formulars in Sekunden an.
     * 
     * @param   integer     $in_formID      ID des Formulars, von dem der constructor ermittelt werden soll
     * @return  string                      Zeit in Sekunden. Wenn keine Angabe ermittelt werden konnte, dann Leerstring
     */
    public function getFormPropertyTimetodelete($in_formID) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID] ["form.time_to_delete"];
        } else {
            return "";
        }
    }

    /** Gibt die app_id eines Formulars an.
     * 
     * @param   integer     $in_formID      ID des Formulars, von dem die app_id ermittelt werden soll
     * @return  string or boolean           Bei Erfolg wird der constructorname in einem String zurückgegeben, sonst false.
     */
    public function getFormPropertyAppId($in_formID) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID] ["form.app_id"];
        } else {
            return false;               //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Gibt die connection-ID  eines Formulars an.
     * 
     * @param   integer    $in_formID       ID des Formulars, von dem die connection-id ermittelt werden soll
     * @return  string or boolean           Bei Erfolg wird der constructorname in einem String zurückgegeben, sonst false.
     */
    public function getFormPropertyConnectionId($in_formID) {
        if (isset($this->_formsArray[$in_formID])) {
            return $this->_formsArray[$in_formID] ["form.connection_id"];
        } else {
            return false;               //Für den Fall, dass es sich nicht um ein Formular mit Daten handelt
        }
    }

    /** Erstellt die komplette Condition einer Instanz eines Formulars und gibt diese zurück.
     * Diese setzt sich aus form.condition und ggf. aus form.history, form_dependence und Sonstigem zusammen.
     * 
     * @param   integer     $in_formID      ID des Formulars, von dem der constructor ermittelt werden soll
     * @param   string      $in_instanceID  ID der Instanz des Formulars
     * @return  string or boolean           Bei Erfolg wird die condition in einem String zurückgegeben, sonst Leerstring ("").
     */
    public function buildFormPropertyConditionComplete($in_formID, $in_instanceID) {

        $condition = "";

        if (isset($this->_formsArray[$in_formID])) {

            $tempConditionList = array();

            //Standard-Condition für Formular (wird aus der DB-Tabelle form übernommen)
            $defaultCondition = $this->getFormPropertyConditionDefault($in_formID);
            if ($defaultCondition <> "") {
                $tempConditionList[] = $defaultCondition;
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> default_condition ', $defaultCondition);
            }
            
            
            //Default-Condition der Instanz, diese kann bspw. durch  ein Parent-Form gesetzt worden sein
            $instance_condition = $this->getFormInstancePropertyCondition($in_formID, $in_instanceID);
            if ($instance_condition <> "") {
                $tempConditionList[] = $instance_condition;
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> instance_condition ', $instance_condition);
            }
            
            
            //Filter-Condition der Instanz, diese kann bspw. durch  ein Parent-Form gesetzt worden sein
            $filter_condition = $this->getFormInstancePropertyConditionFilter($in_formID, $in_instanceID);
            if ($filter_condition <> "") {
                $tempConditionList[] = $filter_condition;
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> filter_condition ', $filter_condition);
        
            }


            //Condition von einem Trigger-Formular, falls es sich um ein abhängiges Formular handelt
            $dependingCondition = $this->getConditionForDependigForm($in_formID);
            if ($dependingCondition <> "") {
                $tempConditionList[] = $dependingCondition;
            }

            //History-Condition ergänzen, falls die Maske historische Daten enthält
            //$currentDate = $this->getPostObject()->getHiddenCurrentDate();
            $currentDate = $this->getFormPropertyCurrentDate($in_formID);
            if ($this->_formsArray[$in_formID] ["form.history_flag"] == true AND $this->_formsArray[$in_formID] ["form.history_col_validfrom"] != "" AND $this->_formsArray[$in_formID] ["form.history_col_validto"] != "" AND $currentDate != "") {
                //Wenn historische Daten ermittelt werden sollen
                $tempConditionList[] = $this->_formsArray[$in_formID] ["form.history_col_validfrom"] . " <= '" . $currentDate . "' AND " . $this->_formsArray[$in_formID] ["form.history_col_validto"] . " >= '" . $currentDate . "'";
            }


            //Alle Conditions in einem String zusammenfassen
            $operator = "";
            foreach ($tempConditionList as $key => $value) {
                $condition = $condition . $operator . "(" . $value . ")";
                $operator = " \n AND ";
            }
        }

        return $condition;
    }

    /** Ermittelt die Anzahl der Daten, die mit den aktuellen Bedingungen im Formular angezeigt werden sollen.
     * Die Daten werden zudem in den Formulareigenschaften hinterlegt (countData, offset, offsetForward, offsetBackward)
     * Wenn keine Daten angezeigt werden sollen (param $in_showData), dann gibt diese Funktion 0 zurück
     * ACHTUNG: Falls es sich um ein nested_form handelt, sollte diese Funktion  erst aufgerufen werden, nachdem die temporäre Condition hinterlegt wurde. 
     * (Das ist momentan der Fall, da der Aufruf erst in showFields.getFormTableData erfolgt)
     * 
     * @param   integer     $in_formID                  ID des Formulars
     * @param   integer     $in_instanceID              eindeutige ID der Formularinstanz
     * @param   integer     $in_offset                  Offset-Wert, der als first_ds hinterlegt werden soll
     * @param   bool        $in_use_cache               Gibt an, dass der Cache aller bisherigen DB-Abfragen genutzt werden soll. D.h., wenn eine identische Abfrage innerhalb des aktuellen 
     *                                                  Maskenaufbaus bereits an die Datenbank gesendet wurde, dann dessen Ergebnis genutzt.
     *                                                  I.d.R. muss hier nur false genutzt werden, wenn zuvor Änderungen an den Daten in der Datenbank
     *                                                  vorgenommen wurden, d.h. wenn ein insert oder delete-Befehel abgesetzt wurde.
     * @param boolean   $in_deactivateSecurityCondition [optional] Nur relevant fpr Formulare, die auf einer Query basieren. Gibt an, ob die Security-Conditions beim ermitteln der Inhaltsdaten über eine Query deaktiviert werden sollen.
     * @return  integer                                 Anzahl dr anzuzeigenden Datensätze
     */
    public function calculateFormCountData($in_formID, $in_instanceID, $in_offset, $in_use_cache, $in_deactivateSecurityCondition = false) {
        $countData = 0;
        $showData = $this->getFormPropertyShowData($in_formID, $in_instanceID);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Attribut showData für Form: '.$in_formID.' instanz: '.$in_instanceID, $showData);
        //Anzuzeigende Daten ermitteln
        if ($showData == true) {
            $form = $this->getFormArray($in_formID);
            if ($form["form.query_id"] != "") {
                //Wenn Daten mit Hilfe einer Query angezeigt werden sollen
                $myQuery = new query();
                $variablesContainerForQuery = $myQuery->buildvariableContainerForQuery(true, $this, $in_formID, $in_instanceID);
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> query  aufrufen mit variableContainer: '.$in_formID.' instanz: '.$in_instanceID, $variablesContainerForQuery);
        
                $myQuery->initialize_1($form["form.query_app_id"], $form["form.query_id"], false, $variablesContainerForQuery, $form, false, 0, 0, $in_deactivateSecurityCondition);
                $countData = $myQuery->getCountData();
            } elseif ($form["form.db_table"] != "") {
                //Wenn Daten aus einer DB-Tabelle angezeigt werden sollen
                //Bedingung für aktuelles Formular abrufen     
                $bedingung = $this->buildFormPropertyConditionComplete($in_formID, $in_instanceID);
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> complete bedingung für Form: '.$in_formID.' instanz: '.$in_instanceID, $bedingung);
                $connection_id = $this->getFormPropertyConnectionId($in_formID);
                //Daten, die den Bedingungen entsprechen, abfragen; 
                if (isset($form['form.id_fields'][0])) {
                    $count_column = $form['form.id_fields'][0];
                } else {
                    $count_column = "*";
                }
                $countData = getTableDataCount($connection_id, $form['form.db_table'], $form['form.db_schema'], $count_column, $bedingung, __FUNCTION__ . " Zeile: " . __LINE__, $in_use_cache);
            }
        }
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Setze CountData für Formular: '.$in_formID." und instance :".$in_instanceID, $countData);
        $this->setFormPropertyCountData($in_formID, $in_instanceID, $countData);
        $this->setCurrentDSValuesInForm($in_formID, $in_instanceID, $in_offset, $this->getFormPropertyLimit($in_formID), $countData);
        return $countData;
    }

    /** Ersetzt vorhandene Formulardaten durch das übergebene Formular (Array).
     * Wenn das Formular unter der gegebenem ID nicht existiert, wird es neu gesetzt.
     * 
     * @param Integer $in_formId    ID eines schon vorhandenen Formulars
     * @param Array   $in_formArray Formular in Form eines Arrays, wie es von getFormsdataByFormID erzeugt wird.
     * 
     */
    public function setFormArray($in_formId, $in_formArray) {
        $this->_formsArray[$in_formId] = $in_formArray;
    }

    /** Ermittelt anhand der Mask_app_id und mask_id alle zugeordneten Formulare (ohne Symbolleisten) sowie  deren Strukturdaten und fügt sie dem Objekt interne Variablen hinzu.
     * 
     * @param array $in_GET         Verweis auf GET-Variable
     * @param type $in_mask_id
     */
    function buildFormArray(&$in_GET) {
        $mask_app_id = $in_GET["maskapp"];
        $mask_id = $in_GET["mask"];

        $formList = getFormList($mask_app_id, $mask_id);
        if (is_array($formList)) {
            foreach ($formList as $key => $value) {
                $relationtyp = $value["htmltaggroup_has_html_tag.relationtyp"];
                //echo "Relationtyp für Form ".$value["html_tag.form_id"].": ".$relationtyp."<br />";
                $this->addForm($value["html_tag.form_id"], $value["html_tag.form_app_id"], $relationtyp);
            }
        }
    }

    /** Ermittelt anhand des geklickten Buttons die gewünschte Function-ID. 
     * Mit Hilfe dieser ID werden alle Eigenschaften einer Funktion nachgeladen und in $this->_functionArray abgelegt.
     * Wenn keine Funktion gewählt wurde wird eine Dummy-Funktion (0) erstellt.
     * Es können nur Button-Funktionen aufgerufen werden, die im Session-Form-Backup-Array für die vorgegebene instance
     * vorhanden sind. Manipulation ist damit weitgehend ausgeschlossen.
     * 
     * @param   integer     $in_sender_form     ID des Formulars, aus dem Die Funktion aufgerufen wurde
     * @param   string      $in_sender_instance ID der Instance des sendenden Formulars
     * @param   string      $in_button_name     Name des Buttons, der die Funktion aufrief, im HTML-Dom
     * @return  booelan                         false, wenn keine Funktion ermittelt wurde, ob wohl das GET-Array die entsprechenden Eigenschaften enthält.
     */
    function buildFunctionArray($in_sender_form, $in_sender_instance, $in_button_name) {

        //Default-Werte
        $myFunctionArray = array();
        $myFunctionArray["button_action_function_id"] = 0;
        $myFunctionArray["button_action_function_app_id"] = global_variables::getAppIdFromSYS01();
        $myFunctionArray["button_target"] = 0;
        $myFunctionArray["form_mode"] = 1;
        $myFunctionArray["classname"] = "";
        $myFunctionArray["functionname"] = "";
        $myFunctionArray["target_form_id"] = global_variables::getDefaultDummyFormId();

        $button_array = $this->getFormPropertyButton($in_sender_form, $in_sender_instance, $in_button_name);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> button-Attribute ', $button_array);
        if ($button_array != false) {
            //Wenn Button-Metadaten im Session_FormBackup vorhanden sind, werden die Buttondaten von dort ermittelt.
            //Die Metadaten des Buttons dürfen aus Sicherheitsgründen nicht per GET oder POST übertragen werden.
            if ($button_array["button_action_function_id"] != false) {$myFunctionArray["button_action_function_id"] = $button_array["button_action_function_id"];}
            if ($button_array["button_action_function_app_id"] != false) {$myFunctionArray["button_action_function_app_id"] = $button_array["button_action_function_app_id"];}
            if ($button_array["button_target"] != false) {$myFunctionArray["button_target"] = $button_array["button_target"];}
            if ($button_array["form_mode"] != false) {$myFunctionArray["form_mode"] = $button_array["form_mode"];}
            if ($button_array["target_form_id"] != false) {$myFunctionArray["target_form_id"] = $button_array["target_form_id"];}
            if ($button_array["feld.vorgabewert"] != false) {$myFunctionArray["feld.vorgabewert"] = $button_array["feld.vorgabewert"];}
        }

        $tempFunction = getFunctionNameAndClass($myFunctionArray["button_action_function_id"], $myFunctionArray["button_action_function_app_id"]);
        if ($myFunctionArray["button_action_function_id"] == 0) {
            //Dummy-Funktion oder Login-Button
            $myFunctionArray["functionname"] = "Dummy";
            $feedback = true;
        } else {
            $myFunctionArray["functionname"] = $tempFunction["functionname"];
            $myFunctionArray["classname"] = $tempFunction["classname"];
            $feedback = true;
        }

        $this->_functionArray = $myFunctionArray;
        return $feedback;
    }

    /** Gibt eine Eigenschaft der aktuell aufgerufenen Funktion zurück..
     * Folgende Eigenschaften existieren
     * 
     * caption,
     * button_id,
     * button_app_id,
     * button_action_function_app_id, 
     * button_action_function_id,
     * button_target,
     * form_mode,
     * target_form_id,
     * functionname,
     * feld.db_column,
     * feld.vorgabewert,
     * params,
     * 
     * params ist wiederum ein array, welches alle Parameter gemaäß der Datenbanktabelle function_param (spalte name) enthält.
     * 
     * @param   string  $in_property    Name der Eigenschaft
     * @return  mixed                   Wenn Eigenschaft existiert, dann wird diese zurückgegeben, ansonsten wird false zurückgegeben.
     */
    public function getFunctionProp($in_property) {
        if(isset($this->_functionArray["$in_property"])){
            return $this->_functionArray["$in_property"];
        } else {
            return false;
        }
    }

    /** Gibt die Liste der Funktionseigenschaften zurück
     * 
     * @return  array                       key = Parameter der Funktion, value = Wert
     */
    public function getFunctionArray() {
        return $this->_functionArray;
    }

    /** Fügt dem FunktionsArray eine beliebige Eigenschaft hinzu
     * 
     * @param   String      $in_propertyname    Beliebiger Name, unter dem die Eigenschaft abgespeichert werden soll
     * @param   Variable    $in_value           Ein Wert, der abgespeichert werden soll
     */
    public function setFunctionProperty($in_propertyname, $in_value) {
        $this->_functionArray[$in_propertyname] = $in_value;
    }

    /** Gibt ein Array mit den geänderten Datensätzen zurück.
     * 
     * @return array
     */
    public function getChangedDataFromPostarray() {
        return $this->internPostObject->getChangedData();
    }

    /** Gibt ein Array mit den neuen (form_mode == insert) Datensätzen zurück.
     * 
     * @return array
     */
    public function getNewDataFromPostarray() {
        return $this->internPostObject->getNewData();
    }

    /** Ergänzt zu Newdata einen neuen Datensatz. Dieser muss wie folgt aufgebaut sein (content ist natürlich flexibel) <br />
     * Array
      (
      [0] => Array
      (
      [ds] => 0
      [form] => 212
      [content] => Array
      (
      [id] => 16823
      [bst] => 02600000
      [uid] => arusu
      [aktiv] => t
      [access_read] => 1
      [delegate_allowed] => t
      [k_tit_grp_id] => 1
      [_k_tit_grp_id] => 0
      [valid_from] =>
      [valid_to] =>
      [editor] => bim01admin
      )

      [schema] => allg
      [table] => permission_bst
      [hash] => 8ecd8c054bc2a1c606e9366c762c66bf
      [instance_id] => i0new
      [button_used] => 1
      [button_name] => button__id2214_00022140Form212_1_i0new
      )

      )
     * 
     * @param   array       $in_newData     neuer Datensatz; Syntax, siehe oben.
     * @param   string      $in_pos         [first|last]; Gibt an, ob der Datensatz am Anfang, oder am Ende ergänzt werden soll
     */
    public function addNewData($in_newData, $in_pos) {
        $this->internPostObject->addNewDataContent($in_newData, $in_pos);
    }

    /** Gibt ein Array mit den markierten Datensätzen zurück.
     * 
     * @return array
     */
    public function getMarkedDataFromPostarray() {
        return $this->internPostObject->getMarkedData();
    }

    

    /** Ermittelt aus der Session den Wert des Attributs "uid".
     * Wenn dieses Attribut nicht existiert wird false zurückgegeben.
     * 
     * @return mixed                wenn Attribut existiert, dann string, ansonsten boolean (false)
     */
    public function getCurrentUserFromSession() {
        return session_class::$session_object->getUid();
    }
    
    
    
    /** Ermittelt aus der Session den Wert des Attributs "uid_app_id".
     * Wenn dieses Attribut nicht existiert wird false zurückgegeben.
     * 
     * @return mixed                wenn Attribut existiert, dann string, ansonsten boolean (false)
     */
    public function getCurrentUserAppFromSession() {

        return session_class::$session_object->getAppIdFromUid();
    }
    
    
    

    /** Ermittelt aus der Session den Wert des Attributs "active_role" (array).
     * Wenn dieses Attribut nicht existiert wird false zurückgegeben.
     * 
     * @return mixed                wenn Attribut existiert, dann array(role.id, role.name, role.app_id), ansonsten boolean (false)
     */
    public function getCurrentRoleFromSession() {
        if (session_class::$session_object->getActiveRoleArray() !== false) {
            $feedback = session_class::$session_object->getActiveRoleArray();
        } else {
            $feedback = false;
        }

        return $feedback;
    }

    



    /** Ermittelt die role.id des aktiven Users
     * 
     * @return integer          Bsp.: 1
     */
    public function getActiveRoleIdFromSession() {

        return session_class::$session_object->getActiveRoleId();
    }

    /** Ermittelt die role.app_id des aktiven Users
     * 
     * @return string           Bsp.: SYS01
     */
    public function getActiveRoleAppIdFromSession() {

        return session_class::$session_object->getActiveRoleAppId();
    }

    /** Ermittelt die Account.id des aktiven Users
     * 
     * @return string           Bsp.: sys01root
     */
    public function getActiveUser() {

        return session_class::$session_object->getUid();
    }
    
    

    

}

/**
 * Erstellt aus dem PostArray ein internesPostAreay, indem die Daten getrennt nach Steuerungsdaten (ControlData) und Formularinhaltsdaten (ContentData) verwaltet werden.
 * 
 */
class POST_Data {
    /*
     *  Beispiel für $_internPostArray
     * [controlData]
      [Speichern] => Speichern
      [hidden_current_date] =>
      [firstFormIdOnMask] => 61
      [contentData]
      [0_Form59_0_11017]
      [Form]=>59
      [schema]=>widerspruch
      [table]=>bew_antrag
      [content]
      [bew_id] => 1
      [id] => 1
      [abschl] => BL
      [antragsstatus] => 3
      [bemerkung] =>
      [zulassung_durch] =>
      [Hash] => f9e262a7c00382520a32abae5629f5d6
      [0_Form60_0_18768]
      [Form]=> 60
      [schema] => widerspruch
      [table]=> bew_antrag
      [content]
      [widerspruch0bew_fach0bew_antrag_bew_id0Form60_0_18768] => 1
      [widerspruch0bew_fach0bew_antrag_id0Form60_0_18768] => 1
      [widerspruch0bew_fach0id0Form60_0_18768] => 1
      [widerspruch0bew_fach0k_fach_id0Form60_0_18768] => 10003
      [Hash] => f80e38539e2cf222ff4eed263fad1441
      [1_Form60_1_4292]
      [Form]=>60
      [schema]=> widerspruch
      [table]=> bew_fach
      [content]
      [widerspruch0bew_fach0bew_antrag_bew_id0Form60_1_4292] => 1
      [widerspruch0bew_fach0bew_antrag_id0Form60_1_4292] => 1
      [widerspruch0bew_fach0id0Form60_1_4292] => 2
      [widerspruch0bew_fach0k_fach_id0Form60_1_4292] => 10009
     */

    protected $_internPostArray = array();                                      //Array mit allen übermittelten Daten, gruppiert nach ControlData und contentData
    protected $_changedDataArray = array();                                     //Array, welches nur die geändert Datensätze enthält
    protected $_markedDataArray = array();                                      //Array, welches die markierten Datensätze enthält
    protected $_mergedMarkedData = array();                                     //Alle Daten von markedData, zusammengefasst in inem fiktiven Datensatz
    protected $_newDataArray = array();                                         //Array, welches die neu angelegten Daten enthält
    protected $_app_id_from_kernel;                                             //APP-ID der Kernanwendung
    
    
    /**
     * Array
//                                                                                    (
//                                                                                        [wkfl_step_mail_to] => test@uni-potsdam.de
//                                                                                        [wkfl_step_mail_cc] => bim01admin@uni-potsdam.de
//                                                                                        [wkfl_step_mail_from] => bim01admin@uni-potsdam.de
//                                                                                        [wkfl_step_comment] => Hinweis
//                                                                                    )
     * 
     * @var array
     */
    protected $_wkflMetaData = array();                                         
    
    function __construct($in_POST) {
        $this->_app_id_from_kernel = global_variables::getAppIdFromSYS01();
        $this->_internPostArray = $this->buildInternPostArray($in_POST);
        $this->_internPostArray = $this->moveWorkflowFieldsFromContentToDSMeta($this->_internPostArray);
        $this->_wkflMetaData = $this->buildWkflMetaDataFromLastPost();
        $newAndChangedData = $this->buildArrayWithChangedAndNewData($this->_internPostArray);
        $this->_changedDataArray = $newAndChangedData["changedData"];
        $this->_newDataArray = $newAndChangedData["newData"];
        $this->_markedDataArray = $this->buildMarkedData($this->_internPostArray);
        $this->_mergedMarkedData = $this->buildMergeMarkedData();

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> internPostArray: ', $this->_internPostArray);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> mergedMarkedData: ', $this->_mergedMarkedData);
    }
    
    
    
    
    
    
    /** Verschiebt die Workflow-Daten (beginnend mit wkfl_; Bsp.: wkfl_email_to, wkfl_email_cc, wkfl_email_from, wkfl_comment) aus dem
     * content-Bereich eines Datensatzes in den Meta.Bereich desselben Datensatzes
     * 
     * @param   array   $in_internPostArray
     * @return  array                           
     */
    private function moveWorkflowFieldsFromContentToDSMeta($in_internPostArray) {
        
        if(isset($in_internPostArray["contentData"])) {
            //gesamtes PostArray durchlaufen
            foreach ($in_internPostArray["contentData"] as $key1 => $currentDS) {
                //Jeden Datensatz separat prüfen
                foreach ($currentDS["content"] as $key2 => $value) {
                    if(strpos(getColumnnameFromTableAndColumn($key2, false),"wkfl_") !== false) {
                        //Workflow-Info aus content heraustrennen und stattdessen unter "workflow" ablegen
                        unset($in_internPostArray["contentData"][$key1]["content"][$key2]);
                        //Tabellennamen entfernen, da dieser je Formular, unterschiedlich sein kann
                        $targetkey = getColumnnameFromTableAndColumn($key2, false);
                        $in_internPostArray["contentData"][$key1]["workflow"][$targetkey] = $value;

                    }

                }

            }
        }

        return $in_internPostArray;
        
        
    }
    
    
    
    /** Falls ein Workflow vorliegt und in diesem wkfl_metadaten übergeben wurden, werden diese zurückgegeben.
     * 
     * 
     * @return  array       Array <br />
//                               ( <br />
//                                  [wkfl_step_mail_to] => test@uni-potsdam.de <br />
//                                  [wkfl_step_mail_cc] => bim01admin@uni-potsdam.de <br />
//                                  [wkfl_step_mail_from] => bim01admin@uni-potsdam.de <br />
//                                  [wkfl_step_comment] => Hinweis <br />
//                               ) <br />
     *                      Wenn wkfl_daten nicht vorliegen, wird ein leeres Array zurückgegeben.                                                    
     */
    public function buildWkflMetaDataFromLastPost() {
        $feedback = array();
        if(isset($this->_internPostArray["controlData"]["formkey_that_call_function"])) {
            $current_ds = $this->_internPostArray["controlData"]["formkey_that_call_function"];
            if(isset($this->_internPostArray["contentData"][$current_ds]["workflow"])) {
                $temp_wkfl_data = $this->_internPostArray["contentData"][$current_ds]["workflow"];
                foreach ($temp_wkfl_data as $key => $value) {
                    $new_key = getColumnnameFromTableAndColumn($key, false);
                    $feedback[$new_key]=$value;
                    
                }
    
            }
            
        }
        
        return $feedback;
    }
    
    
    
    /** Falls ein Workflow vorliegt und in diesem wkfl_metadaten übergeben wurden, werden diese zurückgegeben. 
     * Ansonsten wird ein leeres Array übermittelt.
     * 
     * 
     * @return  array       Array <br />
//                               ( <br />
//                                  [wkfl_step_mail_to] => test@uni-potsdam.de <br />
//                                  [wkfl_step_mail_cc] => bim01admin@uni-potsdam.de <br />
//                                  [wkfl_step_mail_from] => bim01admin@uni-potsdam.de <br />
//                                  [wkfl_step_comment] => Hinweis <br />
//                               ) <br />
     *                      Wenn wkfl_daten nicht vorliegen, wird ein leeres Array zurückgegeben.                                                    
     */
    public function getWkflMetaDataFromPost() {
        return $this->_wkflMetaData;
    }
    

    /**
     * Bildet aus allen markierten Datensatz einen analog aufgebauten Datensatz, der jedoch die
     * zusammengefassten Values aller Datensätze enthält.
     * 
     * @return  array       Bsp.: Array
      (
      [0] => Array
      (
      [ds] => merged
      [form] => 929
      [content] => Array
      (
      [bewsem] => '20162','20162'
      [fach] => 'BWL','LER'
      [verfahrensart] => '40','40'
      [vert] => '.','SE'
      )

      [mark] => mark
      [schema] => manager
      [table] => vquery_widerverfahren
      [hash] => 939c69ee50d25ff5639027bdc2da4a3e
      [instance_id] => i0
      )

      )
     */
    function buildMergeMarkedData() {
        $mergedData = array();
        $markedData = $this->_markedDataArray;
        $content = array();
        $delimiter = "";
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Anzahl markedData: ', count($markedData));
        if (count($markedData) > 0) {
            //Wenn mindestens ein markierter Datensatz existiert, dann wird der erste Datensatz unverändert übernommen
            $mergedData[] = $markedData[0];
            $mergedData[0]["ds"] = "merged";
            $mergedData[0]["hash"] = "merged";
            foreach ($markedData as $markedDataKey => $currentMarkedData) {
                foreach ($currentMarkedData["content"] as $contentKey => $value) {
                    if (isset($content[$contentKey])) {
                        $content[$contentKey] = $content[$contentKey] . $delimiter . "'" . $value . "'";
                    } else {
                        $content[$contentKey] = "'" . $value . "'";
                    }
                }
                $delimiter = ",";   //nach dem ersten Durchlauf wird ein Trennzeichen benötigt.
            }
            $mergedData[0]["content"] = $content;
        }
        return $mergedData;
    }

    /**
     * Gibt die kumulierten markedData-Datensätze zurück.
     * 
     * @return  array           analog aufgebaut zu mergedData
     */
    public function getMergedMarkedData() {
        return $this->_mergedMarkedData;
    }

    /** Erstellt aus der globalen Variable $_POST das Array gemäß dem oben gezeigten Muster.
     * 
     * @param   Array   $in_POST
     */
    function buildInternPostArray($in_POST) {

        $dsStartFlag = getConfig("datensatz_startattribut", $this->_app_id_from_kernel);
        $dsEndFlag = getConfig("datensatz_endattribut", $this->_app_id_from_kernel);
        $dbTrennzeichen = getConfig("db_trennzeichen", $this->_app_id_from_kernel);
        $resultArray = array();
        $datensatzName = "";                                                 //Format: DS-Nr_Form-ID_Nr-Zufallszahl; Bsp.: 0_Form59_0_11017
        $foundDSStart = false;
        $foundDSEnd = false;
        $form_id_button = "";
        $instance_id = "";

        foreach ($in_POST as $key => $value) {
            //Post_array zeilenweise durchwandern
            //echo print_r($key)." - Startpos an Stelle: ".strpos($key,$dsStartFlag)." - foundStart: ".$foundDSStart." - foundEnd: ".$foundDSEnd."<br />";




            if (strpos($key, $dsStartFlag) !== false) {
                //Wenn das StartFlag gefunden wird, wird ein neuer Datensatz angelegt
                $foundDSStart = true;
                $foundDSEnd = false;
                $datensatzName = str_replace($dsStartFlag, "", $key);           //Löscht das Startflag aus $key. Damit bleibt ein eindeutiger Bezeichner für den Datensatz übrig. Bsp.: aus "startds_1_Form60_1_23922" wird "1_Form60_1_23922"
                $resultArray["contentData"][$datensatzName] = array();
                $resultArray["contentData"][$datensatzName]["ds"] = substr($datensatzName, 0, strpos($datensatzName, "_"));

                //Felder form, schema und table ermitteln                       
                $posForm = strpos($key, "Form") + 4;                             //Auftreten der Form-ID
                $posEndeForm = strpos($key, "_", $posForm);                     //Ende der Form-ID
                $laengeForm = $posEndeForm - $posForm;
                $form_id = substr($key, $posForm, $laengeForm);
                $resultArray["contentData"][$datensatzName]["form"] = $form_id;
                $resultArray["contentData"][$datensatzName]["content"] = array();
            } elseif (strpos($key, "Hash") !== false) {
                //Wenn der Hash-Wert eines Datensatzes gefunden wurde
                $resultArray["contentData"][$datensatzName]["hash"] = $value;
            } elseif (strpos($key, "head_") !== false) {
                //das markAll-Field einer Checkbox im header hat dieses Erkennungsmerkmal. Es muss ignoriert werden.
            } elseif (strpos($key, "markField") !== false) {
                //Wenn ein Datensatz durch den User  markiert/ausgewählt wurde 
                $resultArray["contentData"][$datensatzName]["mark"] = $value;
            } elseif (strpos($key, $dsEndFlag) !== false) {
                //Wenn das $in_ds_endattribut eines Datensatzes gefunden wird, dann wird abgebrochen
                $foundDSStart = false;
                $foundDSEnd = true;
                //InstanceID ergänzen
                $resultArray["contentData"][$datensatzName]["instance_id"] = $this->getInstanceIdFromFieldName($key);
            } elseif ($foundDSStart == true AND $foundDSEnd == false) {
                //Wenn  ein Wert zwischen Start- und Endeflag gefunden wurde, wird er als Datensatzinhalt in contentData mit der aktuellen Datensatzbezeichnung abgelegt
                //Beispiel für $key: [0fin0k_gg0gg0Form1218_1_i0] => 945
                $werte = explode($dbTrennzeichen, $key);                        //Key in Einzelelemente, entsprechend der Anzahl des Auftretends des DB-Trennzeichens aufteilen
                $resultArray["contentData"][$datensatzName]["schema"] = $werte[1];
                if (isset($werte[2])) {
                    //$werte[2] ist nur gesetzt, wenn dem Formular schema und table mitegegebn wurde. 
                    //Wenn ein Button der Symbolleiste geklickt wurde, sind diese beiden Attribute nicht gesetzt. 
                    //Ausnahme: die Button-ID enthält zufällig das DB-TRennzeichen
                    if (strpos($key, "button__") !== false) {
                        //Diese Schleife trifft nur zu, wenn die id des Forms zufällig das DB-Trennzeichen enthält (bsp.: 60 -> Trennzeichen = 0)   //Stimmt diese Behauptung noch?
                        //Wenn im key ein button mit form_id enthalten ist, wird die form_id ausgelesen
                        //Buttons haben eine geringfügig andere Syntax als alle anderen Felder, da als Präfix noch die Konstante "button__" gesetzt wird.
                        $form_id_button = $this->setButtonAttributs($resultArray, $key, $datensatzName);
                        $instance_id = $this->getInstanceIdFromFieldName($key);
                        //ToDo: Redundanz mit dem etwas tiefer stehenden Absatz auflösen
                    } else {

                        $resultArray["contentData"][$datensatzName]["table"] = $werte[2];
                        if ($werte[2] != "") {
                            $column_key = $werte[2] . "." . $werte[3];      //table.column
                        } else {
                            $column_key = $werte[3];      //column
                        }
                        $resultArray["contentData"][$datensatzName]["content"][$column_key] = $value;
                    }
                } else {
                    //Wenn innerhalb eines Datensatzes ein Button eingefügt wurde, greift dieser if-Zweig
                    $form_id_button = $this->setButtonAttributs($resultArray, $key, $datensatzName);
                    $instance_id = $this->getInstanceIdFromFieldName($key);
                }
            } elseif ($foundDSStart == false) {
                //Wenn sich der Zeiger ausserhalb eines Datensatzes befindet, handelt es sich um eine Steuerungsinformation
                $resultArray["controlData"][$key] = $value;
                //Wenn ein Button in einer Symbolleiste des Parentformulars geklickt wurde
                if (strpos($key, "button__") !== false) {
                    if(isset($resultArray["contentData"])) {
                        //wenn ein Childformular eingebettet ist, jedoch ein Key aus dem Parentformular geklickt wird (Symbolleiste = unten), 
                        //enthält $datensatzName noch den Link zum Childformular, statt zum Parentformular
                        $parent_datensatz = array_key_first($resultArray["contentData"]);
                    } else {
                        $parent_datensatz = $datensatzName;
                    }
                    $form_id_button = $this->setButtonAttributs($resultArray, $key, $parent_datensatz);
                    $instance_id = $this->getInstanceIdFromFieldName($key);
                }
            }

            next($in_POST);
        }

        //Wenn verschachtelte Formulare im Post-Array ihre Daten übergeben haben, dann wurde nur die form-id des letzten Formulars mitgegeben. Es wird aber die form_id
        //des ersten Formulars benötigt, da in diesem die Symbolleisten und damit die Buttons zugeordnet waren.
        //daher wird hier die form_id auf die form_id des buttons gesetzt, falls der button gefunden wird.
        //Analog wird die instance_id behandelt
        if ($form_id_button <> "") {
            $resultArray["controlData"]["form_id"] = $form_id_button;
        }
        if ($instance_id <> "") {
            $resultArray["controlData"]["instance_id"] = $instance_id;
            $instance_id = "";
        }


        //Falls ein Contentdatensatz für die Überschrift enthalten ist, dann muss dieser entfernt werden.
        if (array_key_exists("contentData", $resultArray)) {
            $falseContentKey = issetKeyLike($resultArray["contentData"], "0head_");
        } else {
            $falseContentKey = false;
        }
        if ($falseContentKey !== false) {
            unset($resultArray["contentData"][$falseContentKey]);
        }

        return $resultArray;
    }
    
    
    
    
    
    
    

    /** ergänzt die Attribute eines Buttons zum ResultArray für InternPostArray
     * 
     * @param   Array   $in_resultArray     Referenz zu $in_resultArray; In $in_resultArray wird direkt reingeschrieben
     * @param   string  $in_key             Key der aktuellen Zeile im original-POST-Array
     * @param   string  $in_datensatzName   Key, aber ohne DS-Kennzeichen
     * @return  Integer                     ID des Buttons    
     */
    private function setButtonAttributs(&$in_resultArray, $in_key, $in_datensatzName) {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> in_resultArray: ', $in_resultArray);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> in_key: ', $in_key);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> in_datensatzName: ', $in_datensatzName);
        if ($in_datensatzName != "") {
            //$in_datensatzName ist nur dann gesetzt, wenn ein Button innerhalb eines Datensatzes geklickt wurde.
            $in_resultArray["contentData"][$in_datensatzName]["button_used"] = true;
            $in_resultArray["contentData"][$in_datensatzName]["button_name"] = $in_key;
            $in_resultArray["controlData"]["formkey_that_call_function"] = $in_datensatzName;
        }
        $form_id_button = $this->getFormidFromButtonname($in_key);
        $in_resultArray["controlData"]["form_id_that_call_function"] = $form_id_button;
        $in_resultArray["controlData"]["buttonname_that_call_function"] = $in_key;
        if (isset($in_resultArray["controlData"]["formkey_that_call_function"]) === false) {
            //Wenn Attribut nicht gesetzt, dann analog form_id_that_call_function setzen.
            //ToDo: das ist redundant. Prüfen, ob das zu einer Eigenschaft zusammengeführt werden kann.
            $in_resultArray["controlData"]["formkey_that_call_function"] = $in_key;
        }

        return $form_id_button;
    }

    /** ermittelt aus einem buttonname, wie ihn die Funktion showFields.php._getFieldSubmitbutton setzt, die form_id.
     * Bsp.: button__Suche_0000Form56_1_1130190281 -> form_id = 56
     * 
     * @param   string  $in_buttonname  Name eines Buttons
     * @return  string                  id des Fomrulars des Buttons
     */
    function getFormidFromButtonname($in_buttonname) {
        $posForm = strpos($in_buttonname, "Form") + 4;                 //Auftreten der Form-ID
        $posEndeForm = strpos($in_buttonname, "_", $posForm);                     //Ende der Form-ID
        $laengeForm = $posEndeForm - $posForm;
        $form_id = substr($in_buttonname, $posForm, $laengeForm);
        return $form_id;
    }

    /** ermittelt aus einem buttonname, wie ihn die Funktion showFields.php._getFieldSubmitbutton setzt, die field_id.
     * Bsp.: button__id5712_0000Form910_0_i0 -> field_id = 5712
     * 
     * @param   string  $in_buttonname  Name eines Buttons
     * @return  string                  id des Feldes des Buttons
     */
    function getFieldidFromButtonname($in_buttonname) {
        $posId = strpos($in_buttonname, "id") + 2;                   //Auftreten der Field-ID
        $posEndeId = strpos($in_buttonname, "_", $posId);           //Ende der Field-ID
        $laengeId = $posEndeId - $posId;
        $field_id = substr($in_buttonname, $posId, $laengeId);
        return $field_id;
    }

    /** ermittelt aus einem Feldnamen, wie ihn bspw. die Funktion showFields.php._getFieldSubmitbutton setzt, die Instance-ID eines Formulars.
     * Bsp.: button__Suche_0000Form56_1_1130190281 -> instance_id = 1130190281
     * 
     * @param   string  $in_fieldname  Name eines Buttons
     * @return  string                  id des Fomrulars des Buttons
     */
    function getInstanceIdFromFieldName($in_fieldname) {
        $posInstance = strripos($in_fieldname, "_") + 1;                 //Letztes Auftreten von "_", danach beginnt die Instance-ID
        $instance_id = substr($in_fieldname, $posInstance);
        $instance_id = str_replace("--", ".", $instance_id);            // Punkt wurde in showFields.buildButtonname durch "--" ersetzt.
        return $instance_id;
    }

    
       
    /** Ermittelt aus dem Backup (Zustand eines Formulars, bevor es an den Client gesendet wurde) der Feldinhalte der geschützten Felder in SESSION den Wert eines Feldes.
     * 
     * @param   string  $in_KeyFromField    ID des Feldes innerhalb eines Formulars (Bsp.: allg0permission_bst0bst0Form212_0_ibst02600000)
     * @param   integer $in_formID          ID eines Formulars (Bsp.: 212)
     * @param   integer $in_datarow         Nummer einer Datenzeile innerhalb eines Formulars (Bsp. 0)
     * @return  array                       Default, wenn kein Value für ein geschütztes Feld im Backup gefunden wurde: $feedback_array = array("foundValue" => false, "value" => "")
     *                                      Wenn ein Wert gefunden wurde: $feedback_array = array("foundValue" => true, "value" => "123");
     */
    public function getValueFromSecureField($in_KeyFromField, $in_formID, $in_datarow) {
        
        $my_formBackup = session_class::$session_object->getFormbackup($in_formID);
        $feedback_array = array("foundValue" => false,
                                "value" => "");

        $instanceId = $this->getInstanceIdFromFieldName($in_KeyFromField);

        if ($my_formBackup !== false) {
            //nachfolgende Prüfung muss in zwei Schritten erfollen, da isset auch dann false wirft, wenn der key existiert, aber NULL ist.
            if (isset($my_formBackup["form.instances"][$instanceId]["valuesSecureFields"][$in_datarow])) {
                if (array_key_exists($in_KeyFromField, $my_formBackup["form.instances"][$instanceId]["valuesSecureFields"][$in_datarow])) {
                    $feedback_array["value"] = $my_formBackup["form.instances"][$instanceId]["valuesSecureFields"][$in_datarow][$in_KeyFromField];
                    $feedback_array["foundValue"] = true;
                }
            } else {
                //nichts gefunden
            }
        } else {
            //nichts gefunden
        }

        return $feedback_array;
    }
    



    /** Gibt das aus dem $_POST-Array mit buildInternPostArray erstellten internes Post_array zurück.
     * 
     * @return array
     */
    function getInternPostArray() {
        return $this->_internPostArray;
    }
    
    
    
    

    //ToDo: Prüfen, ob currentDate pro Maske oder pro Formular gespeichert wird. Ziel wäre: pro Formular.

    /** Ermittelt den Wert des versteckten Feldes "currentDate", falls dieses im Formular vorhanden ist.
     * 
     * @return string
     */
    function getHiddenCurrentDate() {
        if (isset($this->_internPostArray["controlData"]["hidden_current_date"])) {
            return $this->_internPostArray["controlData"]["hidden_current_date"];
        } else {
            return "";
        }
    }

    /** Ermittelt den Wert der form_id aus den controlData des PostArray. 
     * Diese Form_id entspricht der form, in dem der button geklickt wurde.
     * 
     * @return string
     */
    function getFormIDFromControlData() {
        if (isset($this->_internPostArray["controlData"]["form_id"])) {
            return $this->_internPostArray["controlData"]["form_id"];
        } else {
            return "";
        }
    }

    /** Ermittelt den Wert der action_id aus den controlData des PostArray. 
     * Diese action_id wird  der form entnommen, in dem der button geklickt wurde.
     * Die action_id entspricht dem Zeitstempel in Millisekunden (Unix-Format) 
     * zu dem das Formular gerendert wurde. Anhand der action_id kann erkannt werden,
     * ob die Formulardaten bereits zuvor verarbeitet wurden. Das kann passieren, 
     * wenn der User den Reload-Button des Browsers nutzt.
     * 
     *
     * 
     * @return string       Leerstring, wenn keine action_id ermittelt werden konnte.
     */
    function getActionIDFromControlData() {
        if (isset($this->_internPostArray["controlData"]["action_id"])) {
            return $this->_internPostArray["controlData"]["action_id"];
        } else {
            return "";
        }
    }

    /** ermittelt alle Daten, die für ein Formular im $_POST enthalten sind und gibt sie als Array zurück.
     * 
     * HINWEIS_1: diese Funktion kann nicht für eingebettete Formulare (is_nested_form) genutzt werden, da diese Mehrfach im Post-Array mit jeweils 
     * unterschiedlichen conditions enthalten sein können. Stattdessen kann mit Alternativen (getOldIDSForNestedForms) genutzt werden.
     * 
     * HINWEIS_2: Diese Funktion gibt nicht die Metadaten eines Formulars zurück. Dazu muss pagedata->getFormArray genutzt werden.
     * 
     * @param   integer             $in_form_id         ID eines Formulars
     * @return  array oder boolean                      Array mit den Formulardaten oder false.
     *                                                  Bsp.: 
     *                                                  array(
      [form] => 59
      [content] => Array
      (
      [bew_id] => 15
      [id] => 8
      [abschl] => BA
      [antragsstatus] =>
      [bemerkung] => test
      [zulassung_durch] =>
      )

      [schema] => widerspruch
      [table] => bew_antrag
      [hash] => 939130c3b4c28ce84dc4fb4a40e66c7d
      )
     */
    function getFormContent($in_form_id) {

        if (isset($this->getInternPostArray()["contentData"])) {
            $form_array = $this->getInternPostArray()["contentData"];
            foreach ($form_array as $key => $currentForm) {
                if ($currentForm["form"] == $in_form_id) {
                    return $currentForm;
                }
            }
        }

        //bis hier kommt der Programmcode nur, dann wenn vorher die Formulardaten nicht gefunden werden konnten
        return false;
    }

    /** Ermittelt die ID des Formulars, in dem der submitbutton gedrückt wurde.
     * 
     * @return  integer             ID des sendenden Formulars oder 0 (default) 
     */
    function getSenderformId() {
        $form_id = 0;
        $internPostarray = $this->getInternPostArray();

        if (isset($internPostarray["controlData"]["form_id"])) {
            $form_id = $internPostarray["controlData"]["form_id"];
        }

        //Prüfen, ob es formkey_that_call_function gibt und diese einen Wert enthält
        if (isset($internPostarray["controlData"]["form_id_that_call_function"])) {
            //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> form_id_that_call_function: ', $internPostarray["controlData"]["form_id_that_call_function"]);
            if (is_numeric($internPostarray["controlData"]["form_id_that_call_function"]) == true) {
                $form_id = $internPostarray["controlData"]["form_id_that_call_function"];
            }
        }
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> SenderFormID: ', $form_id);
        return $form_id;
    }

    /** Ermittelt die ID der Instance des Formulars, in dem der submitbutton gedrückt wurde.
     * Wenn keine instance_id ermittelt werden kann, wird "0" zurückgegeben. In dem Fall erfolgte der Aufruf des Formulars
     * i.d.R über einen Link. 
     * 
     * @return  integer             ID der Instanz des sendenden Formulars oder 0 (default) 
     */
    function getSenderInstanceId() {
        if (isset($this->getInternPostArray()["controlData"]["instance_id"])) {
            $instance_id = $this->getInternPostArray()["controlData"]["instance_id"];
        } else {
            $instance_id = 0;
        }
        return $instance_id;
    }

    /** Ermittelt den Namen submitbutton.
     * Wenn kein button ermittelt werden kann, wird false zurückgegeben. In dem Fall erfolgte der Aufruf des Formulars
     * i.d.R über einen Link. 
     * 
     * @return  string             Html-Name des Buttons, welcher aufgerufen wurde oder false (default) 
     */
    function getSenderButtonName() {
        if (isset($this->getInternPostArray()["controlData"]["buttonname_that_call_function"])) {
            $button = $this->getInternPostArray()["controlData"]["buttonname_that_call_function"];
        } else {
            $button = false;
        }
        return $button;
    }

    /** Ermittelt das Array des Datensatzes, in welchem der Submit-Buttton geklickt wurde.
     * 
     * @return mixed        False, wenn kein Datensatz ermittelt werden konnte. Ansonsten der DS. Bspw.: <br />
     *                      Array <br />
      ( <br />
      [ds] => 3 <br />
      [form] => 1013 <br />
      [content] => Array <br />
      ( <br />
      [id] => 1 <br />
      [file_usage] => 1 <br />
      [uid] => bim01admin <br />
      [upload_date] => 2020-12-15 <br />
      [filetype] => application/vnd.ms-excel <br />
      [filename] => test.csv <br />
      [upload_user] => bim01admin <br />
      [description] => test <br />
      [encoding] => base64 <br />
      )<br />
      [schema] => allg <br />
      [table] => files <br />
      [button_used] => 1 <br />
      [button_name] => button__id6835_0allg0files068350Form1013_3_i0 <br />
      [hash] => efbbb5d615a718da65cd6a30da87ee03 <br />
      [instance_id] => i0 <br />
      )
     */
    function getDSwhereButtonUsed() {
        $feedback = false;
        if (isset($this->getInternPostArray()["controlData"]["formkey_that_call_function"])) {
            $ds_id = $this->getInternPostArray()["controlData"]["formkey_that_call_function"];
            $feedback = $this->getInternPostArray()["contentData"][$ds_id];
        } else {
            $feedback = false;
        }
        return $feedback;
    }

    /** Ermittelt die ID und die APP einer gewählten Auswertung (query), falls diese existiert.
     * Voraussetzung ist, dass im sendenden Formular ein Feld existiert, welches im name-Attribut des html-tag den Wert "query_id" enthält.
     * Das kann bspw. erreicht werden, indem ein Feld mit der Dummy-Tabelle query_id angelegt wird.
     * 
     * 
     * @param   integer     $in_formID      ID des Formulars, aus dem heraus die Query aufgrufen wurde
     * @return  mixed                       APP und ID (string) des sendenden Formulars oder false, wenn keine ID ermittelt werden konnte. 
     *                                      Wenn APP und ID ermittelt werden können werden sie getrennt durch einen doppelten Unterstrich übergeben. Bsp.: SYS01__10
     */
    function getQueryIDFromListBox($in_formID) {

        $intern_post_array = $this->getInternPostArray();
        //key für die query ermitteln, falls dieser vorhanden ist
        $instance_id = $intern_post_array["controlData"]["instance_id"];
        //[bis 11.07.2018] //$search_string = "query_id".getConfig("db_trennzeichen")."Form".$in_formID;
        $search_string = "query_id" . getConfig("db_trennzeichen", $this->_app_id_from_kernel) . "Form" . $in_formID . "_1_" . $instance_id;
        $keyForQuery = issetKeyLike($intern_post_array["controlData"], $search_string);

        if ($keyForQuery <> false) {               //ToDo: Achtung das funktioniert nur solange das DB-Trennzeichn = 0 ist. Hier muss eine flexiblere Löcung egfunden werden (Bsp. array_filter)
            $feedback = $intern_post_array["controlData"][$keyForQuery];
        } else {
            $feedback = false;
        }

        return $feedback;
    }

    /** Ermittelt die ID und die APP einer gewählten Auswertung (query), die mit einem Button verknüpft ist.
     * Der Button wird über postobject[controlData] ermittelt
     * Voraussetzung ist, dass dem Button über die Eigenschaft feld.query_id eine Query zugeordnet wurde
     * 
     *             
     * @return  mixed                       array mit query_id, querry_app_id und query_ref_field_connection_id 
     *                                      oder false
     */
    function getQueryIDFromButton() {

        $intern_post_array = $this->getInternPostArray();
        //button ermitteln
        $button_name = $intern_post_array["controlData"]["formkey_that_call_function"];
        
        //Wenn Button in Button in Symbolleiste steckt, dann kann Titel über controldata ermittelt werden.
        $button_titel = $intern_post_array["controlData"][$button_name];

        
        //Wenn Button in einem Datensatz integriert ist.
        if($button_titel == "") {
            $button_name = $this->getSenderButtonName();
            $button_id = str_replace("o","0",$this->getFieldidFromButtonname($button_name));
            $condition = "id = ".$button_id;
        } else {
            //        $form_id = $intern_post_array["controlData"]["form_id_that_call_function"];
            //$condition = "form_id = ".$form_id." AND name = '".$button_titel."'";     
            //Problem: Form-ID entspricht dem aktuellen Formular der Daten. 
            //Der Button kann sich aber in einer Symbolleiste befinden und hätte dann eine andere Form-ID.
            //Nun besteht jedoch das Problem, dass der Buttonname möglicherweise nicht eindeutig ist.
            //ToDo: Der Buttonname sollte eindeutiger werden, bspw. indem die Form-Id der Symbolleiste oder die Feld-ID des Buttons integriert wird.
            $condition = "name = '" . $button_titel . "'";
        }
        
        
        
        $FieldList = getTableData(global_variables::getAppIdFromSYS01(), "feld", global_variables::getNameOfDbSchemaSYS01(), 0, "", $condition);
        if (isset($FieldList[0])) {
            $myField = $FieldList[0];       //theoretisch sollte diese Liste nur genau einen Datensatz (ein Feld) enthalten
        } else {
            $myField = false;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Felddaten für Button konnte nicht ermittelt werden.: ', "condition: " . $condition, "ERROR");
        }



        if (isset($myField["feld.query_id"]) AND isset($myField["feld.query_app_id"])) {
            $feedback["query_id"] = $myField["feld.query_id"];
            $feedback["query_app_id"] = $myField["feld.query_app_id"];
            $feedback["query_ref_field_connection_id"] = $myField["feld.query_ref_field_connection_id"];
        } else {
            $feedback = false;
        }

        return $feedback;
    }

    /**
     * Ermittelt aus dem internPostArray nur die geänderten und neuen Datensätze 
     * (Änderung durch User -> Anschließend Button gedrückt) 
     */
    function buildArrayWithChangedAndNewData($internPostArray) {
        $allDataset = $internPostArray;
        $form_mode = "other";
        if (isset($allDataset["contentData"])) {
            $allContentData = $allDataset["contentData"];
            if ($allDataset["controlData"]["last_form_modus"] == 2) {
                $form_mode = "insert";
            }
        } else {
            $allContentData = array();
        }
        $changedData = array();
        $newData = array();
        $feedback = array();
        $trennzeichen = getConfig("db_trennzeichen", $this->_app_id_from_kernel);
        $security_alert = false;                        //Kennzeichen wird auf true gesetzt, wenn eine Manipulation an den Werten von geschützten Feldern erkannt wurde



        foreach ($allContentData as $key1 => $currentData) {

            if ($currentData["content"] != array()) {               //Wenn der aktuelle Datensatz nicht nur ein leeres array enthält werden die nachfolgenden Anweisungen ausgeführt.
                $gesamtString = '';                                 //variable, die alle Inhalte eines Datensatzes aufnehmen kann. So kann anhand des Hash-Wertes erkannt werden, ob Daten verändert wurden
                $field_separator = getConfig("field_separator", global_variables::getAppIdFromSYS01());
                $formID = $currentData["form"];
                $datarow = $currentData["ds"];
                foreach ($currentData["content"] as $fieldColumn => $value) {
                    //Prüfen, ob ein Wert in Session->FormBackup->valuesSecureFields enthalten ist
                    if (strpos($fieldColumn, ".") !== false) {
                        //in fieldColumn ist der Tabellenname enthalten
                        $tableAndColumn = explode(".", $fieldColumn);
                        $column = $tableAndColumn[1];
                    } else {
                        $column = $fieldColumn;
                    }
                    $fieldKey = $trennzeichen . $currentData["schema"] . $trennzeichen . $currentData["table"] . $trennzeichen . $column . $trennzeichen . substr($key1, strpos($key1, "_") + 1);
                    $valueFromBackup = $this->getValueFromSecureField($fieldKey, $formID, $datarow);
                    //echo "fieldKey: ".$fieldKey." formID: ".$formID." datarow: ".$datarow." foundValueFromBackup: ".$valueFromBackup["foundValue"]." valueFromBackup: ".$valueFromBackup["value"]." <br />";
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> geänderte Daten: ', $currentData["content"]);
                    if ($valueFromBackup["foundValue"] === false) {
                        //Security: Wenn im Backup kein Wert vorhanden ist, handelt es sich nicht um ein geschütztes Feld. Daher wird der Wert vom Client genutzt
                        $gesamtString = $gesamtString . $value . $field_separator;
                    } else {
                        If ($value != $valueFromBackup["value"]) {
                            //Der Inhalt eines geschützten Feldes weicht vom Backup-Wert ab. Theoretisch muss eine unerlaubte Manipulation am Client vorgenommen worden sein.
                            //ToDo: Die Situation tritt auch auf, wenn ein Formular im Modus 3 (filter) aufgerufen wurde. Dann dürfen in den geschützten Felder Werte erfasst werden.
                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Manipulationsversuch! Der Wert des Feldes: ' . $fieldKey . ' wurde unerlaubt am Client geändert', 'Originalwert: ' . $valueFromBackup["value"] . ' geänderter Wert: ' . $value, "SECURITY");
                            $security_alert = true;
                        }
                        $gesamtString = $gesamtString . $valueFromBackup["value"] . $field_separator;
                    }
                }
                if ($security_alert == false) {
                    //Wenn keine Manipulation der geschützten Felder erkannt wurde
                    $new_hash = md5($gesamtString);
//                    $new_hash = $gesamtString;       //Wenn Klartext statt Hash verwendet werden soll, dann zugehörige Funktion in showFields._getFieldHiddenHashvalue ebenfalls ändern.
                    if (isset($currentData["hash"])) {
                        $old_hash = $currentData["hash"];
                        if ($new_hash != $old_hash) {
                            //Wenn sich die Hash-Werte geändert haben, dann den Datensatz in einem extra Array speichern
                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> HashWerte der geänderten DS: ', 'old_hash: ' . $old_hash . ' new_hash: ' . $new_hash . ' neuer Gesamtstring: ' . $gesamtString);
                            $changedData[] = $currentData;
                            if ($form_mode == "insert") {
                                $newData[] = $currentData;
                            }
                        } elseif ($form_mode == "insert") {
                            //im Modus new kann es sein, dass alter und neuer hash-Wert identisch sind.
                            //Diese Situation tritt auf, wenn bereits die Vorgabewerte eines Insert-Formulars
                            //ausreichend sind, um das Formular korrekt validiert abzusenden.
                            $newData[] = $currentData;
                        }
                    }
                }
            }
            $security_alert = false;
        }

        $feedback["changedData"] = $changedData;
        $feedback["newData"] = $newData;
        return $feedback;
    }

    /*     * Ermittelt aus InternPostArray alle Datensätze, die das Attribut "mark" haben.
     * 
     * @param type $internPostArray
     * @return type
     */

    function buildMarkedData(&$internPostArray) {
        $allDataset = $internPostArray;
        if (isset($allDataset["contentData"])) {
            $allContentData = $allDataset["contentData"];
        } else {
            $allContentData = array();
        }
        $markedData = array();
        $trennzeichen = getConfig("db_trennzeichen", $this->_app_id_from_kernel);
        $security_alert = false;                        //Kennzeichen wird auf true gesetzt, wenn eine Manipulation an den Werten von geschützten Feldern erkannt wurde


        foreach ($allContentData as $datensatzKey => $currentData) {
            if (isset($currentData["mark"]) OR isset($currentData["button_used"])) {
                $formID = $currentData["form"];
                $datarow = $currentData["ds"];
                //Prüfen, ob geschützte  Daten manipuliert wurden.
                foreach ($currentData["content"] as $fieldColumn => $value) {
                    //Prüfen, ob ein Wert in Session->FormBackup->valuesSecureFields enthalten ist
                    if (strpos($fieldColumn, ".") !== false) {
                        //in fieldColumn ist der Tabellenname enthalten
                        $tableAndColumn = explode(".", $fieldColumn);
                        $column = $tableAndColumn[1];
                    } else {
                        $column = $fieldColumn;
                    }
                    $fieldKey = $trennzeichen . $currentData["schema"] . $trennzeichen . $currentData["table"] . $trennzeichen . $column . $trennzeichen . substr($datensatzKey, strpos($datensatzKey, "_") + 1);

                    $valueFromBackup = $this->getValueFromSecureField($fieldKey, $formID, $datarow);
                    //echo "fieldKey: ".$fieldKey." formID: ".$formID." datarow: ".$datarow." foundValueFromBackup: ".$valueFromBackup["foundValue"]." valueFromBackup: ".$valueFromBackup["value"]." <br />";
                    if ($valueFromBackup["foundValue"] === false) {
                        //Security: Wenn im Backup kein Wert vorhanden ist, handelt es sich nicht um ein geschütztes Feld. Daher wir der Wert vom Client genutzt
                    } else {
                        If ($value != $valueFromBackup["value"]) {
                            //Der Inhalt eines geschützten Feldes weicht vom Backup-Wert ab. Theoretisch muss eine unerlaubte Manipulation am Client vorgenommen worden sein.
                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Manipulationsversuch! Der Wert des Feldes: ' . $fieldKey . ' wurde unerlaubt am Client geändert', 'Originalwert: ' . $valueFromBackup["value"] . ' geänderter Wert: ' . $value, "SECURITY");
                            $security_alert = true;
                        }
                    }
                }

                if ($security_alert == false) {
                    //Wenn keine Manipulation der geschützten Felder erkannt wurde
                    //markierten zurückgeben
                    $markedData[] = $currentData;
                }
            }
        }

        //check Konsistent
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> MarkedData vor checkKonsistenz', $markedData, "INFO");       
        $markedData = $this->checkMarkedDataConsistency($markedData);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> MarkedData nach checkKonsistenz', $markedData, "INFO");



        return $markedData;
    }

    /** Prüft das Array der markierten Daten auf Inkonsistenz. Diese kann auftreten, wenn ein
     * Formular über weitere eingebettete Formulare verfügt. Wir im eingebetteten Formular
     * ein Datensatz markiert, aber in der Symbolleiste des Parentformular der Button geklickt,
     * dann wird fälschlicherweise der Parentdatenssatz, als markierter Datensatz behandelt. 
     * Das würde dazu führen, dass dieser inkl. aller Child-Datensätze gelöscht werden würden,
     * obwohl nur ein Childdatensatz markiert war.
     * 
     * Die Funktion prüft, ob ein markierter und ein ButtonClick-Datensatz gefunden wurden.
     * Falls ja, wird der ButtonClick-Datensatz aus dem Mark-Datensatz-Array entfernt.
     * 
     * @param   array   $in_markedData      Array der markierten Content-Datensätze aus internPostArray
     * @return  array
     */
    private function checkMarkedDataConsistency($in_markedData) {
        $markedData = array();
        $buttonClickedData = array();
        $feedback = array();

        foreach ($in_markedData as $currentData) {
            if (isset($currentData["mark"])) {
                $markedData[] = $currentData;
            }
            if (isset($currentData["button_used"])) {
                $buttonClickedData[] = $currentData;
            }
        }

        if (count($markedData) == 0) {
            $feedback = $buttonClickedData;
        } else {
            $feedback = $markedData;
        }

        return $feedback;
    }

    /** Gibt aus den internPostArray nur die geänderten Datensätze in einem zweidimensionalen Array zurück.
     * 
     * Muster:
     * Array
      (
      [0] => Array
      (
      [form] => 59
      [content] => Array
      (
      [bew_id] => 1
      [id] => 1
      [abschl] => BL
      [antragsstatus] =>
      [bemerkung] => test
      [zulassung_durch] =>
      )

      [schema] => widerspruch
      [table] => bew_antrag
      [hash] => f9e262a7c00382520a32abae5629f5d6
      )

      [1] => Array
      (
      [form] => 59
      [content] => Array
      (
      [bew_id] => 1
      [id] => 3
      [abschl] => BL
      [antragsstatus] =>
      [bemerkung] => Hallo
      [zulassung_durch] =>
      )

      [schema] => widerspruch
      [table] => bew_antrag
      [hash] => 5419dc6d62f4f29379d833f8de443c90
      )
     * 
     * 
     * @return Array                das Array kann ggf. auch leer sein [array()]
     */
    function getChangedData() {
        return $this->_changedDataArray;
    }

    /** Gibt aus den internPostArray nur die neuen Datensätze (form_mode == insert) in einem zweidimensionalen Array zurück.
     * 
     * Muster:
     * Array
      (
      [0] => Array
      (
      [form] => 59
      [content] => Array
      (
      [bew_id] => 1
      [id] => 1
      [abschl] => BL
      [antragsstatus] =>
      [bemerkung] => test
      [zulassung_durch] =>
      )

      [schema] => widerspruch
      [table] => bew_antrag
      [hash] => f9e262a7c00382520a32abae5629f5d6
      )


     * 
     * 
     * @return Array                das Array kann ggf. auch leer sein [array()]
     */
    function getNewData() {
        return $this->_newDataArray;
    }

    /** Legt das Array mit den neuen Datensätzen komplett neu fest. 
     * 
     * @param array $in_array       Das Array muss folgenden Aufabu haben: <br />
     * Array
      (
      [0] => Array
      (
      [form] => 59
      [content] => Array
      (
      [bew_id] => 1
      [id] => 1
      [abschl] => BL
      [antragsstatus] =>
      [bemerkung] => test
      [zulassung_durch] =>
      )

      [schema] => widerspruch
      [table] => bew_antrag
      [hash] => f9e262a7c00382520a32abae5629f5d6
      )


     *                              
     */
    function setNewData($in_array) {
        $this->_newDataArray = $in_array;
    }
    
    
    
    
    /** Legt das Array mit den geänderten Datensätzen komplett neu fest. 
     * 
     * @param array $in_array       Das Array muss folgenden Aufabu haben: <br />
     * * Array
    (
        [0] => Array
            (
                [ds] => 0
                [form] => 1359
                [content] => Array
                    (
                        [ou_pnr.id] => 5240
                        [ou_pnr.k_ou_id] => 7567
                        [ou_pnr.ou] => 00
                        [ou_pnr.pnr] => -1
                        [ou_pnr.manuell] => 1
                    )

                [mark] => mark
                [schema] => omb
                [table] => ou_pnr
                [hash] => d82b781d7ce3f4d639a8cd07c3abf1c0
                [instance_id] => i0
            )

        [1] => Array
            (
                [ds] => 1
                [form] => 1359
                [content] => Array
                    (
                        [ou_pnr.id] => 22
                        [ou_pnr.k_ou_id] => 7572
                        [ou_pnr.ou] => 01000000
                        [ou_pnr.pnr] => 26791
                        [ou_pnr.manuell] => 0
                    )

                [mark] => mark
                [schema] => omb
                [table] => ou_pnr
                [hash] => 98ada2b5130d16c759fd320430850c2e
                [instance_id] => i0
            )

    )

     *                              
     */
    function setChangedData($in_array) {
        $this->_changedDataArray = $in_array;
    }
    
    
    
    
    /** Legt das Array mit den markierten Datensätzen komplett neu fest. 
     * 
     * @param array $in_array       Das Array muss folgenden Aufabu haben: <br />
     * Array
(
    [0] => Array
        (
            [ds] => 0
            [form] => 1359
            [content] => Array
                (
                    [ou_pnr.id] => 5240
                    [ou_pnr.k_ou_id] => 7567
                    [ou_pnr.ou] => 00
                    [ou_pnr.pnr] => -1
                    [ou_pnr.manuell] => 1
                )

            [mark] => mark
            [schema] => omb
            [table] => ou_pnr
            [hash] => d82b781d7ce3f4d639a8cd07c3abf1c0
            [instance_id] => i0
        )

    [1] => Array
        (
            [ds] => 1
            [form] => 1359
            [content] => Array
                (
                    [ou_pnr.id] => 22
                    [ou_pnr.k_ou_id] => 7572
                    [ou_pnr.ou] => 01000000
                    [ou_pnr.pnr] => 26791
                    [ou_pnr.manuell] => 0
                )

            [mark] => mark
            [schema] => omb
            [table] => ou_pnr
            [hash] => 98ada2b5130d16c759fd320430850c2e
            [instance_id] => i0
        )

)

     *                              
     */
    function setMarkedData($in_array) {
        $this->_markedDataArray = $in_array;
    }
    
    

    /** Ersetzt in changedData[id] den Wert des keys "content".
     * Dieser hat bspw. folgende Syntax:
     * 
     * [content] => Array
      (
      [bew_id] => 1
      [id] => 3
      [abschl] => BL
      [antragsstatus] =>
      [bemerkung] => Hallo
      [zulassung_durch] =>
      )
     * 
     * @param   integer $in_id          id des Datensatzes in changedData, dessen Wert von content geändert werden soll.
     * @param   array   $in_content     array, wie oben gezeigt.
     */
    function setChangedDataContent($in_id, $in_content) {
        $this->_changedDataArray["$in_id"]["content"] = $in_content;
    }

    /** Ersetzt in NewData[id] den Wert des keys "content".
     * Dieser hat bspw. folgende Syntax:
     * 
     * [content] => Array
      (
      [bew_id] => 1
      [id] => 3
      [abschl] => BL
      [antragsstatus] =>
      [bemerkung] => Hallo
      [zulassung_durch] =>
      )
     * 
     * @param   integer $in_id          id des Datensatzes in newData, dessen Wert von content geändert werden soll.
     * @param   array   $in_content     array, wie oben gezeigt.
     */
    function setNewDataContent($in_id, $in_content) {
        $this->_newDataArray["$in_id"]["content"] = $in_content;
    }

    /** Ergänztein ein einzelnes Attribut zu NewData[id][content].
     * Ergebnis: <br />
     * [content] => Array
      (
      [bew_id] => 1
      [id] => 3
      [$in_attributKey] => $in_attributValue
      )
     * 
     * 
     * @param   integer $in_id              id des Datensatzes in newData, dessen Wert von content ergänzt werden soll.
     * @param   string  $in_attributKey     Key des neuen Wertes
     * @param   string  $in_attributValue   Value des neuen Wertes
     */
    function addNewDataContentAttribut($in_id, $in_attributKey, $in_attributValue) {
        if (isset($this->_newDataArray["$in_id"])) {
            $this->_newDataArray["$in_id"]["content"][$in_attributKey] = $in_attributValue;
        }
    }
    
    
    
    
     /** Ergänzt ein einzelnes Attribut zu NewData[id][content] oder ChangedData[id][content]; je nachdem, welches Array existiert
     * Ergebnis bspw.: <br />
     * [content] => Array
      (
      [bew_id] => 1
      [id] => 3
      [$in_attributKey] => $in_attributValue
      )
     * 
     * 
     * @param   integer $in_id              id des Datensatzes in newData oder changedData, dessen Wert von content ergänzt werden soll.
     * @param   string  $in_attributKey     Key des neuen Wertes
     * @param   string  $in_attributValue   Value des neuen Wertes
     */
    public function addAttributToNewOrChangedData($in_id, $in_attributKey, $in_attributValue) {
        
        if (isset($this->_newDataArray["$in_id"])) {
            $this->_newDataArray["$in_id"]["content"][$in_attributKey] = $in_attributValue;
        }
        
        
        if (isset($this->_changedDataArray["$in_id"])) {
            $this->_changedDataArray["$in_id"]["content"][$in_attributKey] = $in_attributValue;
        }
    }
    
    
    
    
    

    /** Ergänzt zu Newdata einen neuen Datensatz. Dieser muss wie folgt aufgebaut sein (content ist natürlich flexibel) <br />
     * Array
      (
      [0] => Array
      (
      [ds] => 0
      [form] => 212
      [content] => Array
      (
      [id] => 16823
      [bst] => 02600000
      [uid] => arusu
      [aktiv] => t
      [access_read] => 1
      [delegate_allowed] => t
      [k_tit_grp_id] => 1
      [_k_tit_grp_id] => 0
      [valid_from] =>
      [valid_to] =>
      [editor] => bim01admin
      )

      [schema] => allg
      [table] => permission_bst
      [hash] => 8ecd8c054bc2a1c606e9366c762c66bf
      [instance_id] => i0new
      [button_used] => 1
      [button_name] => button__id2214_00022140Form212_1_i0new
      )

      )
     * 
     * @param   array       $in_newData     neuer Datensatz; Syntax, siehe oben.
     * @param   string      $in_pos         [first|last]; Gibt an, ob der Datensatz am Anfang, oder am Ende ergänzt werden soll
     */
    function addNewDataContent($in_newData, $in_pos) {
        $existingData = $this->_newDataArray;
        $newArray = array();
        if ($in_pos == "first") {
            $newArray[] = $in_newData;
            foreach ($existingData as $currentExistingData) {
                $newArray[] = $currentExistingData;
            }
        } else {
            foreach ($existingData as $currentExistingData) {
                $newArray[] = $currentExistingData;
            }
            $newArray[] = $in_newData;
        }
        $this->_newDataArray = $newArray;

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> newData mit ergänzten Datensätzen: ", $this->_newDataArray);
    }

    /** Gibt die vom User markierten Datensätze aus dem internPostObjekt zurück
     * 
     * @return array or boolean (false)
     */
    function getMarkedData() {
        if (isset($this->_markedDataArray)) {
            return $this->_markedDataArray;
        } else {
            return false;
        }
    }

}

/**
 * Nimmt alle Informationen auf, welche in der InfoBox ausgegeben werden sollen.
 */
class InfoBox {

    /** mehrdimensionales Array, welches belibig viele messages enthält.
     * 
     *  Dimension 1: key = lfd. Nr.; value = array(Dimension 2)
     *  Dimension 2: keys = (icon|time|message|type); values = (Pfad zum icon| Zeit der Meldung| Meldungstext| Art der Meldung: success|info|error)
     *  
     */
    private $_messages = array();
   

    /** Erzeugt die InfoBox, welche dem Anwender Statusmeldungen darstellt. 
     * Die Infobox kann wiederum einem anderen HTMLTag als value hinzugefügt werden.
     * Wenn beim letzten Maskenaufbau per setSessionMessageToField eine Meldung für "infobox" abgelegt wurde,
     * wird diese nun geladen.
     * 
     */
    function __construct() {
        $message = session_class::$session_object->getLastMessageForInfobox("infobox");
        if ($message !== false) {
            $this->addMessage($message, "success", global_variables::getAppIdFromSYS01());
            session_class::$session_object->clearSessionMessageForInfobox();        //Meldung löschen, damit sie nach der nächsten Aktion nicht erneut angezeigt wird.
        }
    }

    /** Ergänzt eine Meldung zur Liste der Meldungen ($this->_messages.
     * Eine Meldung ist ein Array mit folgenden Attributen <br />
     *      array(  <br />
     *              type => [success|info|error],   <br />
     *              message => [text],              <br />
     *              time => date("H:i:s"),          <br />
     *              icon => [$img_path."success.png"|$img_path."info.png"|$img_path."error.png"],   <br />
     *              class => [message_success|message_info|message_error])  <br />
     * 
     * @param string $in_message                Text der Meldung
     * @param string $in_type                   Typ der Meldung (success, info, error)
     * @param string $in_appID                  app_id der Tabelle konstante; davon abhängig können pro app unterschiedliche Icons  (success, info, error) hinterlegt werden.
     */
    function addMessage($in_message, $in_type, $in_appID) {
        $message = array();

        $message["type"] = $in_type;
        $message["message"] = $in_message;
        $message["time"] = date("H:i:s");
        $myDirSep = global_variables::getDirectorySeparator();
        $img_path = ".." . $myDirSep . global_variables::getPathForImages_rel($in_appID);

        if ($in_type == "success") {
            $icon = $img_path . "success.png";
            $class = "message_success";
        } elseif ($in_type == "info") {
            $icon = $img_path . "info.png";
            $class = "message_info";
        } elseif ($in_type == "error") {
            $icon = $img_path . "error.png";
            $class = "message_error";
        } else {
            $icon = "";
            $class = "message_info";
        }

        $message["icon"] = $icon;
        $message["class"] = $class;
        
        
        
        
        if($this->_messages == array()) {
            //Wenn noch keine Message existiert, wird die neue ergänzt.
            $this->_messages[] = $message;
        } elseif($this->_messages[0]["class"] == "message_info") {
            //Wenn vorhandene Message "nur" vom Typ message_info ist, dann wird sie ersetzt.
            $this->_messages = array();
            $this->_messages[] = $message;
        } elseif($message["class"] == "message_info") {
            //Wenn bereits eine Message existiert und die neue "nur" vom Typ message_info ist, dann wird die neue nicht ergänzt.
        } elseif($this->_messages[0]["class"] == "message_error") {
            //Wenn die vorhandene Message bereits vom Typ message_error ist, dann wird sie nicht ersetzt.   
        } else {
            //in allen anderen Situationen wird die neue Message ergänzt.
            $this->_messages[] = $message;
        }
        
    }

    /**
     * Gibt die Meldungen als HTML-Code zurück
     * @param   integer $in_parent_tag_id       ID des übergeordenten tags. Dies ist notwendig, damit für die Infobox eine eindeutige ID generiert werden kann.
     */
    function printHtmlCode($in_parent_tag_id) {
        $htmlcode = "";
        
        //Pro Meldung wird eine InfoBox eingefügt
        //Rahmen für die Infobox erstellen
        foreach ($this->_messages as $key => $message) {
            $class = $message["class"];
            $htmlcode = $htmlcode . "<div id=\"div_infobox_$in_parent_tag_id\" class=\"" . $class . "\" role=\"dialog\" aria-label=\"Infobox\" >";

            $htmlcode = $htmlcode . "<section role=\"none\">";

            $htmlcode = $htmlcode . "<div id=\"message_".$key."_".$in_parent_tag_id."\" class=\"message_content\" role=\"none\">";
            $htmlcode = $htmlcode . "<span id=\"message_icon_".$key."_".$in_parent_tag_id."\" class=\"message_icon\" role=\"none\">";
            $htmlcode = $htmlcode . "<img src=" . $message["icon"] . " alt=\"Symbol ".$message["type"]."\">";
            $htmlcode = $htmlcode . "</span>";

            $htmlcode = $htmlcode . "<div id=\"message_time_".$key."_".$in_parent_tag_id."\">";
            $htmlcode = $htmlcode . $message["time"] . ": ";
            $htmlcode = $htmlcode . "</div>";

            $htmlcode = $htmlcode . "<div id=\"message_text_".$key."_".$in_parent_tag_id."\" role=\"alert\">";
            $htmlcode = $htmlcode . $message["message"];
            $htmlcode = $htmlcode . "</div>";
            $htmlcode = $htmlcode . "</div>";
            $htmlcode = $htmlcode . "<br />";

            $htmlcode = $htmlcode . "</section>";
            $htmlcode = $htmlcode . "</div>";
        }


        return $htmlcode;
    }

}

/**
 * Erstellt aus dem GET-Array ein internesGET-Object, indem die Daten getrennt nach Steuerungsdaten (mask_app_id, mask_id) und Vorbelegungswerten für Felder (fieldcontent)abgelegt werden.
 * 
 */
class GET_Data {

    /**
     *
     * @var     string      App-ID der aufgerufenen Maske 
     */
    private $_mask_app_id;

    /**
     *
     * @var     integer     ID der aufgerufenen Maske 
     */
    private $_mask_id;

    /**
     *
     * @var     string      Wenn der Logout-Button gedrückt wurde, dann gibt es den URL-Paramter logout=true. ACHTUNG, dabei handelt es sich aber um einen String!
     */
    private $_logout;

    /**
     *
     * @var     string      [optional] APP-ID der zu nutzenden CSS-Klasse 
     */
    private $_css_app_id;

    /**
     *
     * @var     integer     ID der zu nutzenden CSS-Klasse 
     */
    private $_css_id;

    /**
     * 
     * @var     string      eindeutige ID, in Form eines Hash-Wertes, anhand dessen über die DB-Tabelle workflow_status, ein Workflow und dessen aktueller Stand ermittelt werden kann.
     */
    private $_workflow_urlid = "";

    /**
     *
     * @var     array       Liste der Vorbelegungswerte für Felder 
     */
    private $_field_list = array();
    
    
    private $_change_app = "";
    
    private $_tab_id;
    
    /**
     * 
     * @var     array       Enthält Conditions, welche  zur weiteren Einschränkung der aktuellen Sichtrechte in einem Formular verwendet werden können.
     *                      Bsp.: array(form234 => "name = 'Startseite' and app_id = 'SYS01'")
     */
    private $_ds_conditions = array();
    
    
    /**
     * 
     * @var     integer     Gibt an, ob der Maskenaufruf durch einen automatischen Button-Klick von appms.js erfolgte.  1 = true; Default = 0
     */
    private $_auto_clicked_button = 0;          

    /**
     *
     * @var     array       Arry, welches alle erlaubten Werte des $_GET-Arrays enthält 
     */
    private $_internGetArray = array();
    
    /**
     * 
     * @var     bool        Gibt an, dass nur das angefragte Formular (inkl. abhängige Formulare) übergeben werden soll.
     */
    public  bool $_loadOnlyTargetForm = false;
    
    /**
     * 
     * @var     string      ID des Formulars, welches separat abgerufen werden soll.
     */
    public string  $targetForm = "";

    /** Wandelt das $_GET-Array in ein Objekt um. Dabei werden verschiedenen Prüfungen durchgeführt und
     * benötigte Methoden zur Verfügung gestellt. Neben dieser Funktion, darf nur der Session.+-Handler diret auf die $_GET-
     * Variable zugreifen. Ale anderen Methoden müssen pagedata->internGetObject nutzen!
     * 
     * @param type $in_GET
     */
    function __construct(&$in_GET) {
        //immer verfügbare Steuerungsdaten ermitteln
        if (isset($in_GET["maskapp"]))      {$this->_mask_app_id            = $in_GET["maskapp"];}
        if (isset($in_GET["mask"]))         {$this->_mask_id                = $in_GET["mask"];}

        //optionale Steuerungsdaten ermitteln
        if (isset($in_GET["css_app"]))      {$this->_css_app_id             = $in_GET["css_app"];}
        if (isset($in_GET["css_id"]))       {$this->_css_id                 = $in_GET["css_id"];}
        if (isset($in_GET["logout"]))       {$this->_logout                 = $in_GET["logout"];}
        if (isset($in_GET["url_id"]))       {$this->_workflow_urlid         = $in_GET["url_id"];}
        if (isset($in_GET["change_app"]))   {$this->_change_app             = $in_GET["change_app"];}
        if (isset($in_GET["auto_clicked"])) {$this->_auto_clicked_button    = $in_GET["auto_clicked"];}
        if (isset($in_GET["tab_id"]))       {$this->_tab_id                 = $in_GET["tab_id"];}
        if (isset($in_GET["loadonlytargetform"])) {$this->_loadOnlyTargetForm = true;}
        if (isset($in_GET["targetform"]))   {$this->targetForm             = $in_GET["targetform"];}
        


        //Vorbelegungswerte für Felder ermitteln (falls vorhanden)
        $this->_field_list = $this->buildFieldArray($in_GET);
        
        //Prüfen, ob einschränkende conditions für das aktuelle Formular enthalten sind.
        //Die Sichtrechte können dadurch nicht ausgeweitet, sondern nur eingeschränkt werden
        $this->_ds_conditions = $this->buildConditionArray($in_GET);
        

        //legt alle erlaubten Werte in dem neuen GET-Array ab.
        $this->_internGetArray = $this->buildInternGetArray();
    }

    
    
    
    
    
    
    /** Die Funktion prüft, ob Vorbelegungswerte für Felder im $_GET-Array vorhanden sind.
     * Falls ja, werden diese unter Angabe der Field-ID in einem Array zurück gegeben.
     * 
     * @param type $in_GET
     * @return array    Liste der Feldvorbelegungswerte
     */
    private function buildFieldArray(&$in_GET) {
        $feedback = array();
        foreach ($in_GET as $key => $value) {
            if (strpos($key, "field") !== false) {
                $id = substr($key, 5);
//                If(is_int($id)) {
                $feedback[$id] = $value;

//                }
            }
        }

        return $feedback;
    }
    
    
    
    /** Die Funktion prüft, ob Bedingungen enthalten sind, die zu den Formularconditions ergänzt werden sollen.
     * Falls ja, werden diese in einem Array zurück gegeben.
     * Bsp. für GET-Parameter: cond_name=Startseite&cond_app_id=SYS01
     * 
     * @param   array   $in_GET
     * @return  array               key = "cond" + form_id; value = sql-String, der zur Where-Klausel ergänzt werden kann.
     *                              Bsp.: array(form234 => "name = 'Startseite' and app_id='SYS01'")
     */
    private function buildConditionArray(&$in_GET) {
        $feedback = array();
        $temp = "";
        $seperator = "";
        $form = "";
        foreach ($in_GET as $key => $value) {
            if (strpos($key, "cond") !== false) {
                $column = substr($key, 5);
                $temp = $temp.$seperator.$column."='".$value."'";
                $seperator = " and ";
            } elseif($key == "targetform") {
                $form = "form".$value;
                
            }
        }
        
        if($temp != "") {
            if($form != "") {
                $feedback[$form] = $temp;
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> targetForm fehlt: ', "Es wurden in den GET-Parametern Bedingungen für einzelne Datenbankspalten gefunden, jedoch fehlt der Parameter 'targetform'.", "ERROR");
            }
            
        }
        return $feedback;
    }
    
    

    /** Gibt alle Werte des GET-Objektes in einem Array zurück
     * 
     * @return array
     */
    private function buildInternGetArray() {
        $feedback = array();

        $feedback["mask_app_id"]        = $this->_mask_app_id;
        $feedback["mask_id"]            = $this->_mask_id;
        $feedback["css_app_id"]         = $this->_css_app_id;
        $feedback["css_id"]             = $this->_css_id;
        $feedback["workflow_urlid"]     = $this->_workflow_urlid;
        $feedback["change_app"]         = $this->_change_app;
        $feedback["fieldlist"]          = $this->_field_list;
        $feedback["tab_id"]             = $this->_tab_id;
        $feedback["add_form_conditions"] = $this->_ds_conditions;
        
        
        return $feedback;
    }

    /** Gibt die Liste der erlaubten GET-Parameter zurück.
     * 
     * @return  array           Bsp.: Array <br />
      ( <br />
      [mask_app_id] => REQ11 <br />
      [mask_id] => 254 <br />
      [css_app_id] => SYS01 <br />
      [css_id] => 10 <br />
      [tab_id] => tab1-Session <br />
      [fieldlist] => Array <br />
      ( <br />
      [4106] => testVM <br />
      [4121] => 34 <br />
      )<br />

      )
     */
    public function getInternGetArray() {
        return $this->_internGetArray;
    }
    
    
    
    
    /** Gibt an, ob in der URL der GET-Parameter auto_clicked gesetzt war.
     * 
     * @return bool
     */
    public function isButtonAutoclickedTrue() {
        if($this->_auto_clicked_button == 1) {
            return true;
        } else {
            return false;
        }
    }
    
    
    

    /** Gibt an, ob per Get-Parameter Vorgabewerte für Feld-IDs übergeben wurden.
     * 
     * @return boolean
     */
    public function existGetFields() {
        if (count($this->_field_list) > 0) {
            return true;
        } else {
            return false;
        }
    }

    /** Gibt die Liste der Felder, für welche Vorgabewerte existieren, zurück.
     * 
     * @return array    Fieldlist des GET-Objektes; Bsp.: <br />
      Array <br />
      ( <br />
      [4106] => testVM <br />
      [4121] => 34 <br />
      ) <br />
     */
    public function getFieldlist() {
        return $this->_field_list;
    }
    
    
    
    /** Falls über GET-Parameter zusätzliche Einschränungen für die Datensätze ([add]form_condition) mitgegeben wurden, werden diese in SQL-Syntax zurückgegeben
     * 
     * @param   integer     $in_form_id         ID des Formulars
     * @return  string                          Bsp.: "name = 'Startseite' and app_id = 'SYS01'"   oder Leerstring
     */
    public function getFormConditions($in_form_id) {
        
        $current_get_array = $this->getInternGetArray();
        if(isset($current_get_array["add_form_conditions"]["form".$in_form_id])) {
            $feedback = $current_get_array["add_form_conditions"]["form".$in_form_id];
        } else {
            $feedback = "";
        }
        
        return $feedback;
    }
    
    

    /** Gibt die aufgerufene Masken-App-ID zurück.
     * 
     * @return  string      
     */
    public function getMaskAppID() {
        return $this->_mask_app_id;
    }

    /** Gibt die aufgerufene Masken-ID zurück.
     * 
     * @return  integer      
     */
    public function getMaskID() {
        return $this->_mask_id;
    }

    /** Gibt den Hash-Wert, welcher per URL als Workflow-Kennung übergeben wurde, zurück.
     * 
     * @return  string
     */
    public function getWorkflowUrlID() {
        return $this->_workflow_urlid;
    }
    
    
    /** Setzt den Hash-Wert, Workflow-ID.
     * 
     * @param   string      $in_wkfl_id     Hash-Wert des aktuellen Workflow-Steps
     */
    public function setWorkflowUrlID($in_wkfl_id) {
        $this->_workflow_urlid = $in_wkfl_id;
    }

    /** Gibt an. ob die aktuelle Maske im Kontext eines Workflows aufgerufen wurde.
     * 
     * @return  boolean
     */
    public function callWorkflowUrlid() {
        //Wenn die Maske mit dem GET-Parameter "urlid" aufgerufen wurde... 
        if ($this->_workflow_urlid == "") {
            return false;
        } else {
            return true;
        }
    }

}

/**
 * Nimmt alle Elemente auf, welche in der Hiddenbox eingebunden werden sollen.
 */
class HiddenBox {

    /**
     *
     * @var array       Liste aller Formulare 
     */
    private $_formList = array();

    /**
     * Ergänzt die hiddenbox, welche versteckte Formulare aufnimmt. 
     * Anwendungsfall: Formulare zur Erfassung von Datensätzen werden versteckt mit vorbelegten Defaultwerten an den Client übergeben.
     */
    function __construct() {
        
    }

    /**
     * Fügt ein Formular der hiddenbox hinzu
     * 
     * @param string    $in_FormInHtml  Html-Code des kompletten Formulars
     * @param integer   $in_form_id     ID des Formulars
     * @param string    $in_instance_id Instanz-ID des Formulars
     */
    function addForm($in_FormInHtml, $in_form_id, $in_instance_id) {
        $id = $in_form_id . "_" . $in_instance_id;
        $this->_formList[$id] = $in_FormInHtml;
    }

    /** Gibt den Html-Code für die hiddenbox inkl. aller enthaltenden Elemente zurück.
     * 
     * @return string
     */
    function printHtmlCode() {
        $htmlcode = "";

        foreach ($this->_formList as $id => $form) {
            $htmlcode = $htmlcode . "<div id=\"hiddenForm$id\" class=\"container container_hidden\">";
            $htmlcode = $htmlcode . $form;
            $htmlcode = $htmlcode . "</div>";
            $htmlcode = $htmlcode . "<br />";
        }



        return $htmlcode;
    }

}

?>