<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


	//Funktionen zur Darstellung des mittleren Bereichs der Masken, die im Ordner "view" angeboten werden
	
	
	require_once("../controller/functions_db.php");
	require_once("../controller/functions.php");
        require_once("../controller/query_class.php");
        require_once("../controller/html_class.php");


	
        

        /** Gibt eine Liste übergebener Formularelemente (Felder, Buttons), ggfs. mit Inhalt, zurück
         * (Achtung: bei Aufruf durch Tabledata oder Singledata, handelt es sich nur um einen Datensatz
         * 
         * @param Array     $fieldlist                  enthält die anzudruckenden Felder inkl. Feldinhalte
         * @param integer   $showName                   Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @param String    $addToName                  String, der in der Feld_id ergänzt wird. Idealerweise ist das eine fortlaufende Zahl, um eindeutige ID's auf der ganzen Webseite zu erreichen
         *                                              $addToName kann ein Leerstring sein oder folgende Syntax haben: "Form".$in_form_id."_".$datensatzNr."_".$in_currentFormInstanceId -> Bsp.: Form43_0_i0
         * @param object    $in_pagedata                Referenz auf Object pagedata
         * @param string    $in_instanceID              ID der Formularinstanz
         * @param string    $in_add_constructor_class   Name einer css-Klasse die zu allen Dom-Elementen ergänzt wird. (zurzeit nur bei Feldart "Zeilenumbruch")
         * @param String    $addDsID                    [optional] Wenn Wert angegeben wurde, dann wird als erstes Feld der Wert als versteckte Datensatz-ID ausgegeben. Das erleichtert bei mehreren Datensätzen pro Formular (Tabelle) die strukturierte Analyse der POST-Variablen. (default = "")
         * @param Boolean   $addFieldWithHash           [optional] Gibt an, ob am Ende ein zusätzliches Feld mit dem Hash-Wert aller Feldinhalte der anderen Felder erzeugt werden soll. Dieses kann genutzt werden, um zu erkennen, ob ein Feldinhalt geändert wurde. (default = FALSE)
         * @param String    $in_trennzeichen            [optional] Trennzeichen zwischen Schema, Tabellenname und Spaltenname (default = "0")
         * @param Boolean   $in_set_vorgabewert         [optional] Gibt an, ob Vorgabewerte in dem Feld eingetragen werden sollen. Das ist sinnvoll bei der Neuanlage von Feldern (default = FALSE)
         * @param Boolean   $beachte_Pflichtfeldangabe  [optional] Gibt an, ob die Feldeigenschaft "Pflichtfeld" beachtet werden soll. (default = TRUE)
         * @param Array     $in_maskArray               [optional] Array mit allen Angabe der aktuellen Maske (siehe getMaskDataById) (default = array() )
         * @param Array     $form                       [optional] Array des Formulars, für welches die aktuellen Felder ermittelt werden. (default = array("form.id" => 0))
         * @param Boolean   $show_markField             [optional] Gibt an, ob ein Markierungsfeld (Checkbox) vor einer Feldliste angezeigt werden soll. Das ist sinnvoll in Zusammenhang mit Listen (getFormTableData)).
         * @param String    $in_caller                  [optional] Name der Funktion, welche diese Funktion (getFields) aufruft. Diese wird im Debug-Protokoll ausgegeben. Es kann auch eine ID (beliebige Kennung) übergeben werden. (default = "unknown")
         * @param Boolean   $in_with_table              [optional] Wenn true, dann werden die rows und divs mit einer entsprechenden CSS-Klasse markiert.
         * @param Boolean   $in_beachte_readonly        [optional] Gibt an, die Eigenschaft "readonly" beachtet werden soll. Bei Formularen, die im modus "Filter" gezeigt werden, sollte die Eigenschaft nicht beachtet werden. (default = true)
         * @param Boolean   $allways_readonly           [optional] Legt fest, dass alle Felder readonly sind. Dieser Parameter überlagert den Parameter $in_beachte_readonly. (default = false oder true wenn im Kernmodul sys-Datensätze angezeigt werden sollen und der aktuelle User <> sysroot ist.))
         * @param Boolean   $in_rowManageButtonAdd      [optional] Wenn true, wird der Button zum Ergänzen von Neuen Zeilen ergänzt.
         * @param Boolean   $in_rowManageButtonHide     [optional] Wenn true, wird der Button zum Entfernen von Neuen Zeilen ergänzt.
         * @return String                               HTML-Quellcode der Felderliste als String
         * 
         */
        function getFieldsOfRow(&$fieldlist, $showName, $addToName, &$in_pagedata, $in_instanceID, $in_add_constructor_class, $addDsID = "", $addFieldWithHash = FALSE, $in_trennzeichen ="0", $in_set_vorgabewert = FALSE, $beachte_Pflichtfeldangabe=TRUE, $in_maskArray=array(), $form = array("form.id" => 0), $show_markField = TRUE, $in_caller = "unknown", $in_with_table = true, $in_beachte_readonly = true, $allways_readonly = false, $in_rowManageButtonAdd = false, $in_rowManageButtonHide = false) {
                $sumOfFeldinhalt = '';                                          //sammelt alle Feldinhalte in einer Gesamtvariablen
                $field_separator = getConfig("field_separator", global_variables::getAppIdFromSYS01());
                $feedback = ""; 
                $form_id = $form["form.id"];    
                $activate_checkbox = false;
                
                   
                
                //String, welches den HTML-Quelltext aufnimmt
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> fieldlist für form: '.$form["form.id"], $fieldlist);
                
                //Systemdatensätze schützen
                if($in_pagedata->protectSysData($fieldlist) == true AND $showName !=2) {
//                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> protectSysData = true: ', $fieldlist);
                    $allways_readonly = true; 
                    $showNoteForSysData = true;
                } else {
                    $showNoteForSysData = false;
                }

                //Festlegung, ob es sich um den Überschriftendatensatz handelt oder nicht.
                if($showName == 2) {$is_head = true;} else {$is_head = false;}
                
                //Wert des Attributs form_id nachbilden, sodass per Javascript darauf referenziert werden kann.
                $formAttribut_formID = "form_".$form_id."_".$in_instanceID;
                    
                $instance_form_mode = $in_pagedata->getFormPropertyFormmode($form_id, $in_instanceID);
                $fieldObjectTree = new HTMLFieldList($fieldlist, $in_set_vorgabewert, $beachte_Pflichtfeldangabe, $in_pagedata, $instance_form_mode, $in_beachte_readonly, $allways_readonly);
                //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> HtmlFieldObjectTree: ', $fieldObjectTree);
                
                //Berechnete Breite des Formulars im Form_array ablegen
                $form_width = $fieldObjectTree->getWidth();
                if($show_markField === true) {$form_width = $form_width + 70;}
                $in_pagedata->setFormPropertyCalculatedWidth($form_id, $form_width);
                
                
                //Wenn ein Markierungsfeld gesetzt werden soll, wird dieses hier erzeugt. Markierungsfelder können genutzt werden, um ganze Datensätze zu kennzeichnen. form_mode = 2 -> insert
                $htmlCodeForMarkField = "";
                $colIndex = 0;
                if ($show_markField == true AND $form["form.instances"][$in_instanceID]["form.form_mode"] !== 2) {  
                    $colIndex = $colIndex + 1;
                    $markFieldID = "Form".$form_id."markField_".$addDsID;
                    //Bei Single-Data wird das Markierungsfeld immer aktiviert
                    if(strpos($form["form.constructor"], "SingleData") !== false) {$activate_checkbox = true;} else {$activate_checkbox = false;}
                    //Wenn nur ein Datensatz vorhanden ist und der Form-Modus = 4 (activateFilter) ist, dann wird das Markierungsfeld aktiviert. Zudem wird im Html-DomTree die Anweisung an JS übergeben, dass der Details-Button zu klicken ist.
                    if($in_pagedata->getFormPropertyFormmode($form_id, $in_instanceID) == 4 AND $in_pagedata->getFormPropertyCountData($form_id, $in_instanceID) == 1 AND $in_pagedata->getFunctionProp("functionname") !== "internFunction_setConditionForDetaileddata") {
                        $activate_checkbox = true;
                    } 
                    $htmlCodeForMarkField = $htmlCodeForMarkField._getMarkField($form["form.constructor"], $markFieldID, $form["form.app_id"], $showNoteForSysData, $is_head, $formAttribut_formID, $colIndex, $activate_checkbox);
                } 
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> htmlCodeForMarkField: ', $htmlCodeForMarkField);
                
                //Einfügen eines versteckten Feldes, welches den Beginn eines Datensatzes markiert.
                $feedback = $feedback._getFieldHiddenDSMarker($addDsID, $addToName, "start", $htmlCodeForMarkField, $showName);
                
                $insert_linebreack = false;
                foreach ($fieldObjectTree->fieldlist as $key => $value) {
                    $myField = $value;                                          //Aus der Liste der Felder (Objekte), wird das aktuelle gewählt.
                    if($insert_linebreack === true) {$myField->class_container = $myField->class_container." zeilenumbruch";} 
                        //Prüfen, ob das Feld unterdrückt werden soll
                        $hide_field = checkIfFieldShouldSupressed($in_pagedata, $myField, $form_id, $in_instanceID); 
                        If($hide_field !== true) {
                            $colIndex = $colIndex + 1;
                            $myField->colIndex = $colIndex;                             //wird für Barrierefreiheit (aria-colindex) verwendet; muss bei 1 (>0) beginnen.
                    
                       
                            //Wenn kein Feldinhalt angedruckt werden soll, wird dieser gelöscht
                            if ((boolval($in_set_vorgabewert) ? 'true' : 'false') == FALSE) {$myField->feldinhalt="";}


                            if ($myField->id == 528) {
                                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> maskarray: ', $in_maskArray);
                                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Button_target_mask: ', $myField->button_target_mask_link);
                            }

                            if(isset($in_maskArray["id"])) {
                                $mask_id = $in_maskArray["id"];
                                $mask_link = $in_maskArray["link"];
                                $mask_app = $in_maskArray["app_id"];
                            } else {
                                $mask_id = 0;                                       //Startmaske
                                $mask_link = "page.php";                            //Standard-view-Datei
                                $mask_app = global_variables::getAppIdFromSYS01();  //Standard-App
                            }


                            if ($myField->button_target_mask == "") {
                                $myField->button_target_mask = $mask_id;          //wenn keine Zielmaske angegeben wurde, dann ist die aktuelle Maske das Ziel
                                $myField->button_target_mask_link = $mask_link;
                            }
                            if ($myField->button_target_form == "") {$myField->button_target_form = $form_id;}       //wenn kein Zielformular angegeben wurde, dann ist das aktuelle Formular das Ziel


                            


                            $trennzeichen = $in_trennzeichen;
                            If (isset($myField->ldapAttribut) AND $myField->ldapAttribut != '') {                       //name-Attribut in html setzen. Es wird entweder ein Wert in $myField->ldapAttribut oder in $Tabele und $Spalte erwartet
                                $nameAttr = $myField->ldapAttribut."_".$addToName;
                                $idAttr = $myField->ldapAttribut."_".$addToName;
                            } else {
                                //name und id-Attribut in Html gleich halten, da je nach Aktion nach Übersendung Absenden der per Post das name oder das id-Attribut weitergeben wird.
                                //bei Buttons wird vor dem ersten Trennzeichen noch das Kürzel "button__" vorangestellt
                                if($myField->spalte == "") {
                                    //field-id nutzen, damit auf jeden Fall eine eindeutige ID im DOM entsteht.
                                    //dabei müssen Nullen jedoch durch O ersetzt werden, da Null bereits das Standard-Trennzeichen ist.
                                    $myField->spalte = str_replace("0", "O", $myField->id);
                                }
                                $nameAttr = $trennzeichen.$myField->schema.$trennzeichen.$myField->tabelle.$trennzeichen.$myField->spalte.$trennzeichen.$addToName;
                                $idAttr =   $nameAttr;
                            }
                            $myField->idAttr = $idAttr;

                            //Werte von geschützten Feldern in Session-Backup des Formular ablegen
                            if($myField->konstante_id == 112)   {$myField->feldinhalt = str_replace(" ", "T", $myField->feldinhalt ?? '');} //In der DB wird Timestamp im Format "2020-11-21 07:53:40" gespeichert; HTML erwartet jedoch "2020-11-21T07:53:40"
                            if($myField->readonly == true)      {$in_pagedata->setFormDatarowValuesForSecureFields($form_id, $in_instanceID, $addDsID, $nameAttr, $myField->feldinhalt);}
                            if($myField->is_password == true)   {$in_pagedata->setFormDatarowValuesForPasswordFields($form_id, $in_instanceID, $addDsID, $myField->spalte, $myField->feldinhalt);}
                            if($myField->is_encrypted == true)   {$in_pagedata->setFormDatarowValuesForEncryptedFields($form_id, $in_instanceID, $addDsID, $myField->spalte, $myField->feldinhalt);}

                            //Werte von PrimaryKeys in Session-Backup des Formular ablegen
                            if(strpos($form["form.primarykey"], $myField->tabelle.'.'.$myField->spalte)!==false) {$in_pagedata->setFormDatarowValuesForPrimarykeyFields($form_id, $in_instanceID, $addDsID, $myField->tabelle.'.'.$myField->spalte, $myField->feldinhalt); }

                            //Felder markieren, bei denen der Browser bei Änderung und Maskenwechsel nicht vor Datenverlust wegen vergessenen Speichern gewarnt werden soll.
                            if($in_caller != "getSymbolGroup" AND in_array($form["form.instances"][$in_instanceID]["form.form_mode"], array(3,8)) === false) {
                                $myField->addClassCode = $myField->addClassCode." warn_by_leave";
                            }
                            


                            //-------------------------------------------------------------------------------------------------------------------------------
                            //Ab hier wird ein Feld eingefügt, je nach Feldtyp. (siehe Tabelle feld)
                            $instance_mode = $form["form.instances"][$in_instanceID]["form.form_mode"];

                            //ein- oder mehrzeiliges Textfeld
                            if ($myField->konstante_id=="3") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "text", $showName, $instance_mode,$in_instanceID, $form["form.constructor"], $form_id);
                            }

                            //label_1 (Bezeichnung label_type_1)
                            elseif ($myField->konstante_id=="4") {
                                //keine Addition zu $sumOfFeldinhalt, da labels nicht übertragen werden. Der Datensatz würde unnötig als geändert erkannt werden.
                                $feedback = $feedback._getFieldLabel($myField, $nameAttr, $myField->idAttr, $showName, "label_type_1","content", $fieldObjectTree);
                            }

                            //label (Beschreibung)
                            elseif ($myField->konstante_id=="44") {
                                //keine Addition zu $sumOfFeldinhalt, da labels nicht übertragen werden. Der Datensatz würde unnötig als geändert erkannt werden.
                                $feedback = $feedback._getFieldLabel($myField, $nameAttr, $myField->idAttr, $showName, "label_type_2","helptext", $fieldObjectTree);
                            }

                            //label_2 (Bezeichnung label_type_2)
                            elseif ($myField->konstante_id=="1444") {
                                //keine Addition zu $sumOfFeldinhalt, da labels nicht übertragen werden. Der Datensatz würde unnötig als geändert erkannt werden.
                                $feedback = $feedback._getFieldLabel($myField, $nameAttr, $myField->idAttr, $showName, "label_type_2","content", $fieldObjectTree);
                            }
                            
                            //label_date (Datum in Format gemäß config_param date_format darstellen)
                            elseif ($myField->konstante_id=="2563") {
                                //keine Addition zu $sumOfFeldinhalt, da labels nicht übertragen werden. Der Datensatz würde unnötig als geändert erkannt werden.
                                $feedback = $feedback._getFieldLabel($myField, $nameAttr, $myField->idAttr, $showName, "label_type_date","date", $fieldObjectTree);
                            }
                            
                            //label_hidden (Bezeichnung label_type_hidden)
                            elseif ($myField->konstante_id=="2560") {
                                //keine Addition zu $sumOfFeldinhalt, da labels nicht übertragen werden. Der Datensatz würde unnötig als geändert erkannt werden.
                                $feedback = $feedback._getFieldLabel($myField, $nameAttr, $myField->idAttr, $showName, "label_type_hidden","content", $fieldObjectTree);
                            }

                            //radio-Button
                            elseif ($myField->konstante_id=="5") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldRadioButton($myField, $nameAttr, $myField->idAttr, $fieldObjectTree, $showName);
                            }

                            //nummeric	
                            elseif ($myField->konstante_id=="7") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldNumeric($myField, $nameAttr, $myField->idAttr, $showName, $instance_form_mode);
                            }

                            //hidden, verstecktes Feld
                            elseif ($myField->konstante_id=="8") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldHidden($myField, $nameAttr, $myField->idAttr, $showName);
                            }

                            //Button
                            elseif ($myField->konstante_id=="9") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $feedback = $feedback._getFieldSubmitbutton($myField, $nameAttr, $myField->idAttr, $myField->button_target_mask_link, $mask_app, true, $form_id, $showName, $in_pagedata, $in_instanceID, $in_caller, false, $form["form.constructor"]);
                                
                                //Wenn Button mit Funktion  loadDetailedData verknüpft ist, dann Button-ID merken. Sollte nur genau ein Datensatz im Filtermodus gefunden worden sein, kann der Details-Button per Javascript sofort geklickt werden.
                                if($myField->button_action_function_id == 9 AND $form["form.instances"][$in_instanceID]["form.countData"]==1) {
                                    //den Wert nur dann setzen, wenn der Maskenaufruf nicht bereits durch auto-click erfolgte 
                                    //und auch nur dann, wenn zuvor die Suchfunktion verwendet wurde
                                    //und sich diese auf das aktuelle Formular bezieht
                                    if($in_pagedata->internGetObject->isButtonAutoclickedTrue() != 1 AND $in_pagedata->getFunctionProp("functionname") === "internFunction_setConditionForFilter" AND $in_pagedata->getFunctionProp("target_form_id") == $form_id) {
                                        session_class::$session_object->setSessionMessageToField("click_button", $myField->idAttr);
                                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> hidden_click_button_for_detaildata: ', $myField->idAttr);
                                    } else {
                                        session_class::$session_object->clearSessionMessageFieldClickbutton();
                                    }
                                }   
                            }

                            //E-Mail-Feld (wie text, aber anderer Typ)
                            elseif ($myField->konstante_id=="15") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "email", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }
                            
                            //Dropdown-Liste mit chosen in Abhängigkeit von einer beliebigen Referenztabelle
                            elseif ($myField->konstante_id=="16") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldReferenceToTable($myField, $nameAttr, $myField->idAttr, $fieldObjectTree, $showName, false, $form, $in_pagedata, $in_caller, $instance_form_mode);
                            }
                            
                            //Dropdown-Liste ohne chosen in Abhängigkeit von einer beliebigen Referenztabelle
                            elseif ($myField->konstante_id=="18") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldReferenceToTable($myField, $nameAttr, $myField->idAttr, $fieldObjectTree, $showName, true, $form, $in_pagedata, $in_caller, $instance_form_mode);
                            }

                            //Dropdown-Liste mit chosen in Abhängigkeit von einer beliebigen Query
                            elseif ($myField->konstante_id=="17") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldReferenceToQuery($myField, $nameAttr, $myField->idAttr, $fieldObjectTree, $form, $showName, false, $in_pagedata, $in_caller, $instance_form_mode);
                            }
                            
                            //Dropdown-Liste ohne chosen in Abhängigkeit von einer beliebigen Query
                            elseif ($myField->konstante_id=="19") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldReferenceToQuery($myField, $nameAttr, $myField->idAttr, $fieldObjectTree, $form, $showName, true, $in_pagedata, $in_caller, $instance_form_mode);
                            }

                            //Zeilenumbruch setzen (Datensatz wird unterbrochn, da bei Verwendung von display:inline-flex; andernfalls kein Zeilenumbruch möglich wäre.)
                            elseif ($myField->konstante_id=="20") {
                                $feedback = $feedback._getDatensatzEndsequenz(). "<div class=\"zeilenumbruch\"></div>\r\n". _getDatensatzStartsequenz($in_with_table, $addDsID, true, false, $in_add_constructor_class, $form_id, $in_instanceID, $addDsID);
                            }
                            
                            //Dropdown-Liste mit chosen in Abhängigkeit von einer beliebigen Referenztabelle
                            elseif ($myField->konstante_id=="21") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldReferenceToTable($myField, $nameAttr, $myField->idAttr, $fieldObjectTree, $showName, false, $form, $in_pagedata, $in_caller, $instance_form_mode);
                            }                            

                            //Checkbox mit Steuerfeld allMarkieren (wie text, aber anderer Typ)
                            elseif ($myField->konstante_id=="48") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;  
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "checkbox", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }
                            
                            
                            //Checkbox ohne Steuerfeld alleMarkieren(wie text, aber anderer Typ)
                            elseif ($myField->konstante_id=="49") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;  
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "checkbox", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }

                            //Abmelden-Button
                            elseif ($myField->konstante_id=="56") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $feedback = $feedback._getFieldLogoutbutton($myField, $nameAttr, $myField->idAttr, $myField->button_target_mask_link_org, $mask_app, $in_pagedata, $form_id, $in_instanceID);
                            }

                            //Anmelden-Button
                            elseif ($myField->konstante_id=="69") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $feedback = $feedback._getFieldLoginbutton($myField, $nameAttr, $myField->idAttr, $myField->button_target_mask_link, $mask_app, $in_pagedata, $form_id, $in_instanceID);
                            }

                            //Passwort-Feld mit ver-hash-ter Datenablage (wie text, aber anderer Typ); Verschlüsselung (hash) erfolgt in extractDataFromPostarray
                            elseif ($myField->konstante_id=="70") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "password", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }
                            
                            //Passwort(String)-Feld mit verschlüsselter Datenablage (wie text, aber anderer Typ); Verschlüsselung (hash) erfolgt in extractDataFromPostarray
                            elseif ($myField->konstante_id=="2628") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "password", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }

                            //Passwort-Feld (wie text, aber anderer Typ)
                            elseif ($myField->konstante_id=="71") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "password", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }

                            //Button ohne Validation
                            elseif ($myField->konstante_id=="73") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $feedback = $feedback._getFieldSubmitbutton($myField, $nameAttr, $myField->idAttr, $myField->button_target_mask_link, $mask_app, false, $form_id, $showName, $in_pagedata, $in_instanceID, $in_caller, true, $form["form.constructor"]);
                            }
                            
                            //Button ohne Validation und ohne Warnung vor Datenverlust
                            elseif ($myField->konstante_id=="2538") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $feedback = $feedback._getFieldSubmitbutton($myField, $nameAttr, $myField->idAttr, $myField->button_target_mask_link, $mask_app, false, $form_id, $showName, $in_pagedata, $in_instanceID, $in_caller, false, $form["form.constructor"]);
                            }
                          
                            //Datumsfeld-Feld (wie text, aber anderer Typ)
                            elseif ($myField->konstante_id=="111") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "date", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }
                            
                            //DateTime-Feld (wie text, aber anderer Typ)
                            elseif ($myField->konstante_id=="112") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "datetime-local", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }
                            
                            //E-Mail-Feld (wie text, aber anderer Typ; mailTo für Anträge (requests))
                            elseif ($myField->konstante_id=="636") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "email", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }

                            //E-Mail-Feld (wie text, aber anderer Typ; mailCC für Anträge (requests))
                            elseif ($myField->konstante_id=="637") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "email", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }

                            //E-Mail-Feld (wie text, aber anderer Typ; mailFrom für Anträge (requests))
                            elseif ($myField->konstante_id=="638") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "email", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }
                            
                            //Text-Feld (wie text, aber anderer Typ; mailSubject für Anträge (requests))
                            elseif ($myField->konstante_id=="639") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "text", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }
                            
                            //Bild(Img)-Feld
                            elseif ($myField->konstante_id=="373") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldImage($myField, $nameAttr, $myField->idAttr, $showName);
                            }

                            //Trennlinie in einer Tabelle setzen   
                            elseif ($myField->konstante_id=="517") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getSeparatorLine($myField, $myField->idAttr, $fieldObjectTree);
                            }  

                            //Text-Feld (inkl. WYSIWYG-Editor)
                            elseif ($myField->konstante_id=="694") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldWysiwyg($myField, $nameAttr, $myField->idAttr, $form["form.instances"][$in_instanceID]["form.form_mode"], $showName);
                            }

                            //Datei-Upload-Feld (wie text, aber anderer Typ)
                            elseif ($myField->konstante_id=="945") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldText($myField, $nameAttr, $myField->idAttr, "file", $showName, $instance_mode, $in_instanceID, $form["form.constructor"], $form_id);
                            }
                            
                            //range	
                            elseif ($myField->konstante_id=="1959") {
                                //ACHTUNG: Diese Zeile muss vor der nächsten folgen, da in manchen _getField-Funktionen der Feldinhalt verändert wird.
                                $sumOfFeldinhalt = $sumOfFeldinhalt.$myField->feldinhalt.$field_separator;
                                $feedback = $feedback._getFieldRange($myField, $nameAttr, $myField->idAttr, $showName, $fieldObjectTree);
                            }



                            //--Ende Felder---------------------------------------------------------------------------------------------------------------------

                            //Bei Bedarf Zeilenumbruch[klasse] beim nächsten Feld ergänzen
                            if($myField->inline == 0 AND $in_with_table != true) {
                                //Wenn ein Zeilenumbruch gesetzt werden soll und es sich nicht um eine Tabellenartige Struktur handelt, dann ...
                                $insert_linebreack = true;
                            } else {
                                $insert_linebreack = false;
                            }
                        }
                        
                    
		}
                

                //Button zur Ergänzung einer neuen Zeile ergänzen
                if($in_rowManageButtonAdd === true) {
                    $feedback = $feedback._getFieldButtonShowRow($myField->id, $nameAttr, $myField->idAttr, $form_id, 1, $in_pagedata,$in_instanceID, $addDsID, "show");
                }
                if($in_rowManageButtonHide === true) {
                    $feedback = $feedback._getFieldButtonShowRow($myField->id, $nameAttr, $myField->idAttr, $form_id, 1, $in_pagedata,$in_instanceID, $addDsID, "hide");
                }
                
                if ($addFieldWithHash==true) {                  		//hidden, verstecktes Feld mit dem Hashwert der Feldinhalte des Datensatzes
                        $hashFieldname = "Hash_".$addDsID."_".$addToName;
                        $feedback = $feedback._getFieldHiddenHashvalue($sumOfFeldinhalt, $hashFieldname, $showName);
                        $in_pagedata->setFormDatarowValuesForSecureFields($form_id, $in_instanceID, $addDsID, $hashFieldname, md5($sumOfFeldinhalt));
//                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> HashWert: ', md5($sumOfFeldinhalt).' gesamtString: '.$sumOfFeldinhalt);
                }
                
               
                //Datensatzendmarkierung
                $feedback = $feedback._getFieldHiddenDSMarker($addDsID, $addToName, "end", "", $showName);
                
                
                 
                
                return $feedback;
	}
	
        
        
        
        /** Die Funktion prüft, ob ein Feld, aufgrund einer Sonderregel unterdrückt werden soll.
         * Sonderregeln werden im Datenbankfeld feld.ausblenden_bei_insert hinterlegt.
         * 
         * @param object    $in_pagedata    globales PageData-Objekt
         * @param object    $in_field       Fieldobjekt
         * @param integer   $in_form_id     ID des Formulars
         * @param string    $in_instance_id ID der Instanz
         */
        function checkIfFieldShouldSupressed($in_pagedata, $in_field, $in_form_id, $in_instance_id) {
            
            $form_mode = $in_pagedata->getFormPropertyFormmode($in_form_id, $in_instance_id);
            
            
            if(strpos($in_field->ausblenden,(string)$form_mode) !== false ) {
                //Wenn form_mode in dem String $in_field->ausblenden enthalten ist, dann wird das Feld ausgeblendet. (siehe Konstantentyp-ID 211)
                $feedback = true;
            } else {
                $feedback = false;
            }
            
            return $feedback;
            
        }
        
       
        
        //Todo: Ist es möglich auch den Aufbau der nested-Forms schon in pagedata zu erledigen? -> nicht solange dort die Inhaltsdaten nicht bekannt sind.
        /** Ermittelt den HTML-Code für alle engebetteten Formulare. Falls einschränkende Felder (Bedingungen) für nestetForms existieren (siehe DB-tabelle form_nesting), werden diese beachtet.
         * @param   string      $in_form_App_id
         * @param   integer     $in_form_id         Form_id des Parent-Formulars
         * @param   array       $in_fieldList       Feldliste, wie sie getFieldList() erzeugt.
         * @param   object      $in_pagedata        Objekt vom Typ pagedata
         * @param   integer     $in_i_parent        aktive Datensatznummer im Parent-Formulars
         * @param   string      $in_add_constructor_class   Name einer css-Klasse die zu allen Dom-Elementen ergänzt wird.
         * @param   string      $in_instance_id     ID der aktuellen Instanz
         * @return  string                          HTMLCode, der im Dom eingefügt werden kann.
         */
        function getHTMLCodeForNestedForms($in_form_App_id, $in_form_id, &$in_fieldList, &$in_pagedata, $in_i_parent, $in_add_constructor_class, $in_instance_id) {
            $HtmlCode = "";            
            
            
            //if($in_field->form_app_id<>"") {
                $nestedForms = getNestedForms($in_form_App_id, $in_form_id);                                                                //Liste der eingebetteten Formulare erstellen
                
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> nestedForms: ', $nestedForms);
                if($nestedForms <> false) {
                    $instance_form_mode = $in_pagedata->getFormPropertyFormmode($in_form_id, $in_instance_id);
                
                    $HtmlCode = $HtmlCode._getDatensatzEndsequenz(). "<div class=\"zeilenumbruch\"></div>\r\n";    //Row des Parent-Forms beenden, da sonst per CSS kein Zeilenumbruch wirkt, da die Zeile des Parentform mit inline-flex ausgerichtet wird.
                    $HtmlCode = $HtmlCode._getDatensatzStartsequenz(true, $in_i_parent, true, false, $in_add_constructor_class, $in_form_id, "i0", $in_i_parent);
                    foreach ($nestedForms as $key => $value) {                                      
                        $currentNestedForm=$value;                                                                                                  
                        $fieldReferences = getNestedFormFields($in_form_App_id, $in_form_id, $currentNestedForm["form_nesting.id"]);        //Feldreferenzen zwischen Parent- und Chiledform ermitteln
                        $fieldObjectTree = new HTMLFieldList($in_fieldList, false, false, $in_pagedata, $instance_form_mode);                                                  //fieldlist in Objektbaum wandeln
                        
                        //Eigenschaften für das eingebettete Formular direkt in pagedata ändern
                        $tempformcondition = getConditionForNestedForms($fieldObjectTree, $fieldReferences);                                //temporäre Condition mit Refernezfeldern bauen
                        $tempSqlCondition = $tempformcondition["SQL"];
                        $tempArrayDefaultvalue = $tempformcondition["Array"];
                        
                        $is_nested_form = $in_pagedata->getFormPropertyIsnested($currentNestedForm["form_nesting.child_form_id"]);
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Instanzcondition: ', "Parent-form: ".$in_form_id."| Child-Form: ".$currentNestedForm["form_nesting.child_form_id"]." | Condition: ".$tempSqlCondition);
                        
                        $tagArrayFromNestedForm = getTagArray($currentNestedForm["form_nesting.child_form_app_id"], $currentNestedForm["form_nesting.child_form_id"]);  //aus dem Tag ergibt sich implizit auch, welches Formular aktuell eingefügt werden soll
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> tagArrayFromNestedForm: ', $tagArrayFromNestedForm);
                        $myHtmlTag = new HtmlTag($tagArrayFromNestedForm[0], $in_pagedata, "", "", $tempSqlCondition, $is_nested_form, $tempArrayDefaultvalue);
                        //$HtmlCode = $HtmlCode._getDatensatzStartsequenz(false, $in_i_parent, true, false);
                        $HtmlCode = $HtmlCode."<div id=\"".$currentNestedForm["form_nesting.child_form_id"]."\" role=\"none\"> <!-- Start nestedForm --> \r\n";
                        $HtmlCode = $HtmlCode.$myHtmlTag->printHtmlCode();
                        $HtmlCode = $HtmlCode."</div> <!-- End: nestedForm ".$currentNestedForm["form_nesting.child_form_id"]." --> \r\n";
                        //$HtmlCode = $HtmlCode._getDatensatzEndsequenz(false). "<div class=\"zeilenumbruch\"></div>\r\n". _getDatensatzStartsequenz(false, "sub", true, false);    //Abschließender Zeilenumbruch am ende eines jeden Formulars
                        
                    }
                    
                    $HtmlCode = $HtmlCode._getDatensatzEndsequenz(). "<div class=\"zeilenumbruch\"></div>\r\n";
                    $HtmlCode = $HtmlCode."<div> <!-- Dummy-Div, um Start für schließendes div von Parentrow zu bieten --> \r\n";
                }
            //}                        
            return $HtmlCode;            
        }
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "Auswahlbox mit Referenz zu einer beliebigen Tabelle" den HTML-Code.
         * 
         * TODO: Könnte doch jetzt eigentlich in die Klasse HtmlField integriert werden?!?
         * @param   object  $in_field       Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr    Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr      Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   object  $in_fieldlist   Objekt vom Typ HtmlFieldlist, welche alle Felder des aktuellen Formulars enthält
         * @param   integer $in_showName    Formulardaten, des Formulars, in dem das Feld eingebunden wird. Wenn es sich um ein Feld einer Symbolleiste handelt, wird das form_array der Parentform erwartet.
         * @param   boolean $in_no_chosen   Gibt an, ob die chosen-Klasse ergänzt werden soll. Wenn true, wird die Select-box nicht mit chosen verbessert. 
         * @param   array   $in_form        Referenz zum Form-Array
         * @param   object  $in_pagedata    Referenz zum pagedata-object
         * @param   string  $in_constructor_function Name des Funktion, die der Constructor aufrief; Der Constructor selbst konnte nicht genutzt wird, da dann Symbolleisten nicht erkannt werden könnten. Diese geben nämlich den Constructor des umschließenden Formulars weiter.
         * @param   integer $instance_form_mode     Modus der aktuellen Instanz
         * @return  string                  HTML-Code eines Formularfeldes
         */
        function _getFieldReferenceToTable($in_field, $in_nameAttr, $in_idAttr, &$in_fieldlist, $in_showName, $in_no_chosen, &$in_form, &$in_pagedata, $in_constructor_function, $instance_form_mode) {
            $content = "";
            $height = "";
            
            //readonly -> Select-Felder können die readonly-Eigenschaft nicht interpretieren, stattdessen muss disabled genutzt werden
            if ($in_field->readonlyCode == "readonly=\"readonly\"") {
                $disabledAttribut = "disabled=\"disabled\"";
                $showOnlySelected = true;
                //$disabledAttribut = "visibility=\"hidden\"";      //Das funktioniert bei SELECT-Feldern nicht!
                $chosen_class = "";
                
                //zusätzlich wird das Feld als verstecktes Textfeld angelegt, damit es im POST-Objekt als Platzhalter an der richtigen Stelle enthalten ist 
                //Der Feldinhalt wird jedoch nach dem POST ignoriert und stattdessen aus einem Backup aus der Session übernommen. Somit soll Manipulation am Client ausgeschlossen werden.
                $hidden_content = _getFieldHidden($in_field, $in_nameAttr, $in_idAttr, $in_showName, true); 
            } else {
                $disabledAttribut = "";
                $showOnlySelected = false;
                $hidden_content = "";
                $chosen_class = "chosen";
            }
            
            if($in_no_chosen == true) {
                $chosen_class = "";
            }
            
            //Wenn eine Referenz auf eine Konstantenliste hinterlegt ist, dann werden die Referenzen zu einer beliebigen Tabelle überlagert.
            if($in_field->ref_const_app_id != "" AND $in_field->ref_const_id != "") {
                $in_field->ref_schema = global_variables::getNameOfDbSchemaSYS01();
                $in_field->ref_table = "konstante";
                $in_field->ref_id_field = "wert";
                $in_field->ref_show_field = "klartext";
                $in_field->ref_order_by_field = "sort";
                $in_field->ref_condition = "konstantentyp_app_id = '".$in_field->ref_const_app_id."' AND konstantentyp_id = ".$in_field->ref_const_id." AND gueltig_ab <= current_date AND gueltig_bis >= current_date";
            }
            
            $condition = getDependsconditionForField($in_field, $in_fieldlist, "SQL");
            if($in_field->ref_condition != "" AND $condition != "") {$condition = $in_field->ref_condition." AND ".$condition;}
            elseif ($in_field->ref_condition != "" AND $condition == "") {$condition = $in_field->ref_condition;}
            elseif ($in_field->ref_condition == "" AND $condition != "") {$condition = $condition;}
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> condition: ', $condition);
            
            //$connection_id vom Referenzfeld ermitteln
            $connection_id = getAppIdFromSchema($in_field->ref_schema, $in_form["form.app_id"]);
            $constlist = getReferenceListFromTable($connection_id, $in_field->ref_schema, $in_field->ref_table, $in_field->ref_id_field, $in_field->ref_show_field, $in_field->ref_order_by_field, $condition);
            if(count($constlist)>0) {
                
                //Prüfen, ob die const_list (optionlist) in der Session abgelegt werden soll
                if($in_form["form.save_optionlist_tmp"] == true) {
                    $in_pagedata->addOptionlistToFormarray($in_form["form.id"], $in_field->id, $constlist);
                }
            }
              
            
            
            if($in_showName<>2) {
                //showname = 2 -> nur der Name des Feldes soll angedruckt werden (Überschriftenzeile)
                $found_value = false;
                $content = "<select class=\"".$in_field->class_content.$in_field->addClassCode." ".$chosen_class."\" name=\"$in_nameAttr\" style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\" title=\"$in_field->name (Feld-ID=$in_field->id, Referenz-Table=$in_field->ref_table, Referenz-Bedingung=$in_field->ref_condition)\" id=\"$in_idAttr\" onclick=\"$in_field->javascriptOnclick\" oninput=\"$in_field->javascriptOninput\" onchange=\"$in_field->javascriptOnchange\" data-feldid=\"$in_field->id\" data-formid=\"$in_field->form_id\" data-feldappid=\"$in_field->app_id\" $in_field->requiredCode $disabledAttribut>\r\n";
                                $content = $content.global_variables::getOptionChoosesomethinForSelect();
                                for($x = 0; $x < count($constlist); $x++) {
                                    If ($in_field->feldinhalt === $constlist[$x] [$in_field->ref_table.".ref_id"]) {
                                        //mit Feldwertvorbelegung
                                        $content = $content. "<option value=\"".$constlist[$x][$in_field->ref_table.".ref_id"]."\" selected=\"selected\">".$constlist[$x][$in_field->ref_table.".ref_value"]."</option>\r\n"; 
                                        $found_value = true;
                                    } elseif($showOnlySelected === false) {
                                        //ohne Feldvorbelegung
                                        $content = $content. "<option value=\"".$constlist[$x][$in_field->ref_table.".ref_id"]."\">".$constlist[$x][$in_field->ref_table.".ref_value"]."</option>\r\n";                
                                    }
                                }
                                if($found_value === false and $in_field->feldinhalt != "") {
                                    //Wenn der Field->feldinahlt nicht in der Konstantenliste vorhanden ist und auch nicht leer ist, dann wird die Konstantenliste um diesen ergänzt.
                                    //Andernfalls würde der Feldinhalt nach dem Speichern der Maske gelöscht werden.
                                    $content = $content. "<option value=\"".$in_field->feldinhalt."\" selected=\"selected\">".$in_field->feldinhalt."</option>\r\n";  
                                        
                                } 
                            $content = $content."</select>\r\n";
            }
            
            $form_mode = 
            $localFeedback = getCellContent($in_field, $in_showName, $height, $in_idAttr, $content, $hidden_content, "", $in_constructor_function, false, $instance_form_mode);
            
            return $localFeedback;
        }




        /** Erzeugt für ein Feldobjekt vom Typ "Radio-Button for List" den HTML-Code.
         * 
         * @param   object  $in_field       Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr    Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr      Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   object  $in_fieldlist   Objekt vom Typ HtmlFieldlist, welche alle Felder des aktuellen Formulars enthält
         * @param   integer $in_showName    Formulardaten, des Formulars, in dem das Feld eingebunden wird. Wenn es sich um ein Feld einer Symbolleiste handelt, wird das form_array der Parentform erwartet.
         * @return  string                  HTML-Code eines Formularfeldes
         */
        function _getFieldRadioButton($in_field, $in_nameAttr, $in_idAttr, &$in_fieldlist, $in_showName) {
            $content = "";
            $height = "";
            
            //readonly -> Select-Felder können die readonly-Eigenschaft nicht interpretieren, stattdessen muss disabled genutzt werden
            if ($in_field->readonlyCode == "readonly=\"readonly\"") {
                $disabledAttribut = "disabled=\"disabled\"";
                //$disabledAttribut = "visibility=\"hidden\"";      //Das funktioniert bei SELECT-Feldern nicht!
                
                //zusätzlich wird das Feld als verstecktes Textfeld angelegt, damit es im POST-Objekt als Platzhalter an der richtigen Stelle enthalten ist 
                //Der Feldinhalt wird jeoch nach dem POST ignoriert und stattdessen aus einem Backup aus der Session übernommen. Somit soll Manipulation am Client ausgeschlossen werden.
                $hidden_content = _getFieldHidden($in_field, $in_nameAttr, $in_idAttr, $in_showName); 
            } else {
                $disabledAttribut = "";
                $hidden_content = "";
            }
            
            $condition = getDependsconditionForField($in_field, $in_fieldlist, "SQL");
            if($in_field->ref_condition != "" AND $condition != "") {$condition = $in_field->ref_condition." AND ".$condition;}
            elseif ($in_field->ref_condition != "" AND $condition == "") {$condition = $in_field->ref_condition;}
            elseif ($in_field->ref_condition == "" AND $condition != "") {$condition = $condition;}
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> condition: ', $condition);
            
            //$connection_id vom Referenzfeld ermitteln
            $connection_id = getAppIdFromSchema($in_field->ref_schema); //ggf. bei diesem Methodenaufruf noch versuchen den zweiten Parameter zu ergänzen, falls die APP-ID nicht korrekt ermittelt wird.
            $constlist = getReferenceListFromTable($connection_id, $in_field->ref_schema, $in_field->ref_table, $in_field->ref_id_field, $in_field->ref_show_field, $in_field->ref_order_by_field, $condition);
              
            
            
            if($in_showName<>2) {
                //showname = 2 -> nur der Name des Feldes soll angedruckt werden (Überschriftenzeile)
                $found_value = false;
                $content = "<section class=\"".$in_field->class_content.$in_field->addClassCode." radio\" name=\"$in_nameAttr\" style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\" title=\"$in_field->name (Feld-ID=$in_field->id, Referenz-Table=$in_field->ref_table, Referenz-Bedingung=$in_field->ref_condition)\" id=\"$in_idAttr\" onclick=\"$in_field->javascriptOnclick\" onchange=\"$in_field->javascriptOnchange\" data-feldid=\"$in_field->id\" data-formid=\"$in_field->form_id\" data-feldappid=\"$in_field->app_id\" $in_field->requiredCode $disabledAttribut>\r\n";
                                for($x = 0; $x < count($constlist); $x++) {
                                    If ($in_field->feldinhalt === $constlist[$x] [$in_field->ref_table.".ref_id"]) {
                                        //mit Feldwertvorbelegung
                                        $content = $content. "<input type=\"radio\" value=\"".$constlist[$x][$in_field->ref_table.".ref_id"]."\" checked=\"checked\" id=\"".$constlist[$x][$in_field->ref_table.".ref_id"]."\" name=\"".$in_nameAttr."\" $in_field->requiredCode>\r\n";
                                        $content = $content. "<label for=\"".$constlist[$x][$in_field->ref_table.".ref_id"]."\">".$constlist[$x][$in_field->ref_table.".ref_value"]."</label><br>\r\n";
                                        $found_value = true;
                                    } 
                                    else {
                                        //ohne Feldvorbelegung
                                        $content = $content. "<input type=\"radio\" value=\"".$constlist[$x][$in_field->ref_table.".ref_id"]."\" id=\"".$constlist[$x][$in_field->ref_table.".ref_id"]."\" name=\"".$in_nameAttr."\" $in_field->requiredCode>\r\n";
                                        $content = $content. "<label for=\"".$constlist[$x][$in_field->ref_table.".ref_id"]."\">".$constlist[$x][$in_field->ref_table.".ref_value"]."</label><br>\r\n";
                                    }
                                }
                                
                            $content = $content."</section>\r\n";
            }
            
            
            $localFeedback = getCellContent($in_field, $in_showName, $height, $in_idAttr, $content, $hidden_content, "");
            
            return $localFeedback;
        }        
        
        
        
        /** Ermittelt die Connection-ID für eine Query, die mit dem aktuellen Feld ($in_Field) verknüpft ist,
         * über ein Referenzfeld. Wenn kein Referenzfeld angegeben ist, wird ein Leerstring zurückgegeben.
         * 
         * @param   object  $in_Field       Obkjekt des aktuellen Feldes
         * @param   array   $in_fieldlist   Liste aller Felder mit deren Eigenschaften, gemäß Tabelle "feld"
         * @return  string                  Connection-ID (bspw.: SYS01 oder "")
         */
        function _getConnectionID($in_Field, $in_fieldlist) {
            //Prüfen, ob für die Query ein Verweis auf ein anderes Feld des selben Formulars hinterlegt wurde, in dem die Connection-ID enthalten ist.
            $ref_connection_id = $in_Field->getProperty("query_ref_field_connection_id");
            if($ref_connection_id !== false AND $ref_connection_id <> "") {
                $my_connection_id = getValueFromFieldInFieldobjectlist($in_fieldlist, $ref_connection_id);
            } else {
//                $my_connection_id = $in_Field->query_app_id;
                $my_connection_id = "";
            }
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> connection_id: ', "connection_id: ".$my_connection_id);
            return $my_connection_id;
        }    
        
        
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "Auswahlbox mit Referenz zu einer beliebigen Query" den HTML-Code.
         * 
         * TODO: Könnte doch jetzt eigentlich in die Klasse HtmlField integriert werden?!?
         * @param   object  $in_field       Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr    Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr      Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   object  $in_fieldlist   Objekt vom Typ HtmlFieldlist, welche alle Felder des aktuellen Formulars enthält
         * @param   array   $in_form        Formulardaten, des Formulars, in dem das Feld eingebunden wird. Wenn es sich um ein Feld einer Symbolleiste handelt, wird das form_array der Parentform erwartet.
         * @param   integer $in_showName
         * @param   boolean $in_no_chosen   Gibt an, ob die chosen-Klasse ergänzt werden soll. Wenn true, wird die Select-box nicht mit chosen verbessert. 
         * @param   object  $in_pagedata    Refernz zum zentralen Pagedata-Objekt
         * @param   string  $in_constructor_function Name des Funktion, die der Constructor aufrief; Der Constructor selbst konnte nicht genutzt wird, da dann Symbolleisten nicht erkannt werden könnten. Diese geben nämlich den Constructor des umschließenden Formulars weiter.
         * @param   integer $instance_form_mode     Modus der aktuellen Instanz
         * @return  string                  HTML-Code eines Formularfeldes
         */
        function _getFieldReferenceToQuery($in_field, $in_nameAttr, $in_idAttr, &$in_fieldlist, $in_form, $in_showName, $in_no_chosen, &$in_pagedata, $in_constructor_function, $instance_form_mode) {
            $content = "";
            $height = "";
            
            
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> _getFieldReferenceToQuery: ', $in_nameAttr);
           
              
            //readonly -> Select-Felder können die readonly-Eigenschaft nicht interpretieren, stattdessen muss disabled genutzt werden
            if ($in_field->readonlyCode == "readonly=\"readonly\"") {
                $disabledAttribut = "disabled=\"disabled\"";
                $showOnlySelected = true;
                //$disabledAttribut = "visibility=\"hidden\"";      //Das funktioniert bei SELECT-Feldern nicht!
                $chosen_class = "";
                
                //zusätzlich wird das Feld als verstecktes Textfeld angelegt, damit es im POST-Objekt enthalten ist 
                //Der Feldinhalt wird jedoch nach dem POST ignoriert und stattdessen aus einem Backup aus der Session übernommen. Somit soll Manipulation am Client ausgeschlossen werden.
                $hidden_content = _getFieldHidden($in_field, $in_nameAttr, $in_idAttr, $in_showName, true); 
            } else {
                $showOnlySelected = false;
                $disabledAttribut = "";
                $hidden_content = "";
                $chosen_class = "chosen";
            }
            
            if($in_no_chosen == true) {
                $chosen_class = "";
            }
            
            
            //Connection_id der Query ermitteln
            $my_connection_id = _getConnectionID($in_field, $in_fieldlist);
            
            $triggerFieldsCondition = getDependsconditionForField($in_field, $in_fieldlist, "ARRAY");
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Conditions by triggerFields: ', $triggerFieldsCondition);
            $variablesContainerForQuery = array();
            $variablesContainerForQuery[] = array("type" => "FormArray", "data" => $in_form);                               //für den Fall, dass über query_add_condition auf form-Variablen verwiesen wird.
            $variablesContainerForQuery[] = array("type" => "triggerFieldsCondition", "data" => $triggerFieldsCondition);   //für den Fall, dass die Werteliste des aktuellen Feldes von den Eingaben in einem vorherigen Feld abhängig sind.
            $variablesContainerForQuery[] = array("type" => "SessionData", "data" => session_class::$session_object->getSessionArrayCurTabAndGlobals());                            //für den Fall, dass über query_add_condition auf SESSION-Variablen verwiesen wird.
            $myQuery = new query();
            $myQuery->initialize_1($in_field->query_app_id, $in_field->query_id, false, $variablesContainerForQuery, $in_form, $my_connection_id);
            $constlist = $myQuery->getQueryResultAsArray();
            if(count($constlist)>0) {
                //In der constList die Spalten suchen, deren Werte für id und value im select-Feld genutzt werden sollen.
                $keyColumnID = issetKeyLike($constlist[0], ".ref_id");
                $keyColumnValue = issetKeyLike($constlist[0], ".ref_value");
                
                //Prüfen, ob die const_list (optionlist) in der Session abgelegt werden soll
                if($in_form["form.save_optionlist_tmp"] == true) {
                    $in_pagedata->addOptionlistToFormarray($in_form["form.id"], $in_field->id, $constlist);
                }
            }
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> query-Ergebnis für Referenzliste: ', $constlist);
                
            
            
            if($in_showName<>2) {
                //showname = 2 -> nur der Name des Feldes soll angedruckt werden (Überschriftenzeile)
                $found_value = false;
                $content = "<select class=\"".$in_field->class_content.$in_field->addClassCode." ".$chosen_class."\" name=\"$in_nameAttr\" title=\"$in_field->name (Feld-ID=$in_field->id, Referenz-Query=$in_field->query_id ($in_field->query_app_id))\" id=\"$in_idAttr\" style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\" onclick=\"$in_field->javascriptOnclick\" oninput=\"$in_field->javascriptOninput\" onchange=\"$in_field->javascriptOnchange\" data-formid=\"$in_field->form_id\" data-feldid=\"$in_field->id\" data-feldappid=\"$in_field->app_id\" $in_field->requiredCode $disabledAttribut>\r\n";
                                $content = $content.global_variables::getOptionChoosesomethinForSelect();                                                        //Der erste Eintrag ist ein leerer Eintrag. Jedoch nur dann, wenn es kein Pflichtfeld ist.
                                for($x = 0; $x < count($constlist); $x++) {
                                    If ($in_field->feldinhalt === $constlist[$x][$keyColumnID]) {
                                        //mit Feldwertvorbelegung
                                        //$content = $content. "<option value=\"".$constlist[$x][$keyColumnID]."\" selected=\"selected\">". str_replace("'", "", $constlist[$x][$keyColumnValue])."</option>\r\n";  
                                        $content = $content. "<option value=\"".$constlist[$x][$keyColumnID]."\" selected=\"selected\">".$constlist[$x][$keyColumnValue]."</option>\r\n";  
                                        $found_value = true;
                                    } elseif($showOnlySelected === false) {
                                        //ohne Feldvorbelegung
                                        //$content = $content. "<option value=\"".$constlist[$x][$keyColumnID]."\">".str_replace("'", "", $constlist[$x][$keyColumnValue])."</option>\r\n";                
                                        $content = $content. "<option value=\"".$constlist[$x][$keyColumnID]."\">".$constlist[$x][$keyColumnValue]."</option>\r\n";                
                                    }
                                }
                                if($found_value === false and $in_field->feldinhalt != "") {
                                    //Wenn der Field->feldinhalt nicht in der Konstantenliste vorhanden ist und aber dennoch nicht leer ist, dann wird die Konstantenliste um diesen ergänzt.
                                    //Andernfalls würde der Feldinhalt nach dem Speichern der Maske gelöscht werden.
                                    $content = $content. "<option value=\"".$in_field->feldinhalt."\" selected=\"selected\">".$in_field->feldinhalt."</option>\r\n";  
                                        
                                } 
                                $content = $content.
                            "</select>\r\n";
            }
                                            

            
            $localFeedback = getCellContent($in_field, $in_showName, $height, $in_idAttr, $content, $hidden_content, "", $in_constructor_function, false, $instance_form_mode);
            
                                            
            return $localFeedback;
        } 
        
        
        
        /** Bildet für ein Select-Feld (HTML), welches auf Basis einer Query die Optionen bietet, die OptionList neu. Dabei werden aktuelle Eingaben in einem Triggerfeld
         * sowie mögliche Parameter aus der DB-Tabelle query_add_condtion vom Typ form... beachtet.
         * 
         * @param   array   $in_dependingField      abhängiges Feld. Es werden mindestens die Attribute "field_depends.feld_app_id" und "field_depends.feld_id" erwartet.
         * @param   array   $in_TriggerField        auslösendes Feld. Eine Dateneingabe in diesem Feld hat die Veränderung der OptionList im DependingField zur Folge. Es werden mindestens die Attribute "data-formid", "fieldAppID", "data-fieldID" und "data-fieldValue" erwaltet. 
         * @return  boolean|string                  false, wenn form_id in Tab-SESSION[forms_backup] nicht existiert; string-> HTML-Code für Optionlist für ein HTML-SELECT-Feld
         */
        function getOptionListForReferenzToQuery($in_dependingField, $in_TriggerField) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> starte mit triggerField: ', $in_TriggerField);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> starte mit dependingField: ', $in_dependingField);
            $formID = $in_TriggerField["formID"];
            $formArray = session_class::$session_object->getFormbackup($formID);
            
            if($formArray == false) {
                
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Für dieses Formular ist kein Backup in SESSION vorhanden: ', "Form_ID = ".$formID, "ERROR");
                return false;
            }
           
            
            //Query ausführen, um die Constlist zu bilden
            $constlist = queryHelper($formArray, $in_dependingField, $in_TriggerField);
            if(count($constlist)>0) {
                //In der constList die Spalten suchen, deren Werte für id und value im select-Feld genutzt werden sollen.
                $keyColumnID = issetKeyLike($constlist[0], ".ref_id");
                $keyColumnValue = issetKeyLike($constlist[0], ".ref_value");
            } 
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> query-Ergebnis für Refernzliste: ', $constlist);
            
            
            //Feedback (HTML-Code für Optionen eines SELECT-Feldes) aufbauen
            $localFeedback = "";
            $localFeedback = $localFeedback.global_variables::getOptionChoosesomethinForSelect(); //Der erste Eintrag ist ein leerer Eintrag.
                                       
            for($x = 0; $x < count($constlist); $x++) {
                $localFeedback = $localFeedback. "<option value=\"".$constlist[$x][$keyColumnID]."\">".$constlist[$x][$keyColumnValue]."</option>\r\n";                //ohne Feldvorbelegung
            }		
            
            
            return $localFeedback;
        }
        
        
        
        
        /** Führt die Query zur Ermittlung von Optionlists aus. Wenn die gegebene Connection-ID zu einer leeren Ergebnismenge führt,
         * wird die gleiche Query mit der Connection-ID des Kernsystems ausgeführt.
         * 
         * @param array     $in_formArray          
         * @param array     $in_dependingField
         * @param array     $in_TriggerField
         * @return array
         */
        function queryHelper($in_formArray, $in_dependingField, $in_TriggerField) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> starte mit formArray: ', $in_formArray);
            $formID = $in_formArray["form.id"];
            
            
             //Condition für dependigField ermitteln
            $triggerFieldsCondition = getDependsconditionDynamicForField($formID, $in_dependingField["field_depends.feld_app_id"], $in_dependingField["field_depends.feld_id"],  $in_TriggerField["rowFieldList"]);
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> triggerFieldsCondition: ', $triggerFieldsCondition);
            
            //für dependingField die Query aus dem Session_Backup ermitteln
            $wholeDependigFieldArray = getFieldArrayFromSessionBackup($formID, $in_dependingField["field_depends.feld_app_id"], $in_dependingField["field_depends.feld_id"]);
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> wholeDependigFieldArray: ', $wholeDependigFieldArray);
          
            
            //Connection_id enthält
            $query_ref_field_connection_id = $wholeDependigFieldArray["feld.query_ref_field_connection_id"];
            if($query_ref_field_connection_id == "") {
                $myConnectionId = false;
                //In dem Fall wird die Standard-Connection-ID der query genutzt
            } else {
                //Feldinhalt aus $in_TriggerField["rowFieldList"] i.V.m. changeFieldlistAsStringToFieldListAsArray ermitteln
                $fieldsInRow = changeFieldlistAsStringToFieldListAsArray($in_TriggerField["rowFieldList"]);
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> fieldsInRow: ', $fieldsInRow);
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> query_ref_field_connection_id: ', $query_ref_field_connection_id);
                //Feldinhalt als connection_id mitgeben
                $myConnectionId = $fieldsInRow[$query_ref_field_connection_id]["fieldContent"];
            }
                  
            
            //Datensätze (constlist) für Optionlist ermitteln
            $variablesContainerForQuery = array();
            $variablesContainerForQuery[] = array("type" => "FormArray", "data" => $in_formArray);                               //für den Fall, dass über query_add_condition auf form-Variablen verwiesen wird.
            $variablesContainerForQuery[] = array("type" => "triggerFieldsCondition", "data" => $triggerFieldsCondition);   //für den Fall, dass die Werteliste des aktuellen Feldes von den Eingaben in einem vorherigen Feld abhängig sind.
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> variablesContainerForQuery: ', $variablesContainerForQuery);
            

            
            $myQuery = new query();
            $myQuery->initialize_1($wholeDependigFieldArray["feld.query_app_id"], $wholeDependigFieldArray["feld.query_id"], false, $variablesContainerForQuery, $in_formArray, $myConnectionId);
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Position: ', "Nach initialize_1 Query");
            $constlist = $myQuery->getQueryResultAsArray();
            
            
            if(count($constlist)>0) {
                //Daten konnten mit der gegebenen Connection-ID ermittelt werden.
            } else {
                //versuchen, ob es ein Ergenis gibt, wenn die Connection-ID des Kernmoduls verwendet wird. 
                //Das kann insbesondere dann sinnvoll sein, wenn eine APP Daten aus dem Kernmodul per Query abfragt.
                unset($myQuery);
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Query restart: ', "Mit der Connection-ID (".$in_ConnectionId.") konnten keine Ergebnisse ermittelt werden. Daher wird die Query erneut mit der Connection-ID des Kernsystems aufgerufen.");
            
                $myQuery = new query();
                $myConnectionId = global_variables::getConnectionIdOfDbSchemaSYS01();
                $myQuery->initialize_1($wholeDependigFieldArray["feld.query_app_id"], $wholeDependigFieldArray["feld.query_id"], false, $variablesContainerForQuery, $in_formArray, $myConnectionId);
                $constlist = $myQuery->getQueryResultAsArray();
            
                
            }
            
            return $constlist;
            
        }
        
        
        
        
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "Textfeld (ein- und mehrzeilig)" den HTML-Code.
         * 
         * 
         * @param   object  $in_field           Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr        Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr          Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   string  $in_type            text, date, file, checkbox, radio, wysiwyg, email oder password
         * @param   integer $in_showName        Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @param   integer $in_instance_mode   Modus, in dem diese Instanz des Formulars gezeichnet werden soll.
         * @param   string  $in_instance_id     ID der Instanz
         * @param   string  $in_constructor     Name des Constructors
         * @param   integer $in_form_id         ID des aktuellen Formulars
         * @return  string                      HTML-Code eines Formularfeldes
         */
        function _getFieldText($in_field, $in_nameAttr, $in_idAttr, $in_type, $in_showName, $in_instance_mode, $in_instance_id, $in_constructor, $in_form_id) {
            $localFeedback = "";
            $checked = "";
            $addDateClass = "";
            $content = ""; 
            $hidden_content = "";
            $height = "";
            $accept = "";
            $multiple = "";
            $maxlength = "";
            $onKeyUp = "";
            $addAttribut = "";
            $aria_label = "";
            
            
            if (strpos($in_field->autocomplete ?? '', $in_instance_mode) !== false) {
                if($in_field->autocomplete_start == "") {$autocomplete_start = 1;} else {$autocomplete_start = $in_field->autocomplete_start;}
                $onKeyUp = "onkeyup=\"suggest(event, this.value, $autocomplete_start)\" ";
            }
            
            if ($in_field->add_attribut !== "") {$addAttribut = $in_field->add_attribut." ";}
            
            if ($in_field->pos_header == 2) {
                // pos_header: [0 = links| 1 = oben| 2 = aus]
                $aria_label= "aria-label=\"".$in_field->name."\"";
            }
            
            if ($in_type=="date") {
                //-------------------------------------------------------------------------------------------------------
                //Solange type=date nicht von allen Browsern unterstützt wird, muss der folgende Block genutzt werden:
                //jQuery-datepicker wird nur noch in IE und Safari genutzt (19.11.2020)
                //Für den Fall, dass pro Datumsfeld das Format separat festgelegt werden muss, könnte an dieser Stelle das nachfolgende 
                //Skript pro Feld hinterlegt werden. Dabei kann individuell das Format festgelegt werden.
//                $localFeedback = "<script>jQuery( function() {jQuery( \"#$in_idAttr\" ).datepicker();} );</script>\r\n " ;
                $in_type="date";
                if($in_field->readonlyCode == "") {
                    //Wenn das Feld schreibgeschützt sein soll, dann darf die folgende Klasse nicht ergänzt werden, da der Datepicker die readonly-Eigenschaft ignoriert.
                    $addDateClass = " datepicker";
                }
                
                //Block Ende-------------------------------------------------------------------------------------------- 
            } elseif($in_type=="datetime-local") {
                $in_type="datetime-local";
            } elseif($in_type == "email") {
                $multiple = " multiple";
                $maxlength = "maxlength=\"$in_field->maxZeichen\"";
            } elseif($in_type == "checkbox" OR $in_type == "radio") {
                
                if($in_field->readonlyCode !== "") {
                    //Bei Checkboxen funktioniert die klassische readonly-Eigenschaft nicht, daher muss hier eingegriffen werden.
                    $in_field->readonlyCode ="disabled=\"disabled\"";
                    $hidden_value = $in_field->feldinhalt;
                } else {
                    //hidden_value muss bei nicht-geschützten Checkboxen auf 0 stehen, ansonsten werden abgewählte Checkbox-Informationen nicht übertragen.
                    $hidden_value = 0;
                }
                
                if($in_field->feldinhalt == 1 OR $in_field->feldinhalt == "t") {
                    //Wenn checkbox oder radio-Button verwendet wird, dann muss mit dem Attribut checked gearbeitet werden.
                    $checked = " checked=\"checked\" ";
                    $in_field->feldinhalt = 1;
                    if($in_field->readonlyCode !== "") {
                        //zusättliche class setzen, damit der style von geschützten Checkboxen, abhängig vom value, beeinflusst werden kann.
                        $addDateClass = " checked_readonly";
                    }
                }  else {
                    //feldinhalt muss immer 1 sein. Feldinhalt wird nur übermittelt, wenn checked = checked. Indem Fall muss die 1 vorhanden sein.
                    //Diese Eigenschaft darf jdoch erst manipuliert werden, wenn der feldinhalt für versteckte Felder nach hidden_value übergeben wurde
                    $in_field->feldinhalt = 1;                          
                }
            } elseif($in_type == "wysiwyg") {
                //Wenn ein Textfeld die Elemente eines WYSIWYG-Editors enthalten soll
                $in_type="text";
                $addDateClass = " wysiwyg";
                $maxlength = "maxlength=\"$in_field->maxZeichen\"";
                $onKeyUp = "";
            } elseif($in_type == "file") {
                $accept = " accept=\"".$in_field->vorgabewert."\"";
                if($in_instance_mode == 7) {$in_type = "text";}                 //in only_red-modus wird Wert aus Datenbank angezeigt.
            }
            
            
            //group_id: Felder der gleichen Spalte, erhalten die gleiche Group-ID
            $group_id = "form".$in_field->form_id."instance".$in_instance_id."field".$in_field->id;
            
            $form_and_instanz = "data-formandinstanz=\"form".$in_field->form_id."instance".$in_instance_id."\"";
            
            if($in_field->javascriptOnchange != "") {
                $js_onchange = "onblur=\"".$in_field->javascriptOnchange."\"";          //onblur funktioniert bei Type "input" besser als "onchange". Onchange wird in manchen Browsern schon vor verlassen des Feldes ausgelöst.
            } else {
                $js_onchange = "";
            }
            
            
            if ($in_field->zeilen == 1) {					//einzeiliges Text-Feld
                if($in_showName<>2) {
                    //showname = 2 -> nur der Name des Feldes soll angedruckt werden (Überschriftenzeile)
                    
                    
                    if($in_type == "checkbox" AND $in_field->feldinhalt == 1 AND in_array($in_instance_mode, array("3","8")) !== true ) {
                        //Bei checkboxen wird kein Wert im $_POST übertragen, wenn diese abgewählt werden. 
                        //Daher muss vorneweg ein verstecktes Feld mit gleichem Namen und value = 0 eingebaut werden.
                        //wird die zweite (sichtbare) Checkbox aktiviert, wird die 0 überschrieben, ansonsten wird der 0-Wert übermittelt.
                        //
                        //Das versteckte Feld darf nicht gesetzt werden, wenn Inhalt bereits 1 ist sowie im Formularmodus filter (3) oder filter_with_required (8).
                        $hidden_content = "<input ".
                                        "name=\"".$in_nameAttr."\" ".
                                        "id=\"".$in_idAttr."_hidden\" ".
                                        "type=\"hidden\" ".
                                        "value=\"".$hidden_value."\" ".
                                        "data-feldid=\"".$in_field->id."\" ".
                                        "data-feldappid=\"".$in_field->app_id."\" ".
                                        "data-formid=\"".$in_field->form_id."\" ".
                                        $accept.
                                        $checked.
//                                        $in_field->readonlyCode.              //eine versteckte Checkbox darf niemals disabled sein, da ihr Wert sonst nicht übertragen wird.
                                        ">";
//                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> hidden_content : ', $hidden_content);
    
                    } 
                    
                    //Bei einzeiligen Textfeldern muss ein doppeltes Hochkammata geparsed werden, da das value-Attribut sonst an der Stelle als beendet interpretiert wird.
                    $in_field->feldinhalt = htmlspecialchars($in_field->feldinhalt ?? '', ENT_QUOTES);
                    $content = "<input 
                                    name=\"$in_nameAttr\" 
                                    id=\"$in_idAttr\" 
                                    title=\"$in_field->name (Feld-ID=$in_field->id)\" 
                                    class=\"".$in_field->class_content.$in_field->addClassCode.$addDateClass."\" 
                                    type=\"$in_type\" ".
                                    "style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\" ". 
                                    $addAttribut.
                                    $maxlength.
                                    "value=\"$in_field->feldinhalt\" ".
                                    $onKeyUp.
                                    "onclick=\"$in_field->javascriptOnclick\" 
                                    oninput=\"$in_field->javascriptOninput\" 
                                    data-feldid=\"$in_field->id\" 
                                    data-feldappid=\"$in_field->app_id\" 
                                    data-formid=\"$in_field->form_id\" 
                                    data-group_id=\"$group_id\" 
                                    $form_and_instanz 
                                    $js_onchange  
                                    $checked 
                                    $multiple 
                                    $aria_label 
                                    $accept 
                                    $in_field->requiredCode 
                                    $in_field->readonlyCode>";
                }
                

                
            } elseif ($in_field->zeilen > 1) {                                    //mehrzeiliges Text-Feld
                $in_field->class_content = "field_content_textarea";
//                $height = "height=\"$in_field->zeilen\"";
                if($in_showName<>2) {
                    //showname = 2 -> nur der Name des Feldes soll angedruckt werden (Überschriftenzeile)
                    $content = "<textarea 
                                    name=\"$in_nameAttr\" 
                                    id=\"$in_idAttr\" 
                                    title=\"$in_field->name\" 
                                    class=\"".$in_field->class_content.$in_field->addClassCode.$addDateClass."\" 
                                    cols=\"$in_field->laenge_content\" ".
                                    "style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\" ".
                                    $addAttribut.
                                    "maxlength=\"$in_field->maxZeichen\" 
                                    rows=\"$in_field->zeilen\"
                                    onclick=\"$in_field->javascriptOnclick\"
                                    oninput=\"$in_field->javascriptOninput\" 
                                    data-feldid=\"$in_field->id\" 
                                    data-group_id=\"$group_id\" 
                                    data-feldappid=\"$in_field->app_id\" 
                                    $form_and_instanz 
                                    $js_onchange 
                                    $checked 
                                    $multiple 
                                    $aria_label 
                                    $in_field->requiredCode 
                                    $in_field->readonlyCode"
                                    .">$in_field->feldinhalt<".             //Beachte, zwischen den Tagzeichen (><) und dem Feldinhalt darf ekin weiteres Zeichen sein, sonst wird dieses auf der Maske mit angedruckt.        
                                "/textarea>\r\n";
                }


                
            }
            
            
            
            $localFeedback = getCellContent($in_field, $in_showName, $height, $in_idAttr, $content, $hidden_content, $group_id, $in_constructor, false, $in_instance_mode);
            
            return $localFeedback;
        }        
        
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "WYSIWYG" den HTML-Code des zugrundliegenden Textarea oder ein einfaches div, wenn mode = "only_read".
         * 
         * 
         * @param   object  $in_field       Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr    Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr      Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   string  $in_form_mode   Modus, in dem das Formular aufgerufen werden soll. Bei modus only_read werden WYSIWYG-Felder nur als DIV dargestellt. D.h. nur der Content wird dargestellt.
         * @param   integer $in_showName    Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @return  string                  HTML-Code eines Formularfeldes
         */
        function _getFieldWysiwyg($in_field, $in_nameAttr, $in_idAttr, $in_form_mode, $in_showName) {
            $content = "";
            $height = "height=\"$in_field->zeilen\"";
            $hidden_content = "";
            $localFeedback = "";
            $addClass = " wysiwyg";
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Form_mode: ', $in_form_mode);
            

            

//            $maxlaenge = $in_field->laenge;                                     //die Zahl der zulässigen Zeichen muss groß sein, da Bilder im base64-Format gespeichert werden.
            if ($in_form_mode == "7" AND $in_showName <> 2) {
                //form_mode 7 = only_read
                //showName 2 = nur Überschrift
                $content =  "<div ". 
                                "name=\"".$in_nameAttr."\" ".
                                "role=\"none\" ".
                                "style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\" ".
                                "id=\"".$in_idAttr."\" ".
                                "title=\"".$in_field->name." (Feld-ID=".$in_field->id.")\" ".
                                "class=\"".$in_field->class_content."\" ".
                                "onclick=\"".$in_field->javascriptOnclick."\" ". 
                                "data-formid=\"".$in_field->form_id."\" ".
                                "data-feldid=\"".$in_field->id."\" ".
                                "data-feldappid=\"".$in_field->app_id."\">".
                                    $in_field->feldinhalt.
                            "</div>\r\n".
                        
                        
                            "<textarea ".
                                "name=\"".$in_nameAttr."\" ".
                                "class=\"field_hidden\" ".
                                "id=\"".$in_idAttr."_hidden\" ".
                                "type=\"hidden\" ".
                                "data-feldid=\"".$in_field->id."\" ".
                                "data-feldappid=\"".$in_field->app_id."\" ".
                                "data-formid=\"".$in_field->form_id."\" >".
                                $in_field->feldinhalt.
                            "</textarea>\r\n";
                
                           
//                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> hidden_content : ', $hidden_content);
    
            } elseif ($in_showName <> 2) {
                //showName 2 = nur Überschrift
                $in_field->class_content = "field_content_textarea";
                
                $content = "<textarea 
                                name=\"$in_nameAttr\" 
                                id=\"$in_idAttr\" 
                                title=\"$in_field->name\" 
                                class=\"".$in_field->class_content.$in_field->addClassCode.$addClass."\" 
                                maxlength=\"$in_field->maxZeichen\" 
                                rows=\"$in_field->zeilen\"
                                height=\"$in_field->zeilen\" 
                                onclick=\"$in_field->javascriptOnclick\" 
                                data-feldid=\"$in_field->id\" 
                                data-feldappid=\"$in_field->app_id\" 
                                onblur=\"$in_field->javascriptOnchange\" ".
                                "style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\" ".
                                $in_field->requiredCode." ". 
                                $in_field->readonlyCode." ".
                                ">$in_field->feldinhalt<".             //Beachte, zwischen den Tagzeichen (><) und dem Feldinhalt darf ekin weiteres Zeichen sein, sonst wird dieses auf der Maske mit angedruckt.        
                            "/textarea>";
            }
            
            $localFeedback = getCellContent($in_field, $in_showName, $height, $in_idAttr, $content, $hidden_content, "", "undefined", false, $in_form_mode);
            
            
            return $localFeedback;
        }        
        
        
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "Label (Bezeichnung)" den HTML-Code.
         * 
         * @param   object  $in_field                       Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr                    Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr                      Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   integer $in_showName                    Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @param   string  $in_add_class_for_label         Zusätzliche Klasse, die im Attribut "class" abgelegt wird.
         * @param   string  $in_show_content_type           Gibt an, ob der Feldinhalt (content) oder der Hilfetext angedruckt werden soll (helptext); Mögliche Werte: (content|helptext|date)
         * @param   object  $in_fieldlist                   Objekt vom Typ HtmlFieldlist, welche alle Felder des aktuellen Formulars enthält
         * @return  string                      HTML-Code eines Formularfeldes
         */
        function _getFieldLabel($in_field, $in_nameAttr, $in_idAttr, $in_showName, $in_add_class_for_label, $in_show_content_type, &$in_fieldlist) {
            $content = "";
            $height = "";
            $hidden_content = "";
            
            if($in_show_content_type == "content") {
                $inner_content = nl2br($in_field->feldinhalt);
            } elseif($in_show_content_type == "helptext") {
                $my_content = replaceFieldplaceholderInString($in_field->helptext, $in_fieldlist);
                $inner_content = nl2br($my_content);
            } elseif($in_show_content_type == "date") {
                if(date_create($in_field->feldinhalt) !== false) {
                    $my_date=date_create($in_field->feldinhalt);
                    $my_format = getConfig("date_format", $in_field->app_id);
                    $inner_content = date_format($my_date,$my_format);
                } else {
                    $inner_content = $in_field->feldinhalt;
                }
            } else {
                $inner_content = "Fehlkonfiguration in Feldart _getFieldLabel";
            }
            
            if($in_showName<>2) {
                    //showname = 2 -> nur der Name des Feldes soll angedruckt werden (Überschriftenzeile)
                    $content = "<label". 
                                    //" name=\"".$in_nameAttr."\"".             //Attribut name ist für label im HTML-Standard nicht erlaubt
                                    " id=\"".$in_idAttr."\"". 
                                    " title=\"".$in_field->name." (Feld-ID=".$in_field->id.")\"". 
                                    " class=\"".$in_field->class_content." $in_add_class_for_label\"". 
                                    " style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\"".
                                    " onclick=\"".$in_field->javascriptOnclick."\"". 
                                    " data-formid=\"".$in_field->form_id."\"". 
                                    " data-feldid=\"".$in_field->id."\"". 
                                    " data-feldappid=\"".$in_field->app_id."\">".
                                        $inner_content.
                                "</label>";
            } else {
                if(strpos($in_add_class_for_label, "hidden") !== false) {
                    $in_showName = 0;       //Andruck Überschrift unterdrücken, wenn label-class vom Typ "hidden"
                }
            }
            
            
            $localFeedback = getCellContent($in_field, $in_showName, $height, $in_idAttr, $content, $hidden_content, "");
            
            return $localFeedback;
        }
        
        
        
       
        
        
        
        /** Ermittelt die Tags, welche in Abhängigkeit davon, ob eine klassische Tabelle mit table-Tag oder 
         * eine Placebo-Tabelle mit div-Tags aufgebaut werden soll. Zudem wird, für die erste Zeile einer Tabelle
         * th, statt td vorgegeben.
         * 
         * 
         * @param   integer     $in_posHeader       [optional] pos_header: [0 = links| 1 = oben| 2 = aus]; (default = 1)
         * @return  array                           Bsp.: array(rowTag => [div], cellTag => [span|div], headerTag => [span|div])
         */
        function getTagVariables($in_posHeader = 1) {
            $myTags = array();
            
            
            $myTags["cellTag"] = "div";
            $myTags["rowTag"] = "div";
            $myTags["headerTag"] = "label";           //tag der Überschrift eines Feldes
            
            if($in_posHeader == 0) {
                //kein Zeilenumbruch zwischen Feldbezeichnung und Feld
                $myTags["cellTag_class"] = "field_name_left";
                $myTags["flex_direction"] = "flex_row";
            } else {
                $myTags["cellTag_class"] = "field_name";
                $myTags["flex_direction"] = "flex_column";
            }
            
            
            
            return $myTags;
        }
        
        
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "number" den HTML-Code.
         * 
         * @param   object  $in_field           Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr        Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr          Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   integer $in_showName        Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @param   integer $instance_form_mode Modus der aktuellen Instanz
         * @return  string                      HTML-Code eines Formularfeldes
         */
        function _getFieldNumeric($in_field, $in_nameAttr, $in_idAttr, $in_showName, $instance_form_mode) {
            $content = "";
            $height = "";
            $hidden_content = "";
            $addAttribut = "";
            
            
            if ($in_field->add_attribut !== "") {$addAttribut = $in_field->add_attribut." ";}
            
            if($in_showName<>2) {
                //showname = 2 -> nur der Name des Feldes soll angedruckt werden (Überschriftenzeile)
                
                if($in_field->numericMin == "") {$min = "";} else {$min = "min=\"$in_field->numericMin\"";}
                if($in_field->numericMax == "") {$max = "";} else {$max = "max=\"$in_field->numericMax\"";}
                
                $content = "<input 
                                name=\"$in_nameAttr\" 
                                id=\"$in_idAttr\" 
                                title=\"$in_field->name (Feld-ID=$in_field->id)\" 
                                class=\"$in_field->class_content$in_field->addClassCode\" 
                                type=\"number\" ".
                                "style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\" ".
                                $addAttribut.
                                "step=\"any\"
                                value=\"$in_field->feldinhalt\" 
                                onclick=\"$in_field->javascriptOnclick\" 
                                data-feldid=\"$in_field->id\" 
                                data-feldappid=\"$in_field->app_id\" 
                                data-formid=\"$in_field->form_id\" 
                                $min
                                $max
                                onchange=\"$in_field->javascriptOnchange\" 
                                oninput=\"$in_field->javascriptOninput\"
                                $in_field->requiredCode 
                                $in_field->readonlyCode>";
            }
            
            
            $localFeedback = getCellContent($in_field, $in_showName, $height, $in_idAttr, $content, $hidden_content, "", "undefined", false, $instance_form_mode);
            
            
            return $localFeedback;
        }   
        
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "range" den HTML-Code.
         * 
         * @param   object  $in_field           Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr        Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr          Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   integer $in_showName        Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @param   object  $in_fieldObjectTree Referenz zum FieldObjectTree. Über diesen kann auf die Feldinhalte der anderen Felder des gleichen Datensatzes zugegriffen werden.
         * @return  string                      HTML-Code eines Formularfeldes
         */
        function _getFieldRange($in_field, $in_nameAttr, $in_idAttr, $in_showName, &$in_fieldObjectTree) {
            $content = "";
            $height = "";
            $hidden_content = "";
            $addAttribut = "";
            
            if($in_field->readonlyCode !== "") {
                $in_field->readonlyCode ="disabled=\"disabled\"";
            }
            
            if ($in_field->add_attribut !== "") {$addAttribut = $in_field->add_attribut." ";}
            
            //Maximalen Rangebereich ermitteln
            if($in_fieldObjectTree->getFieldValueByColumn("max_step") != "") {
                //Wenn im gleichen Datensatz ein Feld mit der db_spalte "max_step" existiert, dann wird dessen value genutzt.
                //Auch im Form-Modus 2 (insert), kann dessen value über dessen Vorgabe-Funktion sinnvoll verwendet werden.
                $max_step = $in_fieldObjectTree->getFieldValueByColumn("max_step")+1;
            } else {
                //Default: max_step wird anhand der numericMax-Angabe desselben Feldes gefüült. Damit ist es für dieses Formular jedoch eine Konstante.
                //Ein Datensatzabhängiger Wert ist nicht möglich.
                $max_step = $in_field->numericMax;
            }
            
            
            
            //Name des aktuellen Steps am Schiebeschalter festlegen
            if($in_fieldObjectTree->getFieldValueByColumn("wkfl_step_name") != "") {
                //Wenn im gleichen Datensatz ein Feld mit der db_spalte "wkfl_step_name" existiert, dann wird dessen value genutzt.
                //Auch im Form-Modus 2 (insert), kann dessen value über dessen Vorgabe-Funktion sinnvoll verwendet werden.
                $title = $in_fieldObjectTree->getFieldValueByColumn("wkfl_step_name")." (Feld-ID=".$in_field->id.")";
            } else {
                //Default: max_step wird anhand der numericMax-Angabe desselben Feldes gefüllt. Damit ist es für dieses Formular jedoch eine Konstante.
                //Ein Datensatzabhängiger Wert ist nicht möglich.
                $title = $in_field->name." (Feld-ID=".$in_field->id.")";
            }
            
            
            
            
            if($in_showName<>2) {
                //showname = 2 -> nur der Name des Feldes soll angedruckt werden (Überschriftenzeile)
                $content = "<input 
                                name=\"$in_nameAttr\" 
                                id=\"$in_idAttr\" 
                                title=\"$title\" 
                                class=\"$in_field->class_content$in_field->addClassCode\" 
                                type=\"range\" ".
                                "style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\"".
                                $addAttribut.
                                "step=\"1\"
                                value=\"$in_field->feldinhalt\" 
                                onclick=\"$in_field->javascriptOnclick\" 
                                data-feldid=\"$in_field->id\" 
                                data-feldappid=\"$in_field->app_id\" 
                                data-formid=\"$in_field->form_id\" 
                                min=\"$in_field->numericMin\"
                                max=\"$max_step\"
                                onchange=\"$in_field->javascriptOnchange\" 
                                oninput=\"$in_field->javascriptOninput\" 
                                $in_field->requiredCode 
                                $in_field->readonlyCode>";
            }
            
            
            $localFeedback = getCellContent($in_field, $in_showName, $height, $in_idAttr, $content, $hidden_content, "");
            
            
            return $localFeedback;
        }   
        
        
        
        
        /** Erzeugt den HTML-Code für eine versteckte Datensatzmarkierung.
         * 
         * @param   string  $in_addDsID                 Datensatz-ID; wenn leer, dann gibt diese Funktion auch nur einen Leerstring zurück.
         * @param   string  $in_addToName               String, der in der Feld_id ergänzt wird. Idealerweise ist das eine fortlaufende Zahl, um eindeutige ID's auf der ganzen Webseite zu erreichen
         *                                              $addToName kann ein Leerstring sein oder folgende Syntax haben: "Form".$in_form_id."_".$datensatzNr."_".$in_currentFormInstanceId -> Bsp.: Form43_0_i0
         * @param   integer $in_start_or_end            Kennzeichen, ob es sich um die Start- oder Endmarkierung eines Datensatzes handelt. Möliche Werte -> [start|end]
         * @param   string  $insertAdditionalHtmlCode   Html-Code, der zusätzlich in dem Feld integriert werden soll. Wenn nicht benötigt, dann Leerstring übergeben
         * @param   integer $in_showName                Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @return  string                              HTML-Code eines Datensatzmarkierungsfeldes
         */
        function _getFieldHiddenDSMarker($in_addDsID, $in_addToName, $in_start_or_end, $insertAdditionalHtmlCode, $in_showName) {
            $localFeedback = "";
            $content = "";
            $app_id_from_kernel = global_variables::getAppIdFromSYS01();
            
           
            if($in_start_or_end == "start") {
                $dataRowType = getConfig("datensatz_startattribut", $app_id_from_kernel).$in_addDsID."_".$in_addToName;
            } else {
                $dataRowType = getConfig("datensatz_endattribut", $app_id_from_kernel).$in_addDsID."_".$in_addToName;
            }

            

            //Einfügen eines versteckten Feldes, welches den Beginn eines Datensatzes markiert.
            if ($in_addDsID !== "") {
                $content = "<input ".
                                "name=\"$dataRowType\" ".
                                "id=\"$dataRowType\" ".
                                "type=\"hidden\" ".
                                "value=\"$dataRowType\">".
                            $insertAdditionalHtmlCode;
                
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> ergänze content: ', $content); 
                
                $field = new HTMLField();
                $field->pos_header = 2;
                $field->inline = 1;
                $field->colIndex = 1;
                
                $localFeedback = getCellContent($field, 0, "", $dataRowType, $content, "", "", "undefinded",true);
            
            } else {
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> in_addDsID is leer: ', $in_addDsID);
                
            }
            
            

            return $localFeedback;
        }   
        
        
        /** Erzeugt den HTML-Code für ein verstecktes Feld mit dem Hashwert aller anderen Felder des Datensatzes
         * 
         * @param   integer $in_sumOfFeldinhalt Summe (Concat) aller Werte des Datensatzes. Daraus wird der Hash-Wert gebildet.
         * @param   string  $in_hashFieldname   Name des Hash_Feldes
         * @param   integer $in_showName        Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @return  string                      HTML-Code eines Datensatzmarkierungsfeldes
         */
        function _getFieldHiddenHashvalue($in_sumOfFeldinhalt,$in_hashFieldname, $in_showName) {
            $content = "";
            
           

            //Einfügen eines versteckten Feldes, welches den Beginn eines Datensatzes markiert.
            $content =  "<input name=\"$in_hashFieldname\" ".
                            "id=\"$in_hashFieldname\" ".
                            "type=\"hidden\" ".
                            "value=\"".md5($in_sumOfFeldinhalt)."\">";
//                            "value2=\"".$in_sumOfFeldinhalt."\">";     //Wenn Klartext statt Hash verwendet werden soll, dann zugehörige Funktion in pagedata_class.buildArrayWithChangedAndNewData ebenfalls ändern.

                        
            
            $localFeedback = getCellContent("no_field", $in_showName, "", $in_hashFieldname, $content, "", "", "undefinded",true);
            
            return $localFeedback;
        } 
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "trennlinie" den HTML-Code, mit darunter liegenden helptext generiert
         * 
         * @param   object  $in_field       Objekt vom Typ HtmlField
         * @param   string  $in_idAttr      Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   object  $in_fieldlist   Objekt vom Typ HtmlFieldlist, welche alle Felder des aktuellen Formulars enthält
         
         * @return  string                  HTML-Code eines Formularfeldes
         */
        function _getSeparatorLine($in_field, $in_idAttr, $in_fieldlist) {
 
            $abstandOberhalbDerLinie = $in_field->zeilen * 20;
            $abstandOberhalbDerLinie = $abstandOberhalbDerLinie."px";

            $content = "";
            $height = "";
            $hidden_content = "";
            $in_field->laenge_sum = $in_field->laenge_content;                      //eine Trennlinie soll stets der laenge_content entsprechen
            
            $my_helptext = replaceFieldplaceholderInString($in_field->helptext, $in_fieldlist);
            
            
            
            $content = "<div". 
                            " class=\"trennlinie\" ". 
                            " id=\"".$in_idAttr."\"". 
                            " role=\"none\" ".
                            " style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";margin-top:".$abstandOberhalbDerLinie.";\"".
                            " data-formid=\"".$in_field->form_id."\"". 
                            " data-feldid=\"".$in_field->id."\"". 
                            " data-feldappid=\"".$in_field->app_id."\">".
                                "$my_helptext".
                        "</div>";
            
            
            
            $localFeedback = getCellContent($in_field, false, $height, $in_idAttr, $content, $hidden_content, "");

            return $localFeedback;
        } 
        
        
        

        
        
        /** Erzeugt die Startsequenz für einen neuen Datensatz (tablerow as tr oder div_row as div
         * 
         * @param   boolean $in_buildTable          Gibt an, ob eine Tabellen-artige Struktur mit Überschriftenzeile (true) oder eine Single-Data-Eingabemaske (false) erzeugt werden soll.
         * @param   string  $in_Datensatznummer     Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   boolean $in_afterLineFeed       Gibt an, ob es sich noch um den selben Datensatz handelt, innerhalb dessen lediglich ein Zeilenumbruch gesetzt wird.
         * @param   boolean $in_headline            Gibt an, ob es sich um die Überschriftenzeile handelt.
         * @param   string  $in_css_constructor_class   Name der CSS-Klasse, welche den Html-Elementen zusätzlich mitgegeben werden soll.
         * @param   Integer $in_form_id             ID des Formulars
         * @param   string  $in_instanz_id          ID der Instanz des Formulars
         * @param   integer $in_aria_row_id         Zeilennummer nach Aria; muss bei 1 beginnen; Überschriftenzeile muss ebenfalls mitgezählt werden. 
         * @return  string                          HTML-Code eines Formularfeldes
         */
        function _getDatensatzStartsequenz($in_buildTable, $in_Datensatznummer, $in_afterLineFeed, $in_headline, $in_css_constructor_class, $in_form_id, $in_instanz_id, $in_aria_row_id) {
            $constructor_type = "";
            if($in_buildTable == true) {$constructor_type = "table";} else {$constructor_type = "single";}
            
            //if($in_afterLineFeed == true AND $in_Datensatznummer > 0) {
            if($in_afterLineFeed == true) {
                $add_mark = "_afterLineFeed_".$constructor_type;
            } elseif($in_headline === true) {
                $add_mark = "head_".$constructor_type;
            } else {
                $add_mark = $constructor_type;
            }
            
            
            
            //Struktur mit div's aufbauen
            $feedback = "<div class=\"div_row_".$add_mark." div_row_".$add_mark."_".$in_css_constructor_class."\" role=\"row\" aria-rowindex=\"$in_aria_row_id\" id=\"row_".$in_Datensatznummer.$add_mark."_".$in_form_id."_".$in_instanz_id."\" data-row_in_form_instanz=\"form".$in_form_id."instance".$in_instanz_id."\" >\r\n";
            
            return $feedback;
        }  
        
        
        
        /** Erzeugt die Endsequenz für einen Datensatz (tablerow as tr oder div_row as div
         * 
         * @return  string                          HTML-Code eines Formularfeldes
         */
        function _getDatensatzEndsequenz() {
            
            $feedback = "</div>\r\n";
           
            return $feedback;
        } 
        
        
        
        
        
        
        /** Liefert ein Div, in dem der Text aus dem Config-Parametr note_if_filter_found_no_data eingebettet wird.
         * 
         * @param   string  $in_app_id      APP-ID, da der Config-Parameter APP-spezifisch abgelegt werden kann.
         * @return  string
         */
        function _getNoDataDefaultText($in_app_id) {
            
            
            $info_text = getConfig("note_if_filter_found_no_data", $in_app_id);
            $feedback = "<div class=\"no_data_available\">".$info_text."</div>";
           
            return $feedback;
        }
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "image" den HTML-Code.
         * 
         * @param   object  $in_field           Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr        Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr          Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   integer $in_showName        Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @return  string                      HTML-Code eines Formularfeldes
         */
        function _getFieldImage($in_field, $in_nameAttr, $in_idAttr, $in_showName) {
            $content = "";
            $height = "";
            $hidden_content = "";

            //Default-Image, wenn keine Bildquelle angegeben wurde
            if($in_field->feldinhalt == "") {
                $src = getConfig("default_no_image", $in_field->app_id);
            } else {
                $src = $in_field->feldinhalt;
            }
            
            
            if($in_showName<>2) {
                    //showname = 2 -> nur der Name des Feldes soll angedruckt werden (Überschriftenzeile)
                    $content = "<img 
                                    alt=\"$in_field->name\" 
                                    id=\"$in_idAttr\" 
                                    title=\"$in_field->name (Feld-ID=$in_field->id)\" 
                                    class=\"$in_field->class_content$in_field->addClassCode\" ". 
                                    "style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";\"".
                                    "heigth=\"$in_field->zeilen\"
                                    src=\"$src\" 
                                    onclick=\"$in_field->javascriptOnclick\" 
                                    data-formid=\"$in_field->form_id\" 
                                    data-feldid=\"$in_field->id\" 
                                    data-feldappid=\"$in_field->app_id\">".
                                "</img>";
                }
            
            
            $localFeedback = getCellContent($in_field, $in_showName, $height, $in_idAttr, $content, $hidden_content, "");
            
            return $localFeedback;
        }   
        
        
        
        /** HTML-Code für das Hinweisfeld, dass der DS für den aktuellen User gesperrt ist.
         * 
         * @param   boolean     $in_getAttentionButton      Wenn true, wird ein Hinweisbutton für den gesperrten Datensatz zurückgegeben. 
         * @return  string                                  HTML-Code, fix verbunden mit Feld-ID 2377 (Hinweisbutton) oder 2570 (Platzhalterbild)
         */
        function _getAttentionMark($in_getAttentionButton) {
            $app_id_from_kernel = global_variables::getAppIdFromSYS01();
            $feedback = "";

                
            if($in_getAttentionButton == false) {
                //es handelt sich nicht um einen geschützten Datensatz.
                //es wird ein Platzhalter eingefügt, der die gleiche Breite, wie ein Hinweisfeld hat, um das Layout gleichmäßig zu halten.
//                $feedback = "<input ". 
//                                        "class=\"placeholder_image\" ".
//                                        "id=\"placeholder_2570\" ".                //fixe Feld-ID, da der Hinweistext immer gleich sein soll
//                                        "type=\"image\" ".
//                                        "data-feldid=\"2570\" ".
//                                        "onClick=\"return false;\" ".
//                                        "data-feldappid=\"$app_id_from_kernel\" >";
            } else {
            
                //button für den Aufruf des Hinweistextes erstellen
                $feedback = "<input ". 
                                "class=\"attentionmark_as_button\" ".
                                "id=\"help_2377\" ".                //fixe Feld-ID, da der Hinweistext immer gleich sein soll
                                "type=\"image\" ".
                                //"alt=\"....\" ".                        //wichtig für Browser, die bei einem fehlenden Bild sonstige Zeichen über dem eigentlichen Backgroundimage darstellen
                                "data-feldid=\"2377\" ".
                                "data-feldappid=\"$app_id_from_kernel\" ".
                                "formnovalidate=\"formnovalidate\" ".
                                "src=\"../data/SYS01/img/platzhalter_transparent1x1.png\" ".
                                "onclick=\"return getHilfeByFeldID2(event)\">";
            }
            return $feedback;
        }
        
        
        
        
        /** Gibt den HTML-Code für die Markierungscheckbox eines Datensatzes zurück.
         * 
         * @param   string      $in_formConstructor     [SingleData|TableData|...]
         * @param   string      $in_markFieldID         Name des Markierungfeldes
         * @param   string      $in_formAppID           APP-ID des Formulars     
         * @param   boolean     $in_showNoteForSysData  Gibt an, ob es sich um einen geschützten Systemdatensatz handelt.
         * @param   boolena     $in_is_header           Gibt an, ob es sich um die Überschriftenzeile handelt
         * @param   string      $in_form_id             Attribut form_id, welches das Formular verwendet. Das Attribut wird verwendet, damit das DOM-Element form per Javascript selectiert werden kann.
         * @param   integer     $in_aria_colindex       Spaltenindex für Barrierefreiheit
         * @param   boolean     $in_activate            Gibt an, ob die Checkbox aktiviert werden soll
         * @return  string                              HTML-Code für die Checkbox bzw. AttentionsMark, wenn es sich um einen geschützten Datensatz handelt.
         */
        function _getMarkField($in_formConstructor, $in_markFieldID, $in_formAppID, $in_showNoteForSysData, $in_is_header, $in_form_id, $in_aria_colindex, $in_activate) {
             
            $htmlCodeForMarkField = "";
            
            //Bei Singledata muss der Datensatz markiert sein, damit da das Markierungsfeld versteckt wird. 
            //Außerdem wird es aktiviert, wenn form_modus = 4 (activeFilter) und nur ein Datensatz vorhanden ist.
            if($in_activate == true) {
                $checked = " checked=\"checked\" ";
            } else {
                $checked = "";
            }
            
            
            //Wenn header, dann checkAll-JS-Funktion verknüpfen
            if ($in_is_header === true) {
                $js_onClick = "onclick=\"checkAllCheckboxes(event)\"";
                $aria_role = "columnheader";
            } else {
                $js_onClick = "";
                $aria_role = "gridcell";
            }
            
            
            //Markfieldgroup-ID bilden, damit alle Checkboxen, die der gleichen Gruppe angehören, erkannt werden können.
            $markFieldID = explode("_", $in_markFieldID);
            $markFieldGroupID = $markFieldID[0];
            
            
            $markField = "<input ".
                            "type=\"checkbox\" ".
                            "name=\"$in_markFieldID\" ".
                            $checked.
                            "value=\"mark\" ".
                            "title=\"mark\" ". 
                            "data-ds_hide=\"false\" ".
                            "id=\"$in_markFieldID\" ".
                            "data-feldid=\"$in_markFieldID\" ".
                            "data-group_id=\"$markFieldGroupID\" ".
                            "data-form_id=\"$in_form_id\" ".
                            $js_onClick." ".
                            "class=\" \" >";
            
            
            
            if ($in_formConstructor=="SingleData") {
                //Bei SingleData ist das Markierungsfeld aktiviert und versteckt.
                $div_class = "field_hidden";
            } else {
                $div_class = "field_container_left mark_field_range";
            }
            $htmlCodeForMarkField = $htmlCodeForMarkField. "<div class=\"".$div_class."\" role=\"none\" data-feldid=\"div_".$in_markFieldID."\">\r\n";
                if($in_formAppID == global_variables::getAppIdFromSYS01()) {$htmlCodeForMarkField = $htmlCodeForMarkField._getAttentionMark($in_showNoteForSysData)."\r\n";}
                //if($in_showNoteForSysData === false) {
                    $htmlCodeForMarkField = $htmlCodeForMarkField.$markField;
                //}
            $htmlCodeForMarkField = $htmlCodeForMarkField."\r\n</div>\r\n";
            
            
            return $htmlCodeForMarkField;
        }
        
        
        
        
        
        /** Stellt für die Überschriftenzeile von Checkboxen die Checkbox, welche alle Checkboxen der
         * gleichen group_id im gleichen Formular steuern kann, bereit.
         * 
         * @param   string  $in_group_id    ID der Gruppe, aller Checkboxen der gleichen Spalte
         * @param   string  $in_form_id     ID des Formulars
         * @return  string                  HTML-Code der Checkbox
         */
        function _getCheckboxInHeader($in_group_id, $in_form_id) {
             
            $htmlCodeForCheckbox = "";
            $form = "form_".$in_form_id."_i0";
            
            $markField = "<input ".
                            "type=\"checkbox\" ".
                            "name=\"".$in_group_id."_head_\" ".
                            "title=\"alle aktivieren bzw. deaktivieren\" ".
                            "id=\"All_Ctrl$in_group_id\" ".
                            "data-group_id=\"$in_group_id\" ".
                            "form_id=\"$form\" ".
                            "role=\"columnheader\" ".
                            "onclick=\"checkAllCheckboxes(event)\" ".
                            "class=\" \" >";
            

            $htmlCodeForCheckbox = $htmlCodeForCheckbox.$markField;
            

            return $htmlCodeForCheckbox;
        }
        
        
        
        /** Erzeugt den HTML-Code für die Bezeichnung eines Feldes
         * 
         * @param   string  $in_name_tag        Name eines tags, welcher verwendet werden soll [div|span]
         * @param   object  $in_field           Objekt vom Typ html_field
         * @param   string  $in_class           CSS-Class_Name, welcher dem Tag hinzugefügt werden soll.
         * @param   string  $in_group_id        ID aller Elemente der gleichen Spalte
         * @param   string  $in_constructor     Name des Constructors
         * @param   mixed   $form_mode          Modus der aktuellen Instanz des Formulares. Wert kann theoretisch auch undefined sein.
         * @param   boolean $in_is_hidden_field Gibt an, ob es sich um ein verstecktes Feld handelt. Versteckte Felder, müssen die role "none" erhalten, damit sie screenreader nicht stören.
         *  
         * @return  string                  HTML-Code
         */
        function _getNameOfField($in_name_tag, $in_field, $in_class, $in_group_id, $in_constructor, $form_mode, $in_is_hidden_field = false){
            $helptext = "";
            $ctrlCheckbox = "";
            
            if($in_field->helptext <> "" and $in_is_hidden_field == false) {
                //Wenn ein Hilfetext vorhanden ist, wird ein button für den Aufruf des Hilfetextes erstellt
                $helptext = "<input ". 
                                "class=\"questionmark_as_button\" ".
                                "id=\"help_$in_field->id\" ".
                                "type=\"image\" ".
                                "alt=\"Hilfelink für Feld $in_field->name\" ".    
                                "title=\"Hilfelink für $in_field->name\" ". 
                                "data-feldid=\"$in_field->id\" ".
                                "data-feldappid=\"$in_field->app_id\" ".
                                "formnovalidate=\"formnovalidate\" ".
                                "src=\"../data/SYS01/img/platzhalter_transparent1x1.png\" ".    //wichtig für chrome
                                "onclick=\"return getHilfeByFeldID2(event)\"> ";
            } 
                
            
            //bei Checkboxen vom 48 in Tabellen die übergreifende Steuerungscheckbox, für alle Boxen der gleichen group_id, ergänzen. Typ 49 sind Checkboxn ohne Steuercheckbox
            if($in_field->konstante_id=="48" AND strpos(strtoupper($in_constructor), "TABLE")!==false) {
                $ctrlCheckbox = _getCheckboxInHeader($in_group_id, $in_field->form_id);
            }
            
            if($in_is_hidden_field === false) {
                $for = " for=\"".$in_field->idAttr."\"";
                $style = " style=\"width:".$in_field->laenge_heading.$in_field->laenge_measureunit.";\"";
            } else {
                $for = "";
                $style = "";
            }
            
            
            if (strpos($in_field->copy_content_button ?? '', $form_mode) !== false) {
                //Wenn der Form-Mode stimmt, wird  bei Feldarten, die das unterstützen, ein Button eingeblendet, 
                //der den Wert des ersten Feldes einer Treffermenge in die nachfolgenden Datensätze überträgt
                $copyValueButton = "<button ".
                                        "onclick=\"return setFirstValueToAllRows(".$in_field->id.")\"".
                                        "title=\"Inhalt des Feldes im ersten Datensatz in die gleichnamigen Felder der folgenden Datensätze kopieren.\"".
                                        "class=\"button ".$in_field->app_id."_button button_copy_value button_".$in_field->id."\"". 
                                    ">".
                                        "copy value".
                                    "</button>";
            } else {
                $copyValueButton = "";
            }
            

            
            
            if($in_field->required == "1") {$addRequridSign = "*";} else {$addRequridSign = "";}
                                    
            $localFeedback = "<$in_name_tag class=\"".$in_class."\"".$for.$style.">".
                                $ctrlCheckbox."\r\n".
                                $in_field->name.$addRequridSign."\r\n".
                                $helptext.
                                $copyValueButton.
                            "</$in_name_tag>\r\n";
            
            
            
            return $localFeedback;
        }
        
        
        
        /** gibt den Kopfbereich des Formulars vor
         * 
         * @param   array       $in_form        Formulararray
         * @return  string                      div "form_head" und div "form_description"; jeweils öffnend und schließend 
         */
        function _getFormHead(&$in_form) {
            $feedback = "";
            
            //Kopfzeile des Formulars
            if($in_form['form.headline_activate'] == 1) {
                $feedback = $feedback. "<div class=\"form_head\" role=\"heading\" aria-level=\"1\">".$in_form['form.name']."</div>\r\n";
            }
            
            //Formularbeschreibung ergänzen
            if($in_form["form.showdescription"]==1) {
                $feedback = $feedback. "<div name=\"form_description\" > <label class=\"form_description\" >".$in_form["form.description"]."</label></div>\r\n";       
            }
            
            return $feedback;
        }
        
        
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "hidden" den HTML-Code.
         * 
         * @param   object  $in_field                   Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr                Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr                  Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   integer $in_showName                Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @param   boolean $in_hideClassFromContainer  [optional] Wenn true, werden vom umschließenden Container alle CSS-Klassen entfernt. Default = false
         * @return  string                              HTML-Code eines Formularfeldes
         */
        function _getFieldHidden($in_field, $in_nameAttr, $in_idAttr, $in_showName, $in_hideClassFromContainer = false) {
            //Wenn die Daten in einer HTML-Table angeordnet werden sollen, dann werden die folgenden Variablen gepflegt. Ansonsten sind sie einfach leer.
            $temp_classBackup = $in_field->class_container;
            
            if($in_hideClassFromContainer === true) {
                $in_field->class_container = "";
            } 
            
            
            $content = "<input 
                            name=\"$in_nameAttr\" 
                            id=\"".$in_idAttr."_hidden\" ".
                            //role=\"none\"                                     //Attribut role is bei type = hidden nicht zulässig
                            //"class=\"$in_field->class_content$in_field->addClassCode\" 
                            "type=\"hidden\" ".
                            //"style=\"width:".$in_field->laenge_sum.$in_field->laenge_measureunit.";\"".
                            "value=\"$in_field->feldinhalt\" 
                            onclick=\"$in_field->javascriptOnclick\" 
                            data-feldid=\"$in_field->id\" 
                            data-feldappid=\"$in_field->app_id\" 
                            data-formid=\"$in_field->form_id\" 
                            onchange=\"$in_field->javascriptOnchange\">";
            
            
            
            $localFeedback = getCellContent($in_field, 0, "", $in_idAttr, $content, "", "", "undefined", true);
            $in_field->class_container = $temp_classBackup;
            return $localFeedback;
        }   
        
        
        
        
        
        /** Erstellt den Zellknoten (th, td oder div), inkl. Inhalt.
         * 
         * @param   object  $in_field           Objekt vom Typ HtmlField; Wenn kein Feld angegeben werden kann, dann den String "no_field" übergeben.
         * @param   integer $in_showName        Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @param   string  $in_height          Angabe zur Höhe, welche in den Tag als Attribut eingebaut werden kann. (Bsp.: "height=\"$in_field->zeilen\""); Alternativ kann Leerstring übergeben werden.
         * @param   string  $in_idAttr          Wert, der als Inhalt für das HTML-Attribut id gnutzt werden soll.
         * @param   string  $content            Geamtes Tag, samt Inhalt, welches in der Zelle als Content eingebaut werden soll.
         * @param   string  $in_hidden_content  Bei manchen Feldarten, bspw. Checkbox muss nochmal ein analoges Feld vom Typ text übergeben werden, da der Inhalt u.U. sonst nicht via POST übergeben wird.
         * @param   string  $in_group_id        ID der GRuppe, welche alle Elemente der gleichen Spalte kennzeichnet.
         * @param   string  $in_constructor     [optional] Constructorname  -> (default = "undefined")
         * @param   boolean $in_hidden_field    [optional] Ausgeblendete Felder werden mit dem width-Wert = 0px hinterlegt. (default = false)
         * @param   integer $form_mode          [optional] Modus des aktuellen Formulars bzw. der aktuellen Instanz (default = undefined)
         * @return  string                      Zell-Knoten für HTML-Dom.
         */
        function getCellContent($in_field, $in_showName, $in_height, $in_idAttr, $content, $in_hidden_content, $in_group_id, $in_constructor = "undefined", $in_hidden_field = false, $form_mode = "undifined") {
            
            if(is_object($in_field) === false) {
                $in_field = new HTMLField();
                $in_field->pos_header = 0;
                $in_field->inline = 1;
            }
            
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> ergänze CellContent für Feld: ', $in_field);  
            
            $tags = getTagVariables($in_field->pos_header); 
            
            
            //Überschrift/Feldbezeichnung
            //durch nametag wird ggf. ein Zeilenumbruch erzeugt (div = Zeilenumbruch, span = kein Zeilenumbruch).
            //showName: 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld
            $role = "";
            $nameField = "";
            If (in_array($in_showName,array(1,2))  AND $in_field->pos_header<>2) {
                //Name des Feldes (Bezeichnung) wird angedruckt
                // pos_header: [0 = links| 1 = oben| 2 = aus]
                $role = "role=\"columnheader\"";
                $nameField = _getNameOfField($tags["headerTag"], $in_field, $tags["cellTag_class"], $in_group_id, $in_constructor, $form_mode, $in_hidden_field)."\r\n";
            } else {
                $nameField = "";
                $role = "role=\"gridcell\"";
                
            }
            
            if($in_field->colIndex != "") {$aria_colindex = " aria-colindex=\"".$in_field->colIndex."\"";} else {$aria_colindex = "";}
            
            
            if($in_showName == 2) {
                //Wenn nur die Überschrift angedruckt werden soll, dann content unterdrücken.
                $in_hidden_content = "";
                $content = "";
            } 
            
            
            if($in_constructor == "getSymbolGroup" OR $in_hidden_field == true) {
                //Bei Symbolleisten wird, statt des constructores, der Name der aufgerufenen Konstruktor-Klasse übergeben.
                $role = "";
                $aria_colindex = "";
            }
            
            
            
            if($in_field->laenge_sum == 0 OR $in_hidden_field == true OR $in_field->laenge_measureunit == "auto") {
                $width = "width:auto;";
            } else {
                $width = "width:".$in_field->laenge_sum.$in_field->laenge_measureunit;
            }
            
            
            
            
            
            $localFeedback =    "<".$tags["cellTag"]." class=\"".$in_field->class_container." ".$tags["flex_direction"]."\" ".$in_height." id=\"container_".$in_idAttr."\" style=\"".$width."\" ".$role.$aria_colindex.">\r\n".
                                    $nameField.
                                    $in_hidden_content.
                                    $content.
                                "</".$tags["cellTag"].">\r\n";
            
            return $localFeedback;
        }
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "submit" den HTML-Code.
         * Es werden Buttons generiert, die im Formularmodus 2 (insert) eine Zeile ein- oder aushängen können.
         * 
         * @param   object  $in_field_id            ID, die als ID im DOM verwendet wird.
         * @param   string  $in_nameAttr            Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr              Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   integer $in_form_id             ID des aktuellen Formulars
         * @param   integer $in_showName            Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @param   object  $in_pagedata            pagedata-object
         * @param   string  $in_instanceId          Instanz des Formulars
         * @param   integer $in_row                 aktuelle Datensatzzeile
         * @param   string  $in_type                [show|hide]
         * @return  string                          HTML-Code eines Formularfeldes
         */
        function _getFieldButtonShowRow($in_field_id, $in_nameAttr, $in_idAttr, $in_form_id, $in_showName, $in_pagedata, $in_instanceId, $in_row, $in_type) {
            
            $hidden_content = "";
            $content = "";
            $field = new HTMLField();
                $field->pos_header = 0;
                $field->inline = 0;
                $field->class_container = "zeilenumbruch";
            $currentMaskArray = $in_pagedata->getMaskArray();          
            $validation = "formnovalidate=\"formnovalidate\"";
            $validation_class = "novalidate_formid_".$in_form_id;
            $warn = "data-warn-by-change-without-save=\"false\"";
            $buttonname = buildButtonname("default", $in_field_id, $in_type.$in_nameAttr);
            
            
            if($in_type == "show") {
                $newRow = $in_row + 1;
                $js_source = "div_hiddenrowcontainer_form".$in_form_id."_instance".$in_instanceId."_row".$newRow;
                $js_target = "table_data_".$in_form_id."_".$in_instanceId;
                $style_add = ";background-image:url(../data/SYS01/img/plus_640.png);padding-left:"."25px".";padding-right:0px;";
                $hide_button = "hide";
                //wenn eine neue Zeile geholt wird, dann muss der geklickte show-Button ausgeblendet werden.
                $buttonname_show = buildButtonname("default", $in_field_id, "show".$in_nameAttr);  //nur der Show-Button wird ein- oder ausgeblendet.
                $title = "Neue Zeile ergänzen";
            } else {
                $js_source = "div_hiddenrowcontainer_form".$in_form_id."_instance".$in_instanceId."_row".$in_row;
                $js_target = "div_2166";
                $style_add = ";background-image:url(../data/SYS01/img/trash.png);padding-left:"."25px".";padding-right:0px;";
                $hide_button = "show";
                //wenn eine Zeile weggeschoben wird, dann muss stattdessen der vorherige Show-Button wieder eingeblendet werden.
                $previous_row = $in_row-1;
                $previous_nameAttr = str_replace("_".$in_row."_", "_".$previous_row."_", $in_nameAttr);
                $buttonname_show = buildButtonname("default", $in_field_id, "show".$previous_nameAttr);  //nur der Show-Button wird ein- oder ausgeblendet.
                $title = "Zeile entfernen";
            }
            
            

            $content = "<input ". 
                            "type=\"submit\" ".
                            "name=\"".$buttonname."\" ".
                            //"value=\"$in_field->name\" ".
                            "title=\"".$title."\" ".
                            "style=\"width:25px;".$style_add."\" ".
                            "onclick=\"return moveNewRowToForm('".$js_source."','".$js_target."','".$buttonname_show."','".$hide_button."')\" ".
                            "id=\"".$buttonname."\" ".
                            "class=\"button ".$currentMaskArray["app_id"]."_button ".$validation_class." button_".$in_idAttr." button_".$in_field_id."\" ".
                            $validation." ".$warn.
                        ">";
            
            
            
            $localFeedback = getCellContent($field, $in_showName, "", $in_idAttr, $content, $hidden_content, "");
            

            return $localFeedback;
        } 
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "submit" den HTML-Code, der primär für die Verwendung in SimpleTable gedacht ist.
         * 
         * @param   array   $in_button_attribute    Array mit den Buttoneigenschaften <br>
         *                                          Array <br>
                                                            ( <br>
                                                                [field.id] => 11534 <br>
                                                                [field.name] => Parameter <br>
                                                                [field.value] =>  <br>
                                                                [field.valueplaintext] =>  <br>
                                                                [field.feldart] => 2538 <br>
                                                                [formID] => 1842 <br>
                                                                [domID] => 0manager0query_part_select0115340Form1842_1_i0 <br>
                                                                [fieldAppID] => SYS01 <br>
                                                                [javascript_onclick] =>  <br>
                                                                [js_click_params] =>  <br>
                                                            ) <br>
         * @param   string  $in_idAttr              Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @return  string                          HTML-Code eines Formularfeldes
         */
        function _getFieldButtonSimpleTable($in_button_attribute, $in_idAttr) {
            
            $content = "";
            $validation = "formnovalidate=\"formnovalidate\"";
            $validation_class = "novalidate_formid_".$in_button_attribute["formID"];
            $warn = "data-warn-by-change-without-save=\"false\"";
            $buttonname = buildButtonname("default", $in_button_attribute["field.id"], $in_idAttr);
            
            $my_field = new HTMLField();
            $my_field->javascriptOnclick = $my_field->buildJavascriptAttribut($in_button_attribute["javascript_onclick"], $in_button_attribute["js_click_params"]);
            
            //Javascript-Funktion für onclick
            if($my_field->javascriptOnclick == "") {
                $js_click = "";
            } else {
                $js_click = "onclick=\"".$my_field->javascriptOnclick."\"";
            }
          
            //Background-Image
            if(strpos($in_button_attribute["vorgabewert"], "url(") !== false) {
                $style_add = ";background-image:".$in_button_attribute["vorgabewert"].";padding-left:"."25px".";padding-right:0px;";
            } else {
                $style_add = "";
            }
            
            

            $content = "<input ". 
                            "type=\"submit\" ".
                            "name=\"".$buttonname."\" ".
                            "value=\"".$in_button_attribute["field.name"]."\" ".
                            "title=\"". htmlspecialchars($in_button_attribute["helptext"] ?? '')." (Feld-ID=".$in_button_attribute["field.id"].")\" ".
                            "style=\"width:".$in_button_attribute["laenge"]."px;".$style_add."\" ".
                            $js_click." ".
                            "id=\"".$buttonname."\" ".
                            "data-feldid=\"".$in_button_attribute["field.id"]."\" ".
                            "data-feldappid=\"".$in_button_attribute["fieldAppID"]."\" ".
                            "data-formid=\"".$in_button_attribute["formID"]."\" ".
                            "class=\"button ".$in_button_attribute["fieldAppID"]."_button ".$validation_class." button_".$in_idAttr." button_".$in_button_attribute["field.id"]."\" ".
                            $validation." ".$warn.
                        ">";
            
            
            
            
            return $content;
        } 
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "label" den HTML-Code, der primär für die Verwendung in SimpleTable gedacht ist.
         * 
         * @param   array   $in_field_attributs    Array mit den Buttoneigenschaften <br>
         *                                          Array <br>
                                                            ( <br>
                                                                [field.id] => 11534 <br>
                                                                [field.name] => Parameter <br>
                                                                [field.value] =>  <br>
                                                                [field.valueplaintext] =>  <br>
                                                                [field.feldart] => 2538 <br>
                                                                [formID] => 1842 <br>
                                                                [domID] => 0manager0query_part_select0115340Form1842_1_i0 <br>
                                                                [fieldAppID] => SYS01 <br>
                                                                [javascript_onclick] =>  <br>
                                                                [js_click_params] =>  <br>
                                                            ) <br>
         * @param   string  $in_idAttr              Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @return  string                          HTML-Code eines Formularfeldes
         */
        function _getFieldTextSimpleTable($in_field_attributs, $in_idAttr) {
            
            if($in_field_attributs["field.valueplaintext"] != "") {
                $value = $in_field_attributs["field.valueplaintext"];
            } else {
                $value = $in_field_attributs["field.value"];
            }

            $content = "<input ".
                "name=\"".$in_idAttr."\" ".
                "id=\"".$in_idAttr."\" ".
                "type=\"text\" ".
                "class=\"input_like_label\" ".
                "readonly ".
                "value=\"".$value."\" ".
                "data-feldid=\"".$in_field_attributs["field.id"]."\" ".
                "data-feldappid=\"".$in_field_attributs["fieldAppID"]."\" ".
                "data-formid=\"".$in_field_attributs["formID"]."\" ".
                ">";
            
            
            
            
            return $content;
        } 
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "submit" den HTML-Code.
         * 
         * @param   object  $in_field               Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr            Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr              Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   string  $in_mask_link           siehe Tabelle mask (Bsp.: page.php)
         * @param   string  $in_mask_app            siehe Tabelle mask (Bsp.: SYS01)
         * @param   boolean $in_validation          Gibt an, ob Formulardaten vor dem absenden validiert werden sollen. Bei Abbrechen-Buttons sollte die Validierung deaktiviert werden.
         * @param   integer $in_form_id             ID des aktuellen Formulars
         * @param   integer $in_showName            Gibt an, ob Name der Felder angedruckt werden soll; 0 = Nein, 1 = Ja, 2 = nur Name ohne Feld (Überschriftenzeile in einer Tabelle)
         * @param   object  $in_pagedata            pagedata-object
         * @param   string  $in_instance_id         ID der Instanz des Formulars
         * @param   string  $in_constructor_function Name des Funktion, die der Constructor aufrief; Der Constructor selbst konnte nicht genutzt wird, da dann Symbolleisten nicht erkannt werden könnten. Diese geben nämlich den Constructor des umschließenden Formulars weiter.
         * @param   boolean $in_warn_change_without_save    Warnen, wenn Änderungen im Formular vorliegen, aber noch nicht gespeichert wurde.
         * @param   string  $in_constructor         Contructor des Formulars
         * @return  string                          HTML-Code eines Formularfeldes
         */
        function _getFieldSubmitbutton($in_field, $in_nameAttr, $in_idAttr, $in_mask_link, $in_mask_app, $in_validation, $in_form_id, $in_showName, $in_pagedata, $in_instance_id, $in_constructor_function, $in_warn_change_without_save, $in_constructor) {
            
            $hidden_content = "";
            $height = "";
            $content = "";
            
            
            if($in_field->button_action_function_id == "") {
                //das ist notwendig, da sonst pagedata->call_function ein Fehlerfeedback gegeben wird.
                $function_id = 0;
            } else {
                $function_id = $in_field->button_action_function_id;
            }
            
            
            
            $formaction = $in_mask_link.
                    "?mask=".$in_field->button_target_mask.
                    "&maskapp=".$in_mask_app.
                    "&form_id=".$in_field->button_target_form;
            
            //Prüfen, ob eine workflow_url_id existiert.
            if($in_pagedata->internGetObject->getWorkflowUrlID() != "") {
                $formaction = $formaction."&url_id=".$in_pagedata->internGetObject->getWorkflowUrlID();
            }
            
                 
           
            //URL-Parameter aus DB-Tabelle content ergänzen
            if ($in_field->button_paramname != "") {$addButtonParam = "&".$in_field->button_paramname."=$in_field->feldinhalt";} else {$addButtonParam = "";}
            //URL-Parameter aus Mask-Array (css-Styles) ergänzen, falls vorhanden
            $currentMaskArray = $in_pagedata->getMaskArray();
            if(isset($currentMaskArray["css_template_app_id_temp"])) {$addButtonParam = "&css_app=".$currentMaskArray["css_template_app_id_temp"]."&css_id=".$currentMaskArray["css_template_id_temp"];}
            //tab_id ergänzen
            $tab_id = session_class::$session_object->getTabId();
            if($tab_id != false) {$addButtonParam = $addButtonParam."&tab_id=".$tab_id;}
            
            
            if ($in_validation == true) {
                $validation = "";
                $validation_class = "validate_formid_".$in_form_id;
            } else {
                $validation = "formnovalidate=\"formnovalidate\"";
                $validation_class = "novalidate_formid_".$in_form_id;
            } 
            
            
            if ($in_warn_change_without_save == true) {
                $warn = "data-warn-by-change-without-save=\"true\"";
            } else {
                $warn = "data-warn-by-change-without-save=\"false\"";
            }
            
            if(strpos($in_field->vorgabewert ?? '', "url(") !== false) {
                $style_add = ";background-image:".$in_field->vorgabewert.";padding-left:"."25px".";padding-right:0px;";
            } else {
                $style_add = "";
            }
            
            
            if($in_constructor == "dynamicSearch") {
                $style_add = ";display:none;";
            }
            
            $buttonname = buildButtonname("default", $in_field->id, $in_nameAttr);
            
            if($in_showName<>2) {
                    //showname = 2 -> nur der Name des Feldes soll angedruckt werden (Überschriftenzeile)
                    $content = "<input 
                                    type=\"submit\" 
                                    name=\"".$buttonname."\"
                                    formaction=\"".$formaction.$addButtonParam."\" 
                                    value=\"$in_field->name\" 
                                    title=\"". htmlspecialchars($in_field->helptext ?? '')." (Feld-ID=$in_field->id)\" ".
                                    //"alt=\"$in_field->name\" ".               //alt-Attribut ist bei input in HTML-Standard nicht zulässig
                                    "style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";".$style_add."\" ".
                                    "onclick=\"$in_field->javascriptOnclick\" ".
                                    "onsubmit=\"$in_field->javascriptOnsubmit\" ".
                                    "id=\"".$in_idAttr."\" ".
                                    //"id=\"field_$in_field->id\" ".
                                    "data-feldappid=\"$in_field->app_id\" 
                                    formmethod=\"post\" 
                                    data-feldid=\"$in_field->id\" 
                                    data-formid=\"$in_form_id\" 
                                    class=\"button ".$in_field->app_id."_button ".$validation_class." button_".$in_idAttr." button_".$in_field->id."\" 
                                    $validation $warn>";
            }
            
            
            $localFeedback = getCellContent($in_field, $in_showName, $height, $in_idAttr, $content, $hidden_content, "", $in_constructor_function);
            
            
            
            //Metadaten des buttons auch in der Session ablegen, damit sie beim nächsten Maskenaufruf zur Verfügung stehen.
            $in_pagedata->setFormPropertyButton($buttonname, 
                                                $in_field->id, 
                                                $in_field->name,
                                                $in_field->app_id, 
                                                $function_id, 
                                                $in_field->button_action_function_app_id, 
                                                $in_field->button_target, 
                                                $in_field->button_form_mode, 
                                                $in_form_id, 
                                                $in_instance_id,
                                                $in_field->button_target_form,
                                                $in_field->spalte,
                                                $in_field->vorgabewert);
            
            
            return $localFeedback;
        }
        
        
        
        
        /** Erstellt einen eindeutigen Buttonname für das HTML-DOM
         * 
         * @param   string  $in_type        Typ des Buttons [login|logout|default]
         * @param   integer $in_field_id    ID des Buttons (feld.id)
         * @param   string  $in_nameAttr    NameAttribut von getField (Bsp.: 0000Form21_1_i0)
         * @return  string                  Eindeutiger Buttonname <br />
         *                                  Bsp.: button__id366_0000Form21_1_i0 <br />
         *                                          button__id  => Präfix für Default-Button <br />
         *                                          366         => feld.id <br />
         *                                          0000        => Trennzeichen zwischen denen schema, Table und Collumn übertragen werden können <br />
         *                                          Form21      => Formular-ID
         *                                          1           => Zeile im Formular
         *                                          i0          => Instanz
         * 
         */
        function buildButtonname($in_type, $in_field_id, $in_nameAttr) {
            //ACHTUNG: Wenn Änderungen an der Syntax vorgenommen werden, 
            //dann muss auch die Funktionsfähigkeit der 
            //Funktionen 
            //  - getFormidFromButtonname 
            //  - getInstanceIdFromFieldName und
            //  - buildInternPostArray
            //sichergestellt werden.
            
            if      ($in_type == "login")   {$präfix = "button__submit_login_id";}
            elseif  ($in_type == "logout")  {$präfix = "button__submit_logout_id";}
            elseif  ($in_type == "default") {$präfix = "button__id";}
            
            
            //0 durch o ersetzen, da 0 ein Trennzeichen innerhalb von $in_nameAttr ist
            $button_name = $präfix.str_replace("0","o",$in_field_id)."_".$in_nameAttr;
            //. durch -- ersetzen, da . per Post nicht übertragen wird. Es würde ein Unterstrich gesetzt werden, der dann jedoch 
            //in pagedata.getInstanceIdFromFieldName falsch interpretiert werden würde.
            $button_name = str_replace(".","--",$button_name);
            
            return $button_name;
        }
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "submit" den HTML-Code. Der Login-Button wird stets mit dem Attribut disabled erzeugt.
         * Die Eigenschaft muss dann per Javascript entfernt werden, wenn alle Voraussetzungen erfüllt sind.
         * 
         * @param   object  $in_field       Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr    Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr      Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   string  $in_mask_link   siehe Tabelle mask (Bsp.: page.php)
         * @param   string  $in_mask_app    siehe Tabelle mask (Bsp.: SYS01)
         * @param   object  $in_pagedata    pagedata-object
         * @param   integer $in_form_id     ID des Formulars (nicht der Symbolleiste)
         * @param   string  $in_instance_id ID der Instanz des Formulars
         * @return  string                  HTML-Code eines Formularfeldes
         */
        function _getFieldLoginbutton($in_field, $in_nameAttr, $in_idAttr, $in_mask_link, $in_mask_app, $in_pagedata, $in_form_id, $in_instance_id) {
            $content = "";
            $with_table = false; 
            $showName = 0;
            $height = "";
            $hidden_content = "";
            
            if($in_field->button_action_function_id == "") {
                //das ist notwendig, da sonst pagedata->call_function ein Fehlerfeedback gegeben wird.
                $function_id = 0;
            } else {$function_id = 
                $function_id = $in_field->button_action_function_id;
            }
             
            $formaction = $in_mask_link.
                    "?mask=".$in_field->button_target_mask.
                    "&maskapp=".$in_mask_app;

            
            //Prüfen, ob eine Umleitung vorliegt
            $redirect_array = session_class::$session_object->getRedirect();
            if($redirect_array !== false) {
                if($redirect_array["redirect_handled"] == 0) {
                    $formaction = $redirect_array["request_uri"];
                    session_class::$session_object->setRedirectDone();
                    
                } 
            } 
            
            
            if(strpos($in_field->vorgabewert ?? "", "url(") !== false) {
                $style_add = ";background-image:".$in_field->vorgabewert.";padding-left:"."25px".";padding-right:0px;";
            } else {
                $style_add = "";
            }
            
            
            $buttonname = buildButtonname("login", $in_field->id, $in_nameAttr);
            
            
            if ($in_field->button_paramname != "") {$addButtonParam = "&".$in_field->button_paramname."=$in_field->feldinhalt";} else {$addButtonParam = "";}
            //tab_id ergänzen
            $tab_id = session_class::$session_object->getTabId();
            if($tab_id != false) {$addButtonParam = $addButtonParam."&tab_id=".$tab_id;}
            
            $content = "<input 
                                    type=\"submit\" 
                                    disabled=\"disabled\" 
                                    name=\"".$buttonname."\" 
                                    formaction=\"".$formaction.$addButtonParam."\" 
                                    value=\"$in_field->name\" ".
                                    //"alt=\"$in_field->name\" ".               //alt-Attribut ist bei input in HTML-Standard nicht zulässig
                                    "style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";".$style_add."\" ".
                                    "title=\"$in_field->name (Feld-ID=$in_field->id)\" ".
                                    "onclick=\"$in_field->javascriptOnclick\" ".
                                    "onsubmit=\"$in_field->javascriptOnsubmit\" ".
                                    "id=\"".$in_idAttr."\" ".
                                    "data-feldappid=\"$in_field->app_id\" 
                                    data-formid=\"$in_field->form_id\" 
                                    data-feldid=\"$in_field->id\" 
                                    formmethod=\"post\" 
                                    class=\"button login_button ".$in_field->addClassCode." validate_formid_".$in_form_id."\">";
                                    
            
            $localFeedback = getCellContent($in_field, $showName, $height, $in_idAttr, $content, $hidden_content, "");
            
            
            //Metadaten des buttons auch in der Session ablegen, damit sie beim nächsten Maskenaufruf zur Verfügung stehen.
            $in_pagedata->setFormPropertyButton($buttonname, 
                                                $in_field->id, 
                                                $in_field->name, 
                                                $in_field->app_id, 
                                                $function_id, 
                                                $in_field->button_action_function_app_id, 
                                                $in_field->button_target, 
                                                $in_field->button_form_mode, 
                                                $in_form_id, 
                                                $in_instance_id,
                                                $in_field->button_target_form,
                                                $in_field->spalte,
                                                $in_field->vorgabewert);

            return $localFeedback;
        }   
        
        
        
        /** Erzeugt für ein Feldobjekt vom Typ "submit" den HTML-Code (hier-Logout-Button).
         * 
         * @param   object  $in_field       Objekt vom Typ HtmlField
         * @param   string  $in_nameAttr    Wert, der als Inhalt für as HTML-Attribut name gnutzt werden soll.
         * @param   string  $in_idAttr      Wert, der als Inhalt für as HTML-Attribut id gnutzt werden soll.
         * @param   string  $in_mask_link   siehe Tabelle mask (Bsp.: page.php)
         * @param   string  $in_mask_app    siehe Tabelle mask (Bsp.: SYS01)
         * @param   object  $in_pagedata    pagedata-Objekt
         * @param   integer $in_form_id     ID des Formulars (nicht der Symbolleiste)
         * @param   string  $in_instance_id ID der Instanz des Formulars
         * @return  string                  HTML-Code eines Formularfeldes
         */
        function _getFieldLogoutbutton($in_field, $in_nameAttr, $in_idAttr, $in_mask_link, $in_mask_app, $in_pagedata, $in_form_id, $in_instance_id) {
            $with_table = false; 
            $showName = 0;
            $height = "";
            $hidden_content = "";
            
            if($in_field->button_action_function_id == "") {
                //das ist notwendig, da sonst pagedata->call_function ein Fehlerfeedback gegeben wird.
                $function_id = 0;
            } else {
                $function_id = $in_field->button_action_function_id;
            }
            
            if(strpos($in_field->vorgabewert, "url(") !== false) {
                $style_add = ";background-image:".$in_field->vorgabewert.";padding-left:"."25px".";padding-right:0px;";
            } else {
                $style_add = "";
            }
            

            //Standardlogin-Maske ermitteln
            $mask_id = global_variables::getDefaultMaskId($in_mask_app, "login_mask");
            $mask_app_id = global_variables::getDefaultMaskAppId($in_mask_app, "login_mask");
            
                
            
            $formaction = $in_mask_link.
                    "?mask=".$mask_id.
                    "&maskapp=".$mask_app_id.
                    "&logout=true";
            
       
            $buttonname = buildButtonname("logout", $in_field->id, $in_nameAttr);
            
            if ($in_field->button_paramname != "") {$addButtonParam = "&".$in_field->button_paramname."=$in_field->feldinhalt";} else {$addButtonParam = "";}
            //tab_id ergänzen
            $tab_id = session_class::$session_object->getTabId();
            if($tab_id != false) {$addButtonParam = $addButtonParam."&tab_id=".$tab_id;}
            
            $content = "<input 
                                    type=\"submit\" 
                                    name=\"".$buttonname."\" 
                                    formaction=\"".$formaction.$addButtonParam."\" 
                                    value=\"$in_field->name\" 
                                    title=\"$in_field->name (Feld-ID=$in_field->id)\" ". 
                                    //"alt=\"$in_field->name\" ".               //alt-Attribut ist bei input in HTML-Standard nicht zulässig
                                    "style=\"width:".$in_field->laenge_content.$in_field->laenge_measureunit.";".$style_add."\" ".
                                    "onclick=\"$in_field->javascriptOnclick\" ".
                                    "onsubmit=\"$in_field->javascriptOnsubmit\" ".
                                    "id=\"".$in_idAttr."\" ".
                                    "data-feldappid=\"$in_field->app_id\" 
                                    data-feldid=\"$in_field->id\" 
                                    data-formid=\"$in_field->form_id\" 
                                    formmethod=\"post\" 
                                    class=\"button "."$in_field->addClassCode\">";
            
            $localFeedback = getCellContent($in_field, $showName, $height, $in_idAttr, $content, $hidden_content, "");
            
            
            //Metadaten des buttons auch in der Session ablegen, damit sie beim nächsten Maskenaufruf zur Verfügung stehen.
            $in_pagedata->setFormPropertyButton($buttonname, 
                                                $in_field->id,
                                                $in_field->name, 
                                                $in_field->app_id, 
                                                $function_id, 
                                                $in_field->button_action_function_app_id, 
                                                $in_field->button_target, 
                                                $in_field->button_form_mode, 
                                                $in_form_id, 
                                                $in_instance_id,
                                                $in_field->button_target_form,
                                                $in_field->spalte,
                                                $in_field->vorgabewert);
            
            
            return $localFeedback;
        }   
        
        
        
        
 
        
        
        
        /** Gibt das Formular zum wählen der aktiven Rolle in einem String zurück.
         * 
         * @param   Array   $in_roleList    Zweidimensionales Feld mit den Rollen, wie es in SESSION['rollen'] enthalten ist
         * @param   Integer $in_activeRole  ID der derzeit aktiven Rolle
         * @return  boolean
         */
        function getRolePicker($in_roleList, $in_activeRole) {			
			
            $feedback = $feedback. "\r\n<form action='/' method='post'>";                                                 //Formular als Rahmen aufbauen
                    
                $feedback = $feedback. "aktive Rolle:" ;
                $feedback = $feedback. "<select class=\"input_role\" name=\"input_role\" id=\"input_role\" onclick=\"$javascriptOnclick\" >";
                    for($x = 0; $x < count($in_roleList); $x++) {
                        If ($in_activeRole == $in_roleList[$x] ["role.id"]) {
                                $feedback = $feedback. "<option value=\"".$constlist[$x] ["role.id"]."\" selected>".$constlist[$x] ["role.name"]."</option>";  	//mit Feldwertvorbelegung
                        } 
                        else {
                                $feedback = $feedback. "<option value=\"".$constlist[$x] ["role.id"]."\">".$constlist[$x] ["role.name"]."</option>";                //ohne Feldvorbelegung
                        }
                    }		
		$feedback = $feedback. 	"</select>";
                $feedback = $feedback. "<input class=\"button_role_reload\" id=\"button_role_reload\" name=\"button_role_reload\" type=\"submit\" value=\"\">";
            $feedback = $feedback. "</form>";
		
		
		return $feedback;
	}
        
        
        
        
    
        
        
        /** Erstellt den HTML-Quellcode für eine Gruppe von Symbolen und Eingabefeldern (Symbolleiste). Eine Gruppe von Symbolen wird selbst auch zu einem Formular 
         * zusammengefasst (Tabelle form), jedoch nicht als html-Formular ausgegeben. Die Ausgabe erfolgt hingegen in einem div, welches in in einem übergeordneten 
         * Formular eingebettet wird.
         * 
         * @param array         $in_symbolForm              Formular (die Symbolgruppe), deren Symbole angezeigt werden sollen
         * @param Array         $in_pagedata                Objekt, siehe pagedata
         * @param String        $in_width                   Angabe der Breite mit Einheit, Bsp.: 2000px (css-Style) (wenn unbekannt, dann "auto" angeben)
         * @param Integer       $in_form_id                 ID des Formulars, in dem die Symbolleiste aktuell angedruckt werden soll (wenn unbekannt, dann  "0" angeben)
         * @param Integer       $in_form_modus_input        Gibt den Modus des Formulars an, in welchem es aufgerufen werden soll, siehe DB-Tabelle form_mode (wenn unbekannt, dann 1 angeben)
         * @param string        $in_form_app_id             APP des Formulars, in dem die Symbolleiste aktuell angedruckt werden soll (wenn unbekannt, dann "SYS01" angeben)
         * @param integer       $in_currentFormInstanceId   ID der aktuellen Instanz des Formulars.
         * @return String
         */
	function getSymbolGroup($in_symbolForm, &$in_pagedata, $in_width, $in_form_id, $in_form_modus_input, $in_form_app_id, $in_currentFormInstanceId) {			
		
            $feedback = "";
            $form = $in_pagedata->getFormArray($in_form_id);
            //Ermittelt die Fieldlist für Symbolleiste
            $fieldlist = getFieldList($in_symbolForm["form.id"], $in_symbolForm["form.app_id"], "feld.sort", $in_form_modus_input, $in_form_app_id, $in_form_id);
            
            
            
            //Wenn in den Feldern die Werte von internen Variablen angedruckt werden sollen, werden diese als Vorgabewert in die Fieldlist übertragen.
            //Dabei werden interneVariablen, die sich aus einem Formular ergeben, aus dem Formular gezogen, welches die Symbolleiste enthalten wird. Gesteuert wird das über $in_form_id.
            //Wenn die form_id "0" ist (bspw. durch Aufruf von getSymbolGroupForAllModi), dann entfällt dieser Schritt
            if ($in_form_id !== 0) {$fieldlist = replaceInternVariables($in_pagedata, $in_form_id, $in_currentFormInstanceId, $fieldlist);}
            //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> fieldlist der Symbolleiste: ', $fieldlist);
            
            $feedback = $feedback."<div id=\"symbolgroup".$in_symbolForm["form.id"]."_".$in_form_id."_".$in_currentFormInstanceId."\" role=\"none\" class=\"symbolgroup\"> \r\n";	
		
                //echo 'Feldliste: '.print_r($fieldlist).'<br>';
                $feedback = $feedback."<div id=\"symbolgroup_".$in_symbolForm["form.id"]."_".$in_form_id."_".$in_currentFormInstanceId."\" role=\"none\"> \r\n";
                    $addID = "Form".$in_form_id."_1_".$in_currentFormInstanceId;
                    //Ermittlung des HTML-Quellcode für die Felder der Fieldlist (Symbolleiste). Buttons beziehen sich allerdings auf das Formular, welches die Symbolleiste enthält
                    $feedback = $feedback.getFieldsOfRow($fieldlist, 1, $addID, $in_pagedata, $in_currentFormInstanceId, "" ,"", FALSE, "0", TRUE, FALSE, $in_pagedata->getMaskArray(), $form, FALSE, __FUNCTION__, false);                                    
                $feedback = $feedback."</div> \r\n";
				
			
            $feedback = $feedback."</div> \r\n";
		
            return $feedback;
	}
        
        
        
        
        
 
        
        /** Erstellt den HTML-Quellcode für den Andruck der Felder und Daten in Tabellenform
         * 
         * @param integer   $in_form_id                     ID des Formulars
         * @param string    $in_currentFormInstanceId       ID der aktuellen Instance des Formulars
         * @param array     $in_pagedata                    Object, siehe pagedata
         * @param string    $in_css_constructor_class       Name der CSS-Klasse, welche den Html-Elementen zusätzlich mitgegeben werden soll.
         * @param string    $in_table_type                  Type der aufzubauenden Tabelle; mögliche Werte: "simpleTable" -> komfortabel zu bedienen, aber keine Datenerfassung; "appmsTable" -> voller Funktionsumfang, aber weniger komfortabel für Anwender
         * @param boolean   $in_deactivateSecurityCondition Gibt an, ob die Security-Conditions beim ermitteln der Inhaltsdaten deaktiviert werden sollen.
         * @return string                               HTML-Code des Formulars
         */
	function getFormTableData($in_form_id, $in_currentFormInstanceId, &$in_pagedata, $in_css_constructor_class, $in_table_type, $in_deactivateSecurityCondition) {			
            
            $form               = $in_pagedata->getFormArray($in_form_id);
            $countData          = $in_pagedata->calculateFormCountData($form['form.id'], $in_currentFormInstanceId, $in_pagedata->getFormPropertyOffset($form['form.id'], $in_currentFormInstanceId), true );  //ToDo kann auch die Eigenschaft ["form.countData"] aus forms genutzt werden? -> Nein funktioniert nicht bei abhängigen Formularen
            $bedingung          = $in_pagedata->buildFormPropertyConditionComplete($form['form.id'], $in_currentFormInstanceId);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> form_condition: ', $bedingung);
            
           
            $feedback = "";
            
            
            //Detail-Tag, falls gewünscht.
            $feedback = $feedback.getDetailsContainer("start",$form, $in_currentFormInstanceId, $countData);
                
            
                //Kopfbereich des Formulars
                $feedback = $feedback._getFormHead($form);


                //Symbolleisten, oben
                $feedback = $feedback.$in_pagedata->getSymbolgroupHtml(1, $form, $in_currentFormInstanceId);


                $feedback = $feedback. "<div class=\"tablerahmen tablerahmen_".$in_css_constructor_class."\" role=\"none\">\r\n";

                    $fieldlist = getFieldList($in_form_id, $form["form.app_id"], "feld.sort");					//Felder des gewünschten views ermitteln
                    if($fieldlist !=array()) {
                        //Wenn die Felderliste nicht leer ist.
                        //Anzuzeigende Daten ermitteln
                        if($in_pagedata->getFormPropertyShowData($in_form_id, $in_currentFormInstanceId) == true) {



                            $connection_id = $form["form.connection_id"];

                            //Die Daten unter Beachtung des Parameters rows_in_form abfragen

                            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Fieldlist von Form '.$in_form_id, $fieldlist);


                            $data = getTableData2($connection_id, $form['form.db_table'], $form['form.db_schema'], $fieldlist, $in_deactivateSecurityCondition, $form['form.order_by'], $bedingung, __FUNCTION__." Zeile: ".__LINE__, $form["form.limit"], $in_pagedata->getFormPropertyOffset($in_form_id, $in_currentFormInstanceId));            //Inhaltsdaten ermitteln, falls vorhanden
                            $countData = count($data);
    //                        $data = getTableData($connection_id, $form['form.db_table'], $form['form.db_schema'], false, $form['form.order_by'], $bedingung, __FUNCTION__." Zeile: ".__LINE__, $form["form.limit"], $in_pagedata->getFormPropertyOffset($in_form_id, $in_currentFormInstanceId));            //Inhaltsdaten ermitteln, falls vorhanden

                            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Daten des Formulars '.$in_form_id, $data);
                            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> is_nested: '.$form["form.is_nested_form"].', countdata: '.$countData.', form: ', $form);

                            if($countData == 0) {
                                //ToDo: Kann das nach pagedata übertragen werden? Beachte nestedForms!
                                //Wenn keine Daten gefunden wurden wird der Formularmodus auf empty gesetzt. Anschließend werden alle Formularattribute neu geladen
                                $in_pagedata->setFormMode($in_form_id, $in_currentFormInstanceId, "5");         //5 = empty
                                $form = $in_pagedata->getFormArray($in_form_id);     //Formular neuladen, um aktuelle Eigenschaften zu übernehmen
                                //$data[] = $in_pagedata->getFormProbertyDefaultValueForInsert($in_form_id, $in_currentFormInstanceId);
                                $data = array();
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Keine Daten gefunden für Form: '.$in_form_id.', daher form_modus = 5.', "empty");
                                //Die Anzeige von allen abhängigen Formularen (also nachgeordneten) wird unterdrückt
                                $in_pagedata->setFormPropertyHide($form["form_dependence.target_forms"], $form["form.id"]);
                            } else {
                                //Formularmodus der abhängigen Formulare auf den gleichen Wert setzen, wie der Modus des aktuellen Formulars (Trigger-Formular)
    //                            $temp_form_mode = $in_pagedata->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId);
    //                            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Setze Form_mode für abhängige Formulare: ', $temp_form_mode);
    //                            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> abhängige Formulare: ', $form["form_dependence.target_forms"]);
    //                            $in_pagedata->setFormModeForGivingFormList($form["form_dependence.target_forms"], $in_pagedata->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId));
                            }

                        } else {

                            $data = array();

                            if ($in_pagedata->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId) == 2) {
                                //form_mode = 2 -> insert
                                
                                //$data[] = $in_pagedata->getFormPropertyDefaultValueForInsert($form["form_dependence.trigger_form_id"], $in_form_id, $in_currentFormInstanceId, true, $form["form.is_nested_form"]);
                                $data = getDefaultInsertLines($in_pagedata, $form, $in_currentFormInstanceId, true);
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Form-Modus = insert für Form: '.$in_form_id.', daher defaultdata gesetzt.', $data);
                            } else {
                                //Die Anzeige von allen abhängigen Formularen (also nachgeordneten) wird unterdrückt, wenn form_mode <> insert und countdata == 0
                                $in_pagedata->setFormPropertyHide($form["form_dependence.target_forms"]);
                            }
                        }

                        if($form["form.show_markfield"] == 1) {$hide_markfield = false;} else {$hide_markfield = true;}
                        if($in_table_type == "appmsTable") { 
                            $feedback = $feedback.$in_pagedata->getFormHtmlStructure($in_form_id, $in_currentFormInstanceId, true, "table", $fieldlist, $data, true, $hide_markfield, $in_css_constructor_class);
                        } elseif($in_table_type == "simpleTable") {
                            $myTable = buildHtmlTableHorizontalQuery($data);
                            $feedback = $feedback.$myTable;
                            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> jQueryDataTable: ', $myTable);
                        }

                    } else {
                        //Wenn die Felderliste leer ist
                        $feedback = $feedback. "<div class=\"no_fields_found\">". getConfig("note_if_no_field_in_form", $form["form.app_id"])."</div>\r\n";
                    }




                $feedback = $feedback. "</div> <!-- End: tablerahmen --> \r\n"; 


                //Symbolleisten, unten
                $feedback = $feedback.$in_pagedata->getSymbolgroupHtml(2, $form, $in_currentFormInstanceId);

    //            $feedback = $feedback."<div class=\"zeilenumbruch\"></div>\r\n";    //Abschließender Zeilenumbruch am ende eines jeden Formulars
            
                
                
            //Detail-Tag schließen
            $feedback = $feedback.getDetailsContainer("end",$form, $in_currentFormInstanceId, $countData);

            //Fieldlist in pagedata ablegen, damit sie in die Session übergeben und somit bei späteren Aufrufen (per js) verfügbar ist.
            $in_pagedata->setFormPropertyDefaultFieldlist($in_form_id, $fieldlist);
                
            return $feedback;
	}        
        
        
        /** Ermittelt über das Triggerformular aus dem FormArray die DefaultdatenForInsert und überträgt diese, entsprechnd der Anzahl der Eigenschaft
         * form.multiline_insert in eine Array
        * 
        * @param  object    $in_pagedata            Referenz auf das Pagedata-Object
        * @param  array     $in_form_array           Arry des aktuellen Formulares       
        * @param  string    $in_instance_id         ID der aktuellen Instanz
        * @param  bool      $in_with_tablename      Gibt an, ob bei der Rückgbae der key die Syntax tablename.columnname oder nur columnname hat
        * @return array                             Bsp.:
        *                                               Array <br>
                                                            ( <br>
        *                                                       [0] = >Array  <br>
        *                                                           (  <br>
        *                                                               [auto.name] => "Mercedes", <br>
        *                                                               [auto.type] => "Coupe" <br>
        *                                                           ) <br>
        *                                                       [1] = >Array <br>
        *                                                           (  <br>
        *                                                               [auto.name] => "Oprel", <br>
        *                                                               [auto.type] => "Omega" <br>
        *                                                           ) <br>
        *                                                   )<br>
        */
        function getDefaultInsertLines($in_pagedata, $in_form_array, $in_instance_id, $in_with_tablename) {
            $feedback = array();
            $countlines = $in_form_array["form.multiline_insert"];
            if ($countlines < 2 or is_null($countlines)) {$countlines = 1;} 
            
            for($i = 1; $i <= $countlines; $i++) {
                $feedback[] = $in_pagedata->getFormPropertyDefaultValueForInsert($in_form_array["form_dependence.trigger_form_id"], $in_form_array["form.id"], $in_instance_id, $in_with_tablename, $in_form_array["form.is_nested_form"]);
            }
            return $feedback;
            
        }
        
        
        
        
        /** Gibt den Html-Code für ein details-tag zurück.
         * 
         * @param   string  $start_or_end       Wenn "start", dann wird das öffnende details-tag generiert.
         * @param   array   $in_form            Array des aktuellen Formulars    
         * @param   string  $in_instance        aktuelle Instanz des Formulars
         * @param   integer $in_countData       Anzahl der Datensätze im Details-Container.
         * @return  string                      html-code für en details-tag
         */
        function getDetailsContainer($start_or_end, $in_form, $in_instance, $in_countData) {
            
            $feedback = "";
            
            if(substr($in_instance, -3) != "new") {
                if(in_array($in_form["form.relationtyp"],array(11,21))) {
                    if($start_or_end == "start") {
                        $feedback = "<details><summary>".$in_form["form.name"]."(".$in_countData.")</summary>\r\n";
                    } else {
                        $feedback = "</details>";
                    }
                } elseif(in_array($in_form["form.relationtyp"],array(12,22))) {
                    if($start_or_end == "start") {
                        $feedback = "<details open=\"open\"><summary>".$in_form["form.name"]."(".$in_countData.")</summary>\r\n";
                    } else {
                        $feedback = "</details>";
                    }
                }
            }
            
            
            return $feedback;
        }
        
        
        
        
        
        
        /** Erstellt den HTML-Quellcode für den Andruck der Felder und Daten für SingleData-Formular. Dabei befinden sich Überschriften 
         * und Hilfetexte dierekt an jedem Feld
         * 
         * @param integer   $in_form_id                     ID des Formulars
         * @param integer   $in_currentFormInstanceId       ID der aktuellen Instanz des Formulars
         * @param Array     $in_pagedata                    Object, siehe pagedata
         * @param string    $in_css_constructor_class       Name der CSS-Klasse, welche den Html-Elementen zusätzlich mitgegeben werden soll.
         * @param boolean   $in_deactivateSecurityCondition Gibt an, ob die Security-Conditions beim ermitteln der Inhaltsdaten deaktiviert werden sollen.
         * @param boolean   $in_showMoreThanOneDS           Gibt an, dass mehr als ein Datensatz angezeigt werden soll.
         * @return String                                   HTML-Code des Formulars
         */
        function getFormSingleData($in_form_id, $in_currentFormInstanceId, &$in_pagedata, $in_css_constructor_class, $in_deactivateSecurityCondition, $in_showMoreThanOneDS) {			
            
            $form               = $in_pagedata->getFormArray($in_form_id);
            $bedingung          = $in_pagedata->buildFormPropertyConditionComplete($form['form.id'], $in_currentFormInstanceId);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> form_condition: ', $bedingung);
            
            
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Aufruf SingleData mit form: '.$form["form.id"], $form);
            $feedback = "";
            
            
            //Detail-Tag, falls gewünscht.
            $feedback = $feedback.getDetailsContainer("start",$form, $in_currentFormInstanceId, 1);
              
                //Kopfbereich des Formulars
                $feedback = $feedback._getFormHead($form);



                //Symbolleisten, oben
                $feedback = $feedback.$in_pagedata->getSymbolgroupHtml(1, $form, $in_currentFormInstanceId);

                $feedback = $feedback. "<div class=\"tablerahmen tablerahmen_".$in_css_constructor_class."\" role=\"none\">\r\n";

                        $fieldlist = getFieldList($in_form_id, $form['form.app_id'], "feld.sort");					//Felder des gewünschten views ermitteln
                        if($fieldlist !=array()) {
                            //Wenn die Felderliste nicht leer ist.

                            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> showData ', $in_pagedata->getFormPropertyShowData($in_form_id, $in_currentFormInstanceId));
                            //Anzuzeigende Daten ermitteln
                            if ($in_pagedata->getFormPropertyShowData($in_form_id, $in_currentFormInstanceId) == true) {
                                //Die anzuzeigenden Daten abfragen. Es kann in dieser Funktion nur ein Datensatz verarbeitet werden. 
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Inhaltsdaten ermitteln ', "");



                                $connection_id = $in_pagedata->getFormPropertyConnectionId($in_form_id);



                                If ($form['form.db_table'] == "form" AND $form['form.constructor'] == "SingleData") {
                                    //hohe Wahrscheinlichkeit, dass ein reines WYSIWYG-Formular vorliegt. Diese dienen i.d.R. zur Anwenderinformation und sollen auch 
                                    // dann angezeigt werden, wenn die aktive Rolle nicht zugreifen darf. Der schreibende Zugriff kann stattdessen über role_has_form_group
                                    //unterdrückt werden.
                                    $deactivateSecurity = true;
                                } elseif ($in_deactivateSecurityCondition === true) {
                                    $deactivateSecurity = true;                            
                                } else {$deactivateSecurity = false;}

                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Vorgabe deactivateSecurityCondition= '.$in_deactivateSecurityCondition, "daher deactivateSecurity=".$deactivateSecurity);


                                if($in_showMoreThanOneDS === false) {
                                    //Inhaltsdaten des Formulars ermitteln -> es wird nur genau ein Datensatz abgefragt 
                                    $limit = 1;
                                } else {
                                    $limit = 0;     //kein Limit
                                }
                                $data = getTableData($connection_id, $form['form.db_table'], $form['form.db_schema'], $deactivateSecurity, $form['form.order_by'], $bedingung, __FUNCTION__." Zeile: ".__LINE__, $limit, 0);            //Inhaltsdaten ermitteln, falls vorhanden
                                if($data <> false) {$countData = count($data);} else {$countData = 0;}
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> is_nested: '.$form["form.is_nested_form"].', countdata: '.$countData.', form: ', $form);
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Daten des Formulars '.$in_form_id, $data);



                                if($countData == 0) {
                                    //Wenn keine Daten gefunden wurden wird der Formulrmodus auf empty gesetzt. Anschließend werden alle Formularattribute neu geladen
                                    $in_pagedata->setFormMode($in_form_id, $in_currentFormInstanceId, "5");         //5 = empty
                                    $form = $in_pagedata->getFormArray($in_form_id);     //Formular neuladen, um aktuelle Eigenschaften zu übernehmen
                                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Formularmodus auf 5 (empty) gesetzt, da keine Daten vorhanden; Form: '.$form['form.id'], $form);
                                    //Die Anzeige von allen abhängigen Formularen (also nachgeordneten) wird unterdrückt
                                    $in_pagedata->setFormPropertyHide($form["form_dependence.target_forms"]);
                                } else {
                                    //Formularmodus der abhängigen Formulare auf den gleichen Wert setzen, wie der Modus des aktuellen Formulars (Trigger-Formular)
                                    setConditionInDependingForms($in_pagedata, $in_form_id, $in_currentFormInstanceId, $data);
                                }
                            } else {

                                $data = array();


                                if ($in_pagedata->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId) == 2) {
                                    //form_mode = 2 -> insert

                                    $data[] = $in_pagedata->getFormPropertyDefaultValueForInsert($form["form_dependence.trigger_form_id"], $form['form.id'], $in_currentFormInstanceId, true, $form["form.is_nested_form"]);
                                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Dummy-Daten für abhängiges Formular ('.$form['form.id'].') ', $data);

                                } else {
                                    //Die Anzeige von allen abhängigen Formularen (also nachgeordneten) wird unterdrückt, wenn form_mode <> insert und countdata == 0
                                    $in_pagedata->setFormPropertyHide($form["form_dependence.target_forms"]);
                                }
                            }
                            
                            
                            if($in_showMoreThanOneDS === true) {
                                //constructor Singledata wird für mehr als einen Datensatz verwendet.
                                $show_markfield = $in_pagedata->getFormPropertySetMarkField($in_form_id, $in_currentFormInstanceId);
                                if($show_markfield == true) {$hide_markfield = false;} else {$hide_markfield = true;}
                                
//                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> MarkFieldOrder für Form_id('.$form['form.id'].') ', $hide_markfield);

                            } else {
                                $hide_markfield = false;
                            }
                            $feedback = $feedback.$in_pagedata->getFormHtmlStructure($in_form_id, $in_currentFormInstanceId, false, "table", $fieldlist, $data, true, $hide_markfield, $in_css_constructor_class);


                        } else {
                            //Wenn die Flederliste leer ist
                            $feedback = $feedback. "<div class=\"no_fields_found\">". getConfig("note_if_no_field_in_form", $form["form.app_id"])."</div>\r\n";
                        }



                $feedback = $feedback. "</div> <!-- End: tablerahmen --> \r\n"; 


                //Symbolleisten, unten
                $feedback = $feedback.$in_pagedata->getSymbolgroupHtml(2, $form, $in_currentFormInstanceId);

    //            $feedback = $feedback."<div class=\"zeilenumbruch\"></div>\r\n";    //Abschließender Zeilenumbruch am ende eines jeden Formulars
                
            
                
            //Detail-Tag schließen
            $feedback = $feedback.getDetailsContainer("end",$form, $in_currentFormInstanceId, 1);
            
            
            
            //Fieldlist in pagedata ablegen, damit sie in die Seesion übergeben und somit bei späteren Aufrufen (per js) verfügbar ist.
            $in_pagedata->setFormPropertyDefaultFieldlist($in_form_id, $fieldlist);
            
            return $feedback;
	}        
        
        
        

        
        
        
        
        
        
        
        /** Ruft den jeweils benötigten FormConstructor auf und gibt den Html-Code für das Formular zurück.
         * FormForInternVariables wird bereits in htmlTag abgefangen.
         * 
         * @param   object      $in_pagedata                Objekt vom Typ pagedata
         * @param   integer     $in_form_id                 ID des aktuellen Formulars
         * @param   string      $in_currentFormInstanceId   Aktuelle Instance des Formulars. Bei eingebetteten Formularen ist es möglich, dass das gleiche Formular mehrfach verwendet wird
         * @param   array       $in_addConditionsFromParent [optional| nur für Constructor TableForQuery] falls es sich um ein ChildFormular handelt, können hier WerteBedingungen des übergeordneten Formulars 
         *                                                  übergeben werden die in der Where-Bedingung zur Ermittlung der Daten in diesem Formular genutzt werden. 
         *                                                  Die Syntax wird bspw. durch getConditionForNestedForms erstellt. [default = array()]
         * @return  string                                  HTML-Source-Code für das Formular
         */
        function getForm(&$in_pagedata, $in_form_id, $in_currentFormInstanceId, $in_addConditionsFromParent = array()) {
            
            //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> in_form_id ', $in_form_id, "INFO");
            //echo "form_id: ".$in_current_formid."<br />";
            $currentFormArray = $in_pagedata->getFormArray($in_form_id);
            
            
            //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Check deactivate SecurityCondition ', "activeRole = ".$in_pagedata->getActiveRoleIdFromSession().", activeRoleApp=".$in_pagedata->getActiveRoleAppIdFromSession().", activeUser=".$in_pagedata->getActiveUser(), "INFO");
            if($in_pagedata->getActiveRoleIdFromSession() == global_variables::getAppManagerRoleId()
                    AND $in_pagedata->getActiveRoleAppIdFromSession() == global_variables::getAppIdFromSYS01()
                    AND isUserRoot($in_pagedata->getActiveUser()) == true
                    AND $in_pagedata->getCurrentUserAppFromSession() == global_variables::getAppIdFromSYS01()) {
                //Wenn der aktuelle User sys01root ist und die verwendete Rolle "APP-Manager" ist, dann werden die Security-Conditions der Formulare
                //deaktiviert. Domit kann in dieser Rolle mit diesem Nutzer anwendungsübergreifend gearbeitet werden.
                $deactivateSecurityCondition = true;
            } else {
                $deactivateSecurityCondition = false;
            }
            
            
            
            
            
            if(isset($currentFormArray["form.hide_me"]) AND $currentFormArray["form.hide_me"] == true) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> form hide ', $currentFormArray, "INFO");
                //Diesem Formular nachgeordnete Formulare (abhängige Formulare) ebenfalls ausblenden
                $in_pagedata->setFormPropertyHide($currentFormArray["form_dependence.target_forms"]);
                $htmlQuellCode = "";
            } else {
                if($currentFormArray["form.constructor"]        =="TableData") {
                    $htmlQuellCode= getFormTableData(           $in_form_id, $in_currentFormInstanceId, $in_pagedata, "table_constructor", "appmsTable", $deactivateSecurityCondition);
                } elseif($currentFormArray["form.constructor"]  =="SingleData") {
                    $htmlQuellCode= getFormSingleData(          $in_form_id, $in_currentFormInstanceId, $in_pagedata, "single_constructor", $deactivateSecurityCondition, false);
                } elseif($currentFormArray["form.constructor"]  =="getFormTableForQuery") {
                    $htmlQuellCode= getFormTableForQuery(       $in_form_id, $in_currentFormInstanceId, $in_pagedata, "query_constructor", true, $deactivateSecurityCondition, $in_addConditionsFromParent);
                } elseif($currentFormArray["form.constructor"]  =="getFormInternVariables") {
                    $htmlQuellCode= getFormForInternVariables(  $in_form_id, $in_currentFormInstanceId, $in_pagedata, "variables_constructor");
                } elseif($currentFormArray["form.constructor"]  =="RectanglesForQuery") {
                    $htmlQuellCode= getFormTableForQuery(       $in_form_id, $in_currentFormInstanceId, $in_pagedata, "rectanglequery_constructor", true, $deactivateSecurityCondition, $in_addConditionsFromParent);
                } elseif($currentFormArray["form.constructor"]  =="RectanglesForTable") {
                    $htmlQuellCode= getFormTableData(           $in_form_id, $in_currentFormInstanceId, $in_pagedata, "rectangletable_constructor", "appmsTable", $deactivateSecurityCondition);
                } elseif($currentFormArray["form.constructor"]  =="simpleTable") {
                    $htmlQuellCode= getFormTableData(           $in_form_id, $in_currentFormInstanceId, $in_pagedata, "rectangletable_constructor", "simpleTable", $deactivateSecurityCondition);
                } elseif($currentFormArray["form.constructor"]  =="SingleDataQuery") {
                    $htmlQuellCode= getFormTableForQuery(       $in_form_id, $in_currentFormInstanceId, $in_pagedata, "single_constructor", false, $deactivateSecurityCondition, $in_addConditionsFromParent);
                } elseif($currentFormArray["form.constructor"]  =="dynamicSearch") {
                    $htmlQuellCode= getFormSingleData(          $in_form_id, $in_currentFormInstanceId, $in_pagedata, "single_constructor", $deactivateSecurityCondition, false);
                } elseif($currentFormArray["form.constructor"]  =="RectanglesForTable2") {
                    $htmlQuellCode= getFormSingleData(          $in_form_id, $in_currentFormInstanceId, $in_pagedata, "rectangletable_constructor", $deactivateSecurityCondition, true);
                } elseif($currentFormArray["form.constructor"]  =="explorerQuery") {
                    $htmlQuellCode= getFormExplorerQuery(       $in_form_id, $in_currentFormInstanceId, $in_pagedata, "query_constructor", true, $deactivateSecurityCondition, $in_addConditionsFromParent);
                }
              
                

                if (!isset($htmlQuellCode)) {addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Constructor für Form kann nicht behandelt werden ', $currentFormArray, "ERROR");}
            }
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> getForm beendet ', $in_form_id, "INFO");
            return $htmlQuellCode;
        }        
        
        
        
        /** Diese Funktion erstellt auf Basis eines Feld-Arrays ein Formular., welches nicht an Daten aus der Datenbank gebunden ist.
         * Felder, bei denen der Inhalt einer internen Variablen entsprechen soll, werden entsprechend ergänzt.
         * Theoretisch wäre es eleganter die Ersetzung auch über extern zu pflegende Funktionen (analog zu button_action_function) zu 
         * realisieren. Dies würde jedoch ein Sicherheitsrisiko darstellen, da dann auch auf SESSION zugegriffen werden könnte.
         * 
         * 
         * @param   integer $in_form_id                 ID des Formulars
         * @param   string  $in_instance_id             Instance des Formulars
         * @param   Object  $in_pagedata                Objekt, welches die internen Variablen enthält.
         * @param string    $in_css_constructor_class   Name der CSS-Klasse, welche den Html-Elementen zusätzlich mitgegeben werden soll.
         * @return  string                              HTML-Code des Formulars
         */
        function getFormForInternVariables($in_form_id, $in_instance_id, &$in_pagedata, $in_css_constructor_class) {			
            
            
            $form = $in_pagedata->getFormArray($in_form_id);
            
            
            $feedback = "";
            
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> formArray: ', $form);
            
  
            $feedback = $feedback. "\r\n<form id=\"form_".$in_form_id."_".$in_instance_id."\">\r\n";
                
                //Detail-Tag, falls gewünscht.
                $feedback = $feedback.getDetailsContainer("start",$form, $in_instance_id, 1);
            
            
                    //Kopfbereich des Formulars
                    $feedback = $feedback._getFormHead($form);


                    //Symbolleisten, oben
                    $feedback = $feedback.$in_pagedata->getSymbolgroupHtml(1, $form, $in_instance_id);


                    //Felder des aktuellen Formulars ermitteln
                    $fieldlist = getFieldList($in_form_id, $form['form.app_id'],  "feld.sort");					

                    if($fieldlist !=array()) {

                        //Wenn die Felderliste nicht leer ist.
                        $feedback = $feedback.$in_pagedata->getFormHtmlStructure($in_form_id, $in_instance_id, false, "noData", $fieldlist, array("dummy_data"), true, true, $in_css_constructor_class);                   

                    } else {
                        //Wenn die Felderliste leer ist
                        $feedback = $feedback. "<div class=\"no_fields_found\">". getConfig("note_if_no_field_in_form", $form["form.app_id"])."</div>\r\n";
                    }

                    //Symbolleisten, unten
                    $feedback = $feedback.$in_pagedata->getSymbolgroupHtml(2, $form, $in_instance_id);
                    
                //Detail-Tag schließen
                $feedback = $feedback.getDetailsContainer("end",$form, $in_instance_id, 1);


                
            $feedback = $feedback. "</form>\r\n";  //Ende formrahmen
            
            //Fieldlist in pagedata ablegen, damit sie in die Seesion übergeben und somit bei späteren Aufrufen (per js) verfügbar ist.
            $in_pagedata->setFormPropertyDefaultFieldlist($in_form_id, $fieldlist);
            
            
            return $feedback;
	}        
        
        
        
        
        
        /** Diese Funktion erstellt auf Basis einer Query ein Formular. Für jede Ergebnisspalten der Query, für die ein Feld in der Tabelle
         * feld angelegt wurde, erfolgt ein Andruck im Formular. 
         * 
         * @param array     $in_form_id                     ID des aktuellen Formulars
         * @param string    $in_currentFormInstanceId       ID der aktuellen Instance des Formulars
         * @param object    $in_pagedata                    das gesamte Pagedata-Objekt
         * @param string    $in_css_constructor_class       Name der CSS-Klasse, welche den Html-Elementen zusätzlich mitgegeben werden soll.
         * @param boolean   $in_buidTableStructure          Wenn true, dann wird eine Tabellenartige HTML-Struktur erstellt. False ist für Singledata gedacht; dabei sind auch Zeilenumbrüche möglich.
         * @param boolean   $in_deactivateSecurityCondition Gibt an, ob die Security-Conditions beim ermitteln der Inhaltsdaten deaktiviert werden sollen.
         * @param array     $in_addConditionsFromParent     [optional] falls es sich um ein ChildFormular handelt, können hier WerteBedingungen des übergeordneten Formulars 
         *                                                  übergeben werden die in der Where-Bedingung zur Ermittlung der Daten in diesem Formular genutzt werden. 
         *                                                  Die Syntax wird bspw. durch getConditionForNestedForms erstellt. [default = array()]
         * @return string                                   HTML-Code des Formulars
         */
        function getFormTableForQuery($in_form_id, $in_currentFormInstanceId, &$in_pagedata, $in_css_constructor_class, $in_buidTableStructure, $in_deactivateSecurityCondition, $in_addConditionsFromParent = array()) {			
            
            
            $form               = $in_pagedata->getFormArray($in_form_id);
            $countData          = $in_pagedata->calculateFormCountData($form['form.id'], $in_currentFormInstanceId, $in_pagedata->getFormPropertyOffset($form['form.id'], $in_currentFormInstanceId), true , $in_deactivateSecurityCondition);  //ToDo kann auch die Eigenschaft ["form.countData"] aus forms genutzt werden? -> nein funktioniert nicht bei anhängigen Formularen
            $bedingung          = $in_pagedata->buildFormPropertyConditionComplete($in_form_id, $in_currentFormInstanceId);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> form_condition: ', $bedingung);
            
            
            $feedback = "";
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> formArray: ', $form);
            
            //Detail-Tag, falls gewünscht.
            $feedback = $feedback.getDetailsContainer("start",$form, $in_currentFormInstanceId, $countData);
            
	
                //Kopfbereich des Formulars
                $feedback = $feedback._getFormHead($form);
            
                //Symbolleisten, oben
                $feedback = $feedback.$in_pagedata->getSymbolgroupHtml(1, $form, $in_currentFormInstanceId);
                
                $feedback = $feedback. "<div class=\"tablerahmen tablerahmen_".$in_css_constructor_class."\" role=\"none\">\r\n";
            
                    //Felder des aktuellen Formulars ermitteln
                    $fieldlist = getFieldList($in_form_id, $form['form.app_id'], "feld.sort");
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Fieldlist für Form: '.$in_form_id, $fieldlist, "INFO");
                    if($fieldlist !=array()) {
                        //Wenn die Felderliste nicht leer ist.
                        
                        if($in_pagedata->getFormPropertyShowData($in_form_id, $in_currentFormInstanceId) == true) {
                        //Daten der Query ermitteln
                            
                            
                            //Daten über Query ermitteln
                            $myQuery = new query();
                            $variablesContainerForQuery = $myQuery->buildvariableContainerForQuery(true, $in_pagedata, $in_form_id, $in_currentFormInstanceId, $in_addConditionsFromParent);
                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> vor initialize_1 (form_limit, Offset): ', $form["form.limit"].",".$in_pagedata->getFormPropertyOffset($in_form_id, $in_currentFormInstanceId));
                                
                            $myQuery->initialize_1($form["form.query_app_id"], $form["form.query_id"], false, $variablesContainerForQuery, $form, false, $form["form.limit"], $in_pagedata->getFormPropertyOffset($in_form_id, $in_currentFormInstanceId),$in_deactivateSecurityCondition);
                            $data = $myQuery->getQueryResultAsArray();
                            
                            //Wenn Constructor = SingleData, dann aktuellen Datensatz als Condition an abhängige Datensätze übergeben
                            if($form["form.constructor"]  =="SingleDataQuery") {
                                if(count($data) > 1) {$data = array_slice($data, 0, 1);}    //$data auf genau ein Element reduzieren
                                //Formularmodus der abhängigen Formulare auf den gleichen Wert setzen, wie der Modus des aktuellen Formulars (Trigger-Formular)
                                setConditionInDependingForms($in_pagedata, $in_form_id, $in_currentFormInstanceId, $data);
                            } 
                            
                            if(count($data) == 0) {
                                $in_pagedata->setFormMode($in_form_id, $in_currentFormInstanceId, "5");         //5 = empty
                                $form = $in_pagedata->getFormArray($in_form_id);     //Formular neuladen, um aktuelle Eigenschaften zu übernehmen
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Keine Daten gefunden für Form: '.$in_form_id.', daher form_modus = 5.', "empty");
                                //Die Anzeige von allen abhängigen Formularen (also nachgeordneten) wird unterdrückt
                                $in_pagedata->setFormPropertyHide($form["form_dependence.target_forms"]);
                            }
                            
                             
                            
                        } else {

                            $data = array();
                            
                            if ($in_pagedata->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId) == 2) {
                                //form_mode = 2 -> insert
                                $data[] = $in_pagedata->getFormPropertyDefaultValueForInsert($form["form_dependence.trigger_form_id"], $in_form_id, $in_currentFormInstanceId, true, $form["form.is_nested_form"]);
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Form-Modus = insert für Form: '.$in_form_id.', daher defaultdata gesetzt.', $data);
                            } else {
                                //Die Anzeige von allen abhängigen Formularen (also nachgeordneten) wird unterdrückt, wenn form_mode <> insert und countdata == 0
                                $in_pagedata->setFormPropertyHide($form["form_dependence.target_forms"]);
                            }

                        }
                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Daten des Formulars '.$in_form_id, $data);
                        
                        if($form["form.show_markfield"] == 1) {$hide_markfield = false;} else {$hide_markfield = true;}
                        $feedback = $feedback.$in_pagedata->getFormHtmlStructure($in_form_id, $in_currentFormInstanceId, $in_buidTableStructure, "query", $fieldlist, $data, true, $hide_markfield, $in_css_constructor_class);


                    } else {
                        //Wenn die Felderliste leer ist
                        $feedback = $feedback. "<div class=\"no_fields_found\">". getConfig("note_if_no_field_in_form", $form["form.app_id"])."</div>\r\n";
                    }
            
                $feedback = $feedback. "</div> <!-- End: tablerahmen --> \r\n"; 
                
                //Symbolleisten, unten
                $feedback = $feedback.$in_pagedata->getSymbolgroupHtml(2, $form, $in_currentFormInstanceId);
            
            //Detail-Tag schließen
            $feedback = $feedback.getDetailsContainer("end",$form, $in_currentFormInstanceId, $countData);

                
            //Fieldlist in pagedata ablegen, damit sie in die Seesion übergeben und somit bei späteren Aufrufen (per js) verfügbar ist.
            $in_pagedata->setFormPropertyDefaultFieldlist($in_form_id, $fieldlist);
            
            return $feedback;
	} 
        
        
        
        
        
        /** Diese Funktion erstellt auf Basis einer Query ein Formular. Für jede Ergebnisspalten der Query, für die ein Feld in der Tabelle
         * feld angelegt wurde, erfolgt ein Andruck im Formular. 
         * 
         * @param array     $in_form_id                     ID des aktuellen Formulars
         * @param string    $in_currentFormInstanceId       ID der aktuellen Instance des Formulars
         * @param object    $in_pagedata                    das gesamte Pagedata-Objekt
         * @param string    $in_css_constructor_class       Name der CSS-Klasse, welche den Html-Elementen zusätzlich mitgegeben werden soll.
         * @param boolean   $in_buidTableStructure          Wenn true, dann wird eine Tabellenartige HTML-Struktur erstellt. False ist für Singledata gedacht; dabei sind auch Zeilenumbrüche möglich.
         * @param boolean   $in_deactivateSecurityCondition Gibt an, ob die Security-Conditions beim ermitteln der Inhaltsdaten deaktiviert werden sollen.
         * @param array     $in_addConditionsFromParent     [optional] falls es sich um ein ChildFormular handelt, können hier WerteBedingungen des übergeordneten Formulars 
         *                                                  übergeben werden die in der Where-Bedingung zur Ermittlung der Daten in diesem Formular genutzt werden. 
         *                                                  Die Syntax wird bspw. durch getConditionForNestedForms erstellt. [default = array()]
         * @return string                                   HTML-Code des Formulars
         */
        function getFormExplorerQuery($in_form_id, $in_currentFormInstanceId, &$in_pagedata, $in_css_constructor_class, $in_buidTableStructure, $in_deactivateSecurityCondition, $in_addConditionsFromParent = array()) {			
            
            require_once("../controller/tree_class.php");
            
            $form               = $in_pagedata->getFormArray($in_form_id);
            $countData          = $in_pagedata->calculateFormCountData($form['form.id'], $in_currentFormInstanceId, $in_pagedata->getFormPropertyOffset($form['form.id'], $in_currentFormInstanceId), true , $in_deactivateSecurityCondition);  //ToDo kann auch die Eigenschaft ["form.countData"] aus forms genutzt werden? -> nein funktioniert nicht bei anhängigen Formularen
            $bedingung          = $in_pagedata->buildFormPropertyConditionComplete($in_form_id, $in_currentFormInstanceId);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> form_condition: ', $bedingung);
            
            
            $feedback = "";
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> formArray: ', $form);
            
            //Detail-Tag, falls gewünscht.
            $feedback = $feedback.getDetailsContainer("start",$form, $in_currentFormInstanceId, $countData);
            
	
                //Kopfbereich des Formulars
                $feedback = $feedback._getFormHead($form);
            
                //Symbolleisten, oben
                $feedback = $feedback.$in_pagedata->getSymbolgroupHtml(1, $form, $in_currentFormInstanceId);
                
                $feedback = $feedback. "<div class=\"tablerahmen tablerahmen_".$in_css_constructor_class."\" role=\"none\">\r\n";
            
                    //Felder des aktuellen Formulars ermitteln
//                    $fieldlist = getFieldList($in_form_id, $form['form.app_id'], "feld.sort");
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Fieldlist für Form: '.$in_form_id, $fieldlist, "INFO");
//                    if($fieldlist !=array()) {
                        //Wenn die Felderliste nicht leer ist.
                        
                        if($in_pagedata->getFormPropertyShowData($in_form_id, $in_currentFormInstanceId) == true) {
                        //Daten der Query ermitteln
                            
                            
                            //Daten über Query ermitteln
                            $myQuery = new query();
                            $variablesContainerForQuery = $myQuery->buildvariableContainerForQuery(true, $in_pagedata, $in_form_id, $in_currentFormInstanceId, $in_addConditionsFromParent);
                            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> vor initialize_1 (form_limit, Offset): ', $form["form.limit"].",".$in_pagedata->getFormPropertyOffset($in_form_id, $in_currentFormInstanceId));
                                
                            $myQuery->initialize_1($form["form.query_app_id"], $form["form.query_id"], false, $variablesContainerForQuery, $form, false, $form["form.limit"], $in_pagedata->getFormPropertyOffset($in_form_id, $in_currentFormInstanceId),$in_deactivateSecurityCondition);
                            $data = $myQuery->getQueryResultAsArray();
                            
                            
                            
                            if(count($data) == 0) {
                                $in_pagedata->setFormMode($in_form_id, $in_currentFormInstanceId, "5");         //5 = empty
                                $form = $in_pagedata->getFormArray($in_form_id);     //Formular neuladen, um aktuelle Eigenschaften zu übernehmen
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Keine Daten gefunden für Form: '.$in_form_id.', daher form_modus = 5.', "empty");
                                //Die Anzeige von allen abhängigen Formularen (also nachgeordneten) wird unterdrückt
                                $in_pagedata->setFormPropertyHide($form["form_dependence.target_forms"]);
                            }
                            
                             
                            
                        } else {

                            $data = array();
                            
                            if ($in_pagedata->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId) == 2) {
                                //form_mode = 2 -> insert
                                $data[] = $in_pagedata->getFormPropertyDefaultValueForInsert($form["form_dependence.trigger_form_id"], $in_form_id, $in_currentFormInstanceId, true, $form["form.is_nested_form"]);
                                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Form-Modus = insert für Form: '.$in_form_id.', daher defaultdata gesetzt.', $data);
                            } else {
                                //Die Anzeige von allen abhängigen Formularen (also nachgeordneten) wird unterdrückt, wenn form_mode <> insert und countdata == 0
                                $in_pagedata->setFormPropertyHide($form["form_dependence.target_forms"]);
                            }

                        }
                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Daten des Formulars '.$in_form_id, $data);
                        
                        if($form["form.show_markfield"] == 1) {$hide_markfield = false;} else {$hide_markfield = true;}
                        //$feedback = $feedback.$in_pagedata->getFormHtmlStructure($in_form_id, $in_currentFormInstanceId, $in_buidTableStructure, "query", $fieldlist, $data, true, $hide_markfield, $in_css_constructor_class." branch");
                        $my_tree = new tree($data, $form);
                        $feedback = $feedback.$my_tree->getTreeAsHtml();

//                    } else {
//                        //Wenn die Felderliste leer ist
//                        $feedback = $feedback. "<div class=\"no_fields_found\">". getConfig("note_if_no_field_in_form", $form["form.app_id"])."</div>\r\n";
//                    }
            
                $feedback = $feedback. "</div> <!-- End: tablerahmen --> \r\n"; 
                
                //Symbolleisten, unten
                $feedback = $feedback.$in_pagedata->getSymbolgroupHtml(2, $form, $in_currentFormInstanceId);
            
            //Detail-Tag schließen
            $feedback = $feedback.getDetailsContainer("end",$form, $in_currentFormInstanceId, $countData);

                
            //Fieldlist in pagedata ablegen, damit sie in die Seesion übergeben und somit bei späteren Aufrufen (per js) verfügbar ist.
//            $in_pagedata->setFormPropertyDefaultFieldlist($in_form_id, $fieldlist);
            
            return $feedback;
	} 
        
        
        
        
        /** Formularmodus auf den gleichen Wert, wie das aktuelle Formular setzen und zudem aktuellen Datensatz als Condition
         * für abhängige Formulare hinterlegen
         * Diese Funktion ist nur für Singledata-constructors gedacht. -> Die daraus resultierenden Conditions werden jedoch in 
         * alle Formulartypen übertragen
         * 
         * @param object    $in_pagedata                Referenz auf das zentrale pagedata-Objekt hinterlegen
         * @param integer   $in_form_id                 ID des aktuellen Formulars
         * @param string    $in_currentFormInstanceId   ID der aktuellen Formularinstanz
         * @param array     $in_data                    aktueller Datensatz
         */
        function setConditionInDependingForms(&$in_pagedata, $in_form_id, $in_currentFormInstanceId, $in_data) {
            //Formularmodus der abhängigen Formulare auf den gleichen Wert setzen, wie der Modus des aktuellen Formulars (Trigger-Formular)
            $temp_form_mode = $in_pagedata->getFormPropertyFormmode($in_form_id, $in_currentFormInstanceId);
            $form = $in_pagedata->getFormArray($in_form_id);
            $ignore_forms = $in_pagedata->form_list_with_fix_mode;
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Setze Form_mode für abhängige Formulare: ', $temp_form_mode);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> abhängige Formulare: ', $form["form_dependence.target_forms"]);
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> zu ignorierende Formulare: ', $ignore_forms);
            
            $in_pagedata->setFormModeForGivingFormList($form["form_dependence.target_forms"], $temp_form_mode, $ignore_forms);
            $in_pagedata->setFormPropertyConditionForDependingForms($in_form_id, $in_data);    //den aktuellen Datensatz verwenden, um Values (Conditions) für abhängige Formulare im form_array zu hinterlegen
            //Test
//            $in_pagedata->setFormModeForAllInstances(1696, 3);
        }
        
        
        
        /** Ermittelt die Ergebnisdaten einer Query, die außerhalb eines Formularkontextes aufgerufen wird.
         * Das ist bspw. für die Query-Vorschau im Query-Builder gedacht. 
         * 
         * @param   string  $in_query_app_id        
         * @param   integer $in_query_id
         * @return  string                      Query-Ergebnis in HTML-Syntax (tag = <table>)
         */
        function getFormTableForQueryWithoutForm($in_query_app_id, $in_query_id) {			
            
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> : ', "Starte getFormTableForQueryWithoutForm");
            //Todo: Wenn in der Formularvorschau auch die Formulaspezifischen Kriterien (query_criteria) beachtet werden sollen. Dann muss im folgenden Aufruf der 5. Paramter genutzt wrden. Das gewünschte Formular könnte vom Anwender erfragt werden.
            $myQuery = new query();
            $myQuery->initialize_1($in_query_app_id, $in_query_id, false, array(), array(), false);
            $data = $myQuery->getQueryResultAsArray();
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Daten für Query-Vorschau', $data);
            $feedback = buildHtmlTableHorizontalQuery($data);    
                
                
                
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Query-Feedback für Ajax-Response ', $feedback);
            return $feedback;
	} 
        
        
        
        
        
        
?>