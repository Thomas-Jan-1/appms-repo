<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

/**
 * Erstellt und verwaltet Zweige eines Tree's
 *
 * @author thomas
 */
class branch {
    
    /**
     * 
     * @var     string      eindeutige ID im DOM
     */
    private string $id;
    
    /**
     * 
     * @var     string      Wert/value des aktuellen Zweiges/Knoten
     */
    private string $value;
    
    /**
     * 
     * @var     string      Gibt die Sortierung bezogen auf das übergeordnete branch (node) an.
     */
    private string $sort;
    
    /**
     * 
     * @var     string      HTML-class, die dem inneren <a>-Tag als Attribut mitgegeben wird.
     */
    private string $iconClass;
    
    /**
     * 
     * @var     string      Link, welcher bei Klick auf den Zweig aufgerufen werden soll. Default = # (-> TOP der aktuellen Seite)
     */
    private string $link;
    
    /**
     * 
     * @var     array       Liste aller nachgeordneten branches/nodes
     */
    private array $childlist = array();
    
    /**
     * 
     * @var     string      ID des Parent-Objektes
     */
    private string  $parentId;
    
    /**
     * 
     * @var     array       Aktuelles Formular
     */
    private array   $formArray;
    
    /**
     * 
     * @var     string      Wird als Attribut data-level in a-tag eingebaut. Kann für CSS-Gestaltung verwendet werden.
     */
    private string  $level;
    
    /**
     * 
     * @var     string      wird im Attribut data-targetmask des a-tag abgelegt.
     */
    private string  $targetForm;
    
    /**
     * 
     * @var     string      (Condition 1) ID des Feldes, auf das eine Bedingung (Werteinschränkung) bei Abruf des Target-Formulars gesetzt werden soll.
     */
    private string  $cond1field;
    
    /**
     * 
     * @var     string      (Condition 1) Wert, auf den das target-Feld eingeschränkt werden soll.
     */
    private string  $cond1value;
    

    
    
    /** erstellt einen einzelnen Knoten eines Baumes
     * 
     * @param   string  $in_id          Eindeutige ID
     * @param   string  $in_value       wird als Name-Attribut verwendet
     * @param   string  $in_sort        Sortiermerkmal innerhalb eines Knotens
     * @param   string  $in_parent_id   ID des übergeordneten Objektes
     * @param   string  $in_formArray   Array des aktuellen Formulars 
     * @param   string  $in_link        [optional, default = #] Wird bei Klick auf das Element aufgerufen
     * @param   string  $in_iconClass   [optional, default = folder-icon] wird class-Attribut zum a-Tag-Attribut ergänzt
     * @param   string  $in_level       [optional, default = "1"] Wird als Attribut data-level in a-tag eingebaut. Kann für CSS-Gestaltung verwendet werden.
     * @param   string  $in_targetForm  [optional, default = "self"] wird im Attribut data-targetmask des a-tag abgelegt.
     * @param   string  $in_cond1field  [optional, default = ""] wird als Attribut data_cond1field des a-tag verwendet
     * @param   string  $in_cond1value  [optional, default = ""] wird als Attribut data_cond1value des a-tag verwendet
     * 
     */
    public function __construct($in_id, $in_value, $in_sort, $in_parent_id, $in_formArray, $in_link = "#", $in_iconClass = "folder-icon", $in_level="1", $in_targetForm="self", $in_cond1field = "", $in_cond1value="") {
        $this->id = $in_id;
        $this->value = $in_value;
        $this->sort = $in_sort;
        If(is_null($in_parent_id)) {$in_parent_id = "root";}
        $this->parentId = $in_parent_id;
        $this->link = $in_link;
        $this->iconClass = $in_iconClass;
        $this->formArray = $in_formArray;
        $this->level = $in_level;
        $this->targetForm = $in_targetForm;
        $this->cond1field=$in_cond1field;
        $this->cond1value=$in_cond1value;
        
    }
    
    
    /** Fügt ein Branch-Objekt als Child ein.
     * 
     * @param   obj     $in_branchObj       Objekt der Klasse branch
     */
    public function addChild($in_branchObj) {
        $this->childlist[$in_branchObj->getSortNr()] = $in_branchObj;
        
    }
    

    
    public function printHtml() {
        $feedback = "";
        
        
        $tz = "0";                  //Trennzeichen
        $form = $this->formArray;
        $id = str_replace("0", "o", $this->id);                                 //da 0 bereits das Trennzeichen ist, müssen alle Nullen durch ein kleines o ersetzt werden.
        $dom_id = $tz.$form["form.db_schema"].$tz.$form["form.db_table"].$tz.$id.$tz."Form".$form["form.id"]."_1_i0";
        if($this->cond1field != "" AND $this->cond1value != "") {
            $cond1 = ' data-cond1field="'.$this->cond1field.'" data-cond1value="'.$this->cond1value.'" ';
        } else {
            $cond1 = "";
        }
        
        //childs sortieren
        //$my_childs = reSortArrayByColumn($this->childlist, "sort");
        $my_childs = $this->childlist;
        if(count($my_childs)==0) {
            $countChilds = "";
            $addClass = "_empty";
        } else {
            $countChilds = " (".count($my_childs).")";
            $addClass = "_full";
        }
        
//        $feedback = $feedback.'<div class="branch"><a href="'.$this->link.'" class="'.$this->iconClass.$addClass.'">'.$this->value.$countChilds.'</a>';
        $feedback = $feedback.'<div class="branch">'.
                                '<a'.
                                    ' onclick="loadASingleForm(event)"'.
                                    ' class="'.$this->iconClass.$addClass.'"'.
                                    ' data-onlytargetform="1"'.
                                    ' data-level="'.$this->level.'"'.
                                    ' data-targetform="'.$this->targetForm.'"'.
                                    ' id="'.$dom_id.'" '.
                                    $cond1.
                                    '">'
                                    .$this->value.$countChilds.
                                '</a>';
            //alle childs ausgeben
            foreach ($my_childs as $key => $cur_child) {
                $feedback = $feedback.$cur_child->printHtml();
            }
        $feedback = $feedback.'</div>';
        
        return $feedback;
    }
    
    
    /**
     * 
     * @return  string      ID des übergeordneten Objektes
     */
    public function getParentId() {
        return $this->parentId;
    }
    
    
    /**
     * 
     * @return  string      ID des Objektes
     */
    public function getId() {
        return $this->id;
    }
    
    /**
     * 
     * @return  sort        Gibt das Sortiermerkmal zurück.
     */
    public function getSortNr() {
        return $this->sort;
    }
    
}
