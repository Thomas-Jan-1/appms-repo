<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

/**
 * Die Klasse stellt Methoden bereit, um eine neue Version/Release einer App zu erstellen.
 *
 * @author Thomas J.
 */
class version {
    
    /**
     *
     * @var     string      APP-ID 
     */
    public  $app_id;
    
    
    /**
     *
     * @var     array       Liste der SQL-Scripte, die ausgeführt werden müssen, bevor ein Update ausgeführt werden kann. 
     */
    public  $before_update_scripts = array();

    
    /**
     *
     * @var     array       Liste der SQL-Scripte, die ausgeführt werden müssen, bevor ein Update ausgeführt werden kann. 
     */
    public  $after_update_scripts = array();

    
    /**
     *
     * @var     string      eindeutige ID zur Kennzeichnung einer Version 
     */
    public $versionnumber;
    
    
    /**
     *
     * @var     string      Name der gepackten Versionsdatei 
     */
    public $versionFileName;
    
    
    /**
     * 
     * @var     string      Name der gepackten Wiki-Versionsdatei
     */
    private $versionWikiFileName;
    
    
    /**
     *
     * @var     string      relativer Pfad zum Speicherordner der Version, mit abschließenden Diretory-Separator. (Bsp.: version/SYS01/201811241234/)
     */
    public $targetPath_rel;
    
    
    /**
     *
     * @var     string      absoluter Pfad zum Speicherordner der Version, mit abschließenden Diretory-Separator. (Bsp: C:/Programme_eigene/xampp/htdocs/appms/version/SYS01/201811241234/)
     */
    public $targetPath_abs;
    
    
    /**
     *
     * @var     array       einfaches array, welches alle aktuell von appms unterstützen SQL-Languages enthält (Bsp.: array("myslq", "postgressql") 
     */
    public $sqlLanguages = array();
    
    
    /**
     *
     * @var     integer     Anzahl der SQL-Anweisungen in der Script_before_update-Datei 
     */
    public $count_commands_before;
    
    
    /**
     *
     * @var     integer     Anzahl der SQL-Anweisungen in der Script_after_update-Datei 
     */
    public $count_commands_after;
    
    
    /**
     *
     * @var     Array       Daten des sendenden Formulars.
     *                      Bsp.: Array
                                    (
                                        [ds] => 0
                                        [form] => 305
                                        [content] => Array
                                            (
                                                [id] => 1
                                                [app_id] => SYS01
                                                [versionnumber] => 
                                                [description] => Versionsvorbereitung
                                            )

                                        [schema] => manager
                                        [table] => version
                                        [hash] => 90ef1462ab8ed8d6a0572caaab391172
                                        [instance_id] => i0
                                    ) 
     */
    public $formData;
    
    
    
    /** 
     *
     * @var     string       aktuell angemeldeter User
     */
    protected $activeUser;
    
    
    /**
     *
     * @var     string      enthält die Versionsnummer, bis zu der diese Version abwärtskompatibel ist. 
     */
    protected $versionnumber_compatible;
    
    
    /**
     *
     * @var     string      enthält die Versionsnummer der KernelApp 
     */
    protected $versionnumber_kernelApp;
    
    
    /**
     *
     * @var     string      Versionsnummer der KernelApp, bis zu der die aktuelle KernelApp abwärtskompatibel ist. 
     */
    protected $versionnumber_kernelApp_compatible;





    /** Erstellt aus dem aktuellen Zustand der gewählten APP eine neue Version/Release, als Installationsbasis
     * 
     * @param   array   $in_senderFormData      Inhaltsdaten des sendenden Formulars; aus internPostarray übernehmen
     * @param   boolean $onlyPreparation        Wenn true, wird nur der Vorbereitungssatz angelegt. Ansonsten wird die Version und anschließend ein neuer Vorbereitungssatz angelegt.
     * @param   object  $in_pagedata            Referenz zum pagedata-object
     * @throws  Exception                       -142 bis -145 (siehe Konstantentyp_ID 35 )
     */
    public function __construct($in_senderFormData, $onlyPreparation, &$in_pagedata) {
        require_once("../controller/progressstatus_class.php"); 
        $connection_id_progress = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        session_write_close();             //wichtig, da sonst die parallele Abfrage des Bearbeitungszustandes via Ajax seitens des Clients nicht möglich ist.
        $myProgress = new progressstatus;
        $myProgress->setStatus($connection_id_progress, 1, 100, "erstelle neues Versionspaket", 1);
        
        
        $this->app_id = $in_senderFormData["content"]["version.app_id"];
        $this->versionnumber_compatible = $in_senderFormData["content"]["version.versionnumber_compatible"];
        $this->formData = $in_senderFormData;
        $this->activeUser = $in_pagedata->getActiveUser();
        $this->versionnumber_kernelApp = getVersionnumberFromApp(global_variables::getAppIdFromSYS01());
        $this->versionnumber_kernelApp_compatible = getVersionnumberCompatibleFromApp(global_variables::getAppIdFromSYS01());
        If($this->versionnumber_kernelApp === false) {throw new Exception(-147);}
 
        
        if($onlyPreparation !== true) {
            //Versionsnummer festlegen 
            $this->versionnumber = $this->getVersionNumber();
            $this->versionFileName = $this->app_id."_".$this->versionnumber.".zip";
            $this->versionWikiFileName = $this->app_id."_".$this->versionnumber."_wiki.zip";

            //Speicherpfad/ordner für die aktuelle Version bestimmen und anlegen
            $my_DIR_SEP = global_variables::getDirectorySeparator();
            $this->targetPath_rel = global_variables::getPathForVersion_rel().$this->app_id.$my_DIR_SEP.$this->versionnumber.$my_DIR_SEP;
            $this->makeVersionDir($this->targetPath_rel);

            //alle unterstützten SQL-Dialekte ermitteln
            $this->sqlLanguages = $this->getSqlLanguages();
            $myProgress->setStatus($connection_id_progress, 10, 100, "Versionspaket erstellen: Versionsmetadaten ermitteln", 1);
            
            //DB-Korrekturskript vor und nach Update erstellen und im Ordner ablegen
            //Dieser Schritt muss vor finalizeVersion erfolgen, da sonst nicht verarbeitete Skripte nicht erkannt werden.
            $this->createScriptBeforeUpdate();
            $this->createScriptAfterUpdate();
            
            //Versionsnummer eintragen und den Datensatz finalisieren
            //Dieser Schritt muss vor dem Backup erfolgen, damit im Backup die Version bereits als finalisiert gilt; (Backup ist in diesem Kontext als Datenkopie für Version zu verstehen).
            if($this->finalizeVersion($in_pagedata) == false) {throw new Exception(-144);}
            $myProgress->setStatus($connection_id_progress, 30, 100, "Versionspaket erstellen: Datenbanksicherung erstellen", 1);
            
            //DB-Sicherung erstellen und im Ordner install ablegen
            $this->makeDB_backup($this->sqlLanguages, $this->versionnumber, $this->targetPath_rel, $in_pagedata);
            $myProgress->setStatus($connection_id_progress, 40, 100, "Versionspaket erstellen: Webverzeichnis kopieren und bereinigen", 1);
            
            //Webverzeichnis-Kopie mit APP-Kürzel erstellen
            $target_path_temp = $this->targetPath_rel.$my_DIR_SEP.global_variables::getNameOfInstallFolder();
            if($this->copyInstalldataToVersion(global_variables::getPathForAppmsinstall_abs(false), $target_path_temp, global_variables::getListOfProgramDirs($this->app_id), "Version")== false) {
                $this->resetVersion($in_pagedata);
                throw new Exception(-142);
            }

            //Webverzeichnis-Kopie bereinigen; Wenn ein Fehler auftrat, dann eine Exception werfen und Abbruch.
            sleep(5);       //kurzer Schlafprozess ist notwendig, da es andernfallssein kann, dass vorherige Prozesse noch ein Handle auf Dateien haben und damit den Löschprozess verhindern.
            if($this->clearVersionFolder() == false) {
                $this->resetVersion($in_pagedata);
                throw new Exception(-142);
            }
            $myProgress->setStatus($connection_id_progress, 50, 100, "Versionspaket erstellen: Webverzeichnis paketieren.", 1);
            
            //version_info.xml in Webverzeichnis-Kopie anlegen
            $this->createVersionInfoFile($this->targetPath_abs);

            //Web-Verzeichnis paketieren => aktuelle Version
            if(createZipFileFromDir($this->targetPath_abs, $this->versionFileName) == false) {
                $this->resetVersion($in_pagedata);
                throw new Exception(-143);
            }
            $myProgress->setStatus($connection_id_progress, 70, 100, "Versionspaket erstellen: Wikidaten paketieren", 1);

            //Aus dem Webverzeichnis alles, außer dem Paket, löschen
            if(clearFolder($this->targetPath_abs, true, array($this->versionFileName)) == false) {
                $this->resetVersion($in_pagedata);
                throw new Exception(-142);
            }
            
            
            //Wiki-Daten in ein separates Installationspaket ablegen
            $this->makeWikiPackage($in_pagedata);
            
            //aktuelle Versionsnummer in der Tabelle app hinterlegen
            if(setVersionNumberIntoTableApp($in_pagedata, $this->versionnumber,$this->versionnumber_compatible, $this->app_id,$this->activeUser) == false) {throw new Exception(-146);}
            $myProgress->setStatus($connection_id_progress, 90, 100, "Versionspaket erstellen: Abschluß", 1);
            
            
            
            
        //	Nutzer darauf hinweisen, dass paket in einem Repository abgelegt und Tabelle Version darauf verlinkt werden könnte.
        
        }
        
//	neuen Versionsdatensatz in Tabelle Version zur nächsten Versionsvorbereitung anlegen
        if($this->initiateNewVersion($in_pagedata) == false) {throw new Exception(-145);}
        $myProgress->setStatus($connection_id_progress, 100, 100, "Versionspaket erstellen: Fertig", 1);
        session_start();                   //alte Session wieder aufnehmen
        
        //unter Ubuntu testen
        
    }

    
    
    
    
    /** Erzeugt das Installationspaket für das APP-spezifische Wiki
     * 
     * @param   object  $in_pagedata    Referenz zum pagedata-object
     * @throws Exception
     */
    private function makeWikiPackage(&$in_pagedata) {
        
        //0. create wiki-path if not exist
        $my_DIR_SEP = global_variables::getDirectorySeparator();
        $this->targetPath_rel = global_variables::getPathForVersion_rel().$this->app_id.$my_DIR_SEP.$this->versionnumber.$my_DIR_SEP."wiki";   
        $this->makeVersionDir($this->targetPath_rel);
        $path_absolute = global_variables::getPathForAppmsinstall_abs(false).$this->targetPath_rel.$my_DIR_SEP;
        $wikiVersionFileName = $this->versionWikiFileName;
        
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__." -> absolute path version", $path_absolute);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__." -> relativer path version", $this->targetPath_rel);
        
        //version_info.xml in Webverzeichnis-Kopie anlegen
        $this->createVersionInfoFile($path_absolute);
        
        //wiki in  wiki-temp-path kopieren; Bei SYS01 werden alle Ordner kopiert
        $source_path = global_variables::getPathForAppmsinstall_abs(false).global_variables::getNameOfWikiDir().$my_DIR_SEP;
        if($this->copyInstalldataToVersion($source_path, $this->targetPath_rel,global_variables::getListOfWikiDirs($this->app_id), "Wiki")== false) {
            $this->resetVersion($in_pagedata);
            throw new Exception(-148);
        }
        
        
        
        //unnötige Verzeichnisse leeren
        clearFolder($path_absolute."data".$my_DIR_SEP."attic".$my_DIR_SEP, true);
        clearFolder($path_absolute."data".$my_DIR_SEP."cache".$my_DIR_SEP, true);
        clearFolder($path_absolute."data".$my_DIR_SEP."media_attic".$my_DIR_SEP, true);
        clearFolder($path_absolute."data".$my_DIR_SEP."media_meta".$my_DIR_SEP, true);
        clearFolder($path_absolute."data".$my_DIR_SEP."meta".$my_DIR_SEP, true);

        //unnötige bzw. zu große  Plugins löschen
        clearFolder($path_absolute."lib".$my_DIR_SEP."plugins".$my_DIR_SEP."dw2pdf".$my_DIR_SEP, true);

        //4. Verzeichnisse löschen, die nicht der aktuellen APP oder dem Ordner "appms" entsprechen
        If ($this->app_id == global_variables::getAppIdFromSYS01()) {
            $exclude_dirs = array("appms", strtolower($this->app_id));
            unlink(realpath($path_absolute."conf".$my_DIR_SEP."users.auth.php"));               //Passwortdatei
        } else {
            $exclude_dirs = array(strtolower($this->app_id));
            unlink(realpath($path_absolute."COPYING")); 
            unlink(realpath($path_absolute."doku.php")); 
            unlink(realpath($path_absolute."feed.php")); 
            unlink(realpath($path_absolute."index.php")); 
            unlink(realpath($path_absolute."README")); 
            unlink(realpath($path_absolute."SECURITY.md")); 
            unlink(realpath($path_absolute."VERSION")); 
            unlink(realpath($path_absolute.".htaccess")); 
        }       
        clearFolder($path_absolute."data".$my_DIR_SEP."pages".$my_DIR_SEP, true, $exclude_dirs);
        clearFolder($path_absolute."data".$my_DIR_SEP."media".$my_DIR_SEP, true, $exclude_dirs);

        //Zip-File erstellen
        if(createZipFileFromDir($path_absolute, $wikiVersionFileName) == false) {
            $this->resetVersion($in_pagedata);
            throw new Exception(-143);
        }
        
        //wiki-temp-path löschen
        clearFolder($path_absolute, true, array($wikiVersionFileName));
        
       
        
    }
    
    
    
    
    


    /**
     * Erstellt die Versionsinfo-Datei "version_info.xml" und schreibt diese in den Versionsordner
     * 
     * @param   string  $in_targetpath_abs      absoluter Zielpfad
     */
    protected function createVersionInfoFile($in_targetpath_abs) {
        
        if($this->versionnumber_compatible == "") {$versionnumber_compatible = 0;} else {$versionnumber_compatible = $this->versionnumber_compatible;}
        
        //xml-File erstellen
        $myVersionInfo = "".
                "<?xml version='1.0' standalone='yes'?> \n".
                    "<category> \n".
                        "<version> \n".
                            "<app>".$this->app_id."</app> \n".	
                            "<version>".$this->versionnumber."</version> \n".
                            "<compatible_with_version>".$versionnumber_compatible."</compatible_with_version> \n".
                            "<needed_kernel_version>".$this->versionnumber_kernelApp."</needed_kernel_version> \n".
                            "<compatible_with_kernel>".$this->versionnumber_kernelApp_compatible."</compatible_with_kernel> \n".
                            "<count_commands_before_script>".$this->count_commands_before."</count_commands_before_script> \n".
                            "<count_commands_after_script>".$this->count_commands_after."</count_commands_after_script> \n".
                        "</version> \n".
                    "</category>";
        
        
        //xml-Datei in Version-Dir schreiben
        $feedback = writeFile($in_targetpath_abs, global_variables::getNameOfVersionInfoFile(), $myVersionInfo);
        
    }
    
    
    
    
    /** Kopiert die, für die Installation notwendigen Daten rekursiv in den Versionsordner (target_path)
     * 
     * @param   string  $in_source_path     Quellpfad (absolut), mit abschließenden Directory-Separator
     * @param   string  $in_target_path     Zielpfad (relativ), ohne abschließenden Directory-Separator
     * @param   array   $in_folderList      Liste der Verzeichnisse aus dem source_path, welche kopiert werden sollen
     * @param   string  $in_log_message     Kennung, die in einer ggf. notwendigen Erroer-Message ausgegeben werden soll (Bsp.: Version oder Wiki)
     * @return  boolean
     */
    private function copyInstalldataToVersion($in_source_path, $in_target_path, $in_folderList, $in_log_message) {
        //$in_folderList = global_variables::getListOfProgramDirs($this->app_id);
        $my_DIR_SEP = global_variables::getDirectorySeparator(); 
        //$in_source_path = global_variables::getPathForAppmsinstall_abs(false);
        $permission = global_variables::getDefaultPermissionForFolder();
        
        //Alle Ordner im Installationsverzeichnis, inkl. aller Unterordner kopiern
        foreach ($in_folderList as $currentFolder) {
            $target_path = global_variables::getPathForAppmsinstall_abs(false).$in_target_path.$my_DIR_SEP;
            $feedback1 = folder_copy($in_source_path.$currentFolder.$my_DIR_SEP, $target_path.$currentFolder, $permission, true);
        }
        
        //nur die Dateien der ersten Ebene aus dem Installationsverzeichnis kopieren.
        $feedback2 = folder_copy($in_source_path, $target_path, $permission, false);
        
        if($feedback1 == false OR $feedback2 == false) {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, $in_log_message.": Die Dateien konnten nicht von: ".$in_source_path."  nach: ".$target_path." kopiert werden.","ERROR");
            return false;
        } else {
            return true;
        }
    }
    
    
    
    
    
    
    
    
    /** Die Funktion entfernt alle unnötigen Ordner und Dateien aus dem Version-Verzeichnis
     * 
     * @return boolean
     */
    private function clearVersionFolder() {
        $feedback = true;
        
        //Data-Verzeichnisse von fremden APP's löschen
        if($this->deleteOtherDataFolders($this->app_id) == false) {
            $feedback = false;
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "deleteOtherDataFolders schlug fehl","ERROR");
        }
        
        //alle Sicherungen im backup-Verzeichnis löschen
        $backupDir = $this->targetPath_abs.global_variables::getPathForAppmsinstall_rel(false).global_variables::getPathForBackups_rel($this->app_id);
        if($this->deleteFilesInFolder($backupDir, array()) == false) {
            $feedback = false;
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "deletebackupFolders schlug fehl","ERROR");
        }

        //Config-Dateien löschen
        $configDir = $this->targetPath_abs.global_variables::getPathForAppmsinstall_rel(false).global_variables::getPathForConfigs_rel($this->app_id);
        if($this->deleteFilesInFolder($configDir, array()) == false) {
            $feedback = false;
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "deleteConfigFolder schlug fehl","ERROR");
        }
        
        //unnötige Dateien aus der Wurzel löschen
        $rootDir = $this->targetPath_abs.global_variables::getPathForAppmsinstall_rel(false);
        $exceptionList = global_variables::getListOfAllowedFilesInRoot($this->app_id);
        if($this->deleteFilesInFolder($rootDir, $exceptionList) == false) {
            $feedback = false;
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "deleterootFolder schlug fehl","ERROR");
        }
        
        return $feedback;
        
    }
    
    
    
    
    /** Löscht die nicht benötigten Data-Verzeichnisse der anderen APP's.
     * I.d.R. wird nur das Data-Verzeichnis der aktuellen APP benötigt.
     * Bei der Kernel-APP bleibt zusätzlich das TEMPL-Verzeichnis erhalten.
     * 
     * @param type $in_app_id
     * @return boolean
     */
    private function deleteOtherDataFolders($in_app_id) {
        $feedback = true;
        
        $DataDirInVersion = $this->targetPath_abs.global_variables::getPathForAppmsinstall_rel(false).global_variables::getPathForData_rel();
        if(global_variables::getAppIdFromSYS01() == $in_app_id) {
            //Im Kernelmodul bleibt der eigene APP-Ordner und der TEMPL-Ordner erhalten
            $exceptList = array(global_variables::getNameOfTemplateInDatafolder(), $in_app_id);
        } else {
            //In allen Anderen APP's bleibt nur der eigene APP-Ordner erhalten
            $exceptList = array($in_app_id);
        }
        
        //Data-Ordner bereinigen
        $deleteResult = clearFolder($DataDirInVersion, true, $exceptList);
        if($deleteResult == false) {
            $feedback = false;
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Dateien oder Ordner in '.$DataDirInVersion.' konnten nicht gelöscht werden. ', $deleteResult, "ERROR");
        }
        return $feedback;
        
    }
    
    
    /** Löscht aus einem bestimmten Verzeichnis alle Dateien. Unterordner bleiben erhalten.
     * 
     * @param   string      $in_folder          absoluter Pfad zum Ordner
     * @param   array       $in_exceptionList   Liste der nicht zu löschenden Dateien
     * @return  boolean                         true, wenn keine Fehler auftraten. Wenn Fehler auftraten, werrden diese in der Tabelle debug abgelegt.
     */
    private function deleteFilesInFolder($in_folder, $in_exceptionList) {
        $feedback = true;

        //Data-Ordner bereinigen
        $deleteResult = clearFolder($in_folder, false, $in_exceptionList);
        if($deleteResult == false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Dateien oder Ordner in '.$in_folder.' konnten nicht gelöscht werden. ', $deleteResult, "ERROR");
            $feedback = false;
        }
        return $feedback;
    }
    
    
    
    /** Erstellt einen String, der $in_topic als Überschrift nutzt und anschließend alle sqlCommands 
     * mit Zeilenumbruch aneinander reiht.
     * 
     * @param  string   $in_topic           Text, der als Überschrift genutzt werden soll
     * @param  array    $in_sqlCommands     Liste von SQL-Commands
     * @return string                       
     */
    private function getSqlPart($in_topic, $in_sqlCommands) {
        $feedback = "";
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Version-write ", $in_topic, "INFO");
        $feedback = $feedback."-- count(commands): ".count($in_sqlCommands)."\n";
        $feedback = $feedback."-- ".$in_topic."--------------\n";
        foreach ($in_sqlCommands as $key => $value) {
            $feedback = $feedback."-- ".$value["version_notes.topic"].";\n";
            $feedback = $feedback.$value["version_script.script"].";\n\n";
        }
        $feedback = $feedback."\n\n\n";
        
        return $feedback;
    }
    
    
    
    
    /** Erstellt für alle SQL-Dialekte jeweils ein Backup vom Typ 101 und 115 (SYS01) oder 111, 112 und 115 (andere APP's) und legt diese im install-Ordner ab
     * 
     * @param array     $in_sql_langueages      Liste der SQL-Dialekte
     * @param string    $in_versionNumber       ID der zu erstellenden Version
     * @param string    $in_targetPath          relativer Pfad (beginnend mit /appms/..), zur Ablage der Backup-Dateien
     * @param object    $in_pagedata            Referenz zum pagedata-object
     */
    protected function makeDB_backup($in_sql_langueages, $in_versionNumber, $in_targetPath, &$in_pagedata) {
        //Dummy-Formulardaten erzeugen, da die Backup_klasse das erwartet.
        $my_formArray["form.app_id"] = global_variables::getAppIdFromSYS01();                               
        $my_formArray["form.logging"] = false;
        
        if($this->app_id == global_variables::getAppIdFromSYS01()) {
            //Für die Kernel-APP muss der Backup-Mode 101 genutzt werden.
            //Dabei können die vier Datentypen (structure, content, config und addContent) in einem Skript gesichert werden,
            //da sie jeweils im gleichen Schema liegen. Das wieder Einspielen der Daten kann hier mit den gleichen 
            //Benutzerrechten erfolgen.
            foreach ($in_sql_langueages as $currentSqlLanguage) {
                    $myBackupObject = new backup($this->app_id, 101, "Version: ".$in_versionNumber, $currentSqlLanguage, $my_formArray, $in_targetPath, false, $in_pagedata, true, $this->versionnumber."_101");
                    $myBackupObject = new backup($this->app_id, 115, "Version: ".$in_versionNumber, $currentSqlLanguage, $my_formArray, $in_targetPath, false, $in_pagedata, true, $this->versionnumber."_115");
            }
        } else {
            //Für alle anderen APP's müssen die Backup-Modi 111 und 112 genutzt werden.
            //Dabei wird davon ausgegangen, dass die  Datentypen (structure und content) 
            //sowie (config und addContent) jeweils im gleichen Schema liegen und daher gemeinsam gesichert werden können.
            foreach ($in_sql_langueages as $currentSqlLanguage) {
                    $myBackupObject = new backup($this->app_id, 111, "Version: ".$in_versionNumber, $currentSqlLanguage, $my_formArray, $in_targetPath, false, $in_pagedata, true, $this->versionnumber."_111");
                    $myBackupObject = new backup($this->app_id, 112, "Version: ".$in_versionNumber, $currentSqlLanguage, $my_formArray, $in_targetPath, false, $in_pagedata, true, $this->versionnumber."_112");
                    $myBackupObject = new backup($this->app_id, 115, "Version: ".$in_versionNumber, $currentSqlLanguage, $my_formArray, $in_targetPath, false, $in_pagedata, true, $this->versionnumber."_115");
            }
            
        }
    }
    
    
    
    
    
    /**
     * Ermittelt alle unterstützten SQL-Dialekte
     * 
     * @return  array                   Bsp.: array("mysql", "postgresql")
     */
    protected function getSqlLanguages() {
        $feedback = array();
        $kernel_schema = global_variables::getNameOfDbSchemaSYS01();
        $kernel_app_id = global_variables::getAppIdFromSYS01();
        $resultlist = getTableData($kernel_app_id, "konstante", $kernel_schema, false, "sort", "konstantentyp_id = 50 AND konstantentyp_app_id = '".$kernel_app_id."'", __FUNCTION__);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> SQL-Dailekte result ', $resultlist);
        foreach ($resultlist as $key => $datarow) {
            $feedback[] = $datarow["konstante.wert"];
        }
        return $feedback;
    }
    
    
    
    /**
     * Methode legt die Grundlagen für eine neue Version.
     * Dazu wird in der DB-Tabelle ein neuer Datensatz angelegt ...
     * 
     * @param  object   $in_pagedata        Referenz auf das pagadata-object
     * @return boolean
     */
    protected function initiateNewVersion(&$in_pagedata) {
        
        $nextID = getMaxValue(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "version", "id");
        $nextID = $nextID + 1;
        
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "version";
	$SqlArray["into"] = "id, app_id";
	$SqlArray["values"] =   $nextID.
                                ", '".$this->app_id."'";
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $this->activeUser, $in_pagedata);
        
        if ($result == false) {return false;} else {return true;}
    }
    
    
    
    
    
    
    
    /** Legt den angegeben Ordner mit Permissions (global_variables::getDefaultPermissionForVersionFolder()) an,
     * wenn er nicht vorhanden ist.
     * 
     * @param   string  $in_relPath         relativer Pfad, der im AppMS-Installationsverzeichnis angelegt werden soll.
     */
    protected function makeVersionDir($in_relPath) {
        $path_absolut = global_variables::getPathForAppmsinstall_abs(false).$in_relPath;
        if(file_exists($path_absolut) == false) {
            $permission = global_variables::getDefaultPermissionForFolder();
            if(mkdir($path_absolut, octdec($permission), true) == true) {
                //Ordnerstruktur wurde angelegt
                $this->targetPath_abs = $path_absolut;
            } else {
                //der Ordner konnte nicht angelegt werden. Abbruch mit Fehlermeldung.
                throw new Exception(-141);
            }
        }
    }
    
    
    
    /**
     * Erstellt für die aktuelle Version das Script, welches vor Durchführung des Updates 
     * auf der Datenbank ausgeführt werden muss, um dort Anpassungen durchzuführen.
     * 
     */
    protected function createScriptBeforeUpdate() {
        $this->before_update_scripts = getVersionScript(global_variables::getAppIdFromSYS01(), $this->app_id, "before");
        $this->count_commands_before = count($this->before_update_scripts);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Skripte, before Update ', $this->before_update_scripts);
        $sqlCommands = $this->getSqlPart("Scripte, welche vor dem Update ausgeführt werden.", $this->before_update_scripts);
        writeZipFile($sqlCommands, $this->targetPath_rel, true, "script_before_update.sql", __FUNCTION__);
    }
    
    
    
    /**
     * Erstellt für die aktuelle Version das Script, welches nach Durchführung des Updates 
     * auf der Datenbank ausgeführt werden muss, um dort Anpassungen durchzuführen.
     * 
     */
    protected function createScriptAfterUpdate() {
        $this->after_update_scripts = getVersionScript(global_variables::getAppIdFromSYS01(), $this->app_id, "after");
        $this->count_commands_after = count($this->after_update_scripts);
        $sqlCommands = $this->getSqlPart("Scripte, welche nach dem Update ausgeführt werden.", $this->after_update_scripts);
        writeZipFile($sqlCommands, $this->targetPath_rel, true, "script_after_update.sql", __FUNCTION__);
    }
    
    
    
    /**
     * Schreibt in die Datenbanktabelle version, dass die Version erstellt wurde 
     * 
     * @param   object  $in_pagedate    Referenz zum pagedata-object
     * @return  boolean
     */
    protected function finalizeVersion(&$in_pagedata) {
        
        
        
        //Daten für Tabelle version ermitteln
        $update =   "versionnumber = '".$this->versionnumber."', ".
                    "versionnumber_compatible = '".$this->versionnumber_compatible."', ".
                    "builddate = '".date("Ymd")."', ".
                    "sys = 1, ".
                    "finalized = 1, ".
                    "pathname = '".$this->targetPath_rel."', ".
                    "filename = '".$this->versionFileName."', ".
                    "filename_wiki = '".$this->versionWikiFileName."', ".
                    "description = '".$this->formData["content"]["version.description"]."'";
        
        $where = "app_id = '".$this->app_id."' AND id = ".$this->formData["content"]["version.id"];
        
        
        $sqlDaten = array();
        $sqlDaten["into"] = "";
        $sqlDaten["values"] = "";
        $sqlDaten["update"] = $update;
        $sqlDaten["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $sqlDaten["table"] = "version";
        $sqlDaten["where"] = $where;
        $sqlDaten["logdata"] = "";
        $sqlDaten["logdata_id_data"] = "";

        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();     
        
        $result = updateData($sqlDaten, $dummy_form, $this->activeUser, $in_pagedata);

        if ($result < 0) {return false;} else {return true;}
    }
    
    

    
    
    
    
    /**
     * Versetzt den Versionsdatensatz wieder in den finalized=false Zustand 
     * 
     * @return boolean
     */
    protected function resetVersion(&$in_pagedata) {
        
        
        
        //Daten für Tabelle version ermitteln
        $update =   "versionnumber = '".$this->versionnumber."', ".
                    "builddate = null, ".
                    "sys = 1, ".
                    "finalized = 0, ".
                    "pathname = '', ".
                    "filename = '', ".
                    "description = '".$this->formData["content"]["version.description"]."'";
        
        $where = "app_id = '".$this->app_id."' AND id = ".$this->formData["content"]["version.id"];
        
        
        $sqlDaten = array();
        $sqlDaten["into"] = "";
        $sqlDaten["values"] = "";
        $sqlDaten["update"] = $update;
        $sqlDaten["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $sqlDaten["table"] = "version";
        $sqlDaten["where"] = $where;
        $sqlDaten["logdata"] = "";
        $sqlDaten["logdata_id_data"] = "";

        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();    
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();     
        
        $result = updateData($sqlDaten, $dummy_form, $this->activeUser, $in_pagedata);
        
        //Versionspaket aus dem Dateisystem wieder löschen, falls vorhanden
        clearFolder($this->targetPath_abs, true);
        rmdir($this->targetPath_abs);

        if ($result < 0) {return false;} else {return true;}
    }
    
    
    /**
     * Gibt die nächste zu verwendende Versionsnummer zurück.
     * Derzeit wird die Versionsnummer aus dem aktuellen Datum und der aktuellen Zeit gebildet.
     * Format: JJJJMMTThhmm 
     * Beispiel: 201811051456   (05.11.2018 14:56)
     * 
     * @return string
     */
    protected function getVersionNumber() {
        return date("YmdHis");
    }
    
}
