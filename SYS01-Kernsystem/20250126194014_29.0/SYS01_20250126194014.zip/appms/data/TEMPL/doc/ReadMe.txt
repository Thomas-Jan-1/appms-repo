Datei: ReadMe.txt im Verzeichnis ../data/%APP_ID%/doc/
Autor: tomjan@gmx.de
Stand: 12.03.2024
------------------------------------------------------

Dieser Ordner dient nur als Vorlage w�hrend der Entwicklung einer neuen APP. Das Wiki-Verzeichnis wird nach ../appms/wiki/data/pages/%APP_ID%/ kopiert.
Die Doku erfolgt daraufhin im Wiki und kann �ber https://%server%/appms/wiki/ aufgerufen werden.



