Wenn Änderungen in Plugins von Drittanbietern vorgenommen werden, dann sollten diese mit
/*AppMS-Änderung*/ gekennzeichnet werden. So lassen sie sich bei Bedarf leichter auffinden.