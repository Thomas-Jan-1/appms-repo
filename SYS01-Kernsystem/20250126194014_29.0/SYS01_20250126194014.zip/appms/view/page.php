<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


/**
 * Diese PHP-Datei ist für den Aufbau (Rendern) beliebiger Webseiten zuständig. Dazu werden die Informationen aus der Tabelle Mask abgerufen
 * Die MAsk-ID muss als Eingabeparameter (GET) übergeben werden. Darauf aufbauend wird das Grundgerüst der Seite aufgebaut.
 */
    ini_set("display_errors", 1);
    require_once("../controller/global_variables_class.php"); 
    //require_once("../controller/sessionHandler.php");                                             //Session prüfen/starten/beenden
    require_once("../controller/session_class.php");  
    require_once("../controller/showFields.php");
    require_once("../controller/html_class.php");
    require_once("../controller/pagedata_class.php");
    
    
    
    
//    echo "PHP_SELF: ".$_SERVER["PHP_SELF"]."<br />";                  //sollte sein -> /appms/view/page.php
//    echo "DOCUMENT_ROOT: ".$_SERVER["DOCUMENT_ROOT"]."<br />";        //könnte sein -> C:/Programme_eigene/xampp/htdocs
//    echo "SERVER_ADDR: ".$_SERVER["SERVER_ADDR"]."<br />";            //könnte sein -> ::1  (localhost)
    
    if(isset($_GET["mask"])) {
    //Wenn bereits ein Menüeintrag gewählt wurde ...

        $pageData = new pagedata($_GET);                             //lädt alle Maskendetails, Formularkonfigurationen und Details zur eventuell aufgerufenen Funktion
        $maskArray = $pageData->getMaskArray();                                 //Daten der Tabelle Mask auslesen (Metadaten zur Mask)
        
        
        
        
        /*--Zugriffsberechtigung prüfen------------*/  
        $Zugriff_erlaubt = checkPermission(session_class::$session_object->getUid(), session_class::$session_object->getAppIdFromUid(), $maskArray["app_id"], $maskArray["id"]); 

        if ($Zugriff_erlaubt["access"] == TRUE) {
            
            
            
            /*--Nur das HTML-tag ermitteln --------*/
            $htmlTag = getTaglistFromMask($maskArray["id"], $maskArray["app_id"], true, $pageData->getCurrentUserFromSession());                                               
            $htmlTag = $htmlTag[0];                                                              //Ergebnismenge kann nur einen Datensatz enthalten, da es nur ein html-tag pro DOM geben darf. Daher wird vom zweidimensionalen Array nur der erste Datensatz extrahiert.
            
            $html_dom = new HtmlDomTree($htmlTag, $pageData);                                    //HTML-Dom-Objekt erzeugen           
            $pageData->setHtmlDomObject($html_dom);                                              //HTML-Dom-Obejt in pagedate referenzieren, damit darauf überall im Programm zugegriffen werden kann.
            /*--Ende  HTML-tag --------------------*/
            
            
            //Mask-Style ermitteln
            if(isset($_GET["css_app"]) AND isset($_GET["css_id"])) {
                //Css-template der Maske wird durch Get-Parameter der URL überlagert
                $css_app_id = $_GET["css_app"];
                $css_id = $_GET["css_id"];
                //Die Werte in das pagedata-Objekt übergeben, damit auch alle weiteren Links mit den CSS-Parametern bestückt werden.
                $pageData->setMaskCSS($css_app_id,$css_id);
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Mask_array nach setMaskCSS: ', $pageData->getMaskArray());
            
            } else {
                //[Default] CSS-Template der Maske wird genutzt.
                $css_app_id = $maskArray["css_template_app_id"];
                $css_id = $maskArray["css_template_id"];
                
            }
            
            
            
            /*--Liste aller sonstigen  Tags -----------*/
            //(ohne <html>-tag und ohne Spezialfunktionen, wie Style oder Tabledata)
            $tagList = getTaglistFromMask($maskArray["id"], $maskArray["app_id"], false, $pageData->getCurrentUserFromSession());                                              
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Tag-Liste: ', $tagList);
            //Alle tags dem DOM hinzufügen
            for ($i = 0; $i < count($tagList); $i++) {
               
                try {
                    //		addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> addTag: '.$i, "button_action_function_id: ".$button_action_function_id);
                    $html_dom->addTag($tagList[$i], $pageData); 
//                              addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> addTag: '.$i, "beendet", "INFO");
                } catch (Exception $ex) {
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Fehler bei Durchlauf: '.$i, $tagList[$i], "ERROR");
                    echo    "Fataler Fehler beim Aufbau des HTML-Dom. (html_tag.id = ".$tagList[$i]["html_tag.id"].") <br />".
                            "<br />".
                            "Ein Dom-Element fehlt. mögliche Fehlerursachen:<br />".
                            "- Der Maske wurde nicht das Maskenelement 'Grundgerüst' zugeordnet. <br />".
                            "- In einem Formular der Maske wird in einem Feld die Feldart 'Referenz zu einer Tabelle' verwendet, jedoch fehlen die Angaben zur Referenztabelle. <br />".
                            "- In einem Formular der Maske wird in einem Feld die Feldart 'Referenz zu einer Query' verwendet, jedoch fehlen die Angaben zur Query. <br />".
                            "<b>die Fehlerursache kann über die Debug-Tabelle ermittelt werden.</b>";
                }
                
            }      
            
            /*--Ende sonstige Tags ---------------------*/
            
            
            
            
            /*--Style-Angaben im Header-Bereich ergänzen ------*/
            $css_attribute = new CssAttribute($maskArray["app_id"], $css_app_id, $css_id);            //Die TagAttributliste der aktuellen Maske für den STYLE-Bereich im head des HTML-DOM ermitteln
            $html_dom->setValueForTag(6, $css_attribute->getStyleElementListInCSSformat());           //TODO: Konstante 6 muss durch eine dynamische Methode zur Ermittlung des style-tags ersetzt werden.
            $template_id_list = $css_attribute->getTemplateIDList();
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> beteiligte CSS_Templates: ', $template_id_list);
            /*--Ende Style-Tag---------------------------------*/
            
            $html_dom->setValueForTag(1789, $maskArray["name"]);           //TODO: Konstante 1789 muss durch eine dynamische Methode zur Ermittlung des style-tags ersetzt werden.
            $html_dom->setValueForTag(2063, $pageData->getSessionMessageForField("click_button"));
                                    
            
            /*--CSS-Klassen zu den verwendeten tags ergänzen----*/
            $css_classes = getClasslistforTemplate($template_id_list, $maskArray["css_template_app_id"], $maskArray["id"], $maskArray["app_id"]);
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Class-Liste: ', $css_classes);
            $html_dom->setClassListForAllTags($css_classes);
            
            /*--Ende CSS-Klassen--------------------------------*/
            
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> target-forms ', $pageData->_requested_forms);
  
            //HTML-Dom an Client übergeben
            if($pageData->_requested_forms == array() AND $pageData->internGetObject->_loadOnlyTargetForm == false) {
                //der gesamte DOM wurde abgefragt oder es wurde ein Explorerformular genutzt, deren abhängigen Formulare auf der aktuellen Maske nicht vorhanden sind.
                echo $html_dom->printHtmlCode();
            } else {
                //nur ein Formular, inkl. aller abhängigen Formulare soll übergeben werden
                $html_dom->printHtmlCodeOnlyForRequestedForms($pageData->_requested_forms);
                
                //Formulare in String umwandeln, welcher durch JS verarbeitet werden kann.
                $feedbackForms = $pageData->getRequestedFormTagsHtml();
                $jsonFeedback = prepareArrayForJsonFeedback($feedbackForms);
                echo $jsonFeedback;
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> target-forms ', $pageData->_requested_forms);
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> target-forms as Html ', $pageData->getRequestedFormTagsHtml());
            }
            
            
            
            //Form_Array in SESSION ablegen, damit die Daten beim nächsten Maskenaufruf wieder zur Verfügungstehen
            session_class::$session_object->setFormBackup($pageData->getFormList());
            //Field_Messages in SESSION löschen, da diese nur von der Funktionsausführung bis zum Maskenaufbau gelten sollen.
            session_class::$session_object->resetFieldMessages();
            session_class::$session_object->my_destructer();          //sicherstellen, dass Session-Änderungen an die globale Variable übergeben werden
            
            $useCacheCounter = db_connection_handler::$countUseCache;
            
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Statistic: Cache-use ', $useCacheCounter);
            
            
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> HTML-Quellcode: ', $html_dom->printHtmlCode());
           
            //Ausgabe der Debug-Meldungen, wenn der Konfigurationsparameter auf TRUE steht.
            //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Interne Variablen: ', serialize($internVariables));
            deleteOldDebugMessages($pageData); 
            db_connection_handler::closeAllConnections();           //nicht zwingend notwendig, da sich die Nutzung von persistenten Verbindungen ohnehin als nicht effizienter erwiesen hat.
            
        }	//Zugriff erlaubt end
        
        else {
            session_class::$session_object->deniedAccess($Zugriff_erlaubt["reason"]);
        }
    }

?>
