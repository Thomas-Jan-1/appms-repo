<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


/**
 * Methoden, die zur Erstellung eines backups benötigt werden.
 *
 */



ini_set('memory_limit', '512M');


require_once("../controller/model/db_connection_handler_class.php");

class backup {
    
     
    
    
    /**
     *
     * @var     string      ID der APP, für die das backup erstellt werden soll. 
     */
    public $app_id;
    
    
    /** 
     *
     * @var     array       Liste aller Schemata von $this->_app_id
     */
    protected $_app_schema_list;
    
    
    /**
     * 
     * @var     array       Liste aller views -> [0] => array(view_name, view_definition, view_schema)
     */
    protected $_view_list;
    
    
    /**
     * 
     * @var     array       Liste aller materilized views -> [0] => array(view_name, view_definition, view_schema)
     */
    protected $_matview_list;
    
    
     /**
     * 
     * @var     array       Liste aller Funktionen -> array(0=>array(function.name, function.schema, function.def))
     */
    protected $_function_list;
    
    
     /**
     * 
     * @var     array       Liste aller Trigger -> array(0=>array(trigger.name, triggrt.schema, triggrt.def))
     */
    protected $_trigger_list;
    
    
     /**
     * 
     * @var     array       Liste aller Trigger-Commands
     */
    protected $_create_trigger_commands;
    
    
    /**
     *
     * @var     array       Eindimensionales Array mit den Schemanamen als key und den Owner als value. Bsp.: array("manager" => "myUser1", "app2" => "myUser2")
     */
    protected $_app_schema_list_with_owner;
    
    
    /**
     *
     * @var     array       Alle Drop-Table-Befehle, ohne Semikolon am Ende
     */
    protected $_dropTableCommands;
    
    
    /**
     *
     * @var     array       Alle Drop-View-Befehle, ohne Semikolon am Ende
     */
    protected $_dropViewCommands;
    
    
    /**
     *
     * @var     array       Alle Drop-MatView-Befehle, ohne Semikolon am Ende
     */
    protected $_dropMatViewCommands;
    
    
     /**
     *
     * @var     array       Alle Drop-Function-Befehle, ohne Semikolon am Ende
     */
    protected $_dropFunctionCommands;
    
    
    /**
     *
     * @var     array       Alle UpdateSequenceCommands der Tabellen im App-Schema. Diese werden nicht für alle DBMS ermittelt, da sie in einigen DBMS nicht notwendig sind. 
     */
    protected $_updateSequenceCommandsForApptables;
    
    
    /**
     *
     * @var     array       Alle UpdateSequenceCommands der Tabellen im Kernel-Schema. Diese werden nicht für alle DBMS ermittelt, da sie in einigen DBMS nicht notwendig sind. 
     */
    protected $_updateSequenceCommandsForConfigtables;
    
    
    /**
     * 
     * @var     array       Alle Drop-Schema-Befehle, ohne Semikolon am Ende
     */
    protected $_dropSchemaCommands;
    
    
    /**
     *
     * @var     array       Alle Create-Schema-Befehle, ohne Semikolon am Ende 
     */
    protected $_createSchemaCommands;
    
    
    /**
     * 
     * @var     array       Alle Create-View-Befehle, mit Semikolon am Ende
     */
    protected $_createViewCommands;
    
    
    /**
     *
     * @var     array       Alle Grant-Commands für Schemata, ohne Semikolon am Ende. 
     */
    protected $_grantSchemaCommands;
    
    
        
    /**
     *
     * @var     array       Alle Delete-Befehle für die Configtabellen 
     */
    protected $_deleteConfigTableCommands;
    
    
    /**
     *
     * @var     array       Alle Delete-Befehle für die Content-Tabellen 
     */
    protected $_deleteContentTableCommands;
    
    
    /**
     *
     * @var     array       Alle Update-Befehle für zu übernehmende lokale Konfigurationen (backup_rewriteColumns) 
     */
    protected $_updateConfigTableCommands;
    
    
    
    /**
     *
     * @var     array       Alle Delete-Befehle für die Add-Tables aus dem Kernmodul (siehe DB-Tabelle "backup_tabledefinitions.definition = "addIfContentBackupForApp"
     */
    protected $_deleteAddTableCommands = array();
    
    
    /**
     *
     * @var     string      Name eines Backups. Dieser wird auch als Dateiname genutzt. (Bsp.:  WIDER_20161030_081430_44.sql => APP_Datum_Uhrzeit_Millisekunden.sql)
     */
    public $_name;
    
    /**
     *
     * @var     string      beliebige Beschreibung des backups. 
     */
    protected $_description;
    
    /**
     *
     * @var     string      Name des Speicherpfades (kann relativ zum Programmpfad sein. siehe Konfigurationsparameter "backup_pathname"
     */
    protected $_pathname;
    
    /**
     *
     * @var     string      Dateiname des Backups 
     */
    public $_filename;
    
    /**
     *
     * @var     timestamp   Datum und Uhrzeit 
     */
    protected $_starttime;
    
    /**
     *
     * @var     timestamp   Datum und Uhrzeit 
     */
    protected $_endtime;

    /**
     *
     * @var     float       Dateigröße in Bytes 
     */
    protected $_filesize;
    
    /**
     *
     * @var     integer     Art der Inhaltsdaten (1 = only_data, 2 = only_structur, 3 = structur and data) 
     */
    protected $_contenttype;
    
    /**
     *
     * @var     string      Backupdaten -> Typ = Content (Insert) 
     */
    protected $_contentData;
    
    
    /**
     *
     * @var     string      SQL-Dialekt für das Ziel-DBMS ( postgressql | mysql | oracle ) 
     */
    protected $_target_sql_language;
    
    
    /**
     *
     * @var     string      SQL-Dialekt des Quell-DBMS ( postgressql | mysql | oracle ) 
     */
    protected $_source_sql_language;
    
    
    /** 
     *
     * @var     array       Array welches alle DB-views enthält
     */
    protected $_viewObjects = array();
    
    
    /** 
     *
     * @var     array       Array welches alle DB-views (inkl. matViews) enthält. Dabei wird die richtige (notwendige) Reihenfolge beachtet:
     */
    protected $_mergedViewObjects = array();
    
    
    /** 
     *
     * @var     array       Array welches alle DB-matviews enthält
     */
    protected $_matviewObjects = array();
    
    
    /** 
     *
     * @var     array       Array welches alle DB-functions enthält
     */
    protected $_functionObjects = array();
    
    
    /** 
     *
     * @var     array       Array welches alle DB-Tabellen, die zur Struktur einer APP gehören, als Objekte enthält
     */
    protected $_tableObjects_structure = array();
    
    
    /** 
     *
     * @var     array       Array welches alle DB-Tabellen, die Inhaltsdaten einer  APP (liegen nicht in SYS01) enthalten, als Objekte enthält
     */
    protected $_tableObjects_content = array();
    
    
    /** 
     *
     * @var     array       Array welches alle DB-Tabellen, die zentral gehostete Inhaltsdaten einer  APP (liegen in SYS01) enthalten, als Objekte enthält
     */
    protected $_tableObjects_addcontent = array();
        
    
    /** 
     *
     * @var     array       Array welches alle DB-Tabellen, die Konfigurationsdaten (liegen in SYS01) einer  APP enthalten, als Objekte enthält
     */
    protected $_tableObjects_config = array();
    
    
    /**
     *
     * @var     string      Enthält den Filename der Backup-Klasse, die in Abhängigkeit vom SQL-Dialekt genutzt werden soll. 
     */
    protected $_target_backup_class_file;
    
    
    
    /**
     *
     * @var     array       Variable nimmt alle Eigenschaften des Backups auf, welche in die DB-Tabelle "backup" geschrieben werden sollen.
     *                      (Werte:  app_id, name, description, pathname, filename, starttime, endtime, filesize
     */
    protected $_backup_metadata = array();

    
    /**
     *
     * @var     string      Dateityp (sql.gz|sql) hängt davon ab, ob auf dem Webserver die extension zlib vorhanden ist. 
     */
    protected $_filetype;
    
    
    /**
     *
     * @var     string      legt den gzip-mode fest. Wenn zlib vorhanden, dann "w9", sonst "w" 
     */
    protected $_gzip_mode;
    
    
    /**
     *
     * @var     object      Objekt der Klasse "backup_mode". Diese legt fest welche Daten gesichert werden müssen. 
     */
    public $backup_mode;
    
    
    /**
     *
     * @var     string      relativer Name des Pfades, in dem die Ergebnisdatei abgelegt werden soll, beginnend mit /appms/... 
     */
    public $safe_path;
    
    
    /**
     *
     * @var     string      namespace, in dem sich die Klassen des target_dbms befinden
     */
    protected $_target_backup_class_namespace;
    
    
       
    /**
     *
     * @var     object      Objekt der Klasse backup_helper aus einer DB-spezifischen Klasse (bspw. aus backup_postgresql_class). Diese ist für die target-Datenbank eines Backups gedacht. 
     */
    protected $_target_backup_class;
    
    
    
    /**
     *
     * @var     string      Hinweistext, welcher am Anfang einer Backupdatei im Bereich "Hinweis" angedruckt wird. 
     */
    protected $_target_note;
    
    
    /**
     *
     * @var     string      Konfigurationsparameter, dem Importskript vorangestellt werden. 
     */
    protected $_DBMS_Config_params = array();
    
    
    /**
     *
     * @var     string      Konfigurationsparameter, die am Ende des Importskripts angefügt werden. 
     */
    protected $_DBMS_Config_params_reset = array();
    
    
    /**
     *
     * @var     boolean     gibt an, ob das Backup in der DB-Tabelle manager.backup geloggt werden soll. 
     */
    protected $_log_backup;
    
    
    /**
     *
     * @var     boolean     Wenn true, werden Schemata, die app_schema.external_administrated = true haben, nicht gesichert. Diese Funktion ist für den Installer-Prozess notwendig, damit externe Schemata währendder Administrationnicht gelöscht werden. 
     */
    protected $_ignore_external_administrated_schema;
    
    
    /**
     * Klasse backup stellt Methoden zur Erstellung und Verwaltung von Backups bereit.
     * 
     * @param string    $in_app_id                                  ID einer APP (Bsp.: SYS01), für welche das Backup erstellt werden soll
     * @param intger    $in_contenttype                             1 = only_data, 2 = only_structur, 3 = structur and data, ... 7 (siehe Konstantentyp "Backup-Typ"
     * @param string    $in_description                             Beliebige Beschreibung, die vom Anwender eingegeben wird.
     * @param string    $in_sqlLanguage                             SQL-Dialekt, indem das Backup erstellt werden soll (postgresql|mysql)
     * @param array     $in_form                                    Array mit allen Meta- und Konfigurationsdaten des Formulars, indem der letzte Button geklickt wurde.
     * @param string    $in_safe_path                               relativer Name des Pfades, in dem die Ergebnisdatei abgelegt werden soll, beginnend mit /appms/... 
     * @param boolean   $in_log_backup                              gibt an, ob das Backup in der DB-Tabelle manager.backup geloggt werden soll.
     * @param object    $in_pagedata                                Referenz zum pagedata-object
     * @param boolean   $in_ignore_external_administrated_schema    Wenn true, werden Schemata, die app_schema.external_administrated = true haben, nicht gesichert. Diese Funktion ist für den Installer-Prozess notwendig, damit externe Schemata während des Update-Prozesses nicht gelöscht werden.
     * @param string    $in_filename_präfix                         [optional] Wenn angegeben, dann wird dieser String als Präfix beim Dateinamen der Backup-Datei verwendet
     * 
     * 
     */
    function __construct($in_app_id, $in_contenttype, $in_description, $in_sqlLanguage, $in_form, $in_safe_path, $in_log_backup, &$in_pagedata, $in_ignore_external_administrated_schema, $in_filename_präfix = "") {
        
        //Ausführungszeit für Skripte deaktivieren (Achtung: das funktioniert nur, wenn PHP nicht im SAFE-Mode-läuft. Ansonsten muss die Änderung in der php.ini erfolgen.)
        set_time_limit(0);
        
        //Backuptyp auswerten und auf dessen Basis festlegen, welche Daten gesichert werden müssen.
        $this->backup_mode = new backup_mode($in_contenttype);

        //backup-Daten zur Protokollierung der Metadaten erstellen
        $this->_starttime = date('Y-m-d H:i:s');;
        $this->app_id = $in_app_id;
        $this->_contenttype = $in_contenttype;
        $this->_description = $in_description;
        if($in_filename_präfix == "") { $praefix = date('Y-m-d_H-i-s');} else { $praefix = $in_filename_präfix;}
        $this->_name = $praefix."_".$this->app_id."_".$in_sqlLanguage;
        $this->safe_path = $in_safe_path;
        $this->_log_backup = $in_log_backup;
        $this->_ignore_external_administrated_schema =$in_ignore_external_administrated_schema;
        
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-Auftrag: ", "app_id: ".$this->app_id.", contenttype: ".$this->_contenttype.", sql_dialekt: ".$in_sqlLanguage);
        
        
        //Backup_Klasse für Target-DB in Abhängigkeit vom SQL-Dialekt laden.
        $this->_target_sql_language = $in_sqlLanguage;
        $target_backupclass_file = "../controller/backupcontroller/backup_".$this->_target_sql_language."_class.php";
        $this->_target_backup_class_namespace = $this->_target_sql_language."\\";   //PHP-Datei mit den dbms-spezifischen Klassen muss den entsprechenden namespace enthalten/deklarieren
        if(file_exists($target_backupclass_file) == true) {
            $this->_target_backup_class_file = $target_backupclass_file;
            require_once($this->_target_backup_class_file);
            $target_class = $this->_target_backup_class_namespace."backup_helper";
            $target_backup_class = new $target_class();
            $this->_target_backup_class = $target_backup_class;
            $this->_DBMS_Config_params = $target_backup_class->getInitialConfigparamsForDBMS();
            $this->_DBMS_Config_params_reset = $target_backup_class->resetInitialConfigparamsForDBMS();
            $this->_target_note = $target_backup_class->getNotesForDBMS();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-TargetClass geladen ", $target_class, "INFO");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-Klasse existiert nicht! ", $target_backupclass_file, "ERROR");
        }
        
        
        //Backup_Klasse für Source-DB in Abhängigkeit vom SQL-Dialekt der App-ID für welches das Backup erstellt werden soll
        $this->_source_sql_language = getValueFromConfigXml($in_app_id, "dbms");
        $source_class = $this->getDbmsBackupclassname($in_app_id);
        if($source_class <> false) {
            $source_class = $source_class."backup_helper";
            $source_backup_class = new $source_class();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-SourceClass geladen ", $source_class, "INFO");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-Klasse existiert nicht! ", $source_class, "ERROR");
        }
        
        
        
        //Liste der Schemata der zu sichernden APP ermitteln
        $this->_app_schema_list =  $this->getSchemaList($this->app_id);
        $this->_app_schema_list_with_owner = $this->getSchemaOwner($this->_app_schema_list);
        

        
        //Die zu sichernden Daten der App auslesen (Backupdaten)
        $this->read_appdata($target_backup_class, $source_backup_class);
        
        //Backupdaten in eine Datei schreiben
        $this->write_backup();
        
        
        //Metadaten in DB-Tabelle backup eintragen
        if($this->_log_backup == true) {$this->logBackup($in_form, $in_pagedata);}
        
    }
    
    
    /** Ermittelt alle zu sichernde Tabellen und Ihre Daten. Die Tabellen werden in $this->_tableObjects... abgelegt.
     * Außerdem werden alle Drop-, Create, Grant-, Delete- und Update-Befehle erstellt und in den Eigenschaften von $this abgelegt.
     * 
     * @param string $in_target_backup_class        Name der Backup-Klasse für das Ziel-DBMS
     * @param string $in_source_backup_class        Name der Backup-Klasse für das Quell-DBMS
     */
    protected function read_appdata($in_target_backup_class, $in_source_backup_class) {
        
        
        //DB-Strukturdaten (a)
            //Struktur-Tabellen der APP ermitteln
            $tablelist = $in_source_backup_class->getTablelistFromSchema($this->app_id, $this->_app_schema_list);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Tablelist', $tablelist);
            //Table-Objekte für alle Tabellen erzeugen
            $this->_tableObjects_structure = $this->createTableObjects($tablelist, $this->app_id, TableType::structure);
            $this->_dropTableCommands = $in_target_backup_class->createTableDropCommand($tablelist);
            $this->_updateSequenceCommandsForApptables = $in_target_backup_class->getUpdateSequenceCommands($this->app_id, $this->_app_schema_list);

            
            //views auslesen
            $this->_view_list = $in_source_backup_class->getViewlistFromSchema($this->app_id, $this->_app_schema_list);
            $this->_viewObjects = $this->createViewObjects($this->_view_list, $this->app_id);
            $this->_dropViewCommands = $in_target_backup_class->createViewDropCommand($this->_view_list);
            //materilized views auslesen (ist nicht für alle DBMS relevant)
            $this->_matview_list = $in_source_backup_class->getMatViewlistFromSchema($this->app_id, $this->_app_schema_list);
            $this->_matviewObjects = $this->createViewObjects($this->_matview_list, $this->app_id);
            $this->_dropMatViewCommands = $in_target_backup_class->createViewDropCommand($this->_matview_list);
            //mateialized views in views einsortieren
            $this->_mergedViewObjects = $this->mergeViewObjects($this->_viewObjects, $this->_matviewObjects);

            
            //Funktionen und Triggerdaten ermitteln
            $this->_function_list = $in_source_backup_class->getFunctionlistFromSchema($this->app_id, $this->_app_schema_list);
            $this->_functionObjects = $this->createFunctionObjects($this->_function_list, $this->app_id);
            $this->_dropFunctionCommands = $in_target_backup_class->createFunctionDropCommand($this->_function_list);
            $this->_trigger_list = $in_source_backup_class->getTriggerlistFromSchema($this->app_id, $this->_app_schema_list);
            $this->_create_trigger_commands = $in_target_backup_class->createTriggerCommand($this->_trigger_list);


            //Schemata (eigentlich nur bei $this->backup_mode->readAppStructure == true notwendig; kostet aber kaum Zeit)
            $this->_dropSchemaCommands = $in_target_backup_class->createSchemaDropCommand($this->_app_schema_list);
            $this->_createSchemaCommands = $in_target_backup_class->createSchemaCommand($this->_app_schema_list);
            $this->_grantSchemaCommands = $in_target_backup_class->createSchemaOwnerCommand($this->_app_schema_list_with_owner, $this->backup_mode->grantsToUser);


            

        
        //DB-Daten (b)
        if($this->backup_mode->readAppData == true) {
            //Daten-Tabellen der APP ermitteln
            $tablelist = $in_source_backup_class->getTablelistFromSchema($this->app_id, $this->_app_schema_list);
            //Table-Objekte für alle Tabellen erzeugen
            $this->_tableObjects_content = $this->createTableObjects($tablelist, $this->app_id, TableType::content); 
            //Delete-Befehle holen
            $this->_deleteContentTableCommands = $in_target_backup_class->getDeleteCommands($this->_tableObjects_content);
        }
        
        
        //Konfigurationsdaten (c)
        if($this->backup_mode->readAppConfig == true) {
            //Konfigurations-Tabellen ermitteln
            $tablelist = $this->getSpecialTablelist("configtable");
            //Table-Objekte für alle Tabellen erzeugen
            $this->_tableObjects_config = $this->createTableObjects($tablelist, global_variables::getAppIdFromSYS01(), TableType::config);             
            //Delete-Befehle für Configtabellen holen
            $this->_deleteConfigTableCommands = $in_target_backup_class->getDeleteCommands($this->_tableObjects_config);  
            //Update-Sequence-Befehle
            $kernel_schemalist = array();
            $kernel_schemalist[] = global_variables::getNameOfDbSchemaSYS01();
            $this->_updateSequenceCommandsForConfigtables = $in_target_backup_class->getUpdateSequenceCommands(global_variables::getAppIdFromSYS01(), $kernel_schemalist);
            
        }
        
        
        
        
        //DB-Daten - addContentDaten ergänzen   -> dieser Schritt darf erst nach c (Konfigurationsdaten) erfolgen, da es sonst zu Verletetzungen von Constraints kommen kann.
        if($this->backup_mode->readAppContentInKernel == true) {
            //Table-Objekte für alle Datentabellen erzeugen. Diese können sich nur im Kernmodul befinden. Es handelt sich um zentral bereitgestellte Datentabellen, wie bspw. logdata
            //Die Klasse Backup-Mode sollte sicherstellen, dass readAppData und readAppDataInKernel nie gleichzeitig true sind. Ansonsten kann es zu identischen Insert-Befehlen kommen.
            //betroffene Tabellen ermitteln
            $tablelist = $this->getSpecialTablelist("addIfContentBackupForApp");
            //Table-Objekte für alle Tabellen erzeugen
            $this->_tableObjects_addcontent = $this->createTableObjects($tablelist, global_variables::getAppIdFromSYS01(), TableType::addContent);
            
            //Delete-Befehle holen
            $this->_deleteAddTableCommands = $in_target_backup_class->getDeleteCommands($this->_tableObjects_addcontent);
            
            //Update Befehle für lokale Konfigurationsdaten übernehmen (backup_rewritecolumns
            $backupRewriteColumns = getBackupRewriteColumns(global_variables::getConnectionIdOfDbSchemaSYS01(), $this->app_id);
            $this->_updateConfigTableCommands = $in_target_backup_class->createUpdateCommand($backupRewriteColumns, $this->app_id);
        }
    }
    
    
    
    
    
    
    
    
    
    
    /** Ermittelt anhand einer App_id den korrekten DBMS-Konnektor, zum auslesen der Daten. Ggf. lädt die Funktion auch die entsprechende PHP-Datei, damit die Klassen genutzt werden kann.
     * 
     * @param   string  $in_app_id      App-ID der Tabelle
     * @return  string                  Name der Klasse, welche für die Tabellen der App-ID genutzt werden muss; Wenn die Klasse nicht vorhanden ist oder geladen werden konnte, wird "false" zurückgegeben
     */
    protected function getDbmsBackupclassname($in_app_id) {
    //Backup_Klasse für Source-DB in Abhängigkeit vom SQL-Dialekt der App-ID für welches das Backup erstellt werden soll
        $source_sql_language = getValueFromConfigXml($in_app_id, "dbms");
        $source_backupclass_file = "../controller/backupcontroller/backup_".$source_sql_language."_class.php";
        $source_backup_class_namespace = $source_sql_language."\\";   //PHP-Datei mit den dbms-spezifischen Klassen muss den entsprechenden namespace enthalten/deklarieren
        if(file_exists($source_backupclass_file) == true) {
            require_once($source_backupclass_file);
            $source_class = $source_backup_class_namespace;
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__."Lade DB-Class" ,$source_backupclass_file , "INFO");
            return $source_class;
        } else {
            return false; 
        }
    }
    
    
    
     
    /** Führt die Listen der viewObjects und der matViewObjects zusammen.
     * Dabei wird auf die notwendige Reihenfolge geachtet.
     * 
     * Es wird davon ausgegangen, dass die views bereits korrekt sortiert sind. Daher werden "nur" die 
     * materialized views an der richtigen Stelle einsortiert.
     * 
     * @param   array  $in_viewObjects      Liste der View-Objekte
     * @param   array  $in_matViewObjects   Liste der materialized-View-Objekte
     * @return  array                       zusamengeführte Liste
     */
    protected function mergeViewObjects($in_viewObjects, $in_matViewObjects) {
        $temp_newList = array();
        $mergedViewList = $in_viewObjects;
        
        
        //Schleife über alle materilized-views
        foreach ($in_matViewObjects as $matviewkey => $cur_matview) {
            $done = false;                          //kennzeichnet, ob die aktulle matview einsortiert wurde.
            foreach ($mergedViewList as $viewkey => $cur_view) {
                //Schleife über die aktuelle View-Liste. Diese kann auch bereits einsortierte matviews enthalten
                if(strpos($cur_view->getViewDefinition(), $cur_matview->name) !== false AND $done == false) {
                    //wenn materialized view in aktueller view verwendet wird, dann davor einsortieren
                    $temp_newList[$matviewkey] = $cur_matview;
                    $done = true;
                }                     
                $temp_newList[$viewkey] = $cur_view;
            }
            //wenn matview noch gar nicht einsortiert wurde, dann am Ende ergänzen
            if($done == false) {$temp_newList[$matviewkey] = $cur_matview;}
            $mergedViewList = $temp_newList;
        
        }

        return $mergedViewList;
    }
    
    
    
    
    /** Ermittelt anhand der app_id die Liste der zugehörigen Schemata und 
     * gibt diese in einem Array zurück
     * 
     * @param   string $in_app_id
     * @return  array               Liste der Schemata (Bsp.: array('Schema1', Schema2'))
     */
    protected function getSchemaList($in_app_id) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        
        $feedback = array();
        
        if ($this->_ignore_external_administrated_schema === true) {
            $condition = "app_id = '".$in_app_id."' AND (external_administrated <> 1 OR external_administrated is NULL)";
        } else {
            $condition = "app_id = '".$in_app_id."'";
        }
        
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> $condition: ", $condition, "INFO");
        $app_schemaList = getTableData($db_schema_manager_connection_id, "app_schema", $db_schema_manager, true, "", $condition, __FUNCTION__, 0, 0);
        
        
        if($app_schemaList <> false) {
            foreach ($app_schemaList as $key => $row) {
                $feedback[] = $row["app_schema.db_schema"];
            }
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup soll folgende Schemata sichern: ", $feedback, "INFO");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Für die app_id: ".$in_app_id." konnte kein Schema ermittelt werden!", "Kein Schema in app_id gefunden. Möglicherweise sind alle Schemata der Anwendung über app_schema.external_administrated von der Sicherung ausgeschlossen worden.", "INFO");
        }
        
        return $feedback;

    }
    
    
    /** Ermittelt den Owner eines Schemas
     * 
     * @param   string  $in_schemaList                      Eindimensionales Array mit den Namen der Schemata, deren Owner ermittelt werden sollen
     * @return  array                                       Eindimensionales Array mit den Schemanamen als key und den Owner als value\n
     *                                                      Bsp.: array("manager" => "myUser1", "app2" => "myUser2")
     */
    protected function getSchemaOwner($in_schemaList) {
        $db_schema_information = global_variables::getNameOfDbSchemaInformation(); 
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        $feedback = array();
        $currentOwner = "";
        
        foreach ($in_schemaList as $currentSchema) {
            $currentOwner = getDataFromTableByID($db_schema_manager_connection_id, $db_schema_information, "schemata", "schema_owner", "schema_name = '".$currentSchema."'");
            $feedback[$currentSchema] = $currentOwner;
        }
        
        
        
        return $feedback;

    }
    
    
    
    /** ermittelt aus dem Schema des Kernmoduls (i.d.R. manager) alle Tabellen, die in der Tabelle backup_tabledefinitions als "configtable" definiert sind.
     * 
     * @param   string  $in_tabletype           Gibt die Art der Spezialtabellen, die ermittelt werden sollen, siehe manager.backup_tabledefinitions.definition.
     *                                          Mögliche Werte [ configtable | addIfContentBackupForApp ] 
     *                                          
     * @return  array                           Array enthält pro Konfigurationstabelle ein internes Array mit den Keys:
     *                                          $array["tables.table_schema"]
     *                                          $array["tables.table_name"]
     *                                          $array["tables.table_type"]
     *                                          $array["tables.app_column"]
     *                                          $array["tables.sort"]
     * 
     */
    function getSpecialTablelist($in_tabletype) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

        
        $queryRequest = new sql_request($db_schema_manager_connection_id, getActiveRoleData()["role.app_id"],getActiveRoleData()["role.id"], __FUNCTION__);
            $queryRequest->addSelectColumn("backup_tabledefinitions", "id");
            $queryRequest->addSelectColumn("backup_tabledefinitions", "app_id");
            $queryRequest->addSelectColumn("backup_tabledefinitions", "tablename");
            $queryRequest->addSelectColumn("backup_tabledefinitions", "app_column");
            $queryRequest->addSelectColumn("backup_tabledefinitions", "sort");
            $queryRequest->addSelectColumn("backup_tabledefinitions", "definition");
            $queryRequest->addTable($db_schema_manager, "backup_tabledefinitions", 1, "BASE");
            $queryRequest->addWhereCondition("AND", "", "backup_tabledefinitions", "definition", "=", "'$in_tabletype'", "");
            $queryRequest->addOrderbyPart("backup_tabledefinitions.sort");
        $result = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
        
        if($result == FALSE) {
            $feedback = array();
        } else {
            //Ergebnismenge so umwandeln, dass die keys äquivalent zur Funktion getTablelistFromSchema vergeben werden.
            foreach ($result as $row) {
                //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> row in result', $row);
                $newrow = array();
                $newrow["tables.table_schema"] = $db_schema_manager;
                $newrow["tables.table_name"] = $row["backup_tabledefinitions.tablename"];
                $newrow["tables.table_type"] = "BASE TABLE";
                $newrow["backup_tabledefinitions.app_column"] = $row["backup_tabledefinitions.app_column"];
                $newrow["tables.sort"] = $row["backup_tabledefinitions.sort"];
                $newrow["backup_tabledefinitions.definition"] = $row["backup_tabledefinitions.definition"];
                $feedback[] = $newrow;
            }
        }
        
        return $feedback;
        
        
    }
    
    
    
    
    
    /** Fügt in die DB-Tabelle "backup" einen Datensatz mit den Metadaten ein.
     * 
     * @param   object      $in_pagedata                Referenz zum pagedata-object
     * @param   array       $in_form                    Array des sendenden Formulars
     */
    protected function logBackup($in_form, &$in_pagedata) {
        $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
        
        $SqlArray = array();
        
        $SqlArray["schema"] = $db_schema_manager;
        $SqlArray["table"] = "backup";
	$SqlArray["into"] = "app_id, name, description, pathname, filename, starttime, endtime, filesize, contenttype, sql_language";
	$SqlArray["values"] =   "'".$this->app_id."'".
                                ", '".$this->_name."'".
                                ", '".$this->_description."'".
                                ", '".$this->_pathname."'".
                                ", '".$this->_filename."'".
                                ", '".$this->_starttime."'".
                                ", '".$this->_endtime."'".
                                ", '".$this->_filesize."'".
                                ", '".$this->_contenttype."'".
                                ", '".$this->_target_sql_language."'";
        
        $feedback = insertDataIntoDB($SqlArray, $in_form, session_class::$session_object->getUid(), $in_pagedata);
        
        
    }
    
    
    
    
   
   
    
    /** Erstellt für jede Tabelle in der tablelist einen Create-Befehl
     * 
     * @param   array   $in_tablelist           Liste der Tabelle
     * @param   string  $in_schema_app_id       ID der App, in dessen Schema die Tabellen zu finden sind.
     * @param   string  $in_tableType   frei wählbare Bezeichnung der tablelist, die in der debug-Tabelle verwendet wird.
     * @return  array                           Liste mit Tabellenobjekten
     */
    private function createTableObjects($in_tablelist, $in_schema_app_id, $in_tableType) {
        $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        $feedback = array(); 
        $is_configtable = false;
        $is_contentTable = false;
        $is_addContentTable = false;
        $is_structureTable = false;
      
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Tablelist für Backup! : ".$in_tableType, $in_tablelist, "INFO");
        
        foreach ($in_tablelist as $key => $table) {
            //ACHTUNG: In diesem Abschnitt wird nur entschieden, ob Commands erstellt werden. Ob diese auch im Backup
            //angedruckt werden, entscheidet die Methode write_backup.
            if($in_tableType == TableType::config) {$is_configtable = true;}
            elseif($in_tableType == TableType::content) {$is_contentTable = true;}
            elseif($in_tableType == TableType::structure) {$is_structureTable = true;}
            elseif($in_tableType == TableType::addContent) {$is_addContentTable = true;}
            
            
            
            //wenn die Spalte app_column vorhanden ist, handelt es sich um eine Konfigurationstabelle, deren zu sichernden Daten  auf die app_id eingeschränkt werden soll.
            if($is_configtable == true OR $is_addContentTable == true) {
                $insert_condition = $this->getAppConditionForDataInKernelSchema($this->backup_mode->handleSysFlag, $table);
                $connection_id = $db_schema_manager_connection_id;
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> ", "backup_tabledefinitions.definition = ".$table["backup_tabledefinitions.definition"]." - condition = ".$insert_condition, "INFO");
            } elseif($is_contentTable == true OR $is_structureTable == true) {
                //Daten stammen aus einer Tabelle des Schemas der zu sichernden app
                $insert_condition = "";
                $connection_id = $this->app_id;
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> ", "backup_tabledefinitions.definition = ".$table["tables.table_name"], "INFO");
            }
            
            //Daten aus Source-DBMS ermitteln
            $source_class = $this->getDbmsBackupclassname($in_schema_app_id);
            if($source_class <> false) {
                $source_class = $source_class."backupTable";
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-Klasse ", $source_class." - notwendig für Tabelle ".$table["tables.table_name"], "INFO");
                //$mySourceTable = new $source_class();
                $mySourceTable = new postgresql\backupTable();
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-Klasse existiert nicht! ", $source_class." - notwendig für Tabelle ".$table["tables.table_name"], "ERROR");
            }
            
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Connection-ID für Tabelle: ".$table["tables.table_name"], $connection_id, "INFO");
            $mySourceTable->initializeAsSourceTable($connection_id, $table, $is_structureTable, $is_configtable, $is_addContentTable, $is_contentTable); 
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup Tabellendaten gelesen für:", $table, "INFO");
            
            //SQL-Befehle für Target-DBMS erstellen
            $target_class = $this->_target_backup_class_namespace."backupTable";        //target_class kommt aus einem anderen namespace und wird deshalb so umständlich aufgerufen
            $myTable = new $target_class();
            $myTable->initializeAsTargetTable($mySourceTable, $insert_condition, $this);
            $feedback[$table["tables.table_schema"]."_".$table["tables.table_name"]] = $myTable;
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup Tabellendaten erstellt für:", $table, "INFO");
        }
        
        return $feedback;
    }
    
    
    
    
    /** Erstellt für jede view in der viewList  einen View-Object inkl, Grant- und Create-Befehle
     * 
     * @param   array   $in_viewlist            Liste der views
     * @param   string  $in_schema_app_id       ID der App, in dessen Schema die views zu finden sind.
     * @return  array                           Liste mit Tabellenobjekten
     */
    private function createViewObjects($in_viewlist, $in_schema_app_id) {
        $feedback = array(); 
        $connection_id = $this->app_id;
      
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> viewlist für Backup! : ", $in_viewlist, "INFO");
        
        foreach ($in_viewlist as $key => $view) {
            
            
            //Daten aus Source-DBMS ermitteln
            $source_class = $this->getDbmsBackupclassname($in_schema_app_id);
            if($source_class <> false) {
                $source_class = $source_class."backupTable";
                $myView = new $source_class();
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-Klasse existiert nicht! ", $source_class." - notwendig für View ".$view, "ERROR");
            }
            
            
            $myView->initializeAsView($connection_id, $view, $this); 
            $feedback[$view["views.view_schema"]."_".$view["views.view_name"]] = $myView;
        }
        
        return $feedback;
    }
    
    
    
    /** Erstellt für jede function in der functionList  einen Function-Object inkl, Grant- und Create-Befehle
     * 
     * @param   array   $in_functionlist            Liste der views
     * @param   string  $in_schema_app_id           ID der App, in dessen Schema die views zu finden sind.
     * @return  array                               Liste mit Functionobjekten
     */
    private function createFunctionObjects($in_functionlist, $in_schema_app_id) {
        $feedback = array(); 
        $connection_id = $this->app_id;
      
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> functionlist für Backup! : ", $in_functionlist, "INFO");
        
        foreach ($in_functionlist as $key => $function) {
            
            
            //Daten aus Source-DBMS ermitteln
            $source_class = $this->getDbmsBackupclassname($in_schema_app_id);
            if($source_class <> false) {
                $source_class = $source_class."backupTable";
                $myFunction = new $source_class();
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-Klasse existiert nicht! ", $source_class." - notwendig für Function ".$function, "ERROR");
            }
            
            
            $myFunction->initializeAsFunction($connection_id, $function, $this); 
            $feedback[$function["function.schema"]."_".$function["function.name"]] = $myFunction;
        }
        
        return $feedback;
    }
    
    
    /** Ermittelt die Condition für Daten, die im Kernel-Schema abgelegt sind
     * 
     * @param   $in_handleSysFlag   backup_mode->handleSysFlag 
     * @param   $in_table           Array der zu sichernden Tabelle  
     * @return  string              SQL-Condition
     */
    private function getAppConditionForDataInKernelSchema($in_handleSysFlag, $in_table) {
        if($in_handleSysFlag == "notSystemData") {
            //Es sollen alle APP-Daten, die nicht als Systemdatensatz gekennzeichnet sind (sys <> 1)
            //sowie die Daten aller anderen APP's im Schema des Kernsystems gesichert werden.
            $insert_condition = $in_table["backup_tabledefinitions.app_column"]." <> '".$this->app_id."' OR (".$in_table["backup_tabledefinitions.app_column"]." = '".$this->app_id."' AND (sys <> 1 OR sys is null))";
      
        } elseif($in_handleSysFlag == "onlySystemData") { 
            //Es sollen alle Daten der aktuell zu sichernden APP, die im Schema des Kernmoduls abgelegt und das Kennzeichen sys = 1 tragen, gesichert werden.
            $insert_condition = $in_table["backup_tabledefinitions.app_column"]." = '".$this->app_id."' AND  sys = 1";

        } else {
            //Daten stehen in einer Tabelle eines anderen Moduls (i.d.R. SYS01). Jeder Datensatz in dieser Tabelle hat jedoch einen Verweis auf die richtige App_ID.
            //Das Backup soll aus diesen Tabellen nur die Daten, die der zu sichernden APP zuzuordnen sind, auslesen.
            $insert_condition = $in_table["backup_tabledefinitions.app_column"]." = '".$this->app_id."'";
        }
        
        return $insert_condition;
    }
    
    
    
    
    
    /** Funktion entscheidet in Abhängigkeit von dem Source- und Target-DBMS,
     * ob die Dbms-SET-Parameter am Anfang eines SQL-Skriptes gesetzt werden können.
     * 
     * @param   string  $in_source_dbms     Name des Source-DBMS
     * @param   string  $in_target_dbms     Name des Target-DBMS
     * @return  boolean                     true or false
     */
    function setDbmsParams($in_source_dbms, $in_target_dbms) {
        $feedback = false;
        
        if($in_source_dbms == "postgresql") {
            if($in_target_dbms == "postgresql") {$feedback = false;}             //Parameter müssen nicht gesetzt werden, da Tabellen in der richtigen Reihenfolge bearbeitet werden. 
            elseif($in_target_dbms == "mysql") {$feedback = true;}                 //Parameter können gesetzt werden, sind aber scheinbar weder notwendig, noch schädlich
            else {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> unbekanntes Ziel-DBMS: ".$in_target_dbms, "Function checkDbmsSetParams muss erweitert werden.", "ERROR");}
        } elseif($in_source_dbms == "mysql") {
            if($in_target_dbms == "postgresql") {$feedback = true;}              //Parameter müssen gesetzt werden, da Constraints sonst Fehler verursachen
            elseif($in_target_dbms == "mysql") {$feedback = true;}                 //Parameter können gesetzt werden, sind aber scheinbar weder notwendig, noch schädlich
            else {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> unbekanntes Ziel-DBMS: ".$in_target_dbms, "Function checkDbmsSetParams muss erweitert werden.", "ERROR");}
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> unbekanntes DBMS: ".$in_source_dbms, "Function checkDbmsSetParams muss erweitert werden.", "ERROR");
        }
        
        return $feedback;
    }


    /** Erstellt einen String, der $in_topic als Überschrift nutzt und anschließend alle sqlCommands 
     * mit Zeilenumbruch aneinander reiht.
     * 
     * @param  string   $in_topic           Text, der als Überschrift genutzt werden soll
     * @param  array    $in_sqlCommands     Liste von SQL-Commands
     * @return string                       
     */
    private function getSqlPart($in_topic, $in_sqlCommands) {
        $feedback = "";
        if($in_sqlCommands != array()) {
    //        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-write ", $in_topic, "INFO");
            $feedback = $feedback."-- ".$in_topic."--------------\n";
            $feedback = $feedback.implode(";\n", $in_sqlCommands).";\n";
            $feedback = $feedback."\n\n\n";
        }
        
        return $feedback;
    }
    




    /**
     * schreibt alle Backupdaten in eine Datei und legt diese im Filesystem ab.
     */
    function write_backup() { 
        $backup_data = "";
       
        // SQL-SET-Befehle
        if(isset($this->_DBMS_Config_params) AND $this->setDbmsParams($this->_source_sql_language, $this->_target_sql_language)) {
            $backup_data = $backup_data.$this->getSqlPart("SET-Anweisungen", $this->_DBMS_Config_params);
        }
        
        //Drop-Constraint-Befehle bei config und add_content-Tabellen (Tabellen in manager)
        //      Drop-Constraint-Befehle  -> muss als erstes  erfolgen, da sonst INSERT-Anweisungen scheitern könnten
        foreach ($this->_tableObjects_config as $myTable) {
            if($this->backup_mode->drop_constraints == true) {
                $backup_data = $backup_data.$this->getSqlPart("Drop-Constraint-commands für config-table ".$myTable->name, $myTable->getDropConstraintCommand());
            }
        }
        foreach ($this->_tableObjects_addcontent as $myTable) {
            if($this->backup_mode->drop_constraints == true) {
                $backup_data = $backup_data.$this->getSqlPart("Drop-Constraint-commands für addcontent-table ".$myTable->name, $myTable->getDropConstraintCommand());
            }
        }

        //Drop-Constrain-Befehle bei content-Tabellen (Tabellen in der jeweiligen APP)
        foreach ($this->_tableObjects_content as $myTable) {
            if($this->backup_mode->drop_constraints == true) {
                $backup_data = $backup_data.$this->getSqlPart("Drop-Constraint-commands für content-table ".$myTable->name, $myTable->getDropConstraintCommand());
            }
        }
        //Constraints bei structure-Tabellen wieder aktivieren, hier jedoch nur außerhalb des Manager-Schema (Tabellen in dem jeweiligen APP-Schema)
        foreach ($this->_tableObjects_structure as $myTable) {
            if($this->backup_mode->drop_constraints == true AND $this->backup_mode->type == 111) {
                $backup_data = $backup_data.$this->getSqlPart("Drop-Constraint-commands für structure-table ".$myTable->name, $myTable->getDropConstraintCommand());
            }
        }
        
//        // Drop-Schema-Befehle
//        // HINWEIS: Dieser Abschnitt ist sehr gefährlich, da durch Drop-Schema auch alle Tabellen im betroffenen Schema, welche nicht durch AppMS verwaltet werden, gelöscht werden.
//        if(isset($this->_dropSchemaCommands) and $this->backup_mode->create_schema == true) {
//            $backup_data = $backup_data.$this->getSqlPart("DROP-SCHEMA-Anweisungen", $this->_dropSchemaCommands);
//        }
        
        // CREATE-Schema-Befehle
        if(isset($this->_createSchemaCommands) and $this->backup_mode->create_schema == true) {
            $backup_data = $backup_data.$this->getSqlPart("CREATE-SCHEMA-Anweisungen", $this->_createSchemaCommands);
            if($this->_source_sql_language <> "mysql") {$backup_data = $backup_data.$this->getSqlPart("CREATE-GRANT-Anweisungen für Schema", $this->_grantSchemaCommands);}             //In mysql wird kein Schema/Database-owner verwaltet. 
        }
        
        // Drop-Table-Befehle (inkl. views, functions und trigger)
        if(isset($this->_dropTableCommands) and $this->backup_mode->drop_tables == true) {
            $backup_data = $backup_data.$this->getSqlPart("Drop-Table-Anweisungen", $this->_dropTableCommands);
            $backup_data = $backup_data.$this->getSqlPart("Drop-View-Anweisungen", $this->_dropViewCommands);
            $backup_data = $backup_data.$this->getSqlPart("Drop-materialized View-Anweisungen (DB-spezifisch)", $this->_dropMatViewCommands);
            $backup_data = $backup_data.$this->getSqlPart("Drop-Function-Anweisungen", $this->_dropFunctionCommands);
        }

        // 2. Tabbellenobjekte andrucken (welche SQL-Anweisungen pro Tabelle angedruckt werden, wird in der Methode getTableCommands entschieden.
        $backup_data = $backup_data.$this->getTableCommands($this->_tableObjects_structure, TableType::structure);
        $backup_data = $backup_data.$this->getTableCommands($this->_tableObjects_config, TableType::config);
        $backup_data = $backup_data.$this->getTableCommands($this->_tableObjects_content, TableType::content);
        $backup_data = $backup_data.$this->getTableCommands($this->_tableObjects_addcontent, TableType::addContent);
        
        
        //3. Backup-Rewrite-Befehle für Daten, welche im Falle eines Updates, von der lokalen Installation übernommen werden müssen
        if($this->backup_mode->readAppContentInKernel == true AND $this->_updateConfigTableCommands <> array()) {
            $backup_data = $backup_data.$this->getSqlPart("Update-Anweisungen für Config-Tables zur Übernahme von lokalen Konfigurationen", $this->_updateConfigTableCommands);
        }
        
        
        //4. Noch einmal Schleife über alle Table-Objekte
        if($this->app_id == global_variables::getAppIdFromSYS01()) {
            //In der Kernelapp wären Structure- und Config-Tabellen identisch. 
            foreach ($this->_tableObjects_structure as $myTable) {
                //      3.1 ALTER-Table-Befehle  -> muss als letztes erfolgen, da sonst INSERT-Anweisungen scheitern könnten
                if($this->backup_mode->add_constraints == true AND $myTable->is_structureTable == true) {
                    $backup_data = $backup_data.$this->getSqlPart("ALTER-Table-commands für structure-table ".$myTable->name, $myTable->getCreateConstraintCommand());
                }
            }
        
        } else {
            //Constraints bei config und add_content-Tabellen wieder aktivieren (Tabellen in manager)
            foreach ($this->_tableObjects_config as $myTable) {
                if($this->backup_mode->add_constraints == true) {
                    $backup_data = $backup_data.$this->getSqlPart("Add-Constraint-commands für config-table ".$myTable->name, $myTable->getCreateConstraintCommand());
                }
            }
            foreach ($this->_tableObjects_addcontent as $myTable) {
                if($this->backup_mode->add_constraints == true) {
                    $backup_data = $backup_data.$this->getSqlPart("Add-Constraint-commands für addcontent-table ".$myTable->name, $myTable->getCreateConstraintCommand());
                }
            }

            //Constraints bei content-Tabellen wieder aktivieren (Tabellen in der jeweiligen APP)
            foreach ($this->_tableObjects_content as $myTable) {
                if($this->backup_mode->add_constraints == true ) {
                    $backup_data = $backup_data.$this->getSqlPart("Add-Constraint-commands für content-table ".$myTable->name, $myTable->getCreateConstraintCommand());
                }
            }
             //Constraints bei structure-Tabellen wieder aktivieren, hier jedoch nur außerhalb des Manager-Schema (Tabellen in dem jeweiligen APP-Schema)
            foreach ($this->_tableObjects_structure as $myTable) {
                if($this->backup_mode->add_constraints == true AND $this->backup_mode->type == 111) {
                    $backup_data = $backup_data.$this->getSqlPart("Add-Constraint-commands für structure-table ".$myTable->name, $myTable->getCreateConstraintCommand());
                }
            }
        }
        
        //views, functions und triggererneuern 
        if($this->backup_mode->readAppStructure == true) {
            $backup_data = $backup_data.$this->getViewCommands($this->_mergedViewObjects);
            $backup_data = $backup_data.$this->getFunctionCommands($this->_functionObjects);
            $backup_data = $backup_data.$this->getSqlPart("Create-Trigger-Anweisungen", $this->_create_trigger_commands);
        }
        
        
        //Dateieigenschaften
        $this->_endtime = date('Y-m-d H:i:s');
        

        // Pfad zum Backup 
        $path_relative = $this->safe_path;
       
       
        
        // Metadaten zum Backup ergänzen 
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Backup-write 5 ", "Metadaten", "INFO");
        $backup_data = $this->printMetadata().$backup_data;
        

        // SQL-SET-Befehle reseten
        if(isset($this->_DBMS_Config_params_reset) AND $this->setDbmsParams($this->_source_sql_language, $this->_target_sql_language) == true) {
            $backup_data = $backup_data.$this->getSqlPart("Reset-Anweisungen für die DB", $this->_DBMS_Config_params_reset);
        }
        
        
        //Daten in eine Datei schreiben
        $myfile = writeZipFile($backup_data, $path_relative, true, $this->_name.".sql", __FUNCTION__);

        //Metadaten ergänzen
        $this->_pathname = $path_relative;
        $this->_filename = $myfile["filename"];
        $this->_filesize = $myfile["filesize"];

    } 
    
    

    /** Übergibt die notwendigen SQL-Befehle für alle Tabellen der übergebenen Liste
     * 
     * @param   array   $in_tablelist   Liste der Table-Objekte
     * @param   string  $in_modus       Eigenschaft der Klasse TableType, die angibt, ob die SQL-Anweisungen für den Modus content, config, structure usw. übergeben werden sollen.
     * @return string
     */
    private function getTableCommands($in_tablelist, $in_modus) {
        $backup_data = "";        
        
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
        $backup_data = $backup_data."-- Abschnitt: ".$in_modus."\n";
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n\n\n";
        
        
        //Delete-From-Table-Commands
        if      ($in_modus == TableType::addContent 
                AND $this->backup_mode->type != 102) {if($this->_deleteAddTableCommands <> array())     {$backup_data = $backup_data.$this->getSqlPart("DELETE-Anweisungen für Add-Tables", $this->_deleteAddTableCommands);}}
        elseif  ($in_modus == TableType::content)    {if($this->_deleteContentTableCommands <> array()) {$backup_data = $backup_data.$this->getSqlPart("DELETE-Anweisungen für Content-Tables", $this->_deleteContentTableCommands);}}
        elseif  ($in_modus == TableType::config)     {if($this->_deleteConfigTableCommands <> array())  {$backup_data = $backup_data.$this->getSqlPart("DELETE-Anweisungen für Config-Tables", $this->_deleteConfigTableCommands);}}
         
        
        // 2. Schleife über alle Tabellenobjekte
        foreach ($in_tablelist as $myTable) {
            //      2.0 Vorlauf für aktuelle Tabelle
            $backup_data = $backup_data."-- ------------------------------------\n";
            $backup_data = $backup_data."-- Abschnitt: ".$in_modus."\n";
            $backup_data = $backup_data."-- Table: ".$myTable->name."\n";
            $backup_data = $backup_data."-- is_structureTable: ".$myTable->is_structureTable."\n";
            $backup_data = $backup_data."-- is_contentTable: ".$myTable->is_contentTable."\n";
            $backup_data = $backup_data."-- is_configTable: ".$myTable->is_configTable."\n";
            $backup_data = $backup_data."-- is_addContentTable: ".$myTable->is_addContentTable."\n";
            $backup_data = $backup_data."-- ------------------------------------\n\n\n";
            
            
            //      2.1 CreateTable-Befehle ausgeben (für Structure = Contenttabellen); + GRANT- und INDEX-Befehle
            if($in_modus == TableType::structure AND $this->backup_mode->readAppStructure == true AND $myTable->is_structureTable == true) {
                $backup_data = $backup_data.$myTable->getCreateTableCommand().";\n\n";
                $backup_data = $backup_data.$this->getSqlPart("GrantCommands for table ", $myTable->getGrantCommands());
                $backup_data = $backup_data.$this->getSqlPart("CREATE-INDEX-Commands for table ".$myTable->name, $myTable->getCreateIndexCommand());
            }
            //      2.2a INSERT-Befehle, für Content-Tabellen (ToDo: eventuell mit Anlegen des nextvalue (Bsp. postgres: SELECT pg_catalog.setval('verfahren_id_seq', 23, true);)
            if($in_modus == TableType::content AND $this->backup_mode->readAppData == true AND $myTable->is_contentTable == true) {
                $backup_data = $backup_data.$this->getSqlPart("INSERT-Commands for table ".$myTable->name, $myTable->getInsertCommands());
                $backup_data = $backup_data.$this->getSqlPart("GrantCommands for table ", $myTable->getGrantCommands());
            }
            //      2.2b INSERT-Befehle, für Konfigurationstabellen 
            if($in_modus == TableType::config AND $this->backup_mode->readAppConfig == true AND $myTable->is_configTable == true) {
                $backup_data = $backup_data.$this->getSqlPart("INSERT-Commands for table ".$myTable->name, $myTable->getInsertCommands());
                $backup_data = $backup_data.$this->getSqlPart("GrantCommands for table ", $myTable->getGrantCommands());
            }
            //      2.2c INSERT-Befehle, für AddContent-Tabellen, aber nicht bei Backup-modus = 102
            if($in_modus == TableType::addContent AND $this->backup_mode->readAppData == true AND $myTable->is_addContentTable == true AND $this->backup_mode->type != 102) {
                $backup_data = $backup_data.$this->getSqlPart("INSERT-Commands for table ".$myTable->name, $myTable->getInsertCommands());
            }
            //      2.2d INSERT-Befehle, für AddContent-Tabellen, nicht Content (um Doppelungen zu vermeiden), aber readAppContentinKernel. Dieser Fall tritt theoretisch nur bei Backup 102 auf. Dabei werden die Update-Befehle geschrieben.
            //      (ToDo: dieser Abschnitt sollte reorganisiert werden.  Für Update-Befehle sollte es eine eigene Eigenschaft in backup_mode geben.)
            if($in_modus == TableType::addContent AND $this->backup_mode->readAppData == false AND $this->backup_mode->readAppContentInKernel == true AND $myTable->is_addContentTable == true) {
                $backup_data = $backup_data.$this->getSqlPart("INSERT-Commands for table ".$myTable->name, $myTable->getInsertCommands());
            }
            //      2.2e INSERT-Befehle, für Content-Tabellen (nur für SYS01, während des Update-Prozesses. Sorgt dafür, dass auch die Daten der addContent-Tabellen im Kernelschema ausgegeben werden.)
            if($in_modus == TableType::content AND $this->backup_mode->readAppData == true AND $this->app_id == global_variables::getAppIdFromSYS01()
                    AND $this->backup_mode->type == 102
                    AND $myTable->is_contentTable == false 
                    AND $myTable->is_configTable == false 
                    AND $myTable->is_addContentTable == false
                    AND $myTable->is_structureTable == false) {
                $backup_data = $backup_data.$this->getSqlPart("INSERT-Commands for table ".$myTable->name, $myTable->getInsertCommands());
            }
            
            

        }
        
        
        //Update-Commands mit Sequencen
        if      ($in_modus == TableType::addContent) {
            if($this->_updateSequenceCommandsForConfigtables <> array() and $this->backup_mode->readAppContentInKernel == true)     {
                $backup_data = $backup_data.$this->getSqlPart("Update-Sequence-Commands ", $this->_updateSequenceCommandsForConfigtables);
            }
        } elseif  ($in_modus == TableType::content)    {
            if($this->_updateSequenceCommandsForApptables <> array() and $this->backup_mode->readAppData == true) {
                $backup_data = $backup_data.$this->getSqlPart("Update-Sequence-Commands ", $this->_updateSequenceCommandsForApptables);
            }
        } elseif  ($in_modus == TableType::config)     {
            if($this->_updateSequenceCommandsForConfigtables <> array() and $this->backup_mode->readAppConfig == true) {
                $backup_data = $backup_data.$this->getSqlPart("Update-Sequence-Commands ", $this->_updateSequenceCommandsForConfigtables);
            }
        }
        
        
        return $backup_data;
    }
    
    
    
    
    
    /** Übergibt die notwendigen SQL-Befehle für alle Views der übergebenen Liste
     * 
     * @param   array   $in_viewObjectlist    Liste der View-Objekte
     * @return string
     */
    private function getViewCommands($in_viewObjectlist) {
        $backup_data = "";        
        
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
        $backup_data = $backup_data."-- Abschnitt: views \n";
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n\n\n";
        
        
        
        
        // Schleife über alle View-Objekte
        foreach ($in_viewObjectlist as $myView) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> myView ", $myView, "INFO");
            //      2.0 Vorlauf für aktuelle View
            $backup_data = $backup_data."-- ------------------------------------\n";
            $backup_data = $backup_data."-- Abschnitt: views \n";
            $backup_data = $backup_data."-- View: ".$myView->name."\n";
            $backup_data = $backup_data."-- ------------------------------------\n\n\n";
            
            
            $backup_data = $backup_data.$myView->getCreateViewCommand().";\n\n";
            $backup_data = $backup_data.$this->getSqlPart("GrantCommands for view ", $myView->getGrantCommands());
            $backup_data = $backup_data.$this->getSqlPart("CREATE-INDEX-Commands for matview ".$myView->name, $myView->getCreateIndexCommand());
        }

        return $backup_data;
    }
    
    
    
    
    /** Übergibt die notwendigen SQL-Befehle für alle Functions der übergebenen Liste
     * 
     * @param   array   $in_FunctionObjectlist    Liste der Function-Objekte
     * @return string
     */
    private function getFunctionCommands($in_FunctionObjectlist) {
        $backup_data = "";        
        
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
        $backup_data = $backup_data."-- Abschnitt: Functions \n";
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
        $backup_data = $backup_data."-- -------------------------------------------------------------------\n\n\n";
        
        
        
        
        // Schleife über alle Function-Objekte
        foreach ($in_FunctionObjectlist as $myFunction) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> myFunction ", $myFunction, "INFO");
            //      2.0 Vorlauf für aktuelle Function
            $backup_data = $backup_data."-- ------------------------------------\n";
            $backup_data = $backup_data."-- Abschnitt: Functions \n";
            $backup_data = $backup_data."-- View: ".$myFunction->name."\n";
            $backup_data = $backup_data."-- ------------------------------------\n\n\n";
            
            
            $backup_data = $backup_data.$myFunction->getCreateFunctionCommand().";\n\n";
            $backup_data = $backup_data.$this->getSqlPart("GrantCommands for function ", $myFunction->getGrantCommands());
            
        }

        return $backup_data;
    }
    
    
    
//     /** Übergibt die notwendigen SQL-Befehle für alle Views der übergebenen Liste
//     * 
//     * @param   array   $in_viewObjectlist    Liste der View-Objekte
//     * @return string
//     */
//    private function getViewCommands($in_viewObjectlist) {
//        $backup_data = "";        
//        
//        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
//        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
//        $backup_data = $backup_data."-- Abschnitt: views \n";
//        $backup_data = $backup_data."-- -------------------------------------------------------------------\n";
//        $backup_data = $backup_data."-- -------------------------------------------------------------------\n\n\n";
//        
//        
//        
//        
//        // Schleife über alle Tabellenobjekte
//        foreach ($in_viewObjectlist as $myView) {
////            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> myView ", $myView, "INFO");
//            //      2.0 Vorlauf für aktuelle View
//            $backup_data = $backup_data."-- ------------------------------------\n";
//            $backup_data = $backup_data."-- Abschnitt: views \n";
//            $backup_data = $backup_data."-- View: ".$myView->name."\n";
//            $backup_data = $backup_data."-- ------------------------------------\n\n\n";
//            
//            
//            $backup_data = $backup_data.$myView->getCreateViewCommand().";\n\n";
//            $backup_data = $backup_data.$this->getSqlPart("GrantCommands for view ", $myView->getGrantCommands());
//            
//        }
//
//        return $backup_data;
//    }
    
   
    
    
    /**
     * 
     * @return      string          Metadaten in Druckbarer Form
     */
    function printMetadata() {
        $meta_data = "-- APP: ".$this->app_id."\n";
        $meta_data = $meta_data."-- Mode: ".$this->_contenttype."\n";
        $meta_data = $meta_data."-- Date: ".date('Y-m-d')."\n";
        $meta_data = $meta_data."-- Start: ".$this->_starttime."\n";
        $meta_data = $meta_data."-- End: ".$this->_endtime."\n";
        $meta_data = $meta_data."-- Source-DBMS: ".$this->_source_sql_language."\n";
        $meta_data = $meta_data."-- Target-DBMS: ".$this->_target_sql_language."\n";
        $meta_data = $meta_data."\n";
        $meta_data = $meta_data."-- Description: ".$this->_description."\n";
        $meta_data = $meta_data."\n";
        if ($this->_target_note<>"") {$meta_data = $meta_data."-- Notes!!!: ".$this->_target_note."\n";}
        $meta_data = $meta_data."\n\n";
        
        return $meta_data;
    }
    
    
    
    
    
    
    /** Erzeugt in Drop-Table-Commands in der gewünschten Sql-Language für die übergebene Tabellenliste
     * 
     * ACHTUNG: nur für externen statischen Aufruf gedacht. Nicht innerhalb der Backup-Klasse verwenden
     * 
     * @param   string      $in_sqlLanguage         bsp.: postgresql|mysql
     * @param   array       $in_tablelist           Zweidiemansionale Liste der Tabellen  (Bsp.: array( 0 => Array("tables.table_schema" => manager, "tables.table_name" => vquery_app))
     * @return  array                              Liste der Drop-Commandos
     */
    public static function getDropTableCommand($in_sqlLanguage, $in_tablelist) {
        
        //Backup_Klasse für DB in Abhängigkeit vom SQL-Dialekt laden.
        $db_helperClass = self::getDBMSspecificClass($in_sqlLanguage, "backup_helper");
        
        if($db_helperClass !== false) {
            //Drop-Commando des spezifischen DBMS ermitteln
            $feedback = $db_helperClass->createTableDropCommand($in_tablelist);
        } else {
            $feedback = false;
        }
        
        return $feedback;
    }
    
    
    
   
    
    
    
    /** Die Funktion ermittelt das Script zur Aktualisierung einer vQuery.
     * Das Script wandelt die übergebene valueList in Insert-Befehle um.
     * Außerdem kann der Create-Befehl für die vquery-Tabelle vorangestellt werden.
     * 
     * Diese Funktion hat nichts mit einem Backup zu tun, nutzt jedoch die Technik zur 
     * Ermittlung von datenbankspezifischer SQL-Syntax aus der Backup-Klasse.
     * 
     * @param   string  $in_sqlLanguage     gewünschte SQL-Syntax; Bsp.: [postgresql|mysql]
     * @param   array   $in_table           grundlegende Tabledaten; Bsp.: array("tables.table_schema" => manager, "tables.table_name" => app)
     * @param   array   $in_columnlist      Zweidiemansionale Liste der Tabellen  (Bsp.: array( 0 => Array("tables.table_schema" => manager, "tables.table_name" => vquery_app))
     * @param   array   $in_valueList       Wenn bereits eine Ergebnismenge vorliegt, kann diese mitgegeben werden. In dem Fall werden die Daten nicht
     *                                      aus der Quell-DB ausgelesen, sondern aus der ValueList genutzt. Verwendungszweck: vQuery
     *                                      Default = array()
     *                                      Syntax: Array(
                                                        [0] => Array(
                                                                [table_name.column1] => Bernd
                                                                [table_name.column2] => Schmid
                                                                [table_name.column3] => Herr)
                                                        [1] => Array(
                                                                [table_name.column1] => Klara
                                                                [table_name.column2] => Augustin
                                                                [table_name.column3] => Frau))* @param  booelan  $in_add_tableCreateCommand      Gibt an, ob TableCreateCommand vorangestellt werden soll
     * @param   array   $in_primaryKeys     Liste der PrimaryKeys; Bsp.: array("id", "app_id", "sys")
     * @param   string  $in_deleteCondition SQL-Condition, die in der Where-Klausel eines Delete-Befehls für die Tabelle ergänzt werden soll.
     * @return  boolean
     */
    public static function getScriptForVquery($in_sqlLanguage, $in_table, $in_columnlist, $in_valueList, $in_add_tableCreateCommand, $in_primaryKeys, $in_deleteCondition) {
        $feedback = ""; 
        
        //Backup_Klasse für DB in Abhängigkeit vom SQL-Dialekt laden.
        $db_class = self::getDBMSspecificClass($in_sqlLanguage, "backupTable");
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "db_class für Sql-Dialekt ermittelt");
        
        if($db_class !== false) {
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "getScriptForVquery");
        
            //Ein Table-Object als vQuery initialisieren
            $myTableObject = new $db_class;
            if($myTableObject->initializeAsVqueryTable($in_table, $in_columnlist, $in_valueList, $in_primaryKeys, $in_deleteCondition) === true) {
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "initializeAsVqueryTable");
        
                if($in_add_tableCreateCommand === true) {
                    $feedback = $feedback."\n\n".$myTableObject->getCreateTableCommand().";\n";
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "getCreateTableCommand");
        
                } else {
                    //delete-Befehl für alte Datensätze der gleichen connection_id abrufen
                    $feedback = $feedback."\n\n".$myTableObject->getDeleteCommand().";\n";
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "getDeleteCommand");
        
                }
                $feedback = $feedback."\n\n".implode(";\n", $myTableObject->getInsertCommands()).";\n";
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "getInsertCommands");
        
            }
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "getInsertCommands");
        
            
        } else {
            $feedback = false;
        }
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "nach initializeAsVqueryTable");
        
        
        return $feedback;
    }
    
    
    
    
    /** Erzeugt in Abhängigkeit vom gegebenen sql-Dialekt eine passende Backup-Klasse vom gewünschten Typ und gibt diese zurück
     * 
     * @param   string      $in_sqlLanguage         SQL-Dialekt; Bsp.: [postgresql|mysql]
     * @param   string      $in_classType           Typ der Klasse; mögliche Werte: [backup_helper|backupTable]
     * @return  mixed                               Backup-Helper-Objekt oder false, wenn die notwendige Klassendatei nicht geladen werden konnte.
     */
    private static function getDBMSspecificClass($in_sqlLanguage, $in_classType) {
        //Backup_Klasse für DB in Abhängigkeit vom SQL-Dialekt laden.
        $target_backupclass_file = "../controller/backupcontroller/backup_".$in_sqlLanguage."_class.php";
        $target_backup_class_namespace = $in_sqlLanguage."\\";   //PHP-Datei mit den dbms-spezifischen Klassen muss den entsprechenden namespace enthalten/deklarieren
        if(file_exists($target_backupclass_file) == true) {
            require_once($target_backupclass_file);
            $target_class = $target_backup_class_namespace.$in_classType;
            $db_class = new $target_class();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> DBMS-Klasse geladen ", $target_class, "INFO");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> DBMS-Klasse existiert nicht! ", $target_backupclass_file, "ERROR");
            $db_class = false;
        }
        
        return $db_class;
    }
    
 
}





class backup_mode {
    
    /**
     *
     * @var boolean     Gibt an, ob die DB-Struktur im Backup eingeschlossen werden soll. Dabei werden auch Drop-Table-Anweisungen vorangestellt. 
     */
    public $readAppStructure; 
    
    /**
     *
     * @var boolean     Gibt an, ob die Daten einer APP in Form von INSERT-Anweisungen eingeschlossen werden sollen.
     */
    public $readAppData;
    
    /**
     *
     * @var boolean     Gibt an, ob die Konfigurationsdaten der APP aus dem Schema "manager" (SYS01) eingeschlossen werden sollen. Diesen werden DELETE-Befehle vorangestellt
     */
    public $readAppConfig;
    
    /**
     *
     * @var boolean     Gibt an, ob Drop-Constraint-Befehle eingefügt werden sollen 
     */
    public $drop_constraints;
    
    /**
     *
     * @var boolean     Gibt an, ob Add-Constraint-Befehle eingefügt werden sollen 
     */
    public $add_constraints;
    
    /**
     *
     * @var boolean     Gibt an ob GrandCommands erzeugt werden sollen 
     */
    public $addGrandCommands;
     
    /**
     *
     * @var boolean     Gibt an, ob die ContentDaten, welche sich im Kernmodul befinden, aber nicht zum Kernmodul gehören, gesichert werden sollen.
     */
    public $readAppContentInKernel;
    
    /**
     *
     * @var string      Gewählter Backup-Modus; Details siehe Kommentar zu Klasse backup_mode
     */
    public $type;
    
    /**
     *
     * @var string      Gibt an, ob und wie das sys-flag behandelt werden soll. 
     *                  Mögliche Werte:
     *                      ignore           -> das Kennzeichen sys in den Tabellen des Kernmoduls wird ignoriert
     *                      notSystemData    -> Daten des Kernmoduls, aber ohne sys = 1, und die Daten aller anderen APP's, die im Schema des Kernsystems liegen.
     *                      onlySystemData   -> Daten der aktuell zu sichernden APP mit dem Kennzeichen sys = 1
     */
    public $handleSysFlag;
    
    
    /**
     *
     * @var string      Gibt an, welchem User die Zugriffsrechte für die DB-Objekte zugeordnet werden sollen
     *                  Mögliche Werte:
     *                      oldUser         -> Rechte werden ausgelesen und 1:1 im Backup wiedergegeben
     *                      newUser         -> Es wird der Platzhalter [newUser] in den SQL-Skripten hinterlegt, der bei der Installation vom Anwender abgefragt und ggf. angelegt werden sollte
     */
    public $grantsToUser;
    
    
    /**
     *
     * @var boolean     Gibt an, ob Drop-Table-Befehle eingefügt werden sollen 
     */
    public $drop_tables;
    
    
    
    /**
     *
     * @var boolean     Gibt an, ob Create-Schema-Befehle erstellt werden sollen. 
     */
    public $create_schema;
    
    

    
    
    /**
     * 
     * @param   integer     $in_backuptyp       Gibt an welche Daten gesichert werden müssen.
     *                                          1 = a) APP-Struktur
     *                                          2 = b) APP-Daten
     *                                          3 = c) APP-Konfigurationsdaten
     *                                          4 = a)+b)
     *                                          5 = a)+c)
     *                                          6 = b)+c)
     *                                          7 = a)+b)+c)
     *                                          100 = SYS01-Releaseunterstützung
     *                                          101 = Release/ Version
     *                                          102 = SYS01-Struktur + Daten (Update-Unterstützung)
     *                                          103 = nicht SYS01 -> Struktur und Daten (Update-Unterstützung)
     */
    function __construct($in_backuptyp) {
        
        
        //Vorab-Erläuterungen:
        //
        //1. Die folgenden Eigenschaften legen das Ziel des Backups fest. Demgegenüber haben auch die Tabellen
        //   im Kernmodul Eigenschaften, die die Art de Tabelle bestimmen (siehe dazu manager[Schema].backup_tabledefinitions bzw. class TableType)
        //
        //readAppStructure:
        //   Es sollen die Strukturdaten der Tabellen ermittelt werden. Somit können Create- und ALter-Commands erstellt werden.
        //
        //readAppData:
        //   Es sollen die Inhaltsdaten einer App ermittelt werden. Somit können Insert-Commands erstelltwerden.
        //   Problem: Es gibt im Kernelmodul auch Daten, die nicht zu den ConfigDaten und auch nicht zu den Inhaltsdaten der Kernel-APP
        //   zählen. Bspw. in Tabelle logdata. Dabei handelt es sich um Inhaltsdaten anderer APP's. Diese müssen wie Inhaltsdaten
        //   behandelt werden. Die entsprechenden Tabellen sind in manager[Schema].backup_tabeldefinitions mit addIfContentBackupForApp 
        //   gekennzeichnet.
        //
        //readAppConfig:
        //   Die ConfigDaten liegen immer in der KernelAPP. Es werden also diejenigen Kerneldaten ermittelt, die sich auf die 
        //   zu sichernde APP beziehen. PROBLEM: Wenn die Kernel-APP gesichert werden soll, dann kommt es zwischen readAppData 
        //   und readAppConfig zu Überschneidungen. Die Configdaten zählen gleichzeitig zu den Inhaltsdaten der Kernel-App
        //
        //readAppContentInKernel:
        //   Wenn ein Strukturbackup der Kernel-APP erstellt wird, dann ist darin auch ein drop schema-Befehl enthalten.
        //   Damit gehen auch alle Config- und Contentdaten anderer App's verloren. Diese Eigenschaft stellt sicher, dass diese 
        //   gesichert werden.
        
        
        //ACHTUNG / ATENTION:
        //in einem Backup sollten niemals die Datentypen
        //  a) readAppStructure + readAppData          mit
        //  b) readAppConfig + readAppContentInKernel  kombiniert werden.
        //  
        //Grund: 
        // Die Daten zu b) liegen im Schema von SYS01, die anderen Daten können in einem anderen Schema liegen.
        // Es kann sein, dass für die beiden Schemata unterschiedliche Zugriffsrechte notwendih sind, 
        // um die bacjup-Dateien wieder einzulesen. Daher könnte beim gemeinsamen Einlsene ein Fehler auftretn.
        
        
        $this->type = $in_backuptyp;
        
        
        if      ($in_backuptyp == 1) {              //a) APP-Struktur
            $this->readAppStructure = true;  $this->readAppData = false; $this->readAppConfig = false; $this->readAppContentInKernel = false; $this->handleSysFlag = "ignore";          $this->grantsToUser = "oldUser";    $this->drop_constraints = false; $this->add_constraints = true;  $this->drop_tables = true;     $this->addGrandCommands = true;     $this->create_schema = false;
        } elseif($in_backuptyp == 2) {              //b) APP-Daten ohne addContent in Kernel-DB
            $this->readAppStructure = false; $this->readAppData = true;  $this->readAppConfig = false; $this->readAppContentInKernel = false; $this->handleSysFlag = "ignore";          $this->grantsToUser = "oldUser";    $this->drop_constraints = false; $this->add_constraints = false; $this->drop_tables = false;    $this->addGrandCommands = false;    $this->create_schema = false;
        } elseif($in_backuptyp == 3) {              //c) APP-Konfigurationsdaten
            $this->readAppStructure = false; $this->readAppData = false; $this->readAppConfig = true;  $this->readAppContentInKernel = false; $this->handleSysFlag = "ignore";          $this->grantsToUser = "oldUser";    $this->drop_constraints = true;  $this->add_constraints = true;  $this->drop_tables = false;    $this->addGrandCommands = false;    $this->create_schema = false;
        } elseif($in_backuptyp == 4) {              //a) + b)
            $this->readAppStructure = true;  $this->readAppData = true;  $this->readAppConfig = false; $this->readAppContentInKernel = false; $this->handleSysFlag = "ignore";          $this->grantsToUser = "oldUser";    $this->drop_constraints = false; $this->add_constraints = false; $this->drop_tables = true;     $this->addGrandCommands = true;     $this->create_schema = false;
        } elseif($in_backuptyp == 20) {              //DBMS-Wechsel
            $this->readAppStructure = true;  $this->readAppData = true;  $this->readAppConfig = false; $this->readAppContentInKernel = false; $this->handleSysFlag = "ignore";          $this->grantsToUser = "newUser";    $this->drop_constraints = false; $this->add_constraints = true;  $this->drop_tables = true;     $this->addGrandCommands = true;     $this->create_schema = false;
             
        } elseif($in_backuptyp == 100) {            //Update-Unterstützung (config und addContent in Kernel-DB ohne sys=1-Datensätze)
            $this->readAppStructure = false; $this->readAppData = false; $this->readAppConfig = true;  $this->readAppContentInKernel = true;  $this->handleSysFlag = "notSystemData";   $this->grantsToUser = "oldUser";    $this->drop_constraints = true; $this->add_constraints = true;    $this->drop_tables = false;   $this->addGrandCommands = true;     $this->create_schema = false; 
        } elseif($in_backuptyp == 101) {            //Release/ Version für SYS01
            $this->readAppStructure = true;  $this->readAppData = false; $this->readAppConfig = true;  $this->readAppContentInKernel = false; $this->handleSysFlag = "onlySystemData";  $this->grantsToUser = "newUser";    $this->drop_constraints = false; $this->add_constraints = true;   $this->drop_tables = true;    $this->addGrandCommands = true;     $this->create_schema = false;
        } elseif($in_backuptyp == 102) {            //(nur für SYS01) Struktur und Daten ohne Einschränkung -> notwendig für Komplettsicherung vor Update
            $this->readAppStructure = true;  $this->readAppData = true;  $this->readAppConfig = false; $this->readAppContentInKernel = false; $this->handleSysFlag = "ignore";          $this->grantsToUser = "oldUser";    $this->drop_constraints = false; $this->add_constraints = true;   $this->drop_tables = true;    $this->addGrandCommands = true;     $this->create_schema = false;
        } elseif($in_backuptyp == 104) {            //Update-Unterstützung (content für andere APPs)
            $this->readAppStructure = false; $this->readAppData = true;  $this->readAppConfig = false; $this->readAppContentInKernel = false; $this->handleSysFlag = "notSystemData";   $this->grantsToUser = "oldUser";    $this->drop_constraints = true; $this->add_constraints = true;  $this->drop_tables = false;   $this->addGrandCommands = false;    $this->create_schema = false;
        } elseif($in_backuptyp == 105) {            //Update-Unterstützung (config und addContent in Kernel-DB für andere App's) 
            $this->readAppStructure = false; $this->readAppData = false; $this->readAppConfig = true;  $this->readAppContentInKernel = true;  $this->handleSysFlag = "ignore";          $this->grantsToUser = "oldUser";    $this->drop_constraints = true;  $this->add_constraints = true;   $this->drop_tables = false;   $this->addGrandCommands = false;    $this->create_schema = false;
        } elseif($in_backuptyp == 111) {            //Release/ Version nur Struktur (für andere APPs)
            $this->readAppStructure = true;  $this->readAppData = false; $this->readAppConfig = false; $this->readAppContentInKernel = false; $this->handleSysFlag = "onlySystemData";  $this->grantsToUser = "newUser";    $this->drop_constraints = false; $this->add_constraints = true;   $this->drop_tables = true;    $this->addGrandCommands = false;    $this->create_schema = false;
        } elseif($in_backuptyp == 112) {            //Release/ Version nur Config (für andere APPs)
            $this->readAppStructure = false; $this->readAppData = false; $this->readAppConfig = true;  $this->readAppContentInKernel = false; $this->handleSysFlag = "onlySystemData";  $this->grantsToUser = "newUser";    $this->drop_constraints = true;  $this->add_constraints = true;   $this->drop_tables = false;   $this->addGrandCommands = false;    $this->create_schema = false;
        } elseif($in_backuptyp == 113) {            //Update-Unterstützung (Constraints deaktivieren)
            $this->readAppStructure = false; $this->readAppData = false; $this->readAppConfig = false; $this->readAppContentInKernel = false; $this->handleSysFlag = "onlySystemData";  $this->grantsToUser = "newUser";    $this->drop_constraints = true;  $this->add_constraints = false;  $this->drop_tables = false;   $this->addGrandCommands = false;    $this->create_schema = false;
        } elseif($in_backuptyp == 114) {            //Update-Unterstützung (Constraints aktivieren)
            $this->readAppStructure = false; $this->readAppData = false; $this->readAppConfig = false; $this->readAppContentInKernel = false; $this->handleSysFlag = "onlySystemData";  $this->grantsToUser = "newUser";    $this->drop_constraints = false; $this->add_constraints = true;   $this->drop_tables = false;   $this->addGrandCommands = false;    $this->create_schema = false;
        } elseif($in_backuptyp == 115) {            //Installation einer APP -> Create Schema
            $this->readAppStructure = false; $this->readAppData = false; $this->readAppConfig = false; $this->readAppContentInKernel = false; $this->handleSysFlag = "onlySystemData";  $this->grantsToUser = "newUser";    $this->drop_constraints = false; $this->add_constraints = false;  $this->drop_tables = false;   $this->addGrandCommands = false;    $this->create_schema = true;
        }
        
    }
}




abstract class TableType {
    /**
     * Inhaltsdaten, alle Daten aus dem Schema der zu sichernden APP
     */
    const content = "content";
    
    /**
     * zusätzliche Inhaltsdaten, die zur APP gehören, aber in den globalen tabellen von SYS01 abgelegt sind. Bspw. in der tabelle manager.logdata
     */
    const addContent = "addContent";
    
    /**
     * DB-Strukturdaten, wie bspw. creste Table, grants, index usw.
     */
    const structure = "structure";
    
    /**
     * Konfigurationsdaten, die in SYS01 abgelegt sind, sich aber auf die APP beziehen.
     */
    const config = "config";
}





