<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


/** Dieses Interface stellt sicher, dass Methoden, die für ein DBMS (db_connector[...]_class] 
 * neu entwickelt werden, zeitnah in alle anderen deb_connector-Klassen übertragen wird.
 * Nur so kann die DB-Unabhängigkeit der AppMS-Anwendungen sichergestellt werden.
 *
 * @author Thomas J.
 */
interface db_connector_interface {
    public function executeDelete($in_SqlDaten, $in_callFromFunction);
    public function executeInsert($in_SqlDaten, $in_callFromFunction, $in_updateSequence);
    public function executeSelect($in_sql_string, $in_callFromFunction, $print_to_debug);
    public function executeUpdate($in_SqlDaten, $in_callFromFunction);
    public function getDbConnection();
    public function getParseSqlValues($in_value);
    public function makeSecureSQL($input, $in_callFromFunction);
    public function close_connection();
    
    //ACHTUNG: Wenn die nachfolgende Liste ergänzt wird, muss in dem jeweiligen Konnektor auch die Function parseFunctions erweitert werden.!!!
    public function parseFunctions($in_function_name, $in_param_list);
    public function getSyntaxForInterval($in_param_list);
    public function getSyntaxForConcat($in_param_list);
    public function getSyntaxForDateFormat($in_param_list);
    public function getSyntaxForCase($in_param_list);
    public function getSyntaxForCoalesce($in_param_list);
    public function getSyntaxForCast($in_param_list);
    public function getSyntaxForReplace($in_param_list);
    public function getSyntaxForCount($in_param_list);
    public function getSyntaxForCountIf($in_param_list);
    public function getSyntaxForLength($in_param_list); 
    public function getSyntaxForMax($in_param_list); 
    public function getSyntaxForSum($in_param_list);
    public function getSyntaxForStringAgg($in_param_list);
    public function getSyntaxForStrpos($in_param_list);
    public function getSyntaxForStrposRight($in_param_list);
    public function getSyntaxForSubstring($in_param_list);    
    public function getSyntaxForReverse($in_param_list);
    public function getSyntaxForRight($in_param_list);
    public function getSyntaxForSplitstring($in_param_list);
    
    
}
