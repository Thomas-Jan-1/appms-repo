<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

/**
 * Bietet Methoden zur Steuerung von SOAP-Anfragen
 *
 * @author thomas
 */
class soap_client_appms {
    

    
    /**
     * 
     * @var     object          Soap-Verbindung
     */
    private $soap_client;
    
    /**
     * 
     * @var     string
     */
    public $username;
    
    /**
     * 
     * @var     string
     */
    public $password;
    
    /**
     * 
     * @var     string
     */
    public $base_url;
    
    /**
     * 
     * @var     string
     */
    public $param_as_string;
    
    /**
     * 
     * @var     string      Default= "SOAP_1_2"
     */
    public $api_method;
    
    
    
    
    
    /** Bietet Methoden zur Steuerung von SOAP-Anfragen. 
     * initiale Arbeitsschritte zur Etablierung der Soap-Verbindung werden ausgeführt, Klassen-Eigenschaften werden vorbelegt.
     * 
     * !!!ACHTUNG!!! TimeOut muss ausreichend sein.
     * es gibt leider mehrere Stellen, an denen das ggf. konfiguriert werden muss
     * apache.conf, php.ini
     * php.ini: max_execution_time = 1000
     * php.ini: max_input_time = 1000
     * apache.conf: Timeout 1000
     * apache.conf: KeepAliveTimeout 1000
     * 
     * @param   string  $in_accessdata_name Name des Datensatzes,der Zugangsdaten enthält. Diese müssen zuvor über die Maske "Zugangsdaten API's" hinterlegt werden.
     * @param   string  $in_app_id          APP-ID
     * @param   boolean $in_trace           [optional] Gibt an, ob trace-stack (debug) aktiviert werden soll. Default = false
     * @param   string  $in_soap_version    [optional] Version; Default = SOAP_1_1; mögliche Werte [SOAP_1_1|SOAP_1_2]
     * @return  boolean                     Wenn Zugngansdaten vorhanden und Soap-Client initiert werden konnten.
     */
    public function __construct($in_accessdata_name, $in_app_id, $in_trace = false, $in_soap_version = "SOAP_1_1") {
        $feedback = false;
        
        
        //Zugangsdaten aus der Tabelle access_token auslesen
        $soap_connect_data = $this->get_access_data($in_accessdata_name, $in_app_id);
        
        
        if(count($soap_connect_data) > 0) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Soap-Zugangsdaten', $soap_connect_data);
            
            $this->base_url = $soap_connect_data[0]["access_token.base_url"];
            $this->api_method = $soap_connect_data[0]["access_token.api_method"];
            $this->param_as_string = $soap_connect_data[0]["access_token.param_as_string"];
            $this->password = crypt_class::decryptString($soap_connect_data[0]["access_token.api_password"]);
            $this->username = $soap_connect_data[0]["access_token.api_username"];
            
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Soap-Passwort', $this->password);
            
            // WSDL-URL des Webservice
            $wsdl = $this->base_url."?wsdl"; 
                     

            $options = [
                'trace' => $in_trace,
                'exceptions' => $in_trace,
                'cache_wsdl' => WSDL_CACHE_NONE,
                'soap_version' => $in_soap_version, // oder SOAP_1_2 je nach Vorgaben des Webservice
                'connection_timeout' => 10000000, // Timeout in Sekunden
                'stream_context' => stream_context_create([
                    'http' => [
                        'timeout' => 100000000, // Timeout in Sekunden
                    ]
                    ]),
                'Max Size' => 0, // Maximalgröße der Anfrage in Bytes
                'Pretty Print' => true, // Ausgabe der Anfrage in lesbarem Format
                'Follow Redirects' => true, // Folgt Redirects
                'connection keep-alive' => true // Verbindungs-Persistenz
            ];


            
            
            
        
            $this->soap_client = new SoapClient($wsdl, $options );


            // Header für WS-Security
            $auth = '
                <ns2:Security SOAP-ENV:mustUnderstand="1" >
                    <ns2:UsernameToken>
                        <ns2:Username>'.$this->username.'</ns2:Username>
                        <ns2:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">'.$this->password.'</ns2:Password>
                    </ns2:UsernameToken>
                </ns2:Security>';


            $header = new SoapHeader(
                'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd',
                'ns2:Security',
                new SoapVar($auth, XSD_ANYXML),
                true
            );
            
            $this->soap_client->__setSoapHeaders([$header]);

            $feedback = true;
        }
        
        
        return $feedback;
    }
    
    
    
    
    
    /** Ermittelt die Zugriffsdaten, welche über die Maske "Zugangsdaten API's" erfasst wurden.
     * 
     * @param string    $in_access_name         Name der Zugangsdaten
     * @param string    $in_app_id              APP-ID der Zugangsdaten
     * @return array                            
     */
    private function get_access_data($in_access_name, $in_app_id) {
        $condition = "api_name = '".$in_access_name."' and app_id = '".$in_app_id."'";
        $soap_connect_data = getTableData2(global_variables::getAppIdFromSYS01(),
                                           "access_token", 
                                           global_variables::getNameOfDbSchemaSYS01(), 
                                           array(0 => Array("feld.spalte" => "api_username"),1 => Array("feld.spalte" => "api_password"),2 => Array("feld.spalte" => "base_url"),3 => Array("feld.spalte" => "param_as_string"),4 => Array("feld.spalte" => "api_method")), 
                                           false, "", $condition, __FUNCTION__);
        
        
        return $soap_connect_data;
    }
    
    
    /** ruft eine bestimmte Zielfunktion per SOAP auf
     * 
     * @param   string  $in_target_function     Funktionsname
     * @param   array   $in_paramlist           Liste aller Parameter/Argumente. Wenn die target-function nur einen String akzeptiert, dann muss dieser dennoch in einem Array "gekapselt" werden.
     * @return  mixed                           Rückgabewert ist abhängig von der aufgerufenen target-function; 
     *                                          Falls ein Fehler auftritt, wird dieser in der debug-Tabelle protokolliert. Rückgabewertist dann false.
     */
    public function soap_call($in_target_function, $in_paramlist) {
        set_time_limit(0); // Setzt die maximale Ausführungszeit auf 1000 Sekunden

        try {
            $result = $this->soap_client->__soapCall($in_target_function, $in_paramlist);
        } catch (SoapFault $fault) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Fehler Soap (Code): '.$fault->faultcode, $fault->faultstring);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> SOAP-Message: ', $fault->getMessage());
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> SOAP-Request: ', $this->soap_client->__getLastRequest());
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> SOAP-Response-Header: ', $this->soap_client->__getLastResponseHeaders());
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> SOAP-Request-Header: ', $this->soap_client->__getLastRequestHeaders());
            $result = false;
        }
        return $result;

    }
    
    
    
    
}
