<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

/**
 * Die Klasse stellt Funktionen bereit, welche durch javascript mit Elementen der Oberfläche verbunden werden können.
 * Somit können Daten dynamisch nachgeladen werden.
 * 
 *
 * @author Thomas J.
 */
class functions_ajaxrequest {
    
    function __construct() 
    { 
        
    }
    
    
    
    
    /** Dies ist nur Test-Methode, die zur Demonstration der Einbindung dient. Die Methode kann angesprochen werden,
     * indem in einem beliebigen Formular ein Button integriert wird. Dem Button muss im <br />
     *  Feld "JavaScript-OnKlick" der Wert "showMoreData" und im <br />
     *  Feld "JavaScript-onClick-Parameter" der Wert "event,'SYS01.functions_ajaxrequest.demo'" <br />
     * zugeordnet werden.
     * 
     * 
     * @param   array   $in_params          Parameterliste ('SYS01.functions_ajaxrequest.demo')
     * @return  string                      HTML-Code einer Tabelle mit den Differenzen
     */
    public function demo($in_params) {
        return "<div><b>Hallo Welt</b> <br />".
                "übergebener Parameter: ".print_r($in_params,TRUE)."</div>";
        
        
        //Beispiel für eine Fehlermeldung
        $feedback = "error:-3101:SYS01";
        //Der Klartext für die Fehlermeldung -101 muss in der Tabelle Konstante unter der Konstantentyp_id = 35 angelegt werden.
        //Warum sollte die Fehlermeldung auf diese Weise erfolgen, statt das der Fehlertext direkt zurückgegeben wird?
        //Auf diese Weise werden Fehlertext gesammelt in einer Datenbanktabelle abgelegt, statt verstreut im Programmcode.
        //Das eröffnet perspektivisch die Möglichkiet der Mehrsprachigkeit der Anwendung.
    }
    
    
    
}
