<?php

/* 
 * Copyright (C) 2024 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


    //diese Datei ist dafür verantwortlich AjaxRequests von Javascript zu beantworten. 
    //Sie befindet sich im view-Ordner, da nur dieser von externen Clients angesprochen werden kann.

    require_once("../controller/session_class.php");  
    require_once("../controller/functions_db.php");
    require_once("../controller/functions.php");
    require_once("../controller/debug.php"); 
    require_once("../controller/showFields.php"); 
    require_once("../controller/progressstatus_class.php");

    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__, "starte ajaxRequest");

    if (isset($_POST)) {							//nur wenn per $_POST eine Anfrage gesendet wurde, wird etwas getan.
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte ajaxRequest.php mit POST: ', $_POST);

        //Anfrage Hilfetext für eine FeldID
        if ($_POST["targetMethod"] == "getHelptextForFeldID")       {$response = getHelptextForFeldID($_POST);}

    //    //Anfrage der HIlfeID und des Hilfetextes für eine FeldID
    //    elseif ($_POST["targetMethod"] == "getHelpdatasetForID")    {$response = getHelpdatasetForID($_POST);}

        //Anfrage für die aktualisierte Optionlist eines abhängigen Feldes  
        elseif ($_POST["targetMethod"] == "getOptionListForDependingFields")  {$response = getOptionListForDependingFields($_POST);}

        //Anfrage für den aktualisierten Optionlist eines Feldes  
        elseif ($_POST["targetMethod"] == "getOptionListForField")  {$response = getOptionListForField($_POST);}
        
        //Anfrage Form-Description für eine form_id
        elseif ($_POST["targetMethod"] == "getFormdescription")  {$response = getFormdescription($_POST);}    

        //Anfrage SQL-Befehl für eine Query anzeigen
        elseif ($_POST["targetMethod"] == "getSqlCommandForQuery")  {$response = getSqlCommandForQuery($_POST);}   

        //Anfrage SQL-Ergebnis für eine Query in einer einfachen tabellarischen Form anzeigen
        elseif ($_POST["targetMethod"] == "getPreviewForQuery")  {$response = getPreviewForQuery($_POST);} 
        
        //Anfrage einer Liste möglicher (vorhandener) Werte für eine Suggest-Funktion eines Input-Feldes
        elseif ($_POST["targetMethod"] == "getSuggestListForFeldID")  {$response = getSuggestListForFeldID($_POST);}  

        //Fragt eine beliebige Plugin-Funktion ab 
        elseif ($_POST["targetMethod"] == "getFeedbackFromPhpFunction")  {$response = getFeedbackFromPhpFunction($_POST);} 

        //Anfrage für deinen Feedbacktext aus der Tabelle Konstante (konstantentyp_id = 35
        elseif ($_POST["targetMethod"] == "getFeedbacktext")  {$response = getFeedbacktext($_POST);} 
        
        //Anfrage des Fortschrittes des aktuellen Jobs aus der Tabelle Session ermitteln
        elseif ($_POST["targetMethod"] == "getProgressStatus")  {$response = getProgressStatusForCurrentJob();} 
        
        //Übermittlung der aktuellen Tab-ID des Browsers
        elseif ($_POST["targetMethod"] == "sendTabIdToServer")  {$response = sendTabIdToServer($_POST);} 


    }



    //--Antwort an den Client--------------------------------------------------------------------------------------------
    //$response = Array
    //(
    //    [0] => Array
    //        (
    //            [form_id] => 133,
    //            [target_field_app_id] => 'SYS01',
    //            [target_field_id] => '1233',
    //            [target_field_column] => 'tablename',
    //            [trigger_field_column] => 'db_schema',
    //            [optionlist] => '<option value=""></option><option value="account">account</option><option value="account_has_role">account_has_role</option><option value="app">app</option>'
    //
    //        )
    //
    //);
    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Antwort von ajaxRequest.php: ', $response);
    $response_json = json_encode($response);
    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Antwort von ajaxRequest.php (json): ', $response_json);
    print_r($response_json);
    //db_connection_handler::closeAllConnections(); -> nicht notwendig, da sich Nutzung von persistenten Verbindungen ohnehin als nicht effizient und diese Methode als unzuverläsig erwiesen hat.
    //--Ende der Antwort an den Client-----------------------------------------------------------------------------------

    session_class::$session_object->my_destructer();          //sicherstellen, dass Session-Änderungen an die globale Variable übergeben werden




    /** Ermittelt für eine FeldID und AppID den zugehörigen Hilfetext
     * 
     * @param   array   $in_POST    $_POST-Array
     * @return  array               Array mit key "answer", welcher den Hilfetext enthält      
     */
    function getHelptextForFeldID($in_POST) {
        if(isset($in_POST["feldID"]) AND isset($in_POST["feldAppID"])) {
            $feldID = $in_POST["feldID"];
            $feldAppID = $in_POST["feldAppID"];
            $Hilfetext = getHilfe($feldID, $feldAppID);
            $response = array ("desc" => $Hilfetext);
        } else {
            $response = array ("desc" => "feldID oder feldAppID nicht erkannt.");
        }
        return $response;

    }
    
    
    
    
    /** Übergibt die Tab_id an die Session-Variable
     * 
     * @param   array   $in_POST    $_POST-Array
     * @return  array               Array mit key "answer", welcher die Erfolgsmeldung oder einen Fehlertext enthält.    
     */
    function sendTabIdToServer($in_POST) {
        if(isset($in_POST["tab_id"])) {
            $tabId = $in_POST["tab_id"];
            session_class::$session_object->setTabIdByBrowser($tabId);
            
            $response = array ("answer" => "tab_id gesetzt");
        } else {
            $response = array ("answer" => "tab_id wurde nicht angegeben");
        }
        return $response;

    }



    




    /** Ermittelt für ein Formular (DB-Table = form) den Inhalt des DB-Feldes description.
     * 
     * @param   array       $in_POST    In in_Post werden die Werte formID und appID erwartet
     * @return  array                      
     */
    function getFormdescription($in_POST) {
        $formID = $in_POST["formID"];
        $appID = $in_POST["appID"];
        $formDataset = getFormsdataByFormID($formID,$appID);

        $feedback = "";
        if ($formDataset["form.description"] === null) {
            $feedback = array (	"desc" => "Für dieses Formular ist keine Beschreibung verfügbar.");

        } else {
            $localFeedback = "<h1>".$formDataset["form.name"]."</h1><br />".$formDataset["form.description"];
            $feedback = array (	"desc" => $localFeedback);

        }									


        $response = $feedback;
        return $response;
    }
    
    
    
    
    /** Ermittelt für ein Feld mögliche Suchvorschläge. Dabei werden die bereits erfassten Zeichen, sowie die 
     * Zugriffrechte (condition) des aktuellen Formulars beachtet.
     * 
     * @param   array       $in_POST    In in_Post werden die Werte fieldID, formID, fieldAppID und term erwartet
     * @return  array                      
     */
    function getSuggestListForFeldID($in_POST) {
        $formID = $in_POST["formID"];
        $appID = $in_POST["fieldAppID"];
        $fieldID = $in_POST["fieldID"];
        $searchTerm = $in_POST["term"];
        $suggestionlist = getSuggestions($formID, $appID, $searchTerm, $fieldID);

        $feedback = "";
        if ($suggestionlist !== false) {
            $feedback = $suggestionlist;

        } 									

        return $feedback;
    }
    
    
    
    /** Ermittelt aus der Session den aktuellen Fortschritt des laufenden Jobs
     * 
     * @return  array           Liste der Fortschrittsattribute: <br>
     *                          start_value -> kleinster Wert der Range <br>
     *                          cur_value -> akzueller Wert <br>
     *                          end_value -> größter Wert der Range <br>
     *                          desc -> Beschreibung des Prozesses <br>
     */
    function getProgressStatusForCurrentJob(){
        $myProgress = new progressstatus;
        $feedback = $myProgress->getStatus();
        //$feedback = "<label>test</label>";
        return $feedback;
    }




    /** Ermittelt aus der Konstantenliste 35 (konstantententyp.id = 35 - User-Feedback for Functions) den Klartext
     * einer bestimmten Konstanten 
     * 
     * @param   array   $in_konstante    In $in_konstante werden die Werte konstantenAppID und konstantenWert erwartet
     * @return  string                      
     */
    function getFeedbacktext($in_konstante) {
        $konstantenAppID = $in_konstante["konstantenAppID"];
        $konstantenWert = $in_konstante["konstantenWert"];
        $feedbackArray = getFeedbacktextForFunction($konstantenWert,$konstantenAppID);

        $feedback = array (	"desc" => $feedbackArray[0]["konstante.klartext"]);

        return $feedback;
    }




    /** Ermittelt für alle abhängigen Felder eines Triggerfields, die Listen der möglichen Werte, die unter Beachtung 
     * des aktuellen Values im TriggerField möglich sind.
     * 
     * @param   array   $in_POST    enthält Angaben zum TriggerField (Bsp.: array(triggerFieldcontent => "Bayern", triggerFieldAppID => "SYS01", triggerFieldID => 122, formID => 12, targetMethod => "getOptionListForDependingFields")) 
     * @return  array               array mit den OptionLists für alle abhängigen Felder des selben Datensatzes   
     */
    function getOptionListForDependingFields($in_POST) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte : ', $in_POST);
        $TriggerField = array();
        $TriggerField["fieldAppID"] = $in_POST["triggerFieldAppID"];
        $TriggerField["fieldID"] = $in_POST["triggerFieldID"];
        $TriggerField["fieldValue"] = $in_POST["triggerFieldcontent"];
        $TriggerField["formID"] = $in_POST["triggerFieldFormID"];
        $TriggerField["rowFieldList"] = $in_POST["rowFieldList"];
        $dependingFieldlist1 = getDependingFields($TriggerField);                    //Todo: depending_Fields könnte auch über SESSION[forms_backup][id][form.default_fields][id][feld.affected_to_field] ermittelt werden. Das würde vermutlich performanter sein.
        $dependingFieldlist2 = getDependingFields2($TriggerField);                  //Liste der Felder, die das TriggerFiled als Connection-ID nutzen
        $dependingFieldlist = array_merge($dependingFieldlist1, $dependingFieldlist2);
    //    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> abhängige Felder1: ', $dependingFieldlist1);
    //    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> abhängige Felder2: ', $dependingFieldlist2);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> abhängige Felder-gesamt: ', $dependingFieldlist);


        $allOptionLists = array();
        //Optionlist für jedes DependingField ermitteln und in $allOptionLists ablegen
        foreach ($dependingFieldlist as $key => $dependingField) {
            $currentOptionList = array();
            $currentOptionList["form_id"] = $TriggerField["formID"];
            $currentOptionList["target_field_app_id"] = $dependingField["field_depends.feld_app_id"];
            $currentOptionList["target_field_id"] = $dependingField["field_depends.feld_id"];
            $currentOptionList["target_field_column"] = $dependingField["feld.target_column"];
            $currentOptionList["trigger_field_column"] = $dependingField["feld.trigger_column"];
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> currentOptionList: ', $currentOptionList);

            //Optionstring in HTML-Syntax ermitteln
            $currentOptionList["optionlist"] = getOptionListForReferenzToQuery($dependingField, $TriggerField);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> currentOptionList: ', $currentOptionList);

            //OptionString mit Angabe der FeldID zurückgeben
            $allOptionLists[] = $currentOptionList;
        }
        $response = $allOptionLists;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> allOptionList: ', $allOptionLists);

        return $response;
    }



    function getOptionListForField($in_POST) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte : ', $in_POST);
        
        $formID = $in_POST["formID"];
        $appID = $in_POST["fieldAppID"];
        $fieldID = $in_POST["fieldID"];
        $searchTerm = $in_POST["term"];
        $rowFieldList = $in_POST["rowFieldList"];
        $suggestionlist = getSuggestionsForOptionList($formID, 
                                                    $appID, 
                                                    $searchTerm, 
                                                    $fieldID, 
                                                    $rowFieldList);

        $feedback = "";
        if ($suggestionlist !== false) {
            $feedback = $suggestionlist;

        } 									

        return $feedback;
    }







    /** Ermittelt für eine query den SQL-Befehl
     * 
     * @param   array       $in_POST                array mit den Angaben queryID und queryAppID
     * @return  string                              SQL-Befehl
     */
    function getSqlCommandForQuery($in_POST) {
    //    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte : ', $in_POST);
        if(isset($in_POST["queryID"]) AND isset($in_POST["queryAppID"])) {
            $queryID = $in_POST["queryID"];
            $queryAppID = $in_POST["queryAppID"];
            $myQuery = new query();
            $myQuery->initialize_1($queryAppID, $queryID, false, array(), array());   
            //ToDo: Eventuell kann unter Nutzung des vierten Parameters an dieser Stelle auch mit Dummy-Parametern gearbitet werden.
            //Dazu könnte der Anwender gefragt werden, für welches Formular er den SQL-Befehl angezeigt bekommen will.
            //So wäre es möglich nur die Kriterien dieses Formulars zu laden.
            $sql = $myQuery->getSqlCommand();
            $response = array (	"desc" => $sql);

        } else {
            $response = array (	"desc" => "queryID oder queryAppID konnte nicht ermittelt werden!");
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->', "Abbruch, da queryID oder queryAppID nicht ermittelt werden konnten.");
        }
        return $response;
    }




    /** Ermittelt das Ergebnis einer Query und gibt es als einfache HTML-Tabelle zurück
     * 
     * @param   array       $in_POST                array mit den Angaben queryID und queryAppID
     * @return  string                              SQL-Befehl
     */
    function getPreviewForQuery($in_POST) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte : ', $in_POST);
        if(isset($in_POST["queryID"]) AND isset($in_POST["queryAppID"])) {
            $queryID = $in_POST["queryID"];
            $queryAppID = $in_POST["queryAppID"];
            $preview = getFormTableForQueryWithoutForm($queryAppID, $queryID);
    //        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ergebnis getFormTableForQueryWithoutForm: ', $preview);
            $response = array (	"desc" => $preview);

        } else {
            $response = array (	"desc" => "queryID oder queryAppID konnte nicht ermittelt werden!");
        }
        return $response;
    }




    /** Ermittelt das Ergebnis einer Plugin . Java-RequestFunktion. Die genaue Funktion muss als Eingangsparameter 
     * benannt werden.
     * 
     * @param   array   $in_POST    Array, mit zwei Attributen <br />
     *                              function_name -> Name der aufzurufenden Methode; Syntax: app_id.class.methode; Bsp.: SYS01.functions_ajaxrequest.hello_world <br />
     *                              row_field_list -> String mit den Werten (FormID, FieldAppID, FieldID, FieldContent) von allen Elementen der Datenzeile.
     *                                                  Die einzelnen Feldattribute werden durch 3 Unterstriche getrennt. Felder werden durch 5 Unterstiche getrennt.
     *                                                  Bsp.: "212|||BIM01|||2025|||00029301|||0allg0permission_bst0bst0Form212_0_i0new_____212|||BIM01|||2024||||||0allg0permission_bst0uid0Form212_0_i0new"
     * @return  string              HTML-Code, welcher direkt im HTML-DOM integriert werden kann.
     */
    function getFeedbackFromPhpFunction($in_POST) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte : ', $in_POST);

        if(isset($in_POST["function_name"]) AND isset($in_POST["row_field_list"])) {
            $feedback = chooseAjaxFunction($in_POST["function_name"], $in_POST["row_field_list"], $in_POST["form_id"], $in_POST["sender_field_id"]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ergebnis chooseAjaxFunction: ', $feedback);
            $response = array (	"desc" => $feedback);

        } else {
            $response = array (	"desc" => "queryID oder queryAppID konnte nicht ermittelt werden!");
        }
        return $response;
    }





    
    /** Bereitet ein FeedbackString für ein AjaxRequest vor, welcher den Value eines Feldes überprüft.
     * Wenn der Check negativ ausfiel, dann wird eine Fehlermeldung eingeblendet und alle Submit-Buttons deaktiviert.
     * 
     * @param bool      $in_is_error            Wenn true, wird Fehlermeldung angezeigt und Submit-Buttons deaktiviert.
     * @param string    $in_message             Fehlermeldung, die den Usern angezeigt werden soll.
     * @param integer   $in_target_field_Id     ID des Feldes, dessen Inhalt geprüft wurde.
     * @param string    $in_domID_of_Field      ID des Feldes im DOM des Feldes, dessen Inhalt geprüft wurde.
     * @param integer   $in_sender_form_id      ID des Formulars, in dem sich das Feld befindet
     * @param string    $in_sender_instance_id  ID der Instanz des Formulars
     * @return string                           Bsp.: "error|||1_____message|||In der APP-ID <b>Paul</b> sind unerlaubte Zeichen vorhanden. <br />Bitte verwenden Sie nur Großbuchstaben und Ziffern von 1-9. Das erste Zeichen soll ein Buchstabe sein. <br />Zudem muss die APP-ID genau 5 Zeichen lang sein._____target_field|||7995_____deactivate_submitbutton|||1_____target_domID|||0manager0app0id0Form1228_0_i0new_____formID|||1228_____instanceID|||i0new"
     */
    function prepareFeedbackForAjaxReqCheckValueOfAField($in_is_error, $in_message, $in_target_field_Id, $in_domID_of_Field, $in_sender_form_id, $in_sender_instance_id) {
        if($in_is_error === true) {$error = "1";} else {$error = "0";}
        
        
        $localfeedback["error"] = "error".global_variables::getDelimiterFieldAttribut().$error;
        $localfeedback["message"]  = "message".global_variables::getDelimiterFieldAttribut().$in_message;
        $localfeedback["target_field"] = "target_field".global_variables::getDelimiterFieldAttribut().$in_target_field_Id;
        $localfeedback["deactivate_submitbutton"] = "deactivate_submitbutton".global_variables::getDelimiterFieldAttribut().$error;
        $localfeedback["target_domID"] = "target_domID".global_variables::getDelimiterFieldAttribut().$in_domID_of_Field;
        $localfeedback["formID"] = "formID".global_variables::getDelimiterFieldAttribut().$in_sender_form_id;
        $localfeedback["instanceID"] = "instanceID".global_variables::getDelimiterFieldAttribut().$in_sender_instance_id;

        
        $feedback= implode(global_variables::getdelimiterFields(), $localfeedback);
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Rückgabewert: ', $feedback);   
        
        
        return $feedback;
    }
    

    
    
    /** Bereitet den Rückgabewert für Ajax auf (serialisieren nach AppMS-Syntax) und 
     * hinterlegt den Rückgabewert auch im Session_Backup, wenn es sich um ein geschütztes Feld handelt
     * 
     * @param   integer     $in_targetField         ID des Feldes, in dem der Wert eingetragen werden soll
     * @param   string      $in_value               Wert, der im Targetfeld eingtragen werden soll.
     * @param   array       $in_params              Parameterliste, wie sie von chooseAjaxFunction bereitgestellt wird
     * @return  string                              serialisierter Rückgabewert; Bsp.: 2345|||value
     */
    function prepareFeedbackForAjaxReqValueForField($in_targetField, $in_value, $in_params) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> prepare Rückgabewert: ', $in_value); 
        $temp_array = array();
        $temp_array[]=$in_targetField.global_variables::getDelimiterFieldAttribut().$in_value;
        
        //Rückgabewerte müssen, wenn sie in geschützte Felder eingetragen werden sollen, auch in SecureFields hinterlegt werden
        $is_onlyread_field = getAttributFromAjaxFieldlist($in_params, $in_targetField, "read_only");
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> is_onlyread_field: ', $is_onlyread_field);
        
        if($is_onlyread_field == 1) {
            $form_id = getAttributFromAjaxFieldlist($in_params, $in_targetField, "formID");
            $instance_id = getAttributFromAjaxFieldlist($in_params, $in_targetField, "instance");
            $ds = getAttributFromAjaxFieldlist($in_params, $in_targetField, "ds");
            $domID = getAttributFromAjaxFieldlist($in_params, $in_targetField, "domID");
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Attribute ermittelt");
        
            setNewDataForSecureFieldsInSessionBackup($form_id, $instance_id, $ds, $domID, $in_value);
        }  
        
        
        //Rückgabewerte wieder in String umwandeln
        $feedback = implode(global_variables::getdelimiterFields(), $temp_array);
        return $feedback;
    }


    
    
    



?>