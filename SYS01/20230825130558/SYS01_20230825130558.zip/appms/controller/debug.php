<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

    require_once("../controller/functions.php");
    
    $app_id_from_kernel = global_variables::getAppIdFromSYS01();
    $debug_mask = getCurrentAppIdForDebug();
    $starttime = date("Y-m-d\TH:i:s");
    $debug = '';
    $debug_param = getDebugParam($debug_mask["app_id"], $debug_mask["id"]);                            //gibt an, Fehlermeldungen protokolliert werden sollen
    $debug_array_length = getConfig("debug_array_length", $debug_mask["app_id"]);   //Länge (items), bei der Arrays im Protokoll abgeschnitten werden
    $SqlErrors = array();                                                       //Liste der SQL-Fehler. Jeder Eintrag ist wiederum ein Array mit den keys "query" und "errorMessage"
    
    
    
    /** Ermittelt die App-ID der target-Mask aus GET (wenn vorhanden), POST (wenn vorhanden) oder SESSION.
     * Wenn diese nicht existiert, wird die APP-ID des Kernsystems zurückgegeben.
     * 
     * @return  array           Bsp.: array(app_id => SYS01, id => 123)
     */
    function getCurrentAppIdForDebug() {
        $feedback = array();
        if(isset($_GET["maskapp"])) {
            //Aufruf erfolgt über URL/Link oder Button
            $feedback["app_id"] = $_GET["maskapp"];
            $feedback["id"] = $_GET["mask"];
        } elseif(isset($_POST["function_name"])) {
            //Aufruf erfolgt über ajax
            $function = $_POST["function_name"];                                //Bsp.: NV11.functions_ajaxrequest.getSumAssets.pruefGrpField.9504.targetField.10456
            $function_array = explode(".", $function);
            $feedback["app_id"] = $function_array[0];
            $feedback["id"] = "unknown";
        } elseif(isset($_SESSION["target_mask"]["app_id"])) {
            //unklarer Aufruf
            $feedback["app_id"] = $_SESSION["target_mask"]["app_id"];
            $feedback["id"] = $_SESSION["target_mask"]["id"];
        } else {
            //Notfall-Lösung
            $feedback["app_id"] = global_variables::getAppIdFromSYS01();
            $feedback["id"] = "unknown";
        }
        
        return $feedback;
    }
    
    
    
    
    /** liest den Parameter "debug" aus. Dabei wird auch geprüft, ob debug auf der target_mask erlaubt ist (siehe Parameter "debug_blocked_masks".
     * 
     * @global  string  $app_id_from_kernel     APP-ID des Kernmoduls
     * @param   string  $in_app_id              APP-ID der aufgerufenen Maske
     * @param   integer $in_target_mask_id      ID der aufgerufenen Maske
     * @return  boolean                         Feedback, ob debug angewendet werden soll.
     */
    function getDebugParam($in_app_id, $in_target_mask_id) {
        global $app_id_from_kernel;
        
        //gibt an, ob Fehlermeldungen protokolliert werden sollen
        $my_debug_param = getConfig("debug", $in_app_id);                           
        
        //falls eine Maske aus der Kernel-APP aufgerufen wird, prüfen, ob die Protokollierung der Target-Maske unterdrückt werden soll.
        if($in_app_id == global_variables::getAppIdFromSYS01()) {
            $debug_blocked_masks_string = getConfig("debug_blocked_masks", $app_id_from_kernel);   //Liste der Masken, die nicht ge-debugged werden. (login, damit Passwort nicht geloggt wird, Debug, da sonst Zirkelbezug entsteht.)
            $debug_blocked_masks_array = explode(",", str_replace(" ", "", $debug_blocked_masks_string));
            if(in_array($in_target_mask_id, $debug_blocked_masks_array) !== false) {$my_debug_param = false;}
        }
        return $my_debug_param;
    }
    
    
    
    /** Speichert die Fehlermeldung und die Query eines fehlgeschlagenen SQL-Befehls im Array "SqlErrors" ab.
     * 
     * @param String    $in_SqlErrorMsg
     * @param String    $in_SqlQuery
     * @param String    $in_callFromFunction            Funktion, welche den SQL-Befehl auslöste
     */
    function addToDebugSqlError($in_SqlErrorMsg, $in_SqlQuery, $in_trigger_function) {
        global $SqlErrors;
        $MySqlError['trigger_function'] = $in_trigger_function;
        $MySqlError['query'] = $in_SqlQuery;
        $MySqlError['errorMessage'] = $in_SqlErrorMsg;
        $SqlErrors[] = $MySqlError;
    } 
    
    
    
    /** prüft, ob der SQL-Befehl der  trigger_function eine Fehlermeldung verursacht hat und gibt diese ggf. zurück.
     * 
     * @param  String   $in_trigger_function    SQL-Befehl
     * @return mixed                            false, falls keine Fehler auftrat oder die Fehlermeldung [Array("trigger_function","query","errorMessage")]  
     */
    function occurredSqlError($in_trigger_function) {
        global $SqlErrors;
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> suche Errors in', $SqlErrors);
        if(is_array($SqlErrors)) {
            foreach ($SqlErrors as $key => $currentSqlError) {
               if($currentSqlError['trigger_function'] == $in_trigger_function) {                            
                   return $currentSqlError;
               }
            }
        }
        return false;
    }
    
    
    /** prüft, ob irgendein SQL-Fehler auftrat
     * 
     * @return integer              Gibt die Anzahl der SQL-Fehler zurück, die bisher auftraten  
     */
    function occurredAnySqlError() {
        global $SqlErrors;
        
        return count($SqlErrors);
    }
    
    
    
    /** Ergänzt eine übergebene Debug-Meldung zum Debug-String <br />
     *  Warum gibt es eine eigene debug-Methode, wenn PHP doch schon error_log bietet? <br />
     *  Weil error_log nicht für große strings geeignet ist, bspw. den Inhalt der Session_Variable.<br />
     *  ToDo: Dennoch sollte über die Nutzung von error_lo nachgedacht werden, da es auch bei fehlendr DB-Verbindung  den Istzustand wiedergeben kann. <br />
     *  <br />
     *  Bsp. für eine sinnvolle Verwendung: addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> NochEinSinnVollerHinweis: ', $Variable, ["ERROR"|"INFO"]);
     *  Beachte die Konfigurationsparameter debug, debug_array_length und debug_timetolife.
     * 
     * @global  String      $debug              globaler Debug-String wird genutzt
     * @param   String      $in_topic           Überschrift
     * @param   variabel    $in_debug_message   Die auszugebene Meldung, kann per String oder Array übergeben werden.
     * @param   String      $debug_type         [optional] Art der Debug-Meldung. Default = INFO
     * @return  Boolean                         Funktion gibt  TRUE zurück, wenn debug_param auf true steht
     */
    function addToDebug($in_topic, $in_debug_message, $debug_type = "INFO") {
        global $debug;
        global $debug_param;
        global $debug_array_length;
        global $debug_mask;
        $current_debug_message = "";
        
        if ($debug_param==TRUE) {
//          $debug = $debug.'<br />'.$in_topic.'<br />'.serialize($in_debug_message).'<br />';
            $debug = $debug."<br /><b>".date("d.m.Y - H:i:s")." > ".$in_topic."</b><br />";
            if ($debug_type == "ERROR") {$debug = $debug."<b><font color = \"red\">ERROR: </font></b>";} else {$debug = $debug."<b>$debug_type: </b>";}
            
            if (is_array($in_debug_message)) {
                if($debug_array_length > 0 AND count($in_debug_message) > $debug_array_length) {
                    $in_debug_message = array_slice($in_debug_message, 0, $debug_array_length);     
                    $current_debug_message = print_r($in_debug_message,TRUE)."\n\n [... gekürzt aufgrund Konfigurationsparamter debug_array_length]";
                } else {    
                    $current_debug_message = print_r($in_debug_message,TRUE);
                }
                addDebugToDatabase($in_topic, $current_debug_message, $debug_type);
            
            } elseif (is_object($in_debug_message)) {
                $current_debug_message = serialize($in_debug_message);
                addDebugToDatabase($in_topic, $current_debug_message, $debug_type);           //Zeile würde zu einem DB-Fehler führen, da auch Hochkommata enthalten sind.
                //addDebugToDatabase($in_topic, "Object", $debug_type);
                
            } else {
                $current_debug_message = $in_debug_message;
                addDebugToDatabase($in_topic, $current_debug_message, $debug_type);
            }
            
            $debug = $debug.$current_debug_message."<br />";
            
            
        return TRUE;
        
        }
        
        return FALSE;
        
    }
   
    
    
    
    /**
     * Ausgabe der Debug-Meldungen im div mit der ID debug, wenn der Konfigurationsparameter debug = TRUE ist.
     * 
     * @param    object     $in_pagedata        Referenz auf das pagadata-object
     */
    function deleteOldDebugMessages(&$in_pagadata) {
        global $debug_mask;
        $debug_timeToLife = getConfig("debug_timeToLife", $debug_mask["app_id"]);
        
        deleteDebugData($in_pagadata, $debug_timeToLife);                      //alte Debug-Meldungen löschen
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ende: ', '--ENDE-------------------------------------------------------------');
    }
    
    
    
    /**
     * Schreibt die aktuelle Debug-Meldung in die Datenbank
     * @param   String      $in_topic           Überschrift
     * @param   Variable    $in_debug_message   Die auszugebene Meldung, kann per String oder Array übergeben werden.
     * @param   String      $in_debug_type      Art der Debug-Meldung. Default = INFO; Wenn ERROR, dann erfolgt eine rotfarbender Andruck.
     */
    function addDebugToDatabase($in_topic, $in_debug_message, $in_debug_type) {
        global $app_id_from_kernel;
        global $starttime;
        global $debug_mask;
        
        $context = $debug_mask["app_id"]." - Mask-ID: ".$debug_mask["id"];
        $connection_id = $app_id_from_kernel;                                                                      
        insertDataIntoDebug($connection_id, $in_debug_type, $in_topic, $in_debug_message, $starttime, $context);
    }
    
    
    
    /** Schreibt alle gesammelten Debug-Meldungen in eine Textdatei
     * 
     * @global  String  $debug          globale Variable wird verwendet
     * @param   String  $in_path        relativer oder absoluter Speicherpfad (Bsp.: /var/www/)
     * @param   String  $in_filename    Dateiname, inkl. Dateiendung (Bsp.: debug.html)
     */
    function writeDebugToFile($in_path, $in_filename) {
        global $debug;
        writeFile($in_path, $in_filename, $debug);
    }
    
?>