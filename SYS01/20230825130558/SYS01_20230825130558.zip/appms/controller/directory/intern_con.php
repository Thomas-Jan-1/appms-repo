<?php		

 /* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

    require_once("../controller/functions_db.php");          //nur bei Direktaufruf notwendig

    $db_schema_manager                  = global_variables::getNameOfDbSchemaSYS01();                                    //Name des Schemas, in dem diese Anwendung liegt
    $db_schema_manager_connection_id    = global_variables::getConnectionIdOfDbSchemaSYS01();




    /** Prüft Account-id (uid) und Passwort mit Hilfe der internen Accountverwaltung.
     * @param   String  $in_directory_id    ID des Directories, welches den User validieren soll (siehe DB-Tabelle directory) [Achtung: Dieser Parameter wird beim internen directory ignoriert!]
     * @param   String  $in_account         Account_id
     * @param   String  $password           Passwort
     * @param   String  $in_account_app_id  App-ID des Accounts 
     * @return  Boolean
     */
    function checkUserAccount($in_directory_id, $in_account, $password, $in_account_app_id) {								
        												//Error-Reporting abschalten, damit bei Eingabe eines falschen Passwortes keine kryptischen fehlermeldungen auf dem Bildschirm erscheinen.
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . '', 'Benutzervalidierung via internem Verzeichnis');
        
        global $db_schema_manager;
        global $db_schema_manager_connection_id;
        
        $password_hash = getDataFromTableByID($db_schema_manager_connection_id, $db_schema_manager, "account", "password_hash", "id = '".$in_account."' and app_id = '".$in_account_app_id."'");									

        

//        if (hash_equals($password_hash, crypt($password,'salt§String')) == true) {		//alte Variante bis 26.01.2019
        if(password_verify($password, $password_hash) == true) {	
                //Passwort ist korrekt
                
                //Prüfen, ob der Account abgelaufen ist
                $accountIsValid = checkUserAccountIsValid($in_account, $in_account_app_id);
                if($accountIsValid == true) {
                    $checkResult = true;
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, 'Accountdaten sind valide');
                } else {
                    $checkResult = false;
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, 'Account ist gesperrt');
                }
        } else {
                //Passwort ist falsch
                $checkResult = false;
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, 'Accountpasswort ist falsch');

        }

        										//Error-Reporting wieder einschalten
        return $checkResult;
    }






    //Die Funktion hash_equals existiert in PHP erst ab Version 5.6.
    //Daher wird sie nachfolgend nur dann eingefügt, wenn sie nicht vorhanden ist.
//    if(!function_exists('hash_equals')) {
//        function hash_equals($str1, $str2) {
//            if(strlen($str1) != strlen($str2)) {
//                return false;
//            } else {
//                $res = $str1 ^ $str2;
//                $ret = 0;
//                for($i = strlen($res) - 1; $i >= 0; $i--) {
//                    $ret |= ord($res[$i]);
//                }
//                return !$ret;
//            }
//        }
//    }
    
    
    
    



?>