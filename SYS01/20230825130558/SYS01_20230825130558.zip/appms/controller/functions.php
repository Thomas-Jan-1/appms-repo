<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

    require_once("../controller/functions_db.php");          //nur bei Direktaufruf notwendig
    require_once("../controller/functions_filesystem.php");  
    require_once("../controller/crypt_class.php");

    $db_schema_manager = global_variables::getNameOfDbSchemaSYS01();                                    //Name des Schemas, in dem diese Anwendung liegt
    $db_schema_information = global_variables::getNameOfDbSchemaInformation();                          // Name der Datenbank, in der sich Schema-Informationen finden (bei Postgres = information_schema)
    $db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
    $app_id_from_kernel = global_variables::getAppIdFromSYS01();
    $config_param_list = array();
    
    
    
    /** Ermittelt alle Parameter der Tabelle Konfiguration, auf die der angemeldte user Zugriff hat.
     * 
     * @global string $db_schema_manager        Wird verwendet
     * @return array                            Liste der Konfigurationsparameter
     *                                                  Array
                                                            (
                                                                [0] => Array
                                                                    (
                                                                        [konfiguration.id] => 120
                                                                        [konfiguration.app_id] => SYS01
                                                                        [konfiguration.parameter] => field_separator
                                                                        [konfiguration.beschreibung] => String, welcher im Hash-Wert einer Datenzeile als Feldtrenner verwendet wird.
                                                                        [konfiguration.wert] => |
                                                                        [konfiguration.sys] => 1
                                                                    )

                                                                [1] => Array
                                                                    (
                                                                        [konfiguration.id] => 8
                                                                        [konfiguration.app_id] => SYS01
                                                                        [konfiguration.parameter] => debug_timeToLife
                                                                        [konfiguration.beschreibung] => Zeitspanne in Sekunden, nach der alte Debug-Meldungen gelöscht werden.
                                                                        [konfiguration.wert] => 300
                                                                        [konfiguration.sys] => 1
                                                                    )
                                                            )
     */
    function getConfigParamList() {
        global $db_schema_manager;
        $feedback = getTableData(global_variables::getConnectionIdOfDbSchemaSYS01(), "konfiguration", $db_schema_manager, true);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  config_param_list', $feedback);
        
        return $feedback;
        
    }
    
    
    
    /** Prüft, ob essich bei dem übergebenen User, um root handelt.
     * 
     * @param   string  $in_user    user_id
     * @return  boolean             
     */
    function isUserRoot($in_user) {
        if(strpos($in_user, "root") > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    
    
    
    
    
    /** Ermittelt aus der Session den aktuellen Fortschritt des laufenden Jobs
     * 
     * @return  array           Liste der Fortschrittsattribute: <br>
     *                          start_value -> kleinster Wert der Range <br>
     *                          cur_value -> akzueller Wert <br>
     *                          end_value -> größter Wert der Range <br>
     *                          desc -> Beschreibung des Prozesses <br>
     */
    function getProgressStatus() {
                 
        
        //Fortschritt aus aktueller Session ermitteln
        $condition = "session_id = '". session_id()."'";
        $progress_status = getTableData(global_variables::getConnectionIdOfDbSchemaSYS01(), "session", global_variables::getNameOfDbSchemaSYS01(), 1, "", $condition, __FUNCTION__);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> progress_status: ', $progress_status);

        
        //Rückgabewerte für ajax-Feedback setzen
//        $feedback["start_value"] = $progress_status[0]["session.progress_start"];
//        $feedback["cur_value"] = $progress_status[0]["session.progress_current"];
//        $feedback["end_value"] = $progress_status[0]["session.progress_end"];
//        $feedback["desc"] = $progress_status[0]["session.progress_task"];
        
        $percent = round($progress_status[0]["session.progress_end"] / $progress_status[0]["session.progress_current"] * 100, 0);
        $feedback["message"] = '<label for="first_appms_progress">'.$progress_status[0]["session.progress_task"].':</label> <br>'.
                               '<progress id="first_appms_progress" value="'.$progress_status[0]["session.progress_current"].'" max="'.$progress_status[0]["session.progress_end"].'"> '.$progress_status[0]["session.progress_task"].' </progress>';
        $feedback["percent"] = $percent;
        
        return $feedback;
    }
    
    
    
    
    
    
    
    

    /** Fügt Daten eines Datensatzes, als Inhaltselemente, in eine Felderliste ein. Zuordnung erfolgt über Tabelle.spalte.
     * 
     * @param Array $fieldlist zweidimensionales Feld, dass die Felder einer Maske enthält. Wird von getFieldlist erzeugt.
     * @param Array $data eindimensionales Feld, welches Inhaltswerte einzelner Felder enthält. key = Tabelle.spalte, value = Inhaltswert
     * @return Array fieldlist ergänzt um Feldinhalte
     */
    function matchFieldsToData($fieldlist, $data) {
        for ($i = 0; $i < count($fieldlist); $i++) {                            //Felder einzeln durchgehen und prüfen, ob es entsprechende Feldinhalte in $data gibt
            $tabelle = $fieldlist[$i] ["form.db_table"];
            $spalte = $fieldlist[$i] ["feld.spalte"];

            if (isset($data [$tabelle . "." . $spalte])) {      //Wenn es in data einen Wert für das gesuchte Feld gibt, wird das Array, um die ID "feldinhalt" erweitert und der Wert übertragen
                $fieldlist[$i] ["feld.feldinhalt"] = $data [$tabelle . "." . $spalte];
            } else {           //Wenn es in data keinen Wert für das gesuchte Feld gibt, wird das Array dennoch um die ID "feldinhalt" erweitert, jedoch mit "" belegt.													
                $fieldlist[$i] ["feld.feldinhalt"] = "";
            }
            
            //Prüfen, ob es sich bei dem aktuellen Datensatz, um einen SYS-Datensatz handelt
            if(isset($data[$tabelle.".sys"])) {
                if($data[$tabelle.".sys"] == 1) {
                    //Der  Datensatz wird als SYS-Datensatz gekennzeichnet. Diese Information wird im ersten Feld , statt eine Ebene höher, eingefügt, damit das Array fieldlist nicht wächst.
                    $fieldlist[0]["datensatz.sys"] = true;
                }
            }
        }
        return $fieldlist;
    }
    
    
    
    /** Ermittelt aus dem Row-Array, welches durch JS übermittelt wird, die aktuell erfassten Daten.
     * Das Array kann bspw. wie folgt ausshene: <br />
     * Array ( <br />
[0] => Array ( [formID] => 1032 [fieldAppID] => SYS01 [fieldID] => 6935 [fieldContent] => postgresql [name] => DBMS [spalte] => dbms [db_schema] => [db_table] => ) <br />
[1] => Array ( [formID] => 1032 [fieldAppID] => SYS01 [fieldID] => 6937 [fieldContent] => localhost [name] => Host [spalte] => host [db_schema] => [db_table] => ) <br />
[2] => Array ( [formID] => 1032 [fieldAppID] => SYS01 [fieldID] => 6943 [fieldContent] => 5432 [name] => Port (Datenbank) [spalte] => port [db_schema] => [db_table] => ) <br /> 
[3] => Array ( [formID] => 1032 [fieldAppID] => SYS01 [fieldID] => 6945 [fieldContent] => appms [name] => Datenbank-Name [spalte] => dbname [db_schema] => [db_table] => ) <br />
[4] => Array ( [formID] => 1032 [fieldAppID] => SYS01 [fieldID] => 6948 [fieldContent] => appms [name] => DB-User [spalte] => user [db_schema] => [db_table] => ) <br />
[5] => Array ( [formID] => 1032 [fieldAppID] => SYS01 [fieldID] => 6949 [fieldContent] => test [name] => Passwort [spalte] => password [db_schema] => [db_table] => ) ) <br />
     * 
     * @param   array   $in_field_list      Siehe oben
     * @param   string  $in_column_name     Name der Spalte, anhand dessen das gesuchte Feld identifiziert werden soll. (bspw. "spalte")
     * @param   string  $in_field_name      gesuchtes Feld. (bspw. "host")
     * @return  string                      fieldcontent des gesuchten Feldes. (bspw. "localhost")
     */
    function extractFieldvalueFromRow($in_field_list, $in_column_name, $in_field_name) {
        $feedback = "";
        
        foreach ($in_field_list as $key => $current_field) {
            if($current_field[$in_column_name] == $in_field_name) {
                $feedback = $current_field["fieldContent"];
            }
        }
        
        return $feedback;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    /** Ersetzt alle Platzhalter in $in_dataset durch Values aus $in_form_array oder $in_dataset selbst.
     * Platzhalter werden mit $$ gekennzeichnet. Bsp.: $$form.name$$
     * 
     * @param   array   $in_form_array      Form-Array
     * @param   array   $in_dataset         Array eines Formulardatensatzes
     * @return  array                       Array, analog dem $in_dataset, jedoch mit ersetzten Platzhaltern.
     */
    function replacePlaceholderInDataset($in_form_array, $in_dataset) {
        
        $new_dataset = array();
        //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Formulardaten', $in_form_array);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' ->  Datensatz', $in_dataset);
        
        //Schleife über alle Werte in $in_dataset, um zu prüfen, ob Platzhalter vorhanden sind.
        foreach ($in_dataset as $key => $value) {
            //Prüfen, ob ein Platzhalter innerhalb eines Values (Feldeintrag) vorhanden ist
            $new_value = $value;
            if(strpos($value, "$$") !== false) {
                //Alle Werte des Dataset werden geprüft, ob sie dem zuvor gefundenen Platzhalter entsprechen.
                foreach ($in_dataset as $key2 => $value2) {
                    if(is_array($value2) === false) {
                        $searchstring = "$$".$key2."$$";
                        $new_value = str_replace($searchstring, $value2, $new_value);
                    }
                }
                
                //Alle Daten des Form-Arrays werden geprüft
                foreach ($in_form_array as $key3 => $value3) {
                    if(is_array($value3) === false) {
                        $searchstring = "$$".$key3."$$";
                        $new_value = str_replace($searchstring, $value3, $new_value);
                    }
                }
            }
            
            $new_dataset[$key] = $new_value;
        }
        
        
        
        return $new_dataset;
        
    }
    
    
    
    
    
    
    
    
    /**Wählt die Plugin-Funktion, welche im Auftrag des Ajax-Requests ausgeführt werden soll. <br />
     * HINWEIS: <br />
     * Die JS-Funktionen, welche diese Ajax-Funktion nutzen können über AjaxRequest.php ermittelt werden. <br />
     * Die PHP-Funktionen, welche durch chooseAjaxFunction aufgerufen werden, können dann wiederrum anhand der JS-Funktionsaufrufe <br />
     * in den DB-Spalten feld.javascript_onclick, feld.javascript_onchange und feld.javascript_onsubmit und der zugehörigen Felder (feld.js_[xxx]_params) <br />
     * ermittelt werden.
     * 
     * @param   string  $in_function_name   APP-ID, Klasse und Name der Funktion; Bsp.: SYS01.functions_ajaxrequest.demo. <br />
     *                                      ACHTUNG: Achtung der Rückgabewert der Funktion muss ein String sein. Arrays müssen vorher ggf. ins json-Format umgewandelt werden.
     * @param   string  $in_paramlist       Daten des aktuellen Datensatzes; Bsp.: Bsp.: "212|||BIM01|||2025|||00029301|||0allg0permission_bst0bst0Form212_0_i0new_____212|||BIM01|||2024||||||0allg0permission_bst0uid0Form212_0_i0new"
     * @param   integer $in_form_id         ID des sendenden Formulars
     * @param   string  $in_sender_field_id ID des auslösenden Feldes
     * @return  string                      HTML-Code, welcher in der Oberfläche als Feedback genutzt werden kann.
     */
    function chooseAjaxFunction($in_function_name, $in_paramlist, $in_form_id, $in_sender_field_id) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> call Function: ', $in_function_name);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> call with Functionparams: ', $in_paramlist);
        $kernelAppId = global_variables::getAppIdFromSYS01();

        $paramlist = changeFieldlistAsStringToFieldListAsArray($in_paramlist);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> paramlist: ', $paramlist);
        
        //Formulardaten, inkl.Default-Field-Liste, des sendenden Formulars ausSession-Backup ermitteln.
        $formArray = getFormArrayFromSessionBackup($in_form_id);
            
        if($formArray == false) {
            // Diese Situation kann auftreten, wenn die Session abgelaufen und bereits gelöscht wurde.
            // Es könnte auch sein, dass parallel in verschiedenen Browser-Tabs mit verschiedenen Masken gearbeitet wird.
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Für dieses Formular ist kein Backup in SESSION vorhanden: ', "Form_ID = ".$in_form_id);
            $message = getFeedbacktextForFunction(-135, $kernelAppId);
            $feedback = prepareFeedbackForAjaxReqCheckValueOfAField(true, $message[0]["konstante.klartext"], $in_sender_field_id, "undefined", $in_form_id, "i0");
            return $feedback;          //Return-Code nicht auflösen, da er auf JS-Seite sonst nur schwer aufgelöst werden kann.
        }
        
        $field_metadata = $formArray["form.default_fields"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Field-Metadaten: ', $field_metadata);
        
        //Daten des aktuellen Datensatzes um Metadaten der Felder ergänzen
        $new_paramlist = addMetadataToFields($paramlist, $field_metadata);
        
        //Daten um das Attribut "senderField" ergänzen.
        $new_paramlist = markSenderField($new_paramlist, $in_sender_field_id);        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> new_paramlist: ', $new_paramlist);
        
        
        //Funktion aufrufen
        $feedback = "";
        if ($in_function_name <> "") {
                //Funktionseigenschaften ermitteln. Dazu muss $in_function_name  wie folgt aussehen: app_id.class.methode.param1.value1.param2.value2...
                $function_properties = changeAjaxParamsToArray($in_function_name);
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> function_properties: ', $function_properties);
                
           
                //Die Klassen und Methoden werden im Plugin-Verzeichnis der jeweiligen APP gesucht (..\data\[APP-ID]\plugin)
                if(in_array($function_properties["function_app"],array($formArray["form.app_id"], $kernelAppId))== false) {
                    //Plugin aus einer fremden APP darf nicht aufgerufen werden.
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Error ', "Plugin aus einer fremden APP darf nicht geladen werden.", "ERROR");
                    $feedback = "error:-3005:".$kernelAppId;
                } elseif(loadPlugin($function_properties["function_app"], $function_properties["function_class"]) == true) {
                    //Plugin konnte geladen werden.
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Plugin ', "Plugin geladen.", "INFO");
                    $function_object = new $function_properties["function_class"]();
                    $myMethod = $function_properties["function_name"];
                    if(method_exists($function_object, $myMethod) == true) {
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Plugin ', "Methode ".$myMethod." gefunden", "INFO");
                        $feedback = $function_object->$myMethod($new_paramlist, $function_properties);
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ergebnis von '.$myMethod.': ', $feedback);
        
                    } else {
                        $feedback = "error:-3004:".$kernelAppId;
                    }
                } else {
                    //Plugin konnte nicht geladen werden
                    //button_action_function_app_id auf Kernel-App setzen, damit der richtige Fehlertext ermittelt wird.
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Error ', "Plugin konnte nicht geladen.", "INFO");
                    $feedback = "error:-3002:".$kernelAppId;
                }
            
            
        
            
        } else {
            //Parameter in feld.js_click_params wurde nicht angegeben
            $feedback = "error:-3001:".$kernelAppId;
        }
        
        
        //Fehlermeldung auflösen
        if(substr($feedback, 0, 6) == "error:") {
            $error_array = explode(":", $feedback);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> errorcode: ', $feedback);
        
            $localfeedback = getFeedbacktextForFunction($error_array[1], $error_array[2]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> errormsg: ', $feedback);
            $feedback = $localfeedback[0]["konstante.klartext"];
        
        }
        
        return $feedback;
    }
    
    
    /** Wandelt eine Liste von Paramtern, die per Ajax in einem String übergeben wurden, in ein Array um.
     * Als Eingabeparameter wird ein String mit folgender Syntax erwartet: <br />
     * APP-ID.Dateiname.Methode.param1.wert1.param2.wert2... <br />
     * <br />
     * Rückgabewert: array{
     *                  function_app => APP-ID,
     *                  function_class => Dateiname,
     *                  function_name => Methode,
     *                  param1 => wert1,
     *                  param2 => wert2,
     *                  param3 => wert3
     *                  }
     *
     * 
     * @param   string  $in_ajax_params     Parameter als String. Bsp.: siehe oben   
     * @return  array
     */
    function changeAjaxParamsToArray($in_ajax_params) {
        $feedback = array();
        
        $function_properties = explode(".", $in_ajax_params);
        
        for($i = 0; $i < count($function_properties); ++$i) {
            if      ($i==0) {$feedback["function_app"] = $function_properties[$i];}
            elseif  ($i==1) {$feedback["function_class"] = $function_properties[$i];}
            elseif  ($i==2) {$feedback["function_name"] = $function_properties[$i];}
            elseif  ($i % 2 != 0) {
                //es liegt eine ungerade Zahl und somit ein Parametername vor. Der Parameterwert sollte im darauffolgenden Feld liegen.
                if(isset($function_properties[$i+1])) {
                    $feedback[$function_properties[$i]] = $function_properties[$i + 1];
                }
            }
        }
        return $feedback;
    }
    
    
    
    /** fügt der field_list ein weiteres Attribut (senderField) hinzu, welches das sendende Feld mit senderField= true kennzeichnet.
     * 
     * @param   array  $in_field_list    Bsp.: Array
                                                (
                                                    [0] => Array
                                                        (
                                                            [formID] => 922
                                                            [fieldAppID] => BIM01
                                                            [fieldID] => 5795
                                                            [fieldContent] => 02600000
                                                            [name] => Kostenatelle
                                                            [spalte] => bst
                                                            [db_schema] => allg
                                                            [db_table] => permission_bst
     *                                                      [only_read] => 0
                                                        )

                                                    [1] => Array
                                                        (
                                                            [formID] => 922
                                                            [fieldAppID] => BIM01
                                                            [fieldID] => 5803
                                                            [fieldContent] => wolowels
                                                            [name] => Person
                                                            [spalte] => uid
                                                            [db_schema] => allg
                                                            [db_table] => permission_bst
     *                                                      [only_read] => 1
                                                        )
     *                                              }
     * @param   integer     $in_sender_field_id     ID des sendenden Feldes
     * @return array
     */
    function markSenderField($in_field_list, $in_sender_field_id) {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> sender_field_id: ', $in_sender_field_id);
        
        foreach ($in_field_list as $key => $current_field) {
            if($current_field["fieldID"]==$in_sender_field_id) {
                $in_field_list[$key]["senderField"] = true;
            } else {
                $in_field_list[$key]["senderField"] = false;
            }
        }
        
        return $in_field_list;
    }
    
    
    
    /** fügt der field_list ein weiteres Attribut (senderField) hinzu, welches das sendende Feld mit senderField= true kennzeichnet.
     * 
     * @param   array  $in_field_list    Bsp.: Array
                                                (
                                                    [0] => Array
                                                        (
                                                            [formID] => 922
                                                            [fieldAppID] => BIM01
                                                            [fieldID] => 5795
                                                            [fieldContent] => 02600000
                                                            [name] => Kostenatelle
                                                            [spalte] => bst
                                                            [db_schema] => allg
                                                            [db_table] => permission_bst
     *                                                      [only_read] => 0
                                                        )

                                                    [1] => Array
                                                        (
                                                            [formID] => 922
                                                            [fieldAppID] => BIM01
                                                            [fieldID] => 5803
                                                            [fieldContent] => wolowels
                                                            [name] => Person
                                                            [spalte] => uid
                                                            [db_schema] => allg
                                                            [db_table] => permission_bst
     *                                                      [only_read] => 1
                                                        )
     *                                              }
     * @param   integer     $in_search_field        ID des gesuchten Feldes
     * @param   string      $in_attribut            Name des gesuchten Attributs. Bsp.: "db_schema"
     * @return  mixed                               Value des Attributs oder false, wenn das Attribut im Array nicht existiert.
     */
    function getAttributFromAjaxFieldlist($in_field_list, $in_search_field, $in_attribut) {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> in_fieldlist', $in_field_list);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> gesucht searchfield und attribut', $in_search_field." - ".$in_attribut);
        
        if(isset($in_field_list[$in_search_field])) {
            if(array_key_exists($in_attribut, $in_field_list[$in_search_field])) {
                return $in_field_list[$in_search_field][$in_attribut];

            } 
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> search_field_id ist nicht vorhanden', $in_search_field." - ".$in_attribut, "ERROR");
        }
        
        return false;
    }

    
    
    
    /** Ermittelt aus der übergebenen Fieldlist (siehe chooseAjaxFunction) das SenderField welches im Attribut "senderField"=true gekennzeichnet ist.
     * 
     * @param   array   $in_fieldlist
     * @return  array
     */
    function getSenderField($in_fieldlist) {
        $feedback = array();
        
        foreach ($in_fieldlist as $currentField) {
            if($currentField["senderField"]==true) {$feedback = $currentField;}
        }
        
        return $feedback;
    }
    

    
    
    /** Ergänzt zu einer Felderliste, welche per Ajax-Request übergeben wurde,
     * Metadaten der Felder aus der Session_Variable
     * 
     * @param   array   $in_fieldlist   Bsp.: Array
                                                    Array
                                                        (
                                                            [7462] => Array
                                                                (
                                                                    [formID] => 1110
                                                                    [fieldAppID] => BIM01
                                                                    [fieldID] => 7462
                                                                    [fieldContent] => 
                                                                    [domID] => 0fin0k_proj_syf0id0Form1110_0_i0new
                                                                )

                                                            [7475] => Array
                                                                (
                                                                    [formID] => 1110
                                                                    [fieldAppID] => BIM01
                                                                    [fieldID] => 7475
                                                                    [fieldContent] => 01007028
                                                                    [domID] => 0fin0k_proj_syf0proj0Form1110_0_i0new
                                                                )
                                                    ) 
     * @param   array   $in_metadata    Bsp.: siehe field_defaults in form_array
     * @return  array                   $in_fieldlist ergänzt um einige Attribute Bsp.:
     *                                  Array
                                                (
                                                    [0] => Array
                                                        (
                                                            [formID] => 1110
                                                            [fieldAppID] => BIM01
                                                            [fieldID] => 7462
                                                            [fieldContent] => 3
                                                            [domID] => 0fin0k_proj_syf0id0Form1110_1_i0
                                                            [ds] => 1
                                                            [instance] => i0
                                                            [name] => ID
                                                            [spalte] => id
                                                            [db_schema] => fin
                                                            [db_table] => k_proj_syf
                                                            [read_only] => 0
                                                            [senderField] => 
                                                        )

                                                    [1] => Array
                                                        (
                                                            [formID] => 1110
                                                            [fieldAppID] => BIM01
                                                            [fieldID] => 7475
                                                            [fieldContent] => 52118846
                                                            [domID] => 0fin0k_proj_syf0proj0Form1110_1_i0
                                                            [ds] => 1
                                                            [instance] => i0
                                                            [name] => Projekt
                                                            [spalte] => proj
                                                            [db_schema] => fin
                                                            [db_table] => k_proj_syf
                                                            [read_only] => 0
                                                            [senderField] => 
                                                        )
     */
    function addMetadataToFields($in_fieldlist, $in_metadata) {
        $feedback = array();
        foreach ($in_fieldlist as $field_id => $current_field) {
            foreach ($in_metadata as $key => $current_metadata) {
                if($field_id == $current_metadata["feld.id"]) {
                    $current_field["name"] = $current_metadata["feld.name"];
                    $current_field["spalte"] = $current_metadata["feld.spalte"];
                    $current_field["db_schema"] = $current_metadata["form.db_schema"];
                    $current_field["db_table"] = $current_metadata["form.db_table"];
                    $current_field["read_only"] = $current_metadata["feld.readonly"];
                    $feedback[$field_id] = $current_field;
                    break;
                }
            }
        }
        
        
        
        return $feedback;
    }
    
    
    
    
    
    
    /** Legt einen neuen Datensatz in der Tabelle mask an.
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     * 
     * @param  object   $in_pagedata        Referenz auf das pagedata-object
     * @param  string   $in_app_id          APP-ID in der die Maske, template und menü (parent_mask/ parent_site)  angelegt werden  
     * @param  string   $in_template_app_id APP-ID des CSS-Templates
     * @param  integer  $in_template_id     ID css_template
     * @param  string   $in_name            Name der Maske
     * @param  string   $in_link            Name der php-Datei, auf die verlinkt werden soll (Bsp.: page.php)
     * @param  string   $in_parent_mask_app APP-ID der parent_mask
     * @param  integer  $in_parent_mask     ID der übergeordneten Maske. Wenn sie nicht angegeben werden soll, dann NULL angeben
     * @param  string   $in_description     Beschreibung der Maske
     * @param  integer  $in_sort            Sortierung dr Maske innerhalb von parent_mask.
     * @param  integer  $in_level           Ebene, sollte eins größer sein, als Ebene von parent_mask
     * @param  integer  $in_navgroup        ID der zusätzlichen Navigationsgruppe. Wenn nicht notwendig, dann "" angeben
     * @param  integer  $in_navgroupsort    Sortierung innerhalb der zusätzlichen Navigationsgruppe. Wenn nicht notwendig, dann "" angeben
     * @return mixed                        Im Fehlerfall wird false zurückgegeben, ansonsten die ID des eingefügten Datensatzes
     */
    function setNewMask(&$in_pagedata, $in_app_id, $in_template_app_id, $in_template_id, $in_name, $in_link, $in_parent_mask_app, $in_parent_mask, $in_description, $in_sort, $in_level, $in_navgroup, $in_navgroupsort) {
        
        $nextID = getMaxValue(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "mask", "id");
        $nextID = $nextID + rand(1,10);
        
        if($in_template_app_id == "") {$in_template_app_id = "NULL";}
        if($in_template_id == "") {$in_template_id = "NULL";}
        if($in_parent_mask_app == "") {$in_parent_mask_app = "NULL";} 
        if($in_parent_mask == "") {$in_parent_mask = "NULL";} 
        if($in_sort == "") {$in_sort = "NULL";}
        if($in_level == "") {$in_level = "NULL";}
        if($in_navgroup == "") {$in_navgroup = "NULL";}
        if($in_navgroupsort == "") {$in_navgroupsort = "NULL";}
        
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "mask";
	$SqlArray["into"]   = "      id,           app_id,       css_template_app_id,     css_template_id,           name,           link,      menu_app_id         ,                 menu,          description,         sort,         level,         navgroup,        navgroupsort";
	$SqlArray["values"] = $nextID.", '".$in_app_id."', '".$in_template_app_id."', ".$in_template_id.", '".$in_name."', '".$in_link."', '".$in_parent_mask_app."', ".$in_parent_mask.", '".$in_description."', ".$in_sort.", ".$in_level.", ".$in_navgroup.", ".$in_navgroupsort;
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return $nextID;}
    }
    
    
    
    
    /** Legt einen neuen Datensatz in der Tabelle html_tag (Maskenelement) an.
     * 
     * @param   object  $in_pagedata        Referenz zum pagedata-object
     * @param   string  $in_app_id          APP-ID des Maskenelements
     * @param   string  $in_form_app_id     APP-ID des einzubettenden Formulars; Angabe optional (Leerstring)
     * @param   int     $in_form_id         ID des einzubettenden Formulars; Angabe optional (Leerstring)
     * @param   string  $in_htmlname        Tag-Name des Maskenelements. Dieser muss ein gültiger html-Wert sein, bspw. "div", "span", "article" usw.
     * @param   string  $in_parent_dom_node ID des übergeordneten Maskenelements; Angabe optional (Leerstring); ACHTUNG: wenn Leerstring, dann wird das Maskenelement auf oberster Ebene im DOM eingehangen Das kann theoretisch nur beim html-Wurzel-tag selbst der Fall sein.
     * @param   int     $in_level           Level (Ebene) des Maskenelements. Angabe optional (Leerstring); Wenn parent_tag angegeben wurde, wird Level von diesem abgeleitet.
     * @param   string  $in_description     Beschreibung des Maskenelements
     * @param   string  $in_has_mask_menu   ID des Navigationsmenüs, falls eines integriert werden soll; Angabe optional (Leerstring)
     * @param   string  $in_specialtype     Kennzeichen für Spezialelemente, die integriert werden sollen [infobox|hiddenbox]
     * @return  mixed                       ID des angelegten htmltags oder false im Fehlerfall
     */
    function setNewHtmltag(&$in_pagedata, $in_app_id, $in_form_app_id, $in_form_id, $in_htmlname, $in_parent_dom_node, $in_level, $in_description, $in_has_mask_menu, $in_specialtype) {
        
        $app_id_kernel = global_variables::getAppIdFromSYS01();
        
        $nextID = getMaxValue($app_id_kernel, global_variables::getNameOfDbSchemaSYS01(), "html_tag", "id");
        $nextID = $nextID + rand(1,10);
        $description = substr($in_description, 0, 45);
        
        
        
        //Feldwerte umwandeln (Plausibilisieren)
        if($in_form_app_id == "" OR $in_form_id == "") {
            $in_form_app_id = "'".$app_id_kernel."'";
            $in_form_id = 100;
        } else {
            $in_form_app_id = "'".$in_form_app_id."'";
        }
        if($in_parent_dom_node == "") {$in_parent_dom_node = "NULL";} 
        if($in_parent_dom_node <> NULL) {
            //Level = parenttag.level +1 
            $level = getDataFromTableByID($app_id_kernel, global_variables::getNameOfDbSchemaSYS01(), "html_tag", "level", "id = ".$in_parent_dom_node);
            if($level == "" OR $level === false) {$level = "NULL";}  else {$level = $level + 1;}
        } elseif ($in_level == "") {
            $level = "NULL";
        } else {
            $level = $in_level;
        }
        if($in_has_mask_menu == "") {$in_has_mask_menu = "NULL";} 
        if($in_specialtype == "") {$in_specialtype = "NULL";} else {$in_specialtype = "'".$in_specialtype."'";}
        
        
        
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "html_tag";
	$SqlArray["into"]   = " id, app_id, form_app_id, form_id, 
                                name, parent_tag, level,  
                                description, has_mask_menu, specialtype";
	$SqlArray["values"] =   $nextID.", '".$in_app_id."', ".$in_form_app_id.", ".$in_form_id.
                                ", '".$in_htmlname."', ".$in_parent_dom_node.", ".$level.
                                ", '".$description."', ".$in_has_mask_menu.", ".$in_specialtype;           
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return $nextID;}
    }
    
    
    
    /** Legt einen neuen Datensatz in der Tabelle form an.
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     * 
     * @param   object  $in_pagedata                Referenz zum pagedata-object
     * @param   string  $in_app_id                  APP-ID des Formulars
     * @param   string  $in_name                    Name des Formulars
     * @param   integer $in_show_headline           Gibt an, ob Überschriften angedruckt werden sollen [1|0] -> Wenn leer, dann wird 0 (false) angenommen.
     * @param   string  $in_constructor             Constructor zum rendern des Formulars (Mögliche Werte siehe Tabelle konstanten; konstantentyp_id = 18)
     * @param   string  $in_description             Beschreibung eines Formulars. Bei WYSIYG-Formularen der Inhalt. Es kann auch ein Leerstring übergeben werden.
     * @param   string  $in_db_schema               DB-Schema, in dem die Daten des Formulars abgelegt werden. Leerstring ist möglich.
     * @param   string  $in_db_table                DB-Tabelle, in dem die Daten des Formulars abgelegt werden. Leerstring ist möglich.
     * @param   string  $in_query_app_id            APP-ID einer Query, welche die Daten des Formulars liefert. (Nur relevant für den Constructor "getFormTableForQuery", ansonsten Leerstring angeben)
     * @param   integer $in_query                   ID einer Query, welche die Daten des Formulars liefert. (Nur relevant für den Constructor "getFormTableForQuery", ansonsten Leerstring angeben)
     * @param   string  $in_order_by                Sortiermerkmal der Daten innerhalb des Formulars. Sortierung wird in SQL-Syntax angegeben (Bsp.: "app_id, id"). Angabe ist nur relevant, wenn auch db_schema und db_table angegeben wird. Ansonsten Leerstring übergeben.
     * @param   string  $in_condition               Bedingung zur Auswahl der Daten aus der Datenbank. Condition wird in SQL-Syntax angegeben (Bsp.: "app_id = 'SYS01'"). Angabe ist nur relevant, wenn auch db_schema und db_table angegeben wird. Ansonsten Leerstring übergeben.
     * @param   integer $in_historydata             Gibt an, ob es sich historisierbare Datenspeicherung handelt. Mögliche Werte [0|1]. Angabe ist nur relevant, wenn auch db_schema und db_table angegeben wird. Ansonsten 0 übergeben.
     * @param   string  $in_history_from_col        Column, welche bei historischen Daten das Gültig-von-Datum enthält. Angabe ist nur relevant, wenn $in_historydata = 1. Ansonsten Leerstring  übergeben.
     * @param   string  $in_history_to_col          Column, welche bei historischen Daten das Gültig-bis-Datum enthält. Angabe ist nur relevant, wenn $in_historydata = 1. Ansonsten Leerstring  übergeben.
     * @param   integer $in_activate_prot           Gibt an, ob die automatische Protokollierung der Datenänderung aktiviert werden soll. [0|1]
     * @param   string  $in_prot_col                Spalte, welche die ID zur Zuordnung von Protokolldaten zu Inhaltsdaten enthält. Angabe ist nur relevant, wenn $in_activate_prot = 1. Ansonsten Leerstring übergeben.
     * @param   integer $in_default_mode            Modus, in dem das Formular per default geöffnet wird. Mögliche Werte siehe DB-Tabelle form_mode.
     * @param   integer $in_limit                   Anzahl der Zeilen, die im Formular amximal angezeigt werden sollen. Wenn keine Angabe, dann greift zentraler Konfigurationsparameter. Angabe kann Leerstring sien.
     * @param   string  $in_behave_after_insert     Verhalten nach insert und update. Möglicher Werte siehe Tabelle Konstanten (konstantentyp_id = 148).
     * @param   integer $in_width                   Breite des Formuars in %. Wenn Leerstring, dann grefit allgemein Angabe aus dem CSS_Template.
     * @param   string  $in_filename                Name der Datei. Diese kann je nach App, verschiedene Funktionen haben.
     * @param   string  $in_image                   Pfad zu einer Bilddatei.
     * @param   intger  $in_show_markfield          Angabe, ob Markierungsfeld gezeigt werden soll. (0 = neun, 1 = ja)
     * @param   integer $in_timeToDelete            Zeit in Sekunden, nach denen Daten, welche über dieses Formular erfasst werden, wieder gelöscht werden. (Funktion muss separat angestoßen werden)
     * @param   integer $in_save_optlist            Gibt an, ob Option-Listen von Referenzfeldern in der Session (forms_backup) gespeichert werden sollen. Dies ermöglicht anschließend die Klartexte in Mails oder Druckaufbereitungen zu verwenden. Es kostst jedoch u.U. erheblich mehr Speicherbedarf. Werte: [0|1]
     * @return  mixed                               ID des erstellten Formulars oder false.
     */
    function setNewForm(&$in_pagedata, $in_app_id, $in_name, $in_show_headline, $in_constructor, $in_description, $in_db_schema, $in_db_table, $in_query_app_id, $in_query, $in_order_by, $in_condition, $in_historydata, $in_history_from_col, $in_history_to_col, $in_activate_prot, $in_prot_col, $in_default_mode, $in_limit, $in_behave_after_insert, $in_width, $in_filename, $in_image, $in_show_markfield, $in_timeToDelete, $in_save_optlist) {
        
        $nextID = getMaxValue(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "form", "id");
        $nextID = $nextID + rand(1,10);
        
        if($in_query_app_id == "") {$in_query_app_id = "NULL";} else {$in_query_app_id = "'".$in_query_app_id."'";}
        if($in_query == "") {$in_query = "NULL";} else {$in_query = "'".$in_query."'";}
        if($in_description == "") {$in_description = "NULL";} else {$in_description = "'".$in_description."'";}
        if($in_show_headline == "") {$in_show_headline = 0;}
        if($in_historydata == "") {$in_historydata = 0;}
        if($in_activate_prot == "") {$in_activate_prot = 0;}
        if($in_limit == "") {$in_limit = "NULL";} else {$in_limit = "'".$in_limit."'";}
        if($in_width == "") {$in_width = "NULL";} else {$in_width = "'".$in_width."'";}
        if($in_order_by == "") {$in_order_by = "NULL";} else {$in_order_by = "'".$in_order_by."'";}
        if($in_condition == "") {$in_condition = "NULL";} else {$in_condition = "'".str_replace("'", "''", $in_condition)."'";}
        if($in_history_from_col == "") {$in_history_from_col = "NULL";} else {$in_history_from_col = "'".$in_history_from_col."'";}
        if($in_history_to_col == "") {$in_history_to_col = "NULL";} else {$in_history_to_col = "'".$in_history_to_col."'";}
        if($in_prot_col == "") {$in_prot_col = "NULL";} else {$in_prot_col = "'".$in_prot_col."'";}
        if($in_db_schema == "") {$in_db_schema = "NULL";} else {$in_db_schema = "'".$in_db_schema."'";}
        if($in_db_table == "") {$in_db_table = "NULL";} else {$in_db_table = "'".$in_db_table."'";}
        if($in_filename == "") {$in_filename = "NULL";} else {$in_filename = "'".$in_filename."'";}
        if($in_image == "") {$in_image = "NULL";} else {$in_image = "'".$in_image."'";}
        if($in_timeToDelete == "") {$in_timeToDelete = "NULL";} else {$in_timeToDelete = "'".$in_timeToDelete."'";}
        
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "form";
	$SqlArray["into"]   = " id, app_id, query_id, 
                                query_app_id, name, constructor, 
                                description, db_schema, db_table, 
                                order_by, default_condition, history_flag, 
                                history_col_validfrom, history_col_validto, logging, 
                                log_id_spalte, default_form_mode, default_limit, 
                                headline_activate, behavior_after_insert, width,
                                filename, image, show_markfield, time_to_delete, 
                                save_optionlist_tmp";
	$SqlArray["values"] =   $nextID.", '".$in_app_id."', ".$in_query.
                                ", ".$in_query_app_id.", '".$in_name."', '".$in_constructor."'".
                                ", ".$in_description.", ".$in_db_schema.", ".$in_db_table.
                                ", ".$in_order_by.", ".$in_condition.", ".$in_historydata.
                                ", ".$in_history_from_col.", ".$in_history_to_col.", ".$in_activate_prot.
                                ", ".$in_prot_col.", ".$in_default_mode.", ".$in_limit.
                                ", ".$in_show_headline.", '".$in_behave_after_insert."', ".$in_width.
                                ", ".$in_filename.", ".$in_image.", ".$in_show_markfield.", ".$in_timeToDelete.
                                ", ".$in_save_optlist;
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return $nextID;}
    }
    
    
    
    /** Legt ein neues Feld in der Tabelle feld an. und gibt die vergebene ID zurück.
     * 
     * @param   object  $in_pagedata                    Referenz zum pagedata-object
     * @param   string  $in_app_id                      APP-ID des Feldes
     * @param   string  $in_feldart_app_id              APP-ID der Feldart (siehe konstante.konstantentyp_id)
     * @param   string  $in_feldart_id                  ID der Feldart, entspricht der Spalte konstante.wert
     * @param   date    $in_feldart_gueltig_ab          Ab-Datum des Datensatzes der Tabelle konstante, wenn Angabe fehlt (Leerstring), wird aktueller Datensatz der Tabelle konstante ermittelt (empfohlen).
     * @param   string  $in_form_app_id                 APP-ID des einzufügenden Formulars; Angabe optional (Leerstring)
     * @param   integer $in_form_id                     ID des einzufügenden Formulars; Angabe optional (Leerstring); Angabe wird ignoriert, wenn $in_form_app_id = Leerstring            
     * @param   string  $in_query_app_id                APP-ID der Query, falls Feldart = "Referenz zu einer Query" ist; Angabe optional (Leerstring)
     * @param   integer $in_query_id                    ID der Query, falls Feldart = "Referenz zu einer Query" ist; Angabe optional (Leerstring)
     * @param   string  $in_query_ref_field_connection_id       APP-ID (connection-id, falls Query mit einer speziellen Connection ausgeführt werden soll. Angabe optional (Leerstring)
     * @param   string  $in_button_action_function_app_id       APP-ID, für Felder der Art "Button", welche eine Funktion aufrufen. Angabe optional (Leerstring)
     * @param   integer $in_button_action_function_id   ID, für Felder der Art "Button", welche eine Funktion aufrufen. Angabe optional (Leerstring)
     * @param   string  $in_form_mode_app_id            APP-ID des Default-Formularmodus; Wenn Angabe fehlt wird Kernel-APP angenommen
     * @param   string  $in_name                        Name des Feldes
     * @param   integer $in_sort                        Reihenfolge in der das Feld im Formular angeordnet werden soll
     * @param   string  $in_laenge                      Breite des Feldes. Abhängig von der Feldart. siehe Hilfe in der Oberfläche im Formular "Felder"
     * @param   string  $in_laenge_label                Breite der Bezeichnung des Feldes. Abhängig von der Feldart. siehe Hilfe in der Oberfläche im Formular "Felder"
     * @param   integer $in_zeilen                      Anzahl Zeilen des Feldes
     * @param   string  $in_spalte                      Name der DB-Spalte, Angabe sollte bei constructor SingleData und Tabledata einer DB-column entsprechen. Ansonsten beachte Hilfe zum Feld in der Oberfläche.
     * @param   string  $in_ldap_attribut               Derzeit ohne Funktion -> Leerstring
     * @param   integer $in_pos_header                  Anordnung der Feldbezeichnung [0 = links|1 = oben| 2 = ohne]
     * @param   integer $in_inline                      Gibt an, ob nach dem Feld ein Zeilenumbruch eingefügt wird. [0 = Zeilenumbruch|1 = inline]
     * @param   string  $in_javascript_onclick          Javascript, welches bei Klick ausgeführt wird. Hilfe siehe Oberfläche. Angabe optional (Leerstring)
     * @param   string  $in_javascript_onchange         Javascript, welches bei Feldwertänderung ausgeführt wird. Hilfe siehe Oberfläche. Angabe optional (Leerstring)
     * @param   integer $in_max_zeichen                 Anzahl zulässiger Zeichen
     * @param   integer $in_numeric_min                 Minimum-Wert bei Feldart numeric; Angabe optional (Leerstring)
     * @param   integer $in_numeric_max                 Maximum-Wert bei Feldart numeric; Angabe optional (Leerstring)
     * @param   integer $in_required                    Pflichtfeld [0 = nein|1 = ja]
     * @param   string  $in_ref_schema                  Name des Schema bei Feldart "Referenz zu einer Tabelle"; Angabe optional (Leerstring)
     * @param   string  $in_ref_table                   Name der Tabelle bei Feldart "Referenz zu einer Tabelle"; Angabe optional (Leerstring)
     * @param   string  $in_ref_id_field                Name der ID-Column bei Feldart "Referenz zu einer Tabelle"; Angabe optional (Leerstring)
     * @param   string  $in_ref_show_field              Name der Anzeige-Column bei Feldart "Referenz zu einer Tabelle"; Angabe optional (Leerstring)
     * @param   string  $in_ref_order_by_field          SQL-Order-By-Angabe bei Feldart "Referenz zu einer Tabelle". Bsp.: "app_id, id"; Angabe optional (Leerstring)
     * @param   string  $in_ref_condition               SQL-Where-Condition bei Feldart "Referenz zu einer Tabelle". Bsp.: "app_id = 'SYS01'"; Angabe optional (Leerstring)
     * @param   integer $in_readonly                    Gibt an, ob ein Feld schreibgeschützt ist [1 = readonly|0 = open]
     * @param   String  $in_vorgabewert                 Vorgabewert bei Neuanlage eines Datensatzes. Mögliche Werte werden im Hilfetext der Oberfläche erläutert. Angabe optional (Leerstring)
     * @param   integer $in_ausblenden_bei_modi         Gibt an, ob ein Feld bei bestimmten Modi ausgeblendet werden soll. Es gibt 7 Modi (siehe Tabelle form_mode). Die Modi können in einem String übergeben werden. Bsp.: "123" blendet das Feld in den Modi 1,2 und 3 aus.
     * @param   integer $in_button_target               Zielformular für eine Buttonfunktion; siehe konstantentyp_id = 17; [1 = form_self|2 = post_array| 3 = nothimg|4 = form_other]; Angabe optional (Leerstring)
     * @param   integer $in_button_target_mask          Zielmaske, welche nach einem Button-Klick aufgerufen werden soll; Angabe optional (Leerstring)
     * @param   integer $in_form_mode_id                ID des Modus, in dem das Formular nach einem Buttonclick aufgerufen werden soll. Mögliche Werte siehe DB-Tabelle form_mode im Kernelschema; Angabe optional (Leerstring)
     * @param   string  $in_helptext                    Hilfetext des Feldes; Angabe optional
     * @return  mixed                                   Field_ID des angelegten Feldes oder false
     */
    function setNewField(   &$in_pagedata, $in_app_id, $in_feldart_app_id, $in_feldart_id,
                            $in_feldart_gueltig_ab, $in_form_app_id, $in_form_id, $in_query_app_id,
                            $in_query_id, $in_query_ref_field_connection_id, $in_button_action_function_app_id, $in_button_action_function_id,
                            $in_form_mode_app_id, $in_name, $in_sort, $in_laenge, $in_laenge_label, $in_zeilen,
                            $in_spalte, $in_ldap_attribut, $in_pos_header, $in_inline,
                            $in_javascript_onclick, $in_javascript_onchange, $in_max_zeichen, $in_numeric_min,
                            $in_numeric_max, $in_required, $in_ref_schema, $in_ref_table,
                            $in_ref_id_field, $in_ref_show_field, $in_ref_order_by_field, $in_ref_condition,
                            $in_readonly, $in_vorgabewert, $in_ausblenden_bei_modi, $in_button_target,
                            $in_button_target_mask, $in_form_mode_id, $in_helptext) {
        $nextID = getMaxValue(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "feld", "id");
        $nextID = $nextID + rand(1,10);             
        
        
        //Feldwerte umwandeln (Plausibilisieren)
        $app_id_kernel = global_variables::getAppIdFromSYS01();
        if($in_feldart_gueltig_ab == "") {
            //Gültig-Ab-Datum wird aus dem aktuellen Datensatz ermittelt
            $const_condition = "app_id = '".$in_feldart_app_id."' AND konstantentyp_app_id = '".$app_id_kernel."' AND konstantentyp_id = 2 AND wert = '".$in_feldart_id."' AND gueltig_ab <= current_date AND gueltig_bis >= current_date";
            $in_feldart_gueltig_ab = "'".getDataFromTableByID($app_id_kernel, global_variables::getNameOfDbSchemaSYS01(), "konstante", "gueltig_ab", $const_condition)."'";
        }
        
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , "form_app_id: ".$in_form_app_id." - form_id: ".$in_form_id);	
	
        if($in_form_app_id == "" OR $in_form_id == "") {
            $in_form_app_id = "'".$app_id_kernel."'";
            $in_form_id = 100;
        } else {
            $in_form_app_id = "'".$in_form_app_id."'";
        }
        if($in_query_app_id == "") {$in_query_app_id = "NULL";} else {$in_query_app_id = "'".$in_query_app_id."'";}
        if($in_query_id == "") {$in_query_id = "NULL";} 
        if($in_query_ref_field_connection_id == "") {$in_query_ref_field_connection_id = "NULL";} else {$in_query_ref_field_connection_id = "'".$in_query_ref_field_connection_id."'";}
        if($in_button_action_function_app_id == "") {$in_button_action_function_app_id = "NULL";} else {$in_button_action_function_app_id = "'".$in_button_action_function_app_id."'";}
        if($in_button_action_function_id == "") {$in_button_action_function_id = "NULL";} 
        if($in_form_mode_app_id == "") {$in_form_mode_app_id = "'".$app_id_kernel."'";} else {$in_form_mode_app_id = "'".$in_form_mode_app_id."'";}
        if($in_spalte == "") {$in_spalte = "NULL";} else {$in_spalte = "'".$in_spalte."'";}
        if($in_ldap_attribut == "") {$in_ldap_attribut = "NULL";} else {$in_ldap_attribut = "'".$in_ldap_attribut."'";}
        if($in_javascript_onclick == "") {$in_javascript_onclick = "NULL";} else {$in_javascript_onclick = "'".$in_javascript_onclick."'";}
        if($in_javascript_onchange == "") {$in_javascript_onchange = "NULL";} else {$in_javascript_onchange = "'".$in_javascript_onchange."'";}
        if($in_numeric_min == "") {$in_numeric_min = "NULL";} 
        if($in_numeric_max == "") {$in_numeric_max = "NULL";} 
        if($in_ref_schema == "") {$in_ref_schema = "NULL";} else {$in_ref_schema = "'".$in_ref_schema."'";}
        if($in_ref_table == "") {$in_ref_table = "NULL";} else {$in_ref_table = "'".$in_ref_table."'";}
        if($in_ref_id_field == "") {$in_ref_id_field = "NULL";} else {$in_ref_id_field = "'".$in_ref_id_field."'";}
        if($in_ref_show_field == "") {$in_ref_show_field = "NULL";} else {$in_ref_show_field = "'".$in_ref_show_field."'";}
        if($in_ref_order_by_field == "") {$in_ref_order_by_field = "NULL";} else {$in_ref_order_by_field = "'".$in_ref_order_by_field."'";}
        if($in_ref_condition == "") {$in_ref_condition = "NULL";} else {$in_ref_condition = "'".$in_ref_condition."'";}
        if($in_vorgabewert == "") {$in_vorgabewert = "NULL";} else {$in_vorgabewert = "'".$in_vorgabewert."'";}
        if($in_button_target == "") {$in_button_target = "NULL";} 
        if($in_button_target_mask == "") {$in_button_target_mask = "NULL";} 
        if($in_form_mode_id == "") {$in_form_mode_id = "NULL";} 
        if($in_helptext == "") {$in_helptext = "NULL";} else {$in_helptext = "'".$in_helptext."'";}
        
        
                
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "feld";
	$SqlArray["into"]   = " id, app_id, konstante_app_id, konstante_gueltig_ab, 
                                konstante_id, form_app_id, form_id, query_app_id, 
                                query_id, query_ref_field_connection_id, button_action_function_app_id, button_action_function_id, 
                                form_mode_app_id, name, sort, laenge, laenge_label, zeilen, 
                                spalte, ldap_attribut, pos_header, inline, 
                                javascript_onclick, javascript_onchange, max_zeichen, numeric_min, 
                                numeric_max, required, ref_schema, ref_table, 
                                ref_id_field, ref_show_field, ref_order_by_field, ref_condition, 
                                readonly, vorgabewert, ausblenden_bei_insert, button_target, 
                                button_target_mask, form_mode_id, helptext";
	$SqlArray["values"] =   $nextID.", '".$in_app_id."', '".$in_feldart_app_id."', ".$in_feldart_gueltig_ab.
                                ", ".$in_feldart_id.", ".$in_form_app_id.", ".$in_form_id.", ".$in_query_app_id.
                                ", ".$in_query_id.", ".$in_query_ref_field_connection_id.", ".$in_button_action_function_app_id.", ".$in_button_action_function_id.
                                ", ".$in_form_mode_app_id.", '".$in_name."', ".$in_sort.", '".$in_laenge."', '".$in_laenge_label."', ".$in_zeilen.
                                ", ".$in_spalte.", ".$in_ldap_attribut.", ".$in_pos_header.", ".$in_inline.
                                ", ".$in_javascript_onclick.", ".$in_javascript_onchange.", ".$in_max_zeichen.", ".$in_numeric_min.
                                ", ".$in_numeric_max.", ".$in_required.", ".$in_ref_schema.", ".$in_ref_table.
                                ", ".$in_ref_id_field.", ".$in_ref_show_field.", ".$in_ref_order_by_field.", ".$in_ref_condition.
                                ", ".$in_readonly.", ".$in_vorgabewert.", ".$in_ausblenden_bei_modi.", ".$in_button_target.
                                ", ".$in_button_target_mask.", ".$in_form_mode_id.", ".$in_helptext;
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return $nextID;}
    }
    
    
    /** Legt einen neuen Datensatz in der tabelle role_has_mask an.
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     * 
     * @param   object  $in_pagedata        Referenz auf das pagedata-object
     * @param   string  $in_role_app_id     APP-ID der Rolle
     * @param   integer $in_role_id         ID der Rolle
     * @param   string  $in_mask_app_id     APP-ID der Maske
     * @param   integer $in_mask_id         ID der Maske
     * @param   boolean $in_access_select   Lesender Zugriff ist für die Rolle erlaubt (wenn true)
     * @param   boolean $in_access_insert   Insert ist für die Rolle erlaubt (wenn true)
     * @param   boolean $in_access_update   Update ist für die Rolle erlaubt (wenn true)
     * @param   boolean $in_access_delete   Löschen ist für die Rolle erlaubt (wenn true)
     * @return  boolean                     true bei Erfolg
     */
    function setRoleAccessToMask(&$in_pagedata, $in_role_app_id, $in_role_id, $in_mask_app_id, $in_mask_id, $in_access_select, $in_access_insert, $in_access_update, $in_access_delete) {
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "role_has_mask";
	$SqlArray["into"]   = "role_app_id          , role_id        , mask_app_id          , mask_id        , access_select        , access_insert        , access_update        , access_delete";
	$SqlArray["values"] = "'".$in_role_app_id."', ".$in_role_id.", '".$in_mask_app_id."', ".$in_mask_id.", ".$in_access_select.", ".$in_access_insert.", ".$in_access_update.", ".$in_access_delete;
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return true;}
    }
    
    
    
    
    /** Legt einen neuen Datensatz in der Tabelle htmltaggroup an und gibt die vergebene ID zurück.
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     * 
     * @param   object  $in_pagedata            Referenz zum pagedata-object
     * @param   string  $in_app_id              APP-ID
     * @param   string  $in_name                Name, der verwendet werden soll
     * @param   integer $in_is_symbolgroup      [0|1] -> gibt an, ob die htmltaggroup eine Symbolleiste ist.
     * @return  mixed                           ID der angelegten htmltaggroup oder false im Fehlerfall.
     */
    function setNewHtmlTagGroup(&$in_pagedata, $in_app_id, $in_name, $in_is_symbolgroup) {
        
        $nextID = getMaxValue(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "htmltaggroup", "id");
        $nextID = $nextID + rand(1,10);
        
        $in_name = preg_replace ( '/[^a-zA-Z0-9äÄöÖüÜß_ -]/i', '', $in_name);
        $name = substr($in_name,0, 44);     //das DB-Feld ist nur 45 Zeichen lang
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "htmltaggroup";
	$SqlArray["into"]   = "id      , app_id          , name          , is_symbolgroup";
	$SqlArray["values"] = $nextID.", '".$in_app_id."', '".$name."', '".$in_is_symbolgroup."'";
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return $nextID;}
    }
    
    
    
    
    /** Legt einen neuen Datensatz in der Tabelle account_has_role an.
     * 
     * @param   object  $in_pagedata            Referenz zum pagedata-object
     * @param   string  $in_account_app_id
     * @param   string  $in_account_id
     * @param   string  $in_role_app_id
     * @param   string  $in_role_id
     * @return  integer                         Rückmelde-ID's entsprechend der Konstantentyp_id 35 [2|-2|-21] 
     */
    function setNewAcoountHasRole(&$in_pagedata, $in_account_app_id, $in_account_id, $in_role_app_id, $in_role_id) {
        

        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "account_has_role";
	$SqlArray["into"]   = "role_id, role_app_id, account_id, account_app_id";
	$SqlArray["values"] = $in_role_id.", '".$in_role_app_id."', '".$in_account_id."', '".$in_account_app_id."'";
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        return $result;
    }
    
    
    
    
    /** Legt einen neuen Datensatz in der Tabelle app.
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     * 
     * @param   object  $in_pagedata            Referenz zum pagedata-object
     * @param   string  $in_app_id              APP-ID
     * @param   string  $in_name                Name, der verwendet werden soll
     * @param   string  $in_description         Beschreibung der APP
     * @param   string  $in_logo                Name einer Bilddatei, die im Verzeichnis img liegen muss.
     * @return  bool                            
     */
    function setNewApp(&$in_pagedata, $in_app_id, $in_name, $in_description, $in_logo) {
        
        
        $name = substr($in_name,0, 255);     //das DB-Feld ist nur 255 Zeichen lang
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "app";
	$SqlArray["into"]   = "id, name, description, logo, sys";
	$SqlArray["values"] = "'".$in_app_id."', '".$in_name."', '".$in_description."', '".$in_logo."', 1";
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result < 0) {return false;} else {return true;}
    }
    
    
    
    
    
    
    
    
    
    /** Legt einen neuen Datensatz in der Tabelle app_schema.
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     * 
     * @param   object  $in_pagedata                Referenz zum pagedata-object
     * @param   string  $in_app_id                  APP-ID
     * @param   string  $in_schema_name             Name, der verwendet werden soll
     * @param   integer $in_extern_administrated    Kennzeichen, ob Schema extern administriert wird
     * @return  bool                            
     */
    function setNewAppschema(&$in_pagedata, $in_app_id, $in_schema_name, $in_extern_administrated) {
        
        
        $name = substr($in_schema_name,0, 45);     //das DB-Feld ist nur 45 Zeichen lang
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "app_schema";
	$SqlArray["into"]   = "app_id, db_schema, external_administrated, sys";
	$SqlArray["values"] = "'".$in_app_id."', '".$in_schema_name."', '".$in_extern_administrated."', 1";
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result < 0) {return false;} else {return true;}
    }
    
    
    
    
    /** Legt einen neuen Datensatz in der Tabelle workflow_instance an. 
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     * 
     * @param   object  $in_pagedata                Referenz zum pagedata-object
     * @param   string  $in_app_id                  APP-ID
     * @param   integer $in_workflow_id             ID des Workflows
     * @param   integer $in_version                 Versionsnummer des Workflows
     * @param   integer $in_instance_id             ID der Instanz; da DB-Spalte autoincrement ist, muss dieser Wert korrekt hochgezählt werden.
     * @param   string  $in_instance_name           Name der Instanzranz; max. 255 Zeichen.
     * @param   integer $in_finished                Gibt an, ob die Instanz/der Vorgang des Workflows abgeschlossen ist.
     * @return  bool                            
     */
    function setNewWorkflowInstance(&$in_pagedata, $in_app_id, $in_workflow_id, $in_version, $in_instance_id, $in_instance_name, $in_finished) {
        
        
        $name = substr($in_instance_name,0, 255);     //das DB-Feld ist nur 255 Zeichen lang
        if($in_finished == 0) {$timestamp = "NULL";} else {$timestamp="current_timestamp";}
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "workflow_instance";
	$SqlArray["into"]   = "app_id, workflow_id, version, instance_id, instance_name, finished, finished_timestamp";
	$SqlArray["values"] = "'".$in_app_id."', ".$in_workflow_id.", '".$in_version."', ".$in_instance_id.", '".$in_instance_name."', ".$in_finished.", ".$timestamp;
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result < 0) {return false;} else {return true;}
    }
    
    
    
    
    
    /** Legt einen neuen Datensatz in der Tabelle workflow_status an.
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     
     * 
     * @param   object  $in_pagedata                Referenz zum pagedata-object
     * @param   string  $in_app_id                  APP-ID
     * @param   integer $in_workflow_id             ID des Workflows
     * @param   integer $in_version                 Versionsnummer des Workflows
     * @param   integer $in_step                    Workflow_step
     * @param   integer $in_instance_id             ID der Instanz; da DB-Spalte autoincrement ist, muss dieser Wert korrekt hochgezählt werden.
     * @param   string  $in_editor                  angemeldeter account
     * @param   string  $in_url_id                  id, welcher als Referenz zum Status-Datensatz dienen soll; Muss im Ascii-Format vorliegen, damit sie in der URL verwendet werden kann.
     * @param   string  $in_con1                    Condition1; Wert des ersten PK
     * @param   string  $in_con2                    Condition2; Wert des zweiten PK
     * @param   string  $in_con3                    Condition3; Wert des dritten PK
     * @param   string  $in_email_to                
     * @param   string  $in_email_cc
     * @param   string  $in_email_from
     * @param   string  $in_comment
     * @param   integer $in_finished                1 = Step ist abgeschlossen; 0 = Step ist noch zu erledigen
     * @param   integer $in_back_to_step            Wenn der Status wieder auf einen vorherigen Step gesetzt werden soll, dann ist dieser hier zu benennen. (Default = "NULL")
     * @param   integer $in_repeat_step_count       Anzahl der Wiederholungen des aktuellen Steps. Wenn ein Step abgelehnt wird, dann wird der in workflow_step.back_to_step definierte Step wiederholt. (Default = 0)
     * @return  boolean
     */
    function setNewWorkflowStatus(&$in_pagedata, $in_app_id, $in_workflow_id, $in_version, $in_step, $in_instance_id, $in_editor, $in_url_id, $in_con1, $in_con2, $in_con3, $in_email_to, $in_email_cc, $in_email_from, $in_comment, $in_finished, $in_back_to_step = "NULL", $in_repeat_step_count = 0) {
        
        if($in_finished == 0) {$timestamp = "NULL";} else {$timestamp="current_timestamp";}
        if($in_back_to_step != "NULL" AND $in_back_to_step > 0) {$step = $in_back_to_step;} else {$step = $in_step;}
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "workflow_status";
	$SqlArray["into"]   = "app_id          , workflow_id        , version        , step     , instance_id        , timestamp_edit, editor          , url_id          , con1          , con2          , con3          , email_to          , email_cc          , email_from          , wkfl_comment     , finished        , repeat_step_count";
	$SqlArray["values"] = "'".$in_app_id."', ".$in_workflow_id.", ".$in_version.", ".$step.", ".$in_instance_id.", $timestamp    , '".$in_editor."', '".$in_url_id."', '".$in_con1."', '".$in_con2."', '".$in_con3."', '".$in_email_to."', '".$in_email_cc."', '".$in_email_from."', '".$in_comment."', ".$in_finished.", ".$in_repeat_step_count;
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result < 0) {return false;} else {return true;}
    }
    
    
    
    
    
    /** Legt den Status eines noch nicht abgeschlossenen Datensatzes (finished = 0) in workflow_status neu fest.
     * 
     * @param   object  $in_pagedata                Referenz zum pagedata-object
     * @param   string  $in_app_id                  APP-ID
     * @param   integer $in_workflow_id             ID des Workflows
     * @param   integer $in_version                 Versionsnummer des Workflows
     * @param   integer $in_step                    Workflow_step
     * @param   integer $in_instance_id             ID der Instanz; da DB-Spalte autoincrement ist, muss dieser Wert korrekt hochgezählt werden.
     * @param   string  $in_editor                  angemeldeter account
     * @param   string  $in_email_to                
     * @param   string  $in_email_cc
     * @param   string  $in_email_from
     * @param   string  $in_comment
     * @param   integer $in_finished                1 = Step ist abgeschlossen; 0 = Step ist noch zu erledigen
     * @param   integer $in_back_to_step               Gibt den Step an, zu dem zurückgekehrt werden soll. Das ist nur dann notwendig, wenn dem aktuellen Step nicht zugestimmt wird. (Default = NULL)
     * @return  boolean
     */
    function setWorkflowStatus(&$in_pagedata, $in_app_id, $in_workflow_id, $in_version, $in_step, $in_instance_id, $in_editor, $in_email_to, $in_email_cc, $in_email_from, $in_comment, $in_finished, $in_back_to_step = "NULL") {
        
        if($in_finished == 0) {$timestamp = "timestamp_edit = NULL";} else {$timestamp="timestamp_edit = current_timestamp";}
        if($in_back_to_step == "NULL") {$back_to_step = "back_to_step = NULL";} else {$back_to_step="back_to_step = $in_back_to_step";}
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"]  = "workflow_status";
	$SqlArray["update"] = "finished = ".$in_finished.", editor = '".$in_editor."', email_to = '".$in_email_to."', email_cc = '".$in_email_cc."', email_from = '".$in_email_from."', wkfl_comment = '".$in_comment."', ".$timestamp.", ".$back_to_step;
        $SqlArray["where"]  = "app_id='".$in_app_id."' AND workflow_id=".$in_workflow_id." AND version=".$in_version." AND step=".$in_step." AND instance_id =".$in_instance_id." AND finished = 0";
	             
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();     
        
        $result = updateData($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return true;}
    }
    
    
    
    
    
    /** Legt den Status eines Datensatzes in workflow_instance neu fest.
     * 
     * @param   object  $in_pagedata                Referenz zum pagedata-object
     * @param   string  $in_app_id                  APP-ID
     * @param   integer $in_workflow_id             ID des Workflows
     * @param   integer $in_version                 Versionsnummer des Workflows
     * @param   integer $in_instance_id             ID der Instanz; da DB-Spalte autoincrement ist, muss dieser Wert korrekt hochgezählt werden.
     * @param   integer $in_finished                1 = Step ist abgeschlossen; 0 = Step ist noch zu erledigen
     * @return  boolean
     */
    function setWorkflowInstanceStatus(&$in_pagedata, $in_app_id, $in_workflow_id, $in_version, $in_instance_id, $in_finished) {
        
        if($in_finished == 0) {$timestamp = "finished_timestamp = NULL";} else {$timestamp="finished_timestamp = current_timestamp";}
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"]  = "workflow_instance";
	$SqlArray["update"] = "finished = ".$in_finished.", ".$timestamp;
        $SqlArray["where"]  = "app_id='".$in_app_id."' AND workflow_id=".$in_workflow_id." AND version=".$in_version." AND instance_id =".$in_instance_id;
	             
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();     
        
        $result = updateData($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return true;}
    }
    
    
    
    
    
    
    
    
    /**
    * Generate a random string.
    *
    * @param integer   $length     Length of the generated string.
    * @param string    $chars      The string containing all of the available characters.
    *
    * @return string 
    */
   function getRandomString($length = 24, $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') {
       $feedback = '';

       $size = strlen($chars);
       for ($i = 0; $i < $length; $i++) {
           $feedback = $feedback.$chars[mt_rand(0, $size - 1)];
       }

       return $feedback;
   }
    
    
    
    
    /** Setzt die Sortierreihenfolge für ein html_tag innerhalb einer htmltaggroup neu fest.
     * 
     * @param   object  $in_pagedata                Referenz zum pagedata-object
     * @param   string  $in_htmltaggroup_app_id     APP-ID der htmltaggroup
     * @param   int     $in_htmltaggroup_id         ID der htmltaggroup
     * @param   string  $in_htmltag_app_id          APP-ID des html_tag
     * @param   int     $in_htmltag_id              ID des html_tag
     * @param   int     $in_sort                    Sortier-ID des html_tag innerhalb der htmltaggroup
     * @return  boolean
     */
    function setSortInHtmlTagGroup(&$in_pagedata, $in_htmltaggroup_app_id, $in_htmltaggroup_id, $in_htmltag_app_id, $in_htmltag_id, $in_sort) {
        
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"]  = "htmltaggroup_has_html_tag";
	$SqlArray["update"] = "sort = ".$in_sort;
        $SqlArray["where"]  = "htmltaggroup_id=".$in_htmltaggroup_id." AND html_tag_id=".$in_htmltag_id." AND htmltaggroup_app_id='".$in_htmltaggroup_app_id."' AND html_tag_app_id='".$in_htmltag_app_id."' ";
	             
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();     
        
        $result = updateData($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return true;}
    }
    
    
    
    /** Legt die Position eines htmltags innerhalb einer htmltaggroup neu fest. 
     * Dabei werden alle htmltags der group mit neuen Sortierkennzahlen versehen.
     * 
     * @param   object  $in_pagedata                    Referenz auf das pagedata-object
     * @param   int     $in_resort_htmltag              ID des Artikels (html_tag), welcher verschoben werden soll
     * @param   int     $in_neightbor_htmltag           ID des Artikels, zu dem der $resort_article verschoben werden soll.
     * @param   string  $in_pos                         relative Position zum $in_neightbor_htmltag [before|after]
     * @param   int     $in_htmltaggroupForForms_id     ID der htmlataggroup, deren htmltags neu sortiert werden sollen.
     * @param   string  $in_htmltaggroupForForms_app_id APP-ID der htmlataggroup, deren htmltags neu sortiert werden sollen.
     * @return  boolean
     */
    function reSortInHtmlTagGroup(&$in_pagedata, $in_resort_htmltag, $in_neightbor_htmltag, $in_pos, $in_htmltaggroupForForms_id, $in_htmltaggroupForForms_app_id) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , "einzusortierender Artikel = ".$in_resort_htmltag.", Nachbarartikel = ".$in_neightbor_htmltag.", einfügen: ".$in_pos);
        $feedback = array();
        $temp_htmltag = array();
        $count = 0;
        
        //Ist-Zustand der Sortierung ermitteln
        $condition = "htmltaggroup_id = ".$in_htmltaggroupForForms_id." AND htmltaggroup_has_html_tag.htmltaggroup_app_id = '".$in_htmltaggroupForForms_app_id."'";
        $htmltag_list = getTableData(global_variables::getAppIdFromSYS01(), "htmltaggroup_has_html_tag", global_variables::getNameOfDbSchemaSYS01(), 1, "sort", $condition, __FUNCTION__);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> articlelist: ', $htmltag_list);
        
        
        // $in_resort_article in htmltags suchen
        foreach ($htmltag_list as $value) {
            if($value["htmltaggroup_has_html_tag.html_tag_id"] == $in_resort_htmltag) {
                $temp_htmltag = $value;
                break;
            }
        }
        
        
        //neu Sortieren
        foreach ($htmltag_list as $key => $current_htmltag) {
            $count = $count + 1;
            if($current_htmltag["htmltaggroup_has_html_tag.html_tag_id"] == $in_neightbor_htmltag) {
                //Wenn dar Nachbar-Artikel gefunden wurde
                if($in_pos == "before") {
                    //Wenn $in_resort_article vor dem Nachbarartikel eingefügt werden soll
                    $temp_htmltag["htmltaggroup_has_html_tag.sort"] = $count;
                    $feedback[$count] = $temp_htmltag;
                    $count = $count + 1;
                    $current_htmltag["htmltaggroup_has_html_tag.sort"] = $count;
                    $feedback[$count] = $current_htmltag;
                } else {
                    //Wenn $in_resort_article nach dem Nachbarartikel eingefügt werden soll
                    $current_htmltag["htmltaggroup_has_html_tag.sort"] = $count;
                    $feedback[$count] = $current_htmltag;
                    $count = $count + 1;
                    $temp_htmltag["htmltaggroup_has_html_tag.sort"] = $count;
                    $feedback[$count] = $temp_htmltag;
                }
            } elseif($current_htmltag["htmltaggroup_has_html_tag.html_tag_id"] == $in_resort_htmltag) {
                //Wenn der zu verschiebene Artikel gefunden wird
                // -> dann nichts tun, da dieser an dieser Stelle nicht übernommen werden soll. 
                // Er wird stattdessen in der vorherigen IF-Bedingung an der gewünschten Stelle eingefügt.
            } else {
                //unbeteiligter Artikel wird unverändert übernommen.
                $current_htmltag["htmltaggroup_has_html_tag.sort"] = $count;
                $feedback[$count] = $current_htmltag;
            }
        }
        
        //Update auf htmltaggroup_has_html_tag
        foreach ($feedback as $key => $current_htmltag) {
            setSortInHtmlTagGroup(  $in_pagedata, 
                                    $current_htmltag["htmltaggroup_has_html_tag.htmltaggroup_app_id"], 
                                    $current_htmltag["htmltaggroup_has_html_tag.htmltaggroup_id"],
                                    $current_htmltag["htmltaggroup_has_html_tag.html_tag_app_id"],
                                    $current_htmltag["htmltaggroup_has_html_tag.html_tag_id"],
                                    $current_htmltag["htmltaggroup_has_html_tag.sort"]);
        }
        
        
        return true;
    }
    
    
    /** Legt einen neuen Datensatz in der Tabelle htmltaggroup_has_html_tag an.
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     * 
     * @param   object  $in_pagedata            Referenz zum pagedate-object
     * @param   int     $in_htmltaggroup_id     ID der htmltaggroup (Gruppe von Maskenelementen)
     * @param   int     $in_html_tag_id         ID des hinzuzufügenden html_tag (Maskenelement)
     * @param   string  $in_htmltaggroup_app_id APP-ID der htmltaggroup
     * @param   string  $in_html_tag_app_id     APP-ID des html_tags
     * @param   int     $in_relationtyp         [1 = eigenständiges Formular|2 = eingebettetes Formular]
     * @param   int     $in_sort                Reihenfolge der Maskenelemente innerhalb einer Maskenelement-Gruppe.
     * @param   int     $in_active              [1 = aktiviert|0 = deaktiviert]
     * @return  boolean 
     */
    function setHtmlTagToHtmlTaggroup(  &$in_pagedata, $in_htmltaggroup_id, $in_html_tag_id, $in_htmltaggroup_app_id, $in_html_tag_app_id,
                                        $in_relationtyp, $in_sort, $in_active) {
        
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "htmltaggroup_has_html_tag";
	$SqlArray["into"]   = " htmltaggroup_id, html_tag_id, htmltaggroup_app_id, html_tag_app_id, 
                                relationtyp, sort, active";
	$SqlArray["values"] =   $in_htmltaggroup_id.", ".$in_html_tag_id.", '".$in_htmltaggroup_app_id."', '".$in_html_tag_app_id."'".
                                ", ".$in_relationtyp.", ".$in_sort.", ".$in_active;
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return true;}
    }
    
    
    
    
    
    /** Erzeugt einen neuen Datensatz in der Tabelle html_tag_has_style_element  (Style-Element für Maskenelement)
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     * 
     * @param   objact  $in_pagedata            Referenz auf das pagedata-object
     * @param   string  $in_html_tag_app_id     APP-ID des Maskenlements
     * @param   int     $in_html_tag_id         ID des Maskenlements
     * @param   string  $in_styleelement_app_id APP-ID des Styleelements
     * @param   int     $in_styleelement_id     ID des STyleelements
     * @return  boolean
     */
    function setHtmlTaghasStyleelement(  &$in_pagedata, $in_html_tag_app_id, $in_html_tag_id, $in_styleelement_app_id, $in_styleelement_id) {
        
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "html_tag_has_style_element";
	$SqlArray["into"]   = " html_tag_app_id, html_tag_id, style_element_app_id, style_element_id";
	$SqlArray["values"] =   "'".$in_html_tag_app_id."', ".$in_html_tag_id.", '".$in_styleelement_app_id."', ".$in_styleelement_id;
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return true;}
    }
    
    
    
    
    /** Fügt einen Datensatz in die Tabelle htmltaggroup_has_form ein
     * 
     * @param   object  $in_pagedata                Referenz zum pagedata-object
     * @param   string  $in_htmltaggroup_app_id     APP-ID der htmlgroup (Symbolleiste/ Symbolleistengruppe)
     * @param   int     $in_htmltaggroup_id         ID der htmlgroup
     * @param   string  $in_form_app_id             APP-ID des Formulars 
     * @param   int     $in_form_id                 ID des Formulars
     * @param   int     $in_sort                    Reihenfolge des Formulars innerhalb der Formularleistengruppe                 
     * @param   int     $in_grouptype               Anordnung der Symbolleiste (1 = oben|2 = unten]
     * @return  boolean
     */
    function setHtmlTaggroupHasForm(&$in_pagedata, $in_htmltaggroup_app_id, $in_htmltaggroup_id, $in_form_app_id, $in_form_id, $in_sort, $in_grouptype) {
        
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "htmltaggroup_has_form";
	$SqlArray["into"]   = " htmltaggroup_app_id, htmltaggroup_id, form_app_id, form_id, sort, grouptype";
	$SqlArray["values"] =   "'".$in_htmltaggroup_app_id."', ".$in_htmltaggroup_id.", '".$in_form_app_id."', ".$in_form_id.", ".$in_sort.", ".$in_grouptype;
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return true;}
    }
    
    
    
    
    /** Legt in der tabelle mask_has_htmltaggroup einen Datensatz, d-h. eine Verknüpfung zwischen einer
     * Maskenelementgruppe und einer Maske an.
     * [Theoretisch sind eigenständige Funktionen zum Anlegen neuer Datensätze in einer beliebigen Tabelle nicht notwendig, da dies die 
     * Funktion insertDataIntoDB flexibel für jede beliebige Tabelle erledigen kann. Im Kernmodul sind jedoch komfortable Zusatzfunktionen
     * auf Basis der speziellen set...-Funktionen möglich.]
     * 
     * @param   object  $in_pagedata            Referenz zum pagadata-object
     * @param   string  $in_htmltaggroup_app_id APP-ID der htmltaggroup (Maskenelementgruppe)
     * @param   integer $in_htmltaggroup_id     ID der htmltaggroup
     * @param   string  $in_mask_app_id         APP-ID der Maske
     * @param   integer $in_mask_id             ID der Maske
     * @return  boolean 
     */
    function setHtmltaggroupToMask(&$in_pagedata, $in_htmltaggroup_app_id, $in_htmltaggroup_id, $in_mask_app_id, $in_mask_id) {
        
        $SqlArray = array();
        $SqlArray["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $SqlArray["table"] = "mask_has_htmltaggroup";
	$SqlArray["into"]   = "mask_app_id, mask_id, htmltaggroup_app_id, htmltaggroup_id";
	$SqlArray["values"] = "'".$in_mask_app_id."', ".$in_mask_id.", '".$in_htmltaggroup_app_id."', ".$in_htmltaggroup_id;
                     
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();  
        
        $result = insertDataIntoDB($SqlArray, $dummy_form, $in_pagedata->getSessionArray()["uid"], $in_pagedata);
        
        if ($result == false) {return false;} else {return true;}
    }
    
    
    
    
    /** Ermittelt für eine APP-ID aus der config.xml bestimmtes Attribut
     * 
     * @param   string      $in_AppId       ID der APP dessen DBMS ermittelt werden soll.
     * @param   string      $in_attribut    Attribut, dessen Wert ermittelt werden soll. Es muss sich um ein gültiges Attribut innerhalb des Knotens db_connect handeln. 
     * @return  mixed                       Wert des Attributs (bspw. postgresql oder mysql) oder false, wenn Config-Datei nicht geöffnet werden konnte
     */
    function getValueFromConfigXml($in_AppId, $in_attribut) {
        $myDirSep = global_variables::getDirectorySeparator();
        $_configFile = "..".$myDirSep.global_variables::getPathAndFileForConfigxml_rel($in_AppId);                                       //ToDo: passt nur solange pro app nur eine Connection benötigt wird, da in_id = app_id
        
        if(file_exists($_configFile) == true) {
            $config_file = new SimpleXMLElement(file_get_contents($_configFile));
            $value = $config_file->db_connect->$in_attribut->__toString();
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> config.xml gefunden: ', "Ziel: ".$_configFile." - eigene Position: ".$_SERVER['PHP_SELF'],"INFO");
            
        } else {
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> config.xml nicht gefunden: ', "Ziel: ".$_configFile." - eigene Position: ".$_SERVER['PHP_SELF'],"ERROR");
            $value = false;
        }
        return $value;  
    }
    
    
    
    /** Schreibt in die Datenbanktabelle app, die Versionnumber zur APP
     * 
     * @param   object  $in_pagedata                    Referenz zum pagedata-object
     * @param   string  $in_versionnumber               einutragende Versionsnummer
     * @param   string  $in_versionnumber_compatible    Versionsnummer, bis zu der die Version abwärtskompatibel ist
     * @param   string  $in_app_id                      app_id, deren Version gesetzt werden soll
     * @param   string  $in_uid                         aktuell angemeldete uid
     * @return  boolean
     */
    function setVersionNumberIntoTableApp(&$in_pagedata, $in_versionnumber, $in_versionnumber_compatible, $in_app_id, $in_uid) {
        
        
        
        //Daten für Tabelle version ermitteln
        $update =   "version = '".$in_versionnumber."', version_compatible = '".$in_versionnumber_compatible."'";
        
        $where = "id = '".$in_app_id."'";
        
        
        $sqlDaten = array();
        $sqlDaten["into"] = "";
        $sqlDaten["values"] = "";
        $sqlDaten["update"] = $update;
        $sqlDaten["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $sqlDaten["table"] = "app";
        $sqlDaten["where"] = $where;
        $sqlDaten["logdata"] = "";
        $sqlDaten["logdata_id_data"] = "";

        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();     
        
        $result = updateData($sqlDaten, $dummy_form, $in_uid, $in_pagedata);

        if ($result < 0) {return false;} else {return true;}
    }
    
    
    
    
    /**Lädt über einen require_once-Aufruf  ein Plugin aus dem Verzeichnis
     * ..\data\[APP-ID]\plugin\
     * 
     * @param   string      $in_app_id          App-ID in dessen Verzeichnis das Plugin abgelegt ist
     * @param   string      $in_plugin          Name der PHP-Plugin-Datei (ohne Dateiendung, Bsp.:  myPlugin statt myPlugin.php); 
     *                                          Wenn sich das Plugin in einem Unterverzeichnis befindet, dann Verzecinisname und Directory-Seperator
     *                                          im Dateinamen angeben. (Bsp.: myDir\myPlugin)
     * @return  boolean
     */
    function loadPlugin($in_app_id, $in_plugin) {
        $myDirSep = global_variables::getDirectorySeparator();
        $plugin_path = global_variables::getPathForAppmsinstall_abs(false).global_variables::getPathForPlugins_rel($in_app_id);
        if(file_exists($plugin_path.$in_plugin.".php") == true) {
            require_once($plugin_path.$in_plugin.".php");
            return true;
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Lade Plugin fehlgeschalgen", "Plugin-Datei: ".$plugin_path.$in_plugin.".php existiert nicht.", "ERROR");
            return false;
        }
    }
    
    
    
    
    
    /** In der Regel besteht der Columnname eines SQL-Result aus Tabellen- und Spaltennamen.
     * Bsp.: acoount.name
     * Wenn das der Fall ist, gibt diese Funktion den Wert "Name" zurück. D.h. der Tabellenname wird entfernt
     * und der erste Buchstabe des Spaltennamens kann groß geschrieben werden.
     * Anderfalls wird davon ausgegangen, dass nur ein Columnname vorhanden ist.
     * 
     * @param   string      $in_tableAndColumn          Tabellen und Spaltenname (BSp.: account.name)
     * @param   boolean     $in_firstLetterBig          Legt fest, dass der erste Buchstabe der Spalte groß geschrieben sein soll
     * @return  string                                  Bsp.: Name; Wenn kein Punkt in $in_tableAndColumn enthalten ist wird wieder $in_tableAndColumn zurückgegeben.
     */
    function getColumnnameFromTableAndColumn($in_tableAndColumn, $in_firstLetterBig) {
        $feedback = "";
        
        if(strpos($in_tableAndColumn, ".") !== false) {
            $temp = explode(".", $in_tableAndColumn);
            $columnname = $temp[1];             //Temp[0] = tablename; temp[1] = columnname
            if($in_firstLetterBig == true) {
                $feedback = ucfirst($columnname);
            } else {
                $feedback = $columnname;
            }
        } else {
            if($in_firstLetterBig == true) {
                $feedback = ucfirst($in_tableAndColumn);
            } else {
                $feedback = $in_tableAndColumn;
            }
        }
        return $feedback;
    }
    
    
    
    /** In der Regel besteht der Columnname eines SQL-Result aus Tabellen- und Spaltennamen.
     * Bsp.: acoount.name
     * Wenn das der Fall ist, gibt diese Funktion den Wert "account" zurück. D.h. der Columnname wird entfernt.
     * Anderfalls wird davon ausgegangen, dass nur ein Columnname vorhanden ist und somit kein Tablename
     * 
     * @param   string      $in_tableAndColumn          Tabellen und Spaltenname (BSp.: account.name)
     * @return  string                                  Bsp.: Name; Wenn kein Punkt in $in_tableAndColumn enthalten ist, wird false zurückgegeben
     */
    function getTablenameFromTableAndColumn($in_tableAndColumn) {
        $feedback = "";
        
        if(strpos($in_tableAndColumn, ".") !== false) {
            $temp = explode(".", $in_tableAndColumn);
            $feedback = $temp[0];             //Temp[0] = tablename; temp[1] = columnname
            
        } else {
            
            $feedback = false;
            
        }
        return $feedback;
    }
    
    
    
    
    /** Wandelt ein Formular-Dataset in eine horizontale HTML-Tabelle um.
     * D.h. eine Überschriftenzeile und beliebig viele Datenzeile.
     * Wenn Dataset leer ist, wird ein Leerstring zurückgegeben.
     * Der Input-Parameter unterscheidet sich von buildHtmlTableHorizontalQuery
     * 
     * @param   Array   $in_queryResultAsArray          Array, wie es von der Funktion getQueryResultAsArray erzeugt wird. key kann statt table.column auch nur column anthalten.
     *                                                  Bsp.: Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [k_bst_pre.id] => Array
                                                                                (
                                                                                    [field.id] => 9121
                                                                                    [field.name] => ID
                                                                                    [field.value] => 238
                                                                                    [field.valueplaintext] => 
                                                                                )

                                                                            [k_bst_pre.bst] => Array
                                                                                (
                                                                                    [field.id] => 6272
                                                                                    [field.name] => Haushaltskostenstellennummer
                                                                                    [field.value] => 02601203
                                                                                    [field.valueplaintext] => 
                                                                                ) <br />
     * @return  string                                  Resultarray in <table>-Syntax
     */
    function buildHtmlTableHorizontal($in_queryResultAsArray) {
        $data = $in_queryResultAsArray;
        $feedback = "";
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> übergebene Daten: ', $data);
                            
        
        if (count($data)>0) {                                                                   //Wenn Daten gefunden wurden, werden die Felder pro Datensatz erneut angedruckt
            //Überschriften andrucken
            $feedback = $feedback."<table id=\"simpleTable\">\n";

                // Überschriften
                $feedback = $feedback."<tr class=\"tablerow_header\">\n";
                    foreach ($data[0] as $fieldkey => $fieldarray) {
                        $my_columnname = $fieldarray["field.name"];
                        $feedback = $feedback.  "<th class=\"tablecell_query_preview\">$my_columnname</th>\n";
                    }
                $feedback = $feedback."</tr>\n";

                //Inhalte zeilenweise durchgehen
                for ($i=0; $i<count($data);$i++) {                                                  //Jeder Datensatz wird einzeln bearbeitet
                    $feedback = $feedback. "<tr class=\"tablerow\">\n";
                        //Pro Zeile alle Spalten durchgehen
                        foreach ($data[$i] as $key => $cur_ds) {
                            if($cur_ds["field.valueplaintext"] != "") {$value = $cur_ds["field.valueplaintext"];} else {$value = $cur_ds["field.value"];}
                        
                            $feedback = $feedback.  "<td class=\"tablecell_query_preview\">\n$value</td>\n";
                        }

                    $feedback = $feedback. "</tr>\n";
                    
                    
                    
                }

            $feedback = $feedback."</table>\n";

        } 
        return $feedback;
    }
    
    
    
    
    /** Wandelt ein queryResultArray in eine horizontale HTML-Tabelle um.
     * D.h. eine Überschriftenzeile und beliebig viele Datenzeile.
     * Wenn queryResultArray leer ist, wird ein Leerstring zurückgegeben.
     * 
     * @param   Array   $in_queryResultAsArray          Array, wie es von der Funktion getQueryResultAsArray erzeugt wird. key kann statt table.column auch nur column anthalten.
     *                                                  Bsp.: Array <br />
                                                                ( <br />
                                                                    [0] => Array <br />
                                                                        ( <br />
                                                                            [tables.table_schema] => manager <br />
                                                                            [tables.ref_id] => account <br />
                                                                            [tables.ref_value] => account <br />
                                                                            [tables.table_type] => BASE TABLE <br />
                                                                        ) <br />
                                                                    [1] => Array <br />
                                                                        ( <br />
                                                                            [tables.table_schema] => manager <br />
                                                                            [tables.ref_id] => account_has_role <br />
                                                                            [tables.ref_value] => account_has_role <br />
                                                                            [tables.table_type] => BASE TABLE <br />
                                                                        ) <br />
     *                                                          ) <br />
     * @return  string                                  Resultarray in <table>-Syntax
     */
    function buildHtmlTableHorizontalQuery($in_queryResultAsArray) {
        $data = $in_queryResultAsArray;
        $feedback = "";
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> übergebene Daten: ', $data);
                            
        
        if (count($data)>0) {                                                                   //Wenn Daten gefunden wurden, werden die Felder pro Datensatz erneut angedruckt
            //Überschriften andrucken
            $feedback = $feedback."<table id=\"simpleTable\">\n";

                // Überschriften
                $feedback = $feedback."<tr class=\"tablerow_header\">\n";
                    foreach ($data[0] as $columnname => $value) {
                        $my_columnname = getColumnnameFromTableAndColumn($columnname,true);
                        $feedback = $feedback.  "<th class=\"tablecell_query_preview\">$my_columnname</th>\n";
                    }
                $feedback = $feedback."</tr>\n";

                //Inhalte zeilenweise durchgehen
                for ($i=0; $i<count($data);$i++) {                                                  //Jeder Datensatz wird einzeln bearbeitet
                    $feedback = $feedback. "<tr class=\"tablerow\">\n";
                        //Pro Zeile alle Spalten durchgehen
                        foreach ($data[$i] as $key => $value) {
                            $feedback = $feedback.  "<td class=\"tablecell_query_preview\">\n$value</td>\n";
                        }

                    $feedback = $feedback. "</tr>\n";
                }

            $feedback = $feedback."</table>\n";

        } 
        return $feedback;
    }
    
    
    
    
    
    
    
    /** Wandelt einen Datensatz in eine vertikale HTML-Tabelle um.
     * D.h. die erste Spalte enthält die Überschriften und die zweite Spalte die Inhalte.
     * Wenn queryResultArray leer ist, wird ein Leerstring zurückgegeben.
     * 
     * @param   Array   $in_queryResultAsArray          Array, wie es von der Funktion getQueryResultAsArray erzeugt wird. key kann statt table.column auch nur column anthalten.
     *                                                  Bsp.: Array
                                                                        (
                                                                            [k_bst_pre.id] => Array
                                                                                (
                                                                                    [field.id] => 9121
                                                                                    [field.name] => ID
                                                                                    [field.value] => 238
                                                                                    [field.valueplaintext] => 
                                                                                )

                                                                            [k_bst_pre.bst] => Array
                                                                                (
                                                                                    [field.id] => 6272
                                                                                    [field.name] => Haushaltskostenstellennummer
                                                                                    [field.value] => 02601203
                                                                                    [field.valueplaintext] => 
                                                                                ) <br />
     * @return  string                                  Resultarray in <table>-Syntax
     */
    function buildHtmlTableVertical($in_queryResultAsArray) {
        $data = $in_queryResultAsArray;
        $feedback = "";
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> übergebene Daten: ', $data);
                            
        
        if (count($data)>0) {                                                                   //Wenn Daten gefunden wurden, werden die Felder pro Datensatz erneut angedruckt
            
            
            $feedback = $feedback."<table id=\"simpleTable\">\n";
                foreach ($data as $my_field_id => $my_field_attributs) {
                    // neue Zeile
                    If($my_field_attributs["field.valueplaintext"]!="") {$value = $my_field_attributs["field.valueplaintext"];} else {$value = $my_field_attributs["field.value"];}
                    $feedback = $feedback."<tr>\n";
                        //in der ersten Spalte die Überschrift andrucken
                        $feedback = $feedback."<th class=\"tablecell_header\">".$my_field_attributs["field.name"]."</th>\n";
                        $feedback = $feedback."<td class=\"tablecell_default\">\n$value</td>\n";
                        
                    $feedback = $feedback."</tr>\n";
                }
            $feedback = $feedback."</table>\n";

        } 
        return $feedback;
    }
    
    
    
    
    
    /** Wandelt einen Datensatz in eine vertikale RTF-Tabelle um.
     * D.h. die erste Spalte enthält die Überschriften und die zweite Spalte die Inhalte.
     * Wenn queryResultArray leer ist, wird ein Leerstring zurückgegeben.
     * 
     * @param   Array   $in_queryResultAsArray          Array, wie es von der Funktion getQueryResultAsArray erzeugt wird. key kann statt table.column auch nur column anthalten.
     *                                                  Bsp.: Array
                                                                        (
                                                                            [k_bst_pre.id] => Array
                                                                                (
                                                                                    [field.id] => 9121
                                                                                    [field.name] => ID
                                                                                    [field.value] => 238
                                                                                    [field.valueplaintext] => 
                                                                                )

                                                                            [k_bst_pre.bst] => Array
                                                                                (
                                                                                    [field.id] => 6272
                                                                                    [field.name] => Haushaltskostenstellennummer
                                                                                    [field.value] => 02601203
                                                                                    [field.valueplaintext] => 
                                                                                ) <br />
     * @param   $in_query_object                        Referenz auf ein Query-Objekt
     * @return  string                                  Resultarray in <trowd>-Syntax
     * 
     */
    function buildRtfTableVertical($in_queryResultAsArray, &$in_query_object) {
        $data = $in_queryResultAsArray;
        $feedback = "";
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> übergebene Daten: ', $data);
                            
        
        if (count($data)>0) {                                                                   //Wenn Daten gefunden wurden, werden die Felder pro Datensatz erneut angedruckt
            
            
            $feedback = "\n";
            foreach ($data as $feldkey => $feldarray) {
                if(isHiddenField($in_query_object->form_array["form.id"], $in_query_object->form_array["form.app_id"], $feldarray["field.name"]) != true) {
                    if($feldarray["field.valueplaintext"]!="") {$value = $feldarray["field.valueplaintext"];} else {$value = $feldarray["field.value"];}
                    $feedback = $feedback.'\trowd '."\n";
                    $feedback = $feedback.'\cellx3000\cellx9000 '."\n";          //x3000-> Position der rechten Kante der Zelle
                    $feedback = $feedback.'\pard\intbl\widctlpar\li100 '.$feldarray["field.name"].' \cell \intbl '.$value.' \cell '."\n";
                    $feedback = $feedback.'\row '."\n";
                }
            }
            $feedback = $feedback.'\pard\widctlpar\par '."\n";

        } 
        return $feedback;
    }
    
    
    
    
    
    
    /** Ermittelt die aktuell installierte Versionsnummer der angegebenen APP
     * 
     * @param   string      $in_appId       APP-ID, dessen Versionsnummer ermittelt werden soll
     * @return  mixed                       Wenn die App noch keine Versionsnummer hat, wird 0 zurückgegeben. Wenn ein Fehler auftrat oder die APP nicht existiert wird false zurückgegeben.
     */
    function getVersionnumberFromApp($in_appId) {
        $connectionID = global_variables::getConnectionIdOfDbSchemaSYS01();
        $kernelSchema = global_variables::getNameOfDbSchemaSYS01();
        $versionnumber = getDataFromTableByID($connectionID, $kernelSchema, "app", "version", "id = '".$in_appId."'");
        
        if($versionnumber === false) {
            $feedback = false;
        } elseif($versionnumber == "") {
            $feedback = 0;
        } else {
            $feedback = $versionnumber;
        }
        
        return $feedback;
    }
    
    
    /** Ermittelt die abwärtskompatible Version der aktuell installierten Version der angegebenen APP
     * 
     * @param   string      $in_appId       APP-ID, dessen Versionsnummer ermittelt werden soll
     * @return  mixed                       Wenn die App noch keine Versionsnummer hat, wird 0 zurückgegeben. Wenn ein Fehler auftrat wird false zurückgegeben.
     */
    function getVersionnumberCompatibleFromApp($in_appId) {
        $connectionID = global_variables::getConnectionIdOfDbSchemaSYS01();
        $kernelSchema = global_variables::getNameOfDbSchemaSYS01();
        $versionnumber = getDataFromTableByID($connectionID, $kernelSchema, "app", "version_compatible", "id = '".$in_appId."'");
        
        if($versionnumber === false) {
            $feedback = false;
        } elseif($versionnumber == "") {
            $feedback = 0;
        } else {
            $feedback = $versionnumber;
        }
        
        return $feedback;
    }
    
    
    
    
    
    /** Fügt eine Datenliste, welche durch eine Query ermittelt wurde, als Inhaltselemente, in eine Felderliste ein. 
     * Daten werden übertragen, wenn der Spaltenname (bzw. der Alias aus query_part_select) als Name in einem Feld (feld.name) angegebn wurde.
     *
     * 
     * @param array $fieldlist      zweidimensionales Feld, dass die Felder einer Maske enthält. Wird von getFieldlist erzeugt.
     * @param array $data           eindimensionales Feld, welches das Ergebnis einer Query zurückgibt
     *                              Bsp.:
     *                              Array(
                                        [app.id] => BIM01
                                        [app.name] => BI-Manager )
     * @return array                fieldlist ergänzt um Feldinhalte
     */
    function matchFieldsToQueryData($fieldlist, $data) {
        for ($i = 0; $i < count($fieldlist); $i++) {       
            //Maskenfelder einzeln durchgehen und prüfen, ob es entsprechende Feldinhalte in $data gibt
            
            //prüfen, ob es für feld.spalte einen entsprechenden Wert in data gibt
            //$myKey = issetKeyLike($data, $fieldlist[$i]["feld.spalte"]);
            $myKey = issetColumnnameLike($data, $fieldlist[$i]["feld.spalte"]);
            //die folgende Zeile ist nur zur Abwärtskompatibilität für Version4 aller App's enthalten
            if($myKey === false) {$myKey = issetColumnnameLike($data, $fieldlist[$i]["feld.name"]);}
            
            if($myKey <> false) {
                //wenn der Spaltenname aus $data mit dem Feldnamen aus fieldlist übereinstimmt, dann value aus data nach feldinhalt aus Fieldlist übertragen
                $fieldlist[$i]["feld.feldinhalt"] = $data[$myKey];
            }
            
            
//            //Prüfen, ob es sich bei dem aktuellen Datensatz, um einen SYS-Datensatz handelt
//            !!!Absatz funktioniert nicht, da data nicht die Spalte tabelle.sys enthält.!!!
//            if (isset($fieldlist[0]["form.db_table"])) {
//                //Wenn im aktuellen Formular, neben der Quelle auch eine Tabelle hinterlegt ist, dann müssen die SYS-Datensätze geschützt werden.
//                $tabelle = $fieldlist[0]["form.db_table"];
//                if(isset($data[$tabelle.".sys"])) {
//                    if($data[$tabelle.".sys"] == 1) {
//                        //Der  Datensatz wird als SYS-Datensatz gekennzeichnet. Diese Information wird im ersten Feld , statt eine Ebene höher, eingefügt, damit das Array fieldlist nicht wächst.
//                        $fieldlist[0]["datensatz.sys"] = true;
//                    }
//                }
//            }
        }
        return $fieldlist;
    }
    
    
    /** übergibt Vorgabewerte aus einen Get-Array in die entsprechenden Felder. 
     * Jedoch nur, wenn das Feld nicht schreibgeschützt ist.
     * 
     * @param array $in_fieldlist          zweidimensionales Feld, dass die Felder einer Maske enthält. Wird von getFieldlist erzeugt.
     * @param array $in_get_fieldlist   Fieldlist des GET-Objektes; Bsp.: <br />
     *                                                                Array <br />
                                                                        ( <br />
                                                                            [4106] => testVM <br />
                                                                            [4121] => 34 <br />
                                                                        ) <br />
     * @return type
     */
    function matchFieldsToGetdata($in_fieldlist, $in_get_fieldlist) {
        
        
        for ($i = 0; $i < count($in_fieldlist); $i++) { 
        //Schleife über alle Felder    
            
            if(isset($in_get_fieldlist[$in_fieldlist[$i]["feld.id"]])) {
                //Wenn für das aktuelle Feld in $_GET ein Vorbelegungswert übergeben wurde, ...
//                if(isset($in_fieldlist[$i]["feld.vorgabewert"]) !== false) {      //ACHTUNG: Bedingung ist aus unerklärlichen Gründen nie true?!?
                    //if($in_fieldlist[$i]["feld.vorgabewert"] == "" AND $in_fieldlist[$i]["feld.readonly"] != 1) {
                    if($in_fieldlist[$i]["feld.readonly"] != 1) {
                    //wenn das Feld nicht schreibgeschützt ist, wird der Vorgabewert aus $_GET gesetzt. Ein ggf. bereits vorhandener Vorgabewert wird überschrieben.    
                        $in_fieldlist[$i]["feld.vorgabewert"] = $in_get_fieldlist[$in_fieldlist[$i]["feld.id"]];
                    }
//                }
            }
            
        }
        
        return $in_fieldlist;
    }



    /** Ermittelt App_id und id der aktiven Rolle, des zurzeit angemeldeten users.
     * Wenn keine aktive Rolle ermittelt werden konnte, werden die Daten des SYS01-guest-users zurückgegeben
     * 
     * @return array    array mit den keys "role.app_id" und "role.id" wird zurückgegeben.
     */
    function getActiveRoleData() {
        $activeRole = array();

        if(isset($_SESSION["active_role"]) == true) {
            //aktive Rolle existiert
            $activeRole["role.app_id"] = $_SESSION["active_role"]["role.app_id"];                      
            $activeRole["role.id"] = $_SESSION["active_role"]["role.id"];                       
        } else {
            //Defaultwerte, wenn noch keine aktive Rolle gesetzt wurde
            $activeRole["role.app_id"] = "SYS01";                      
            $activeRole["role.id"] = 6;         
        }

        return $activeRole;
    }
    
    
    
    /** Ermittelt die APP-ID des aktiven Accounts aus der aktiven SESSION.
     * Wenn das nicht gelingt,
     * wird die App-ID der aktiven Rolle zurückgegeben.
     * 
     * @return  string          App-ID
     */
    function getAppIDFromActiveAccount() {
        //aktiver Account
        $activeAppId = $_SESSION["app_id"];             
        
        
        if($activeAppId == false OR                                             //tritt auf, wenn ?
           $activeAppId == global_variables::getAppIdFromSYS01() OR             //Wenn maske per redirekt aufgerufen wurde, die Rolle aber eigentlich per mask_has_roe and_directory Zugriff haben könnte, dann kann role_app abweichend von sys01 sein.
           $activeAppId == "noAppFound")                                        //tritt im Zusammenhang mit mask_has_role_and_directory auf.
        {
            $feedback = getAppIDFromActiveRole();
        } else {
            $feedback = $activeAppId;
        }
        return $feedback;
        
    }
    
    
    
    /** liefert die App-ID des aktuell angemeldeten User (account.id)
     * Wenn der User in der internen Account-Verwaltung (DB-Table = account) nicht existiert,
     * dsnn entspricht die APP-ID i.d.R. der APP-ID der Anmeldemaske
     * 
     * @return string
     */
    function getAppIDFromActiveUser() {
        return $_SESSION["app_id"];
    }
    
    
    /** Ermittelt die APP-ID der aktiven Rolle über die SESSION-Variable
     * 
     * @return  string          App-ID
     */
    function getAppIDFromActiveRole() {
        
            $feedback = getActiveRoleData()["role.app_id"];
        
        return $feedback;
        
    }






    /** Prüft, ob der aktuelle Account auf eine angeforderte Maske zugreifen darf.
     *  
     * 
     * @param   String  $in_AccountID       Account-ID, welche die Maske anfordert 
     * @param   String  $in_AccountAppID    Account-App-ID
     * @param   string  $in_mask_app_id     App-id der angeforderten Maske
     * @param   String  $in_mask_id         ID einer angeforderten Maske
     * @param   array   $in_SESSION         Referenz auf das Session-Array
     * @return  array                       Bsp. array("access" => false,
                                                    "reason" => "-130_info");
     *                                      reason: -132 = Zurgiiff für IP nicht erlaubt
     *                                              -130_info = Zurgif für Rolle nicht erlaubt
     */
    function checkPermission($in_AccountID, $in_AccountAppID, $in_mask_app_id, $in_mask_id, &$in_session) {
        $permission = array("access" => false,
                            "reason" => "");
        
        //Prüfen, ob der Account Mitglied einer Rolle ist, die die angeforderte Maske aufrufen darf
        if($in_session["validator_process_type"] == "roleByMask" AND $in_session["guest_user"] != true) {
            //Permission anhand der Maske prüfen  
            $role_app_id = $in_session["active_role"]["role.app_id"];
            $role_id = $in_session["active_role"]["role.id"];
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' - suche Masken mit getMaskListByRole', "Rolle: ".$role_id." - App-ID der Rolle: ".$role_app_id);
            $allowed_masks = getMaskListByRole($role_app_id, $role_id);         //ermittelt ein mehrdimensionales Feld, welches alle zulässigen Masken für die übergebene Role-ID enthält. 
        } else {
            //Permissions anhand des Accounts prüfen
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' - suche Masken mit getMaskListByAccount', "Account-ID: ".$in_AccountID." - App-ID des Account: ".$in_AccountAppID);
            $guest_user = getConfig("guest_user", $in_mask_app_id);
            $allowed_masks = getMaskListByAccount($in_AccountID, $in_AccountAppID, $guest_user);               //ermittelt ein mehrdimensionales Feld, welches alle zulässigen Masken für die übergebene Account-ID enthält.  
        }
        $mask_uniqueid = array_column($allowed_masks, '.uniqueid');             //aus dem zweidimensionalen Array ein eindimensionales machen, dass nur die Werte für uniqueid (CONCAT(mask.app_id,'_',mask.id) as uniqueid) enthält
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' - mask_uniqueid_list', $mask_uniqueid);
        $mask_uniqueid[] = global_variables::getAppIdFromSYS01()."_0";          //Default-Dummy-Mask für Ajax-Requests und Query-Anforderungen (Druckaufbereitungen)
        $permission_role = in_array($in_mask_app_id."_".$in_mask_id, $mask_uniqueid);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' - erlaubte Masken', $allowed_masks);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' - angeforderte Maske', $in_mask_app_id."_".$in_mask_id);
        
        
        
        
        //Prüfen, ob die Maske von der IP-Adresse aufgerufen werden darf.
        $permission_ip = checkPermissionForIP($in_mask_app_id);
        
        
        if($permission_role == true AND $permission_ip == true) {
            $permission["access"] = true;
        } else {
            $permission["access"] = false;
            //Den Grund der Zugriffsverweigerung hinterlegen. Die ID kann über die Tabelle konstante (konstantentyp_id = 35) aufgelöst werden
            if($permission_role == false) {$permission["reason"] = "-130_info";} 
            if($permission_ip == false) {$permission["reason"] = "-132";}   
        }
        
        return $permission;
    }
    
    
    
    
    
    /** Die Funktion prüft, ob der aktuelle user eine andere Rolle inne hat, welche Zugriff auf die target_mask ermöglicht.
     * Sollte ein Workflow vorliegen, wird das Zugriffsrecht auf die Maske in Abhängigkeit vom aktuellen workflow_step
     * ermittelt (siehe workflow_access). Andernfalls wird die Zugriffsberechtigung über die Tabelle role_has_mask ermittelt.
     * 
     * @param   array   $in_session         Referenz auf das SESSION-Array
     * @param   string  $in_maskAppId       
     * @param   integer $in_maskId
     * @param   object  $in_pagedata        Referenz auf das pagedata-object
     * @return  mixed                       Array der ersten ermittelten zugriffsberechtigten Rolle oder false.
     *                                      Array
                                                (
                                                    [role.id] => 99
                                                    [role.name] => D4 Haushalt - SB
                                                    [role.app_id] => BIM01
                                                )
     */
    function getRoleWithAccessToMask(&$in_session, $in_maskAppId, $in_maskId, &$in_pagedata) {
        
        $feedback = false;
        
        
        //Alle Rollen des user aus der Session auslesen
        $my_roles = $in_session["rollen"];
        
        
        //alle Rollen, die berechtigt sind die target_mask aufzurufen, ermitteln
        if($in_pagedata->existWorkflow() === true) {
            $my_workflow = $in_pagedata->getWorkflow();
            $roles_with_access = $my_workflow->getRoleWithAccessFromCurrentUser();
        } else {
            $active_role_app = $in_session["active_role"]["role.app_id"];
            $active_role = $in_session["active_role"]["role.id"];
            $roles_with_access = getRolesForMask($in_maskAppId, $in_maskId, $active_role_app, $active_role);
        }
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' - zugriffsberechtigte Rollen', $roles_with_access);
        
        
        
        
        //Prüfen, ob der user über eine zugriffsberechtigte Rolle verfügt
        foreach ($roles_with_access as $key => $cur_access_role) {
            foreach ($my_roles as $key => $cur_my_role) {
                if($cur_my_role["role.app_id"] == $cur_access_role["role_app_id"] AND $cur_my_role["role.id"] == $cur_access_role["role_id"]) {
                    $feedback = $cur_my_role;
                    break;
                }
            }
        }
        
        
        
        return $feedback;
        
    }
    
    
    
    
    /** 
     * 
     * @param type $in_mask_app_id
     * @return boolean
     */
    function checkPermissionForIP($in_mask_app_id) {
        $feedbackPermission = "undefined";                                      //Default: Es ist unbekannt, ob User Zugriff hat

        //IP-Adresse des Nutzers ermitteln
        $client_ip = getIpAdress();
        
        // IP-Rules für die APP der Maske ermitteln
        $ip_rules = getIpSecureRules($in_mask_app_id);
        
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> client_ip: ', $client_ip);
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> ip_secure_rules: ', $ip_rules);
        
        
        
        if($ip_rules == array()) {
            //Wenn keine IP-Secure-Rules gefunden wurden, dann ist der Zugriff erlaubt
            $feedbackPermission = "true";
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> ip_permission: ', "Es wurden keine IP-Rules zur Zugriffsbeschränkung gefunden");
        } else {
            //Wenn IP-Secure-Rules vorhanden, dann prüfen ob die client_ip Zugriff erhält
            foreach ($ip_rules as $current_rule) {
                if($current_rule["ip.iptype"] == "ipv4") {
                    //Prüfen, ob die Client-IP von der aktuellen Rule erfasst wird
//                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Prüfe IP-Rule: ', $current_rule);
                    if(doesTheIpRuleApply($client_ip, $current_rule["ip.ip"]) == true) {
                        //Rule auswerten
                        if($current_rule["app_has_ipgroup.access_type"] == "allow") {
                            $feedbackPermission = "true";
                            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Prüfe IP-Rule: ', "IP-Rule passt zur client-IP und erlaubt den Zugriff");
                        } else {
                            $feedbackPermission = "false";
                            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Prüfe IP-Rule: ', "IP-Rule passt zur client-IP und verbietet den Zugriff");
                        }
                    } 
                } else {
                    addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> ipv6: ', "Es gibt noch keine Methode um ipv6-Adressen zu behandeln");
                }
                
                //Wenn passende Zugriffsregel gefunden wurde, dann die weiteren Rules nicht mehr prüfen
                if($feedbackPermission <> "undefined") {
                    break;
                }
            }
        }
        
        

        if($feedbackPermission == "false") {
            return false;
        } else {
            //wenn "true" oder "undefined", dann wird true zurückgegeben
            return true;
        }
        

    }
    
    
    
    
    /** Prüft, ob die Client-IP in den Bereich der Rule-IP gehört. 
     * 
     * @param   string          $in_client_ip       IPv4-Adresse (Bsp.: 127.0.0.1 oder 127:0:0:1 oder localhost)
     * @param   string          $in_rule_ip         IPv4-Adresse oder Adressbereich (Bsp.: 192.168.x.x
     * @return  boolean                             true or false
     */
    function doesTheIpRuleApply($in_client_ip, $in_rule_ip) {
        
        $in_client_ip = str_replace(":", ".", $in_client_ip);                   //Falls die IP-Adresse mit Doppelpunkten ermittelt wurde
        $inClient_ip_array = explode(".", $in_client_ip);
        
        $in_rule_ip = str_replace(":", ".", $in_rule_ip);                       //Falls die IP-Adressen in den Regeln mit Doppelpunkten angegeben wurden
        $in_rule_ip = str_replace("localhost", "127.0.0.1", $in_rule_ip);
        $in_rule_ip_array = explode(".", $in_rule_ip);
        
        for ($i = 0; $i <= 3; $i++) {
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> IP-Tupel-Vergleich: ', "client-Tupel = ".$inClient_ip_array[$i]."; rule-Tupel = ".$in_rule_ip_array[$i] );
            if($inClient_ip_array[$i] == $in_rule_ip_array[$i] OR $in_rule_ip_array[$i] == "x") {
                //die Tupel sind gleich, daher  läuft die Schleife weiter
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> IP-Tupel-Vergleich: ', "Tupel passen" );
            } else {
                //die client_ip ist nicht von der Rule erfasst
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> IP-Tupel-Vergleich: ', "Tupel passen nicht, daher Abbruch dieser Prüfung" );
                //Abbruch der Funktion, da weitere Prüfung nicht mehr sinnvoll
                return false;
            }
        }
        
        //Wenn die Funktion bis hierhin durchgelaufen ist, dann betrifft die Rule die cleint-IP
        return true;
    }
    
    
    
    
    
    
    
   
    /** Ermittelt die zugehörige App_id zu einem Schema aus der Tabelle app_schema.
     * 
     * @global  string  $db_schema_manager_connection_id
     * @global  string  $db_schema_manager
     * @param   string  $in_schema_name                     Name des Schemas, für welches die zugehörige app_id ermittelt werden soll
     * @return  mixed                                       app_id (string) oder false (boolean)
     */
    function getAppIdFromSchema($in_schema_name) {
        global $db_schema_manager_connection_id;
        global $db_schema_manager;
        $app_id = getDataFromTableByID($db_schema_manager_connection_id, $db_schema_manager, "app_schema", "app_id", "db_schema = '".$in_schema_name."'" );
        
        return $app_id;
    }





    /**
     * Fügt Daten in die Debug-Tabelle. Diese Funktion abstrahiert den Zugriff auf die tatsächliche Funktion in der Model-Klasse
     * @param   string  $in_connection_id       ID der zu nutzenden Connection
     * @param   String  $in_debug_type          Art des Debug-Datensatzes [INFO | ERROR]
     * @param   String  $in_debugtopic          Überschrift des Debug-Satzes
     * @param   string  $in_debugmessage        Debug-Meldung
     * @param   String  $in_starttime           einheitliche Startzeit des aktuellen Debug-Vorgangs für alle Debug-Meldungen, die zum selben Debug-Vorgang gehören.
     * @param   string  $in_context             Kennung, die in die Spalte debug.context geschrieben wird.
     */
    function insertDataIntoDebug($in_connection_id, $in_debug_type, $in_debugtopic, $in_debugmessage, $in_starttime, $in_context) {
        insertDebugData($in_connection_id, $in_debug_type, $in_debugtopic, $in_debugmessage, $in_starttime, $in_context);
    }



    /** Löscht alle Einträge der Debug-Tabelle, die älter als n Sekunden sind.
     * 
     * @global string   $db_schema_manager      wird genutzt
     * @param  object   $in_pagadata            Referenz auf das pagedata-object
     * @param  integer  $in_timeToLife          Zeit in Sekunden, nach denen alte Debug-Meldungen gelöscht werden. Default = 3600
     * @return boolean
     */
    function deleteDebugData(&$in_pagadata, $in_timeToLife = 3600) {

        global $db_schema_manager;
        $app_id_from_kernel = global_variables::getAppIdFromSYS01();
        $debugTable = "debug";
        $sql_functionplaceholder_start_tag = getConfig("sql_start_tag_function_placeholder", $app_id_from_kernel);
        $sql_functionplaceholder_end_tag = getConfig("sql_end_tag_function_placeholder", $app_id_from_kernel);
        $where = "debug_time < current_timestamp - ".$sql_functionplaceholder_start_tag."function_name=interval?interval_value=".$in_timeToLife."&interval_type=SECOND".$sql_functionplaceholder_end_tag;                             //Dummy-Bedingung -> alle Datensätze der Debug-Tabelle werden gelöscht
        
        $deleteCommand = array("into" => "",
            "values" => "",
            "update" => "",
            "schema" => $db_schema_manager,
            "table" => $debugTable,
            "where" => $where,
            "logdata" => "",
            "logdata_id_data" => "");

        $dummy_form = array("form.logging" => 0, "form.app_id" => "SYS01");
        $dummy_account_id = "nobody";
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();

        $feedback = deleteData($deleteCommand, $dummy_form, $dummy_account_id, $in_pagadata);
        return $feedback;


    }
    
    
    

    
      



    /** Sendet für die Datensätze eines Datasets (Tabelle, welche durch ein Formular per POST gesendet wurde) jeweils ein Update-Befehl an die Datenbank
     * Voraussetzung ist, dass es pro Datensatz mindestens eine id-Spalte gibt.
     * 
     * @param   array     $in_datensaetze           Zweidimensionales Array, welches eine Liste von Datensätzen enthält. Es sollten nur die Sein, in denen Änderungen auftreten.
     * @param   object    $in_pagedata              Objekt vom Typ pagedata
     * @param   string    $in_current_account_id    Account_id des aktuell angemeldeten Users
     * @param   date      $in_current_date          [optional] Stichtag, falls es sich um eine Maske mit historischen Daten handelt.
     * @return  integer                             Rückmelde-ID's entsprechend der Konstantentyp_id 35 [1|-1|-12|-13|2|22|-2|-22] 
     */
    function updateTabledata($in_datensaetze, &$in_pagedata, $in_current_account_id, $in_current_date = '') {
        


        //for ($i = 0; $i < count($in_datensaetze); $i++) {
        foreach ($in_datensaetze as $key => $current_datensatz) {
            $feedback_update = 0;
//            $in_schema = $in_datensaetze[$i]["schema"];
//            $in_table = $in_datensaetze[$i]["table"];
            $currentForm_id = $current_datensatz["form"];
            $currentFormArray = $in_pagedata->getFormArray($currentForm_id);
            $in_history_flag = $currentFormArray['form.history_flag'];                       //Todo, das muss aus pagadata-> Form ermittelt werden, da es pro Maske unterschiedliche Formulare geben kann
            $in_history_primary = $currentFormArray['form.primarykey'];
            $in_history_gueltig_ab = $currentFormArray['form.history_col_validfrom'];   
            $in_history_gueltig_bis = $currentFormArray['form.history_col_validto'];
            $instance_id = $current_datensatz["instance_id"];
            $datarow = $current_datensatz["ds"];
            
            $current_date = new DateTime($in_current_date);                 //Aufruf muss inerhalb der Schleife erfolgen, damit $current_date bei Mehrfachdurchläufen immerwieder den Ausgangswert annimmt.
            if ($in_history_flag == TRUE) {
                //bei historischen Daten, wird der bestehende Datensatz zum Stichtag (-1 Tag) beendet und zusätzlich ein neuer Datensazt mit den geänderten Werten angelegt.
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Änderung historischer Daten ', 'bisherigen Datensatz befristen (Stichtag -1) und neuen Datensatz ab Stichtag anlegen.');
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Datensatz: ', $current_datensatz);
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Eingabeparameter: ', 'History_flag: ' . $in_history_flag . ' Stichtag: ' . $in_current_date);


                
                if (strtotime($in_current_date) > strtotime($current_datensatz["content"][$in_history_gueltig_ab])) {             
                    //wenn der Stichtag größer dem der aktuellen Historie ist
                    //Step1: bestehenden Datensatz zum Stichtag -1 befristen. Ausnahme Stichtag = $in_history_gueltig_ab
                    $historyData = extractNeededFieldsForHistoryChange($current_datensatz, $in_history_primary, $in_history_gueltig_ab, $in_history_gueltig_bis);
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> reduzierter Datensatz, nur historische Daten: ', $historyData);
                    $historyData[$in_history_gueltig_bis] = date_format(date_modify($current_date, '-1 day'), 'Y-m-d');
                    $historyDataForUpdate = extractDataFromPostarray($historyData, $currentFormArray, $instance_id, $datarow, $in_pagedata);                      
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> reduzierter Datensatz, aufbereitet für Update (Step1): ', $historyDataForUpdate);
                    $feedback_update = updateData($historyDataForUpdate, $currentFormArray, $in_current_account_id, $in_pagedata);
                    
                    if($feedback_update > 0) {
                        //nur wenn Update zuvor erfolgreich war.
                        //Step2: neuen Datensatz ab dem Stichtag mit geänderten Daten anlegen
                        $current_datensatz["content"][$in_history_gueltig_ab] = $in_current_date;
                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> reduzierter Datensatz, aufbereitet für Insert (Step2): ', $current_datensatz["content"]);
                        $historyDataForInsert = extractDataFromPostarray($current_datensatz["content"], $currentFormArray, $instance_id, $datarow, $in_pagedata);
                        $feedback_insert = insertDataIntoDB($historyDataForInsert, $currentFormArray, $in_current_account_id, $in_pagedata);
                    }
                } else {
                    //wenn der Stichtag kleiner oder gleich dem der aktuellen Historie ist
                    $sql_basis_daten = extractDataFromPostarray($current_datensatz["content"], $currentFormArray, $instance_id, $datarow, $in_pagedata);
                    $feedback_update = updateData($sql_basis_daten, $currentFormArray, $in_current_account_id, $in_pagedata);
                }
            } else {
                $sql_basis_daten = extractDataFromPostarray($current_datensatz["content"], $currentFormArray, $instance_id, $datarow, $in_pagedata);
                $feedback_update = updateData($sql_basis_daten, $currentFormArray, $in_current_account_id, $in_pagedata);
            }


            //Wenn update fehlschlägt und 
            //der Grund <> -12 (Permission denied) 
            //der Grund <> -14 (kein Primary-Key vorhanden) 
            //ist, dann wird ein insert versucht                      
            if ($feedback_update < 0 AND in_array($feedback_update, array(-12,-14)) == false) {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Update konnte nicht durchgeführt werden, daher insert: ', "Fehlermeldung nach Update: ".$feedback_update);
                $feedback_insert = insertDataIntoDB($sql_basis_daten, $currentFormArray, $in_current_account_id, $in_pagedata);
                if($feedback_insert < 0 AND $feedback_insert != -21) {
                    //Insert schlug fehl, obwohl Zugriff auf Maske zulässsig war.
                    $feedback = -13;
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Insert konnte nicht durchgeführt werden: ', "Fehlermeldung nach Insert: ".$feedback_insert);
                } else {
                    $feedback = 1;
                }
            } else {
                $feedback = $feedback_update;
                //Auch beim Update werden die gespeicherten Daten als LastInsert abgelegt, damit Drittfunktionen auf die Daten zugreifen können. 
                //$in_pagedata->setFormPropertyDataFromLastInsert($currentForm_id, $current_datensatz["content"]);                     //Daten ablegen, damit später, bspw. beim Mailversand wieder darauf zugegriffen werden kann.
                
            }
            
            

        }

        
        return $feedback;
        
    }


        
    /** Ermittelt für die Tabelle eines Formulares Werte, welche für Autoincrement-Felder genutzt werden können.
     * Bsp.: Die Tabelle user enthält die Spalten
     *  - id (autoincrement)
     *  - name 
     *  - expired_date
     * 
     * Die Funktion getNextValuesForAutoincrementPKs erkennt die autoincrement-Spalte/n und ermittelt für jede Spalte einen zurzeit freien Wert.
     * Um Kollisionen mit gleichzeitig arbeiteten Nutzern zu vermeiden, wird der letzte verwendete ID-Wert um eine Zufallszahl zwischen 1 und 10 erhöht.
     * 
     * @param   array       $in_formArray       Array, vom Typ form
     * @return  array                           Array für alle id-Spalten (Bsp.: array( id => 56, id2 => 8)) 
     */
    function getNextValuesForAutoincrementPKs($in_formArray) {
        $feedback = array();
        $connection_id = $in_formArray["form.connection_id"];
        if(count($in_formArray["form.id_fields_autoincrement"]) > 0) {
            //Wenn Autoincrementfelder im Formular existieren
            
            $maxValue = 0;
            foreach ($in_formArray["form.id_fields_autoincrement"] as $key => $column) {
                //Maxvalue ermitteln und um eine Zufallszahl zwischen 5 und 10 erhöhen.
                $maxValue = getMaxValue($connection_id, $in_formArray["form.db_schema"], $in_formArray["form.db_table"], $column);    //höchste aktuelle id in der Tabelle
                $newValue = $maxValue + rand(1,10);                                                         //maxValue wird um eine Zufallszahl zwischen 1 und 10 erhöht. Damit wird versucht eine Kollision zwischen zwei parallel einzufügendenen Datensätzen zu vermeiden.          
                //für jeden Autoincrementwert einen Eintrag mit Table.Spalte und Wert in $feedback ergänzen
                $feedback[$in_formArray["form.db_table"].".".$column] = $newValue;
            }
            
        }
        
        return $feedback;
    }
    

    
    /** Ermittelt aus einer übergebenen Liste von Feldern eines Formulardatensatzes den Wert des gesuchten Feldes
     * 
     * @param   array   $in_fieldlist           Standard-Fieldlist, wie sie die Methode getFieldList ermittelt
     * @param   string  $in_searchedField       Name des gesuchten Feldes
     * @return  mixed                           Wenn das Feld gefunden wird, wird der Feldinhalt als String zurückgegeben, ansonsten gibt die Funktion false zurück
     */
    function getValueFromFieldInFieldlist($in_fieldlist, $in_searchedField) {
        foreach ($in_fieldlist as $key => $currentField) {
            if($currentField["feld.spalte"] == $in_searchedField) {
                if(isset($currentField["feld.feldinhalt"])) {
                    return $currentField["feld.feldinhalt"];
                }
            }
        }
        return false;
    }
    
    
    
    
    
    
    
    
    /** Ermittelt aus einer vonAjax übergebenen Liste von Feldern eines Formulardatensatzes den Wert des gesuchten Feldes
     * 
     * @param   array   $in_fieldlist           Standard-Fieldlist, wie sie die Ajax-Methode an Plugin-Funktionen übergibt
     *                                          Bsp.:
     *                                          Array
                                                    (
                                                        [8389] => Array
                                                            (
                                                                [formID] => 1303
                                                                [fieldAppID] => SYS01
                                                                [fieldID] => 8389
                                                                [fieldContent] => BIM01
                                                                [domID] => 0manager0workflow_status0app_id0Form1303_0_i0_hidden
                                                                [ds] => 0
                                                                [instance] => i0
                                                                [name] => APP-ID
                                                                [spalte] => app_id
                                                                [db_schema] => manager
                                                                [db_table] => workflow_status
                                                                [read_only] => 0
                                                                [senderField] => 
                                                            )

                                                        [8393] => Array
                                                            (
                                                                [formID] => 1303
                                                                [fieldAppID] => SYS01
                                                                [fieldID] => 8393
                                                                [fieldContent] => 1
                                                                [domID] => 0manager0workflow_status0workflow_id0Form1303_0_i0_hidden
                                                                [ds] => 0
                                                                [instance] => i0
                                                                [name] => Workflow-ID
                                                                [spalte] => workflow_id
                                                                [db_schema] => manager
                                                                [db_table] => workflow_status
                                                                [read_only] => 0
                                                                [senderField] => 
                                                            )
                                                         )
     * @param   string  $in_searchedField       Name des gesuchten Feldes
     * @return  mixed                           Wenn das Feld gefunden wird, wird der Feldinhalt als String zurückgegeben, ansonsten gibt die Funktion false zurück
     */
    function getValueFromFieldInFieldlistFromAjax($in_fieldlist, $in_searchedField) {
        foreach ($in_fieldlist as $key => $currentField) {
            if($currentField["spalte"] == $in_searchedField) {
                if(isset($currentField["fieldContent"])) {
                    return $currentField["fieldContent"];
                }
            }
        }
        return false;
    }
    
    
    
    
    
    
    /** Ermittelt aus einer übergebenen Object-Liste von Feldern eines Formulardatensatzes den Wert (feldinhalt) des gesuchten Feldes
     * 
     * @param   object      $in_fieldobjectlist     Liste von HTMLField-Objekten
     * @param   string      $in_searchedField       ID des gesuchten Feldes
     * @return  mixed                               Feldinhalt oder false
     */
    function getValueFromFieldInFieldobjectlist($in_fieldobjectlist, $in_searchedField) {
        $myField = $in_fieldobjectlist->getField($in_searchedField);
        if($myField !== false) {
            $myValue = $myField->getProperty("feldinhalt");
            return $myValue;
        }
        return false;
    }
    


    /** Ermittelt aus einem eindimensionalen Array, wie bspw. POST_Objekt->contentData, alle Daten einer bestimmten Tabelle und übergibt diese 
     * in die strings into, values, update und where. 
     * 
     * @param   Array   $in_datensatz_content       Array, enthält aus dem internPostArray, nur den content_teil!)
     * @param   Array   $in_formArray               Array mit allen notwendigen Formular-Daten. Siehe Tabelle form (es muss dem Formular entsprechen, 
     *                                              von welchem die Datensätze stammen.)
     * @param   string  $in_instance_id             Instance_ID des Datensatzes
     * @param   integer $in_datarow                 Zeilennummer des Datensatzes im Formular
     * @param   object  $in_pagedata                Verweis auf das Pagedata-Objekt
     * @return  array                               Enthält die Attribute (schema, table, into, values, update, where, logdata und logdata_id_data)
     */
    function extractDataFromPostarray($in_datensatz_content, &$in_formArray, $in_instance_id, $in_datarow, &$in_pagedata) {

        $schema = $in_formArray['form.db_schema'];
        $table = $in_formArray['form.db_table']; 
        $primarykeys = $in_formArray['form.primarykey'];
        $log_id_spalte = $in_formArray['form.log_id_spalte'];
        $form_id = $in_formArray['form.id'];

        
        $into = "";                             //nimmt Liste aller Spaltennamen auf
        $values = "";                           //nimmt alle Werte auf
        $update = "";                           //nimmt alle Spalten und Werte auf, außer die der Primary-Keys
        $where = "";                            //nimmt alle Primary-Keys-Wertpaare  auf
        $where_insert = "";                     //nimmt alle Primary-Keys-Wertpaare für den Fall eines Inserts auf.
        $logdata = "";                          //nimmt alle Wertpaare auf
        $logdata_id_data = "";                  //nimmt die id, welche die Referenz zur Tabelle logdata bilden wird, auf
        $fields_without_column = "";            //Liste aller fields, für die keine Spalte in feld.spalte angegeben wurde.
    

        foreach ($in_datensatz_content as $key => $value) {
            
            $spalte = getColumnnameFromTableAndColumn($key, false); 
            $connection_id = $in_formArray["form.connection_id"];
            
            //prüfen, ob ein Passwort-Feld vorliegt, wenn ja, wird alter value (password-hash) zurückgegeben.
            $old_password_value = $in_pagedata->isPasswordField($form_id, $in_instance_id, $in_datarow, $spalte);
            if($old_password_value !== false) {
                //Es liegt ein PasswordField vor
                if($old_password_value <> $value) {
                    //Passwortänderung liegt vor -> neuen HashWert bilden
                    $value = password_hash($value, PASSWORD_DEFAULT);        
//                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Paswort: ', "Neuen Hashwert bilden ");
                }
            }
            
            
            if(in_array($table, array(  "feld"
                                        ,"debug"
                                        ,"field_depends"
                                        ,"konstante"
                                        ,"logdata"
                                        ,"query_add_condition"
                                        ,"query_part_join_condition"
                                        ,"query_part_select"
                                        ,"role_access_restriction"
                                        ,"version_script")) == true) {
                //In den aufgelisteten Tabellen können die forbidden_words nicht entfernt werden, da sie entweder zur Datenstruktur oder
                //zu den Inhalten gehören
                $parsedValueAsId = parseSqlValue2($connection_id, $value, __FUNCTION__,false);
            } else {
                $parsedValueAsId = parseSqlValue2($connection_id, $value, __FUNCTION__,true);
            }
            if($parsedValueAsId == "") {$parsedValue = "NULL";} else {$parsedValue = "'".$parsedValueAsId."'";}
                                                                            
            $logdata = $logdata.$spalte."=".$parsedValueAsId.", ";                                 //alle keys und values in logdata aufnehmen (Achtung, hier dürfen die Values nicht von Hochkommata umschlossen sein!
//            echo "Primary-Keys: ".$in_primarykeys." - aktuelle Spalte: ".$spalte."<br />";
            if (strpos($primarykeys, $table.".".$spalte) !== FALSE) {
                //bei Update müssen die Primary-Keys zur identifizierung der betroffenen Datensätze genutzt werden.
            
                //Prüfen, ob für den Primarykey ein Wert aus dem Session_backup verfügbar ist. Das ist notwendig, wenn der Primarykey über die Oberfläche geändert werden soll.
                $valueFromBackup = $in_pagedata->getPostObject()->getValueFromPrimarykeyFieldInSessionArray($table.".".$spalte, $form_id, $in_datarow, $in_instance_id);
                if($valueFromBackup !== false) {
                    $where = $where . "$spalte='" . $valueFromBackup . "' AND "; 
                } else {
                    $where = $where . "$spalte=" . $parsedValue . " AND "; 
                }
                $where_insert = $where_insert . "$spalte=" . $parsedValue . " AND "; 
                
                
                if ($parsedValueAsId == "") {
                     //Wenn für einen PK kein Wert vorliegt, sollte es sich um eine id-Spalte handeln, die per autoincrement automatisch beim insert gefüllt wird.
                }    
                
            } 
            
            $update = $update . "$spalte=$parsedValue, ";                                    //aktuellen Spaltennamen und Inhalt an Update anhängen
            $values = $values . "$parsedValue, ";                                            //aktuellen Inhalt an values anhängen
            $into = $into . "$spalte, ";                                                     //aktuellen Spaltennamen an into anhängen
            if(is_numeric($spalte) == true) {$fields_without_column = $fields_without_column.$spalte;}
            
            
            
            if ($spalte == $log_id_spalte) {
                //Jede beliebige Spalte kann als Referenz zu logdata genutzt werden.
                //ToDo: Zurzeit kann nur zu einer Spalte eine Referenz hinterlegt werden.
                $logdata_id_data = $parsedValueAsId;
            }      //Referenz zur Tabelle logdata


        }

        $where = substr($where, 0, (strlen($where) - 5));                                               //entfernt das letzte überflüssige Trennzeichen wieder
        $where_insert = substr($where_insert, 0, (strlen($where_insert) - 5));                          //entfernt das letzte überflüssige Trennzeichen wieder
        $into = substr($into, 0, (strlen($into) - 2));                                                  //entfernt das letzte überflüssige Trennzeichen wieder
        $values = substr($values, 0, (strlen($values) - 2));                                            //entfernt das letzte überflüssige Trennzeichen wieder
        $update = substr($update, 0, (strlen($update) - 2));                                            //entfernt das letzte überflüssige Trennzeichen wieder
        $logdata = substr($logdata, 0, (strlen($logdata) - 2));                                         //entfernt das letzte überflüssige Trennzeichen wieder

        $feedback = array("into" => $into,
            "values" => $values,
            "update" => $update,
            "schema" => $schema,
            "table" => $table,
            "where" => $where,
            "where_insert" => $where_insert,
            "logdata" => $logdata,
            "logdata_id_data" => $logdata_id_data,
            "fields_without_column" => $fields_without_column);

        return $feedback;
    }

    
    
    /** Prüft, ob in einem Array ein key, welcher den Teilstring  "in_needle" enthält, auf erster Ebene vorhanden ist.
    * 
    * @param    array       $in_array       Verweis auf ein array, dessen keys der ersten Ebene durchsucht werden.  
    * @param    string      $in_needle      String, welcher im key vorhanden sein soll
    * @return   mixed                       gibt den key, in dem $in_needle gefunden wurde, oder false, falls $in_needle nicht gefunden wurde, zurück
    */
   function issetKeyLike(&$in_array, $in_needle) {
       if(is_null($in_needle)) {$in_needle = "";}
       foreach ($in_array as $key => $value) {
           if(stripos($key, $in_needle) !== false) {                            
               return $key;
           }
       }
       return false;
   }
   
   
   
   
   
   
   
   /** Prüft, ob in einem Array ein Columnname, welcher den Teilstring  "in_needle" enthält, auf erster Ebene vorhanden ist.
    * Anders als "issetKeyLike" ist diese funktion nur dazu geeignet "Columnnames" zu suchen. Zu suchen, dass heißt die 
    * array-Keys entsprechen entweder der Syntax "table.column" oder "column".
    * 
    * @param    array       $in_array       Verweis auf ein array, dessen keys der ersten Ebene durchsucht werden.  
    * @param    string      $in_needle      String, welcher im key vorhanden sein soll
    * @return   mixed                       gibt den key, in dem $in_needle gefunden wurde, oder false, falls $in_needle nicht gefunden wurde, zurück
    */
    function issetColumnnameLike(&$in_array, $in_needle) {
        if(is_null($in_needle)) {$in_needle = "";}
        foreach ($in_array as $key => $value) {
            if(stripos($in_needle, ".")) {
                //der gesuchte Spaltenname wurde in dr Syntax "table.column" angegeben
                if(stripos($key, $in_needle) !== false) {                            
                    return $key;
                }
            } else {
                //der gesuchte Spaltenname wurde in dr Syntax "column" angegeben
                if(stripos(getColumnnameFromTableAndColumn($key, false), $in_needle) !== false) {                            
                    return $key;
                }
            }
        }
        return false;
    }
   
   
   
   
   
   /** Prüft, ob in einem Array ein bestimmter Value auf erster Ebene vorhanden ist.
    * 
    * @param    array       $in_array       Verweis auf ein array, dessen values der ersten Ebene durchsucht werden.  
    * @param    string      $in_needle      String, welcher im key vorhanden sein soll
    * @return   mixed                       gibt den key, in dem $in_needle gefunden wurde, oder false, falls $in_needle nicht gefunden wurde, zurück
    */
   function issetValue(&$in_array, $in_needle) {
                    
       foreach ($in_array as $key => $value) {
           if($value == $in_needle) {                            
               return $key;
           }
       }
       return false;
   }
    
   
   
   
   
   /**  Ermittelt in einem String alle Teilstrings, die zwischen $in_startplaceholer 
    * und $in_end_Placeholder eingeschlossen sind und gibt diese als Array zurück.
    * Wenn in $in_string die Platzhalter nur einmal auftreten, liefert die Funktion ein
    * Array mit nur einem Wert.
    * 
    * Bsp.: für $in_string "Hallo {{{{Welt}}}} ich bin {{{{Oskar}}}}!" liefert die Funktion das folgende Array zurück.
    * Array(1 => "Welt", 2 => "Oskar")
    * Dabei gilt: 
    * $in_start_placeholder = "{{{{"
    * $in_end_placeholder = "}}}}"
    * 
    * @param    string  $in_string                  String, welcher durchsucht werden soll
    * @param    string  $in_start_placeholder       Kennzeichen, welches die Startposition eines Platzhalters kennzeichnet (Bsp.: "{{{{")
    * @param    string  $in_end_placeholder         Kennzeichen, welches die Endposition eines Platzhalters kennzeichnet (Bsp.: "}}}}")
    * @return   array                               Bsp.: Array(1 => "Welt", 2 => "Oskar"); Wenn kein Platzhalter gefunden wird, dann wird ein leeres Array zurückgegeben
    */
   function getPlaceholderInStringAsArray($in_string, $in_start_placeholder, $in_end_placeholder) {
       $feedback = array();
       $startposition_for_search = 0;
      
       while (strpos($in_string, $in_start_placeholder, $startposition_for_search) !== false) {
           $startposition_for_search = strpos($in_string, $in_start_placeholder, $startposition_for_search) + 1;
           if(strpos($in_string, $in_end_placeholder, $startposition_for_search) > $startposition_for_search) {
               $endposition_for_search = strpos($in_string, $in_end_placeholder, $startposition_for_search);
               $searchstring = substr($in_string, $startposition_for_search + strlen($in_start_placeholder) -1, $endposition_for_search - ($startposition_for_search + strlen($in_start_placeholder) -1));
               $feedback[] = $searchstring;
           } else {
               addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Schließendes Zeichen für Platzhalter nicht gefunden: ', $in_string);
           }
       }
       
       return $feedback;
       
   }



    /** Extrahiert aus einem Datensatz die Primary-Keys und die Spalten Gültig_ab und Gültig_bis und gibt Sie als neuen Datensatz zurück
     * 
     * @param Array $in_datensatz Eindimensionales Array, welches als Key Schema+Trennzeichen + Tabelle + Trennzeichen + Spalte und als Value den Feldinhalt enthält
     * @param String $in_primary_col Kommaseoparierte Liste der Primary-Keys
     * @param String $in_history_gueltig_ab_col Name der Gültig_ab-Spalte
     * @param String $in_history_gueltig_bis_col Name der Gültig_bis-Spalte
     * @return array 
     * 
     */
    function extractNeededFieldsForHistoryChange($in_datensatz, $in_primary_col, $in_history_gueltig_ab_col, $in_history_gueltig_bis_col) {
        //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> $in_history_primary_col - $in_history_gueltig_ab_col - $in_history_gueltig_bis_col', $in_primary_col . ' - ' . $in_history_gueltig_ab_col . ' - ' . $in_history_gueltig_bis_col);
        $table = $in_datensatz["table"];
        $new_Datensatz = Array();
        foreach ($in_datensatz["content"] as $spalte => $value) {
            if (strpos($in_primary_col, $table.'.'.$spalte) !== FALSE OR $spalte == $in_history_gueltig_ab_col or $spalte == $in_history_gueltig_bis_col) {
                //Wenn die Spalte zu den Primary-Keys oder zur Gültig_ab oder Gültig_bis-Spalte gehrört, wird sie ins neue Array übertragen
                $new_Datensatz[$spalte] = $value;
            }
        }

        return $new_Datensatz;
    }



    
    
    
    
    
    

    /** Ermittelt aus dem PostArray des POST-Objects alle Felder, für die ein Wert vorhanden ist und bildet daraus eine SQL-Bedingung.
     * 
     * @param   string  $in_connection_id           ID der connection, die genutzt werden soll
     * @param   array   $in_postArray               pagedata->getPostArray
     * @param   string  $in_form_app_id             APP-ID des Fromulars
     * @param   String  $rueckgabetyp               Bestimmt, den Typ des Rueckgabewertes (SQL = als SQL-Where-Bedingung, ARRAY = Als Key-Value-Paare in einem Array)
     * @global  String  $db_schema_information      Wird genutzt
     * @return  String                              Where-Bedingung, mit den zu filternden Werten, die in einem SQL-Befehl genutzt werden kann.
     */
    function getFilterCondition($in_connection_id, $in_postArray, $in_form_app_id, $rueckgabetyp = 'SQL') {
        global $db_schema_information;
        $WhereBedingung = "";
        $array_bedingung = array();
        $PostAllRows = $in_postArray["contentData"];
        
       

        //Theoretisch kann das Post-Array die Werte mehrerer Formulare enthalten. Nur die Werte des ersten werden berücksichtigt
        foreach ($PostAllRows as $key => $dataRow) {
            
            $activeSchema = $dataRow["schema"];
            $activeForm = $dataRow["form"];
            foreach ($dataRow["content"] as $spalte => $value) {
                if ($value != "" ) {
                    
                    if(strpos($spalte,".")!== false) {
                        //Wenn der Spaltennamen einen Punkt enthält, dann wird von der Syntax table.column ausgegangen.
                        //das ist insbesondere bei Formularen, die auf Queries basieren sinnvoll, da dort die tabelle pro Spalte variieren kann.
                        $tableAndColumn = explode(".", $spalte);
                        $activeTable = $tableAndColumn[0];
                        $spalte = $tableAndColumn[1];
                        $activeTableWithDot = $activeTable.".";
                    } else {
                        $activeTable = $dataRow["table"];
                        $activeTableWithDot = $activeTable.".";
                    }
                    
                    $spalte_type = getFieldTypeBySpalteFromSessionBackup($activeForm, $in_form_app_id, $spalte);

                    $datentyp = getDataFromTableByID($in_connection_id, $db_schema_information, "columns", "data_type", "table_schema = '$activeSchema' AND table_name = '$activeTable' AND column_name = '$spalte'");            //Datentyp der aktuellen Spalte aus den Schema-Informationen der DB abrufen.
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> build filter_condition: ', "Spalte: ".$spalte.", Datentyp: ".$datentyp.", Spaltentyp: ".$spalte_type.", Form_id: ".$activeForm);
                    if (in_array($spalte_type, array(16,17,18,19,21)) == true) {
                        //Wenn die Bedingung für ein Drop-Down-Feld gelten soll.
                        $sql_bedingung = $activeTableWithDot . $spalte . " = '" . $value . "'";
                    } elseif (strpos($datentyp, 'character') !== false) {
                        $sql_bedingung = "lower(" . $activeTableWithDot . $spalte . ") like lower('%" . $value . "%')";
                    } elseif (strpos($datentyp, 'text') !== false) {
                        $sql_bedingung = "lower(" . $activeTableWithDot . $spalte . ") like lower('%" . $value . "%')";
                    } elseif (strpos($datentyp, 'name') !== false) {
                        $sql_bedingung = "lower(" . $activeTableWithDot . $spalte . ") like lower('%" . $value . "%')";
                    } elseif (strpos($datentyp, 'integer') !== false) {
                        $sql_bedingung = $activeTableWithDot . $spalte . " = " . $value;
                    } elseif (strpos($datentyp, 'date') !== false) {
                        if (validateDate($value)) {
                            $sql_bedingung = $activeTableWithDot . $spalte . " = '" . $value . "'";
                        } else {
                            $sql_bedingung = '';
                            $value = "";
                        }
                    } else {
//                        $sql_bedingung = $activeTableWithDot . $spalte . " = '" . $value . "'";
                        $sql_bedingung = "lower(cast(" . $activeTableWithDot . $spalte . " as text)) like lower('%" . $value . "%')";
                    }

                        //echo "Key: $key , Schema: $activeSchema , Tabelle: $activeTable , Spalte: $spalte , Wert: $value , Datentyp = $datentyp <br />";

                    $WhereBedingung = $WhereBedingung . $sql_bedingung . " AND ";
                    $array_bedingung[$activeTableWithDot . $spalte] = $value;
                }
            }

            break;                                                                  //Abbruch nach der ersten Zeile, da es theoretisch nicht mehr als eine Zeile in einem Filter geben sollte. ToDo: falls mehrfach-Kriterien notwendig werden, wäre hier der richtige Ansatzpunkt
        }

        if ($rueckgabetyp == "SQL") {
            $feedback = substr($WhereBedingung, 0, strlen($WhereBedingung) - 5);        //'AND' am Ende abkürzen
        } else {
            $feedback = $array_bedingung;
        }

        return $feedback;


    }




    /** prüft, ob ein Datum von einem bestimmten Typ ist
     * 
     * @param String $date zu prüfendes Datum
     * @param String $format Datumsformat, welchem das übergebene Datum entsprechen soll
     * @return Boolean
     */
    function validateDate($date, $format = 'Y-m-d') {
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) == $date;
    }
    
    
    
    /** Ermittelt den Wert eines Konfigurationsparameters. 
     * 
     * @global String   $db_schema_manager
     * @param String    $in_parameter       Name des Parameters, dessen Wert ermittelt werden soll (siehe Tabelle Konfiguration)
     * @param Integer   $in_app             APP/Modul, dem der Paramter zugeordnet ist. Der Parameter wird zuerst in dieser APP 
     *                                      gesucht. Wird er dort nicht gefunden, dann wird autom. im Kernmodul (SYS01) gesucht.
     * @return mixed or false               Wert des Konfigurationsparameters oder FALSE, wenn Parameter nicht gefunden wurde
     */
    function getConfig($in_parameter, $in_app) {
        global $db_schema_manager;
        global $db_schema_manager_connection_id;
        global $app_id_from_kernel;
        global $config_param_list;
        
        $feedback = false;
        
        //alle Config-params einmalig aus der DB auslesen.
        if($config_param_list == array()) {$config_param_list = getConfigParamList();}
                
//        $feedback = getDataFromTableByID($db_schema_manager_connection_id, $db_schema_manager, "konfiguration", "wert", "app_id = '$in_app' AND parameter='$in_parameter'");
        
        
        //Suche nach APP-spezifischen Parameter
        foreach ($config_param_list as $current_param) {
            if($current_param["konfiguration.app_id"] == $in_app AND $current_param ["konfiguration.parameter"] == $in_parameter) {
                $feedback = $current_param["konfiguration.wert"];
            }
        }
        
        
        
        if ($feedback === false AND $in_app <> $app_id_from_kernel) {
            //Wenn der Paramter in der angegebenen APP nicht gefunden wurde, dann versuchen den gleichen Parametr aus dem Kernmodul auszulesen.
            //$feedback = getDataFromTableByID($db_schema_manager_connection_id, $db_schema_manager, "konfiguration", "wert", "app_id = '$app_id_from_kernel' AND parameter='$in_parameter'");
            foreach ($config_param_list as $current_param) {
                if($current_param["konfiguration.app_id"] == $app_id_from_kernel AND $current_param ["konfiguration.parameter"] == $in_parameter) {
                    $feedback = $current_param["konfiguration.wert"];
                }
            }
        }
        
        return $feedback;
    }
    


    




    /** Trägt in einer Fieldlist (siehe getFieldList) den Inhalt einer internen Variable in das Feld "Vorgabewert" ein, 
     * wenn ein Feld dies erwartet.
     * Ob ein Feld das erwartet, ergibt sich aus dem Wert in content.intern_variable.
     * 
     * @param   object  $in_pagedata            siehe Klasse pagedata_class
     * @param   integer $in_formID              ID eines Formulars, auf welches sich $in_fieldlist bezieht
     * @param   string  $in_instance_id         Instanz des Formulars
     * @param   array   $in_SESSION             entspricht SESSION
     * @param   array   $in_fieldlist           Array, wie es durch getFieldList erstellt wird
     * @return  array                           wie $in_fieldlist, jedoch enthält "Vorgabewert" nun den Inhalt der Internen Variable
     */
    function replaceInternVariables(&$in_pagedata, $in_formID, $in_instance_id, $in_SESSION, $in_fieldlist) {
        
        $form_array = $in_pagedata->getFormArray($in_formID);
        
        
        for ($i=0; $i<count($in_fieldlist);$i++) {
//            echo $in_fieldlist[$i] ["content.intern_variable"]."<br />";
            if     ($in_fieldlist[$i] ["content.intern_variable"] == "mask.name") {$in_fieldlist[$i] ["feld.vorgabewert"] = $in_pagedata->getMaskArray()["name"];}
            elseif ($in_fieldlist[$i] ["content.intern_variable"] == "session.uid") {$in_fieldlist[$i] ["feld.vorgabewert"] = $in_SESSION["uid"];}
            elseif ($in_fieldlist[$i] ["content.intern_variable"] == "session.role_id") {$in_fieldlist[$i] ["feld.vorgabewert"] = $in_SESSION["active_role"]["role.id"];}
            elseif ($in_fieldlist[$i] ["content.intern_variable"] == "mask.description") {$in_fieldlist[$i] ["feld.vorgabewert"] = $in_pagedata->getMaskArray()["description"];}
            elseif ($in_fieldlist[$i] ["content.intern_variable"] == "ConfigParam.rows_in_form") {
                if($form_array["form.default_limit"] <> "") {
                    $in_fieldlist[$i] ["feld.vorgabewert"] = $form_array["form.default_limit"];
                } else {
                    $in_fieldlist[$i] ["feld.vorgabewert"] = getConfig("rows_in_form",$form_array["form.app_id"]);
                }
            }
            elseif ($in_fieldlist[$i] ["content.intern_variable"] == "form.countData") {$in_fieldlist[$i] ["feld.vorgabewert"] = $in_pagedata->getFormPropertyCountData($in_formID, $in_instance_id);}
            elseif ($in_fieldlist[$i] ["content.intern_variable"] == "form.offset_back" AND ($in_pagedata->getFormPropertyOffsetBack($in_formID, $in_instance_id)<>false)) {$in_fieldlist[$i] ["feld.vorgabewert"] = $in_pagedata->getFormPropertyOffsetBack($in_formID, $in_instance_id);}
            elseif ($in_fieldlist[$i] ["content.intern_variable"] == "form.offset_forward" AND ($in_pagedata->getFormPropertyOffsetForward($in_formID, $in_instance_id)<>false)) {$in_fieldlist[$i] ["feld.vorgabewert"] = $in_pagedata->getFormPropertyOffsetForward($in_formID, $in_instance_id);}
            elseif ($in_fieldlist[$i] ["content.intern_variable"] == "form.current_first_ds" AND ($in_pagedata->getFormPropertyCurrentFirstDS($in_formID, $in_instance_id)<>false)) {$in_fieldlist[$i] ["feld.vorgabewert"] = $in_pagedata->getFormPropertyCurrentFirstDS($in_formID, $in_instance_id);}
            elseif ($in_fieldlist[$i] ["content.intern_variable"] == "form.current_last_ds" AND ($in_pagedata->getFormPropertyCurrentLastDS($in_formID, $in_instance_id)<>false)) {$in_fieldlist[$i] ["feld.vorgabewert"] = $in_pagedata->getFormPropertyCurrentLastDS($in_formID, $in_instance_id);}
        }

        return $in_fieldlist;
    }
    
    
    
    
    /** Wenn in in_field_value eine PluginFunktion enthalten ist, wird deren Ergebniswert zurückgegeben.
     * Ansonsten wird in_field_value unverändert zurückgegeben.
     * 
     * @param   string  $in_field_value     Irgendein String oder ein Aufruf einer Plugin-Funktion; Bsp.: '$$function.SYS01.currentdate'
     * @param   object  $in_pagedata        Referenz zum Pagedata-Object
     * @return  string
     */
    function replacePluginFunction($in_field_value, &$in_pagedata) {
        $feedback = $in_field_value;
        
        if(strpos($feedback,'$$function.')!== false) {
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Funktionsplatzhaber a ", $feedback, "ERROR");
            
            //Alle Funktionsaufrufe innerhalb des Strings ermitteln
            $functionCallList = getPlaceholderInStringAsArray($feedback, "$$", "$$");
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Funktionsplatzhaber b ", $functionCallList, "ERROR");
            if($functionCallList == array()) {
                //schließender Funktionskennzeichner fehlt. Daher wird davon ausgegangen, dass der gesamte String den Funktionsaufruf darstellt.
                $functionCallList[] = str_replace("$", "", $feedback);
            }
            
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Funktionsplatzhaber c ", $functionCallList, "ERROR");
                
            //Alle Funktionsaufrufe innerhalb des Strings separat durchlaufen
            foreach ($functionCallList as $key => $cur_function) {
                $cur_feedback = getValueFromPluginFunction("$$".$cur_function."$$",$in_pagedata);
                if($cur_feedback !== false) {
                    $feedback = str_replace("$$".$cur_function."$$", $cur_feedback, $feedback);
                } 
            }
             
        } 
        
        return $feedback;
    }
    

    
    
    /** Führt eine Plugin-Funktion aus und gibt den Ergebnis wert zurück.
     * 
     * @param   string          $in_function_name   Name der Funktion, kann eingeschlossen sein in Funktionsplatzhalter "$$". <br />
     *                                              Es wird ein Funktionsdeklaration in der Form $$function.[app_id].[functionname].[paramlist] erwartet <br />
     *                                              (Bsp.: $$function.SYS01.now  <br />
     *                                              oder $$function.SYS01.getNextID.WIDER.widerspruch.k_fach.id.100000)
     * @param   object          $in_pagedata        Referenz auf das pagedata-object
     * @return  mixed                               Rückgabewert der Funktion, Leerstring, wenn keine Funktion in der erwarteten Syntax gefunden wurde oder false, im Fehlerfall.
     */
    function getValueFromPluginFunction($in_function_name, &$in_pagedata = false) {
        $feedback = "";
    
        if(strpos($in_function_name,'$$function.')!== false) {
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Wert über Funktion ermitteln! ", $in_function_name, "INFO");
            $function_string_cleared = trim($in_function_name, "$");            //Am Anfang und am Ende des Funktionsplatzhalters können sich $-Zeichen befinden.
            $functionCall = explode(".", $function_string_cleared);    //Es wird ein Funktionsdeklaration in der Form $$function.[app_id].[functionname].[paramlist] erwartet (Bsp.: $$function.SYS01.now  oder $$function.SYS01.getNextID.WIDER.widerspruch.k_fach.id.100000)
            $function_app = $functionCall[1];
            $function_name = $functionCall[2];
            $function_param = array();
            if(count($functionCall) > 3) {
                //Der Funktionsaufruf enthält noch Parameter
//                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> functionCall ", $functionCall, "INFO");
                for ($index = 3; $index < count($functionCall); $index++) {
                    $function_param[] = $functionCall[$index];          //Parameter werden einzeln in ein neues Array übergeben
                }
            }
            if ($in_pagedata !== false) {$function_param[] = $in_pagedata;}
            //PHP-Datei, in der die Funktion definiert ist, laden
            $fieldFunctionFile = "../data/".$function_app."/plugin/functions_fielddefault.php";
            if(file_exists($fieldFunctionFile) == true) {
                require_once($fieldFunctionFile);
//                        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> function_param ", $function_param, "INFO");
                $feedback = call_user_func_array($function_name, $function_param);
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Plugin-Funktion ausführen: Plugin-Datei konnte nicht geladen werden! ", $fieldFunctionFile, "ERROR");
                $feedback = false;
            }
        } else {
        }
        
        return $feedback;
    }
    
    
    
    
    /** Ersetzt in einem String den Wert zwischen den Placeholdern durch einen neuen String.
     * Wenn Placeholder nicht gefunden wurden, wird false zurückgegeben.
     * 
     * @param   string      $in_subject                     Der String, in dem die Platzhalter ersetzt werden sollen
     * @param   string      $in_start_tag_placeholder       String, welcher den Beginn des Platzhalters kennzeichnt (Bsp.: <replace>
     * @param   string      $in_end_tag_placeholder         String, welcher das Ende des Platzhalters kennzeichnet (Bsp.: </replace>
     * @param   string      $in_replace                     String, welcher statt des Platzhalters eingesetzt werden soll.
     * @return  mixed                                       Es wird entweder der neue String oder false zurückgegeben
     */
    function replacePlaceholderInString($in_subject, $in_start_tag_placeholder, $in_end_tag_placeholder, $in_replace) {
        $feedback = false;
        
            
            
        if (strpos($in_subject, $in_start_tag_placeholder) > 0) {
            $startposition_placeholder = strpos($in_subject, $in_start_tag_placeholder) + 1;
            if(strpos($in_subject, $in_end_tag_placeholder) > $startposition_placeholder) {
                $endposition_placeholder = strpos($in_subject, $in_end_tag_placeholder);
                $searchstring = substr($in_subject, $startposition_placeholder + strlen($in_start_tag_placeholder) -1, $endposition_placeholder - ($startposition_placeholder + strlen($in_start_tag_placeholder) -1));
                //Text der Platzhalter ersetzen
                $feedback = str_replace($searchstring, $in_replace, $in_subject);
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Schließendes Zeichen für Platzhalter nicht gefunden: ', $in_subject);
            }
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Öffnendes Zeichen für Platzhalter nicht gefunden: ', $in_subject);
        }
        

        return $feedback;
    }
    
    
    
    /** Ermittelt aus der SESSION-Variable das array mit der angegeben role_id
     * 
     * @param   array   $in_SESSION     Referenz auf SESSION
     * @param   integer $in_role_id     ID der gesuchten Rolle
     * @return  mixed                   Entweder array mit den Angaben zur Rolle oder false
     */
    function getRoleFromSession(&$in_SESSION, $in_role_id) {
        foreach ($in_SESSION["rollen"] as $key => $currentRole) {
            if($currentRole["role.id"] == $in_role_id) {
                return $currentRole;
            }
        }
        
        return false;
    }
    


    /** Ermittelt für eine Feld-ID die SQL-Bedingung in Abhängigkeit von den Inhalten der Felder des gleichen Formulars, von denen das Feld abhängt.
     * 
     * @param   object   $in_Field              Feldobjekt (siehe class HtmlField), für das die Bedingung aus der Fieldlist ermittelt werden soll.
     * @param   array    $in_FieldObjectlist    Array, welches alle Felder (als Objekte) des aktuellen Formulars enthält.
     * @param   string   $in_feedback_type      Rückgabetyp: SQL->es wird ein SQL-String zurückgegeben; ARRAY->es werden die Bedingungen in einem Array zurückgegeben
     * @return  mixed                           SQL -> String, welcher die SQL-Where-Klausel enthält (Bsp.: form.app_id = 'SYS01' AND table2.spalte2 = '1')
     *                                          ARRAY -> (Bsp.: array{[0] -> array{[sourcetable] ->form,[sourcecolumn] ->app_id,[targettable] ->app;[targetcolumn] ->id;[value] ->'SYS01'}; [1] -> array{[table] ->table2,[column] ->spalte2,[targetcolumn] => table3, [targetcolumn] => column3,[value] ->'1'}}
     */
    function getDependsconditionForField(&$in_Field, &$in_FieldObjectlist, $in_feedback_type) {
        //Das aktuelle Feld enthält ggf. eine Liste von Feldern, von denen es abhängt. Die Schleife durchläuft diese Liste
        $conditionSQL = "";
        $conditionArray = array();
        

        if(is_array($in_Field->depends_from_field)) {
            foreach ($in_Field->depends_from_field as $key => $value) {
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> depends from Field: ', $value);
                //Feldobjekt für die aktuelle Feldid (value) aus dem array depends_from_Field ermitteln
                $dependsFromFieldId = $value;
                //an gleicher Position (key) im array dependsfield_target befindet sich das Feld, welches die potenziel zulässigen Werte für in_Field.value festlegt
                $conditionField = $in_Field->dependsfield_target[$key];
                
                if($conditionSQL!="") {$conditionSQL=$conditionSQL." AND ";}
                $baseField = $in_FieldObjectlist->getField($dependsFromFieldId);
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> depends from Field (Object): ', $baseField);
                $newCondition = $in_Field->ref_table.".".$in_Field->ref_id_field.
                                " in (SELECT ".$baseField->tabelle.".".$in_Field->spalte.
                                " FROM ".$baseField->schema.".".$baseField->tabelle.
                                " WHERE ".$conditionField."='".$baseField->feldinhalt."')";
                //$condition = $condition.$conditionField."='".$baseField->feldinhalt."'";              //funktioniert nur, wenn referenzierte Tabelle gleich der aktuellen Tabelle ist
                $conditionSQL = $conditionSQL.$newCondition;
                $targetfield = explode( ".", $in_Field->dependsfield_target[$key]);
                $conditionArray[] = array("sourcetable" => $baseField->tabelle, "sourcecolumn" => $baseField->spalte, "targettable" => $targetfield[0] , "targetcolumn" => $targetfield[1] , "value" => $baseField->feldinhalt);
            }
        }
        
        if($in_feedback_type == "SQL") {
            return $conditionSQL;
        } else {
            return $conditionArray;
        }
    }
    
    
    
    
    
    /** Überträgt die Werte von $in_fieldAddInfos in $in_fieldlist, wenn in beiden die selbe feld_id existiert.
     * 
     * @param array     $in_fieldlist           Zweidiemsionale Feldliste, wie sie getFieldList ermittelt
     * @param array     $in_fieldAddInfos       eindimensionales Feld, in dem zu den Feld_ids (keys) Zusatzinformationen (values) abgelegt sind.
     * @param string    $in_target_column_name  Name des Keys(Spalte), in der in In_fieldlist die Werte ergänzt werden sollen.
     * @return array                            Gibt die fieldlist ergänzt um die Spalte $in_target_column_name zurück. Die Spalte enthält die Werte von $in_fieldAddInfos
     */
    function mergeListToFieldlist($in_fieldlist, $in_fieldAddInfos, $in_target_column_name) {    
        foreach ($in_fieldlist as $key => $row) {
            //Die Liste der Felddatensätze einzeln durchlaufen
            if(array_key_exists($row["feld.id"], $in_fieldAddInfos)) {
                //Wenn in $in_fieldAddInfos die aktuelle Feld.id als key existiert, dann deren Values in $in_fieldlist übertragen
                $in_fieldlist[$key][$in_target_column_name] = $in_fieldAddInfos[$row["feld.id"]];
            } else {
                $in_fieldlist[$key][$in_target_column_name] = "";
            }
        }
        
        return $in_fieldlist;
    }
    
    
    
    
    /** überträgt die Werte von $in_targetformList in $in_fieldlist in die Spalte $in_target_column_name. 
     * Mehrere targetForms, die sich auf das gleiche Feld beziehen, werden als Kommaseparierte Liste übertragen
     * 
     * @param   array   $in_fieldlist           Zweidiemsionale Feldliste, wie sie getFieldList ermittelt
     * @param   array   $in_targetformList      zweidimensionale Liste, wie sie getTargetForms ermittelt
     * @param   string  $in_target_column_name  Name des Keys(Spalte), in der in In_fieldlist die Werte ergänzt werden sollen.
     * @return  array                           Gibt die fieldlist ergänzt um die Spalte $in_target_column_name zurück. Die Spalte enthält die Werte von $in_targetformList
     */
    function mergeTargetformsToFieldlist($in_fieldlist, $in_targetformList, $in_target_column_name) {    
        
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> BaseFieldArray: ', $in_fieldlist);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> TargetFormList: ', $in_targetformList);
        
//        if(count($in_targetformList) > 0) {
            foreach ($in_fieldlist as $key_fieldlist => $current_field) {
                //die Feldliste zeilenweise durchlaufen
                $temp_formlist_string = "";
                $current_field_id = $current_field["feld.id"];
                $current_field_function_app = $current_field["feld.button_action_function_app_id"];
                $current_field_function = $current_field["feld.button_action_function_id"];
                foreach ($in_targetformList as $key_targetformlist => $current_targetform) {
                    if( $current_field_id           == $current_targetform["form_dependence.feld_id"] AND
                        $current_field_function_app == $current_targetform["form_dependence.button_action_function_app_id"] AND
                        $current_field_function     == $current_targetform["form_dependence.button_action_function_id"]) {
                        if($temp_formlist_string == "") {
                            $temp_formlist_string = $current_targetform["form_dependence.target_form_id"];
                        } else {
                            $temp_formlist_string = $temp_formlist_string.",".$current_targetform["form_dependence.target_form_id"];
                        }
                    }
                }
                $in_fieldlist[$key_fieldlist][$in_target_column_name] = $temp_formlist_string;
            }
//        }
        
        return $in_fieldlist;
    }
    
    
    
    
    
    
    
    /** Wandelt ein Multiarray in ein Singlearray um.
     * 
     * Bsp.: 
     * multiArray 
     * Array
        (
            [0] => array([key_column] => 396, [value_column] => 2203),
            [1] => array([key_column] => 411, [value_column] => 412),
            [2] => array([key_column] => 411, [value_column] => 89),
            [3] => array([key_column] => 608, [value_column] => 599)
        )
     * wird gewandelt in singleArray
     * Array
        (
            [396] => 2203, [411] => 412, 89, [608] => 599, [1284] => 1269, 1255, 1260
        )
     * 
     * @param   array       $in_multiarray      Array, welches umgewandelt werden soll
     * @param   string      $in_key_column      Name des keys im multiarray
     * @param   string      $in_value_column    name der value_spalte im multiarray
     * @param   string      $in_data_type       [optional] wenn "string", dann werden die Werte in der Value_spalte in einfachen Hochkommata gesetzt (Bsp.: Array([396] => '2203', [411] => '412', '89', [608] => '599', [1284] => '1269', '1255', '1260')
     * @return  array                           Wie oben dargestellt.
     */
    function changeMultiArrayToSingleArray($in_multiarray, $in_key_column, $in_value_column, $in_data_type = "integer") {
        if($in_data_type == "string") {$add = "'";} else {$add = "";}
        $last_field_id = "";
        $field_list = array();
            
        foreach ($in_multiarray as $resultRow) {
            $current_field_id = $resultRow[$in_key_column];
            if($current_field_id <> $last_field_id) {
                //Wenn ein neues Feld vorliegt.
                if($last_field_id <> "") {
                    //letztes Feld  in field_list schreiben
                    $field_list[$last_field_id] = $triggerFields;
                }

                //Triggerfields für aktuelles Feld sammeln
                $vorlauf = "";
                $triggerFields = $add.$resultRow[$in_value_column].$add;
                $last_field_id = $current_field_id;
            } else {
                //Wenn auch dieser Datensatz zum vorherigen Index gehört
                $vorlauf = ",";
                $triggerFields = $triggerFields.$vorlauf.$add.$resultRow[$in_value_column].$add;
            }

        }


        //allerletztes Feld in fieldlist schreiben
        if(count($in_multiarray) > 0) {
            $field_list[$current_field_id] = $triggerFields;
        }
        
        return $field_list;
    }
    
    
    
    /** Wandelt ein Multiarray in ein String um. In den String werden kommasepariert die Werte eines Values übertragen
     * 
     * Bsp.: 
     * multiArray 
     * Array
        (
            [0] => array([key_column] => ID, [value_column] => 2203),
            [1] => array([key_column] => ID, [value_column] => 412),
            [2] => array([key_column] => ID, [value_column] => 89),
        )
     * wird gewandelt in String
     * wird string = "'2203', '412', '89'"
     * 
     * @param   array       $in_multiarray      Array, welches umgewandelt werden soll
     * @param   string      $in_column          Name der Spalte im multiarray, deren Werte im String zusammengefasst werden sollen
     * @param   string      $in_type            [optional] wenn "string", dann werden die Werte in der Value_spalte in einfachen Hochkommata gesetzt (Bsp.: Array('412', '89')
     * @param   string      $in_separator       [optional] Trennzeichen, default = ","
     * @return  string                          Wie oben dargestellt.
     */
    function changeMultiArrayToString($in_multiarray, $in_column, $in_type = 'string', $in_separator = ",") {
        $feedback = "";
        
        if($in_type == "string") {$add = "'";} else {$add = "";}
        
        
        $separator = "";
        foreach ($in_multiarray as $key => $row) {
            $feedback = $feedback.$separator.$add.$row[$in_column].$add;
            $separator = $in_separator;
        }
        return $feedback;
    }
    
    
    /**
     * 
     * @param   String    $in_rowFieldList      ein String, indem durch "_____" separiert Informationen über alle Felder <br />
     *                                          einer Zeile eines Formulars inkl. der aktuellen Inhalte enthalten sind. <br />
     *                                          Die Datenzeile wird per Ajax zur Laufzeit an den Server gesendet. <br />
     *                                          Der formale Aufbau wird über appms.js->getDataFromCurrentRow festgelegt.
     * @return  Array                           Array(formID, fieldAppID, fieldID, fieldContent, fieldID)
     */
    function changeFieldlistAsStringToFieldListAsArray($in_rowFieldList) {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> in_rowFieldList: ', $in_rowFieldList);
        
        $fieldList = explode(global_variables::getdelimiterFields(), $in_rowFieldList);         
        $myFields = array();
        foreach ($fieldList as $key => $currentField) {
            //Die Attribute eines Feldes werden durch "|||" separiert übergeben
            $currentFieldAttributs = explode(global_variables::getDelimiterFieldAttribut(), $currentField);
            $myFieldArray = array();
            $myFieldArray["formID"] = $currentFieldAttributs[0];
            $myFieldArray["fieldAppID"] = $currentFieldAttributs[1];
            $myFieldArray["fieldID"] = $currentFieldAttributs[2];
            $myFieldArray["fieldContent"] = $currentFieldAttributs[3];
            $myFieldArray["domID"] = $currentFieldAttributs[4];
            if($myFieldArray["formID"] != "null") {                     //das Markierungsfeld wird mit dieser Bedingung aussortiert.
                $myFieldArray["ds"] = getInstanceOrDSFromDomID($myFieldArray["domID"], "ds");
                $myFieldArray["instance"] = getInstanceOrDSFromDomID($myFieldArray["domID"], "instance");
                $myFields[$myFieldArray["fieldID"]] = $myFieldArray; 
            }
        }
        
        return $myFields;
    }
    
    
   
      
    
    
    /** Die Funktion ermittelt aus der DomID den Datensatz und die Instanz-ID
     * 
     * @param   stding      $in_dom_id      DomID eines Feldes. Bsp.: 0fin0k_proj_syf0id0Form1110_0_i0new
     * @param   string      $in_needle      gewünschter Rückgabewert. [ds|instance]
     * @return  string
     */
    function getInstanceOrDSFromDomID($in_dom_id, $in_needle) {
        //DomID ab dem String "Form" auftrennen
        $posForm = strripos($in_dom_id, "Form");
        $form_ds_instance = substr($in_dom_id, $posForm);
        $form_ds_instance_array = explode("_", $form_ds_instance);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> form_ds_instance_array: ', $form_ds_instance_array);
        if($in_needle == "ds") {
            return $form_ds_instance_array[1];      //Rückgabe = ds (Datensatz)
        } else {
            return $form_ds_instance_array[2];      //Rückgabe = instance
        }
        
        
        //
    }
    
    
    
    /** Ermittelt dynamisch, wenn der Nutzer in der Oberfläche Werte eingegeben hat, beim verlassen des Feldes (Triggerfeld), die 
     * Eingabeoptionen für Depending-Fields. Dabei kann ein DependingField mehrere TriggerFields haben (siehe DB-Tabelle field_depends
     * 
     * @param   integer     $in_form_id                 ID des Formulars
     * @param   string      $in_targetfield_app_id      APP_ID des Targetfields
     * @param   integer     $in_targetfield_id          ID des Targetfields
     * @param   string      $in_trigger_rowFieldList    String, in dem alle Felder einer Zeile, in der sich auch das TriggerField befindet, mit deen values enthalten sind.
     *                                                  Bsp. für syntaktischen Aufnau: siehe return von appms.js->getDataFromCurrentRow
     * @return  array                                   Zweidimensionales Array, pro Condition wird ein internes Array übergeben
     *                                                  ARRAY -> (Bsp.: array{[0] -> array{[sourcetable] ->form,[sourcecolumn] ->app_id,[targettable] ->app;[targetcolumn] ->id;[value] ->'SYS01'}; [1] -> array{[table] ->table2,[column] ->spalte2,[targetcolumn] => table3, [targetcolumn] => column3,[value] ->'1'}}
     */
    function getDependsconditionDynamicForField($in_form_id, $in_targetfield_app_id, $in_targetfield_id, $in_trigger_rowFieldList) {
        $conditionArray = array();
        $is_fieldDepensCondition = true;        //Gibt an, ob die targetfield-Condition aus field_depends oder aus feld.query_ref_field_connection_id stammt
      
        
        //$targetFieldArray aus der Session ermitteln
        $targetFieldArray = getFieldArrayFromSessionBackup($in_form_id, $in_targetfield_app_id, $in_targetfield_id);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> targetFieldArray: ', $targetFieldArray);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Eingangsparameter: ', "Form_id: ".$in_form_id." | targetfield_app_id: ".$in_targetfield_app_id." | in_targetfield_id: ".$in_targetfield_id);
      
        //1. $in_trigger_rowFieldList in Array umwandeln mit allen Feldern der Zeile
        $myTriggerRow = changeFieldlistAsStringToFieldListAsArray($in_trigger_rowFieldList);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> TriggerRow: ', $myTriggerRow);
        
        //aus dem TargetField den dependsfield_target-String ermitteln, also alle Felder, von denen das targetField abhängt.
        $dependsfield_target = $targetFieldArray["feld.dependsfield_target"];   
        $triggerFieldId_target = $targetFieldArray["feld.depends_from_field"];
                
        //$dependsfield_target kann eine Liste von Spalten in einem String enthalten. Bsp.: "query_part_from.query_id,query_part_from.query_app_id,query_part_from.id"
        $dependsFieldArray = explode(",", $dependsfield_target);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> DependsFields: ',$dependsFieldArray);
        //$triggerFieldId_target enthält die ID's der Felder, von denen ein Target-Field abhängt. 
        $triggerFieldIdArray = explode(",", $triggerFieldId_target);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> TriggerFieldsArray: ',$triggerFieldIdArray);
        if($triggerFieldId_target == "") {$is_fieldDepensCondition = false;} else {$is_fieldDepensCondition = true;}
        
        //2. Schleife über dependsfield_target; dabei über .depends_from_field das zugehörige Triggerfeld zuordnen
        if($is_fieldDepensCondition == true) {
            //$triggerFieldIdArray kann leer sein, wenn die Feldabhängigkeit nicht über die Tabelle field_depends, sondern über die Spalte feld.query_ref_field_connection_id ausgelöst wurde.
            foreach ($dependsFieldArray as $key => $currentDependsField) {
                //unter Umständen kann ein Array mit Key 0, aberohne weitere Daten übergeben werden. Dieses muss ausgefiltert werden, da per
                //Ajax ansonsten ein PHP-Fehler an JS zurückgegeben wird, wenn der Debug-Modus aus ist.
                //if($key != 0) {
                    //die zugehörige ID des TriggerFields zu currentDependsField befindet sich in $triggerFieldId_target an gleicher Position
                    $currentTriggerFieldId = $triggerFieldIdArray[$key];
                    $currentTriggerFieldArray = $myTriggerRow[$currentTriggerFieldId];
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> TriggerFields: ',"Suche TriggerFieldID ".$currentTriggerFieldId);
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> TriggerFields: ',$myTriggerRow);
        //            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Triggerconditions: ', "currentTriggerFieldID: ".$currentTriggerFieldId." TriggerFieldContent: ".$currentTriggerFieldArray["fieldContent"]." currentDependsField: ".$currentDependsField);

                    //jedes DependsFiled besteht aus der Angabe DB-Tabelle und DB-Spalte. Diese Angaben werden durch einen Punkt separiert
                    $refTableAndColumn = explode(".",$currentDependsField);             //enthält Referenz auf table und column, welche die mögliche Werte für targetField vorgeben

                    //$baseFieldArray aus der Session ermitteln        
                    $baseFieldArray = getFieldArrayFromSessionBackup($currentTriggerFieldArray["formID"], $currentTriggerFieldArray["fieldAppID"], $currentTriggerFieldArray["fieldID"]);
        //            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> BaseFieldArray: ', $baseFieldArray);

                    //3. [Depends]$conditionArray für jedes dependsfield_target erstellen
                    $conditionArray[] = array(  "sourcetable" => $baseFieldArray["form.db_table"] ,  
                                                "sourcecolumn" => $baseFieldArray["feld.spalte"] , 
                                                "targettable" => $refTableAndColumn[0], 
                                                "targetcolumn" => $refTableAndColumn[1], 
                                                "value" => $currentTriggerFieldArray["fieldContent"]);
                //}

            }
        }
        
        return $conditionArray;
        
    }

    
    /** Ermittelt aus SESSION["forms_backup"][$in_form_id]["form.default_fields"] das default_field_array 
     * für die übergebene field_id. Die Vorgabewerte sind für alle Datensätze gültig.
     * 
     * @param   integer     $in_form_id         id der Form
     * @param   string      $in_field_app_id    app_id der Form
     * @param   integer     $in_field_id        ID des Feldes, dessn Array aus der SESSION-Variable ermittelt werden soll.
     * @return  mixed                           Wert eines bestimmten Feldattributes. Wenn das Feld nicht existiert, wird false zurückgegeben.
     */
    function getFieldArrayFromSessionBackup($in_form_id, $in_field_app_id, $in_field_id) {
        if(isset($_SESSION["forms_backup"][$in_form_id]["form.default_fields"])) {
            $fieldlist = $_SESSION["forms_backup"][$in_form_id]["form.default_fields"];
            foreach ($fieldlist as $key => $field) {
                if($field["feld.app_id"] == $in_field_app_id AND $field["feld.id"] == $in_field_id) {
                    return $field;
                }
            }
        }
        
        return false;
    }
    
    

    
    
    
    
    /** Ermittelt aus $in_session["forms_backup"][$in_form_id]["form.default_fields"] die Attribute "feld.name"  und "feld.id" 
     * des Feldes, welches in "feld.spalte" den übergebenen Wert $in_spalteName enthält.
     * 
     * @param   integer     $in_form_id         id der Form
     * @param   string      $in_field_app_id    app_id der Form
     * @param   integer     $in_spalteName      Wert des Attributs "feld.spalte"
     * @param   array       $in_session         Referenz zum SESSION-Array
     * @return  mixed                           Array mit "name" und "id" des gesuchten Feldes. Wenn das Feld nicht gefunden werden konnte, wird false zurückgegeben.
     */
    function getFieldNameAndIdBySpalteFromSessionBackup($in_form_id, $in_field_app_id, $in_spalteName, &$in_session) {
        
        if(isset($in_session["forms_backup"][$in_form_id]["form.default_fields"])) {
            if($in_session["forms_backup"][$in_form_id]["form.db_table"]!=""){
                $table = $in_session["forms_backup"][$in_form_id]["form.db_table"].".";
            }else {
                $table= "";
            }
            
            $fieldlist = $in_session["forms_backup"][$in_form_id]["form.default_fields"];
            foreach ($fieldlist as $key => $field) {
                if(strpos($field["feld.spalte"],".")!==false) {
                    $searchField = $field["feld.spalte"];
                } else {
                    $searchField = $table.$field["feld.spalte"];
                }
                if($field["feld.app_id"] == $in_field_app_id AND $searchField == $in_spalteName) {
                    $feedback = array("field.id" => $field["feld.id"], "field.name" => $field["feld.name"]);
                    return $feedback;
                }
            }
        }
        
        return false;
    }
    
    
    
    
    
    
    
    
    
    
    /** Ermittelt aus SESSION["forms_backup"][$in_form_id]["form.default_fields"] das Attribut "feld.konstante_id" des Feldes, welches
     * in "feld.spalte" den übergebenen Wert $in_spalteName enthält.
     * 
     * @param   integer     $in_form_id         id der Form
     * @param   string      $in_field_app_id    app_id der Form
     * @param   integer     $in_spalteName      Name der Spalte, dessen Feldtyp ("feld.konstante_id") ermittelt werden soll
     * @return  mixed                           "feld.konstante_id" des gesuchten Feldes. Wenn das Feld nicht gefunden werden konnte, wird false zurückgegeben.
     */
    function getFieldTypeBySpalteFromSessionBackup($in_form_id, $in_field_app_id, $in_spalteName) {
        if(isset($_SESSION["forms_backup"][$in_form_id]["form.default_fields"])) {
            $fieldlist = $_SESSION["forms_backup"][$in_form_id]["form.default_fields"];
            foreach ($fieldlist as $key => $field) {
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> vergleiche Felder" , "fieldspalte = ".$field["feld.spalte"]." vs. insertData = ".$in_spalteName);
        
                //Searchcolumn festlegen, je nachdem, ob mit oder ohne Tabellennamen gesucht werden muss.
                If (strpos($field["feld.spalte"], ".") !== false ) {
                    //$field["feld.spalte"] enthält einen Punkt und somit auch den Tabellennamen
                    $searchColumn = $in_spalteName;
                } else {
                    $searchColumn = getColumnnameFromTableAndColumn($in_spalteName, false);
                }
                
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> vergleiche bereinigte Felder" , "fieldspalte = ".$field["feld.spalte"]." vs. insertData = ".$searchColumn);
        
                
                if($field["feld.app_id"] == $in_field_app_id AND $field["feld.spalte"] == $searchColumn) {
                    return $field["feld.konstante_id"];
                }
            }
        }
        
        return false;
    }
    
    
    
    
    /** Ermittelt aus SESSION["forms_backup"][$in_form_id]["form.default_fields"] das Attribut "feld.spalte" des Feldes, welches
     * in "feld.id" den übergebenen Wert $in_spalteName enthält.
     * 
     * @param   integer     $in_form_id         id der Form
     * @param   string      $in_field_app_id    app_id der Form
     * @param   integer     $in_field_id        ID des Feldes, Attribut (Feld.spalte) ermittelt werden soll
     * @return  mixed                           "feld.spalte" des gesuchten Feldes. Wenn das Feld nicht gefunden werden konnte, wird false zurückgegeben.
     */
    function getFieldColumnByIdFromSessionBackup($in_form_id, $in_field_app_id, $in_field_id) {
        if(isset($_SESSION["forms_backup"][$in_form_id]["form.default_fields"])) {
            $fieldlist = $_SESSION["forms_backup"][$in_form_id]["form.default_fields"];
            foreach ($fieldlist as $key => $field) {
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." -> vergleiche Felder" , "fieldspalte = ".$field["feld.spalte"]." vs. insertData = ".$in_spalteName);
                
                if($field["feld.app_id"] == $in_field_app_id AND $field["feld.id"] == $in_field_id) {
                    return $field["feld.spalte"];
                }
            }
        }
        
        return false;
    }
    
    
    
    /** Ermittelt aus SESSION["forms_backup"][$in_form_id]["form.default_fields"] über das Attribut "feld.konstante_id" des Feldes, 
     * ob es sich um ein hidden-field handelt.
     * 
     * @param   integer     $in_form_id         id der Form
     * @param   string      $in_field_app_id    app_id der Form
     * @param   integer     $in_fieldName       Name des Feldes
     * @return  boolean                         true, wenn es ein hidden-Field ist, ansonsten false (auch wenn das Feld nicht gefunden wurde)
     */
    function isHiddenField($in_form_id, $in_field_app_id, $in_fieldName) {
        if(isset($_SESSION["forms_backup"][$in_form_id]["form.default_fields"])) {
            $fieldlist = $_SESSION["forms_backup"][$in_form_id]["form.default_fields"];
            foreach ($fieldlist as $key => $field) {
                if( $field["feld.app_id"] == $in_field_app_id 
                    AND $field["feld.name"] == $in_fieldName
                    AND $field["feld.konstante_id"] == 8) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    
    
    /** Ermittelt aus SESSION["forms_backup"] das formArray für die übergebene form_id
     * 
     * @param   integer     $in_form_id     ID des Formulars
     * @return  mixed                       FormArray oder false, falls Formular nicht vorhanden ist
     */
    function getFormArrayFromSessionBackup($in_form_id) {
        if(isset($_SESSION["forms_backup"][$in_form_id])) {
            return $_SESSION["forms_backup"][$in_form_id];
        }
        return false;
    }
    
    
    

    /** Ermittelt einen SQL-Condition-String und ein Array mit den Conditions. 
     * Der SQL-String kann genutzt werden, um die Daten des eingebetteten (Childformulars) in Abhängigkeit vonm aktuellen Datensatz des Parentformulars, einzuschränken.
     * Das Array kann genutzt werden, um im eingebetteten Formular Feldvorbelegungen vorzunehmen. D.h. in einem leeren Datensatz die PK's vorbelegen.
     * 
     * @param   object              $in_Fieldlist           Objektbaum (HtmlTree) der Feldobjekte der Parentform
     * @param   array               $in_fieldReferences     Liste der Feldreferenzen zwischen Parent- und Childform (siehe getNestedFormFields)
     * @return  array                                       array["SQL"] enthält den SQL-String, der in einer  Where-Bedingung eingefügt werden kann;
     *                                                      array["Array"] enthält die Vorbelegungswerte, wobei key = spaltenname und $value = Spaltenwert enthalten.
     *                                                          Bsp.:   array["SQL"]="bew_antrag_id='3' AND bew_antrag_bew_id='48959'"
     *                                                                  array["Array"] = array("bew_antrag_id" => 3, "bew_antrag_bew_id" => 48959)
     */
    function getConditionForNestedForms(&$in_Fieldlist, $in_fieldReferences) {
        $conditionSQL = "";
        $conditionArray = array();
        $feedback = array();

        if(is_array($in_fieldReferences)) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> nestedForms, fieldReferences: ', $in_fieldReferences);
            foreach ($in_fieldReferences as $key => $value) {
                //aktuelle Feldreferenz ermitteln
                $currentFieldReference = $value;
                $sourceFieldId=$currentFieldReference["form_nesting_fieldreference.source_field_id"];
                //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> currentFieldRference: ', $currentFieldReference);
                $sourceFieldObject = $in_Fieldlist->getField($sourceFieldId);
                if(isset($sourceFieldObject->feldinhalt)) {$sourceFieldValue = $sourceFieldObject->feldinhalt;} else {$sourceFieldValue="";}
                $targetFieldDBspalte = $currentFieldReference["target_field.target_field_spalte"];
                //$targetFieldDBTable = $currentFieldReference["form.target_form_table"];

                if($conditionSQL!="") {$conditionSQL=$conditionSQL." AND ";}
                $conditionSQL = $conditionSQL.$targetFieldDBspalte."='".$sourceFieldValue."'";
                $conditionArray[$targetFieldDBspalte] = $sourceFieldValue;      //kann zur Vorbelegung von newForms genutzt werden
                $conditionArray["queryBase"][] = array( "sourcetable" => $currentFieldReference["source_form.source_form_table"],
                                                        "sourcecolumn" => $currentFieldReference["source_field.source_field_spalte"],
                                                        "targettable" => $currentFieldReference["target_form.target_form_table"],
                                                        "targetcolumn" => $targetFieldDBspalte,
                                                        "value" => $sourceFieldValue);
            }
        }

        $feedback["SQL"]=$conditionSQL;
        $feedback["Array"]=$conditionArray;
        return $feedback;
    }
    
    
   
    
    



    /** deprecated: Ablösen, da ein Button theoretisch auf mehrere Formen wirken können sollte.
     * 
     * @param   array   $in_array       beliebiges Array
     * @return  various                 Typ des ersten Values
     */
    function getFirstValueFromArray($in_array) {

        $firstValue = "";
        //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> array: ', $in_array);
        if(is_array($in_array)) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> array: ', $in_array);
            foreach ($in_array as $key => $value) {
                //ertsen Wert auslesen
                $firstValue = $value;
                return $firstValue;
            }
        }

        return $firstValue;
    }






    
    
    
    /**
     * Wandelt ein Zweidimensionales Array, bestehend aus key und einem Value in einen String um. Dabei gehen die 
     * keys verloren, während die values getrennt durch jeweils einen Seperator in einen String geschrieben werden.
     * 
     * Bsp.:    Aus array(0 => "324", 1 => "516", 2 => "28") 
     *          wird string = '324', '516', '28'
     * 
     * @param   array   $in_array       Zweidimensionales Array.
     * @param   string  $in_type        [optional] Gibt an, ob die Werte in einfache Hochkommata gesetzt werden sollen. Mögliche Werte: string|integer. (default = string)
     *                                  string -> '324', '516', '28'
     *                                  integer-> 324, 516, 28
     * @param   string  $in_separator   [optional] Trennzeichen, welches zwischen den Werten verwendet werden soll (default: ", ")
     * @return  string                  Zeichenlkette mit den Value-Werten des Array
     */
    function arrayToString($in_array, $in_type="string", $in_separator=", ") {
        $feedback = "";
        
        if($in_type == "string") {$add = "'";} else {$add = "";}
        
        for ($i = 0; $i <= count($in_array)-1; $i++) {
            if($i == (count($in_array))-1) {$in_separator = "";}                    //nach dem letzten Element soll kein Trennzeichen mehr eingefügt werden, daher wird es gelöscht
            $feedback = $feedback.$add.$in_array[$i].$add.$in_separator;
        }
        
        return $feedback;
    }
    
    
    /** Ergänzt in einem zweidimensionalen Array in zweiter Ebene
     * in jedem Datensatz den Wert von $in_const als value unter dem
     * key ($in_new_key). D.h., aus <br />
     * Array( <br />
        [0] => Array(	<br />
                [table_name.column1] => Bernd	<br />
                [table_name.column2] => Schmid	<br />
                [table_name.column3] => Herr)	<br />
        [1] => Array(	<br />
                [table_name.column1] => Klara	<br />
                [table_name.column2] => Augustin	<br />
                [table_name.column3] => Frau))	<br /><br />
     * wird, mit $in_new_array = "table_name.column3" und $in_const = "Mensch": <br />
     * Array( <br /><br />
        [0] => Array(	<br />
                [table_name.column1] => Bernd	<br />
                [table_name.column2] => Schmid	<br />
                [table_name.column3] => Herr)	<br />
                [table_name.column4] => Mensch)	<br />
        [1] => Array(	<br />
                [table_name.column1] => Klara	<br />
                [table_name.column2] => Augustin	<br />
                [table_name.column3] => Frau)	<br />
                [table_name.column4] => Mensch))	<br /><br />
     * @param   array   $in_array       Zweidimensionales Array (siehe oben)
     * @param   string  $in_new_key     neuer Key
     * @param   string  $in_const       neuer Value
     * @return  array                   Zweidimensionales Array (siehe oben)
     */
    function addConstToAMultiArray($in_array, $in_new_key, $in_const) {
        $feedback = array();
        foreach ($in_array as $key => $currentSubArray) {
            $currentSubArray[$in_new_key] = $in_const;
            $feedback[$key] = $currentSubArray;
        }
        
        return $feedback;
    }
    
    
        
    
        
    /** Prüft ob ein Account noch gültig ist oder das expiredate bereits erreicht ist.
     * 
     * @global  string  $db_schema_manager      Diese globale Variable wird genutzt
     * @param   string  $in_account             Account-ID
     * @param   string  $in_account_app_id      App-ID des Accounts
     * @return  boolean                         true, wenn expiredate >= heute oder NULL
     */
    function checkUserAccountIsValid($in_account, $in_account_app_id) {
        
        global $db_schema_manager;
        global $db_schema_manager_connection_id; 
        
        $validDate = getDataFromTableByID($db_schema_manager_connection_id, $db_schema_manager, "account", "expiredate", "id = '".$in_account."' and app_id = '".$in_account_app_id."'");
        
        if($validDate == "" OR $validDate >= date("Y-m-d")) {
            $checkResult = true;
        } else {
            $checkResult = false;
        }
											//Error-Reporting wieder einschalten
        return $checkResult;
    }
	
    
    

    
    
    /** Ermittelt nur den Hilfetext zu einer übergebenen Feld-ID
    * 
    * @global  string  $db_schema_manager  Angabe des Schemas, in dem sich die hilfe-Tabelle befindet
    * @param   integer $feldID             ID des Feldes, für das der Hilfetext angezeigt werden soll (feld.id)
    * @param   String                      APP des Feldes, für das der Hilfetext angezeigt werden soll (feld.app_id)
    * @return  array                       eindimensional
    */
    function getHilfe($in_feldID, $in_feldAppID) {														
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Starte getHilfe ', $in_feldID);
            $hilfe = getHilfe2($in_feldID, $in_feldAppID);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Hilfetext für Feld-ID '.$in_feldID.': ', $hilfe);
            if ($hilfe["hilfe.inhalt"] === NULL) {
                $feedback = "keine Hilfe verfuegbar"; 
            } else {
                $feedback = "<b>Feld: ".$hilfe["hilfe.name"]."</b><br />";
                $feedback = $feedback."(max. Anzahl Zeichen: ".$hilfe["hilfe.max_length"].")<br /><br />";
                $feedback = $feedback.$hilfe["hilfe.inhalt"];
                
            }

            return $feedback;							

    }
    
    
    
    
    
    /** Hinterlegt den Wert eines Feldes einer Datarow in der Formulereigenschaft [$in_formID]["form.instances"][$in_instance_id]["valuesSecureFields"]
     * TODO: Derzeit greift diese Funktion direkt auf die globale Variable SESSION zu. 
     * Das sollte besser über pagedata gekapselt werden. Die Funktion wird jedoch momentan nur über AjaxRequest genutzt. 
     * Dort ist pagedata noch nicht vorhaneden.
     * 
     * 
     * @param integer   $in_formID          ID des Formulars
     * @param string    $in_instance_id     ID der Instanz des Formulars
     * @param integer   $in_datarow         Nummer der Datenzeile
     * @param integer   $in_fieldId         DomID des Feldes
     * @param string    $in_value           Wert, des Feldes
     */
    function setNewDataForSecureFieldsInSessionBackup($in_formID, $in_instance_id, $in_datarow, $in_fieldId, $in_value) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, $_SESSION); 
        
        if(isset($_SESSION["forms_backup"][$in_formID]["form.instances"][$in_instance_id])) {
            
        
            $_SESSION["forms_backup"][$in_formID]["form.instances"][$in_instance_id]["valuesSecureFields"][$in_datarow][$in_fieldId] = $in_value;
        }
        
        
    }
    
    
    /** Prüft, ob ein String ein Datum ist.
     * Wenn ja, wird das Datum im gewünschten Format umgewandelt
     * 
     * @param   string  $value      String, der zu prüfen ist (Bsp.: "2022-01-18")
     * @param   string  $in_format  gültiges Format, siehe https://www.php.net/manual/en/datetime.format.php ; Bsp.: 'Y-m-d H:i:s'
     * @return boolean
     */
    function isDate($value, $in_format) {
        if (!$value) {
            return false;
        }
        
        if(strpos($value, "-")=== false AND strpos($value, ".")=== false) {
            return false;
        }

        try {
            $my_date = new DateTimeImmutable($value);
            return $my_date->format($in_format);;
        } catch (\Exception $e) {
            return false;
        }
    }
    
    
    /** Ersetzt in einem Template (Html, Mail oder RTF)  die Platzhalter für Daten aus dem form_array, dem wrkfl_array oder dem Datensatz eines Formulars durch den jeweiligen 
     * value. 
     * 
     * @param   string  $in_template    Template der Mail- oder RTF-Vorlage
     * @param   array   $in_datensatz   Array eines Datensatzes, bspw. Array
                                                                            (
                                                                                [k_bst_pre.id] => Array
                                                                                    (
                                                                                        [field.id] => 9121
                                                                                        [field.name] => ID
                                                                                        [field.value] => 218
                                                                                        [field.valueplaintext] => 
                                                                                    )

                                                                                [k_bst_pre.bst] => Array
                                                                                    (
                                                                                        [field.id] => 6272
                                                                                        [field.name] => Haushaltskostenstellennummer
                                                                                        [field.value] => 02601202
                                                                                        [field.valueplaintext] => 
                                                                                    )
                                                                            }
     * @param   array   $in_formarray   Array eines Formulars
     * @param   object  $in_pagedata    Referenz zum Pagedata-Objekt
     * @return  string                  Template mit ersetzten Platzhaltern
     */
    function replacePlaceholderInTemplateBySysdata($in_template, $in_datensatz, $in_formarray, &$in_pagedata) {
        $feedback = $in_template;
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Suche Platzhalter:', "Datensätze, form-Array und wkfl_Array");
                
        
         //Alle Platzhalter, die sich auf den Datensatz aus einem Workflow beziehen, ersetzen
        foreach ($in_datensatz as $fieldkey => $fieldarray) {
            if(is_array($fieldarray) AND $fieldarray != array()) {
                //Platzhalter ersetzen
                $spalte = "$$".$fieldarray["field.name"]."$$";
    //            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Suche Platzhalter:', $spalte." für Wert: ".$feldwert);
                if($fieldarray["field.valueplaintext"]!= "") {$new_value = $fieldarray["field.valueplaintext"];} else {$new_value = $fieldarray["field.value"];}
                $feedback = str_replace($spalte, $new_value, $feedback);
            }
        }
        
        
        //Alle Platzhalter, die sich auf den Datensatz aus einer Query beziehen, ersetzen
        foreach ($in_datensatz as $feldname => $feldwert) {
            if(is_string($feldwert)) {
                //Platzhalter ersetzen
                $spalte = "$$".$feldname."$$";
                //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Suche Platzhalter:', $spalte." für Wert: ".$feldwert);
                $feedback = str_replace($spalte, $feldwert, $feedback);
            }
        }
        
        
        
        
        //Alle Platzhalter, die sich auf das form-array beziehen, ersetzen
        foreach ($in_formarray as $formarray_key => $feldwert) {
            if(is_array($feldwert) === false) {
                $spalte = "$$".$formarray_key."$$";
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Suche Platzhalter:', $formarray_key." für Wert: ".$feldwert);
                $feedback = str_replace($spalte, $feldwert, $feedback);
            }
        }
        
        
        
        
         //Alle Platzhalter, die sich auf Workflowdaten beziehen, ersetzen
        if($in_pagedata !== false) {                                            //$in_pagedata kann false sein, wenn Aufruf über query erfolgt.
            if ($in_pagedata->existWorkflow() == true) {
                $my_workflow = $in_pagedata->getWorkflow();
                foreach ($my_workflow->getWkflMetadata() as $wkfl_key => $wkfl_value) {
                    //Platzhalter ersetzen
                    $spalte = "$$".$wkfl_key."$$";
    //                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Suche Platzhalter:', $spalte." für Wert: ".$wkfl_value);
                    $feedback = str_replace($spalte, $wkfl_value, $feedback);
                }
            }
        }
        
        
        //Alle sonstigen Platzhalter ersetzen
            //Date-Platzhalter

        $spalte = '$$date|dd.mm.YYYY$$'; $feedback = str_replace($spalte, strftime("%d.%m.%Y", time()), $feedback);
        $spalte = '$$date|day, d. mmm YYYY$$'; $feedback = str_replace($spalte, strftime("%A, %d. %B %Y", time()), $feedback);
        $spalte = '$$date|day$$'; $feedback = str_replace($spalte, strftime("%A", time()), $feedback);
        $spalte = '$$time|hh:mm$$'; $feedback = str_replace($spalte, strftime("%H:%M", time()), $feedback);
        $spalte = '$$time|hh:mm:ss$$'; $feedback = str_replace($spalte, strftime("%H:%M:%S", time()), $feedback);
        $spalte = '$$server$$'; $feedback = str_replace($spalte, $_SERVER['HTTP_HOST'], $feedback);
        
        
        
        
        return $feedback;

    }
    
    
    
    /** Diese funktion entfernt aus einem String einige Sonderzeichen. 
     * 
     * @param   String  $in_string      String, aus dem die Sonderzeichen entfernt werden sollen.
     * @param   array   $in_charlist    [optional] Liste der zu entfernenden Sonderzeichen
     */
    function replace_speicial_chars($in_string, $in_charlist = array("'", "/")) {
        $feedback = str_replace($in_charlist, "", $in_string);
        return $feedback;
    }



?> 

