<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

/**
 * Klasse stellt Methoden zur Erstellung von Navigationsmenüs zur Verfügung
 *
 * @author Thomas J.
 */
class navMenu {
    
    /**
     *
     * @var integer     ID der aktiven Maske 
     */
    public $active_mask_id;
    
    
    /**
     *
     * @var string      ID der APP der Rolle, in dessen Kontext das Navigationsmenü erstellt werden soll
     */
    protected $role_app_id;
    
    
    /**
     *
     * @var integer     ID der Rolle, in dessen Kontext das Navigationsmenü erstellt werden soll 
     */
    protected $role_id;
    
    
    /** 
     *
     * @var string     oid des übergeordneten HTML-Tag, in dem das Menü eingefügt werden soll. (CONCAT(html_app_id,"_",html_tag.id))
     */
    public $ParentHtmlTag;
    
    
    /**
     *
     * @var integer     Ebene des obersten tags der Maskenliste
     */
    public $tagLevel;

    
    /**
     *
     * @var integer     ID der Navigationsgruppe, welche ermittelt werden soll (siehe htmltag.has_nav_menu); 99 = all
     */
    public $nav_group;

    
    /**
     *
     * @var integer     [optional; default = 100000] ID, ab der die IDs der htmltags beginnen sollen. Mit der StartId muss sichergestellt werden, dass die verwendeten IDs im DOM eindeutig sind. (default = 10000) 
     */
    public $startID;
    
    
    /**
     *
     * @var string      Enthält die [html]ID des Navigationsmenüs. Diese kann beim Einhängen eines Menüeintrages in den HTML-Dom
     *                  genutzt werden, falls der eigentliche Parent-html-tag im DOM nicht vorhanden ist. Diese Situation kann auftreten,
     *                  wenn in einer APP-XYZ nur einzelne Masken des Kernmoduls einer Rolle der APP-XYZ genutzt werden.
     */
    protected $default_parent;
    
    
    
    /** Liste aller Masken als zweidimensionales Array, auf die die aktuelle Rolle (User) Zugriff hat. 
     * Das Array kann dem  DomTree-Objekt mit addTag (in einer Schleife) übergeben werden.
     *
     * @var array 
     */
    private $navtreeList = array();
    

    /** Klasse stellt Methoden zur Erstellung von Navigationsmenüs zur Verfügung
    * 
    * @param   integer $in_active_mask_id      ID der aktiven (aufgerufenen) Maske
    * @param   string  $in_ParentHtmlTag       oid des übergeordneten HTML-Tag, in dem das Menü eingefügt werden soll
    * @param   integer $in_tagLevel            Ebene des obersten tags der Maskenliste
    * @param   integer $in_nav_group           ID der Navigationsgruppe, welche angedruckt werden soll (siehe htmltag.has_nav_menu); 99 = all
    * @return  Array                           Gibt das Menü als zweidimensionales Array zurück
    */
    function __construct($in_active_mask_id, $in_ParentHtmlTag, $in_tagLevel, $in_nav_group) {
        $this->active_mask_id = $in_active_mask_id;
        $this->role_app_id = $_SESSION["active_role"]["role.app_id"];
        $this->role_id = $_SESSION["active_role"]["role.id"];
        $this->ParentHtmlTag = $in_ParentHtmlTag;
        $this->tagLevel = $in_tagLevel;
        $this->nav_group = $in_nav_group;
        $this->startID = 10000;
        
        $this->navtreeList = $this->buildNavTree();
    }
    
    
    
    /** Gibt die Liste aller Masken (Navigationsmenüeinträge), auf die die aktuelle Rolle (User) Zugriff hat,  als zweidimensionales Array, zurück. 
     * Das Array kann dem  DomTree-Objekt mit addTag (in einer Schleife) übergeben werden.
     * 
     * @return array
     *      Bsp.: Array( <br />
                    [0] => Array( <br />
                        [mask.id] => 100 <br />
                        [mask.app_id] => SYS01 <br />
                        [mask.css_template_app_id] => SYS01 <br />
                        [mask.css_template_id] => 1 <br />
                        [mask.name] => Startseite <br />
                        [mask.link] => page.php <br />
                        [mask.menu_app_id] => SYS01 <br />
                        [mask.menu] =>  <br />
                        [mask.description] => Startseite ... <br />
                                    [mask.sort] => 0 <br />
                        [mask.level] => 0 <br />
                        [mask.navgroup] => 1 <br />
                        [mask.navgroupsort] => 1 <br />
                        [mask.sys] => 1 <br />
                        [.uniqueid] => SYS01_100 <br />
                        ) <br />
                    [1] => Array... <br />
     */
    public function getNavTreeList() {
        return $this->navtreeList;
    }
    
    /** gibt eine Liste aller Masken als zweidimensionales Array, auf die eine Rolle (User) Zugriff hat, zurück
    * Das Array kann dann dem  DomTree-Objekt mit addTag (in einer Schleife) übergeben werden.
     * Die Sortierung erfolgt beim Einhängen der Elemente in den Dom-Tree automatisch, da jeder Listeneintrag sein korrekten Parent-Eintrag kennt.
    * 
    * @return  Array                           Gibt das Menü als zweidimensionales Array zurück
    */
    private function buildNavTree() {													
        $default_dummy_form_id      = global_variables::getDefaultDummyFormId();
        $default_dummy_form_app_id  = global_variables::getAppIdFromSYS01();     

        $maskList = getMaskListByRole($this->role_app_id, $this->role_id, $this->nav_group);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Maskarray: ', $maskList);



        $html_array = array();                                                  //Array anlegen


        //Als erster tag wird ul hinzugefügt
        $html_array[0] ["html_tag.id"] = $this->ParentHtmlTag.$this->startID;
        $html_array[0] ["html_tag.app_id"] = $default_dummy_form_app_id;
        $html_array[0] ["html_tag.form_app_id"] = $default_dummy_form_app_id;                      //App für Dummy-Formular
        $html_array[0] ["html_tag.form_id"] = $default_dummy_form_id;                                //Dummy-Formular
        $html_array[0] ["html_tag.name"] = "ul";
        $html_array[0] ["html_tag.level"] = $this->tagLevel;
        $html_array[0] ["html_tag.parent_tag"] = $this->ParentHtmlTag;
        $this->default_parent = $html_array[0] ["html_tag.id"];
        $html_array[0] ["html_tag.description"] = "navtree_".$this->ParentHtmlTag;                             
        $html_array[0] ["html_tag.sort"] = 10;
        $html_array[0] ["html_tag.value"] = "";  
        $html_array[0] ["html_tag.specialtype"] = ""; 
        $html_array[0] ["html_tag.has_mask_menu"] = "";


            for($i = 1; $i < (count($maskList)+1); $i++) {
                //Für jeden Datensatz aus mask einen tag Listenpunkt (li) hinzufügen
                $id = $maskList[$i-1] ["mask.id"];
                $name = $maskList[$i-1] ["mask.name"];
                $link = $maskList[$i-1] ["mask.link"];
                $ebene = $maskList[$i-1] ["mask.level"];
                $maskApp = $maskList[$i-1] ["mask.app_id"];
                if($maskList[$i-1]["mask.menu"] == "" OR $this->nav_group <> 99) {
                    $my_parent_tag = $html_array[0] ["html_tag.id"];
                } else {
                    $my_parent_tag = $this->ParentHtmlTag.$maskList[$i-1]["mask.menu"];
                }

                if($this->active_mask_id == $id) {$active_mask_class = " active_mask";} else {$active_mask_class = "";}

                $html_array[$i] ["html_tag.id"] = $this->ParentHtmlTag.$id;
                $html_array[$i] ["html_tag.app_id"] = $maskApp;
                $html_array[$i] ["html_tag.name"] = "li";
                $html_array[$i] ["html_tag.level"] = $maskList[$i-1] ["mask.level"];
                $html_array[$i] ["html_tag.parent_tag"] = $my_parent_tag;
                $html_array[$i] ["html_tag.value"] = "<a data-level=\"$ebene\" class=\"menu".$active_mask_class."\" href=\"$link?mask=$id&maskapp=$maskApp\">$name</a>";
                $html_array[$i] ["html_tag.description"] = "navtreeitem_".$html_array[$i]["html_tag.id"]." - parent: ".$my_parent_tag;
                $html_array[$i] ["html_tag.form_id"] = $default_dummy_form_id;                       //Dummy-Formular
                $html_array[$i] ["html_tag.form_app_id"] = "";                  //App für Dummy-Formular
                $html_array[$i] ["html_tag.sort"] = $html_array[0] ["html_tag.sort"]+$i;
                $html_array[$i] ["html_tag.specialtype"] = "";
                $html_array[$i] ["html_tag.has_mask_menu"] = "";
            }


        return $html_array;
    }	
    
    
    public function getDefaultParentTag() {
        return $this->default_parent;
    }

    
    
}
