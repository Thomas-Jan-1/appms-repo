
/* 
 * Copyright (C) 2023 AppMS-IT (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */



var global_trennzeichen = "0";              //globale Variable zur Festlegung des Trennzeichens in Feldernamen und ids
var delimiterFieldAttribut  = "|||";        //globale Variable zur Festlegung Trennzeichens für Attribute in einer Datarow (siehe getDataFromCurrentRow) 
var delimiterFields         = "_____";      //globale Variable zur Festlegung Trennzeichens für Felder in einer Datarow (siehe getDataFromCurrentRow) 
var class_usedRows = 'used_data';           //globale Variable zur Markierung von used Rows
var global_feedback = "";                   //globale Variable für funktionsübergreifendes Feedback. Notwendig, bei der Verwendung von jQuery.ajax   
var submitted = false;
var userinput = false;
var intervaltimer;                          //globale Variable für setInterval()
var global_abort = false;


const sleep = m => new Promise(r => setTimeout(r, m));          //Aufruf mit await sleep(3000);



function click_button_date_update() {
    jQuery("#button_date_update").click();
}



/** verschiebt das Source-Element zum target-Element (als Child) innerhalb des DOM.
 * 
 * @param   {string}    in_source           ID des Source-Elements
 * @param   {string}    in_target           ID des Target-Elements
 * @param   {string}    in_button           ID des buttons, welcher geklickt wurde
 * @param   {string}    in_handle_button    Gibt an, ob der Button ein- oder ausgeblendet werden soll. [show|hide]
 * @returns {boolean}                       Die Funktion gibt immer False zurück, damit die Seite nicht neu geladen wird.
 */
function moveNewRowToForm(in_source, in_target, in_button, in_hide_button) {
    console.log("source: "+in_source+" | target: "+in_target+" | buttonname: "+in_button);
    let my_source_element = document.getElementById(in_source);
    let my_target_element = document.getElementById(in_target);
    //let my_button_element = document.getElementById(in_button);
    //Datenzeile umhängen
    my_target_element.appendChild(my_source_element);
    //Button ausblenden
    if(in_hide_button === "hide") {
        hideFieldID(in_button);
    } else {
        showFieldID(in_button);
    }
    return false;
}




/** Ändert den Wert des auslösenden Textfeldes in Kleinbuchstaben um
 * 
 * @version 2018-01-15
 * @param {object} event
 * @returns {boolean}        Wenn Funktion abgeschlossen, dann wird true zurückgegeben.
 */
function changeDataFromCurrentFieldToLowercase(event) {
    
    return new Promise(resolve => {
        var currentElementID = getIdFromEventelement(event);
        var currentElement = document.getElementById(currentElementID);
        var currentValue = currentElement.value;
        var lowerCurrentValue = currentValue.toLowerCase();
        //alert("lowerCase " + lowerCurrentValue);
        jQuery("#"+currentElementID).val(lowerCurrentValue);
        resolve(true);
    });
    
}


/** Funktion aktiviert oder deaktiviert alle Checkboxen mit der gleichen Group-ID im gleichen Formular.
 * 
 * @param   {object}    event   Element, welches das Ereignis ausgelöst hat
 * @returns {undefined}
 */
function checkAllCheckboxes(event) {
    var currentElementID = getIdFromEventelement(event);
    var currentElement = document.getElementById(currentElementID);
    var currentGroupName = getValueFromEventelementAttribut(event, "data-group_id");
    var currentFormIDAttr = getValueFromEventelementAttribut(event, "data-form_id");
    
//    alert("geklickte Checkbox: ID = "+currentElementID + ", data-group_id = " + currentGroupName + ", form_id = " + currentFormIDAttr);
    
    var x = document.getElementById(currentFormIDAttr).querySelectorAll("input[data-group_id='"+currentGroupName+"']");
    var i;
    for (i = 0; i < x.length; i++) {
        if(currentElement.checked) {// Ist die Checkbox im Header aktiviert?
            if(x[i].getAttribute("data-ds_hide") == "false") {
                x[i].checked = true; 
            }
        } else {
            x[i].checked = false; 
        }  
    }
}




/** Entfernt alle Zeichen, außer kleine Buchstaben
 * 
 * @version 2019-06-11
 * @param {object} event
 * @returns {undefined}
 */
function changeDataFromFieldToOnlyLowercase(event) {
    var currentElementID = getIdFromEventelement(event);
    var currentElement = document.getElementById(currentElementID);
    var currentValue = currentElement.value;
    var lowerCurrentValue = currentValue.toLowerCase();
    var lowerCurrentValue = lowerCurrentValue.replace(/[^a-z0-9.:-_ ]/g, '');
    //alert("lowerCase " + lowerCurrentValue);
    jQuery("#"+currentElementID).val(lowerCurrentValue);
    
}







/** Entfernt alle Zeichen, außer Zahlen
 * 
 * @version 2020-11-27
 * @param {object} event
 * @returns {undefined}
 */
function changeDataFromFieldToOnlyNumber(event) {
    var currentElementID = getIdFromEventelement(event);
    var currentElement = document.getElementById(currentElementID);
    var currentValue = currentElement.value;
    var newCurrentValue = currentValue.replace(/[^0-9]/g, '');
//    alert("newCurrentValue " + newCurrentValue);
    jQuery("#"+currentElementID).val(newCurrentValue);
    
}



/** Prüft, ob das Datum des aktuellen Feldes (event) kleiner, als das eines Vergleichsfeldes ist.
 * Falls nein, werden beide Felder um die CSS-Klasse highlight_field erweitert und
 * alle validate-Buttons des selben Formulars deaktiviert.
 * 
 * @param   {object}    event
 * @param   {type}      compare_field_id        ID des Vergleichsfeldes
 * @returns {undefined}
 */
function dateMustBeLessThanDateInField(event, compare_field_id) {
    //Wert des aktuellen Feldes ermitteln
    var currentElementID = getIdFromEventelement(event);
    var currentElement = document.getElementById(currentElementID);
    var currentValue = currentElement.value;
    var currentElementName = getValueFromEventelementAttribut(event, "title");
    //alert("DateIsSmallerThenDateInField: " + currentValue + " \n " + "Field-ID: " + currentElementID);
    
    
    //Wert des Vergleichsfeldes ermitteln
    var value_of_compare_field = getValueFromFieldIDOfSameDatarow(currentElementID, compare_field_id, 3);
    var DomID_of_compare_field = getValueFromFieldIDOfSameDatarow(currentElementID, compare_field_id, 4);
    var form_id = getValueFromFieldIDOfSameDatarow(currentElementID, compare_field_id, 0);
    var compareElementName = jQuery("#"+DomID_of_compare_field).attr("title");
    
    
      
    
    //Wenn Vergleichsfeld und aktueller Wert <> Null, dann vergleichen
    if(currentValue != "" & value_of_compare_field != "") {
        var first_date = new Date(currentValue);
        var second_date = new Date(value_of_compare_field);
        //Wenn der aktuelle Wert > oder gleich dem Vergleichswert, dann einen Fehler anzeigen, Das Feld hervorheben und Cursor in Feld setzen
        if(first_date < second_date) {
            jQuery("#"+DomID_of_compare_field).removeClass("highlight_field");
            jQuery("#"+currentElementID).removeClass("highlight_field");
            enableButtonsInForm(form_id, "validate");
            $feedback = true;
            
        } else {
            showFeedbackBox2('Der Wert im Feld "<b>' + currentElementName + '</b>" ist gleich oder größer als der Wert im Feld "<b>' + compareElementName + '</b>".');
            jQuery("#"+DomID_of_compare_field).addClass("highlight_field");
            jQuery("#"+currentElementID).addClass("highlight_field");
            disableButtonsInForm(form_id, "validate");
            $feedback = false;
            
        }
    }

}



/** Prüft, ob das Datum des aktuellen Feldes (event) größer, als das eines Vergleichsfeldes ist.
 * Falls nein, werden beide Felder um die CSS-Klasse highlight_field erweitert und
 * alle validate-Buttons des selben Formulars deaktiviert.
 * 
 * @param   {object}    event
 * @param   {type}      compare_field_id        ID des Vergleichsfeldes
 * @returns {undefined}
 */
function dateMustBeLaterThanDateInField(event, compare_field_id) {
    //Wert des aktuellen Feldes ermitteln
    var currentElementID = getIdFromEventelement(event);
    var currentElement = document.getElementById(currentElementID);
    var currentValue = currentElement.value;
    var currentElementName = getValueFromEventelementAttribut(event, "title");
    //alert("DateIsSmallerThenDateInField: " + currentValue + " \n " + "Field-ID: " + currentElementID);
    
    
    //Wert des Vergleichsfeldes ermitteln
    var value_of_compare_field = getValueFromFieldIDOfSameDatarow(currentElementID, compare_field_id, 3);
    var DomID_of_compare_field = getValueFromFieldIDOfSameDatarow(currentElementID, compare_field_id, 4);
    var form_id = getValueFromFieldIDOfSameDatarow(currentElementID, compare_field_id, 0);
    var compareElementName = jQuery("#"+DomID_of_compare_field).attr("title");
    
    
      
    
    //Wenn Vergleichsfeld und aktueller Wert <> Null, dann vergleichen
    if(currentValue != "" & value_of_compare_field != "") {
        var first_date = new Date(currentValue);
        var second_date = new Date(value_of_compare_field);
        //Wenn der aktuelle Wert > oder gleich dem Vergleichswert, dann einen Fehler anzeigen, Das Feld hervorheben und Cursor in Feld setzen
        if(first_date > second_date) {
            jQuery("#"+DomID_of_compare_field).removeClass("highlight_field");
            jQuery("#"+currentElementID).removeClass("highlight_field");
            enableButtonsInForm(form_id, "validate");
            $feedback = true;
            
        } else {
            showFeedbackBox2('Der Wert im Feld "<b>' + currentElementName + '</b>" ist gleich oder kleiner als der Wert im Feld "<b>' + compareElementName + '</b>".');
            jQuery("#"+DomID_of_compare_field).addClass("highlight_field");
            jQuery("#"+currentElementID).addClass("highlight_field");
            disableButtonsInForm(form_id, "validate");
            $feedback = false;
            
        }
    }

}





/** Prüft, ob Wert des aktuellen Feldes (event) anders, als der eines Vergleichsfeldes ist.
 * Falls nein, werden beide Felder um die CSS-Klasse highlight_field erweitert und
 * alle validate-Buttons des selben Formulars deaktiviert.
 * 
 * @param   {object}    event
 * @param   {type}      compare_field_id        ID des Vergleichsfeldes
 * @returns {undefined}
 */
function checkValuesNotEqual(event, compare_field_id) {
    //Wert des aktuellen Feldes ermitteln
    var currentElementID = getIdFromEventelement(event);
    var currentElement = document.getElementById(currentElementID);
    var currentValue = currentElement.value;
    var currentElementName = getValueFromEventelementAttribut(event, "title");
    //alert("DateIsSmallerThenDateInField: " + currentValue + " \n " + "Field-ID: " + currentElementID);
    
    
    //Wert des Vergleichsfeldes ermitteln
    var value_of_compare_field = getValueFromFieldIDOfSameDatarow(currentElementID, compare_field_id, 3);
    var DomID_of_compare_field = getValueFromFieldIDOfSameDatarow(currentElementID, compare_field_id, 4);
    var form_id = getValueFromFieldIDOfSameDatarow(currentElementID, compare_field_id, 0);
    var compareElementName = jQuery("#"+DomID_of_compare_field).attr("title");
    
    
      
    
    //Wenn Vergleichsfeld und aktueller Wert <> Null, dann vergleichen
    if(currentValue != "" & value_of_compare_field != "") {
        var first_value = currentValue;
        var second_value = value_of_compare_field;
        //Wenn der aktuelle Wert gleich dem Vergleichswert, dann einen Fehler anzeigen, Das Feld hervorheben und Cursor in Feld setzen
        if(first_value !=  second_value) {
            jQuery("#"+DomID_of_compare_field).removeClass("highlight_field");
            jQuery("#"+currentElementID).removeClass("highlight_field");
            enableButtonsInForm(form_id, "validate");
            $feedback = true;
            
        } else {
            showFeedbackBox2('Der Wert im Feld "<b>' + currentElementName + '</b><br />" darf nicht gleich dem Wert im Feld "<b>' + compareElementName + '</b><br /> sein".');
            jQuery("#"+DomID_of_compare_field).addClass("highlight_field");
            jQuery("#"+currentElementID).addClass("highlight_field");
            disableButtonsInForm(form_id, "validate");
            $feedback = false;
            
        }
    }

}









/** Setzt das Attribut "disable" aller Buttons der angegebenen Form, die den gewählten Buttontype haben.
 * 
 * @param   {integer}   form_id     ID des Formulars
 * @param   {string}    buttontype  Art der Button {validate|novalidate}
 * @returns {undefined}
 */
function disableButtonsInForm(form_id, buttontype) {
    var button_class = "";
    if(buttontype === "validate") {
        button_class = "validate_formid_" + form_id;
    } else {
        button_class = "novalidate_formid_" + form_id;
    }
    
    jQuery('.'+button_class).each(function() {
        jQuery(this).attr("disabled","disabled");
    });
}


/** Setzt das Attribut "disable" aller Buttons der angegebenen Form auf false (aktiv), die den gewählten Buttontype haben.
 * 
 * @param   {integer}   form_id     ID des Formulars
 * @param   {string}    buttontype  Art der Button {validate|novalidate}
 * @returns {undefined}
 */
function enableButtonsInForm(form_id, buttontype) {
    var button_class = "";
    if(buttontype === "validate") {
        button_class = "validate_formid_" + form_id;
    } else {
        button_class = "novalidate_formid_" + form_id;
    }
    
    jQuery('.'+button_class).each(function() {
        jQuery(this).removeAttr("disabled");
    });
}



/** Zeigt einen Hinweistext beim Klick auf einen Löschbutton. 
 * 
 * @returns {Boolean}
 */
function confirmDeleting() {
    //ACHTUNG: diese Methode ersetzen, wenn Ticket 470 umgesetzt ist.
    return window.confirm("Wollen Sie den/die Datensätze wirklich löschen?");     //Wenn false, dann wird das Formular nicht neu geladen (formaction wird abgebrochen)
}



function confirmFinalizeVersion() {
    //ACHTUNG: diese Methode ersetzen, wenn Ticket 470 umgesetzt ist.
    //Wenn false, dann wird das Formular nicht neu geladen (formaction wird abgebrochen)
    
    var feedback = false;
    feedback = window.confirm(  "ACHTUNG: \n" + 
                            "Dieser Schritt kann nicht rückgängig gemacht werden!\n" +
                            "Bevor Sie fortfahren, stellen Sie sicher, dass sie der Version im Feld -Beschreibung- einen sinnvollen Text mitgegeben haben.\n" +
                            "Die Versionsnummer wird durch den folgenden Prozess automatisch vergeben.\n" +
                            "Das Versionspaket wird im Versionsverzeichnis unter der APP-ID und der Versionsnummer abgelegt.\n" +
                            "Außerdem wird ein neuer Vorbereitungsdatensatz für die nächste Version in der Tabelle -version- im Kernmodul angelegt.\n" +
                            "\n\n\n" +
                            "HINWEIS: \n" +
                            "Wenn das Beschreibungsfeld nicht angezeigt wird, können Sie bedenkenlos fortfahren. In dem Fall wird erstmals ein Vorbereitungsdatensatz für diese Anwendung angelegt. \n" +
                            "Wollen Sie fortfahren?");    
    
    if (feedback === true) {
        //WaitForm einblenden
        showWaitBox();
        
    }
    
    return feedback;
    
}



/** ermittelt den Hilfetext zu einem Feld und gibt diesen über showHilfe aus. 
 * 
 * @version 2017-10-09
 * @param   {object}        event       Ereignis, welches auf der Oberfläche durch einen Mausclick ausgelöst wurde.
 * @returns {undefined}
 */
function getHilfeByFeldID(event) {									
	var currentElement = getIdFromEventelement(event);						//Element ermitteln
        var targetMethodName = "getHelptextForFeldID";                                                  //Name der Methode, die per ajax am Server angesprochen werden soll
	var FeldID = jQuery("#"+currentElement).attr("data-feldid");
        var FeldAppID = jQuery("#"+currentElement).attr("data-feldappid");
	jQuery.ajax({											//Serveranfrage
                url: "ajaxRequest.php",	
                async: false,
                data: { feldID: FeldID, feldAppID: FeldAppID, targetMethod: targetMethodName },
                datatype: "json",
                type: "POST",
                success: function(data) { showHilfe(data); }                                            //Aufruf der Funktion, die die antwort des Servers auswertet
        });	

}



/** wie getHilfeByFeldID, aber das Ergebnis wird in der Feedbackbox ausgegeben
 * 
 * @param   {object}        event       Ereignis, welches auf der Oberfläche durch einen Mausclick ausgelöst wurde.
 * @returns {false}                     Rückgabewert ist immer false, damit das Neuladen der Maske unterdrückt wird.
 */
function getHilfeByFeldID2(event) {									//ermittelt den Hilfetext zu einem Feld
    var currentElement = getIdFromEventelement(event);						//Element ermitteln
    var targetMethodName = "getHelptextForFeldID";                                                  //Name der Methode, die per ajax am Server angesprochen werden soll
    var FeldID = jQuery("#"+currentElement).attr("data-feldid");
    var FeldAppID = jQuery("#"+currentElement).attr("data-feldappid");
    jQuery.ajax({											//Serveranfrage
            url: "ajaxRequest.php",
            async: false,
            data: { feldID: FeldID, feldAppID: FeldAppID, targetMethod: targetMethodName },
            datatype: "json",
            type: "POST",
            success: function(data) { showFeedbackBox(data); }                                            //Aufruf der Funktion, die die antwort des Servers auswertet
    });	
        
    return false;
}




/** ermittelt aus einem übergebenden Event die ID des Elements, welches das Event ausgelöst hat
 * 
 * @param {type} event
 * @returns {event.srcElement.id}
 */
function getIdFromEventelement(event) {															
	if (event.srcElement) { var currentElement = event.srcElement.id;}                              //id des auslösenden Elements ermitteln (IE)	
	else { if (event.target)  {var currentElement = event.target.id;}}                              //id des auslösenden Elements ermitteln (andere Browser)
	return currentElement;
}



/** ermittelt aus einem übergebenden Event-Element den Inhalt eines bestimmten Attributes
 * 
 * @param {object}  event
 * @param {string}  attributName        Name des Attributs
 * @returns Inhalt des name-Attributs oder null
 */
function getValueFromEventelementAttribut(event, attributName) {															
    var att;
    
    if (event.target)  {
        att = event.target.getAttribute(attributName);
    } else {
        att = null;
    }                             
    return att;
}



function showHilfe(data) {										//zeigt den übergebenen Hilfetext im Hilfefeld an
    //var response = jQuery.parseJSON(data);								//parsed den Rückgabewert des Servers
    var response = JSON.parse(data);
    var antwort = response.desc;											

//        jQuery('div[data-alt=infobox]').text(antwort);                                                        //beliebige Infobox, wenn html_tag.description = infobox
    document.querySelector("div[data-alt='infobox']").innerHTML = antwort;

    jQuery('div[data-alt=infobox]').css("background-color", "#FFFFCC");                                        //Farbe auf gelb (#ffffcc) setzen
    setTimeout( function() { jQuery('div[data-alt=infobox]').css("background-color", "white");  }, 1000);      //Farbe nach 1s wieder auf Weiß stellen    
}




/** aktualisiert das Hilfe-Div mit den übergebenen Daten
 * 
 * @param   {string}      data    Daten im json-Format (hilfeID, hilfeInhalt)
 * @returns {undefined}
 */
function showHilfe2(data) {									
    //var response = jQuery.parseJSON(data);								//parsed den R�ckgabewert des Servers
    var response = JSON.parse(data);
    
    //        alert(response.hilfeID);

    jQuery("#manager0hilfe0id0").val(response.hilfeID);
    jQuery("#manager0hilfe0id0").text(response.hilfeID);
    jQuery("#manager0hilfe0inhalt0").text(response.hilfeInhalt);
    jQuery("#save_feedback").text("");                                                              //Falls noch eine Meldung vorhanden ist, über das letzte Speicherergebnis, wird diese gelöscht
}



/** Füllt bei einem Suchfeld das darunterliegende Feld mit Suchvorschlägen, sobald eine bestimmte Anzahl von Zeichen eingegeben wurde.
 * 
 * @param {object} event                Auslösendes DOM-Objekt
 * @param {string} suchBegriff          Zeichen, nach denen gesucht werden soll
 * @param {integer} autocomplete_start  Anzahl Zeichen, ab denen mit der Suche begonnen werden soll.
 * @returns {undefined}
 */
function suggest(event, suchBegriff, autocomplete_start) {																
    var currentElement = getIdFromEventelement(event);						//Element ermitteln
    var targetMethodName = "getSuggestListForFeldID";                                                  //Name der Methode, die per ajax am Server angesprochen werden soll
    var FieldID = jQuery("#"+currentElement).attr("data-feldid");
    var FieldAppID = jQuery("#"+currentElement).attr("data-feldappid");
    var FormID = jQuery("#"+currentElement).attr("data-formid");
//    alert("Abfrage für ID: " + currentElement + ", fieldvalue: " + suchBegriff + " fieldappid: " + FieldAppID + " fieldid: " + FieldID + " formid " + FormID);

    jQuery( "#"+currentElement ).autocomplete({
        source: function (request, response) {
            var requestIndex = 0;							//unterbindet das Cachen des Servers
            jQuery.ajax({
                url: "ajaxRequest.php",
                data: { fieldID: FieldID, formID: FormID, fieldAppID: FieldAppID, targetMethod: targetMethodName, term: request.term},
                async: false,
                dataType: "json",
                type: "POST",
                autocompleteRequest: requestIndex += 1,
                success: function (data) {
                    if (this.autocompleteRequest === requestIndex) {response(data);}   //data muss nicht von json-Format zurückgeparst werden. Die Methode erwartet dieses Format.
                },
                error: function () {
                    if (this.autocompleteRequest === requestIndex) {response([]);}
                }
            });
        },
        minLength: autocomplete_start

    });

}


 
/** Ruft den Fortschritt aus der aktuellen Session ab, falls eine Serverseitige Funktion diesen in der Tabelle Session ablegt.
 * Das Ergebnis wird in "div[data-alt='Progressbar for Waitbox']" abgelegt.
 * 
 * @returns {undefined}
 */
function updateProgressStatus() {	

 								
    let targetMethodName = "getProgressStatus";                                                  //Name der Methode, die per ajax am Server angesprochen werden soll
    console.log('Anfrage an Server');
    jQuery.ajax({											//Serveranfrage
        url: "ajaxRequest.php",
        data: { targetMethod: targetMethodName},
        datatype: "json",
        type: "POST",
        async: false,
        //cache: false,
        success: function(data) { writeProgressStatus(data); }

    });


}



function writeProgressStatus($in_data) {
    console.log($in_data);
    let answer = JSON.parse($in_data);
//    console.log("Prozent: "+answer.percent);
//    console.log("Meldung: "+answer.message);
    document.querySelector("div[data-alt='Progressbar for Waitbox']").innerHTML = answer.message; 
    if (answer.percent == 100) {
        global_abort = true;
    }
}







/** aktualisiert Felder, die vom aktuellen Feld abhängen
 * 
 * @param   {object}    event
 * @returns {boolean}   gibt true zurück, sobald Antwort vom Server vorliegt und Funktion changeHtmlElementContent gestartet wurde.
 */
function updateDependingFields(event) { 
    return new Promise(resolve => {
        var currentElement = getIdFromEventelement(event);                                                  //Element ermitteln
        var FieldContent = jQuery("#"+currentElement).val();						//Inhalt des gewählten Feldes auslesen
        var targetMethodName = "getOptionListForDependingFields";  
        var FieldAppID = jQuery("#"+currentElement).attr("data-feldappid");
        var FieldID = jQuery("#"+currentElement).attr("data-feldid");
        var FormID = jQuery("#"+currentElement).attr("data-formid");
        
//            alert("Abfrage für ID: " + currentElement + ", fieldvalue: " + FieldContent + " fieldappid: " + FieldAppID + " fieldid: " + FieldID + " formid " + FormID);

        //Daten der gesamte aktuellen Zeile (des aktuellen Datensatzes ermitteln)
        var rowFieldList = getDataFromCurrentRow(currentElement);


        jQuery.ajax({											//Serveranfrage
                url: "ajaxRequest.php",
                async: false,
                data: { triggerFieldID: FieldID, triggerFieldAppID: FieldAppID, targetMethod: targetMethodName, triggerFieldcontent: FieldContent, triggerFieldFormID: FormID , rowFieldList: rowFieldList},
                datatype: "json",
                type: "POST",
                success: function(data) { changeHtmlElementContent(currentElement, data); }                                            //Aufruf der Funktion, die die antwort des Servers auswertet
        });	
        resolve(true);
    });
    
}



function updateDependingAppList(source_element) { 
    return new Promise(resolve => {
        var currentElement = source_element.getAttribute("id");                                                  //Element ermitteln
        var FieldContent = source_element.value;						//Inhalt des gewählten Feldes auslesen
        var targetMethodName = "getOptionListForDependingFields";  
        var FieldAppID = source_element.getAttribute("data-feldappid");
        var FieldID = source_element.getAttribute("data-feldid");
        var FormID = source_element.getAttribute("data-formid");
        
//            alert("Abfrage für ID: " + currentElement + ", fieldvalue: " + FieldContent + " fieldappid: " + FieldAppID + " fieldid: " + FieldID + " formid " + FormID);

        //Daten der gesamte aktuellen Zeile (des aktuellen Datensatzes ermitteln)
        var rowFieldList = getDataFromCurrentRow(currentElement);


        jQuery.ajax({											//Serveranfrage
                url: "ajaxRequest.php",
                async: false,
                data: { triggerFieldID: FieldID, triggerFieldAppID: FieldAppID, targetMethod: targetMethodName, triggerFieldcontent: FieldContent, triggerFieldFormID: FormID , rowFieldList: rowFieldList},
                datatype: "json",
                type: "POST",
                success: function(data) { changeHtmlElementContent(currentElement, data); }                                            //Aufruf der Funktion, die die antwort des Servers auswertet
        });	
        resolve(true);
    });
    
}





/** Ermittelt für eine Query den SQL-Befehl In der selben Datarow des Buttons, welcher geklickt wird, müssen sich 
 * auch die input-Felder mit Angabe der queraAppID (FeldID = 1620) und queryID (FeldID = 1612) befinden. 
 * 
 * @param   {object}    event       Enthält Informationen zum Objekt, welches angeklickt wurde.
 * @returns {false}                 Die Funktion gibt immer false zurück, damit das Neuladen der Maske unterdrükt wird. 
 */
function showQuerySqlCommand(event) {
    
    var currentElement = getIdFromEventelement(event);                                                  //Element ermitteln
    var targetMethodName = "getSqlCommandForQuery";  
    
    //Daten aus der aktuellen Zeile ermitteln
    var queryAppID = getValueFromFieldIDOfSameDatarow(currentElement, "1620", 3);
    var queryID = getValueFromFieldIDOfSameDatarow(currentElement, "1612", 3);
//    alert("Abfrage für ID: " + currentElement + ", Query-ID: " + queryID + " , Query-APP-ID: " + queryAppID);
    
   
    
    //AjaxRequest
    jQuery.ajax({											//Serveranfrage
            url: "ajaxRequest.php",
            async: false,
            data: { targetMethod: targetMethodName, queryID: queryID, queryAppID: queryAppID},
            datatype: "json",
            type: "POST",
            success: function(data) { showFeedbackBox(data, true); }                                            //Aufruf der Funktion, die die antwort des Servers auswertet
    });
    
    
    
    return false;                                                               //Um das Neuladen der Maske zu unterdrücken, wird immer false zurückgegeben.
    
}




/** Ermittelt für eine Query den SQL-Befehl In der selben Datarow des Buttons, welcher geklickt wird, müssen sich 
 * auch die input-Felder mit Angabe der queraAppID (FeldID = 1620) und queryID (FeldID = 1612) befinden. 
 * 
 * @param   {object}    event       Enthält Informationen zum Objekt, welches angeklickt wurde.
 * @returns {false}                 Die Funktion gibt immer false zurück, damit das Neuladen der Maske unterdrükt wird. 
 */
function showQueryPrieview(event) {
    
    showWaitBox();
    
    var currentElement = getIdFromEventelement(event);                                                  //Element ermitteln
    var targetMethodName = "getPreviewForQuery";  
    
    //Daten aus der aktuellen Zeile ermitteln
    var queryAppID = getValueFromFieldIDOfSameDatarow(currentElement, "1620",3);
    var queryID = getValueFromFieldIDOfSameDatarow(currentElement, "1612", 3);
//    alert("Abfrage für ID: " + currentElement + ", Query-ID: " + queryID + " , Query-APP-ID: " + queryAppID);
    
   
    
    //AjaxRequest
    jQuery.ajax({											//Serveranfrage
            url: "ajaxRequest.php",
            async: false,
            data: {targetMethod: targetMethodName, queryID: queryID, queryAppID: queryAppID},
            datatype: "json",
            type: "POST",
            success: function(data) { showFeedbackBox(data, false); }                                            //Aufruf der Funktion, die die antwort des Servers auswertet
    });
    
    
//    jQuery('#DataTable').DataTable();
    hideWaitBox();
    
    return false;                                                               //Um das Neuladen der Maske zu unterdrücken, wird immer false zurückgegeben.
    
}



/** ruft Ajax-Funktionen auf, die in Feld.js_click_params oder feld.js_change_params definiert sind.
 * Die Rückgabewerte werden in der Feedbackbox dargestellt
 * 
 * @param   {object}    event           Enthält Informationen zum Objekt, welches angeklickt wurde.
 * @param   {string}    targetFunction  Enthält den Funktionsaufruf auf der Serverseite (siehe feld.js_click_params)
 * @returns {Boolean}
 */
function showMoreData(event, targetFunction) {
    
    var currentElement = getIdFromEventelement(event);                                                  //Element ermitteln
    var targetFunctionName = targetFunction;						
    var targetMethodName = "getFeedbackFromPhpFunction";  
    var formID = jQuery("#"+currentElement).attr("data-formid");
    var senderFieldId = jQuery("#"+currentElement).attr("data-feldid");
 
//    alert("Abfrage für ID: " + currentElement + ", targetFunctionName: " + targetFunctionName + " targetMethodName: " + targetMethodName + " feldID: " + senderFieldId);
    
    //Daten der gesamten aktuellen Zeile (des aktuellen Datensatzes ermitteln)
    var rowFieldList = getDataFromCurrentRow(currentElement);
    
    //aktuelle Zeile markieren und alte Markierungen entfernen
    markRowAsUsed(currentElement);
    
    //AjaxRequest
    jQuery.ajax({											//Serveranfrage
            url: "ajaxRequest.php",			
            data: {targetMethod: targetMethodName, function_name: targetFunctionName, row_field_list: rowFieldList, form_id: formID, sender_field_id: senderFieldId},
            datatype: "json",
            type: "POST",
            success: function(data) { showFeedbackBox(data, false); }                                            //Aufruf der Funktion, die die antwort des Servers auswertet
    });
    
    
    return false;                                                               //Um das Neuladen der Maske zu unterdrücken, wird immer false zurückgegeben.
    
}






/** Nach Eingabe des Benutzernamens, werden die verfügbaren APP's geladen 
 * und das Formular so umgestaltet, dass nur das Passwort eingegeben werden kann.
 * 
 * @param {object}      event           auslösendes HTML-Element
 * @returns {Boolean}                   die Funktion gibt immer false zurück, damit das Absenden des Formulars unterdrückt wird.
 */
function loginStep0(event) {
    var currentElementID = getIdFromEventelement(event);
    
    //Wenn Benutzername eingegeben wurde, dann ...
    var value_of_uid_field = getValueFromFieldIDOfSameDatarow(currentElementID, "387", 3);
    if(value_of_uid_field !== "") {
        
        
        //APP-Liste in Abhängigkeit vom uid setzen 
        username_DomId = getValueFromFieldIDOfSameDatarow(currentElementID, "387", 4);
        username_element = document.getElementById(username_DomId);
        updateDependingAppList(username_element);
        
        //Passwortfeld einblenden und zu Pflichtfeld machen.
        changeRequiredAttributForFieldlist(event,'389|||true');
        
        //Weiter-Button ausblenden
        hideFieldID("container_0001O3760Form50_0_i0");
        
        //Schreibschutz für username-Field setzen
        setValueInField("0001O3820Form50_0_i0", value_of_uid_field, false)      //username in Label-Field übertragen
        hideFieldID("container_000uid0Form50_0_i0");                            //username ausblenden
        showFieldID("container_0001O3820Form50_0_i0");                          //username-Label-Field einblenden
        
        //Password-Field, Zurück-Button und Login-Button einblenden
        showFieldID("container_000password0Form50_0_i0");   //Password
        showFieldID("container_0001O3870Form50_0_i0");      //Zurück-Button
        showFieldID("container_0001O3940Form50_0_i0");      //Login-Button
        
        
        
        //Liste der verfügbaren APP's ermitteln
        loginStep1(event);
    } else {
        alert("Bitte geben Sie einen Benutzernamen ein.");
    }
    
    return false;
}



/** Stellt den Ursprungszustand der Login-Maske wieder her.
 * Geeignet für einen backward-button.
 * 
 * @param {object}              event
 * @returns {Boolean}
 */
function loginStep2(event) {
    
    
    //Passwortfeld einblenden und zu Pflichtfeld machen.
    changeRequiredAttributForFieldlist(event,'389|||false');

    //Weiter-Button einblenden
    showFieldID("container_0001O3760Form50_0_i0"); 

    //Schreibschutz für username-Field zurücknehmen
    showFieldID("container_000uid0Form50_0_i0");                            //username einblenden
    hideFieldID("container_0001O3820Form50_0_i0");                          //username-Label-Field ausblenden

    //Password-Field, Zurück-Button und Login-Button ausblenden
    hideFieldID("container_000password0Form50_0_i0");   //Password
    hideFieldID("container_0001O3870Form50_0_i0");      //Zurück-Button
    hideFieldID("container_0001O3940Form50_0_i0");      //Login-Button
    hideFieldID("container_000app_id_temp0Form50_0_i0");      //APP-Auswahlliste
        
    
    return false;
}




/** ruft verschiedenen weitere Javascript-Funktionen auf, um nach Angabe des einzuloggenden Benutzernamens weitere Datenfelder 
 * vorzubereiten.
 * a)   ausgelagert in loginStep0 (02.12.2022)
 * b)   App-ID des Benutzers ermitteln
 * c)   einblenden der AppListe, wenn Zugriff auf mehrere möglich ist.
 * 
 * 
 * @param   {object}    event           Enthält Informationen zum Objekt, welches angeklickt wurde.
 * @returns {Boolean}
 */
async function loginStep1(event) {
    var currentElementID = getIdFromEventelement(event);
    var app_id = "";
    
    showWaitBox();
    
    
    
    //zu b): App-ID des Nutzers ermitteln. Wenn der Nutzer nur auf eine App-ID zugreifen darf, dann wird das Feld entsprechend vorbelegt.
    await loadDependingData(event, 'SYS01.functions_ajaxrequest.getAppByAccount.accountFieldId.387.targetFieldId.7560');  //Anwendung_temp (input-text-field)
    app_id = global_feedback;
    
    //Der folgende Befehl funktioniert leider nicht. Der value des Selects lässt sich nicht setzen
//    loadDependingData(event, 'SYS01.functions_ajaxrequest.getAppByAccount.accountFieldId.387.targetFieldId.7542');  //Anwendung (input-select-field)
//    sleep(1000);

    
    //Feld App-ID (Select) ausblenden, wenn der Nutzer auf nur eine APP-ID oder gar keine App zugreifen darf.
    var DomID_of_appidSelect_field = getValueFromFieldIDOfSameDatarow(currentElementID, "7542", 4);
//    alert("app_id: " + app_id);
    inputSelectApp = document.getElementById(DomID_of_appidSelect_field);
    if(app_id === "noAppFound") {
        //Nutzer hat keinen Zugriff auf eine APP
        inputSelectApp.parentNode.style.visibility = 'hidden';
        setRequiredToInputField(inputSelectApp, false);
    } else if(app_id.substring(0,5) === "error") {
        //Wenn das Formular in forms_backup der Session nicht gefunden werden konnte oder die Session nicht mehr existiert
        showErrorMessageAndMarkDependingFields2 (app_id, false);
        
    } else if(app_id === "chooseOneApp") {
        //Wenn das Feld nicht belegt ist, dann hat der Nutzer auf mehr als eine App Zugriff und muss sich entscheiden.
        inputSelectApp.parentNode.style.visibility = 'visible';
        setRequiredToInputField(inputSelectApp, true);
    } else {
        //Der Nutzer hat Zugriff auf genau eine APP. Diese wurde bereits in das Feld App_id (7560) eingetragen
        inputSelectApp.parentNode.style.visibility = 'hidden';
        setRequiredToInputField(inputSelectApp, false);
    }
    
    
    //erst am Ende den Login-Button aktivieren.
    enableButtonsInForm(50, "validate");
    hideWaitBox();
    
    
    return false;                                                               //Um das Neuladen der Maske zu unterdrücken, wird immer false zurückgegeben.
    
}










/** Setzt das Attribut trequired und ergänzt die entsprechende css-Klasse
 * 
 * @param {object}  element     DOM-Element, welches geändert werden soll
 * @param {boolean} required    true or false
 * @returns {undefined}
 */
function setRequiredToInputField(element, required) {
    if(element != null) {
        if(required === true) {
            element.required = true;
            element.classList.add('field_content_left_required');
            element.style.color = "";
        } else {
            element.required = false;
            element.classList.remove('field_content_left_required');
            element.classList.remove('field_content_default_required');
            element.style.color = "lightgrey";
            
        }
    }
}













/** ruft Ajax-Funktionen auf, die in Feld.js_click_params oder feld.js_change_params definiert sind.
 * Die Rückgabewerte werden in der abhängigen Felder übergeben. Die abhängigen Felder werden auf der Serverseite
 * in den aufgerufenen Funktionen definiert.
 * 
 * @param   {object}    event           Enthält Informationen zum Objekt, welches angeklickt wurde.
 * @param   {string}    targetFunction  Enthält den Funktionsaufruf auf der Serverseite (siehe feld.js_click_params)
 * @returns {Boolean}
 */
async function loadDependingData(event, targetFunction) {
    return new Promise(resolve => {
        var currentElement = getIdFromEventelement(event);                                                  //Element ermitteln
        var targetFunctionName = targetFunction;						
        var targetMethodName = "getFeedbackFromPhpFunction";  
        var formID = jQuery("#"+currentElement).attr("data-formid");
        var senderFieldId = jQuery("#"+currentElement).attr("data-feldid");
        
    //    alert("Abfrage für ID: " + currentElement + ", targetFunctionName: " + targetFunctionName + " targetMethodName: " + targetMethodName);

        //Daten der gesamten aktuellen Zeile (des aktuellen Datensatzes ermitteln)
        var rowFieldList = getDataFromCurrentRow(currentElement);



        //AjaxRequest
        jQuery.ajax({											//Serveranfrage
                url: "ajaxRequest.php",			
                data: {targetMethod: targetMethodName, function_name: targetFunctionName, row_field_list: rowFieldList, form_id: formID, sender_field_id: senderFieldId},
                datatype: "json",
                type: "POST",
                success: function(data) { 
                    setDataInFields(data, currentElement); 
                }                                            //Aufruf der Funktion, die die antwort des Servers auswertet
        });
        setTimeout(() => {
            resolve('resolve');
        }, 1500);
    });
    
                                                                 
}




/** Ändert die CSS-Eigenschaft "required" eines HTML-Elements. Es wird zudem die entsprechende CSS-Klasse gesetzt.
 * 
 * @param   {oject}     event               auslösendes DOM-Element
 * @param   {type}      targetFieldString   Liste der zu ändernden Felder. 
 *                                          Bsp.: '9704|||true_____9684|||false'
 *                                          Feld 9704 -> required = true
 *                                          Feld 9684 -> required = false
 * @returns {undefined}
 */
function changeRequiredAttributForFieldlist(event, targetFieldString) {
    
    var currentElement = getIdFromEventelement(event);                                                  //Element ermitteln


    if (targetFieldString !== "") {
        //Fieldliste in Array umwandeln
        if(targetFieldString.includes(delimiterFields)) {
            //Wenn in dem String (desc) mehrere Felder inkl. value übergeben wurden
            var targetFieldList =  targetFieldString.split(delimiterFields); 
        } else {
            //Wenn in dem String desc nur ein Feld inkl. value übergeben wurde
            var targetFieldList = [targetFieldString];
        }

        var fieldAttributs;
        var i; 

        for (i = 0; i < targetFieldList.length; i++) {
            fieldAttributs = targetFieldList[i].split(delimiterFieldAttribut);          //fieldAttributs[0] = Field-ID; fieldAttributs[1] = boolean (required)
            var DomID_of_target_field = getValueFromFieldIDOfSameDatarow(currentElement, fieldAttributs[0], 4);
            var DomID_of_target_field_chosen = DomID_of_target_field+"_chosen";
//            alert("setze value: " + fieldAttributs[1] + " in field (Dom-ID): " + currentFieldDomId);
            if (DomID_of_target_field !== false) {

                var targetField = document.getElementById(DomID_of_target_field);
                var targetField_chosen = document.getElementById(DomID_of_target_field_chosen);
                
                if(fieldAttributs[1] === "true") {
                    //targetField als required kennzeichnen
                    setRequiredToInputField(targetField, true);
                    if (targetField_chosen != null) {setRequiredToInputField(targetField_chosen, true);}
                } else {
                    //targetField als nicht-required kennzeichnen
                    setRequiredToInputField(targetField, false);
                    //Inhalt des Feldes löschen
                    setValueInField(DomID_of_target_field, "", false)
                    if (targetField_chosen != null) {
                        setRequiredToInputField(targetField_chosen, false);
                        //Inhalt des Feldes löschen
                        setValueInField(DomID_of_target_field_chosen, "", false)
                    }
                }
                   
            }
            
        }
    }                                            
}





function changeRequireAndLoadDependingData(event, targetFieldString, targetFunction) {
    
    changeRequiredAttributForFieldlist(event, targetFieldString);
    loadDependingData(event, targetFunction);
                                       
}





/** ruft Ajax-Funktionen auf, die in Feld.js_click_params oder feld.js_change_params definiert sind.
 * Die Rückgabewerte werden in der Feedbackbox ausgegebe. Außerdem werden die zu prüfenden Felder rot markiert.
 * 
 * @param   {object}    event           Enthält Informationen zum Objekt, welches angeklickt wurde.
 * @param   {string}    targetFunction  Enthält den Funktionsaufruf auf der Serverseite (siehe feld.js_click_params)
 * @returns {Boolean}
 */
function checkFieldValue(event, targetFunction) {
    
    var currentElement = getIdFromEventelement(event);                                                  //Element ermitteln
    var targetFunctionName = targetFunction;						
    var targetMethodName = "getFeedbackFromPhpFunction";  
    var formID = jQuery("#"+currentElement).attr("data-formid");
    var senderFieldId = jQuery("#"+currentElement).attr("data-feldid");
 
//    alert("Abfrage für ID: " + currentElement + ", targetFunctionName: " + targetFunctionName + " targetMethodName: " + targetMethodName);
    
    //Daten der gesamten aktuellen Zeile (des aktuellen Datensatzes ermitteln)
    var rowFieldList = getDataFromCurrentRow(currentElement);
    
    
    
    //AjaxRequest
    jQuery.ajax({											//Serveranfrage
            url: "ajaxRequest.php",			
            data: {targetMethod: targetMethodName, function_name: targetFunctionName, row_field_list: rowFieldList, form_id: formID, sender_field_id: senderFieldId},
            datatype: "json",
            type: "POST",
            success: function(data) { showErrorMessageAndMarkDependingFields(data, false); }                                            //Aufruf der Funktion, die die antwort des Servers auswertet
    });
    
    
    return false;                                                               //Um das Neuladen der Maske zu unterdrücken, wird immer false zurückgegeben.
    
}



/** Weist dem übergebenen tagretElement den Wert zu. Dabei wird auf die Besonderheiten von Checkboxen und Select-Feldern eingegangen.
 * 
 * @param {string}  in_targetDomElementId       ID eines Elements im DOM
 * @param {mixed}   in_value                    Wert, der dem Element zugewiesen werden sollen
 * @param {bool]    in_start_onchange           Gibt an, ob eine ggfs. vorhandenen on_change-Funktion angestoßen werden soll.
 * @returns {undefined}
 */
function setValueInField(in_targetDomElementId, in_value, in_start_onchange) {
    //Element suchen
    var myElement = document.getElementById(in_targetDomElementId);
    var hidden_targetDomElementId = in_targetDomElementId + "_hidden";          //bei geschützten Checkboxen existiert auch noch ein hidden-Element
    var myElementHidden = document.getElementById(hidden_targetDomElementId);
    //tag auslesen
    var tagname = myElement.tagName;
//    alert("tagname = "+tagname + " - type = "+myElement.getAttribute("type") + " - value = "+ in_value)
    
        //wenn Select, dann selected setzen
        //wenn input, dann type auslesen
        if(tagname.toString().toLowerCase() == "input") {
            if(myElement.getAttribute("type") == "checkbox") {
                
                if(in_value == "1") { 
                    myElement.checked = true;
                    myElement.value = in_value;
//                    alert(myElementHidden.id);
                    if(myElementHidden !== null) {myElementHidden.checked = true; myElementHidden.value = in_value;}
                } else {
                    myElement.checked = false; 
                    if(myElementHidden !== null) {myElementHidden.checked = false; myElementHidden.value = in_value;}
                }
            } else  {
                myElement.value = in_value;
            }
        } else if (tagname.toString().toLowerCase() == "select") {
            myElement.value = in_value;
            
        } else if (tagname.toString().toLowerCase() == "label") {
            //falls es sich um ein label handelt, dann prüfen, ob es ein weiteres namensgleiches verstecktes Element gibt
            if(typeof(myElementHidden) != 'undefined' && myElementHidden != null){
                myElementHidden.value = in_value;
            }
            myElement.textContent = in_value;
        }
        
        //Falls an dem targetFeld ein onchange-Ereignis oder ein onblur-Ereignis geknüpft ist, dann wird dieses nun ausgelöst
//        alert("in_start_onchange "+in_start_onchange)
        if(typeof(myElement.onchange) != 'undefined' && myElement.onchange != null && in_start_onchange == true){
            myElement.dispatchEvent(new Event('change'));
        }
        if(typeof(myElement.onblur) != 'undefined' && myElement.onblur != null && in_start_onchange == true){
            myElement.dispatchEvent(new Event('blur'));
        }
}



/** trägt eine Liste von Werten in die entsprechenden Zielfelder ein.
 * 
 * @param   {string}    in_data             Rückgabewerte von einer PHP-Funktion im Json-Format:  {"desc":"5784|||1_____5888|||true_____5999|||Albert"}  -> "_____" = Feldtrenner; "|||" = Attributtrenner  -> {"desc":"Feld_id|||value"}
 * @param   {string}    in_eventElement     ID des DOM-Elements der aktuellen Datenzeile, welches den Prozess angestoßen hat. Bsp.: "0allg0permission_bst0access_uid0Form922_0_i0new"
 * @returns {mixed}                         Gibt den letzten eingetragenen Wert oder false (wenn kein) Wert existierte, zurück
 */
function setDataInFields(in_data, in_eventElement ) {
    //    alert("Antwort von Request: " + in_data);
        var response = JSON.parse(in_data);
        var targetFieldString = response.desc;
        var feedback = "";

//        alert("data: " + targetFieldString + ", currentEllemntId: " + in_eventElement);

        
        if (targetFieldString.substring(0,5) === "error") {
            global_feedback = targetFieldString;
        } else if (targetFieldString != "") {
            var currentFieldDomId;
            if(targetFieldString.includes(delimiterFields)) {
                //Wenn in dem String (desc) mehrere Felder inkl. value übergeben wurden
                var targetFieldList =  targetFieldString.split(delimiterFields); 
            } else {
                //Wenn in dem String desc nur ein Feld inkl. value übergeben wurde
                var targetFieldList = [targetFieldString];
            }
            var fieldAttributs;
            var i; 

            for (i = 0; i < targetFieldList.length; i++) {
                fieldAttributs = targetFieldList[i].split(delimiterFieldAttribut);          //fieldAttributs[0] = Field-ID; fieldAttributs[1] = value
                currentFieldDomId = getValueFromFieldIDOfSameDatarow(in_eventElement, fieldAttributs[0], 4);
//                alert("setze value: " + fieldAttributs[1] + " in field (Dom-ID): " + currentFieldDomId);
                if (currentFieldDomId != false) {
                    setValueInField(currentFieldDomId, fieldAttributs[1], true);
                    global_feedback = fieldAttributs[1];
                }
            }
        }
        
}









/** Ermittelt den Inhalt eines Feldes, welches sich in der gleichen Datarow befindet, wie das Element, welches das Javascript angestoßen hat.
 * 
 * @param   {string}    currentElement          ID des HTML-Elements, welches das Javascript ausgelöst hat und sich in der gleichen datarow, wie taregetElement befindet
 * @param   {string}    targetElementFieldID    FeldID eines gesuchten Feldes, dessen Value ermittelt werden soll.
 * @param   {integer)   valueType               Welche Information wird benötigt? 0 = FormID, 1 = FieldAppID, 3 = FieldContent, 4 = DomID des Feldes
 * @returns {string|Boolean}                    Gibt entweder den Feldinhalt wieder oder false, falls das targetElement nicht ermittelt werden konnte.
 */
function getValueFromFieldIDOfSameDatarow(currentElement, targetElementFieldID, valueType) {															
    var rowFieldList = getDataFromCurrentRow(currentElement);                   //Bsp.: "212|||BIM01|||2025|||00029301|||0allg0permission_bst0bst0Form212_0_i0new_____212|||BIM01|||2024||||||0allg0permission_bst0uid0Form212_0_i0new"
    var fieldlist =  rowFieldList.split(delimiterFields);                       //Bsp.: 212|||BIM01|||2025|||00029301|||0allg0permission_bst0bst0Form212_0_i0new,212|||BIM01|||2024||||||0allg0permission_bst0uid0Form212_0_i0new...                  
    var feedback = false;
    //alert("Values in row: " + fieldlist);
    //showFeedbackBox2(fieldlist);
    
    //Die Liste der Felder durchwandern, um das Feld mit der angegebenen FieldID zu suchen
    for (var i=0;i<fieldlist.length;i++) {
        var fieldString = fieldlist[i];                                         //Bsp.:null|||null|||1398|||mark
        var fieldAttributs = fieldString.split(delimiterFieldAttribut);         //Bsp.:null,null,1398,mark
        var fieldID = fieldAttributs[2];                                        //Bsp.: 1398
        if (targetElementFieldID == fieldID) {
            //FieldID wurde gefunden
            feedback = fieldAttributs[valueType];                               
            
        }
    }
    return feedback;
}


/**
 * 
 * @param   {string} id         ID des DOM-Elementes
 * @returns {string}            String oder Leerstring
 */
function getInnerHtmlFromDomElement(id) {
    var my_element = document.getElementById(id);
    var feedback = "";
    if(my_element !== null) {
        var feedback = my_element.innerHTML;
    }  
    return feedback;
}




/** Ermittelt alle Elemente und deren aktuellen Value einer Datenzeile und gibt diese in einem String (eigene seriliazed Variante) zurück. Der Rückgabewert ist ein s
 * String, damit dieser per ajax an den Server übermittelt werden kann. Ein Array müsste erst decodiert werden.
 * Die Funktion geht davon aus, dass übergebenen Element ein Feld der aktiven Datenzeile ist. Zudem befindet sich der row_node zwei Ebenen höher.
 * 
 * @param {string} elementOfRow         ID eines beliebigen Elements der Datenzeile
 * @returns {string}                    String mit den Werten (FormID, FieldAppID, FieldID, FieldContent) von allen Elementen der Zeile, in der sich elementOfRow befindet.
 *                                      Die einzelnen Feldattribute werden durch 3 Unterstriche getrennt. Felder werden durch 5 Unterstiche getrennt.
 *                                      Bsp.: "212|||BIM01|||2025|||00029301|||0allg0permission_bst0bst0Form212_0_i0new_____212|||BIM01|||2024||||||0allg0permission_bst0uid0Form212_0_i0new"
 */
function getDataFromCurrentRow(elementOfRow) {
    
    var parent2;
    var myChildNodes;
    var myChildNodes2;

    var myField = "";
    var myRow = "";
    
    
    parent2 = document.getElementById(elementOfRow).parentNode.parentNode; 
    myChildNodes = parent2.childNodes;
//    alert("Anzahl ChildNotes: " + myChildNodes.length + " Name of currentElement: " + parent2.nodeName);
    for (var i=0;i<myChildNodes.length;i++) {
//        Childnodes der Ebene 1 durchlaufen. Auf dieser Ebene befinden sich noch nicht die Eingabefelder.
        try {
            //Auf Ebene 1 werden auch die Childnodes der Ebene 2 gezählt aber nur als #text ausgegeben. Daher ist der Try-Block notwendig.
            myChildNodes2 = myChildNodes[i].childNodes;
            for (var x=0;x<myChildNodes2.length;x++) {
                //Childnodes der Ebene 2 enthalten die Eingabefelder
                try {
                    
                    var currentFieldID = myChildNodes2[x].getAttribute("data-feldid");
                    //var currentNodeName = myChildNodes2[x].nodeName;
                    if (currentFieldID === null) { 
                        //nix tun
                    } else {
//                        alert("Ebene 2 FeldID: " + currentFieldID);
                        //hier virtuelles Array als String aufbauen (String lässt sich leichter per ajax übertragen
                        //var currentIdInDOM = myChildNodes2[x].getAttribute("id");
                        var currentFieldAppID = myChildNodes2[x].getAttribute("data-feldappid");
                        var currentFieldContent = myChildNodes2[x].value;
                        var currentFormID = myChildNodes2[x].getAttribute("data-formid");
                        var currentIdInDom = myChildNodes2[x].getAttribute("id");
                        myField =   currentFormID + delimiterFieldAttribut +
                                    currentFieldAppID + delimiterFieldAttribut +
                                    currentFieldID + delimiterFieldAttribut + 
                                    currentFieldContent + delimiterFieldAttribut + 
                                    currentIdInDom;
//                        alert("Ebene 2 FeldID: " + currentFieldID + " - Field for ajax" + myField);
                        //Aktuelles Feld der Zeile hinzufügen
                        if (myRow === "") {
                            //wenn das erste Feld zu myRow ergänzt wird
                            myRow = myField;
                        } else {
                            //wen ein weiteres Feld zu myRow ergänzt wird.
                            myRow = myRow + delimiterFields + myField;
                        }
                    }
                } catch(err) {
                    
                }
                
            }
            
        } catch(err) {
            //irrelevanter ChildNode
            
        }
    } 
    
    return myRow;
}


/** Prüft ob der gesuchte String im Value eines der Felder der angegebenen Zeile enthalten ist.
 * 
 * @param {object}  currentRow                          DomElement (div_row_table)
 * @param {string}  searchValue                         Ein String, der in den Feldern der Row gesucht wird
 * @param {bool}    uncheckMarkfieldIfValueNotFound     Wenn Suchstring in der Zeile nicht gefunden wird, dann das Markierungsfeld unchecken und kennzeichnen, als ds_hide = true
 *          
 * @returns {bool}
 */
function isValueInRow(currentRow, searchValue, uncheckMarkfieldIfValueNotFound) {
    
    var myChildNodes;
    var myChildNodes2;
    var feedback = false;
    var markField = "undefined";
    var markFields;
    
    var searchValue_lowercase = searchValue.toLowerCase();
    
    
    myChildNodes = currentRow.childNodes;
//    alert("Anzahl ChildNotes: " + myChildNodes.length + " Name of currentElement: " + currentRow.nodeName);
    for (var i=0;i<myChildNodes.length;i++) {
        //Childnodes der Ebene 1 durchlaufen. Auf dieser Ebene befinden sich noch nicht die Eingabefelder.
        try {
            //Auf Ebene 1 werden auch die Childnodes der Ebene 2 gezählt aber nur als #text ausgegeben. Daher ist der Try-Block notwendig.
            myChildNodes2 = myChildNodes[i].childNodes;
            for (var x=0;x<myChildNodes2.length;x++) {
                //Childnodes der Ebene 2 enthalten die Eingabefelder
                try {
                    
                    var currentFieldID = myChildNodes2[x].getAttribute("data-feldid");
//                    alert('Feld-ID: '+currentFieldID);
                    //var currentNodeName = myChildNodes2[x].nodeName;
                    if (currentFieldID === null) { 
                        //nix tun
                    } else {
                        //Content des aktuellen Feldes ermitteln
                        if(myChildNodes2[x].nodeName === 'LABEL') {
                            var currentFieldContent = myChildNodes2[x].innerHTML;
                        } else if (myChildNodes2[x].nodeName === 'SELECT') {
                            var selectedIndex = myChildNodes2[x].selectedIndex;
                            var optionList = myChildNodes2[x].options;
                            var currentFieldContent =optionList[selectedIndex].text;;
                        } else {
                            var currentFieldContent = myChildNodes2[x].value;
                        }
                        
                        var currentFieldIDString = currentFieldID.toString();
//                        alert("Zeile 741 (currentFieldIDString): " + currentFieldIDString);
//                        alert("Zeile 742 (indexOf): " + currentFieldIDString + " - " + currentFieldIDString.indexOf("markField"));
                        if(currentFieldIDString.indexOf("markField") > -1) {
                            //Wenn das aktuelle Feld das Markierungsfeld des aktuellen Datensatzes ist, dann dieses "merken", um es ggf. Ändern zu können.
                            markFields = myChildNodes2[x].childNodes;
                            markField = markFields[1];
                        }
                        
                        var currentString = currentFieldContent.toString();
                        var currentFieldContent_lowercase = currentString.toLowerCase();
                        if(currentFieldContent_lowercase.indexOf(searchValue_lowercase) > -1) {feedback = true;}
                        
                    }
                } catch(err) {
                    
                }
                
            }
            
        } catch(err) {
            //irrelevanter ChildNode
            
        }
    } 
    
    if(markField != "undefined") {
        if(feedback !== true && uncheckMarkfieldIfValueNotFound == true) {
            //Wenn der Suchstring nicht gefunden wurde und der Datensatz ausgebldent wird, dann das Markierungsfeld unchecken und Attribut ds_hide auf "true" setzen.
            markField.checked = false;
            markField.setAttribute("data-ds_hide", "true");
        } else {
    //        alert("Zeile 772: " + currentFieldIDString);
            markField.setAttribute("data-ds_hide", "false");
        }
    }
    
    return feedback;
}



/** Ergänzt zur aktuellen Zeile die Klasse "used_data" und entfernt vorher die Klasse bei allen anderen Elementen.
 * 
 * @param   {String}          elementOfRow        ID eines Feldes der aktuellen Zeile
 * @returns {nothing}
 */
function markRowAsUsed(elementOfRow) {
    
    var row;
    
    //alle Vorkommen von used_data entfernen
    unmarkRowAsUsed(class_usedRows);
    
    //Datenzeile von elementOfRow ermitteln
    row = document.getElementById(elementOfRow).parentNode.parentNode; 
    
//    alert("aktuelles Element: " +document.getElementById(elementOfRow).getAttribute("name"));
//    alert("aktuelle Zeile: " + row.getAttribute("name"));
    
    
    //class used_data ergänzen
    row.className += " "+class_usedRows;
    
}


/** alle Vorkommen von used_data entfernen
 * 
 * @param   {String}     cls  Name der Klasse, welche zur Markierung von used rows genutzt wird.
 * @returns {undefined}
 */
function unmarkRowAsUsed(cls) {
    var meineElemente = document.getElementsByClassName(cls);
    var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
    for(var i = 0; i < meineElemente.length; i++) {
        meineElemente[i].className=meineElemente[i].className.replace(reg,' ');
    }
}





/** ändert den Inhalt eines HTML-Elements
 * 
 * @param {String}  HtmlElementID   ID des HTML-Elements, dessen Inhalt geändert werden soll
 * @param {array}   data            response des ajax-Requests von updateDependingFields; Bsp.:
 *                                  Array
 *                                       (
 *                                           [0] => Array
 *                                               (
 *                                                   [form_id] => 12
 *                                                   [field_app_id] => SYS01
 *                                                   [field_id] => 121
 *                                                   [optionlist] => <option value=""></option>
 *                                                                   <option value="1">Sys-Admin WIDER</option>
 *                                                                   <option value="13">Widerspruch-SB-A</option>
 *                                                                   <option value="21">Widerspruch-SB-B</option>
 *                                                                   <option value="26">Widerspruch-Test</option>
 *
 *                                               )
 *
 *                                       )
 * @returns {undefined}
 */
function changeHtmlElementContent(HtmlElementID, data) {
    
//    alert("ungeparste Antwort von ajaxRequest: " + data);
    var response = jQuery.parseJSON(data);					//parsed den Rückgabewert des Servers
//    var response = JSON.parse(data);
    var optionList = [];
    var target_column = "";
    var trigger_column = "";
    var id_parts = [];
    var targetHtmlElementID = "";
    
    
    /*-----------------------------------------------------------------
     * ACHTUNG:
     * Die Alert-Funktion kann an dieser Stelle zu Problemen führen.
     * Offenbar wird der response-Wert zo verändert, dass er nicht mehr
     * als gültiges Objekt erkannt wird.
     * ----------------------------------------------------------------
     */
//    alert("Antwort von ajaxRequest: " + response);
    jQuery.each(response, function() {
        //der Rückgabewert von ajaxRequest kann neue Optionlists für mehrere TargetFelder enthalten. Diese Schleife durchläuft alle TargetFelder. Das entspricht der ersten Ebene des Arrays.
//        alert("Feld: " + i);
        jQuery.each(this, function(key_ebene2, value_ebene2) {
            //Die zweite Ebene des Arrays enthält Attribute zu einem bestimmten TargetField
            
//            alert("Rückgabe von AjaxRequest: key: " + key_ebene2 + " - Value: " + value_ebene2);
            // 1. Value für optionlist  ermitteln
            if (key_ebene2 === "optionlist") { optionList = value_ebene2;} 
            else if (key_ebene2 === "target_field_column") { target_column = value_ebene2;}
            else if (key_ebene2 === "trigger_field_column") { trigger_column = value_ebene2;}
            
        });
        
        //splittet den String, welcher die id des sendenden HTML-tags enthält in zwei Bestandteile (Trennstelle = trigger_column) und entfernt dabei die trigger_column (Bsp.: triggerHtmlID: manager0account_has_role0role_app_id0Form12_0_i0; trigger_column = role_app_id)
        id_parts = HtmlElementID.split(global_trennzeichen + trigger_column + global_trennzeichen);                    
        
        //target-tag-ID bilden, dabei statt trigger_column neu die target_column einsetzen
        targetHtmlElementID = id_parts[0] + global_trennzeichen + target_column + global_trennzeichen + id_parts[1];
//        alert("Optionlist einsetzen in : " + targetHtmlElementID);
        jQuery("#"+targetHtmlElementID).html(optionList);
        
        //falls das chosen-Plugin aktiv ist werden die alten chosen-Tags im target-Field gelöscht und neu aufgebaut
        if (document.getElementById(targetHtmlElementID+"_chosen")) {
            jQuery("#"+targetHtmlElementID).trigger("chosen:updated");
        }

    });
    
 

}








/** Fragt die Beschreibung eines Formulars per ajax-Request vom Server ab und übergibt das Ergebnis an showFeedbackBox
 * 
 * @param   {object}    event       Enthält Informationen zum Objekt, welches angeklickt wurde.
 * @returns {false}                 Die Funktion gibt immer false zurück, damit das Neuladen der Maske unterdrükt wird. 
 */
function getFormDescription(event) {
    var formaction_target = getValueFromEventelementAttribut(event, 'formaction');
    var maskapp = getParamvalueFromAGivenUrlString(formaction_target, 'maskapp');
    var formId = getParamvalueFromAGivenUrlString(formaction_target, 'form_id');
    
    
    
    var targetMethodName = "getFormdescription";                                //Name der Methode, die per ajax am Server angesprochen werden soll

    jQuery.ajax({                                                               //Serveranfrage
                    url: "ajaxRequest.php",			
                    data: { appID: maskapp, formID: formId, targetMethod: targetMethodName },
                    datatype: "json",
                    type: "POST",
                    success: function(data) { showFeedbackBox(data); }                //Aufruf der Funktion, die die antwort des Servers auswertet
//                  ,error: function() { alert('Error occured');}

                });
    
    return false;                                                               //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)
}




/** Gibt eine Meldung (aus der Tabelle konstante) aus, wenn eine Checkbox abgewählt wird.
 * Die Funktion kann mit einem Ereignishandler einer Checkbox verbunden werden (Bsp.: onchange).
 * 
 * @param   {object}    event           auslösendes Element (Checkbox)
 * @param   {string}    in_appID        APP-ID der Meldung in der Tabelle konstante
 * @param   {integer}   in_messageID    ID der Meldung (siehe Spalte konstante.wert
 * @returns {Boolean}                   Zudem wird die Meldung in FeedbackBox eingeblendet
 */
function getFeedbackMessageIfCheckboxUnselected(event,in_appID,in_messageID) {
    //Typ des Elementes prüfen. Die Funktion ist nur für Checkboxen gedacht
    var currentElementID = getIdFromEventelement(event);						//Element ermitteln
    
    var FieldType = jQuery("#"+currentElementID).attr("type");
//    alert("type = "+FieldType + " - messageID = "+ in_messageID)
    var feedback = true;
        
    if(FieldType == "checkbox") {
        var myCheckbox = document.getElementById(currentElementID);
    
        if(!myCheckbox.checked) {
            feedback = getFeedbackMessage(event,in_appID,in_messageID,false);
        }
    } 
    
     
    return feedback;
}




/** Ermittelt für eine Konstante (Konstante.wert) den Klartext.
 * 
 * @param   {object}    event               auslösendes Element
 * @param   {string}    appID               App-ID der Konstante
 * @param   {string}    messageID           Konstante.wert
 * @param   {Boolean}   param_showWaitBox   [optional] Wenn true, wird das WaitGif bis zum Neuladen der Seite angezeigt, Default = true
 * @returns {Boolean}
 */
function getFeedbackMessage(event,appID,messageID,param_showWaitBox = true) {
    
    
//    alert('Starte showFeedbackMessage')
    var targetMethodName = "getFeedbacktext";                                //Name der Methode, die per ajax am Server angesprochen werden soll
    if(param_showWaitBox == true) {
        showWaitBox();
    }
    
    jQuery.ajax({                                                               //Serveranfrage
                    url: "ajaxRequest.php",
                    async: false,
                    data: { konstantenAppID: appID, konstantenWert: messageID, targetMethod: targetMethodName },
                    datatype: "json",
                    type: "POST",
                    success: function(data) { global_feedback = showFeedbackMessage(data);}                 //Aufruf der Funktion, die die antwort des Servers auswertet
    //              ,error: function() { alert('Error occured');}

                });
    
//    alert("Jetzt bin ich hier. Antwort: "+global_feedback);
    return global_feedback;
}




/** Zeigt eine übegebene Feedback-Message in einem Dialog-Fenster vom System.
 * Der Anwender kann Zustimmen und Ablehnen
 * 
 * @param   {json}      data            Die Antwort muss im Json-Feld "desc" enthalten sein.
 * @param   {boolean}   replace_breaks  Ändert OS-spezifische Zeilenumbrüche (\n) in HTML-Syntax
 * @returns {boolean}
 */
function showFeedbackMessage(data, replace_breaks) {

//    alert("Antwort von Request: " + data);
    var response = JSON.parse(data);
    var antwort = response.desc;
    
//    alert("Antwort von Request: " + antwort);

    //SQL-Zeilenumbrüche durch HTML-Zeilenumbrüche ersetzen
    if (replace_breaks === true) {
        antwort = antwort.replace(/\n/g, "<br />");
    }     
    
   ;
    if (window.confirm(antwort) === true) {
//        alert("ok geklickt")
        return true;
    } else {
//        alert("abbrechen geklickt")
        hideWaitBox();
        return false;
        
    }
    
}



/** Ermittelt aus einem URL-String den Wert eines Parameters
 * Bsp. URL: page.php?mask=6&maskapp=SYS01&form_id=6&button_id=913&button_action_function_id=&button_target=1&form_mode=6
 * 
 * @param {string} urlString    
 * @param {string} paramName    
 * @returns {value des params|String}
 */
function getParamvalueFromAGivenUrlString(urlString, paramName) {
    
    var answer = "";
    var urlParts = urlString.split("?");                                        //part[0] = url, part[1] = params
    var paramsString = urlParts[1];
    params = paramsString.split("&");
    
    for (var i=0;i<params.length;i++) {
        var pair = params[i].split("=");
            // If first entry with this name
        if (pair[0] === paramName) {
            answer = pair[1];
        } 
    } 
    return answer;
}




/** Setzt die CSS-Eigenschaft visibility der hiddenFeedbackBox aud visible.
 * 
 * @param   {object}    data            Antwort eines ajax-Request im json-Format
 * @param   {boolean}   replace_breaks  In der Json-Übergabe befinden sich Textzeilenumbrüche (\n), wenn replace_breaks = true, dann werden diese durch <br /> ersetzt
 * @returns {nothing}
 */
function showFeedbackBox (data, replace_breaks) {

//    alert("Antwort von Request: " + data);
//    console.log(data);
    var response = JSON.parse(data);
    var antwort = response.desc;
    
//    alert("Antwort von Request: " + antwort);

    //SQL-Zeilenumbrüche durch HTML-Zeilenumbrüche ersetzen
    if (replace_breaks === true) {
        antwort = antwort.replace(/\n/g, "<br />");
    }  
    
    if (antwort !== "") {
        document.querySelector("div[data-alt='feedbackBoxBody']").innerHTML = antwort;
        document.querySelector("div[data-alt='hiddenFeedbackBox']").style.visibility = 'visible';
    }
    
}




/** Zeigt eine Fehlermeldung an und verhindert das Absenden des Formulars. 
 * Zudem wird die Liste der genannten Felder markiert.
 * 
 * 
 * @param   {object}    data            Antwort eines ajax-Request im json-Format. 
 *                                      Beispiel: error|||1_____message|||Es gibt bereits einen anderen Datensatz, welcher sich mit dem Jahr <b>2015</b> überschneidet. <br />
 *                                      Prüfen, Sie das angegebene Jahr oder ändern Sie vorab die bereits vorhandenen Datensätze.
 *                                      _____target_field|||7478_____deactivate_submitbutton|||1_____target_domID|||0fin0k_proj_syf0valid_from0Form1110_0_i0new_____formID|||1110_____instanceID|||i0new
 * @param   {boolean}   replace_breaks  In der Json-Übergabe befinden sich Textzeilenumbrüche (\n), wenn replace_breaks = true, dann werden diese durch <br /> ersetzt
 * @returns {nothing}
 */
function showErrorMessageAndMarkDependingFields (data, replace_breaks) {

//    alert("Antwort von Request: " + data);
    var response = JSON.parse(data);
    var antwort = response.desc;
    
//    alert("Antwort von Request: " + antwort);

    showErrorMessageAndMarkDependingFields2(antwort, replace_breaks);
    
    
}




/** Zeigt eine Fehlermeldung an und verhindert das Absenden des Formulars. 
 * Zudem wird die Liste der genannten Felder markiert.
 * 
 * 
 * @param   {string}    message         Antwort eines ajax-Request als string. 
 *                                      Beispiel: error|||1_____message|||Es gibt bereits einen anderen Datensatz, welcher sich mit dem Jahr <b>2015</b> überschneidet. <br />
 *                                      Prüfen, Sie das angegebene Jahr oder ändern Sie vorab die bereits vorhandenen Datensätze.
 *                                      _____target_field|||7478_____deactivate_submitbutton|||1_____target_domID|||0fin0k_proj_syf0valid_from0Form1110_0_i0new_____formID|||1110_____instanceID|||i0new
 * @param   {boolean}   replace_breaks  In der Json-Übergabe befinden sich Textzeilenumbrüche (\n), wenn replace_breaks = true, dann werden diese durch <br /> ersetzt
 * @returns {nothing}
 */
function showErrorMessageAndMarkDependingFields2 (message, replace_breaks) {

    var antwort = message;
    
//    alert("Antwort von Request: " + antwort);

    //SQL-Zeilenumbrüche durch HTML-Zeilenumbrüche ersetzen
    if (replace_breaks === true) {
        antwort = antwort.replace(/\n/g, "<br />");
    }     
    
    
    if (antwort !== "") {
        var error_flag;
        var message;
        var target_field;
        var target_domID;
        var form_id;
        var deactivate_submitbutton;
        var targetFieldList =  antwort.split(delimiterFields); 
        var fieldAttributs;
        var i; 

        for (i = 0; i < targetFieldList.length; i++) {
            fieldAttributs = targetFieldList[i].split(delimiterFieldAttribut);          //fieldAttributs[0] = attributname; fieldAttributs[1] = value
//            alert("Attribut: " + fieldAttributs[0] + " | Value: " + fieldAttributs[1]);
            if (fieldAttributs[0] == "error") {error_flag = fieldAttributs[1];}
            else if (fieldAttributs[0] == "message") {message = fieldAttributs[1];}
            else if (fieldAttributs[0] == "target_field") {target_field = fieldAttributs[1];}
            else if (fieldAttributs[0] == "deactivate_submitbutton") {deactivate_submitbutton = fieldAttributs[1];}
            else if (fieldAttributs[0] == "target_domID") {target_domID = fieldAttributs[1];}
            else if (fieldAttributs[0] == "data-formid") {form_id = fieldAttributs[1];}
        }
    }
    
    
    
    
    //depending Fields markieren
    if(error_flag == 0) {
        jQuery("#"+target_domID).removeClass("highlight_field");
        if(deactivate_submitbutton == 0) {enableButtonsInForm(form_id, "validate");}
        $feedback = true;

    } else {
        showFeedbackBox2(message);
        jQuery("#"+target_domID).addClass("highlight_field");
        if(deactivate_submitbutton == 1) {disableButtonsInForm(form_id, "validate");}
        $feedback = false;

    }
    
    
}







/** Setzt die CSS-Eigenschaft visibility der hiddenFeedbackBox aud visible.
 * Für echte Feedbackmeldungen an den USer ist es besser die Feedbackbox zu nutzen, statt der alert-Funktion von js.
 * Meldungen der Alert-Funktionen könnten durch den Browser geblockt werden. Zudem können Feedbackbox-Meldungen
 * ansprechender gestaltet werden.
 * 
 * @param   {string}    message    Text, der Angezeigt werden soll. Dieser kann html-Syntax enthalten, welche interpretiert wird.
 * @returns {nothing}
 */
function showFeedbackBox2(message) {
    
    document.querySelector("div[data-alt='feedbackBoxBody']").innerHTML = message;
    document.querySelector("div[data-alt='hiddenFeedbackBox']").style.visibility = 'visible';
    
}





/** Ändert die CSS-Eigenschaft visibility des div mit dem Attribut (alt = hiddenFeedbackBox) auf "hidden"
 * 
 * @returns false       Der Rückgabewert ist immer false, damit das Neuladen der Maske abgebrochen wird.
 */
function hideFeedbackBox() {
    document.querySelector("div[data-alt='hiddenFeedbackBox']").style.visibility = 'hidden';
    //document.getElementById('hiddendiv').style.visibility = 'visible';
    
    //alle Vorkommen von used_data entfernen
    unmarkRowAsUsed(class_usedRows);
    
    
    return false;                                                               //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)

}





/** Setzt die CSS-Eigenschaft visibility eines ausgeblendeten Formulars auf visible.
 * 
 * @param   {object}    event   Objekt, welches auf der Maske angeklickt wurde
 * @returns {boolean}           Funktion gibt immer false zurück, damit formaction nicht ausgeführt wird, sonst würde eine neue URL geladen werden.
 */
function showHiddenForm(event) {
    //Form-ID und Instanz anhand des Button_Namens ermitteln
    var form_id = getValueFromEventelementAttribut(event, 'data-formid');
    var button_name = getValueFromEventelementAttribut(event, 'name');
    var instance_id = getInstanceIdFromButtonname(button_name);
    
    //Formular mit der entsprechenden Form-ID und Instanz einblenden
    var id_new_form = "hiddenForm" + form_id + "_" + instance_id + "new";
    //alert("id_new_form: "+id_new_form);
    
    document.getElementById(id_new_form).style.visibility = 'visible';
    showBarrier();
    return false;                                                               //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)


}



/** Sucht Zeilen, die mindestens ein Feld enthalten, dass dem eingegebenen Suchstring enthält und blendet diese aus.
 * 
 * @param   {object}        event       DOM-Objekt, welches diese Funktion aufgerufen hat
 * @returns {Boolean}                   Rückgabe ist immer false, damit die Maske nicht neugeladen wird.
 */
function searchRows(event) {
    //Form-ID und Instanz anhand des Button_Namens ermitteln
//    var form_id = getValueFromEventelementAttribut(event, 'data-formid');            //Form_id, in dem das event-Element angeordnet wurde
    let button_name = getValueFromEventelementAttribut(event, 'name');
    let field_id = getIdFromEventelement(event);
    let instance_id = getInstanceIdFromButtonname(button_name);
    let targetform_id = getFormidFromButtonname(button_name);                              //Form-ID auf den sich der Button bezieht.
    let countFieldID = "0002850Form"+targetform_id+"_1_"+instance_id;
    let countField = document.getElementById(countFieldID);
    
    let search_value = document.getElementById(field_id).value;
    let row_index = "form" + targetform_id + "instance" + instance_id;
    
    //alert("Durchsuche Zeilen mit Kennzeichnung: " + row_index);
    
    let tbody_id = "div_tbody_form" + targetform_id + "instance" + instance_id;
//    alert("Suche Zeilen von div Kennzeichnung: row_in_form_instanz=" + tbody_id);
    
    
    //Alle Zeilen des aktuellen Formulars ermitteln
    let rows_in_form = document.getElementById(tbody_id).querySelectorAll("div[data-row_in_form_instanz='"+row_index+"']");
    let i;
    let last_action;                                                            //Aktion merken, falls nachfolgend Datenzeilen eines eingebettenen Formulars gefunden werden.
    for (i = 0; i < rows_in_form.length; i++) {
        
//        console.log("Zeile "+i, rows_in_form[i]);
//        console.log("class", rows_in_form[i].getAttribute("class"));
        if(rows_in_form[i].getAttribute("class").search("div_row__afterLineFeed_table") >= 0) {
            //eingebettete Zeile. Daher wird die selbe Aktion angewendet, wie bei der vorherigen Zeile
//            console.log("Zeile "+i, "eingebettet");
            if(last_action === "show") {
                rows_in_form[i].style.display = 'inherit'; 
            } else if(last_action === "hide") {
                rows_in_form[i].style.display = 'none';
            } else {
                //nichts tun
            }
            
        } else if(isValueInRow(rows_in_form[i], search_value, true) === true) {
            
            if(rows_in_form[i].style.display === 'none') {
                //Datensatz einblenden
                rows_in_form[i].style.display = 'inherit'; 
                //Anzahl der Datensätze neu berechnen
                if(typeof(countField) != 'undefined' && countField != null) {countField.value = Number(countField.value) + Number(1);}
                last_action = "show";
            } else {
                last_action = "do_noting";
            }
            
        } else {
            //Anzahl der Datensätze neu berechnen
            if(rows_in_form[i].style.display !== 'none') {
                //Datensatz ausblenden
                rows_in_form[i].style.display = 'none';
                //Anzahl der Datensätze neu berechnen
                if(typeof(countField) != 'undefined' && countField != null) {countField.value = Number(countField.value) - Number(1);}
                last_action = "hide";
            } else {
                last_action = "do_noting";
            }
            
            
        }  
    }
    
    //Zeilenweise alle Felder prüfen, wenn Suchstring nicht vorhanden, dann Zeile ausblenden
  
//    document.getElementById(id_new_form).style.visibility = 'visible';

    return false;                                                               //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)


}




/** Setzt die CSS-Eigenschaft visibility des ausgeblendeten Formulars (neue Seite) auf visible.
 * 
 * @param   {integer}    id     ID des Formulars; Dieses muss in Hochkommata beim Aufruf angegeben werden. Bsp.: 'div_620'
 * @returns {boolean}           Funktion gibt immer false zurück, damit formaction nicht ausgeführt wird, sonst würde eine neue URL geladen werden.
 */
function showHiddenFormByID(id) {
    
//    window.confirm("Starte mit Form: "+id);   

    document.getElementById(id).style.visibility = 'visible';
    
    showBarrier();
    return false;                                                               //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)
}



/** Setzt die CSS-Eigenschaft visibility eines Formulars auf hidden.
 * Diese Funktion ist für Buttons in einer Symbolleiste geeignet.
 * 
 * @param   {object}    event   Objekt, welches auf der Maske angeklickt wurde
 * @returns {boolean}           Funktion gibt immer false zurück, damit formaction nicht ausgeführt wird, sonst würde eine neue URL geladen werden.
 */
function hideForm(event) {
    //Form-ID und Instanz anhand des Button_Namens ermitteln
    var form_id = getValueFromEventelementAttribut(event, 'data-formid');
    var button_name = getValueFromEventelementAttribut(event, 'name');
    var instance_id = getInstanceIdFromButtonname(button_name);
    
    //Formular mit der entsprechenden Form-ID und Instanz ausblenden
    try {
        //Variante für inew-Formulare
        var id_hidden_form = "hiddenForm" + form_id + "_" + instance_id;
//        alert("Suche Form: " + id_hidden_form);
        document.getElementById(id_hidden_form).style.visibility = 'hidden';
        hideBarrier();                      //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)
        return false;
    } finally {
        //Variante für freischwebend angelegte hidden-forms (Bsp.: neue Maske)
        var id_hidden_form = "form_" + form_id + "_" + instance_id;
//        alert("Suche Form: " + id_hidden_form);
        document.getElementById(id_hidden_form).parentNode.style.visibility = 'hidden';
        hideBarrier();                      //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)
        return false;
    }

}



/** Setzt die CSS-Eigenschaft display eines Formulars auf none.
 * Diese Funktion ist für Buttons in einer Symbolleiste geeignet.
 * 
 * @param   {object}    event   Objekt, welches auf der Maske angeklickt wurde
 * @returns {boolean}           Funktion gibt immer false zurück, damit formaction nicht ausgeführt wird, sonst würde eine neue URL geladen werden.
 */
function hideFormDisplay(event) {
    //Form-ID und Instanz anhand des Button_Namens ermitteln
    var form_id = getValueFromEventelementAttribut(event, 'data-formid');
    var button_name = getValueFromEventelementAttribut(event, 'name');
    var instance_id = getInstanceIdFromButtonname(button_name);
    
    //Formular mit der entsprechenden Form-ID und Instanz ausblenden
    try {
        //Variante für inew-Formulare
        var id_hidden_form = "hiddenForm" + form_id + "_" + instance_id;
//        alert("Suche Form: " + id_hidden_form);
        document.getElementById(id_hidden_form).style.display = 'none';
        hideBarrier();                      //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)
        return false;
    } finally {
        //Variante für freischwebend angelegte hidden-forms (Bsp.: neue Maske)
        var id_hidden_form = "form_" + form_id + "_" + instance_id;
//        alert("Suche Form: " + id_hidden_form);
        document.getElementById(id_hidden_form).parentNode.style.display = 'none';
        hideBarrier();                      //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)
        return false;
    }

}


/** Setzt die CSS-Eigenschaft visibility eines Formulars auf hidden.
 * Diese Funktion ist für Buttons innerhalb eines Formulars, jedoch nicht innerhalb einer Symbolleiste, geeignet.
 * 
 * @param   {object}    id     Objekt, welches auf der Maske angeklickt wurde
 * @returns {boolean}          Funktion gibt immer false zurück, damit formaction nicht ausgeführt wird, sonst würde eine neue URL geladen werden.
 */
function hideFormByID(id) {
    
//    window.confirm("Starte mit Form: "+id);   
    document.getElementById(id).style.visibility = 'hidden';
    
    hideBarrier();
    return false;                                                               //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)
}



/** Setzt die CSS-Eigenschaft visibility eines Formulars auf hidden.
 * Diese Funktion ist für Felder innerhalb eines Formulars, jedoch nicht innerhalb einer Symbolleiste, geeignet.
 * 
 * @param   {string}    fieldId     ID des Feldes, welches im Formular ausgeblendet werden soll.
 * @returns {boolean}               Funktion gibt immer false zurück, damit formaction nicht ausgeführt wird, sonst würde eine neue URL geladen werden.
 */
function hideFieldID(fieldId) {
    
//    window.confirm("Starte mit Form: "+id);   
    var my_element = document.getElementById(fieldId);
    if(typeof(my_element) !== 'undefined' && my_element !== null){my_element.style.visibility = 'hidden';} 
    
    
    hideBarrier();
    return false;                                                               //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)
}


/** Setzt die CSS-Eigenschaft visibility eines Formulars auf einen Leerstring.
 * Diese Funktion ist für Felder innerhalb eines Formulars, jedoch nicht innerhalb einer Symbolleiste, geeignet.
 * 
 * @param   {string}    fieldId     ID des Feldes, welches im Formular ausgeblendet werden soll.
 * @returns {boolean}               Funktion gibt immer false zurück, damit formaction nicht ausgeführt wird, sonst würde eine neue URL geladen werden.
 */
function showFieldID(fieldId) {
    
//    window.confirm("Starte mit Form: "+id);   
    document.getElementById(fieldId).style.visibility = '';
    
    return false;                                                               //false, damit durch den Button-Klick nicht das Formular neu geladen wird. (formaction wird abgebrochen)
}





/** Setzt die CSS-Eigenschaft visibility des html-tag mit dem Attribut desc=barrier auf visible.
 * 
 * @returns {undefined}
 */
function showBarrier() {
    document.querySelector("div[data-alt='barrier']").style.visibility = 'visible';
}



async function showWaitBox() {
    
    //WaitForm einblenden
    showBarrier();
    document.querySelector("div[data-alt='hiddenWaitBox']").style.visibility = 'visible';
    
    
    while (global_abort === false) {
        await sleep(3000);
        updateProgressStatus();
    }
    
}



//function showWaitBox() {
//    
////    alert("Blende Waitbox ein:");
//    //WaitForm einblenden
//    showBarrier();
//    document.querySelector("div[data-alt='hiddenWaitBox']").style.visibility = 'visible';
//    
//}


function hideWaitBox() {
    //WaitForm einblenden
    hideBarrier();
    document.querySelector("div[data-alt='hiddenWaitBox']").style.visibility = 'hidden';
}



/** Setzt die CSS-Eigenschaft visibility des html-tag mit dem Attribut alt=barrier auf visible.
 * 
 * @returns {undefined}
 */
function hideBarrier() {
    document.querySelector("div[data-alt='barrier']").style.visibility = 'hidden';
}





/** Ermittelt aus dem Namen eines Buttons die Instanz_id
 * Bsp. Buttonname: button__Neu_000Form31_1_i0
 * -> Instanz-ID = i0
 * 
 * @param   {string}    in_button_name     name-Attribut eines Buttons
 * @returns {string}
 */
function getInstanceIdFromButtonname(in_button_name) {
    
    let instance_id = in_button_name.split("_").pop();                          // split erstellt ein array; pop liefert das letzte Element des arrays
    instance_id = instance_id.replace("--",".");                                // Punkt wurde in showFields.buildButtonname durch "--" ersetzt.
    return instance_id;
}



/** ermittelt aus einem buttonname, wie ihn die Funktion showFields.php._getFieldSubmitbutton setzt, die form_id.
     * Bsp.: button__Suche_0000Form56_1_1130190281 -> form_id = 56
     * 
     * @param   {string}  in_button_name  Name eines Buttons
     * @returns  {string}                 id des Fomrulars des Buttons
     */
    function getFormidFromButtonname(in_button_name) {
        var posForm = in_button_name.indexOf("Form") + 4;                 //Auftreten der Form-ID
        var posEndeForm = in_button_name.indexOf("_", posForm);                     //Ende der Form-ID
        var laengeForm = posEndeForm - posForm;
        var form_id = in_button_name.substr(posForm, laengeForm); 
        return form_id;
    }


//verschiebt das aktive DIV an die Stelle, an der die Maus es loslies (übernommen von w3schools
function dragElement(elmnt) {
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  if (document.querySelector("div[data-alt='feedbackBoxHead']")) {
    /* Wenn das Element gefunden wird, dann wird dragMouseDown verknüpft*/
    document.querySelector("div[data-alt='feedbackBoxHead']").onmousedown = dragMouseDown;
  } 


  function dragMouseDown(e) {
    e = e || window.event;
    e.preventDefault();
    // get the mouse cursor position at startup:
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves:
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e = e || window.event;
    e.preventDefault();
    // calculate the new cursor position:
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    // set the element's new position:
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
  }

  function closeDragElement() {
    /* stop moving when mouse button is released:*/
    document.onmouseup = null;
    document.onmousemove = null;
  }
}


//
// prüfen, ob die Anwendung in einem iFrame geladen wurde
function isInIframeAndFalseBrowser() {
  
  
  


    if(window.self !== window.top) {
        // Opera 8.0+
        //    var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;

        // Firefox 1.0+
        //    var isFirefox = typeof InstallTrigger !== 'undefined';

        // Safari 3.0+ "[object HTMLElementConstructor]" 
        //    var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

        // Internet Explorer 6-11
        var isIE = /*@cc_on!@*/false || !!document.documentMode;

        // Edge 20+
        var isEdge = !isIE && !!window.StyleMedia;

        // Chrome 1 - 79
        var isChrome = !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);

        // Edge (based on chromium) detection
        var isEdgeChromium = isChrome && (navigator.userAgent.indexOf("Edg") != -1);

        // Blink engine detection
        //    var isBlink = (isChrome || isOpera) && !!window.CSS;
        //Browser, welche Cookies im iframe nicht unterstützen
        if(isIE || isEdge || isChrome || isEdgeChromium) {
            //ACHTUNG: Die folgende Aussage stimmt nicht!!!
            //Die Methode bleibt nur als Muster erhalten.
            showFeedbackBox2(   "ACHTUNG: die Anwendung wurde eingebettet in einem iFrame geladen. <br /> \
                                Zudem verwenden Sie den Browser Chrome, Edge oder IE. In diesem \
                                Fall werden Cookies innerhalb des iFrames nicht akzeptiert werden. <br /> <br /> \
                                Nutzen Sie bitte einen anderen Browser oder öffnen Sie die eingebettete Seite in einen \n\
                                eigenen Fenster! <br /><br /> " +
                                '<a target="_blank" href="' + window.location + '">In einem eigenen Fenster öffnen</a>');
            }
        } else {
    //        showFeedbackBox2("Anwendung wurde nicht in einem iFrame geladen");
        }
    
  
  
  
}


    /** verbessert Datumsfelder in alten Browsern durch komfortablejQuery-Datepicker
     * 
     * @returns {undefined}
     */
    function improveDatefields() {
        // Safari 3.0+ "[object HTMLElementConstructor]" 
        var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

        // Internet Explorer 6-11
        var isIE = /*@cc_on!@*/false || !!document.documentMode;

        
        if(isIE || isSafari) {
            //Datumsfeld durch jquery verbessern, da die Browser selbst keine Lösung bieten.
            //Achtung: jquery ansonsten so gut es geht vermeiden, da es zu anderen Nebeneffekten kommen kann (bspw. falsch platzierte Datumsfelder)
            jQuery(".datepicker").datepicker({dateFormat: 'yy-mm-dd'});
        } 
        
        
    }



    /** blendet li-Elemente ab level=1 in left_part aus und verteckt  den closeBtnVerticalMenu-Button
     * 
     * @returns {Boolean}
     */
    function closeNavMenuHorizontal() {

        //closeBtn für Standardmenü ausblenden  
        setInlineCssClass("closeBtnHorizontalMenu", "", "display", "none");
        
        //openBtn für Standardmenü ausblenden  
        setInlineCssClass("openBtnHorizontalMenu", "", "display", "block");
        
        //Höhe der Überschriften der sonstigen Menü-Punkte (level > 0)
        setInlineCssClass("nav_item_level_1", "", "display", "none");
        setInlineCssClass("nav_item_level_2", "", "display", "none");
        setInlineCssClass("nav_item_level_3", "", "display", "none");
        setInlineCssClass("nav_item_level_4", "", "display", "none");
        setInlineCssClass("nav_item_level_5", "", "display", "none");
        
        return false;
    }

    
    
    /** blendet li-Elemente ab level=1 in left_part ein und verteckt  den openBtnVerticalMenu-Button
     * 
     * @returns {Boolean}
     */
    function openNavMenuHorizontal() {

        //closeBtn für Standardmenü einblenden  
        setInlineCssClass("closeBtnHorizontalMenu", "", "display", "block");
        
        //openBtn für Standardmenü ausblenden  
        setInlineCssClass("openBtnHorizontalMenu", "", "display", "none");
        
        //Höhe der Überschriften der sonstigen Menü-Punkte (level > 0)
        setInlineCssClass("nav_item_level_1", "", "display", "list-item");
        setInlineCssClass("nav_item_level_2", "", "display", "list-item");
        setInlineCssClass("nav_item_level_3", "", "display", "list-item");
        setInlineCssClass("nav_item_level_4", "", "display", "list-item");
        setInlineCssClass("nav_item_level_5", "", "display", "list-item");
        
        return false;
    }
    
    



    /** blendet left_part ein und verteckt  den openBtnVerticalMenu-Button
     * 
     * @returns {Boolean}
     */
    function openNavMenuVertical() {
        
        
        //left_part (enthält Standardmenü) einblenden
        setInlineCssClass("left_part", "max-width", "width", "");
        
        //openbtn für Standardmenü ausblenden  
        setInlineCssClass("openBtnVerticalMenu", "min-width", "width", "");
        
        //closebtn für Standardmenü einblenden  
        setInlineCssClass("closeBtnVerticalMenu", "max-width", "width", "");
        
        //middle_part Platz korrigieren
        setInlineCssClass("middle_part", "min-width", "width", "");
        
        
        return false;
    }



    /** blendet left_part aus und zeigt stattdessen den openBtnVerticalMenu-Button
     * 
     * @returns {Boolean}       Gibt immer false zurück, damit submit unterdrückt wird.
     */
    function closeNavMenuVertical() {
        
        //left_part (enthält Standardmenü) ausblenden
        setInlineCssClass("left_part", "min-width", "width", "");
        
        //openBtn für Standardmenü einblenden    
        setInlineCssClass("openBtnVerticalMenu", "max-width", "width", "");
        
        //closebtn für Standardmenü ausblenden  
        setInlineCssClass("closeBtnVerticalMenu", "min-width", "width", "");
        
        //middle_part Platz korrigieren
        setInlineCssClass("middle_part", "max-width", "width", "");
        
        return false;
    }




    /** Die Funktion sucht alle Elemente der angegebenen Klasse (in_class) und
     * setzt den Wert des CSS-Attributes (in_source_css_attribut) der Klasse in die 
     * inline-Eigenschaft des CSS-Attributes (in_target_css_attribut).
     * 
     * @param {string} in_class                 eine beliebige Klasse 
     * @param {string} in_source_css_attribut   ein CSS_Attribut der Klasse, bspw. max-width
     * @param {string} in_target_css_attribut   ein CSS-Attribut, bspw. width
     * @param {string} $in_const_css_attribut   Konstanter Wert, der in in_target_css_attribut eingesetzt werden soll
     * @returns {undefined}                     kein Rückgabewert
     */
    function setInlineCssClass(in_class, in_source_css_attribut, in_target_css_attribut, $in_const_css_attribut) {
        var elements = document.getElementsByClassName(in_class);
        
        for (let i = 0; i < elements.length; i++) {
            const cssObj = window.getComputedStyle(elements[i], null);
            if($in_const_css_attribut != "") {
                elements[i].style[in_target_css_attribut] = $in_const_css_attribut;
            } else {
                elements[i].style[in_target_css_attribut]= cssObj.getPropertyValue(in_source_css_attribut);    //inline-Attribut wird mit Wert aus Klasse belegt
                //requiredElement.style.width = requiredElement.style.maxWidth;   //Damit greift man nur auf inline-Style zu. Man muss computed oder Klasse treffen
            }
        }
    }
    
    
    
    /** ergänzt zur formation-URl eines Buttons einen Parameter
     * URL-Encoding findet nicht statt
     * 
     * @param   {string}    in_button_id    DOM-ID des Buttons
     * @param   {string}    in_param_name   Name des Parameter
     * @param   {value}     in_param_value  Wert des Parameters
     * @returns {boolean}
     */
    function addParamToUrl(in_button_id, in_param_name, in_param_value) {
        let myElement = document.getElementById(in_button_id);
        //console.log("myElement: ", myElement);
        let url = myElement.getAttribute("formaction");
        
        if(url !== null) {
            //console.log("alter url-Wert: ", url);
            url = url+"&"+in_param_name+"="+in_param_value;
            myElement.setAttribute("formaction",url);
            //let newurl = myElement.getAttribute("formaction");
            //console.log("neuer url-Wert: ",newurl);
            return true;
        } else {
            return false;
        }
    }





//------------------------------------------------------------------------------
//Funktionen, die in jedem Fall, nach dem Laden des HTML-Doms ausgeführt werden.


window.onload = function () {
    
//    showWaitBox();   
    
    
    //Falls sofort ein Button geklickt werden soll, um bspw. die Detail-Daten eines einzelnen gefilterten Datensatzes in ein abhängiges Formular zu laden, wird das nun ausgeführt
    let my_button = getInnerHtmlFromDomElement("div_2063");
    my_button = my_button.trim();
    if(my_button != "") {
        //URL des Buttons um den Parameter "auto_clicked" erweitern
//        console.log("my-Button", my_button);
        addParamToUrl(my_button, "auto_clicked", "1");
        //Button klicken
        document.getElementById(my_button).click();
    } else {
    

        //alle Details-tags, die das Attribut open nicht haben, sammeln, damit nur diese im Anschluss wieder geschlossen werden
        const details_close = document.querySelectorAll("details:not([open])"); 
        //alle details-tags öffnen, da sonst die nachfolgenden Javascript-Manipultationen teilweise scheitern (insbesondere chosen)
        //weitere Tipps siehe: https://stackoverflow.com/questions/16751345/automatically-close-all-the-other-details-tags-after-opening-a-specific-detai
        details_close.forEach((detail) => {
            detail.setAttribute("open", "open");
        });



        //Auf Login-Maske Felder ausblenden, wenn vorhanden
        hideFieldID("container_0001O3820Form50_0_i0");              //Benutzer (2. Feld, label)
        hideFieldID("container_000app_id_temp0Form50_0_i0");        //APP-ID-temp
        hideFieldID("container_000password0Form50_0_i0");           //password
        hideFieldID("container_0001O3870Form50_0_i0");              //back-button
        hideFieldID("container_0001O3940Form50_0_i0");              //login-button


        //Alle Select-Felder werden mit dem chosen-Plugin verbessert
        jQuery(".chosen").chosen({
            disable_search_threshold: 5,
            allow_single_deselect: true, 
            inherit_select_classes: true,
            search_contains: true,
            no_results_text: "keine Treffer",
            placeholder_text_multiple: "Wählen Sie Werte",
            placeholder_text_single: "Wählen Sie einen Wert"
        }).on('invalid', function(){
            $(this).addClass('submitted');
        });


        //Alle Date-Felder werden in alten Browsern mit dem datepicker-Plugin verbessert
        improveDatefields();






        //Alle WYSIWYG-Felder werden mit dem trumbowyg-Plugin verbessert
        //jQuery.trumbowyg.svgPath = '../js/trumbowyg/ui/icons.svg';
        //alle Wysiwyg-Felder, deren Höhe nicht fest definiert ist
        jQuery('.wysiwyg[rows=0]').trumbowyg({                  
    //    jQuery(".wysiwyg").trumbowyg({
            svgPath: '../js/trumbowyg/ui/icons.svg',
            lang: 'de',
            semantic: true,
            autogrowOnEnter: true,
            imageWidthModalEdit: true,
            btnsDef: {
                image: {
                    dropdown: ['base64'],
                    ico: 'insertImage'
                }
            },
            // re-define the button pane
            btns: [
                ['viewHTML'],
                ['undo', 'redo'],  //wird nicht von jedem Browser unterstützt
                ['formatting'],
                ['bold', 'italic', 'strikethrough', 'underline'],
                ['superscript', 'subscript'],
                ['foreColor', 'backColor'],
                ['link'],
                ['indent', 'outdent'],
                ['image'], //Link auf image (siehe weiter oben)
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull'],
                ['unorderedList', 'orderedList'],
                ['horizontalRule'],
                ['table'], 
                ['removeformat'],
                ['fullscreen']
            ]
        });


        //alle Wysiwyg-Felder, deren Höhe fest definiert ist
        jQuery('.wysiwyg[rows!=0]').trumbowyg({                  
    //    jQuery(".wysiwyg").trumbowyg({
            svgPath: '../js/trumbowyg/ui/icons.svg',
            lang: 'de',
            semantic: true,
            autogrowOnEnter: false,
            imageWidthModalEdit: true,
            btnsDef: {
                image: {
                    dropdown: ['base64'],
                    ico: 'insertImage'
                }
            },
            // re-define the button pane
            btns: [
                ['viewHTML'],
                ['undo', 'redo'],  //wird nicht von jedem Browser unterstützt
                ['formatting'],
                ['bold', 'italic', 'strikethrough', 'underline'],
                ['superscript', 'subscript'],
                ['foreColor', 'backColor'],
                ['link'],
                ['indent', 'outdent'],
                ['image'], //Link auf image (siehe weiter oben)
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull'],
                ['unorderedList', 'orderedList'],
                ['horizontalRule'],
                ['table'], 
                ['removeformat'],
                ['fullscreen']
            ]
        });




        //jQueryDataTables deaktiviert, da Fehler geworfen werden. (siehe Ticket 736)
        //zum aktivieren:
        // - Maskenelemente 1138 und 1144 zum Grundgerüst (Maskenelementgruppe) hinzufügen 
        // - nachfolgenden Code aktivieren
    //    $(document).ready(function() {
    //        $("#simpleTable").DataTable();
    //    } );


        // hiddenFeedbackBox dragable gestalten
    //    document.querySelector("div[data-alt='hiddenFeedbackBox']").setAttribute("draggable", "true");					
    //    document.querySelector("div[data-alt='hiddenFeedbackBox']").setAttribute("ondragend", "verschiebeElement(event)");
        dragElement(document.querySelector("div[data-alt='hiddenFeedbackBox']"));


        //alle <details>-tags, welche oben geöffnet wurden, schließen
        details_close.forEach((detail) => {
            detail.removeAttribute("open");
        });



        //---------------------------------------------------
        //Funktionen, die vor dem Absenden ausgeführt werden.
        //


        //Klickevent an alle Buttons hängen
        jQuery('.button').click(function(){
            //Vom geklickten Button das Attribut auslesen
            let warn_by_change = jQuery(this).attr('data-warn-by-change-without-save');
            //alert("warn: "+warn_by_change);
            if(warn_by_change == "false") {
                //Wenn ein Button vorliegt, bei dem nicht gewarnt werden muss (bspw: Speichern)
                submitted = true;
            }
        });



        //an alle Eingabefelder den folgenden change-event-Handler hängen -> bei Änderung wird userinput auf true gesetzt
        jQuery(".warn_by_leave").change(function() {userinput = true;});






        hideWaitBox();
    //    isInIframeAndFalseBrowser();

    }


    
 
};


window.onbeforeunload = function () {
        if (userinput && !submitted) {
          return 'Es liegen noch nicht gespeicherte Änderungen vor.';
        }
      };




