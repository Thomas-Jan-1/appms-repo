<?php

/*
 * Copyright (C) 2023 thomas
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Klasse bietet statische Methoden zur Ver- und Entschlüsselung von Daten.
 *
 * @author thomas
 */
class crypt_class {
    
    private static $pe = "SERVER_NAME";
    private static $encryptMethod = "aes-256-cbc";
    private static $hash_algo = "sha3-256";
    
    /** Verschlüsselt Strings mit sha3-256, wandelt diese in base64-Format um und setzt das Präfix "sha3-256:" voran.
     * 
     * @param   string  $in_data            zu verschlüssenlde Daten
     * @param   string  $in_app_id          APP-ID, wird als Salz genutzt.
     * @return  string
     */
    protected static function encrypt_sha3_256($in_data, $in_app_id) {
        $passphrase = hash(self::$hash_algo, $_SERVER[self::$pe]);
        $vector = substr(hash(self::$hash_algo, $in_app_id), 0, 16);
        $feedback = openssl_encrypt($in_data, self::$encryptMethod, $passphrase, 0, $vector);
        $result = self::$hash_algo.":".base64_encode($feedback);
        return $result;
    }

    /** Entschlüsselt Strings, welche vorher mit dieser Klasse verschlüsselt wurden.
     * 
     * @param   string  $in_data        sha3-codierter Wert, inkl. Präfix "sha3-256:"; Bsp.: sha3-256:bkNOVm4rUXU5UUloNGk4OU95bEhTUT09
     * @param   string  $in_app_id      APP-ID, wird als Salz genutzt.
     * @return  string                  
     */
    protected static function decrypt_sha3_256($in_data, $in_app_id) {
        $my_data = substr($in_data, strlen(self::$hash_algo.":"));
        $passphrase = hash(self::$hash_algo, $_SERVER[self::$pe]);
        $vector = substr(hash(self::$hash_algo, $in_app_id), 0, 16);
        $feedback = base64_decode($my_data);
        $result = openssl_decrypt($feedback, self::$encryptMethod, $passphrase, 0, $vector);
        return $result;
    }
    
    
    
    
    
    
    /** Entschlüsselt Strings, die vorab mit der Klasse encrypt_class verschlüsselt wurden.
    * Wenn keine Verschlüsselungsmethode erkannt wird, dann wird $in_password_phrase unverändert zurückgegeben. 
    * 
    * @param    string  $in_password_phrase         verschlüsseltes oder unverschlüsseltes Passwort.
    * @param    string  $in_app_id                  APP-ID, wird als Salz genutzt.
    * @return   string
    */
   public static function decryptString($in_password_phrase, $in_app_id) {
       
       if (substr($in_password_phrase, 0, 9) == "sha3-256:") {  
           //interne Verschlüsselungsmethode
           $feedback = self::decrypt_sha3_256($in_password_phrase, $in_app_id);
           
       } else {
           //unverschlüsselt
           $feedback = $in_password_phrase;
       }
       
       return $feedback;
       
   }
   
   
   
    /** Verschlüsselt Strings mit der aktuellen Verschlüsselungsmethode von AppMS
    * 
    * @param    string  $in_password_phrase         zu verschlüsselender String.
    * @param    string  $in_app_id                  APP-ID, wird als Salz genutzt.
    * @return   string                              verschlüsselter String: als Präfix wird die Verschlüsselungsmethode vorangestellt.
    */
   public static function encryptString($in_password_phrase, $in_app_id) {
       $feedback = self::encrypt_sha3_256($in_password_phrase,$in_app_id);
       
       return $feedback;
   }
    
    
    
    
}
