<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

/**
 * Die Klasse stellt Funktionen zum erstellen und verwalten von Formularen bereit.
 *
 * @author Thomas
 */
class form {
    
    /**
     *
     * @var     object      Referenz auf das pagedata-object 
     */
    protected $pagedata;
    
    
    protected $app_id;
    protected $id;
    protected $name;
    protected $show_headline = 1;
    protected $constructor;
    protected $description;
    protected $db_schema;
    protected $db_table;
    protected $query_app_id;
    protected $query;
    protected $order_by;
    protected $condition;
    protected $historydata;
    protected $history_from_col;
    protected $history_to_col;
    protected $htmltaggroup_id;
    protected $activate_prot;
    protected $prot_col;
    protected $default_mode;
    protected $limit;                           //Anzahl der Datensätze, die im Formular angezeigt werden sollen. Wenn leer, dann greift allgemeiner Konfigurationsparameter
    protected $behave_after_insert;
    protected $width;                           //Breite in Prozent
    protected $htmltag_id;                      //ID des htmltags des Formulars
    protected $parent_dom_node;                 //ID des htmltags, in dem das Formular mit seinem eigenen htmltag eingehangen werden soll.
    protected $filename;                        //Name einer Datei. Diese kann, je nach app, unterschiedliche Funktionen haben.
    protected $is_symbolgroup;
    protected $image;                           //Pfad zu einer Bilddatei.
    protected $show_markfield; 
    protected $timeToDelete;
    protected $save_optlist;
    
    
    /** Die Klasse stellt Funktionen zum erstellen, verwalten und löschen von Formularen bereit.
     * 
     * @param   object  $in_pagedata        Referenz zum pagedata_object
     * @param   string  $in_form_app_id     [optional] APP-ID des Formulars, falls ein bereits bestehende Formular verwaltet werden soll
     * @param   int     $in_form_id         [optional] ID des Formulars, falls ein bereits bestehende Formular verwaltet werden soll
     */
    public function __construct(&$in_pagedata, $in_form_app_id = "", $in_form_id = "") { 
        $this->pagedata = $in_pagedata;
        if($in_form_app_id !== "") {$this->app_id = $in_form_app_id ;}
        if($in_form_id !== "") {$this->id = $in_form_id ;}
    }
    
    
    
    /** Kopiert alle Felder eines Source-Formulars in ein Target-Formular
     * 
     * @param   string    $in_sourceForm_app
     * @param   integer   $in_sourceForm_id
     * @param   string    $in_targetForm_app
     * @param   integer   $in_targetForm_id
     * @return  integer                             Rückmelde-ID's entsprechend der Konstantentyp_id 35 [901|-901|-21] 
    */
    public function copyFieldsToForm($in_sourceForm_app, $in_sourceForm_id, $in_targetForm_app, $in_targetForm_id) {
        
        
        $myScript = "INSERT INTO manager.feld (".
                    "app_id, konstante_app_id, konstante_gueltig_ab, konstante_id, name, form_app_id, form_id, query_app_id, ".
                    "query_id, query_ref_field_connection_id, button_action_function_app_id, javascript_onclick, js_click_params, ".
                    "javascript_onchange, js_change_params, javascript_onsubmit, js_submit_params, javascript_oninput, js_oninput_params, ".
                    "button_action_function_id, form_mode_app_id, sort, laenge, laenge_label, zeilen, spalte, ldap_attribut, pos_header, ".
                    "inline, max_zeichen, numeric_min, numeric_max, required, ref_schema, ref_table, ref_id_field, ref_show_field, ".
                    "ref_order_by_field, ref_condition, readonly, vorgabewert, ausblenden_bei_insert, button_target, button_target_mask, ".
                    "form_mode_id, helptext, ref_konstantentyp_app_id, ref_konstantentyp_id, sys, autocomplete, autocomplete_start, add_attribut) ".
 
                    "SELECT ".  
                    "'".$in_targetForm_app."', konstante_app_id, konstante_gueltig_ab, konstante_id, name, '".$in_targetForm_app."', ".$in_targetForm_id.", query_app_id, query_id, ".
                    "query_ref_field_connection_id, button_action_function_app_id, javascript_onclick, js_click_params, javascript_onchange, ".
                    "js_change_params, javascript_onsubmit, js_submit_params, javascript_oninput, js_oninput_params, button_action_function_id, ".
                    "form_mode_app_id, sort, laenge, laenge_label, zeilen, spalte, ldap_attribut, pos_header, inline, max_zeichen, numeric_min, ".
                    "numeric_max, required, ref_schema, ref_table, ref_id_field, ref_show_field, ref_order_by_field, ref_condition, readonly, ".
                    "vorgabewert, ausblenden_bei_insert, button_target, button_target_mask, form_mode_id, helptext, ref_konstantentyp_app_id, ".
                    "ref_konstantentyp_id, sys, autocomplete, autocomplete_start, add_attribut ".
                
                    "from manager.feld where form_app_id = '".$in_sourceForm_app."' and form_id = ".$in_sourceForm_id.";";
        
        $connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();
        $feedback = db_connection_handler::executeScriptOnDatabase($connection_id, $myScript, __FUNCTION__, true, $this->pagedata);
        
        if($feedback == -901) {
            $feedback = -910;
        } elseif ($feedback == 901) {
            $feedback = 910;
        }
        
        return $feedback;
    }
    
    
    
    
    /** Ermittelt eine Liste, aller Masken, auf denen das Formular verwendet wird.
     * 
     * @return array        Array, wie es die Funktion getMaskListByForm ermittelt.
     */
    public function getMaskList() {
        $myMaskList = getMaskListByForm($this->app_id, $this->id);
        return $myMaskList;
    }
    
    
    
    /** Löscht das Formular aus der Tabelle form.
     * 
     * @return  int                             [3|-3|-31] -> [succes|error] -> Fehlerdetails werden in die Debug-Tabelle geschrieben.
     */
    public function deleteForm() {
        $schema_kernel = global_variables::getNameOfDbSchemaSYS01();
        
        //Htmltaggroup der form ermitteln (dazu htmltag nutzen). Prüfen, ob diese nach dem Löschen des Formulars, noch weitere htmltags enthält. 
        //Falls nein und Kennzeichen is_symbolgroup gesetzt ist, kann die Gruppe auch gelöscht werden. Wenn Kennzeichen nicht gelöscht ist, 
        //bleibt die Gruppe solange erhalten, bis die Maske gelöscht wird.
        $this->htmltaggroup_id = $this->searchHtmltaggroupidFromSymbolgroup();
        if($this->htmltaggroup_id !== false) {$this->is_symbolgroup = true;}

        //SQL-Array für Löschbefehl aufbauen
        $sql_daten["schema"] = $schema_kernel;
        $sql_daten["table"] = "form";
        $sql_daten["where"] = "id=".$this->id." AND app_id = '".$this->app_id."'";
//        $sql_daten['logdata_id_data'] = $this->form_id;
//        $sql_daten["logdata"] = "Artikel ".$this->article_name." inkl. Formular gelöscht";

        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();
//        $dummy_form['form.log_id_spalte'] = "id";
//        $dummy_form['form.name'] = $this->article_name;

        $feedback = deleteData($sql_daten, $dummy_form, $this->pagedata->getSessionArray()["uid"], $this->pagedata);
        
        if($this->isSymbolHtmlgroupEmpty($this->htmltaggroup_id) == true AND $this->is_symbolgroup === true) {
            //htmltaggroup wird nicht mehr benötigt
            $localfeedback = deleteHtmltaggroup($this->htmltaggroup_id, $this->app_id, $this->pagedata->getSessionArray()["uid"], $this->pagedata);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> lösche htmltaggroup: ', 'Ergebnis: '.$localfeedback);
            
        }
        
        
        return $feedback;
    }
    
    
    
    
    
    
    
    /**
     * 
     * @param   string  $in_app_id                  APP-ID des Formulars
     * @param   string  $in_name                    Name des Formulars
     * @param   integer $in_show_headline           Gibt an, ob Überschriften angedruckt werden sollen [1|0] 
     * @param   string  $in_constructor             Constructor zum rendern des Formulars (Mögliche Werte siehe Tabelle konstanten; konstantentyp_id = 18)
     * @param   string  $in_description             Beschreibung eines Formulars. Bei WYSIYG-Formularen der Inhalt. Es kann auch ein Leerstring übergeben werden.
     * @param   string  $in_db_schema               DB-Schema, in dem die Daten des Formulars abgelegt werden. Leerstring ist möglich.
     * @param   string  $in_db_table                DB-Tabelle, in dem die Daten des Formulars abgelegt werden. Leerstring ist möglich.
     * @param   string  $in_query_app_id            APP-ID einer Query, welche die Daten des Formulars liefert. (Nur relevant für den Constructor "getFormTableForQuery", ansonsten Leerstring angeben)
     * @param   integer $in_query                   ID einer Query, welche die Daten des Formulars liefert. (Nur relevant für den Constructor "getFormTableForQuery", ansonsten Leerstring angeben)
     * @param   string  $in_order_by                Sortiermerkmal der Daten innerhalb des Formulars. Sortierung wird in SQL-Syntax angegeben (Bsp.: "app_id, id"). Angabe ist nur relevant, wenn auch db_schema und db_table angegeben wird. Ansonsten Leerstring übergeben.
     * @param   string  $in_condition               Bedingung zur Auswahl der Daten aus der Datenbank. Condition wird in SQL-Syntax angegeben (Bsp.: "app_id = 'SYS01'"). Angabe ist nur relevant, wenn auch db_schema und db_table angegeben wird. Ansonsten Leerstring übergeben.
     * @param   integer $in_historydata             Gibt an, ob es sich historisierbare Datenspeicherung handelt. Mögliche Werte [0|1]. Angabe ist nur relevant, wenn auch db_schema und db_table angegeben wird. Ansonsten 0 übergeben.
     * @param   string  $in_history_from_col        Column, welche bei historischen Daten das Gültig-von-Datum enthält. Angabe ist nur relevant, wenn $in_historydata = 1. Ansonsten Leerstring  übergeben.
     * @param   string  $in_history_to_col          Column, welche bei historischen Daten das Gültig-bis-Datum enthält. Angabe ist nur relevant, wenn $in_historydata = 1. Ansonsten Leerstring  übergeben.
     * @param   integer $in_activate_prot           Gibt an, ob die automatische Protokollierung der Datenänderung aktiviert werden soll. [0|1]
     * @param   string  $in_prot_col                Spalte, welche die ID zur Zuordnung von Protokolldaten zu Inhaltsdaten enthält. Angabe ist nur relevant, wenn $in_activate_prot = 1. Ansonsten Leerstring übergeben.
     * @param   integer $in_default_mode            Modus, in dem das Formular per default geöffnet wird. Mögliche Werte siehe DB-Tabelle form_mode.
     * @param   integer $in_limit                   Anzahl der Zeilen, die im Formular amximal angezeigt werden sollen. Wenn keine Angabe, dann greift zentraler Konfigurationsparameter. Angabe kann Leerstring sien.
     * @param   string  $in_behave_after_insert     Verhalten nach insert und update. Möglicher Werte siehe Tabelle Konstanten (konstantentyp_id = 148).
     * @param   string  $in_width                   Breite des Formuars in %. Wenn Leerstring, dann greift allgemein Angabe aus dem CSS_Template.
     * @param   integer $in_parent_dom_node         ID des htmltags, in dem das Formular mit seinem eigenen htmltag eingehangen werden soll.
     * @param   string  $in_filename                Name der Datei. Diese kann je nach App, verschiedene Funktionen haben.
     * @param   string  $in_image                   Pfad zu einer Bilddatei.
     * @param   integer $in_timeToDelete            Zeit in Sekunden, nach denen Daten, welche über dieses Formular erfasst werden, wieder gelöscht werden. (Funktion muss separat angestoßen werden)
     * @param   integer $in_save_optlist            Gibt an, ob Option-Listen von Referenzfeldern in der Session (forms_backup) gespeichert werden sollen. Dies ermöglicht anschließend die Klartexte in Mails oder Druckaufbereitungen zu verwenden. Es kostst jedoch u.U. erheblich mehr Speicherbedarf. Werte: [0|1]
     * @throws Exception
     */
    public function addNewForm($in_app_id, $in_name, $in_show_headline, $in_constructor, $in_description, $in_db_schema, $in_db_table, $in_query_app_id, $in_query, $in_order_by, $in_condition, $in_historydata, $in_history_from_col, $in_history_to_col, $in_activate_prot, $in_prot_col, $in_default_mode, $in_limit, $in_behave_after_insert, $in_width, $in_parent_dom_node, $in_filename, $in_image, $in_timeToDelete = "", $in_save_optlist = 0) {
        $this->app_id = $in_app_id;
        $this->name = preg_replace ( '/[^a-zA-Z0-9äÄöÖüÜß_ ()-]/i', '', $in_name);
        $this->show_headline = $in_show_headline;
        $this->constructor = $in_constructor;
        $this->description = $in_description;
        $this->db_schema = $in_db_schema;
        $this->db_table = $in_db_table;
        $this->query_app_id = $in_query_app_id;
        $this->query = $in_query;
        $this->order_by = $in_order_by;
        $this->condition = $in_condition;
        $this->historydata = $in_historydata;
        $this->history_from_col = $in_history_from_col;
        $this->history_to_col = $in_history_to_col;
        $this->activate_prot = $in_activate_prot;
        $this->prot_col = $in_prot_col;
        $this->default_mode = $in_default_mode;
        $this->limit = $in_limit;
        $this->behave_after_insert = $in_behave_after_insert;
        $this->width = $in_width;
        $this->parent_dom_node = $in_parent_dom_node;       //wird in addNewHtmlTag verwendet
        $this->filename = $in_filename;
        $this->image = $in_image;
        $this->timeToDelete = $in_timeToDelete;
        $this->save_optlist = $in_save_optlist;
        
        if(strpos($this->constructor, "ForQuery") !== false) {
            //bei Query-Constructor, die mehrere Datensätze anzeigen können, wird show_markfield per default auf 0 gesetzt. Der Anwender kann
            //das bei Bedarf ändern.
            $this->show_markfield = 0;
        } else {
            $this->show_markfield = 1;
        }
        
        
        
        $my_form_id = setNewForm(   $this->pagedata, 
                                    $this->app_id, 
                                    $this->name, 
                                    $this->show_headline, 
                                    $this->constructor, 
                                    $this->description, 
                                    $this->db_schema, 
                                    $this->db_table, 
                                    $this->query_app_id, 
                                    $this->query, 
                                    $this->order_by, 
                                    $this->condition, 
                                    $this->historydata, 
                                    $this->history_from_col, 
                                    $this->history_to_col, 
                                    $this->activate_prot, 
                                    $this->prot_col, 
                                    $this->default_mode, 
                                    $this->limit, 
                                    $this->behave_after_insert, 
                                    $this->width,
                                    $this->filename,
                                    $this->image,
                                    $this->show_markfield,
                                    $this->timeToDelete,
                                    $this->save_optlist);
        
        if($my_form_id !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Formular angelegt: ".$my_form_id);
            $this->id = $my_form_id;
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Formular konnte nicht angelegt werden!", "ERROR");
            throw new Exception(-2015);
        }
        
        //Maskenelement mit Verknüpfung zur Form_id einfügen
        $this->addNewHtmltag();
    }
    
    
    
    /** Legt eine Maskenelement mit Angabe der Formular-ID an.
     * 
     * @throws Exception  -2017 im Fehlerfall
     */
    private function addNewHtmltag() {
        $my_htmltag_id = setNewHtmltag($this->pagedata, $this->app_id, $this->app_id, $this->id, "div", $this->parent_dom_node, "", $this->name, "", "");
        
        if($my_htmltag_id !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Maskenelement (htmltag) angelegt: ".$my_htmltag_id);
            $this->htmltag_id = $my_htmltag_id;
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Maskenelement (htmltag) konnte nicht angelegt werden!", "ERROR");
            throw new Exception(-2017);
        }
    }
    
    
    
    /** Ergänzt eine Symbolleistengruppe zum Formular
     * 
     * @param   string  $in_symbolgroup_app_id  APP-ID der Symbolleistengruppe
     * @param   int     $in_symbolgroup_id      ID der Symbolleistengruppe (htmltaggroup)
     * @param   int     $in_sort                Reihenfolge der Anordnung der Symbolleiste
     * @param   int     $in_grouptype           Anordnung [1=oben|2 = unten]
     * @return  boolean
     */
    public function addSymbolgroup($in_symbolgroup_app_id, $in_symbolgroup_id, $in_sort, $in_grouptype) {
        $feedback = setHtmlTaggroupHasForm($this->pagedata, $in_symbolgroup_app_id, $in_symbolgroup_id, $this->app_id, $this->id, $in_sort, $in_grouptype);
        if($feedback !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Symbolgruppe ".$in_symbolgroup_id." wurde dem Formular zugeordnet");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Symbolgruppe ".$in_symbolgroup_id." konnte dem Formular nicht zugeordnet werden", "ERROR");
        }
        return $feedback;
    }
    
    
    /** Ergänzt ein Styleset zum htmltag des Formulars
     * 
     * @param   string  $in_styleelement_app_id     APP-ID des Style-Elements
     * @param   int     $in_styleelement_id         ID des Style-Elements
     * @return  boolean
     */
    public function addStyleElement($in_styleelement_app_id, $in_styleelement_id) {
        $feedback = setHtmlTaghasStyleelement($this->pagedata, $this->app_id, $this->htmltag_id, $in_styleelement_app_id, $in_styleelement_id);
        if($feedback !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Styleelement ".$in_styleelement_id." wurde dem Maskenelement des Formulars zugeordnet");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Styleelement ".$in_styleelement_id." konnte dem Maskenelement des Formulars nicht zugeordnet werden", "ERROR");
        }
        
        return $feedback;
    }
    
    
    
    /** Gibt die ID des Maskenelements des Formulars zurück.
     * 
     * @return  integer     ID des Maskenelements
     */
    public function getHtmltagID() {
        return $this->htmltag_id;
    }
    
    
    
    
    /** Ermittelt die htmltaggroup einer Symbolleiste.
     * 
     * @return  mixed       ID oder false
     */
    private function searchHtmltaggroupidFromSymbolgroup() {
        $feedback = false;
        $htmltaggroupList = getHtmltaggroupFromSymbolgroup($this->app_id, $this->id);
        if($htmltaggroupList != false) {
            $feedback = $htmltaggroupList[0]["htmltaggroup.id"];
        }
        return $feedback;
    }
    
    
    /** Prüft, ob die gegebene Htmltaggroup Symbolleisten enthält.
     * Es sollte sichergestellt sein, dass die Htmltaggroup vom Typ is_symbolgroup ist. Andernfalls könnte sie andere Formulare enthalten.
     * 
     * @param type $in_htmltaggroup_id
     * @return boolean
     */
    private function isSymbolHtmlgroupEmpty($in_htmltaggroup_id) {
        $feedback = true;
            
        $symbolgroupList = getSymbolgropusFromHtmltagGroup($this->app_id, $in_htmltaggroup_id);
        if($symbolgroupList != false) {
            if(count($symbolgroupList) >=0) {
                $feedback = false;   //Die Htmltaggroup enthält weitere Symbolleisten
            }
        }
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Ergebnis: ', $feedback);
        
        return $feedback;
    }
    
    
    
    
    /** Gibt die ID des neu erstellten  Formulars zurück.
     * 
     * @return  integer     ID des Formulars
     */
    public function getFormID() {
        return $this->id;
    }
    
    
    
    /**
     * Sendet einen Update-Befehl für eine Spalte an die Datenbank für das aktuelle Formular 
     * 
     * @param   $in_column          Spaltenname, dessen Wert verändert werden soll.
     * @param   $in_value           Wert, der desetzt werden soll
     * @return  boolean
     */
    public function updateFormData($in_column, $in_value) {
        
        $update =   $in_column." = '".$in_value."'";
        $where = "app_id = '".$this->app_id."' AND id = ".$this->id;
        
        $sqlDaten = array();
        $sqlDaten["into"] = "";
        $sqlDaten["values"] = "";
        $sqlDaten["update"] = $update;
        $sqlDaten["schema"] = global_variables::getNameOfDbSchemaSYS01();
        $sqlDaten["table"] = "form";
        $sqlDaten["where"] = $where;
        $sqlDaten["logdata"] = "";
        $sqlDaten["logdata_id_data"] = "";

        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();    
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();     
        
        $result = updateData($sqlDaten, $dummy_form, $this->pagedata->getCurrentUserFromSession(), $this->pagedata);

        if ($result < 0) {return false;} else {return true;}
    }
    
}
