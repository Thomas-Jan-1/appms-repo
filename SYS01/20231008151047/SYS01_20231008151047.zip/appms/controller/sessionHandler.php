<?php
      
/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

  

    //Grundeinstellungen der Session festlegen
    setSessionSettings();
    // Session starten bzw. vorhandene Session wieder aufnehmen und auf Hijack prüfen
    session_start();
    $_SESSION = protectSessionAgainstHijack($_SESSION);
    
    
    
    //die folgenden Funktionen dürfen erst nach session_start aufgerufen werden.
    require_once("../controller/functions.php");
    require_once("../controller/debug.php");
    
    
    
    
    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Start: ', '--START-------------------------------------------------------------');
    setErrorLevel();
    
    
    //SessionStorageID bei Bedarf setzen
    $_SESSION = setSessionStorageID($_SESSION);
    
    
    if(isset($_SESSION)) {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Aufruf Sessionhandler mit bestehender Session: ', $_SESSION);}
    if(isset($_POST)) {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Aufruf Sessionhandler mit POST: ', $_POST);}
    if(isset($_GET)) {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Aufruf Sessionhandler mit GET: ', $_GET);}
    if(checkUrlForForbiddenStrings() === true) {cancelLogin("Seitenaufruf abgebrochen, da unerlaubte Aktion erkannt wurde.", 1, "URL enthält unerlaubten String, daher wurde Nutzer automatisch abgemeldet.", true);};
    if(isset($_SESSION["hijack"])) {
        //Diese Fehlermeldung kann erst jetzt, außerhalb von protectSessionAgainstHijack erfolgen, da session_start vor require_once erfolgen muss.
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Session-Hijack: ', "Session-Manipulation erkannt. Session IP und Browser=".$_SESSION["old_identifier"]." | neuer identifier=". getIpAdress().":".$_SERVER["HTTP_USER_AGENT"],"SECURITY");
    }
    
    

    //TargetMask ermitteln (es wird ein möglicherweise vorhandener redirect beachtet)
    $target_mask_array = getTargetMaskArray($_SESSION);
    

    
    // Gast-User ermitteln
    $guest_user = getConfig("guest_user", $target_mask_array["app_id"]);
    $guest_userRoleId = getConfig("guest_user_role", $target_mask_array["app_id"]);
    
    

    //Falls noch eine Guest_Session existiert wird diese zerstört, da sonst keine Validierung gegen ein Verzeichnis erfolgen würde.
    if(isset($_SESSION['guest_user'])) {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'vor checkGuestSession', $_SESSION);
        $_SESSION = checkGuestSession($_SESSION, $target_mask_array["app_id"], $target_mask_array["id"]);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'nach checkGuestSession', $_SESSION);
    }
    
    
    
    
    
    //------------------------------------------------------------------------------------------------------------
    //--Session-Handler Start-------------------------------------------------------------------------------------
    ////------------------------------------------------------------------------------------------------------------
    
    // 1. Session starten (Aufruf durch Login-Maske)----------------------------------------------------
    if(issetKeyLike($_POST, "submit_login") !== false) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Pos 1', 'Login');
        
        //uid, app_id und password aus POST_Array ermitteln; app_id kann auch den Wert false haben
        $accountArray = getAccountdataFromPostArray($_POST);
        
        
        //validator ermitteln
	$validator = getValidator($accountArray, $_SESSION, $target_mask_array["app_id"]);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'ValidatorArray für Account '.$accountArray["uid"], $validator);
	$_SESSION["validator_process_type"] = $validator["validator_process_type"];
        $_SESSION["validator_directory_id"] = $validator["directory.id"];

        //Rollen ermitteln
	$accountRollen = getRoles($validator, $accountArray, $target_mask_array);
              
        // Benutzeraccount durch Verzeichnis validieren
        require_once("../controller/directory/".$validator["directory.validator"]);
        $checkAccount=checkUserAccount($validator["directory.id"], $accountArray["uid"], $accountArray["password"], $accountArray["app_id"]);        
        
        if ($checkAccount==true){
            //Clientidentifier für Prüfung in protectSessionAgainstHijack vorbereiten
            $ip = getIpAdress();
            $browser = $_SERVER["HTTP_USER_AGENT"];
            $_SESSION["identifer"] = $ip.":".$browser;
            //Accountdaten in SESSION ablegen 
            $activeRole = $accountRollen[0];
            $target_mask_array = rebuildTargetMask($target_mask_array, $activeRole);
            $_SESSION = setSessionAttributs($_SESSION, $accountArray["uid"], false, $accountArray["app_id"], $accountRollen, $activeRole, $_SESSION["validator_process_type"], $target_mask_array);
            
        
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Session an Pos 121 ', $_SESSION);
        } else {
            //Wenn der Benutzer/Account durch das Verzeichnis nicht validiert werden konnte, dann ...
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Pos 13 ', 'if-Zweig: checkAccount = false');
            cancelLogin("Sie konnten nicht eingeloggt werden.<br>\r\n Benutzername oder Passwort sind möglicherweise falsch, der Account gesperrt oder der Directory-Server nicht erreichbar. Details können der Debug-Tabelle entnommen werden..<br>\n", 1, "Passwort für Benutzer ".$accountArray["uid"]."falsch", true);
        }
    }
    
    //2.App wechseln
    elseif(isset($_SESSION['uid']) AND $_SESSION['guest_user'] == false AND isset($_GET['change_app'])) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'App-wechseln', $_GET['change_app']);
        //Hier ist Platz für weitere Prüfungen, Bsp.: Timestamp.
        
            $accountArray = array("uid" => $_SESSION["uid"], "app_id" => $_GET['change_app']);
            $validator = getValidator($accountArray, $_SESSION, $target_mask_array["app_id"]);
            $accountRollen = getRoles($validator, $accountArray, $target_mask_array);
            $_SESSION = setSessionAttributs($_SESSION, $accountArray["uid"], false, $accountArray["app_id"], $accountRollen, $accountRollen[0], $validator, $target_mask_array);
            

            
    }
    
    // 3. Sitzung auf Gültigkeit prüfen------------------------------------------------------------
    elseif(isset($_SESSION['uid']) AND $_SESSION['guest_user'] == false) {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Pos 2, Session prüfen', $_SESSION);
        //Hier ist Platz für weitere Prüfungen, Bsp.: Timestamp.
        
            $accountArray = array("uid" => $_SESSION["uid"], "app_id" => $_SESSION["app_id"]);
            $validator = getValidator($accountArray, $_SESSION, $target_mask_array["app_id"]);
            $accountRollen = getRoles($validator, $accountArray, $target_mask_array);
            $_SESSION = setSessionAttributs($_SESSION, $accountArray["uid"], false, $accountArray["app_id"], $accountRollen, $_SESSION["active_role"], $_SESSION["validator_process_type"], $target_mask_array);
            
           
    }
    
    
    // 4. Gastzugang -----------------------------------------------------------------------------
    elseif(isset($guest_user)) {
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Pos 3', 'Gastzugang');
        $myRoles = getRoleByAccount($guest_user, $target_mask_array["app_id"], $target_mask_array["app_id"], $target_mask_array["id"], $target_mask_array["app_id"], $guest_userRoleId);
        
        //Wenn der zuvor verwendete Guest-User keinen Zugriff hat, dann testen, ob der Guest-User des Kernmoduls Zugriff hat.
        if($myRoles == array()) {
            $myRoles = getRoleByAccount(getConfig("guest_user", global_variables::getAppIdFromSYS01()), global_variables::getAppIdFromSYS01(), $target_mask_array["app_id"], $target_mask_array["id"], global_variables::getAppIdFromSYS01(), getConfig("guest_user", global_variables::getAppIdFromSYS01()));
        }
        $_SESSION = setSessionAttributs($_SESSION, $guest_user, true, $target_mask_array["app_id"], $myRoles, $myRoles[0], "roleByAccount", $target_mask_array);

    }
    
    
    // 5. direkter Aufruf der Seite ohne vorhandene Sitzung----------------------------------------
    //    Dieser Fall tritt auf, wenn zuvor kein Gastaccount ermittelt werden konnte oder wenn die Sitzung abgelaufen ist.
    elseif(!isset($_SESSION['uid'])) {
        
        //cancelLogin("Ihre Benutzerdaten konnten nicht geprüft werden.<br>\r\n Eventuell ist Ihre Sitzung abgelaufen.", 1, "Session konnte nicht validiert werden. Eventuell ist die Sitzung abgelaufen", false);
        deniedAccess("-134");
        
    }
    
	
    // 6. Logout-----------------------------------------------------------------------------------
    if(isset($_GET["logout"])) { 
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Pos 5', 'Logout');
        if($_GET["logout"]=="true") { 
            cancelLogin("Sie haben sich abgemeldet.<br>\r\n ", 2, "Benutzer hat sich abgemeldet.", true);
        } 
    } else {
            //Ansonsten Logout-Link bereitstellen --> muss in ../controller/functions.showInhaltObererRand() passieren						 													

    }

    

//    if(isset($_SESSION)) {addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> Sessionvariable nach Durchlauf des Sesionhandler: ', $_SESSION);}
    
    //------------------------------------------------------------------------------------------------------------
    //--Session-Handler Ende-------------------------------------------------------------------------------------
    //------------------------------------------------------------------------------------------------------------
    
    
    
    
    
    
    
    
    
    
    
    
    
    //--Hilfsfunktionen-------------------------------------------------------------------------------
    
    
    /** Extrahiert aus einem POST_Array die Werte der Felder, welche uid, app_id oder password enthalten.
     * Sollten mehrere entsprechende Felder enthalten sein, dann wird der jeweils letzte Wert übermittelt.
     * 
     * @param   Array   $in_PostArray   $_POST
     * @return  Array                   Array mit den keys uid, app_id und password; app_id kann auch den boolean-Wert false annehmen
     */
    function getAccountdataFromPostArray($in_PostArray) {
        $accountdata = array("uid" => "", "app_id" => "", "password" => "");
        foreach ($in_PostArray as $key => $value) {
            if (strpos($key, "uid") !== false) {$accountdata["uid"]=$value;}
            if (strpos($key, "app_id") !== false) {$accountdata["app_id"]=$value;}       //Wenn das Sender-Formular eine App-ID vorgibt
            if (strpos($key, "password") !== false) {$accountdata["password"]=$value;}  
        }
        
        if($accountdata["app_id"] == "") {
            //Wenn das Senderformular keine App-ID vorgegeben hat, dann prüfen, ob es sich um einen internen Account handelt. Wenn ja, liefert dieser die App-ID
            $intern_app_id = getDataFromTableByID(global_variables::getAppIdFromSYS01(), global_variables::getNameOfDbSchemaSYS01(), "account", "app_id", "id = '".$accountdata["uid"]."'");
            if($intern_app_id !== false) {
                $accountdata["app_id"]=$intern_app_id;
            } else {
                require_once("../data/".global_variables::getAppIdFromSYS01()."/plugin/functions_fielddefault.php");
                $accountdata["app_id"]= getCurrentMaskAppID();
            }
        }
        
        return $accountdata;
    }
    
    
    
    /** ergänzt die Session um das Attribut "SessionStorage", falls noch nicht vorhanden.
     * 
     * @param   string  $in_session     Aktuelle Session
     * @return  string                  Session ergänzt um SessionStorage
     */
    function setSessionStorageID($in_session) {
        if(isset($in_session["SessionStorage"])===false) {
            $in_session["SessionStorage"]["1"] = "tab1-Session";
            $in_session["curSessionID"] = "1";
        }
        
        return $in_session;
    }
    
    
    
    /** Prüft, ob IP und Browserkennung mit den in der Session hinterlegten Werten überinstimmt.
     * Wenn nicht wird die Session zerstört und neu aufgebaut. Das Attribut hijack wird auf true gesetzt, damit es später ausgewertet werden kann.
     * 
     * @return  array                       geprüfte Session
     */
    function protectSessionAgainstHijack() {
        if(isset($_SESSION["identifer"])) {
            //bestehende Session -> prüfen, ob IP und Browserkennung stimmen.
            //Falls nicht, Session zerstören und somit Neuanmeldung erzwingen
            $ip = getIpAdress();
            $browser = $_SERVER["HTTP_USER_AGENT"];
            if($_SESSION["identifer"] == $ip.":".$browser) {
                //ok, nothing to do
            } else {
                //maybe Session-hijacking
                $old_identifier = $_SESSION["identifer"];
                session_destroy();  //bestehende Session zerstören, damit bisherige Zugriffsrechte verloren gehen und eine Neuanmeldung erzwungen wird.
                session_start();
                $_SESSION["hijack"] = true;   //Fehlermeldung kann erst nach den folgenden Zeilen nach Debug geschrieben werden.
                $_SESSION["old_identifier"] = $old_identifier;

            }
        } else {
            //nothing ToDo, da es sich nur um eine guest-Session handeln kann
        }
        return $_SESSION;
    }
    
    
    
    /** Ermittelt die IP-Adresse des aufrufenden Clients. Wenn ein Proxy erkannt wurde
     * wird versucht die ursprüngliche IP-Adresse zu ermitteln
     * 
     * @return  string          IPv4-Adresse
     */
    function getIpAdress() {
        if (!empty($_SERVER['HTTP_CLIENT_IP']))   {
            //kein Standard, aber manche Netzwerkkomponenten setzen dieses Attribut
            $client_ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))  {
            //Der Nutzer kam mit Proxy
            $client_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            //Der Nutzer kam ohne Proxy
            $client_ip = $_SERVER['REMOTE_ADDR'];
        }
        
        if($client_ip == "::1") {
            $client_ip = "127.0.0.1";
        }
        return $client_ip;
    }
    
    

    /** Ermittelt auf Basis des Accounts den zu verwendenden Validator.
     * Wenn dies nicht gelingt, wird geprüft, ob anhand der target-Mask oder der Default-Mask
     * der App ein validator ermittelt werden kann.
     * 
     * @param   array   $in_accountArray        Array, mit Daten zum Account (uid, app_id)
     * @param   array   $in_SESSION             aktive SESSION, anhand derer geprüft wird, ob das redirect-Attribut existiert.
     * @param   array   $in_targetMaskApp             MaskApp-ID, welche geöffnet werden soll.
     * @return  array                           Validatorarray mit den Attributen: 
     *                                          array("directory.validator" => "ldap_con.php", "directory.id" => 3, "validator_process_type" => [roleByAccount|roleByMask|undefined])
     */
    function getValidator($in_accountArray, $in_SESSION, $in_targetMaskApp) {
        $feedback = array();
        
        //versuchen, validator auf Basis des Accounts zu ermitteln
        $validator = getValidatorForAccount($in_accountArray["uid"], $in_accountArray["app_id"]);
	
	
	if ($validator != false) {
            //validator konnte mit Hilfe des Account ermittelt werden
            $feedback = $validator;
            $feedback["validator_process_type"] = "roleByAccount";
		
	} else {	
            //validator konnte nicht anhand des Account ermittelt werden. Daher versuchen, anhand
            //der targetMask einen validator zu ermitteln
            if(isset($in_SESSION["redirect"])) {
                //prüfen, ob die LoginMaske nur aufgrund eines redirects aufgerufen wurde 
                $targetMaskAppId = $in_SESSION["redirect"]["request_appid"];
                $targetMaskId = $in_SESSION["redirect"]["request_maskid"];
            } else {
                //Prüfen, ob für die gewünschte App eine default-Startmaske existiert 
                $targetMaskAppId = global_variables::getDefaultMaskAppId($in_targetMaskApp, "start_mask");
                $targetMaskId = global_variables::getDefaultMaskId($in_targetMaskApp, "start_mask");
            }
            
            //Validator mit Hilfe der targetMask ermitteln. Wenn das misslingt, wird false zurückgegeben.
            $validator = getValidatorForMask($targetMaskAppId, $targetMaskId);
            if($validator == false) {
                $feedback["validator_process_type"] = "undefined";
            } else {
                $validator["validator_process_type"] = "roleByMask";
                $feedback = $validator;
            }	
	}
        
        return $feedback;
    }
    
    
    
    /** Ermittelt eine Liste von Rollen, auf die der aktuelle Account Zugriff hat. Der Zugriff ergibt sich entweder
     * aus den Rollenzuordnungen zum Account oder zur Target-Mask.
     * 
     * @param   array   $in_validator           Angaben zum Validator (validator_process_type => [roleByAccount|roleByMask|undefined], directory.validator)
     * @param   array   $in_accountArray        Angaben zum Account (uid, app_id, 
     * @param   array   $in_target_mask_array   Angaben zur target_mask (app_id, id)
     * @return  array                           Liste der verfügbaren Rollen (role.id, role.app_id, role.name)
     */
    function getRoles($in_validator, $in_accountArray, $in_target_mask_array) {
        //Rollen ermitteln
	if($in_validator["validator_process_type"] == "roleByAccount") {
            //validator-prozesstype = roleByAccount
            $accountRollen = getRoleByAccount($in_accountArray["uid"], $in_accountArray["app_id"], $in_target_mask_array["app_id"], $in_target_mask_array["id"]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Validator für Account '.$in_accountArray["uid"].' gefunden', $in_validator["directory.validator"]);
       		
	} elseif($in_validator["validator_process_type"] == "roleByMask") {
            //validator-prozesstype = roleByMask
            $accountRollen = getRoleByMask($in_target_mask_array["app_id"], $in_target_mask_array["id"]);
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Validator für Maske gefunden', $in_validator["directory.validator"]);
               
	} else {
            //cancel login
            cancelLogin("Sie konnten nicht eingeloggt werden.<br>\r\n Benutzername oder Passwort sind falsch.<br>\n", 0, "Validator konnte für Benutzer ".$in_accountArray["uid"]." nicht ermittelt werden.", true);
	}
        
        
        return $accountRollen;
    }
    
    
     
    /**
     * 
     * @param   array     $in_SESSION                 Refernez zum SESSION-Array
     * @param   string    $in_uid             
     * @param   boolean   $in_is_guest_user           Gibt an, ob es sich um einen Guest-User handelt
     * @param   string    $in_app_id                  APP-ID der uid
     * @param   array     $in_roles                   Rollen, auf die uid Zugriff hat. (Zweidimensionales Array: role.id, role.name, role.app_id)
     * @param   array     $in_active_role             die aktive Rolle (role.id, role.name, role.app_id)
     * @param   string    $in_validator_process_type  [roleByAccount|roleByMask|undefined]
     * @param   array     $in_targetMask              Bsp.: Array("app_id" => "SYS01", "id" => "100") 
     * @return  array                                 Session-Array mit neu gesetzten Attributen
     */ 
    function setSessionAttributs($in_SESSION, $in_uid, $in_is_guest_user, $in_app_id, $in_roles, $in_active_role, $in_validator_process_type, $in_targetMask) {
        $in_SESSION['uid'] = $in_uid;            
        $in_SESSION['guest_user'] = $in_is_guest_user;            
        $in_SESSION['app_id']=$in_app_id;            
        $in_SESSION["rollen"] = $in_roles;		
	$in_SESSION["active_role"] = $in_active_role;                      
        $in_SESSION["validator_process_type"] = $in_validator_process_type;
        
       
        
        //Session-Datensatz in Datenbank anlegen oder aktualisieren
        $local_feedback = writeSessionStatusToDb($in_uid, $in_app_id);

        if(isset($in_SESSION["redirect"])) {
            if($in_SESSION["redirect"]["redirect"]!= 1) {
                $setNewTargetMask = true;
                
            } else {
                $setNewTargetMask = false;
            }
        } else {
            $setNewTargetMask = true;
        }
        
        
        if($setNewTargetMask === true) {
            $in_SESSION["target_mask"] = $in_targetMask;
            //GET-Variable ebenfalls anpassen.
            //Anwendungsfall: Target-Mask wird ursprünglich über die GET-Variable ermittelt. Anschließend könnte die Target-Mask jedoch
            //bspw. durch rebuildTargetMask wieder geändert worden sein.
            setTargetMaskToGET($in_targetMask); 
        }

            
        
        return $in_SESSION;
    }
    
    
    
    
    
    
    /** Erstellt oder aktualisiert einen Datensatz zur aktuellen Session in der Datenbank.
     * 
     * @param string    $in_user       aktueller user
     * @param string    $in_app_id     momentan genutzte APP
     * @return bool
     */
    function writeSessionStatusToDb($in_user, $in_app_id) {
        
        $feedback = true;
        
        $session_lifetime = getConfig("session_lifetime", global_variables::getAppIdFromSYS01());
        $last_activity_time = date('Y-m-d H:i:s');
        $end_time = date('Y-m-d H:i:s', strtotime("now +".$session_lifetime." minutes"));
        $browser = $_SERVER['HTTP_USER_AGENT'];
        $cur_user = $in_user;
        $cur_app_id = $in_app_id;                //Wert ist veränderlich, da der angemedete user die APP auch wechseln kann.
        $connection_id = global_variables::getAppIdFromSYS01();
        $schema = global_variables::getNameOfDbSchemaSYS01();
        $table = "session";
        
        $SqlArray = array();
        $SqlArray["schema"] = $schema;
        $SqlArray["table"] = $table;
	$SqlArray["into"]   = "   app_id,           session_id,          valid_from,               valid_to,        browser_id,       ip_adress,           account_id,       last_activity";
	$SqlArray["values"] = "'".$cur_app_id."', '".session_id()."', '".$last_activity_time."', '".$end_time."', '".$browser."', '". getIpAdress()."', '".$cur_user."', '".$last_activity_time."'";
        $SqlArray["update"] = "valid_to = '".$end_time."', last_activity = '".$last_activity_time."', app_id = '".$cur_app_id."', account_id= '".$cur_user."'";
        $SqlArray["where"]  = "session_id='".session_id()."'";
	
        
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = $connection_id;  
        
        
        
        //Prüfen, ob der Session-Datensatz bereits in der Tabelle session existiert
        $exist_ds = getDataFromTableByID($connection_id, $schema, $table, "session_id", $SqlArray["where"]);
        
        if($exist_ds === false) {
            $result = db_connection_handler::insertOnDatabase($connection_id, $SqlArray, __FUNCTION__, false);
        } else {
            $result = db_connection_handler::updateOnDatabase($connection_id, $SqlArray, __FUNCTION__, false);
        }


        if ($result < 0) {
            $feedback = false;
        }  
        
        
        $feedbacktext = getFeedbacktextForFunction($result, global_variables::getAppIdFromSYS01());
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , $feedbacktext);
            
        return $feedback;
    }
    
    
    
    
    

    /** Die Funktion überträgt die Werte mask_id und die mask_app_id von targetMask in die globale
     * GET-Variable. Das ist notwendig, da die GET-Variable noch im späteren Programmverlauf verwendet wird.
     * 
     * @param type $in_targetMask
     */
    function setTargetMaskToGET($in_targetMask) {
        $_GET["mask"] = $in_targetMask["id"];
        $_GET["maskapp"] = $in_targetMask["app_id"];
    }
    
    

    /**
     * Grundeinstellungen für alle Sessions festelgen.
     */
    function setSessionSettings() {
        //Session-Einstellungen
        //Session-Lifetime in Sekunden -> 1800 = 30 Minuten; default 1440
        ini_set('session.gc_maxlifetime', 43000);  
        //Muss identisch sein mit session-Lifetime, damit es garantiert funktioniert. 
        //Dadurch verlängert sich die Session jedoch auch nicht bei User-Aktion. Die Session läuft nach erreichen der Zeit ab.
        //Wenn ein anderes Verhalten gewünscht ist, sollte der nachfolgende Parameter nicht oder auf 0 gesetzt werden.
        //session_set_cookie_params(0);  
        
        //Sorgt dafür, dass nach jedem Session_destroy die letzte ID verworfen wird.
        ini_set('session.use_strict_mode', true);
        
        session_set_cookie_params([
                'lifetime' => 43000,                 //in Sekunden
                'path' => '/',                      //übergreifend belassen, da sonst temp-Pfad während Install-Vorgang nicht akzeptiert wird
                'domain' => $_SERVER['HTTP_HOST'],  // leading dot for compatibility or use subdomain
                'secure' => true,
                'httponly' => false,                //Parameter kann leider nicht durch einen Config-Parameter bestimmt werden, da dann Client bereits vor der Session Daten erhält. -> WhiteScreen
                'samesite' => 'Lax'                // None || Lax  || Strict
            ]);


        // gc (Aufräumen) mit einer Wahrscheinlichkeit von 100% aufrufen 
        // Schlägt fehl, wenn Rechte für den Session-Ordner nicht gegeben sind -> daher auskommentiert und Standardeinstellung belassen.
        //   ini_set('session.gc_probability', 100);            
        //   ini_set('session.gc_divisor', 100);
    }
    
    
    
    /**
     * Setzt den ErrorLevel für PHP-Feedback an den Browser entsprechend dem Config-Parameter "debug_php_errorreporting".
     * Kein Rückgabewert.
     */
    function setErrorLevel() {
        //Fehlermeldungen sollten im Normalfall abgeschaltet sein, damit Anwender keine kryptischen Meldungen und Angreifer keine unterstützenden Informationen erhalten.
        $error_level = getConfig("debug_php_errorreporting", global_variables::getAppIdFromSYS01());
        if($error_level == 0) {$error_level = $error_level;} else {$error_level = E_ALL; ini_set("display_errors", 1);}
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." für PHP-Feedback an den Browser", $error_level);
        error_reporting($error_level);  
    }
    
    
    
    /** Bricht den Anmeldevorgang ab, dokumentiert den Grund und führt den Anwender wieder auf die Ausgangsseite zurück
     * 
     * @param string    $in_message         Meldung, die dem Anwender angezeigt wird
     * @param integer   $in_action          Aktion, die dem Anwender angeboten wird <br />
     *                                      0 = Anwender Link zur Ausgangsseite anbieten. <br />
     *                                      1 = Link zur Standard-Anmeldeseite anbieten <br />
     *                                      2 = Link zur Anmeldeseite der App nachdem zuvor ein Button mit diesem Ziel angeklickt wurde
     * @param string    $in_debug_message   Meldung, die im debug-log geschrieben wird.
     * @param boolean $in_destroy_session Gibt an, ob die Session zerstört werden soll
     */
    function cancelLogin($in_message, $in_action, $in_debug_message, $in_destroy_session) {
        
        
        if          ($in_action == 0) {
            $sender_url = $_SERVER["HTTP_REFERER"];
            $action_message = "Zurück zur <a href=\"$sender_url\">Ausgangsseite</a><br/>";
        } elseif    ($in_action == 1) {
            $target_mask_app_id = $_GET["maskapp"];
            $action_message = "Zurück zur <a href=\"".global_variables::getDefaultMask($target_mask_app_id, "login_mask")."\">Anmeldung</a><br/>";
        } elseif    ($in_action == 2) {
            
            $target_mask_id = $_GET["mask"];
            $target_mask_app_id = $_GET["maskapp"];
            $action_message = "Zurück zur <a href=\"../view/page.php?mask=".$target_mask_id."&maskapp=".$target_mask_app_id."\">Anmeldung</a><br/>";
        }

        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'Abbruch in Session_Handler', $in_debug_message);
        
        
        
        header('Content-Type: text/html; charset=utf-8');
        echo    $in_message;
        echo    "<br />";
        echo    $action_message;
        
        if($in_destroy_session == true) {
            destroyMySession();
            exit;
        } 
    }
    
    

    /**
     * Leert und zerstört das SESSION-Array. Zudem wird die DB-Tabelle session bereinigt.
     */
    function destroyMySession() {
        
        
        //eigene und alle abgelaufenen Sessions aus der DB-Tabelle session löschen
        $now = date('Y-m-d H:i:s');
        $connection_id = global_variables::getAppIdFromSYS01();
        $schema = global_variables::getNameOfDbSchemaSYS01();
        
        $sql_daten["schema"] = $schema;
        $sql_daten["table"] = "session";
        $sql_daten["where"] = "session_id='".session_id()."' or valid_to < '".$now."'";

        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();

        
        // SESSION leeren
        $_SESSION = array();
        // Session zerstören
        session_unset();

        session_destroy();
        
        
        
        
        
        $result = db_connection_handler::deleteOnDatabase($connection_id, $sql_daten, __FUNCTION__, false);
        
        
        
        
       
    }
    
    

    /** Prüft, ob der Gastuser Zugriff hat. Falls nicht, wird die Session zerstört und ein neue erstellt. 
     * Falls ein redirect besteht, bleibt dieser erhalten.
     * Auch form_backup bleibt erhalten.
     * 
     * @param   array   $in_SESSION     Referenz auf das SESSION-Array
     * @param   string  $in_maskApp     App-ID der aufgerufenen Maske
     * @param   integer $in_maskId      ID der Maske
     */
    function checkGuestSession(&$in_SESSION, $in_maskApp, $in_maskId) {
        //Prüfen, ob guest auf die angeforderte Maske zugreifen darf.
        $Zugriff_erlaubt = checkPermission($in_SESSION["uid"], $in_SESSION["app_id"], $in_maskApp, $in_maskId, $in_SESSION); 
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . 'array Zugriff_erlaubt für Masken:', $Zugriff_erlaubt);
            
        //Falls Guest nicht zugreifen darf, wird die Guest-Session zerstört.
        if($in_SESSION['guest_user'] == true AND $Zugriff_erlaubt["access"] != true) {
            $redirect_backup = "";
            $form_backup = "";
            if(isset($in_SESSION["redirect"])){
                //Wenn ein Redirect-Zweig in der Session existiert, wird dieser gesichert
                $redirect_backup = $in_SESSION["redirect"];
            } 
            
            if(isset($in_SESSION["forms_backup"])) {
                //Wenn form_backup vorhanden ist, wird es gesichert. Nur so können Ajax-Abfragen bei abgelaufenen oder zerstörten Sessions noch sinnvolle Ergebnisse liefern.
                $form_backup = $in_SESSION["forms_backup"];
            }
            
            $in_SESSION = array();
            // Session zerstören
            destroyMySession();
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, 'destroy_guest_Session:');
            
            session_start();
            if(is_array($redirect_backup)) {$_SESSION["redirect"] = $redirect_backup;}
            if(is_array($form_backup)) {$_SESSION["forms_backup"] = $form_backup;}

        } else {
            //Gastuser = false -> Dieser Fall wird separat behandelt
            //Gastuser = true und access = true -> nothing Todo
        }
        return $_SESSION;
    }
    
    

    /** Prüft, ob in der aufgerufenen URL verbotene Strings enthalten sind.
     * 
     * @return      boolean         True, wenn verbotene Strings erkannt wurden.
     */
    function checkUrlForForbiddenStrings() {
        $called_url=$_SERVER["REQUEST_URI"];
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ .'aufgerufene URL.', $called_url);

        $forbiddenStrings = array('${', 'jquery{');
        foreach ($forbiddenStrings as $curForbiddenStr) {
            if (strpos($called_url, $curForbiddenStr)) {
                $feedback = true;
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ .'In der aufgerufenen URL wurden verbotene Zeichen entdeckt.', $called_url);
                break;
            } else {
                $feedback = false;
            }
        }
        
        return $feedback;
    }
    
    

    /**
    * Lenkt den Nutzer auf die Login-Maske um, wenn der Zugriff verweigert wurde.
    * Das ursprüngliche URL-Ziel wird in SESSION["redirect"] abgelegt
    * 
    */
    function deniedAccess($in_reason) {
        
        $redirect_array = array();
        $redirect_array["redirect"] = 1;
        $redirect_array["redirect_handled"] = 0;                                //Merkmal, um zu erkennen, um diese Umleitung schon verarbeitet wurde
        $redirect_array["reason"] = $in_reason;
        $redirect_array["reason_text"] = "access_denied";    
            
        if($in_reason == "-130_info") {
            //-130 -> die Rolle darf nicht auf die gewünschte Ressource zugreifen
            
            //Function-ID in URI deaktivieren, da sonst nach dem Redirect die Funktion aufgerufen wird, obwohl weder POST-Array noch form-Array erhalten sind.
            $requestUriWithoutFunction = str_replace("button_action_function_id", "deactivate_button_action_function_id", $_SERVER['REQUEST_URI']); 
            //Targetmask und mask_app_id in SESSION für redirect hinterlegen
            $redirect_array["request_uri"] = $requestUriWithoutFunction;
            $redirect_array["request_appid"] = $_GET['maskapp'];
            $redirect_array["request_maskid"] = $_GET['mask'];
        
        } elseif($in_reason == "-134") {
            //-134 -> Session abgelaufen oder falsche Anmeldung
            
            cancelLogin("Ihre Sitzung ist abgelaufen.<br>\r\n ", 2, "Bittemelden Sie sich erneut an.", true);
            
        } elseif($in_reason == "132") {
            //-132 -> die IP-Adresse darf nicht auf die gewünschte Ressource zugreifen
            $redirect_array["request_uri"] = global_variables::getDefaultMask(global_variables::getAppIdFromSYS01(), "start_mask");
            $redirect_array["request_appid"] = global_variables::getDefaultMaskAppId(global_variables::getAppIdFromSYS01(), "login_mask");
            $redirect_array["request_maskid"] = global_variables::getDefaultMaskId(global_variables::getAppIdFromSYS01(), "login_mask");
        }
        
        //Loginmaske und Formular ermitteln
        $defaultLoginPage = global_variables::getDefaultMask($redirect_array["request_appid"], "login_mask");
        
        $_SESSION['redirect'] = $redirect_array;
        $_SESSION['guest_user'] = true;                                         //dadurch wird sichergestellt, dass der Aufruf der LoginPage zulässig ist.
        unset($_SESSION['target_mask']);                                        //target_mask wieder entfernen, da sonst Endlosschleife entstehen kann.
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' SESSION_ARRAY', $_SESSION);
        
        
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' Redirect zur Login-Page', $defaultLoginPage);
        header("Location: ".$defaultLoginPage);
        exit;
        
        
    }
   
   
    
    /** Ermittelt für den aktuellen URL-Aufruf die gewünschte Maske und app_id. Dabei wird ein 
     * möglicherweise vorliegender redirect beachtet
     * 
     * @param   array   $in_SESSION     Session-Array
     * @return  array                   Bsp.: Array("app_id" => "SYS01", "id" => "100") 
     */
    function getTargetMaskArray($in_SESSION) {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' SESSION_ARRAY', $_SESSION);
        
        $target_mask_array = array();
        
        if (isset($_GET['maskapp'])) {
            //Normalfall beim Aufruf einer Maske
            $target_mask_array["app_id"] = $_GET['maskapp'];
            $target_mask_array["id"] = $_GET["mask"];      
        } else {
            //$_GET['maskapp'] ist nicht gesetzt, wenn der Aufruf über ajaxRequest.php erfolgt
            $target_mask_array["app_id"] = global_variables::getAppIdFromSYS01();                                         
            $target_mask_array["id"] = 0;                                                            
        }
        
        
        if(isset($in_SESSION["redirect"])) {
            //login-Maske wurde durch einen redirect aufgerufen.
            if($in_SESSION["redirect"]["redirect_handled"] == 1) {
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, ' targetmask aus session-redirect ermitteln');
        
                $target_mask_array["app_id"] = $in_SESSION["redirect"]["request_appid"];
                $target_mask_array["id"] = $in_SESSION["redirect"]["request_maskid"];
            }
        } 
        
        return $target_mask_array;
    }
    
    

    /**Prüft, ob für die APP der aktiven Rolle eine abweichende Start-Maske hinterlegt wurde. Falls ja, wird diese als TargetMask zurückgegeben.
     * Falls nicht, wird $in_targetMask zurückgegeben.
     * 
     * @param   array   $in_targetMask      Bsp.: Array("app_id" => "SYS01", "id" => "100") 
     * @param   array   $in_activeRole      Array(role.id, role.app_id, role.name)
     * @return  array                       Bsp.: Array("app_id" => "INV11", "id" => "775") 
     */
    function rebuildTargetMask($in_targetMask, $in_activeRole) {
        $new_targetMask = $in_targetMask;
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' active Role', $in_activeRole);
        
        if($in_activeRole["role.app_id"] != "") {
            //Startmaske der Target-App
            
            //Prüfen, ob für die Rolle eine start_mask definiert wurde
            $startmask_by_role = getRoleStartmask($in_activeRole["role.app_id"], $in_activeRole["role.id"]);
            if($startmask_by_role != array()) {
                //Start_Mask wurde über Rolle ermittelt
                $new_targetMask["app_id"] = $startmask_by_role["mask_app_id"];
                $new_targetMask["id"] = $startmask_by_role["mask_id"];
            } else {
                $new_targetMask["app_id"] = global_variables::getDefaultMaskAppId($in_activeRole["role.app_id"], "start_mask");
                $new_targetMask["id"] = global_variables::getDefaultMaskId($in_activeRole["role.app_id"], "start_mask");
            }
        }
        
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' Rückgabe targetMask', $new_targetMask);
        return $new_targetMask;
        
    }

   
   
?>



