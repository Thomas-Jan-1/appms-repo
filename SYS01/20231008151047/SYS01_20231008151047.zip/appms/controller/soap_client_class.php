<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

/**
 * Bietet Methoden zur Steuerung von SOAP-Anfragen
 *
 * @author thomas
 */
class soap_client_appms {
    

    
    /**
     * 
     * @var     object          Soap-Verbindung
     */
    private $soap;
    
    
    
    
    /** Bietet Methoden zur Steuerung von SOAP-Anfragen. 
     * Der Constructor übernimmt bereits initiale Arbeitsschritte. Dabei werden die Klassen-Eigenschaften vorbelegt.
     *  
     * @param   string  $in_location        URL des Webservices; Bsp.: http://localhost/soap/soapserver.php
     * @param   boolean $in_trace           [optional] Gibt an, ob trace-stack (debug) aktiviert werden soll. Default = false
     * @param   string  $in_uri             [optional] Domäne, i.d.R. identisch zu location. Default = location
     * @param   string  $in_soap_version    [optional] Version; Default = SOAP_1_2
     * @return  int                         1 = alles ok
     */
    public function __construct($in_location, $in_trace = false, $in_uri = "", $in_soap_version = "SOAP_1_2") {
        $feedback = 1;
        if($in_uri == "") {$in_uri = $in_location;}	

        
        $this->soap = new SoapClient( 
            null, 
            array( 
                  "location" => $in_location,
                  "uri" => $in_uri,
                  "soap_version" => $in_soap_version,
                  "trace" => $in_trace
                 ) 
            );
        
        
        
        return $feedback;
    }
    
    
    public function soap_call($in_target_function, $in_paramlist) {
        $result = $this->soap->__soapCall($in_target_function, $in_paramlist);
        return $result;
    }
    
    
}
