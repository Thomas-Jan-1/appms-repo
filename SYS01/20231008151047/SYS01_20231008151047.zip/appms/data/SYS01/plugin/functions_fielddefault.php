<?php
/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    



//In dieser Datei werden Funktionen angeboten, die in feld.vorgabewert (DB-Spalte im Schema manager) genutzt werden können

    /** liefert das aktuelle Datum im Format "Y-m-d H:i:s" (Bsp.: 2001-03-10 17:16:18 )
     * die meisten relationalen DBMS sollten dieses in einer Spalte vom Typ timestamp speichern können.
     * WICHTIG: ShowFields stellt das nur richtig dar, wenn input-type = datetime-local.  
     * 
     * @return date 
     */
    function now() {
        return date("Y-m-d\TH:i:s");                   
    }

    
    /** liefert das aktuelle Datum im Format "Y-m-d" (Bsp.: 2001-03-10 )
     * WICHTIG: ShowFields stellt das nur richtig dar, wenn input-type = date.  
     * 
     * @return date
     */
    function today() {
        return date("Y-m-d");                   
    }
    
    
    
    

    
    
    /** liefert den aktuell angemeldeten User (account.id)
     * 
     * @return string
     */
    function currentUser() {
        return $_SESSION["uid"];
    }
    
    
    
    
    
    
    /** liefert die Mailadresse des aktuell angemeldeten Users. Diese wird 
     * aus der account.id und dem Config-Parameter mail_domain gebildet.
     * 
     * @param   string  $in_app_id      APP-ID, des Config-Parameters "mail-domain"
     * @return string
     */
    function currentUserMail($in_app_id) {
        $feedback = currentUser()."@".getConfig("mail_domain", $in_app_id);
        return $feedback; 
    }
    
    
    
    /** liefert die Mailadresse des aktuell angemeldeten users. Die Mailadresse wird
     * anhand der account_id des aktuellen users aus einer Mapping-Tabelle ausgelesen.
     * Wenn keine Mailadresse über die Mappingtabelle ermittelt werden kann, dann 
     * wird die Funktion currentUserMail aufgerufen.
     * 
     * @param   string  $in_app_id                  APP-ID, welche connection_id genutzt wird.
     * @param   string  $in_schema                  Schema, in dem sich die Mapping-Tabelle befindet
     * @param   string  $in_table                   Name der Mapping-Tabelle
     * @param   string  $in_searchcolumn            DB-Spalte, welche in der Mappingtabelle die Mailadresse enthält
     * @param   string  $in_accountcolumn           DB-Spalte, welche in der Mappingtabelle die account_id (user) enthält
     * @return  string                              Mailadresse
     */
    function currentUserMailByMappingtable($in_app_id,$in_schema, $in_table, $in_searchcolumn, $in_accountcolumn) {
        $currentuser = currentUser();
        $condition = $in_accountcolumn."='".$currentuser."'";
        $mail_address = getDataFromTableByID($in_app_id, $in_schema, $in_table, $in_searchcolumn, $condition);
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Mailadresse über Mappingtabelle ermitteln", "Schema: ".$in_schema. ", Tabelle: ".$in_table.", searchcolumn: ".$in_searchcolumn.", user".$currentuser);
            
        
        if ($mail_address === false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Mailadresse über Mappingtabelle nicht ermittelbar", "Schema: ".$in_schema. ", Tabelle: ".$in_table.", searchcolumn: ".$in_searchcolumn.", user".$currentuser);
            $mail_address = currentUserMail($in_app_id);
        } else {
            //Wenn keine gültige Mailadresse ermittelt werden konnte, dann Leerstring zurückgeben.
            //dies kann auftreten, wenn über diese Funktion unerlaubt Daten aus einer artfremden Tabelle ausgelesen werden sollen.
            if (filter_var($mail_address, FILTER_VALIDATE_EMAIL)) {
                //syntaktisch korrekte Mailadresse
            } else {
                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> falsche Mailadresse, daher Rückgabe Leerstring ", $mail_address, "SECURITY");
                $mail_address = "";
            }
        }
        
        
        
        return $mail_address;
    }
    
    
    
    /** Ermittelt die APP-ID der aktiven Rolle
     * 
     * @return  String          Bsp.: "SYS01"
     */
    function currentRoleAppID() {
        return $_SESSION["active_role"]["role.app_id"];
    }
    
    
    
    /** Ermittelt die ID der aktiven Rolle
     * 
     * @return  String          Bsp.: "139"
     */
    function currentRoleID() {
        return $_SESSION["active_role"]["role.id"];
    }
    
    
    
    
    /** Ermittelt die APP-ID des aktiven Accounts
     * 
     * @return  String          Bsp.: "SYS01"
     */
    function currentAccountAppID() {
        return $_SESSION["app_id"];
    }
    
    
    
    /** Prüft, ob in der Sessionvariablen eine Nachricht (Vorgabewert)
     * für ein Feld hinterlegt ist
     * 
     * @param   integer     $in_field_id        ID des Feldes
     * @return  string                          Nachricht. Wenn keine Nachricht vorhanden ist wird "[ - ]" zurückgegeben
     */
    function getMessageForField($in_field_id) {
        
        if(isset($_SESSION["Fieldmessages"][$in_field_id])) {
            $feedback = $_SESSION["Fieldmessages"][$in_field_id];
        } else {
            $feedback = "[ - ]";
        }
        return $feedback;
    }
    
    
    
    /**
     * Gibt die ID der aktuell aufgerufene Maske zurück. Diese wird aus dem GET-Parametern 
     * "mask" des letzten URI-Aufrufes ermittelt.
     * 
     * return   mixed       Bsp.: 100 oder false im Fehlerfall.
     */
    function getCurrentMaskID() {
        $feedback = "";
        if(isset($_GET["mask"])) {
            $feedback= $_GET["mask"];
        } else {
            $feedback = false;
        }
        
        return $feedback;
    }
    
    
    /**
     * Gibt die APP-ID der aktuell aufgerufene Maske zurück. Diese wird aus dem GET-Parametern 
     * "maskapp" des letzten URI-Aufrufes ermittelt.
     * 
     * return   mixed       Bsp.: SYS01 oder false im Fehlerfall.
     */
    function getCurrentMaskAppID() {
        $feedback = "";
        if(isset($_GET["maskapp"])) {
            $feedback= $_GET["maskapp"];
        } else {
            $feedback = false;
        }
        
        return $feedback;
    }
    
    
    
    
    /** Ermittelt für ein ID-Feld (Integer) den nächsten freien Eintrag, ggfs. innerhalb eines vorgegebenen Wertebereichs.
     * 
     * @param   string  $in_app_id      App-ID der Tabelle. Diese wird als Connection-ID genutzt
     * @param   string  $in_schema      Name des Datenbankschemas
     * @param   string  $in_table       Name der Datenbanktabelle
     * @param   string  $in_column      Name der ID-Spalte
     * @param   integer $in_min         [optional] Falls ein Wertebereich genutzt werden soll, dann ist dies der minimale Wert
     * @param   integer $in_max         [optional] Falls ein Wertebereich genutzt werden soll, dann ist dies der maximale Wert. Es ist auch möglich nur den minimalen Wert anzugeben.
     * @return  mixed                   Entweder die nächste freie ID (integer) oder die Meldung "keine freie ID" (string)
     */
    function getNextID($in_app_id, $in_schema, $in_table, $in_column, $in_min = NULL, $in_max = NULL) {
        
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Parameter ", "$in_app_id, $in_schema, $in_table, $in_column, $in_min, $in_max", "INFO");

        if(isset($in_min) AND isset($in_max)) {
            $condition = $in_column." > ".$in_min." AND ".$in_column." < ".$in_max;
        } elseif (isset($in_min)) {
            $condition = $in_column." > ".$in_min;
        } else {
            $condition = "";
        }
        
        $max_id = getMaxValue($in_app_id, $in_schema, $in_table, $in_column, $condition);
        
        if($max_id !== false AND $max_id != "") {
            //letzte vergebene ID um 1 erhöhen
            $feedback = $max_id + 1;
        } elseif ($max_id == "") {
            //im Wertebereich wurde noch keine ID vergeben.
            $feedback = $in_min + 1;
        } else {
            $feedback = "keine freie ID";
        }
        return $feedback;
    }
    
    
    
    
    /**
     * Gibt eine kommaseparierte Liste aller Maskenelemente der aktuellen Maske, deren Name "MEGruppe Seite" enthält,
     * zurück.
     * 
     * @return  string          Bsp.: "102,103"
     */
    function getMaskelementsFromCurMask() {
        $mask_id = getCurrentMaskID();
        $mask_app_id = getCurrentMaskAppID();
        $delimiter = "";
        $feedback = "";
        
        $mask_element_list1 = getHtmltaggroupFromMask($mask_app_id, $mask_id, "Maskenelementgruppe für Seite");
        $mask_element_list2 = getHtmltaggroupFromMask($mask_app_id, $mask_id, "MEGruppe Seite");
        
        $mask_element_list = array_merge($mask_element_list1, $mask_element_list2);
        if($mask_element_list !== false) {
            foreach ($mask_element_list as $key => $mask_element) {
                $feedback = $feedback.$delimiter.$mask_element["htmltaggroup_has_html_tag.htmltaggroup_id"];
                $delimiter = ",";
            }
        } else {
            $feedback = "0";
        }
        
        return $feedback;
    }
    
    
    
    
    
    /** Wenn in einer Maske eine Workflow steckt, wird der Name des Workflows zurückgegeben.
     * 
     * @param   object  $in_pagedata        Refernez auf das Pagedata-Object
     * @return  string
     */
    function getWorkflowName($in_pagedata) {
        
        $workflow_object = $in_pagedata->getWorkflow();
        if($workflow_object !== false) {
            $feedback = $workflow_object->getName();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> WorkflowName: ', $feedback);
            
        } else {
            $feedback = "workflow-name";
        }
        return $feedback;
    }
    
    
    
    /** Wenn in einer Maske eine Workflow steckt, wird die Beschreibung des Workflows zurückgegeben.
     * 
     * @param   object  $in_pagedata        Refernez auf das Pagedata-Object
     * @return  string
     */
    function getWorkflowDescription($in_pagedata) {
        $workflow_object = $in_pagedata->getWorkflow();
        if($workflow_object !== false) {
            $feedback = $workflow_object->getDescription();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> WorkflowDescription: ', $feedback);
            
        } else {
            $feedback = "workflow-description";
        }
        return $feedback;
        
    }
    
    
    
    /** Wenn in einer Maske eine Workflow steckt, wird die Beschreibung des aktuellen Steps zurückgegeben.
     * 
     * @param   object  $in_pagedata        Refernez auf das Pagedata-Object
     * @return  string
     */
    function getWorkflowStepDescription($in_pagedata) {
        $workflow_object = $in_pagedata->getWorkflow();
        if($workflow_object !== false) {
            $feedback = $workflow_object->getStepDescription();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> WorkflowStepDescription: ', $feedback);
            
        } else {
            $feedback = "step-description";
        }
        return $feedback;
    }
    
    
    
    /** Wenn in einer Maske eine Workflow steckt, wird die Beschreibung des aktuellen Steps zurückgegeben.
     * 
     * @param   object  $in_pagedata        Referenz auf das Pagedata-Object
     * @return  string
     */
    function getWorkflowMaxStep($in_pagedata) {
        $workflow_object = $in_pagedata->getWorkflow();
        if($workflow_object !== false) {
            $feedback = $workflow_object->getMaxStep();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> WorkflowMaxStep: ', $feedback);
            
        } else {
            $feedback = "3";
        }
        return $feedback;
        
    }
    
    
    
    
    
    /** ermittelt die From-Adresse aus workflow_status, welche beim ersten Step verwendet wurde.
     * 
     * @param   object  $in_pagedata
     * @return  string
     */
    function getWorkflowFirstStepFromMail($in_pagedata) {
        $workflow_object = $in_pagedata->getWorkflow();
        if($workflow_object !== false) {
            $feedback = $workflow_object->getFrommailFromFirstStep();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> WorkflowFirstStepFromMail: ', $feedback);
            
        } else {
            $feedback = "from-Mail from first Step";
        }
        return $feedback;
        
    }
    
    
    /** Wenn in einer Maske ein Workflow verknüpft ist, dann wird der Name des aktuellen Steps zurückgegeben.
     * 
     * @param   object  $in_pagedata        Referenz auf das Pagedata-Object
     * @return  string
     */
    function getWorkflowStepName($in_pagedata) {
        $workflow_object = $in_pagedata->getWorkflow();
        if($workflow_object !== false) {
            $feedback = $workflow_object->getCurrentStepName();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> name from current step: ', $feedback);
            
        } else {
            $feedback = "name from current step";
        }
        return $feedback;
        
    }
    
    

?>

