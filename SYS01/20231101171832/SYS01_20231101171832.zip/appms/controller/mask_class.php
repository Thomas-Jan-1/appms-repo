<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */    

/**
 * Die Klasse stellt Funktionen zum erstellen und verwalten von Masken bereit.
 *
 * @author Thomas
 */
class mask {
    /**
     *
     * @var     string      APP-ID der Maske; bspw.: CMS11 
     */
    protected $app_id;
    
    /**
     *
     * @var     integer     ID des css_templates 
     */
    protected $template_id;
    
    /**
     *
     * @var     integer     APP-ID des css_templates 
     */
    protected $template_app_id;
    
    /**
     *
     * @var     string      Name der Maske 
     */
    protected $name;
    
    /**
     *
     * @var     string      PHP-Datei, welche die Maske steuert (i.d.R. page.php) 
     */
    protected $link;
    
    /**
     *
     * @var     integer     ID der übergeordneten Maske oder "" (Leerstring)
     */
    protected $parent_mask;
    
    /**
     *
     * @var     integer     APP-ID der übergeordneten Maske oder "" (Leerstring)
     */
    protected $parent_mask_app;
    
    /**
     *
     * @var     integer     Sortierung der Maske innerhalb eines Navigationsmenü-Knoten (parent_mask) 
     */
    protected $sort;
    
    /**
     *
     * @var     integer     ID der neu erstellten Maske 
     */
    protected $id;
    
    /**
     *
     * @var     integer     ID der htmltaggroup 
     */
    protected $htmltaggroup_id_forForms;
    
    /**
     *
     * @var     integer     ID des Levels der Maske, abhängig von parent_node
     */
    protected $level;
    
    /**
     *
     * @var     integer     ID einer Navigationsmenügruppe (siehe Konstantentyp-ID 188) 
     */
    protected $navgroup;
    
    /**
     *
     * @var     integer     Sortierreihenfolge der Maske innerhalb der Navigationsmenügruppe 
     */
    protected $navgroupsort;
    
    /**
     *
     * @var     object      Referenz auf das pagedata-object 
     */
    protected $pagedata;
    
    
    
    /** Klasse erstellt eine neue Maske inkl. aller notwendigen Elemente (Maskenelement-Gruppe usw.)
     * Zusätzlich bietet die Klasse weitere Methoden zur Verwaltung der Maske (addAccess usw.)
     * Über die Methode getMaskID() kann die ID der angelegten Maske ermittelt werden.
     * 
     * @param   object  $in_pagedata        Referenz zum pagedata_object
     * @param   string  $in_app_id          [optional] APP-ID der Maske, falls eine bereits bestehende Maske verwaltet werden soll
     * @param   int     $in_id              [optional] ID der Maske, falls eine bereits bestehende Maske verwaltet werden soll
     */
    function __construct(&$in_pagedata, $in_app_id = "", $in_id = "") { 
        $this->pagedata = $in_pagedata;
        if($in_app_id !== "") {$this->app_id = $in_app_id ;}
        if($in_id !== "") {$this->id = $in_id ;}
        
    }
    
    
    /** Legt einen neuen Datensatz in der DB-Tabelle mask auf Basis der im Post-Objekt
     * übermittelten Daten an.
     * 
     * @throws Exception    -2010 im Fehlerfall
     * 
     * @param   sting   $in_app_id                  APP-ID der Maske
     * @param   sting   $in_css_template_app_id     APP-ID des CSS_Template; kann auch ein Leerstring sein ("")
     * @param   integer $in_css_template_id         ID des CSS-Templates; kann auch ein Leerstring sein ("")
     * @param   sting   $in_name                    Name der Maske; wird auch für Maskenelementgruppe und ggf. erstes Formular genutzt.
     * @param   sting   $in_link                    Name der rendernden PHP-Datei (bspw.: page.php)
     * @param   sting   $in_parent_mask_app         APP-ID der übergordneten Maske; kann auch ein Leerstring sein ("")
     * @param   integer $in_parent_mask             ID der übergeordneten Maske; kann auch ein Leerstring sein ("")
     * @param   integer $in_sort                    Sortierkennzahl
     * @param   integer $in_navgroup                ID eines zusätzlichen Navigationsgruppe; kann auch ein Leerstring sein ("")
     * @param   integer $in_navgroup_sort           Sortiermerkmal innerhalb der zusätzlichen Navigationsgruppe; kann auch ein Leerstring sein ("")
     
     */
    public function addNewMask($in_app_id, $in_css_template_app_id, $in_css_template_id, $in_name, $in_link, $in_parent_mask_app, $in_parent_mask, $in_sort, $in_navgroup, $in_navgroup_sort) {
        $feedback = false;
        
        
        //Attribute belegen	
        $this->app_id = $in_app_id;
        $this->template_app_id = $in_css_template_app_id;
        $this->template_id = $in_css_template_id;
        $this->name = preg_replace ( '/[^a-zA-Z0-9äÄöÖüÜß_ -]/i', '', $in_name);
        $this->link = $in_link;
        $this->parent_mask_app = $in_parent_mask_app;
        $this->parent_mask = $in_parent_mask;
        $this->sort = $in_sort;
        $this->navgroup = $in_navgroup;
        $this->navgroupsort = $in_navgroup_sort;
        if($this->parent_mask == "") {
            $this->level = 1;
        } else {
            //Wenn eine Maske einer anderen nachgeordnet ist, dann wird level eins höher, als parent_level gesetzt.
            $mask_parentlevel = getDataFromTableByID(global_variables::getConnectionIdOfDbSchemaSYS01(), global_variables::getNameOfDbSchemaSYS01(), "mask", "level", "app_id = '".$in_app_id."' AND id = ".$this->parent_mask);
            if($mask_parentlevel !== false) {
                $this->level = $mask_parentlevel + 1;
            } else {
                $this->level = 1;
            }
            
        }
        
        
        $my_mask_id = setNewMask(   $this->pagedata, 
                                    $this->app_id,
                                    $this->template_app_id,
                                    $this->template_id, 
                                    $this->name, 
                                    $this->link, 
                                    $this->parent_mask_app,
                                    $this->parent_mask, 
                                    $this->name, 
                                    $this->sort, 
                                    $this->level, 
                                    $this->navgroup, 
                                    $this->navgroupsort);
        
        if($my_mask_id !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Maske angelegt: ".$my_mask_id);
            $this->id = $my_mask_id;
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Maske konnte nicht angelegt werden!", "ERROR");
            throw new Exception(-2010);
        }
        
        
        //a) htmltaggroup anlegen; Diese nimmt später weitere Maskenelemente auf.
        $this->addHtmlTagGroup();
        
        //htmltaggroup (a) mit Maske verknüpfen
        $this->addhtmlTagGroupToMask($this->app_id, $this->htmltaggroup_id_forForms);
        
        //b) htmltaggroup (default-Grundgerüst) der APP mit der Maske verknüpfen
        $param = str_replace(" ", "", getConfig("default_mask_htmltaggroup", $this->app_id));       //Parameter enthält Masken-ID und APP-ID durch Komma getrennt
        $param_array = explode(",", $param);
        $default_htmlgroup_id = $param_array[0];
        $default_htmlgroup_app_id = $param_array[1];
        $this->addhtmlTagGroupToMask($default_htmlgroup_app_id, $default_htmlgroup_id);
        
        
    }
    
    
    
    /** Legt eine htmltaggroup für die Maske an.
     * 
     * @throws  Exception       -2013 im Fehlerfall
     */
    private function addHtmlTagGroup() {
        $htmltaggroup_id = setNewHtmlTagGroup($this->pagedata, $this->app_id, "MEGruppe Seite ".$this->name, 0);
        if($htmltaggroup_id !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "HtmlTagGroup angelegt: ".$htmltaggroup_id);
            $this->htmltaggroup_id_forForms = $htmltaggroup_id;
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "HtmlTagGroup konnte nicht angelegt werden!", "ERROR");
            throw new Exception(-2013);
        }
    }
    
    
    /** Ordnet eine htmltaggroup (Maskenelementgruppe einer Maske zu
     * 
     * @param   string      $in_htmltaggroup_app_id     APP-ID der htmltaggroup
     * @param   integer     $in_htmltaggroup_id         ID der htmltaggroup
     * @return  boolean
     */
    public function addhtmlTagGroupToMask($in_htmltaggroup_app_id, $in_htmltaggroup_id) {
        $feedback = setHtmltaggroupToMask($this->pagedata, $in_htmltaggroup_app_id, $in_htmltaggroup_id, $this->app_id, $this->id);
        
        if($feedback !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "htmltaggroup ".$in_htmltaggroup_app_id."-".$in_htmltaggroup_id." wurde der Maske zugeordnet.");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "htmltaggroup ".$in_htmltaggroup_app_id."-".$in_htmltaggroup_id." konnte der Maske nicht zugeordnet werden.", "ERROR");
        }
        
        return $feedback;
    }
    
    
    
    /** Löscht alle Datensätze aus der Tabelle htmltaggroup (Maskenelementgruppe), die im Parameter $in_ids übergeben werden.
     * 
     * @param   array   $in_ids         ID der htmltaggroup
     * @return  int                     [3|-3|-31] -> [succes|error] -> Fehlerdetails werden in die Debug-Tabelle geschrieben.
     */
    private function deleteHtmltaggroups($in_ids) {
        $schema_kernel = global_variables::getNameOfDbSchemaSYS01();
        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Aufruf mit id-List', $in_ids);
        $feedback = 3;

        //SQL-Array für Löschbefehl aufbauen
        $sql_daten["schema"] = $schema_kernel;
        $sql_daten["table"] = "htmltaggroup";
        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = false;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();
        
        foreach ($in_ids as $cur_htmltaggroup) {
            $sql_daten["where"] = "id=".$cur_htmltaggroup." AND app_id = '".$this->app_id."'";
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> sql_daten für delete', $sql_daten);
            $feedback = deleteData($sql_daten, $dummy_form, $this->pagedata->getSessionArray()["uid"], $this->pagedata);
            
        }   

        return $feedback;
    }
    
    
    
    /** Die Funktion ermittelt alle Maskenelemente der aktuellen Maske, die im Namen den String
     * "%MEGruppe Seite%" tragen. Nur diese Maskenelemente wurden bei der Anlage der
     * Maske automatisch angelegt. Maskenelemente, welche Symbolleisten enthalten, bleiben somit enthalten.
     * 
     * @return   array                      Liste der Id's der Maskenelemente.
     */
    public function getMaskelementsFromMask() {
        $mask_id = $this->id;
        $mask_app_id = $this->app_id;
        $feedback = array();
        
        $mask_element_list = getHtmltaggroupFromMask2($mask_app_id, $mask_id, "MEGruppe Seite");
        if($mask_element_list !== false) {
            foreach ($mask_element_list as $key => $mask_element) {
                $feedback[] = $mask_element["htmltaggroup.id"];
            }
        } 
        
        return $feedback;
    }
    
    
    
    /** Löscht eine Maske aus der Tabelle mask.
     * 
     * @param   string  $in_mask_name       Name wird für den Logdata-Datensatz benötigt
     * @return  int                         [3|-3|-31] -> [succes|error] -> Fehlerdetails werden in die Debug-Tabelle geschrieben.
     */
    public function deleteMask($in_mask_name) {
        $schema_kernel = global_variables::getNameOfDbSchemaSYS01();
        
        //Maskenelemente suchen, welche exclusiv zu dieser Maske gehören, um diese im Anschluss löschen zu können.
        //Die Suche der Maskenelemente muss vor dem Löschen der Maske erfolgen, da sie sonst über die Verknüpfung nicht mehr ermittelt werden können.
        $my_htmltaggroup_ids = $this->getMaskelementsFromMask();
        
        

        //SQL-Array für Löschbefehl aufbauen
        $sql_daten["schema"] = $schema_kernel;
        $sql_daten["table"] = "mask";
        $sql_daten["where"] = "id=".$this->id." AND app_id = '".$this->app_id."'";
        $sql_daten['logdata_id_data'] = $this->id;
        $sql_daten["logdata"] = "Seite/Maske ".$in_mask_name." gelöscht";

        $dummy_form = array();
        $dummy_form["form.app_id"] = global_variables::getAppIdFromSYS01();     
        $dummy_form["form.logging"] = true;
        $dummy_form['form.log_id_spalte'] = "id";
        $dummy_form['form.name'] = $in_mask_name;
        $dummy_form["form.connection_id"] = global_variables::getAppIdFromSYS01();
        
        //Maske löschen
        $feedback = deleteData($sql_daten, $dummy_form, $this->pagedata->getSessionArray()["uid"], $this->pagedata);
        
        if($feedback >= 0) {
            //Wenn die Maske erfolgreich gelöscht wurde, dann auch die Maskenelemente löschen.
            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> delete htmlgroups', $my_htmltaggroup_ids);
            $this->deleteHtmltaggroups($my_htmltaggroup_ids);
        }
        

        return $feedback;
    }
    
    
    
    
    
    /** Gibt die ID der neu erstellten  Maske zurück.
     * 
     * @return  integer     ID der Maske
     */
    public function getMaskID() {
        return $this->id;
    }
    
    /** Gibt die APP-ID der neu erstellten  Maske zurück.
     * 
     * @return  integer     APP-ID der Maske
     */
    public function getMaskAppID() {
        return $this->app_id;
    }
    
    
    /** Gibt die ID der htmltaggroup, welche die Formulare aufnehmen soll, zurück.
     * 
     * @return  integer     ID der htmltaggroup
     */
    public function getHtmltaggroupIDForForms() {
        return $this->htmltaggroup_id_forForms;
    }
    
    
    
    /** Setzt das Zugriffsrecht für den Chefredakteur für die Maske
     * 
     * @param   object  $in_pagedata        Referenz zum pagedata-object
     * @param   string  $in_role_app_id     APP-ID der Rolle
     * @param   integer $in_role_id         ID der Rolle, für die der Zugriff eingeichtet werden soll
     * @param   integer $in_access_select   Berechtigung (1 = ja)
     * @param   integer $in_access_insert   Berechtigung (1 = ja)
     * @param   integer $in_access_update   Berechtigung (1 = ja)
     * @param   integer $in_access_delete   Berechtigung (1 = ja)
     * @return  boolean                     true, wenn das recht gesetzt werden konnte.
     */
    public function addAccessToMask(&$in_pagedata, $in_role_app_id, $in_role_id, $in_access_select, $in_access_insert, $in_access_update, $in_access_delete) {
        $feedback = false;

        
        $feedback = setRoleAccessToMask($in_pagedata, $in_role_app_id, $in_role_id, $this->app_id, $this->id, $in_access_select, $in_access_insert, $in_access_update, $in_access_delete);
        if($feedback !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Zugriffsrecht für Rolle ".$in_role_id." wurde gesetzt");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Zugriffsrecht für Rolle ".$in_role_id." konnte nicht gesetzt werden!", "ERROR");
        }
        
        return $feedback;
    }
    
    
    
    
    /** Ergänzt zu einer Maskenelementgruppe der Maske ein weiteres Maskenelement.
     * 
     * 
     * @param   object  $in_pagedata            Referenz zum pagedate-object
     * @param   int     $in_htmltaggroup_id     ID der htmltaggroup (Gruppe von Maskenelementen)
     * @param   int     $in_html_tag_id         ID des hinzuzufügenden html_tag (Maskenelement)
     * @param   string  $in_htmltaggroup_app_id APP-ID der htmltaggroup
     * @param   string  $in_html_tag_app_id     APP-ID des html_tags
     * @param   int     $in_relationtyp         [1 = eigenständiges Formular|2 = eingebettetes Formular]
     * @param   int     $in_sort                Reihenfolge der Maskenelemente innerhalb einer Maskenelement-Gruppe.
     * @param   int     $in_active              [1 = aktiviert|0 = deaktiviert]
     * @return  boolean 
     */
    public function addHtmlTagToHtmlTaggroup($in_htmltaggroup_id, $in_htmltaggroup_app_id, $in_html_tag_app_id, $in_html_tag_id, $in_relationtyp, $in_sort, $in_active) {
        $feedback = false;

        
        $feedback = setHtmlTagToHtmlTaggroup($this->pagedata, $in_htmltaggroup_id, $in_html_tag_id, $in_htmltaggroup_app_id, $in_html_tag_app_id, $in_relationtyp, $in_sort, $in_active);
        if($feedback !== false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Maskenelement ".$in_html_tag_id." wurde der Maskenelementgruppe ". $in_htmltaggroup_id." zugeordnet");
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__, "Maskenelement ".$in_html_tag_id." konnte der Maskenelementgruppe ". $in_htmltaggroup_id." nicht zugeordnet werden", "ERROR");
        }
        
        return $feedback;
    }
    
    
    
}
