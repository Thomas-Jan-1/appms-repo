<?php


/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */


/**
 * Diese Klasse verwaltet alle benötigten DB-Verbindungen und stellt Eigenschaften 
 * und Methoden deren Nutzung zur Verfügung.
 */

require_once("db_connector_interface.php"); 
require_once("../controller/crypt_class.php");


//globals
$db_schema_manager = global_variables::getNameOfDbSchemaSYS01();
$db_schema_manager_connection_id = global_variables::getConnectionIdOfDbSchemaSYS01();

class db_connection_handler {
    
    /** Enthält die gesamte Konfigurationsdatei als String
     *
     * @var type 
     */
    protected static $_config_file_content; 
    
    /** Liste der geöffneten Datenbankverbindungen
     * Beim Aufruf von select, update ... muss dann ein Merkmal zur Erkennung der richtigen Verbindung mitgegeben werden.
     *
     * @var     array   Liste der Connection-Objekte (key = Kennung; value = Connection) 
     */
    protected static $_dbConnectionList = array();
    
    
    /** Liste aller bereits getätigten Datenbankabfragen und derer Ergebnisse.
     * Kann als Cache genutzt werden, um die Zahl der Datenbankzugriffe zu reduzieren.
     *
     * @var     array   Liste aller DB-Abfragen (key = fortlaufende Zahl, value[sql] = SQL-Statement, value[result] = Ergebnismenge)
     */
    protected static $_dbSelectQueryResultListCache = array();
    
    
    /**
     *
     * @var     array           Zählt die Anzahl der DB-Zugriffe und wieviele davon aus dem Cache beantwortet wurden.
     *                          Bsp.: array(calls_sum => 10, answer_from_cache => 5)
     */
    public static $countUseCache = array("calls_sum" => 0, "answer_from_cache" => 0);
    
    
    
    /**
     * Baut eine Datenbankverbindung auf. Wenn die Verbindung zur benötigten Datenbank bereits besteht, wird diese zurückgegeben.
     * Die benötigte Konnektor-Datei (bspw. db_connector_postgres_class.php wird automatisch geladen.
     * 
     * @param   string  $in_id  ID zur Identifizierung einer Datenbankverbindung (ToDo: Zurzeit ist das die app_id. D.h. aber, dass pro App nur eine Connection existieren kann
     *                          Wenn es mehr als eine Connection pro App geben soll, muss ein anderes Konzept genutzt werden (Bsp.: Konnection werden in einer eigenständigen 
     *                          Tabelle gepflegt und Forms, sowie Referenzfeldrn zugeordnet)       
     */
    protected static function getConnectionH($in_id) {
        
//        echo "getConnection for: ".$in_id." - vorhandene Connections: ".print_r(self::$_dbConnectionList)."<br />";
        if (isset(self::$_dbConnectionList[$in_id])) {
            //vorhandene Connection zurückgeben
            return self::$_dbConnectionList[$in_id]->getConnection();  
                          
        } else {
            //Wenn noch keine Verbindung existiert
            self::readConfigFile($in_id);                                       //ToDo: passt nur solange pro app nur eine Connection benötigt wird, da in_id = app_id
            
            $config_file = new SimpleXMLElement(self::$_config_file_content);
                $dbms = $config_file->db_connect->dbms->__toString();
                $host = $config_file->db_connect->host->__toString();
                $port = $config_file->db_connect->port->__toString();
                $dbname = $config_file->db_connect->dbname->__toString();
                $user = $config_file->db_connect->user->__toString();
                $temp_password = $config_file->db_connect->{'password'}->__toString();
                $password = crypt_class::decryptString($temp_password, $in_id);
                
            //Wenn Passwort nach decrypt noch unverändert ist, dann liegt es im Config-File unverschlüsselt vor. In dem Fall wird es nun verschlüsselt in die Config-Datei geschrieben.
            if($temp_password == $password) {self::replaceStringInConfigFile($in_id, $temp_password, crypt_class::encryptString($temp_password,$in_id),"password");}
                
            if(isset($config_file->db_connect->encoding)) {
                $encoding = $config_file->db_connect->encoding->__toString();
            } else {
                $encoding = "";
            }  
            
            $myDbConnection = new db_connection($in_id, $dbms, $host, $port, $dbname, $user, $password, $encoding);
            self::$_dbConnectionList[$in_id]=$myDbConnection;     //object, welches die Connection enthält
            
            return self::$_dbConnectionList[$in_id]->getConnection();  
        }
  
  
    }
    
    
    /**
     * Schließt alle persistenten Connections
     */
    public static function closeAllConnections() {
        foreach (self::$_dbConnectionList as $key => $my_connection) {
            $my_connection->getConnection()->close_connection();
        }
    }
    
    
    
    
    /**
     * Liest die Konfigurationsdatei der APP-ID ein und legt den Inhalt in $this->_config_file_content ab.
     */
    protected static function readConfigFile($in_app_id) {
        $myDirSep = global_variables::getDirectorySeparator();
        $_configFile = "..".$myDirSep.global_variables::getPathAndFileForConfigxml_rel($in_app_id);
        
        $file_content = file_get_contents($_configFile);
        if($file_content === false) {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' Config-File konnte nicht gelesen werden', $_configFile, "ERROR");
            throw new Exception(-170);
            
        } else {
            self::$_config_file_content = file_get_contents($_configFile);
        }
    }
    
    
    
    /** Ersetzt einen String in der Config-Datei
     * 
     * @param   string  $in_app_id          APP-ID der Config-Datei
     * @param   string  $in_searchString    alter Value im tag
     * @param   string  $in_replaceString   neuer Value im tag
     * @param   string  $in_tagname         Name des tags, in dem der Searchstring erstezt werden soll.
     */
    protected static function replaceStringInConfigFile($in_app_id, $in_searchString, $in_replaceString, $in_tagname) {
        $myDirSep = global_variables::getDirectorySeparator();
        $_configFilepath = "..".$myDirSep.global_variables::getPathForConfigs_rel($in_app_id);
        $_configFile = global_variables::getNameOfConfigFile();
        
        replaceStringInFile($_configFilepath, $_configFile, false, "<".$in_tagname.">".$in_searchString."</".$in_tagname.">", "<".$in_tagname.">".$in_replaceString."</".$in_tagname.">", false);
            
    }
    
    
    
    
    
    
    
    
    //ToDo: vorerst mit SQL-Command arbeiten. Nach Refactoring von functions_db auf SQL-Object umstellen
    /** deprecated
    * 
    * @param    string      $in_connection_id       ID der Connection
    * @param    string      $in_sql_Command         SQL-Befehl, der ausgeführt werden soll. Der Befehl kann beliebig verschachtelt sein, darf aber nur ein Statement (Semikolon) enthalten. Weitere Semikolon werden aus Sicherheitsgründen entfernt.
    * @param    string      $in_callFromFunction    Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.
    * @param    bool        $in_use_cache           [optional] Gibt an, dass der Cache aller bisherigen Abfragen genutzt werden soll. D.h., wenn eine identische Abfrage innerhalb des aktuellen 
    *                                               Maskenaufbaus bereits an die Datenbank gesendet wurde, dann dessen Ergebnis genutzt. (default = true)
    * @param    bool        $in_log_error_msg       [optional] Wenn true, wird im Fehlerfall ein Array mit Fehlermeldung und abgesetzter query in der globalen sqlErrors abgelegt; 
    *                                               Bsp.: Array("trigger_function" => "getResultForSql", "query" => "Select ...", "errorMessage" => "Error on Line ...")
    * @return  mixed                                Auf das Ergebnis einer bestimmten Spalte in der ersten Zeile kann wie folgt zugegriffen werden: $result[0][Tablename.".".Columnname]
    *                                               BEACHTE: Im Ergebnisarray erscheinen keine Aliasnamen für Tabellen, wohl aber die Aliasnamen für Spalten!
    *                                               Wenn die DB-Abfrage einen Fehler verursacht hat, dann wird "false" zurückgegeben
    *                                      
    */
    public static function selectOnDatabase_old($in_connection_id, $in_sql_Command, $in_callFromFunction, $in_use_cache = true, $in_log_error_msg = false){
        $myConnection = self::getConnectionH($in_connection_id);                                  //Datenbank-connector-Objekt
        //Platzhalter für DB-unabhängige Funktionen, die noch im SQL-Kommando enthalten sein könnten, in die DB-spezifische Syntax der aktuellen Connection umwandeln
        $in_sql_Command = self::replaceFunctionplacehodlersInSql($myConnection, $in_sql_Command);
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Platzhalter ersetzt ", $in_sql_Command, "INFO");
        
        
        
        if($in_use_cache == true) {
            $old_result = self::getResultForSameSelectSql($in_sql_Command);
        } else {
            $old_result = false;
        }
        if($old_result == false) {
            //Wenn der Select-Befehl erstmals übergeben wird, wird eine entsprechende DB-Abfrage ausgeführt
            $feedback = $myConnection->executeSelect($in_sql_Command, $in_callFromFunction, true);
            
            //wenn gewünscht, wird im Fehlerfall die Fehlermeldung zurück gegeben
            $errorMsg = occurredSqlError($in_sql_Command);
            if($errorMsg != false AND $in_log_error_msg == true) {
                $feedback = $errorMsg;
            }
            
            //Ergebnis im Cache ablegen
            $currentSqlResult["result"]=$feedback;
            self::$_dbSelectQueryResultListCache[$in_sql_Command] = $feedback;
        } else {
            //Wenn der Select-Befehl bereits zuvor ausgeführt wurde, wird das alte Ergebnis zurückgegeben
            $feedback = $old_result;
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> found old result! ", $in_sql_Command, "INFO");
        }
        
        return $feedback;
    }
    
    
    
    
    
    /** Führt einen Select-Befehl in der Datenbank aus.
     * 
     * @param   object $in_sql_Request      Objekt vom Typ "sql_request"
     * @param   string $in_callFromFunction Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.
     * @param   bool   $in_print_to_debug   [optional] Gibt an, ob der Select-Befehl in der Debug-Tabelle ausgegeben werden soll. (default = false)
     * @param   bool   $in_use_cache        [optional] Gibt an, dass der Cache aller bisherigen Abfragen genutzt werden soll. D.h., wenn eine identische Abfrage innerhalb des aktuellen 
     *                                      Maskenaufbaus bereits an die Datenbank gesendet wurde, dann dessen Ergebnis genutzt. (default = true)
     * @param    bool        $in_log_error_msg       [optional] Wenn true, wird im Fehlerfall ein Array mit Fehlermeldung und abgesetzter query in der globalen sqlErrors abgelegt; 
     *                                               Bsp.: Array("trigger_function" => "getResultForSql", "query" => "Select ...", "errorMessage" => "Error on Line ...")
    * @return  mixed                                Auf das Ergebnis einer bestimmten Spalte in der ersten Zeile kann wie folgt zugegriffen werden: $result[0][Tablename.".".Columnname]
    *                                               BEACHTE: Im Ergebnisarray erscheinen keine Aliasnamen für Tabellen, wohl aber die Aliasnamen für Spalten!
    *                                               Wenn die DB-Abfrage einen Fehler verursacht hat, dann wird "false" zurückgegeben
    *                                      
    */
    public static function selectOnDatabase(&$in_sql_Request, $in_callFromFunction, $in_print_to_debug = false, $in_use_cache = true, $in_log_error_msg = false){
        $connection_id = $in_sql_Request->connection_id;                 
        $myConnection = self::getConnectionH($connection_id);                    //Datenbank-connector-Objekt
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "start SelectOnDatabase");
        
        $sql_Command = $in_sql_Request->getSelectCommand();
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "nach getSelectCommand");
        
        
        //Platzhalter für DB-unabhängige Funktionen, die noch im SQL-Kommando enthalten sein könnten, in die DB-spezifische Syntax der aktuellen Connection umwandeln
        if($in_sql_Request->include_function_placeholder == true) {
//            Achtung: folgender Befehl kann zu einem Speicherüberlauf führen, wenn er bei jedem Select ausgeführt werden würde.
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SQL-Command vor replaceFunctionplacehodlersInSql ', $sql_Command);
            $sql_Command = self::replaceFunctionplacehodlersInSql($myConnection, $sql_Command, $in_sql_Request);
            
            //Prüfen, ob es innerhalb der Funktionen referenzen auf andere Spalten gibt (Mehrfachverschachtelung von Funktionen.)
            $columnReferences = getPlaceholderInStringAsArray($sql_Command, "<column>", "</column>");
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SQL-Command nach ReplaceFunktionPlaceholder ', $sql_Command);

            if($columnReferences != array()) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Weitere Spaltenrefernzen entdeckt ', $columnReferences);
                $sql_Command = $in_sql_Request->replaceColumnReferencesInSqlcommand($columnReferences, $sql_Command);
            }
            
            //Sql-Befehl an $in_sql_Request zurückgeben, damit er dem User als Feedback ausgegeben werden kann
            $in_sql_Request->setSqlCommand($sql_Command);
        }
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  SQL-Command nach ReplaceColumnRefernz ', $sql_Command);
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Columnlist nach ReplaceFunktionPlaceholder ', $in_sql_Request->getColumnlist());
        
        
        if($in_use_cache == true) {
            $old_result = self::getResultForSameSelectSql($sql_Command);
        } else {
            $old_result = false;
        }
        if($old_result == false) {
            //Wenn der Select-Befehl erstmals übergeben wird, wird eine entsprechende DB-Abfrage ausgeführt
            $feedback = $myConnection->executeSelect($sql_Command, $in_callFromFunction, $in_print_to_debug);
            
            //wenn gewünscht, wird im Fehlerfall die Fehlermeldung zurück gegeben
            $errorMsg = occurredSqlError($sql_Command);
            if($errorMsg != false AND $in_log_error_msg == true) {
                $feedback = $errorMsg;
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> errorMsg', 'errorMsg ist vorhanden');
            }
            //Ergebnis im Cache ablegen
            $currentSqlResult["result"]=$feedback;
            self::$_dbSelectQueryResultListCache[$sql_Command] = $feedback;
        } else {
            //Wenn der Select-Befehl bereits zuvor ausgeführt wurde, wird das alte Ergebnis zurückgegeben
            $feedback = $old_result;
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> found old result! ", $in_sql_Command, "INFO");
        }
        
        return $feedback;
    }
    
    
    
    /** Prüft, ob der identische SQL-Befehl schon einmal auf die DB abgesetzt wurde. Wenn ja, wird das alte Ergebnis zurück gegeben.
     * Falls nein, wird false zurück gegeben.
     * 
     * @param   string  $in_Sql_Command     SQL-Befehl
     * @return  mixed                       Ergebnismenge (zweidimensionales Array, wie es executeSelect zurückgibt) oder false
     */
    protected static function getResultForSameSelectSql(&$in_Sql_Command) {
            if(isset(self::$_dbSelectQueryResultListCache[$in_Sql_Command])) {
                self::addCountToCacheCounter(true);
                return self::$_dbSelectQueryResultListCache[$in_Sql_Command];
            }     
        self::addCountToCacheCounter(false);
        return false;
    }
    
    
    /** Zählt in self::$countUseCache die Anzahl der DB-Zugriffe und wieviele davon aus dem Cahce beantwortet werden.
     * 
     * @param type $in_use_cache
     */
    protected static function addCountToCacheCounter($in_use_cache) {
        self::$countUseCache["calls_sum"] = self::$countUseCache["calls_sum"] + 1;
        if($in_use_cache === true) {
            self::$countUseCache["answer_from_cache"] = self::$countUseCache["answer_from_cache"] +1;
        }
    }
    
    
    /** Sendet einen Delete-Befehl an eine Datenbank. Dazu muss ein Array mit den Werten schema, table, into und values  übergeben werden.
    * 
    * @param    string  $in_connection_id       ID der Connection, welche genutzt werden soll.
    * @param    Array   $in_SqlDaten            Array mit dem Strukturellen Aufbau, wie es die Funktion extractDataFromPostarray erzeugt.
    * @param    string  $in_callFromFunction    Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
    * @param    boolean $in_check_permissionForMask [default = true] Wenn false, wird die Zugriffsberechtigung für die Maske nicht geprüft. Dies ist notwendig für Deletes, die nicht über eine Maske laufen, bspw. Session löschen.
    * @param    object  $in_pagadata            [default = NULL] Referenz zum pagedata-object; Darf nur, wenn $in_check_permissionForMask = false, NULL sein
    * @return   integer                         siehe Konstantentyp_id = 35; alle Feedbackmeldungen des 3er-Bereichs 
    *                                           3   => erfolgreich gelöscht
     *                                          -3  => nicht gelöscht (SQL-Fehler)
     *                                          -31 => Zugriffsrecht für aktive Rolle und aktuelle Maske nicht gegeben.
     *                                          ...     
    */
    public static function deleteOnDatabase($in_connection_id, $in_SqlDaten, $in_callFromFunction, $in_check_permissionForMask, &$in_pagadata = NULL){
        
        if($in_check_permissionForMask == true) {
            $permission = self::checkPermissionForMask($in_pagadata, "delete");
        } else {
            $permission = true;
        }
        
        if($permission == true) {
            $myConnection = self::getConnectionH($in_connection_id);

            //Platzhalter für DB-unabhängige Funktionen, die noch im SQL-Kommando enthalten sein könnten, in die DB-spezifische Syntax der aktuellen Connection umwandeln
            $in_SqlDaten["where"] = self::replaceFunctionplacehodlersInSql($myConnection, $in_SqlDaten["where"]);


            if($in_SqlDaten["where"] == "") {
                //Wenn keine Where-Bedingung vorhanden ist, kann der Zieldatensatz nicht eingeschränkt werden.
                //Vermutlich besitzt die Tabelle keinen Primary-Key
                $feedback = -14;
            } elseif($myConnection->executeDelete($in_SqlDaten, $in_callFromFunction,$in_pagadata) == true) {
                //Daten wurden erfolgreich gelöscht
                $feedback = 3;
            } else {
                //Daten konnten nicht gelöscht werden
                $feedback = -3;
            }
            self::addCountToCacheCounter(false);
        } else {
            //Zugriff auf dieser Maske ist für die aktive Rolle für die Aktion delete nicht gestattet
            $feedback = -31;
        }
        return $feedback;
    }
    
    
    /** Ersetzt Platzhalter für DB-unabhängige Funktionen, die noch im SQL-Kommando enthalten sein könnten, 
     * in die DB-spezifische Syntax der aktuellen Connection. <br />
     * <br />
     * Bsp.: Der Platzhalter <br />
     * "{{{{function_name=interval?interval_value=300&interval_type=SECOND}}}}" <br />
     * wird für eine postgres-DB durch <br />
     * "interval '300 SECOND'" <br />
     * ersetzt. Für eine MySql-DB wird er durch <br />
     * "interval 300 SECOND" <br />
     * ersetzt. <br />
     * Das Ergebnis wird mit urldecode bearbeitet.
     * 
     * @param   resource        $in_connection      DB-Verbindung     
     * @param   string          $in_sql             SQL-Befehl oder ein Teil davon, mit oder ohne Funktionsplatzhalter 
     * @return  string                              SQL-Befehl ohne Funktionsplatzhalter
     */
    public static function replaceFunctionplacehodlersInSql($in_connection, $in_sql, $in_sql_request = NULL) {
        if($in_sql <> "") {                                                     //Achtung: If-Bedingung ist wichtig, da sonst Endlosschleife entsteht!
            //0. PHP-Platzhalter ersetzen
            $in_sql = db_connection_handler::replacePhpFunctionPlaceholder($in_sql);


            //1. Funktionsplatzhalter aus $in_sql  extrahieren
            //Beispiel-Syntax eines Funktionsplatzhalters: {{{{function_name=interval?interval_value=300&interval_type=SECOND}}}}
            
            $app_id_from_kernel = global_variables::getAppIdFromSYS01();
            
            
            $sql_functionplaceholder_start_tag = getConfig("sql_start_tag_function_placeholder", $app_id_from_kernel);
            $sql_functionplaceholder_end_tag = getConfig("sql_end_tag_function_placeholder", $app_id_from_kernel);
            $function_placeholder = getPlaceholderInStringAsArray($in_sql, $sql_functionplaceholder_start_tag, $sql_functionplaceholder_end_tag);
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> gefundene Platzhalter! ", $function_placeholder, "INFO");



            //2. Funktionsplatzhalter nacheinander durch DB-spezifische Syntax ersetzen
            //Bsp.: Array
            //    (
            //         [0] => function_name=interval?interval_value=300&interval_type=SECOND
            //    )

            foreach ($function_placeholder as $current_function_placeholder) {
                $function_params = array();                                     //Löschen für den zweiten Durchlauf
                $function_parts = explode("?", $current_function_placeholder);       
                $function_name = explode("=", $function_parts[0])[1];
                $function_param_pairs = explode("&", $function_parts[1]);            //$function_parts[0] => function_name=interval; $function_parts[1] => interval_value=300&interval_type=SECOND
                foreach ($function_param_pairs as $current_param_pair) {
                    $current_param = explode("=", $current_param_pair);
                    if(isset($current_param[2])) {
                        //Wenn ein dritter param_part existiert, dann waren in dem aktuellen Param-Pair zwei Gleichheitszeichen enthalten. Das kann insbesondere bei der Funktion
                        //CountIf passieren (Bsp.: condition=bew.active=1. In dem Fall wird der dritte Teil wieder zum zweiten ergänzt und das Gleichheitszeichen als Verbinder genutzt.
                        $function_params[$current_param[0]] = $current_param[1]."=".$current_param[2];
                    } else {
                        $function_params[$current_param[0]] = $current_param[1];
                    }
                    
                }
                $function_in_sql_syntax = $in_connection->parseFunctions($function_name, $function_params);
                $placeholder = $sql_functionplaceholder_start_tag.$current_function_placeholder.$sql_functionplaceholder_end_tag;
                $in_sql = str_replace($placeholder, $function_in_sql_syntax, $in_sql);
                
                //Wenn SQL-Request übergeben wurde, dann wird in der dortigen Columnlist ebenfalls der functionplaceholder durch den SQL-Ausdruck ersetzt.
                if($in_sql_request !== NULL) {
                    $in_sql_request->replaceFunctionPlaceholderInColumnlist($placeholder, $function_in_sql_syntax);
                }
            }
        }
        
        //url-dekodierte Zeichen umwandeln
            //Verwendung: 
            //In function_params in Queries (bspw. zur Erzeugung einer URL mit Parametern) und
            //in Folge des SQL-like-Oparators bei einer automatisch generierten Suche
                //$in_sql = rawurldecode($in_sql);          //->damit wird zuviel decodiert. Bspw. Platzhater in like-Suchen ('%0260%')
        
            $in_sql = str_replace("%3F", "?", $in_sql);
            $in_sql = str_replace("%3D", "=", $in_sql);
            $in_sql = str_replace("%26", "&", $in_sql);
        
        
        return $in_sql;
    }
    
    
    
    /** Ersetzt Platzhalter für PHP-Funktionen, durch die entsprechenden Werte.
     * 
     * @param  string   $in_sql     SQL-Befehl mit Platzhalter (Bsp.: '$$SERVER(HTTP_REFERER)$$')
     * @return string
     */
    public static function replacePhpFunctionPlaceholder($in_sql) {
        $new_sql = $in_sql;
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> in_sql ", $in_sql, "INFO");
        
        if(strpos($new_sql, "__SERVER(HTTP_REFERER)__") !== false) {
            //liefert die gesamte aktuelle URL. Bsp.: 'http://localhost/appms/view/page.php?mask=132&maskapp=SYS01&form_id=125'
            $root = $_SERVER['HTTP_REFERER'];
            //?, =  und & müssen maskiert werden, da sie als Steuerzeichen, bei der späteren Dekodierung von DB-unabhängigen Funktionen dienen.
            $root = str_replace("?",'%3F',$root);
            $root = str_replace("&",'%26',$root);
            $root = str_replace("=",'%3D',$root);
            $new_sql = str_replace("__SERVER(HTTP_REFERER)__", $root, $new_sql);
        }
        
        if(strpos($new_sql, "__SERVER(HTTP_ROOT)__") !== false) {
            //liefert die aktuelle URL ohne Parameter. Bsp.: 'http://localhost/appms/view/page.php'
            $root = $_SERVER['HTTP_REFERER'];
            $root_array = explode("?", $root);
            $new_sql = str_replace("__SERVER(HTTP_ROOT)__", $root_array[0], $new_sql);
        }
        
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> new_sql ", $new_sql, "INFO");
        return $new_sql;
    }
    
    
    
    /** Sendet einen Update-Befehl an eine Datenbank. Dazu muss ein Array mit den Werten schema, table, update und where  übergeben werden.
    * 
    * @param    string  $in_connection_id           ID der Connection, welche genutzt werden soll. 
    * @param    Array   $in_SqlDaten                Array mit dem Strukturellen Aufbau, wie es die Funktion extractDataFromPostarray erzeugt.
    * @param    string  $in_callFromFunction        Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
    * @param    boolean $in_check_permissionForMask [default = true] Wenn false, wird die Zugriffsberechtigung für die Maske nicht geprüft. Dies ist notwendig für Updates, die nicht über eine Maske laufen, bspw. Session-Verwaltung.
    * @param    object  $in_pagadata                [default = NULL] Referenz zum pagedata-object; Darf nur, wenn $in_check_permissionForMask = false, NULL sein
    * @return   integer                             Rückmelde-ID's entsprechend der Konstantentyp_id 35 [1|-1|-12] 
    */
    public static function updateOnDatabase($in_connection_id, $in_SqlDaten, $in_callFromFunction, $in_check_permissionForMask = true, &$in_pagadata = NULL){
        if($in_check_permissionForMask == true) {
            $permission = self::checkPermissionForMask($in_pagadata, "update");
        } else {
            $permission = true;
        }
        
        
        if($permission == true) {
            
            If(!isset($in_SqlDaten["fields_without_column"])) {$in_SqlDaten["fields_without_column"] = "";}         //andernfalls kommt es im Folgenden zu einer unnötigen Warnung.
        
            if($in_SqlDaten["fields_without_column"] == "") {
                //Speichern auf Maske für aktuelle Rolle zulässig
                $myConnection = self::getConnectionH($in_connection_id);
                //Platzhalter für DB-unabhängige Funktionen, die noch im SQL-Kommando enthalten sein könnten, in die DB-spezifische Syntax der aktuellen Connection umwandeln
                $in_SqlDaten["where"] = self::replaceFunctionplacehodlersInSql($myConnection, $in_SqlDaten["where"]);
                if($in_SqlDaten["where"] == "") {
                    //Wenn keine Where-Bedingung vorhanden ist, kann der Zieldatensatz nicht eingeschränkt werden.
                    //Vermutlich besitzt die Tabelle keinen Primary-Key
                    $feedback = -14;
                } elseif($myConnection->executeUpdate($in_SqlDaten, $in_callFromFunction) == true) {
                    $feedback = 1;
                } else {
                    $feedback = -1;
                }
                self::addCountToCacheCounter(false);
            } else {
                //mindestens ein Feld wurde ohne Angabe einer DB-Spalte konfiguriert.
                $feedback = -24;
            }
        } else {
            //Speichern nicht erlaubt
            $feedback = -12;
        }
        return $feedback;
    }
    
    
    
    
    /** Prüft, ob die Aktion (delete, update, insert) auf der aktuellen Maske für die aktuelle Rolle
     * zulässig ist.
     * 
     * @param   object  $in_pagedata        Referenz auf das pagedata-object
     * @param   string  $in_access_type     Art des Zugriffes [delete|insert|update]
     * @return  boolean
     */
    protected static function checkPermissionForMask(&$in_pagedata, $in_access_type) {
        $feedback = false;
        
        //Prüfen, ob Zugriffsbeschränkungen für die aktuelle Maske und Rolle hinterlegt wurden.
        $mask_app_id = $in_pagedata->getMaskProbertyAppid();
        $mask_id = $in_pagedata->getMaskProbertyID();
        
        $permissions = getAccessToMaskByActiveRole($mask_app_id, $mask_id);
        
        if($permissions == array()) {
            //theoretisch muss ein Manipulationsversuch vorliegen, da der Nutzer diese Maske gar nicht erst hätte aufruffen dürfen.
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> Aufruf einer unerlaubten Maske mit Aktion (".$in_access_type.")", "Manipulationsverdacht! Der aktive User hat keinen Zugriff auf die Maske (".$mask_app_id.", ".$mask_id.").", "ERROR");
        } else {
            //Ergebnismenge kann nur einen Datensatz haben.
            if      ($in_access_type == "delete") {if($permissions[0]["role_has_mask.access_delete"] == 1) {$feedback = true;} else {$feedback = false;}}
            elseif  ($in_access_type == "update") {if($permissions[0]["role_has_mask.access_update"] == 1) {$feedback = true;} else {$feedback = false;}}
            elseif  ($in_access_type == "insert") {if($permissions[0]["role_has_mask.access_insert"] == 1) {$feedback = true;} else {$feedback = false;}}    
        }
        
        return $feedback;
        
        
    }
    
    
    
    /** Sendet einen Insert-Befehl an eine Datenbank. Dazu muss ein Array mit den Werten schema, table, into und values  übergeben werden.
    * 
    * @param    string  $in_connection_id           ID der Connection, welche genutzt werden soll. 
    * @param    Array   $in_SqlDaten                Array mit dem Strukturellen Aufbau, wie es die Funktion extractDataFromPostarray erzeugt.
    * @param    string  $in_callFromFunction        Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
    * @param    boolean $in_check_permissionForMask [default = true] Wenn false, wird die Zugriffsberechtigung für die Maske nicht geprüft. Dies ist notwendig für Inserts, die nicht über eine Maske laufen, bspw. Debug-Meldungen.
    * @param    object  $in_pagadata                [default = NULL] Referenz zum pagedata-object; Darf nur, wenn $in_check_permissionForMask = false, NULL sein
    * @return   integer                             Rückmelde-ID's entsprechend der Konstantentyp_id 35 [2|-2|-21|-24] 
    */
    public static function insertOnDatabase($in_connection_id, $in_SqlDaten, $in_callFromFunction, $in_check_permissionForMask = true, &$in_pagadata = NULL){
        if($in_check_permissionForMask == true) {
            $permission = self::checkPermissionForMask($in_pagadata, "insert");
        } else {
            $permission = true;
        }
        
        If(!isset($in_SqlDaten["fields_without_column"])) {$in_SqlDaten["fields_without_column"] = "";}         //andernfalls kommt es im Folgenden zu einer unnötigen Warnung.
        
        
        if($permission == true) {
            if($in_SqlDaten["fields_without_column"] == "") {
                if($in_pagadata != NULL) {
                    //Prüfen, ob ein Systemdatensatz angelegt werden soll (sys=1)
                    if($in_pagadata->isSysData($in_SqlDaten) == true) {
                        //Zum Datensatzcontent wird sys=1 ergänzt.
                        $in_SqlDaten["into"] = $in_SqlDaten["into"].", sys";
                        $in_SqlDaten["values"] = $in_SqlDaten["values"].", 1";
                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Datensatz für InsertData: ', $in_SqlDaten);
                    }

                }
                $myConnection = self::getConnectionH($in_connection_id);
                //Platzhalter für DB-unabhängige Funktionen, die noch im SQL-Kommando enthalten sein könnten, in die DB-spezifische Syntax der aktuellen Connection umwandeln
                if(isset($in_SqlDaten["where"])){
                    $in_SqlDaten["where"] = self::replaceFunctionplacehodlersInSql($myConnection, $in_SqlDaten["where"]);
                }


                if($myConnection->executeInsert($in_SqlDaten, $in_callFromFunction) == true) {
                    $feedback = 2;
                } else {
                    $feedback = -2;
                }
                self::addCountToCacheCounter(false);
            } else {
                //mindestens ein Feld wurde ohne Angabe einer DB-Spalte konfiguriert.
                $feedback = -24;
            }
        } else {
            //Zugriff verweigert
            $feedback = -21;
        }
        return $feedback;
    }
    
    
    
    
    /** ACHTUNG: Diese Funktion darf nur ausnahmsweise, bspw. während des Update-Prozesses,
     *           genutzt werden. Durch die Ausführung eines Skriptes werden diverse
     *           Sicherheitsmechanismen umgangen. Es muss sichergestellt werden, dass
     *           nur vertrauenswürdige Scripte ausgeführt werden.
     * 
     * HINWEIS:  Platzhalter für DB-unabhängige Funktionen werden zurzeit nicht ersetzt.
     *           Der Programmcode ist jedoch entsprechend vorbereitet, aber auskommentiert -> ggf. Testen.
    * 
    * @param    string  $in_connection_id           ID der Connection, welche genutzt werden soll. 
    * @param    string  $in_Script                  SQL-Script, welches ausgeführt werden soll (Liste von SQL-Befehlen)
    * @param    string  $in_callFromFunction        Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
    * @param    boolean $in_check_permissionForMask [default = true] Wenn false, wird die Zugriffsberechtigung für die Maske nicht geprüft. Dies ist notwendig für Inserts, die nicht über eine Maske laufen, bspw. Debug-Meldungen.
    * @param    object  $in_pagadata                [default = NULL] Referenz zum pagedata-object; Darf nur, wenn $in_check_permissionForMask = false, NULL sein
    * @return   integer                             Rückmelde-ID's entsprechend der Konstantentyp_id 35 [901|-901|-21] 
    */
    public static function executeScriptOnDatabase($in_connection_id, $in_Script, $in_callFromFunction, $in_check_permissionForMask = true, &$in_pagadata = NULL){
        if($in_check_permissionForMask == true) {
            $permission = self::checkPermissionForMask($in_pagadata, "update");
        } else {
            $permission = true;
        }
        
        if($permission == true) {
            $myConnection = self::getConnectionH($in_connection_id);
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Connection-File für '.$in_connection_id,self::$_config_file_content);
            //Platzhalter für DB-unabhängige Funktionen, die noch im SQL-Kommando enthalten sein könnten, in die DB-spezifische Syntax der aktuellen Connection umwandeln
//            if(isset($in_SqlDaten["where"])){
//                $in_SqlDaten["where"] = self::replaceFunctionplacehodlersInSql($myConnection, $in_SqlDaten["where"]);
//            }

            
            if($myConnection->executeScript($in_Script, $in_callFromFunction) == true) {
                $feedback = 901;
            } else {
                $feedback = -901;
            }
        } else {
            //Zugriff verweigert
            $feedback -21;
        }
        return $feedback;
    }
    
    
    
    
    /** Entfernt unerlaubte Zeichen bzw. maskiert diese. Die Maskierung erfolgt abhängig vom Datenbankmanagementsystem
     * 
     * @param   string  $in_connection_id           ID der Connection, welche genutzt werden soll. 
     * @param   various $in_value                   Ein string oder array Wert, aus dem unerlaubte Zeichen entfernt werden sollen.
     * @param   string  $in_callFromFunction        Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
     * @param   boolean $in_deleteForbiddenWords    Gibt an, ob verbotene Wörter, wie bspw. onchange, gelöscht werden sollen.
     * @param   boolean $in_allow_semicolon         Gibt an, ob auch das Semikolon entfernt werden soll. Wichtig beim Speichern in DB's, teilweise aber hinderlich für das Erzeugen von HTML-Dokumenten; Default = false
     * @return  mixed                               string oder value, abhängig vonm Eingabewert
     */
    public static function parseSqlValue($in_connection_id, $in_value, $in_callFromFunction, $in_deleteForbiddenWords, $in_allow_semicolon = false) {
        //DB-spezifische Änderungen ausführen
        $myConnection = self::getConnectionH($in_connection_id);          
        $value = $myConnection->getParseSqlValues($in_value, $myConnection);
        
        
        
        
        //DB-unspezifische Änderungen ausführen
        if($in_deleteForbiddenWords == true) {
            if($in_allow_semicolon === true) {$added_forbidden_words = array();} else {$added_forbidden_words = array(";");}
            $forbidden_values1 = array("<script>", "</script>", "<input>", "</input>", "href=\"javascript", "onclick", "onchange", "onsubmit", "onblur", "onload", "onunload", "onmouseover", "onmouseout", "onmousedown", "onmouseup", "onfocus", "addEventListener", "removeEventListener", "jquery", "$(", ".on(");
            $forbidden_values = array_merge($forbidden_values1, $added_forbidden_words);
    
            //1. Durchlauf
            $temp_feedback = str_ireplace($forbidden_values, "", $value);
            //2. Durchlauf: Wenn nun erneut eine Änderung vorliegt, dann lag ein bewußter Manipulationsversuch vor (Verschachtelung von verbotenen Begriffen).
            $feedback = str_ireplace($forbidden_values, "", $temp_feedback);
        } else {
            $feedback = $value;
            $temp_feedback = $feedback;
        }
        
        
        
        
        
        /*
         * Folgende verbotene Zeichen bei Insert und update müssen und können nicht separat verhindert werden, da prpared Statements verwendet werden.
                ' (String)_
                • % (Wildcard)
                • _ (Wildcard)
                • [ (Escape-Zeichen in MS SQL)
                • ) (Verknüpfung)
                • ( (Verknüpfung)
                • @ (Funktion oder Variable, min. in MS SQL)
                • ; (Kommandokonkatenation)
                • + (Textkonkatenation)
                • = (Vergleich)
                • < (Vergleich)
                • > (Vergleich)
                • # (Kommentar)
                • -- (Kommentar)
                • /* (Kommentar)
                • \0
                • \r
                • \n
                • \t
                • \h
                • …
         * 
         */
        
        
        
        
        if($in_callFromFunction != "insertDebugData") {
            //addToDebug darf nicht verwendet werden, wenn die auslösende Funktion insertDebugData ist. Andernfalls kommt es zu einer Endlosschleife.
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> String vor Änderung', $feedback, "INFO");
            
            if ($temp_feedback != $feedback) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> attack detected', "Die Daten des Clients enthalten verschachtelte verbotene Strings.", "SECURITY");
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> attack detected: blocked SQL-Command', $in_value, "SECURITY");
                $feedback = "";         //-> ungültige SQL-Syntax zurückgeben
            }
        }
        
        
        
        return $feedback;
    }
    
    
    
    
    /** Entfernt schädlichen Code im SQL-Befehl, bspw. ein Semikolon. Diese Funktion wird üblicherweise nur einmal auf den gesamten SQL-Befehl angewendet.
     * (Anders als parseSqlValue).
     * Beachte auch parseSqlValue
    * 
    * @param    String  $in_value               Ein SQL-Befehl, der auf mögliche Sicherheitsrisiken geprüft wird
    * @param    string  $in_callFromFunction    Name der Funktion, die den SQL-Befehl übergibt. Der Name wird im Falle eines Fehlers im Debug-Protokoll mit ausgegeben. I.d.R. sollte die Konstante __FUNCTION__ genutzt werden.  
    * @return String 
    */
    public static function makeSecureSqlGlobalrules($in_value, $in_callFromFunction) {
        
        $feedback = str_replace(';','',$in_value);                             //entfernt Semikolon, sodass durch ein Formularfeld keine zusätzlichen SQL-Befehle untergeschoben werden können.
        
        if($in_callFromFunction != "insertDebugData") {
            //addToDebug darf nicht verwendet werden, wenn die auslösende Funktion insertDebugData ist. Andernfalls kommt es zu einer Endlosschleife.
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> String vor Änderung', $feedback, "INFO");
            
            
            //Falls in einem WYSIWIG-Feld ein Bild enthalten ist, muss das Semikolon wieder gesetzt werden.
            $feedback = str_replace('data:image/png','data:image/png;',$feedback); 
            $feedback = str_replace('data:image/jpeg','data:image/jpeg;',$feedback); 
            $feedback = str_replace('data:image/gif','data:image/gif;',$feedback); 

            //Falls in einem WYSIWIG-Feld ein Link gesetzt werden sollte muss das URL-encodede &-Zeichen wieder gesetzt werden.
            //& wurde durch &amp; ersetzt. Das Semikolon wurde etwas weiter oben aber bereits entfernt.
            $feedback = str_replace('&amp','&',$feedback); 
        }

        
        return $feedback;
    }
    
}




class db_connection {
    
    /**
     *
     * @var     string      Kennung, aus Sicht von appms. 
     */
    public $_id;
    
    /**
     *
     * @var     string      Datenbankmanagementsystem (postgresql|mysql|oracle|mssql|...) 
     */
    public $_dbms;
    
    /**
     *
     * @var     resource    Datenbankverbindung  
     */
    protected $_connection;
    
    
    
    /** Erstellt eine DB-Verbindung und legt diese als Resource in $this-> _connection ab.
     * Anhand des Parameters $in_dbms wird entschieden welcher DB-Konnektor geladen werden muss.
     * 
     * @param   string    $in_id            Kennung aus Sicht von appms
     * @param   string    $in_dbms          Datenbankmanagementsystem (postgresql|mysql|...)
     * @param   string    $in_host          IP-Adresse oder hostname
     * @param   string    $in_port          Portnummer, über den mit dem DBMS kommuniziert werden kann
     * @param   string    $in_db_name       name der Datenbank im DBMS
     * @param   string    $in_user          User, der im DBMS auf die Datenbank lesend und schreibend zugreifen darf.
     * @param   string    $in_password      DBMS-Passwort des Users
     * @param   string    $in_encoding      Kodierung bei postgresql. Default ist UTF8/UNICODE. Wenn dieser Wert DBMS-unabhängig gewählt werden soll, dann an dieser Stelle inen Leerstring übergeben.
     *                                      Ansonsten, mögliche Werte: SQL_ASCII, EUC_JP, EUC_CN, EUC_KR, EUC_TW, UNICODE, MULE_INTERNAL, LATINX (X=1...9), KOI8, WIN, ALT, SJIS, BIG5 or WIN1250. 
     */
    public function __construct($in_id, $in_dbms, $in_host, $in_port, $in_db_name, $in_user, $in_password, $in_encoding = "") {
        //Todo: Testen, ob es zu einer Art Überladung kommt, wenn postgres und mysql-Datei mit gleichen Funktionsnamen auf einer Maske genutzt werden.
        $db_connector_class_file = "../controller/model/db_connector_".$in_dbms."_class.php";
        
        $this->_id = $in_id;
        $this->_dbms = $in_dbms;
        
        
        if(file_exists($db_connector_class_file) == true) {
            require_once($db_connector_class_file);
            $db_connector_class = $this->_dbms."\\db_connector";
            
            //Aufruf einer Connector-Klasse in einem DB-spezifischen namespace
            $myConnection = new $db_connector_class($in_host, $in_port, $in_db_name, $in_user, $in_password, $in_encoding);           
            $this->_connection = $myConnection;


            if($this->_connection->getDbConnection() == false) {
                echo "Datenbankzugriff nicht möglich. Prüfen Sie die config.xml für die App: ".$in_id;
                
                //echo __FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> DB-Connection gescheitert: '."host: ".$in_host.", port: ".$in_port.", DB: ".$in_db_name.", DBMS: ".$this->_dbms.", user: ".$in_user;

                //Abbruch aller weiteren Aktivitäten
                exit();
            }
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> db_connector_class_file konnte nicht gefunden werden! ", $db_connector_class_file, "ERROR");
        }
        
 
        
    }
    
    
    /**
     * 
     * @return  resource        Datenbankverbindung
     */
    public function getConnection() {
        return $this->_connection;
    }
    
    
    

    
    
    /** Die Funktion prüft, ob eine Verbindung zu einer Datenbank möglich ist.
     * 
     * @param   string      $in_dbms
     * @param   string      $in_host
     * @param   string      $in_port
     * @param   string      $in_db_name
     * @param   string      $in_user
     * @param   string      $in_password
     * @param   string      $in_encoding    Kodierung bei postgresql. Default ist UTF8/UNICODE. Wenn dieser Wert DBMS-unabhängig gewählt werden soll, dann an dieser Stelle inen Leerstring übergeben.
     *                                      Ansonsten, mögliche Werte: SQL_ASCII, EUC_JP, EUC_CN, EUC_KR, EUC_TW, UNICODE, MULE_INTERNAL, LATINX (X=1...9), KOI8, WIN, ALT, SJIS, BIG5 or WIN1250. 
     * @return  array                       Zweidimensionales Array: array("status" => $status, "reason" => $reason)
     */
    public static function checkConnection($in_dbms, $in_host, $in_port, $in_db_name, $in_user, $in_password, $in_encoding) {
        $db_connector_class_file = "../controller/model/db_connector_".$in_dbms."_class.php";
        $status = true;
        $reason = "nothing";
        
        if(file_exists($db_connector_class_file) == true) {
            require_once($db_connector_class_file);
            $db_connector_class = $in_dbms."\\db_connector";
            
            //Aufruf einer Connector-Klasse in einem DB-spezifischen namespace
            $myConnection = new $db_connector_class($in_host, $in_port, $in_db_name, $in_user, $in_password, $in_encoding, true);           
            

            if($myConnection->getDbConnection() == false) {
                $status = false;
                $reason = "connection failed (host: ".$in_host.", port: ".$in_port.", DB: ".$in_db_name.", DBMS: ".$in_dbms.", user: ".$in_user.")";
            } else {
                $status = true;
                $reason = "connection successfull";
                $myConnection->close_connection();
            }
        } else {
            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " -> db_connector_class_file konnte nicht gefunden werden! ", $db_connector_class_file, "ERROR");
            $status = false;
            $reason = "connection failed (connector not found".$db_connector_class_file.")";
        }
        
        $feedback = array("status" => $status, "reason" => $reason);
        return $feedback;
 
        
    }
    
    
} //End Class db_connection






class sql_request {
    
    

    
    /**
     *
     * @var     array      DB-Tabellen, auf die sich die SQL-Anforderung bezieht. Zweidimensionales array:
     *                      1. Dimension: key = lfd. Nr.; value = array 
     *                      2. Dimension: key = (db_schema|table|alias|join); value = der jeweilige Wert
     */
    protected $_tableList = array();
    
    /**
     *
     * @var     array       DB-Spalten, die in der Select-Anweisung genutzt werden sollen. Zweidimensionales array:
     *                      1. Dimension: key = lfd. Nr.; value = array 
     *                      2. Dimension: key = (table|column|alias|const|function_id|function_params|hidden); value = der jeweilige Wert
     */
    protected $_columnList = array();
    
    /**
     *
     * @var     String      SQL-Befehl. 
     */
    protected $_sql_command = "";
    
    /**
     *
     * @var     boolean     Gibt an, ob das SQL-Request-Object mit Einzelanweisungen für SELECT, FROM, JOIN usw. aufgebaut wird (Idealfall) oder ob 
     *                      komplexe Statementteile übergeben wurden. Wenn komplexe Statementteile übergeben wurden, wird der SQL-Befehl beinahe 1:1 belassen,
     *                      lediglich Security-Anweisungen werden ergänzt.
     */
    protected $_is_complex_statement = false; 
    
    /**
     *
     * @var     boolean     Gibt an, dass Teile der SQL-Anweisngen db-unabhängige Funktionsplatzhalter enthalten. Diese müsse noch durch den richtigen 
     *                      DB-Konnektor ersetzt werden. 
     */
    public $include_function_placeholder = false;
    
    /**
     *
     * @var     string      kompletter SELECT-Part, indem auch komplexe Ausdrücke verwendet werden können. Ohne "SELECT" als Einleitung
     */
    protected $_selectComplexPart;
    
    /**
     *
     * @var     string      kompletter FROM-Part, indem auch komplexe Ausdrücke verwendet werden können. Ohne "FROM" als Einleitung
     */
    protected $_fromComplexPart;
    
    /**
     *
     * @var     array       [optional] Liste der Column-Value-Paare, die für einen Insert-Befehl genutzt werden sollen. key = column, value = value
     */
    protected $_intoValueList;
    
    /**
     *
     * @var     array       [optional] Liste der Column-Value-Paare, die für einen Update-Befehl genutzt werden sollen. key = column, value = value
     */
    protected $_updateColumnList;
    
    /**
     *
     * @var     array       Where-Ausdrücke. Zweidimensionales array: default = array()
     *                      1. Dimension: key = lfd. Nr.; value = array 
     *                      2. Dimension: key = (separator|clam_open[optional]|table|column|operator|value|clam_close[optional]); value = der jeweilige Wert; separator = (AND|OR)
     */
    protected $_whereConditionList = array();
    
    
    /**
     *
     * @var     string      WhereCondition, die sich aus der Methode pagedata->getFormPropertyCondition ergeben. Diese werden nur bei 
     *                      Queries in diesem Attribut übergeben. Bei Tables wird stattdessen mit ComplexStatements gearbeitet. 
     */
    protected $_whereConditionFormFilter = "";
    
    /**
     *
     * @var     array       Where-Ausdrücke, welche einer Join-Klusel hinzugefügt werden. Zweidimensionales array: default = array()
     *                      1. Dimension: key = lfd. Nr.; value = array 
     *                      2. Dimension: key = (separator|clam_open[optional]|table_id|column|operator|right_tablename|right_columnname|clam_close[optional]); separator = (AND|OR)
     */
    protected $_joinConditionList = array();
    
    
    /**
     *
     * @var     array       Liste von Where-Anweisungen, die sich aus der DB-Tabelle role_access_restriction ergibt
     */
    protected $_whereSecurityConditionList;
    
    /**
     *
     * @var     string      [optional] kompletter WHERE-Part, indem auch komplexe Ausdrücke verwendet werden können. Ohne "WHERE" als Einleitung
     */
    protected $_whereComplexPart = "";
    
    /**
     *
     * @var     integer     id der aktiven Userrole, in dessen Kontext der SQL-Request ausgeführt werden soll 
     */
    protected $_activeUserroleId;
    
    
    /**
     *
     * @var     string      id des aktiven Users 
     */
    protected $_activeUserId;
    
    
    /**
     *
     * @var     string      app_id der aktiven Userrole, in dessen Kontext der SQL-Request ausgeführt werden soll
     */
    protected $_activeUserroleAppid;
    
    /**
     *
     * @var     string      ID der zu verwendenden db-connection 
     */
    public $connection_id;
    
    /**
     *
     * @var     string      [optional] kompletter ORDER-BY-Part, indem auch komplexe Ausdrücke verwendet werden können. Ohne "ORDER BY" als Einleitung
     */
    protected $_orderbyComplexPart = "";

    /**
     *
     * @var     string      [optional] kompletter GROUP-BY-Part, indem auch komplexe Ausdrücke verwendet werden können. Ohne "GROUP BY" als Einleitung
     */
    protected $_groupbyComplexPart = "";
    
    /**
     *
     * @var     integer     [optional] Limit-Parameter für SELECT-Anweisungen
     */
    protected $_limit = 0;
    
    /**
     *
     * @var     integer     [optional] Offset-Anweisung für SELECT-Anweisungen 
     */
    protected $_offset = 0;
    
    /**
     *
     * @var     array       Liste der Security-Conditions für die aktive Rolle. Die Security-Conditions
     *                      werden entweder über die Tabelle role_access_restriction durch den jeweiligen
     *                      App-Admin oder App-root vorgegeben oder sie werden durch die Funktion addSecurityCondition
     *                      ergänzt.
     * * Bsp.: Array
                    (
                    [0] => Array
                        (
                            [role_access_restriction.role_app_id] => WIDER
                            [role_access_restriction.role_id] => 13
                            [role_access_restriction.id] => 1
                            [role_access_restriction.restriction_calm_open] => (
                            [role_access_restriction.restriction_praefix] => 
                            [role_access_restriction.restriction_schema] => widerspruch
                            [role_access_restriction.restriction_table] => bew
                            [role_access_restriction.restriction_column] => nachname
                            [role_access_restriction.restriction_operator] => like
                            [role_access_restriction.restriction_value] => 'R%'
                            [role_access_restriction.restriction_calm_close] => 
                            [role_access_restriction.sort] => 1
     *                      [role_access_restriction.restriction_value_internvariable] => 
                        )

                    [1] => Array
                        (
                            [role_access_restriction.role_app_id] => WIDER
                            [role_access_restriction.role_id] => 13
                            [role_access_restriction.id] => 2
                            [role_access_restriction.restriction_calm_open] => 
                            [role_access_restriction.restriction_praefix] => AND
                            [role_access_restriction.restriction_schema] => widerspruch
                            [role_access_restriction.restriction_table] => bew
                            [role_access_restriction.restriction_column] => nachname
                            [role_access_restriction.restriction_operator] => like
                            [role_access_restriction.restriction_value] => 'S%'
                            [role_access_restriction.restriction_calm_close] => )
                            [role_access_restriction.sort] => 2
     *                      [role_access_restriction.restriction_value_internvariable] => 
                        )

                )
     */
    protected $_securityConditions = array();
    
    
    /**
     *
     * @var     boolean         (optional; default = 1) [0|1] Schalter, um Berücksichtigung der Security-Conditions abzuschalten. Das ist notwendig, 
     *                          wenn die Klasse sql_request sich selbst aufruft. Sonst würde eine Endlosschleife enstehen. Zudem müssen die meisten internen 
     *                          Funktionen vollen Zugriff auf Daten haben. I.d.R. müssen nur Anwender-Queries und Anwenderdaten (getTableData) eingeschränkt werden. 
     */
    protected $_deactivateSecurity;
    
    
    /**
     *
     * @var     string          App-ID des angemeldeten Users. 
     */
    protected $_logedInUserAppId;



    /** Erzeugt ein SQL-Request-Objekt, welches zur Kommunikations mit dem Datenbankhandler genutzt werden kann/muss.
     * 
     * @param string    $in_connetion_id        ID der connection
     * @param string    $in_userroleAppId       app_id der aktiven Userrole, in dessen Kontext der SQL-Request ausgeführt werden soll   
     * @param integer   $in_userroleId          id der aktiven Userrole, in dessen Kontext der SQL-Request ausgeführt werden soll 
     * @param string    $in_caller              aufrufende Funktion
     * @param boolean   $in_deactivateSecurity  (optional; default = 1) [0|1] Schalter, um Berücksichtigung der Security-Conditions abzuschalten. Das ist notwendig, 
     *                                          wenn die Klasse sql_request sich selbst aufruft. Sonst würde eine Endlosschleife enstehen. Zudem müssen die meisten internen 
     *                                          Funktionen vollen Zugriff auf Daten haben. I.d.R. müssen nur Anwender-Queries und Anwenderdaten (getTableData) eingeschränkt werden.
     */
    public function __construct($in_connetion_id, $in_userroleAppId, $in_userroleId, $in_caller, $in_deactivateSecurity = true) {
        
        $this->_activeUserroleAppid = $in_userroleAppId;
        $this->_activeUserroleId = $in_userroleId;
        if (isset($_SESSION["uid"])) {$this->_activeUserId = $_SESSION["uid"];} else {$this->_activeUserId = "undefined";}
        $this->connection_id = $in_connetion_id;
        $this->_deactivateSecurity = $in_deactivateSecurity;
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  Query-Security-Flag from Caller '.$in_caller, $in_deactivateSecurity);
        if($in_deactivateSecurity != true) {$this->_securityConditions = $this->readSecurityConditionsForRole();}
        
    }
    
    
    /**
     * gibt den String der Daten, die in der Tabelle logdata in die Spalte "daten" geschrieben werden sollen.
     */
    public function getLogdata() {
        //ToDo: Funktion getLogdata beenden
    }
    
    
    /** Gibt die Scurity-Condtions zurück, falls vorhanden.
     * Diese sind erst nach dem Aufruf von 
     * 
     * @return  array         Array mit den Conditions. Wenn keine Conditions vorhanden sind, dann gibt die Funktion ein leeres Array zurück
     */
    public function getSecurityConditions() {
        return $this->_securityConditions;
    }
    
    
    
    /** Setzt oder ergänzt $in_formFilterCondition zum Attribut _whereConditionFormFilter.
     * 
     * @param   string      $in_formFilterCondition     SQL-Bedingung
     */
    public function addFormFilterCondition($in_formFilterCondition) {
        if(is_string($in_formFilterCondition) AND $in_formFilterCondition != "") {
            if($this->_whereConditionFormFilter != "") {
                $this->_whereConditionFormFilter = $this->_whereConditionFormFilter." AND ".$in_formFilterCondition;
            } else {
                $this->_whereConditionFormFilter = $in_formFilterCondition;
            }
        } 
    }
    
    
    
    /** Ergänzt eine SecurityCondition zur Liste der Conditions
     * 
     * @param   array   $in_condition   Bsp.: Array
                                                    (
                                                        [role_access_restriction.role_app_id] => WIDER
                                                        [role_access_restriction.role_id] => 13
                                                        [role_access_restriction.id] => 2
                                                        [role_access_restriction.restriction_calm_open] => 
                                                        [role_access_restriction.restriction_praefix] => AND
                                                        [role_access_restriction.restriction_schema] => widerspruch
                                                        [role_access_restriction.restriction_table] => bew
                                                        [role_access_restriction.restriction_column] => nachname
                                                        [role_access_restriction.restriction_operator] => like
                                                        [role_access_restriction.restriction_value] => 'S%'
                                                        [role_access_restriction.restriction_calm_close] => )
                                                        [role_access_restriction.sort] => 2
     *                                                  [role_access_restriction.restriction_value_internvariable] => 
                                                    )
     */
    public function addSecurityConditions($in_condition) {
        $this->_securityConditions[] = $in_condition;
    }
    
    
    public function getLogdataIdCollums() {
        //ToDo: Funktion getLogdataIdCollums beenden
    }
    
    
    /**
     * Für die aktive Rolle werden zusätzliche Bedingungen zur Einschränkung der Tabellen
     * im Kernelschema (App = SYS01) ergänzt. Jede Rolle, darf in diesem Schema nur die Daten der eigenen APP
     * und der KernelApp auslesen.
     */
    protected function addDefaultSecurityCondition() {
        
        //1. Prüfen, ob in der Tablelist eine Tabelle des Kernelschema enthalten ist.
        $containsKernelSchema = $this->containsTablelistSchema(global_variables::getNameOfDbSchemaSYS01());
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> $containsKernelSchema: ', $containsKernelSchema);
        
        
        //Wenn Rolle APP-Manager und user sys01root angemeldet sind, dann securityBedingungen deaktivieren.
        if($this->_activeUserroleAppid == global_variables::getAppIdFromSYS01() AND
           $this->_activeUserroleId == global_variables::getAppManagerRoleId() AND
           isUserRoot($this->_activeUserId) == true) {
            $containsKernelSchema = false;
        }
        
            if($containsKernelSchema == true) {

                //2. Liste der SYS01-Tabellen aus backuptabledefinitions auslesen 
                $kernelTablelist = getBackupTabledefinitions("'configtable', 'addIfContentBackupForApp'", global_variables::getAppIdFromSYS01());
    //            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> $kernelTablelist: ', $kernelTablelist);

                //3. App und ID der aktuellen Rolle ermitteln -> Role-App, Role-ID
                $role_app_id = $this->_activeUserroleAppid;
                $role_id = $this->_activeUserroleId;
                $user_app_id = getAppIDFromActiveAccount();
//                $user_app_id = $this->_activeUserroleAppid;                   //nicht verwendbar, da _activeUserroleAppid auch SYS01 sein kann. 
                

                //4. Schleife über alle verwendeten Tabellen durchführen, um zusätzliche Security-Conditions zu bilden
                $i = 1000;              
                foreach ($kernelTablelist as $currentKernelTable) {
                    $temp_array = array();
                    $i = $i + 1;
                    $temp_array["role_access_restriction.role_app_id"] = $role_app_id;
                    $temp_array["role_access_restriction.role_id"] = $role_id;
                    $temp_array["role_access_restriction.role_id"] = $i;        //ToDo: Warum wird hier die vorherige Zeile gleich wieder überschrieben? [TJ: 17.10.2021]
                    $temp_array["role_access_restriction.restriction_calm_open"] = "";
                    $temp_array["role_access_restriction.restriction_praefix"] = "";
                    $temp_array["role_access_restriction.restriction_schema"] = global_variables::getNameOfDbSchemaSYS01();
                    $temp_array["role_access_restriction.restriction_table"] = $currentKernelTable["backup_tabledefinitions.tablename"];
                    $temp_array["role_access_restriction.restriction_column"] = $currentKernelTable["backup_tabledefinitions.app_column"];
                    $temp_array["role_access_restriction.restriction_operator"] = "in";
                    $temp_array["role_access_restriction.restriction_value"] = "('".global_variables::getAppIdFromSYS01()."', '".$user_app_id."')";
                    $temp_array["role_access_restriction.restriction_calm_close"] = "";
                    $temp_array["role_access_restriction.sort"] = $i;
                    $temp_array["role_access_restriction.restriction_value_internvariable"] = "";

                    $this->addSecurityConditions($temp_array);
                }

            }
    }
    
    
    /** Ersetzt in $this->_columnlist den übergebenen FunctionPlaceholder durch den übergebenen SQL-Ausdruck.
     * 
     * @param   string      $in_placeholder     Platzhalter der Funktion (Bsp.: {{{{function_name=strpos?string=form.image&find_string='img/'}}}} )
     * @param   string      $in_sql_syntax      Ausdruck in SQL-Syntax (Bsp.: STRPOS(form.image, 'img/') )
     */
    public function replaceFunctionPlaceholderInColumnlist($in_placeholder, $in_sql_syntax) {
        foreach ($this->_columnList as $key => $currentColumn) {
            if($in_placeholder == $currentColumn["command"]) {
                $this->_columnList[$key]["command"] = $in_sql_syntax;
            }
        }
    }
    
    
    
    
    /** Ersetzt Referenzen im SQL-Ausdruck einer Spalte durch den SQL-Ausdruck der referenzierten Spalte.
     * $this->_columnlist wird ebenfalls aktualisiert.
     * 
     * @param   array   $in_references      Liste der Referenzen. Eine Refernz besteht jeweils aus dem tag column und dem Alias der Referenziertern spalte. Bsp.: <column>spalte_a</column>
     * @param   string  $in_SqlCommand      komplettes SQL-Statement (inkl. SELECT, FROM, WHERE, usw.)
     * @return  string                      SqlCommand, in dem die Referenzen durch die SQL-Ausdrücke der refernzierten Spalten ersetzt sind.
     */
    public function replaceColumnReferencesInSqlcommand($in_references, $in_SqlCommand) {
        
        foreach ($in_references as $key => $currentReference) {
            $sql_value_for_reference = $this->getColumnSql($currentReference);
            if($sql_value_for_reference === false) {
                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Column-Reference nicht gefunden ', "Refernce ".$currentReference." konte nicht aufgelöst werden. Wahrscheinlich ist der Alias falsch.", "ERROR");
            } else {
                $tempReference = "<column>".$currentReference."</column>";
                $in_SqlCommand = str_replace($tempReference, $sql_value_for_reference, $in_SqlCommand);
                $this->replaceColumnReferenzInColumnlist($tempReference, $sql_value_for_reference);
            }
            
            
        }
        
        return $in_SqlCommand;
        
    }
    
    
    /** Ersetzt in $this->_columnlist die Referenz auf eine andere Spalte durch den übergebenen Ausdruck
     * 
     * @param   string      $in_ColumnReferenz      Referenzkennzeichen; Bsp.: "<column>alias</column>"
     * @param   string      $in_replacestring       String, welcher stattdessen eingefügt werden soll.
     */
    private Function replaceColumnReferenzInColumnlist($in_ColumnReferenz, $in_replacestring) {
        foreach ($this->_columnList as $key => $currentColumn) {
            if(strpos($currentColumn["command"], $in_ColumnReferenz) !== false) {
                $this->_columnList[$key]["command"] = str_replace($in_ColumnReferenz, $in_replacestring, $currentColumn["command"]);
            }     
        }
    }
    
    
    /** Sucht in der Columnlist nach einer Spalte mit dem gegebenen Alias und gibt deren SQL-Ausdruck zurück.
     * 
     * @param   string      $in_ColumnAlias     Alias einer Spalte
     * @return  mixed                           String (Sql-Ausdruck) oder false, falls keine Spalte mit dem Alias gefunden wurde.
     */
    private function getColumnSql($in_ColumnAlias) {
        $feedback = false;
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Columnlist ', $this->_columnList, "INFO");
        foreach ($this->_columnList as $currentColumn) {
            if($currentColumn["alias"] == $in_ColumnAlias) {
                //Wenn die Spalte gefunden wurde
                $feedback = $currentColumn["command"];
            }
        }
        
        return $feedback;
    }
    
    
    
    /** Prüft, ob in $this->_tablelist eine Tabelle des angegebenen Schema enthalten ist.
     * 
     * @param   string  $in_schema      Name des DB-Schema
     * @return  boolean
     */
    protected function containsTablelistSchema($in_schema) {
        $containsSchema = false;
//        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> tablelist: ', $this->_tableList);
        foreach ($this->_tableList as $currentTable) {
            if($currentTable["db_schema"] == $in_schema) {
                $containsSchema = true;
                break;
            }
        }
        return $containsSchema;
    }
    
    
    
    /** [optional] Setzt den OrderBy-Part. Dabei das "ORDER BY" nicht angeben. Es wird lediglich eine Liste der 
     * Spalten in einem String erwartet.
     * 
     * @param string $in_orderBy    Spaltenliste, nach denen sortiert werden soll (Bsp.: table.column1, table.column2, table.column3)
     */
    public function addOrderbyPart($in_orderBy) {
        $this->_orderbyComplexPart = $in_orderBy;
    }
    
    
    
     /** [optional] Setzt den GroupBy-Part. Dabei das "GROUP BY" nicht angeben. Es wird lediglich eine Liste der 
     * Spalten in einem String erwartet.
     * 
     * @param string $in_groupBy    Spaltenliste, nach denen gruppiert werden soll (Bsp.: table.column1, table.column2, table.column3)
     */
    public function addGroupbyPart($in_groupBy) {
        $this->_groupbyComplexPart = $in_groupBy;
    }
    
    
    
    /** [optional] Legt den Limit-Wert und bei Bedarf den Offset-Wert für eine SELECT-Anweisung fest.
     * 
     * @param integer $in_limit     Anzahl der anzuzeigenden Datensätze. Wenn alle Datensätze angezeigt werden sollen, dann sollte kein LImit-Wert gesetzt werden.
     * @param integer $in_offset    Startpunkt, ab dem limit-Datensätze der Ergebnismenge zurückgegeben werden sollen.
     */
    public function setLimit($in_limit, $in_offset = 0) {
        $this->_limit = $in_limit;
        $this->_offset = $in_offset;
    }
    
    
    
    
    
    /**Selektiert die SecurityConditions, welche sich auf $this->_tablelist beziehen.
     * Diese werden in SQL-Syntax zurückgegeben, sodass sie in im WherePart verwendet werden können.
     * 
     * @param   string      $in_tablename   [optional] Tabellenname, auf den sich die Security-Condition beziehen soll. Falls dieser Parameter nicht angegeben ist, werden die Security-Conditions für alle Tabelle in $this->_tablelist ermittelt.
     * @return  string                      Bsp.: (widerspruch.bew like 'R%' AND widerspruch.bew like 'S%')
     */
    protected function getSecurityConditionsForTables($in_tablename = "") {
        $sqlFeedback = "";
        $durchlauf = 1;
        //Default-Security-Conditions für die aktive Rolle ergänzen, falls sich der SqlRequest auf eine DB-Tabelle des Kernelschemas bezieht.
        if($this->_deactivateSecurity <> true) {
            $this->addDefaultSecurityCondition();
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Security-Condition: ', $this->getSecurityConditions()); 
        }
                
        //Liste der Tabellen, die im aktuellen SQL-Befehl beteiligt sind, durchlaufen und die Conditions, die sich auf die beteiligten Tabellen beziehen, 
        //in einem SQL-String für den Where-Part zurückgeben
        foreach ($this->_tableList as $currentTable) {
            if ($in_tablename <> "") {
                //Wenn ein Tabellenname angegeben wurde, werden nur die Conditions für diese Tabelle gesucht
                if($in_tablename == $currentTable["table"]) {$is_searched_table = true;} else {$is_searched_table = false;}
            } else {
                //Ansonsten werden alle Conditions genutzt.
                $is_searched_table = true;
            }
            if($is_searched_table == true) {
                //Prüfen, ob für die aktuelle Tabelle eine SecurityCondition existiert
                foreach ($this->_securityConditions as $currentCondition) {
                    if($currentCondition["role_access_restriction.restriction_table"] == $currentTable["table"]) {
                        //Platzhalter für interne Variablen ersetzen
                        if ($currentCondition["role_access_restriction.restriction_value_internvariable"] <> "") {
                            $value = "'".$this->getValueFromSessionVariable($currentCondition["role_access_restriction.restriction_value_internvariable"])."'";
                        } else {
                            $value = $currentCondition["role_access_restriction.restriction_value"];
                        }
                        
                        
                        //Ab dem zweiten Durchlauf bzw. ab der zweiten Ergänzung einer Security-Condition muss sichergestellt werden, dass ein Präfix angegeben ist.
                        //In der Oberfläche kann das nicht erzwungen werden, da dem Anwender nicht klar sein kann, ob Programmintern zwei Conditions,
                        // welche sich auf verschiedene Tabellen beziehen, miteinander kombiniert werden.
                        if($durchlauf > 1 AND $currentCondition["role_access_restriction.restriction_praefix"] == "") {
                            $praefix = 'AND';
                        } else {
                            $praefix = $currentCondition["role_access_restriction.restriction_praefix"];
                        }
                        
//                        addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> ergänze Security-Condition mit Präfix: '.$praefix, $currentCondition); 
                        //Wenn es für die aktuelle Tabelle eine SecurityCondition gibt, wird diese in $sqlFeedback übertragen
                        if($currentTable["alias"] != "") {$tempTableName = $currentTable["alias"];} else {$tempTableName = $currentTable["table"];}
                        $sqlFeedback = $sqlFeedback.
                            $currentCondition["role_access_restriction.restriction_calm_open"].
                            $praefix." ".
                            $tempTableName.".".
                            $currentCondition["role_access_restriction.restriction_column"]." ".
                            $currentCondition["role_access_restriction.restriction_operator"]." ".
                            $value." ".
                            $currentCondition["role_access_restriction.restriction_calm_close"]." ";
                        
                        $durchlauf = $durchlauf +1;
                    }
                }
            }
        }
        if ($sqlFeedback <> "") {
            $sqlFeedback = " \n --SecurityConditions \n "." AND (".$sqlFeedback.") \n";          //Klammer stellt sicher, dass Conditions nur in Summe wirken und eventuell enthaltende OR-Operatoren nicht die sonstigen Bedingungen im WHEREPart beeinflussen
//            addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> Security-Condition: ', $sqlFeedback); 
        }
        return $sqlFeedback;
    }
    
    
    
    
    /** gibt für ein Attribut der SessionVariable dessen Inhalt zurück.
     * <b>Achtung</b>: Derzeit nur für die Variable "session.uid"
     * 
     * @param   string  $in_Variable    SESSION-Attribut; gültige Werte [session.uid]
     * @return  string                  Wert des Attributs
     */
    protected function getValueFromSessionVariable($in_Variable) {
        if($in_Variable == "session.uid") {
            return $_SESSION["uid"];   
        }
    }

    
    /** Schreibt in die interne Eigenschaft _sql_command das übergebene SQL-Kommando.
     * Dadurch wird dieses bei der Ausführung auch unverändert verwendet.
     * 
     * @param type $in_sqlCommand
     */
    public function setSqlCommand($in_sqlCommand) {
        $this->_sql_command = $in_sqlCommand;
    }
    
    
    
    
    /** Gibt auf Basis der vorhandenen Attribute dieses Objektes einen SELECT-Befehl zurück.
     * 
     * @return string
     */
    public function getSelectCommand() {
        if($this->_sql_command != "") {
            return $this->_sql_command;
        } else {
            $sqlCommand = "";
//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ , "Aufruf getSelectCommad", "INFO");
            if($this->_is_complex_statement == true) {
                //wenn komplexe Ausdrücke vorgegeben wurden

                //SelectPart
                $sqlCommand = $sqlCommand."SELECT \n".$this->_selectComplexPart." \n";
                //FromPart
                $sqlCommand = $sqlCommand."FROM \n".$this->_fromComplexPart." \n";
                //addConditions und SecurityConditions im Where-Part ergänzen
                $addConditions = $this->_whereComplexPart;
                $securityConditions = $this->getSecurityConditionsForTables();
                if($addConditions == "") {
                    if($securityConditions == "") {
                        //keine Ergänzung notwendig
                        $wherePart = "";
                    } else {
                        //die Security-Conditions existieren
                        $wherePart = "WHERE \n 1=1 ".$securityConditions." ";
                    }
                } else {
                    if($securityConditions == "") {
                        //nur die addConditions existieren
                        $wherePart = "WHERE \n (1=1 ".$addConditions." ) ";
                    } else {
                        //die Security-Conditions und addConditions existieren
                        $wherePart = "WHERE \n (1=1 ".$addConditions." ) ".$securityConditions;
                    }
                }

                $sqlCommand = $sqlCommand.$wherePart;


                //GroupByPart
                if($this->_groupbyComplexPart <> "")    {$sqlCommand = $sqlCommand."GROUP BY \n".$this->_groupbyComplexPart." \n";}
                //OrderByPart
                if($this->_orderbyComplexPart <> "")    {$sqlCommand = $sqlCommand."ORDER BY \n".$this->_orderbyComplexPart." \n";}
                //Limit und Offset
                $sqlCommand =   $sqlCommand.$this->buildLimitPartForSqlCommand()." \n";
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." - SQL-Abfrage" , $sqlCommand, "INFO");


            } else {
                //wenn der SQL-Befehl aus Einzelangaben zusammengesetzt werden soll
//                addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' ->  lebe noch ', "in getSelectCommand");
                //1. Select-Part
                $sqlCommand = $this->buildSelectPartForSqlCommand()." \n";
//                addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__." - Columnlist" , $this->_columnList, "INFO");
                //2. From-Part
                $sqlCommand = $sqlCommand.$this->buildFromPartForSqlCommand()." \n";
                //3. Alle Conditions, die nicht bereits zuvor in einer JOIN-Condition im From-Part eingebunden werden konnten, werden nun im Where-Part ergänzt.
                $wherePart = $this->buildWherePartForSqlCommad(true);
                if($wherePart <> "") {$sqlCommand =   $sqlCommand."WHERE \n ".$wherePart." \n";}
                //4. GroupBy-Part
                if($this->_groupbyComplexPart <> "")    {$sqlCommand = $sqlCommand."GROUP BY \n".$this->_groupbyComplexPart." \n";}
                //5. OrderBy-Part
                if($this->_orderbyComplexPart <> "")    {$sqlCommand = $sqlCommand."ORDER BY \n".$this->_orderbyComplexPart." \n";}
                //6. Limit-Offset-Part
                $sqlCommand =   $sqlCommand.$this->buildLimitPartForSqlCommand()." \n";
                
            }

//            addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  getSelectCommad (complexstatement = $this->_is_complex_statement", $sqlCommand, "INFO");
            $this->_sql_command = $sqlCommand;
            return $sqlCommand;
        }
    }
    
    
    
    
    
    /** Erstellt auf Basis von $this->_limit und $this->_offset den Limit-Part für einen SQL-Befehl
     * 
     * @return  string  Select-Part inklusive dem Schlüsselwort "LIMIT"
     */
    public function buildLimitPartForSqlCommand() {
        $sqlCommand = "";
        if($this->_limit <> 0) {
            $sqlCommand = $sqlCommand."LIMIT ".$this->_limit." ";
            if($this->_offset <> 0) {
                $sqlCommand = $sqlCommand."OFFSET ".$this->_offset." \n";
            }
        }
        return $sqlCommand;
    }
        
    
    
    
    
    
    /** Erstellt auf Basis von $this->_whereConditionList den Where-Part für einen SQL-Befehl. Alle benutzten Conditions werden 
     * mit used = true gekennzeichnet.
     * 
     * @param   boolean $in_addSecurityCondtions    Wenn true, werden die SeciurityConditions ergänzt.
     * @param   string  $in_tablename               [optional] Falls angegegeben, werden nur Conditions für diese Tabelle gesucht. 
     *                                              Achtung: Wenn für die Tabelle eine Alias verwendet werden soll, muss an dieser Stelle der Alias übergeben werden.
     * @return  string                              Where-Conditions in SQL-Syntax inklusive
     */
    protected function buildWherePartForSqlCommad($in_addSecurityCondtions, $in_tablename = "") {
        $sqlCommand = "";
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> whereConditionList: ', $this->_whereConditionList);
                                
        if($this->_whereConditionList <> array()) {
            foreach ($this->_whereConditionList as $key => $conditionData) {
                if(isset($conditionData["used"]) == false) {
                    if ($in_tablename <> "") {
                        //Wenn ein Tabellenname angegeben wurde, werden nur die Conditions für diese Tabelle gesucht
                        if($in_tablename == $conditionData["table"]) {$is_searched_table = true;} else {$is_searched_table = false;}
                    } else {
                        //Ansonsten werden alle Conditions genutzt.
                        $is_searched_table = true;
                    }
                    if($is_searched_table == true) {
                        $sqlCommand = $sqlCommand."    ".$conditionData["separator"]." ".$conditionData["clam_open"].$conditionData["table"].".".$conditionData["column"]." ".$conditionData["operator"]." ".$conditionData["value"].$conditionData["clam_close"]." ";
                        $this->_whereConditionList[$key]["used"] = true;
                    }
                }
            }
        }
        
        $sqlCommand =   "(1=1".$sqlCommand.") ";
        if ($this->_whereConditionFormFilter != "" and $in_tablename == "") {
            //Wenn eine Where-Condition existiert, aber keine Tabelle angegeben wurde, dann wird gerade der Where-Part, 
            //statt einem Join-Part aufgebaut. In dem Fall wird die vorher bereits ermittelte Where-Condition ebenfalls ergänzt.
            $sqlCommand =   $sqlCommand." AND (".$this->_whereConditionFormFilter.") ";
        }
        if ($in_addSecurityCondtions == true) {
            $sqlCommand =   $sqlCommand.$this->getSecurityConditionsForTables($in_tablename);
        } 
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> sqlCommand nach addWhereCondition (table '.$in_tablename.'): ', $sqlCommand);
        
        return $sqlCommand;
    }


    
    /** Erstellt auf Basis von $this->_joinConditionList die ON-Bedingungen für einen JOIN-Part einer bestimmten Tabelle in 
     * einem SQL-Befehl.
     * 
     * @param   string $in_tablename    Name der Tabelle, dessen Join-Conditions erstellt werden sollen.
     * @return  string                  JOIN-Conditions in SQL-Syntax inklusive
     */
    protected function buildJoinWherePartForSqlCommad($in_tablename) {
        $sqlCommand = "";
        $wherePart = "";
        $app_id_from_kernel = global_variables::getAppIdFromSYS01();
        if($this->_joinConditionList <> array()) {
            foreach ($this->_joinConditionList as $key => $conditionData) {
                
                //Es werden nur die Conditions für die angegebene Tabelle gesucht
                if($in_tablename == $conditionData["table"]) {
                    if($conditionData["right_column_format"] <> "") {
                        $sql_functionplaceholder_start_tag = getConfig("sql_start_tag_function_placeholder", $app_id_from_kernel);
                        $sql_functionplaceholder_end_tag = getConfig("sql_end_tag_function_placeholder", $app_id_from_kernel);
                        $left_part = $conditionData["table"].".".$conditionData["column"];
                        $right_part = $sql_functionplaceholder_start_tag."function_name=cast?value=".$conditionData["right_tablename"].".".$conditionData["right_columnname"]."&type=".$conditionData["right_column_format"].$sql_functionplaceholder_end_tag;
                        $this->include_function_placeholder = true;
                    } elseif($conditionData["column_format"] <> "") {
                        $sql_functionplaceholder_start_tag = getConfig("sql_start_tag_function_placeholder", $app_id_from_kernel);
                        $sql_functionplaceholder_end_tag = getConfig("sql_end_tag_function_placeholder", $app_id_from_kernel);
                        $right_part = $conditionData["right_tablename"].".".$conditionData["right_columnname"];
                        $left_part = $sql_functionplaceholder_start_tag."function_name=cast?value=".$conditionData["table"].".".$conditionData["column"]."&type=".$conditionData["column_format"].$sql_functionplaceholder_end_tag;
                        $this->include_function_placeholder = true;
                    } else {
                        $right_part = $conditionData["right_tablename"].".".$conditionData["right_columnname"];
                        $left_part = $conditionData["table"].".".$conditionData["column"];
                    }
                    $wherePart = $wherePart." ".$conditionData["separator"]." ".$conditionData["clam_open"].$left_part." ".$conditionData["operator"]." ".$right_part.$conditionData["clam_close"]." ";
                }
            }
        }
        $sqlCommand = $wherePart;
        return $sqlCommand;
    }
    
    
    
    
    
    /** Erstellt auf Basis von $this->_columnList den Select-Part für einen SQL-Befehl
     * 
     * @return  string  Select-Part inklusive dem Schlüsselwort "SELECT"
     */
    protected function buildSelectPartForSqlCommand() {
        $sqlCommand = "SELECT \n";
        $separator = "";                                                        //der separator wird erst nach dem ersten Durchlauf gesetzt.
        $app_id_from_kernel = global_variables::getAppIdFromSYS01();
        
        foreach ($this->_columnList as $key => $columnData) {
            if ($columnData["alias"] <> "") {$alias = " as ".$columnData["alias"];} else {$alias = "";}
            
            if ($columnData["const"] <> "") {
                //Wenn eine Konstante verwendet werden soll
                $currentCommand= "'".$columnData["const"]."'".$alias;
                if($columnData["hidden"] == 0) {
                    $sqlCommand = $sqlCommand."    ".$separator.$currentCommand." \n";
                } else {
                    $sqlCommand = $sqlCommand."    --".$separator.$currentCommand." \n";
                }
            } elseif ($columnData["function_id"] <> "") {
                //Wenn eine db-unabhängige Funktion genutzt werden soll.
                //einen Funktionsplatzhalter bilden, der später im DB-Connector durch die DBMS-spezifische Syntax ersetzt wird.
                //Bsp.: {{{{function_name=interval?interval_value=300&interval_type=SECOND}}}}
                $sql_functionplaceholder_start_tag = getConfig("sql_start_tag_function_placeholder", $app_id_from_kernel);
                $sql_functionplaceholder_end_tag = getConfig("sql_end_tag_function_placeholder", $app_id_from_kernel);
                $currentCommand = $sql_functionplaceholder_start_tag."function_name=".$columnData["function_id"]."?".$columnData["function_params"].$sql_functionplaceholder_end_tag;
                if($columnData["hidden"] == 0) {
                    $sqlCommand = $sqlCommand."    ".$separator.$currentCommand.$alias." \n";
                } else {
                    //Column wird ausgeblendet, aber Function dennoch korrekt dargestellt.
                    $sqlCommand = $sqlCommand."    --".$separator.$currentCommand.$alias." \n";
                }
                $this->include_function_placeholder = true;
            } else {
                //in allen anderen Fällen
                $currentCommand= " ".$columnData["table"].".".$columnData["column"].$alias;
                if($columnData["hidden"] == 0) {
                    $sqlCommand = $sqlCommand."    ".$separator.$currentCommand."\n";
                } else {
                    $sqlCommand = $sqlCommand."    --".$separator.$currentCommand."\n";
                }
                
            }
            $this->_columnList[$key]["command"] = $currentCommand;              //Spaltenkomando in columnlist zurückschreiben, damit es für spätere Spaltenverweise genutzt werden kann.
            if($separator == "" AND $columnData["hidden"] == 1) {
                $separator = "";                                                //Wenn schon die erste Spalte ausgeblendet werden soll, dann bleibt der seperator unverändert.
            } else {
                $separator = ",";                                               //ab dem zweiten Durchlauf, wird vor jede Spalte ein Komma gesetzt.
            }
                
        }
        
        return $sqlCommand;
    }
    
    
    
    
    
    
    
    /** Erstellt auf Basis von $this->_tableList und $this->_joinConditionList den From-Part für einen SQL-Befehl
     * Joins werden integriert.
     * 
     * @return  string  Select-Part inklusive dem Schlüsselwort "FROM"
     */
    protected function buildFromPartForSqlCommand() {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  tablelist ", $this->_tableList, "INFO");
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  joinConditionlist ", $this->_joinConditionList, "INFO");
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  securityCondition ", $this->_securityConditions, "INFO");
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  whereConditionlist ", $this->_whereConditionList, "INFO");
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  securityConditionlist ", $this->_whereSecurityConditionList, "INFO");
        
        $sqlCommand = "FROM \n";
        $separator = "";
        foreach ($this->_tableList as $tableData) {
            if ($tableData["join"] == "BASE") {
                //Die Basetabelle wird ohne ein Jointype eingebettet
                if ($tableData["alias"] <> "") {$alias = " as ".$tableData["alias"];} else {$alias = "";}
                $sqlCommand = $sqlCommand."    ".$separator." ".$tableData["db_schema"].".".$tableData["table"].$alias."\n";
                //$separator = ",";
            } else {
                
                //1. Tabelle über Join-Syntax  einbinden
                if ($tableData["alias"] <> "") {$alias = " as ".$tableData["alias"];} else {$alias = "";}
                $sqlCommand = $sqlCommand."\n        ".$separator." ".$tableData["join"]." JOIN ".$tableData["db_schema"].".".$tableData["table"].$alias." ON ";
                
                //2. Join-Conditions für die aktuelle Tabelle ergänzen
                if ($tableData["alias"] <> "") {$table = $tableData["alias"];} else {$table = $tableData["table"];}
                $joinConditions = $this->buildJoinWherePartForSqlCommad($table)." ";
                
                
                //3. Where-Conditions inkl. Security-Conditions für die aktuelle Join-Tabelle ermitteln und ergänzen
                $whereConditions = $this->buildWherePartForSqlCommad(false, $table)." ";
                
                
                
                if($joinConditions != "") {
                    $sqlCommand = $sqlCommand." (1=1) ".$joinConditions;
                    if($whereConditions != "") {
                        $sqlCommand = $sqlCommand." AND ".$whereConditions;
                    }
                } else {
                    if($whereConditions != "") {
                        $sqlCommand = $sqlCommand.$whereConditions;
                    }
                }
                
                
               
            }
        }
        return $sqlCommand;
    }



    
    
    public function getDeleteCommand() {
        
    }
    
    public function getUpdateCommand() {
        
    }
    
    public function getInsertCommand() {
        
    }
    
    
    
    
    /** Ermittelt für die aktive Rolle die Liste der Security-Einschränkungen aus der DB-Tabelle role_access_restriction.
     * 
     * @global  string      $db_schema_manager                      Diese globale Konstante wird benutzt
     * @global  string      $db_schema_manager_connection_id        Diese globale Konstante wird benutzt
     * @return  array                                               Liste der Security-Einschränkungen der aktuellen Rolle (Zweidimensionales Array; 
     */
    protected function readSecurityConditionsForRole() {
        //role_restriction auswerten und Security-Part aufbauen
        global $db_schema_manager;
        global $db_schema_manager_connection_id;

        $queryRequest = new sql_request($db_schema_manager_connection_id, $this->_activeUserroleAppid,$this->_activeUserroleId, __FUNCTION__, true);
            $queryRequest->addSelectColumn("role_access_restriction", "role_app_id");
            $queryRequest->addSelectColumn("role_access_restriction", "role_id");
            $queryRequest->addSelectColumn("role_access_restriction", "id");
            $queryRequest->addSelectColumn("role_access_restriction", "restriction_calm_open");
            $queryRequest->addSelectColumn("role_access_restriction", "restriction_praefix");
            $queryRequest->addSelectColumn("role_access_restriction", "restriction_schema");
            $queryRequest->addSelectColumn("role_access_restriction", "restriction_table");
            $queryRequest->addSelectColumn("role_access_restriction", "restriction_column");
            $queryRequest->addSelectColumn("role_access_restriction", "restriction_operator");
            $queryRequest->addSelectColumn("role_access_restriction", "restriction_value");
            $queryRequest->addSelectColumn("role_access_restriction", "restriction_value_internvariable");
            $queryRequest->addSelectColumn("role_access_restriction", "restriction_calm_close");
            $queryRequest->addSelectColumn("role_access_restriction", "sort");
            
            $queryRequest->addTable($db_schema_manager, "role_access_restriction", 1, "BASE");
            
            $queryRequest->addWhereCondition("AND",    "", "role_access_restriction", "role_app_id",  "=", "'".$this->_activeUserroleAppid."'",    "");
            $queryRequest->addWhereCondition("AND", "", "role_access_restriction", "role_id",      "=", $this->_activeUserroleId,        "");
            
            $queryRequest->addOrderbyPart("role_access_restriction.sort");
        $queryResult = db_connection_handler::selectOnDatabase($queryRequest, __FUNCTION__);
        
        //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> SecurityList sql: ', $queryRequest->getSelectCommand());
        //addToDebug(__FILE__.' Zeile '.__LINE__.' -> '.__FUNCTION__.' -> SecurityList for role: '.$this->_activeUserroleAppid."-".$this->_activeUserroleId, $queryResult);
        
        return $queryResult;
    }
    
    
    
    /** Ergänzt ein Column-Value-Paar zur Gesamtliste der Paare, die für einen Insert-Befehl genutzt werden sollen.
     * 
     * @param string $in_column
     * @param string $in_value
     */
    public function addIntoValuePair($in_column, $in_value) {
        $this->_intoValueList[$in_column] = $in_value;
        
    }
    
    
    
    /** Ergänzt ein Column-Value-Paar zur Gesamtliste der Paare, die für einen Update-Befehl genutzt werden sollen.
     * 
     * @param string $in_column
     * @param string $in_value
     */
    public function addUpdateValuePair($in_column, $in_value) {
        $this->_updateColumnList[$in_column] = $in_value;
        
    }
    
    
    
    /** [optional] Ergänzt einen SQL-Ausdruck der WHere-Klausel
     * 
     * @param string    $in_separator       (AND|OR)
     * @param string    $in_clam_open       öffnende Klammer (auch mehrere) oder Leerstring ""
     * @param string    $in_table           Tabellenname
     * @param string    $in_column          Spaltenname
     * @param string    $in_operator        (=|>=|like|in| ...)
     * @param string    $in_value           der Vergleichswert
     * @param string    $in_clam_close      schließende Klammer (auch mehrere) oder Leerstring ""
     */
    public function addWhereCondition($in_separator, $in_clam_open, $in_table, $in_column, $in_operator, $in_value, $in_clam_close) {
        $whereCondition = array();
        $whereCondition["separator"] = $in_separator;
        $whereCondition["clam_open"] = $in_clam_open;
        $whereCondition["table"] = $in_table;
        $whereCondition["column"] = $in_column;
        $whereCondition["operator"] = $in_operator;
        $whereCondition["value"] = $in_value;
        $whereCondition["clam_close"] = $in_clam_close;
        
        $this->_whereConditionList[] = $whereCondition;
    }
    
    
    
    /** [optional] Ergänzt Join-Tabellen um entsprechende Conditions. JoinConditions können nicht in Verbindung mit Complex-TStaements genutzt werden.
     * 
     * @param string    $in_separator           (AND|OR) Auch für die erste Bedingung muss ein Seperator angegeben werden. 
     * @param string    $in_calm_open           öffnende Klammer (auch mehrere) oder Leerstring ""
     * @param string    $in_table_id            ID einer Tabelle, welche mit addTable angelegt wurde
     * @param string    $in_column              Spaltenname in table_id
     * @param string    $in_column_format       Format, in dem die linke Spalte umgewandelt werden soll. Wird mit der SQL-Funktion CAST verwendet. Wenn nicht notwendig, dann Leerstring übergeben.
     * @param string    $in_operator            (=|>=|like|in| ...)
     * @param string    $in_right_tablename     Tabellenname für rechte Seite
     * @param string    $in_right_columnname    Spaltenname für rechte Seite
     * @param string    $in_right_column_format Format, in dem die rechte Spalte umgewandelt werden soll. Wird mit der SQL-Funktion CAST verwendet. Wenn nicht notwendig, dann Leerstring übergeben.
     * @param string    $in_calm_close          schließende Klammer (auch mehrere) oder Leerstring ""
     */
    public function addJoinCondition($in_separator, $in_calm_open, $in_table_id, $in_column, $in_column_format, $in_operator, $in_right_tablename, $in_right_columnname, $in_right_column_format, $in_calm_close) {
        $joinCondition = array();
        $joinCondition["separator"] = $in_separator;
        $joinCondition["clam_open"] = $in_calm_open;
        $joinCondition["table_id"] = $in_table_id; 
        $joinCondition["table"] = $this->getTableNameById($in_table_id);
        $joinCondition["column"] = $in_column;
        $joinCondition["column_format"] = $in_column_format;
        $joinCondition["operator"] = $in_operator;
        $joinCondition["right_tablename"] = $in_right_tablename;
        $joinCondition["right_columnname"] = $in_right_columnname;
        $joinCondition["right_column_format"] = $in_right_column_format;
        $joinCondition["clam_close"] = $in_calm_close;
        
        $this->_joinConditionList[] = $joinCondition;
    }
    
    
    
    
    /** Ergänzt eine Spalte zur Gesamtliste der abzufragenden Spalten.
     * Alternativ kann auch addSelectComplexStatement genutzt werden. Dies ist i.d.R. schneller, lässt aber weniger Eingabeprüfungen zu.
     * Bei Select-Statements sind die Eingabeprüfungen jedoch nicht so wichtig wie bei den Statements, die Änderungen an der Datenbank vornehmen.
     * 
     * @param string    $in_table           Name der DB-Tabelle
     * @param string    $in_column          Spaltenname
     * @param string    $in_alias           [optional] Alias für den Spaltennamen; Hinweis: in der Ergebnismenge lautet der key dann: "table.alias", statt "table.column" (default = "")
     * @param string    $in_const           [optional] Konstante, welche gesetzt werden soll (default = "")
     * @param string    $in_function_id     [optional] [optional] ID einer Funktion (default = "")
     * @param string    $in_function_params [optional] Liste der Paramter, die zu einer function gehören. Bsp.: zur function "concat" können beliebig viele zu verketende Paramter durch Komma getrennt angegeben werden. (Beiepiele siehe Doku #Spaltenfunktionen)
     * @param boolean   $in_hidden          [noch nicht unterstützt] [optional] gibt an, ob eine Spalte ausgeblendet werden soll. (default = false)
     *      */
    public function addSelectColumn($in_table, $in_column, $in_alias = "", $in_const = "", $in_function_id = "", $in_function_params = "", $in_hidden = false) {
        $newColumn = array();
        $newColumn["table"] = $in_table;
        $newColumn["column"] = $in_column;
        $newColumn["alias"] = $in_alias;
        $newColumn["const"] = $in_const;
        $newColumn["function_id"] = $in_function_id;
        $newColumn["function_params"] = $in_function_params;
        $newColumn["hidden"] = $in_hidden;
        
        $this->_columnList[] = $newColumn; 
    }
    
    
    
    /** Diese Funktion kann genutzt werden, um komplexe SELECT-Statements zu realisieren, 
     * in den verschachtetelte Selects, Concat und sonstige Sprachelemente genutzt werden.
     * An die Where-Klausel werden zusätzlich Secutity-Conditions ergänzt.
     * Wenn diese Funktion genutzt wird, dann werden Spalten, dieüber addSelectColumn
     * ergänzt werden, ignoeriert.
     * 
     * BEACHTE: wenn diese Funktion genutzt wird, dann werden die Funktionen (addSelectColumn, addTable und addWhereCondition ) ignoriert.
     * 
     * @param string $in_select_part    kompletter SELECT-Part, in dem auch komplexe Ausdrücke verwendet werden können, ohne "SELECT" als Einleitung
     * @param string $in_from_part      kompletter FROM-Part, in dem auch komplexe Ausdrücke verwendet werden können, ohne "FROM" als Einleitung. Jedem Tabellennamen muss das Schema vorangestellt werden. Bsp.: "manager.account".
     * @param string $in_where_part     [optional] kompletter WHERE-Part, in dem auch komplexe Ausdrücke verwendet werden können, ohne "WHERE" als Einleitung
     * @param string $in_groupby_part   [optional] kompletter GROUP-BY-Part, in dem auch komplexe Ausdrücke verwendet werden können, ohne "GROUP BY" als Einleitung
     * @param string $in_orderby_part   [optional] kompletter ORDER-BY-Part, in dem auch komplexe Ausdrücke verwendet werden können, ohne "ORDER BY" als Einleitung
     */
    public function addSelectComplexStatement($in_select_part, $in_from_part, $in_where_part = "", $in_groupby_part = "", $in_orderby_part = "") {
        $this->_selectComplexPart = $in_select_part;
        $this->_fromComplexPart = $in_from_part;
        if ($in_where_part <> "") {$this->_whereComplexPart = "AND (".$in_where_part.")";} else {$this->_whereComplexPart = $in_where_part;}
        $this->_groupbyComplexPart = $in_groupby_part;
        $this->_orderbyComplexPart = $in_orderby_part;
        $this->_is_complex_statement = true;
        
        
        //beteiligte Tabellen ermitteln
        $this->deconstructComplexFromPart();
        
        //ToDo: whereSecurityCondiion für alle Tables ergänzen
        
    }
    
    
    /**
     * Extrahiert aus dem ComplexFromPart alle Tabellen und Schemaangaben
     */
    protected function deconstructComplexFromPart() {
        $myComlexFromPart = $this->_fromComplexPart;
        $table_counter = 0;
        
        $fromPartList = explode(",", $myComlexFromPart);                           //fromPart in Einzelabschnitte, pro Tabelle aufsplitten. Es können jedoch noch JOIN-Ausdrücke enthalten sein.
        //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  Tablelist:", $fromPartList, "INFO");
        foreach ($fromPartList as $fromPart) {
            $table_counter = $table_counter + 1;
            if(strpos(strtolower($fromPart), "join")) {
                $this->extractTablelistFromJoinstatement($fromPart, $table_counter);
            } else {
                //schema und table aufsplitten
                $schemaAndTable = explode(".", $fromPart);
                //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  Schema an Table:", $schemaAndTable, "INFO");
                if($fromPart == $schemaAndTable[0]) {
                    //Schema konnte nicht ermittelt werden
                    addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  Angabe des Schemata fehlt für Tabelle:", $fromPart, "ERROR");
                    return false;
                } else {
                    $schema = trim($schemaAndTable[0]);                         //der erste Teil ohne Leerzeichen vor dem Punkt sollte dem Schema entsprechen
                    if(strpos(strtolower($schemaAndTable[1])," as ")) {
                        //Im zweiten Teil könnte neben der Angabe der Tabelle auch ein alias enthalten sein.
                        $tableAndAlias = explode("as", strtolower($schemaAndTable[1]));
                        $table = trim($tableAndAlias[0]);
                        $alias = trim($tableAndAlias[1]);
                    } else {
                        $table = trim($schemaAndTable[1]);
                        $alias = "";
                    }
                    if($table_counter == 0) {$jointype = "BASE";} else {$jointype = "INNER";}
                    $this->addTable($schema, $table, $table_counter, $jointype, $alias);
                }
            }
        } 
        //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  Tablelist from complex Select-Command", $this->_tableList, "INFO");
        
    }
    
    
    /** Extrahiert aus einem Join-Statement die Angaben zur Tabelle. Jedoch nur Schema und Tabellenname. Alias wird ignoriert.
     * Alias-Angaben sollten jedoch im Falle der Übergabe einer  complexen Select-Anweisungen auch irrelevant sein. 
     * Hintergrund: die einzelnen Tabellen müssen aus den komplexen Selectangaben nur zum Zwecke der Ergänzung der Security-Einschränkungen
     * extrahiert werden. Die Security-Einschränkungen beziehen sich stets auf Tabellen, nicht auf Aliase.
     * 
     * @param type $in_joinstatement
     */
    protected function extractTablelistFromJoinstatement($in_joinstatement, $in_table_counter) {
        //das gesamte Statement wird anhand des strings " join " aufgesplittet. 
        //Danach enthält jeder Abschnitt eine Angabe zur Tabelle, wobei Schema und Tabelle stets am Anfnag stehen sollten
        $joinList = explode(" join ", strtolower($in_joinstatement));
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  JoinList:", $joinList, "INFO");
        foreach ($joinList as $joinPart) {
            //addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  JoinPart:", $joinPart, "INFO");
            $schemaAndRest = explode(".",$joinPart);
            //Im ersten Teil befindet sich das Schema. 
            $schema = trim($schemaAndRest[0]);
            //Der zweite Teil beginnt mit der Tabelle, einem Leerzeichen und dem Rest.
            $tableAndRest = explode(" ", $schemaAndRest[1]);
            $table = $tableAndRest[0];
            
            //ToDo: Jointype kann theoretisch aus $joinlist[0] erkannt werden. Indem Fall könnte "UNKNOWN" durch den richtigen jointype ersetzt werden.
            $this->addTable($schema, $table, $in_table_counter, "UNKNOWN", "");
        }
        
    }
    
    
    
    
    /** Ergänzt ein TableArray zur Liste der Tabellen
     * 
     * @param string $in_schema     
     * @param string $in_table
     * @param integer $in_id        ID der Tabelle, auf welche sich Join- und where-Conditions beziehen können
     * @param string $in_jointype   Jointyp (INNER, LEFT, RIGHT, CROSS, FULL or BASE) 
     *                              Besonderheit BASE: Kennzeichnet die Basistabelle, auf die sich der erst folgende Join bezieht.
     * @param string $in_alias      [optional]
     */
    public function addTable($in_schema, $in_table, $in_id, $in_jointype, $in_alias = "") {
        $myTable = array();
        $myTable["db_schema"] = $in_schema;
        $myTable["table"] = $in_table;
        $myTable["alias"] = $in_alias;
        $myTable["join"] = $in_jointype;
        $this->_tableList["$in_id"] = $myTable;
        
    }
    
    
    /** Ermittelt anhand eines Tabellennamens die id im Array sql_request ($this)
     * 
     * @param   integer     $in_tableName       Name einer Tabelle
     * @return  mixed                           ID oder false, wenn Tabellenname nicht gefunden wurde
     */
    public function getTableIdByName($in_tableName) {
        foreach ($this->_tableList as $table_id => $table_data) {
            if($table_data["table"] == $in_tableName) {
                return $table_id;
            }
        }
        
        return false;
    }
    
    
    
    /** Ermittelt anhand einer Tabellen-ID den Namen der Tabelle aus dem Array sql_request->_tableList ($this).
     * Wenn die Tabelle einer Alias hat, wird dieser zurück gegeben.
     * 
     * @param   integer     $in_tableName       Name einer Tabelle
     * @return  mixed                           ID oder false, wenn Tabellenname nicht gefunden wurde
     */
    public function getTableNameById($in_tableId) {
//        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . " ->  suche Tablename für id: ".$in_tableId, $this->_tableList, "INFO");
        if(isset($this->_tableList[$in_tableId])) {
            if($this->_tableList[$in_tableId]["alias"]=="") {
                return $this->_tableList[$in_tableId]["table"];
            } else {
                return $this->_tableList[$in_tableId]["alias"];
            }
        }
        
        
        return false;
    }
    
    
    
    
    
    /** Ermittelt anhand einer Column-ID den Namen der Spalte aus dem Array sql_request->_columnList ($this).
     * Wenn die Tabelle einer Alias hat, wird dieser zurück gegeben.
     * 
     * @param   integer     $in_ColumnId        Name einer Spalte
     * @return  mixed                           ID oder false, wenn Spaltenname nicht gefunden wurde
     */
    public function getColumnNameById($in_ColumnId) {
        
        if(isset($this->_tableList[$in_tableId])) {
            if($this->_tableList[$in_tableId]["alias"]=="") {
                return $this->_tableList[$in_tableId]["table"];
            } else {
                return $this->_tableList[$in_tableId]["alias"];
            }
        }
        
        
        return false;
    }
    
    
    /** Gibt die aktuelle Spaltenliste zurück.
     * 
     * @return array        Zweidimensionales Array <br />
     *                      1. Dimension: key = lfd. Nr.; value = array  <br />
     *                      2. Dimension: key = (table|column|alias|const|function_id|function_params|hidden); value = der jeweilige Wert
     */
    public function getColumnlist() {
        return $this->_columnList;
        
    }
    
    
}