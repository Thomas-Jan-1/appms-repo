<?php

/* 
 * Copyright (C) 2023 (Thomas J.; tomjan@gmx.de)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * 
 * Dieses Programm ist freie Software. Sie können es unter den Bedingungen 
 * der GNU General Public License, wie von der Free Software Foundation 
 * veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß 
 * Version 3 der Lizenz oder (nach Ihrer Option) jeder späteren Version. 
 * 
 * Die Veröffentlichung dieses Programms erfolgt in der Hoffnung, 
 * daß es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 * sogar ohne die implizite Garantie der MARKTREIFE oder der 
 * VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. 
 * Details finden Sie in der GNU General Public License. 
 * 
 * Sie sollten ein Exemplar der GNU General Public License zusammen 
 * mit diesem Programm erhalten haben. Falls nicht, 
 * siehe <http://www.gnu.org/licenses/>. 
 * 
 */

/**
 * Klasse stellt Methoden zur Protokollierung und zum Auslesen des Status von lang laufenden Prozessen bereit.
 * Der Status kann noch während der Ausführung per Ajax an den Client übergeben werden.
 *
 * @author thomas
 */
class progressstatus {
    
    
    private $app_id = "";
    
    /**
     * 
     * @var     string      Verzeichnis, indem temporären Dateien abgelegt werden. In den temporären Datein wird der Fortschrittstatus eines Prozesses abgelegt.
     */
    private $path = "";
    
    /**
     * Klasse stellt Methoden zur Protokollierung und zum Auslesen des Status von lang laufenden Prozessen bereit.
     * Der Status kann noch während der Ausführung per Ajax an den Client übergeben werden.
     */
    public function __construct() {
        
    }
    
    
    function __destruct() {
        $this->deleteOldStatusfiles($this->path);
    }
    
    
        /** Aktualisiert die Fortschrittswerte in der temporären Datei /data/[APP-ID]/temp/session_id.txt.
     * Diese können genutzt werden, um bei lang laufenden Methoden den Fortschritt persistent abzulegen.
     * Diese Werte könnten bspw. durch einen parallel laufenden Prozess des Clients (per Ajax angesteuert) genutzt werden, 
     * um den Anwender den Fortschritt darzustellen.
     * 
     * @param   string      $in_app_id                      APPID, notwendig, um den temporären Pfad einer APP, zur Ablage des Fortschrittstatus finden zu können.
     * @param   integer     $in_progress_cur_step           Aktueller Fortschrittsstand
     * @param   integer     $in_progress_range_end          [optional] Maximalwert der Fortschrittsskale; Default = 100
     * @param   string      $in_progress_task               [optional] Text, welcher dem Nutzer angezeigt wird. Default = "progress"   
     * @param   integer     $in_progress_range_start        [optional] Startwert der Fortschrittsskala; Default = 100
     * @return bool
     */
    public function setStatus($in_app_id, $in_progress_cur_step, $in_progress_range_end = 100, $in_progress_task = "progrss", $in_progress_range_start = 1) {
        $feedback = true;
        $arr_content = array();
        $this->app_id = $in_app_id;


        $arr_content['progress_start'] = $in_progress_range_start;
        $arr_content['progress_end'] = $in_progress_range_end;
        $arr_content['progress_current'] = $in_progress_cur_step;
        $arr_content['progress_task'] = replace_speicial_chars($in_progress_task, array("'","/","ä","ü","ö","Ä","Ö","Ü"));

        // Write the progress into file and serialize the PHP array into JSON format.
        // The file name is the session id.
        $path = global_variables::getPathForAppmsinstall_abs(false).global_variables::getPathForTemp_rel($in_app_id);
        $this->path = $path;
        //$result = file_put_contents($path . session_id() . ".txt", json_encode($arr_content), LOCK_EX);
        $result = file_put_contents($path . session_id() . ".txt", json_encode($arr_content));

        

        if ($result === false) {
            $feedback = false;
        }  

        return $feedback;
    }
    
    
    
    
    /** Löscht alle Dateien, im angegeben Pfad, die älter als x Minuten sind.
     * 
     * @param   string  $in_path            Pfad, in dem die temporären Dateien abgelegt sind.
     * @param   integer $in_age_in_minutes  Alter der Dateien in Minuten, die gelöscht werden sollen.
     */
    private function deleteOldStatusfiles($in_path, $in_age_in_minutes = 30) {
        $files = glob($in_path);
        $now   = time();

        foreach ($files as $file) {
          if (is_file($file)) {
            if ($now - filemtime($file) >= $in_age_in_minutes) { // 5 Minuten und älter
              unlink($file);
            }
          }
        }
    }  
    
    
    
    
    
     /** Ermittelt aus einer temporären Datei den aktuellen Fortschritt des laufenden Jobs
     * 
     * @return  array           Liste der Fortschrittsattribute: <br>
     *                          message -> label und progressbar in html-Syntax. message kann direkt einem anderen Objekt des DOM's als innerhtml übergeben werden. <br>
     *                          percent -> prozentualer Fortschrittswert <br>
     *                          
     *                          Wenn ein Fehler auftritt, dann erscheint ein entsprechender Text als message.
     */
    public function getStatus() {
        $app_id = $_SESSION["app_id"];
        addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> ', "Starte Statusabfrage für APP ".$app_id );
            
        $path = global_variables::getPathForAppmsinstall_abs(false).global_variables::getPathForTemp_rel($app_id);
        $file = $path . session_id() . ".txt";

        if (file_exists($file)) {
          $text = file_get_contents($file);
          //unlink($file);
          $obj = json_decode($text);
          addToDebug(__FILE__ . ' Zeile ' . __LINE__ . ' -> ' . __FUNCTION__ . ' -> öffne Statusfile', $file );
          
        

        //Rückgabewerte für ajax-Feedback setzen
//        $feedback["start_value"] = $obj->progress_start;
//        $feedback["cur_value"] = $obj->progress_current;
//        $feedback["end_value"] = $obj->progress_end;
//        $feedback["desc"] = $obj->progress_task;
        
            $percent = round($obj->progress_end / $obj->progress_current * 100, 0);
//          $percent = 1;   //Uncaught DivisionByZeroError: Division by zero in /var/www/html/appms/controller/functions.php:132
            $feedback["message"] = '<label for="first_appms_progress">'.$obj->progress_task.':</label> <br>'.
                                   '<progress id="first_appms_progress" value="'.$obj->progress_current.'" max="'.$obj->progress_end.'"> '.$obj->progress_task.' </progress>'.
                                   '<label>'.$obj->progress_current.' von '.$obj->progress_end.'</label>';
            $feedback["percent"] = $percent;
        } else {
            $feedback["message"] = "Für diese Funktion ist keine detaillierte Fortschrittsanzeige verfügbar oder diese wird gerade erst initialisiert (".$file.").";
            $feedback["percent"] = 0;
        }
        return $feedback;
    }
    
    
    
    
}
